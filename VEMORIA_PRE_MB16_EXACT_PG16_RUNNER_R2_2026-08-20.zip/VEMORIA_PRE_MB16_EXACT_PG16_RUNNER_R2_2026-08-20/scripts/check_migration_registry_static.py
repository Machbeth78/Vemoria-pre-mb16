from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DB_DIR = ROOT / "backend" / "database"
REGISTRY = ROOT / "backend" / "services" / "migration_registry_service.py"

# Migrazioni che devono essere visibili al runner prudente perché riguardano
# blocchi runtime/post-bootstrap recenti. Include anche i gap storici v112/v113
# e il namespace parallelo Authorized Memory v124-v127.
RUNTIME_CRITICAL_MIGRATIONS: list[str] = [
    "migration_v74_invio_hardening.sql",
    "migration_v95_sensitivity_overrides.sql",
    "migration_v96_user_operational_profile.sql",
    "migration_v97_v77_indexes.sql",
    "migration_v112_memory_operative_layer.sql",
    "migration_v113_backend_a_plus.sql",
    "migration_v124_authorized_memory_multi_device_macro_a.sql",
    "migration_v125_authorized_memory_cross_device_identity_macro_b.sql",
    "migration_v126_authorized_memory_selective_secure_line_macro_c.sql",
    "migration_v127_authorized_memory_revocation_propagation_macro_f.sql",
    "migration_v128_authorized_memory_professional_node_macro_d.sql",
    "migration_v129_authorized_memory_owner_control_macro_e.sql",
    "migration_v130_chat_native_macro_b_baseline_lock.sql",
    "migration_v131_chat_native_macro_c_candidates.sql",
    "migration_v132_chat_language_bridge_c1.sql",
    "migration_v133_chat_group_coordinato_visibility_d.sql",
    "migration_v134_chat_proof_ack_e.sql",
    "migration_v135_chat_final_ux_security_f.sql",
    "migration_v136_gate05_recovery_backup_capsula.sql",
    "migration_v137_gate05_r1a_adaptive_profile_encryption_contract.sql",
    "migration_v138_gate05_r1b_restore_preflight.sql",
    "migration_v139_gate06_self_knowledge_atlas.sql",
    "migration_v140_gate06_r1a_scrivania_guided_atlas.sql",
    "migration_v141_gate06_r1b_guided_operational_contracts.sql",
    "migration_v142_gate06_r1c_satellite_contracts.sql",
    "migration_v143_gate06_r1d_p0_foundation_static_completion.sql",
    "migration_v144_gate06_r1e_p1_core_guards_static_completion.sql",
    "migration_v145_gate06_r1f_p2_input_memory_static_completion.sql",
    "migration_v146_gate06_r1g_p3_user_surfaces_static_completion.sql",
    "migration_v147_gate06_r1h_p4_localization_static_completion.sql",
    "migration_v148_gate06_r1i_p5_relations_chat_static_completion.sql",
    "migration_v149_gate06_r1j_p6_fabric_proof_static_completion.sql",
    "migration_v150_gate06_r1k_p7_commercial_distribution_static_completion.sql",
    "migration_v151_gate07a_p0_functional_completion.sql",
    "migration_v152_gate07b_p1_core_guards_functional_completion.sql",
    "migration_v153_gate07c_p2_input_memory_functional_completion.sql",
    "migration_v154_gate07d_p3_user_surfaces_functional_completion.sql",
    "migration_v155_gate07e_p4_localization_functional_completion.sql",
    "migration_v156_gate07f_p5_relations_chat_functional_completion.sql",
    "migration_v157_gate07g_p6_fabric_proof_functional_completion.sql",
    "migration_v158_gate07h_p7_commercial_distribution_functional_completion.sql",
    "migration_v159_gate08_pre_fiduciary_invariants.sql",
    "migration_v160_gate08a_source_atlas_provenance.sql",
    "migration_v161_gate08a_r1_relation_source_vertical_guards.sql",
    "migration_v162_gate08b_active_workfile.sql",
    "migration_v163_gate08b5_device_capability_guide.sql",
    "migration_v164_gate08c_document_understanding.sql",
    "migration_v165_gate08d_consumer_intelligence_owner_agent.sql",
    "migration_v166_gate08e_language_lexicon_translation.sql",
    "migration_v167_gate08f_runtime_modular_probes.sql",
    "migration_v168_gate08g_cerebro_orchestrator.sql",
    "migration_v169_gate08g_r1_cerebro_engine_policy.sql",
    "migration_v170_gate08g_r1b_capability_explanation.sql",
]

# Queste non passano dal runner MANAGED_MIGRATIONS per design o sono guardie
# di rollback/probe. Il test anti-ricaduta ignora solo questa allowlist esplicita.
INTENTIONALLY_UNMANAGED_SQL: set[str] = {
    *(f"migration_v{i}.sql" for i in range(2, 27)),
    "migration_v4b.sql",
    "migration_v122_fabric_receipt_trust_rollback_guard.sql",
}

ORDER_CONSTRAINTS: list[tuple[str, str]] = [
    ("migration_v112_memory_operative_layer.sql", "migration_v113_backend_a_plus.sql"),
    ("migration_v123_fabric_recovery_replay_metrics.sql", "migration_v124_authorized_memory_multi_device_macro_a.sql"),
    ("migration_v124_authorized_memory_multi_device_macro_a.sql", "migration_v125_authorized_memory_cross_device_identity_macro_b.sql"),
    ("migration_v125_authorized_memory_cross_device_identity_macro_b.sql", "migration_v126_authorized_memory_selective_secure_line_macro_c.sql"),
    ("migration_v126_authorized_memory_selective_secure_line_macro_c.sql", "migration_v127_authorized_memory_revocation_propagation_macro_f.sql"),
    ("migration_v127_authorized_memory_revocation_propagation_macro_f.sql", "migration_v128_authorized_memory_professional_node_macro_d.sql"),
    ("migration_v128_authorized_memory_professional_node_macro_d.sql", "migration_v129_authorized_memory_owner_control_macro_e.sql"),
    ("migration_v129_authorized_memory_owner_control_macro_e.sql", "migration_v130_chat_native_macro_b_baseline_lock.sql"),
    ("migration_v130_chat_native_macro_b_baseline_lock.sql", "migration_v131_chat_native_macro_c_candidates.sql"),
    ("migration_v131_chat_native_macro_c_candidates.sql", "migration_v132_chat_language_bridge_c1.sql"),
    ("migration_v132_chat_language_bridge_c1.sql", "migration_v133_chat_group_coordinato_visibility_d.sql"),
    ("migration_v133_chat_group_coordinato_visibility_d.sql", "migration_v134_chat_proof_ack_e.sql"),
    ("migration_v134_chat_proof_ack_e.sql", "migration_v135_chat_final_ux_security_f.sql"),
    ("migration_v135_chat_final_ux_security_f.sql", "migration_v136_gate05_recovery_backup_capsula.sql"),
    ("migration_v136_gate05_recovery_backup_capsula.sql", "migration_v137_gate05_r1a_adaptive_profile_encryption_contract.sql"),
    ("migration_v137_gate05_r1a_adaptive_profile_encryption_contract.sql", "migration_v138_gate05_r1b_restore_preflight.sql"),
    ("migration_v138_gate05_r1b_restore_preflight.sql", "migration_v139_gate06_self_knowledge_atlas.sql"),
    ("migration_v139_gate06_self_knowledge_atlas.sql", "migration_v140_gate06_r1a_scrivania_guided_atlas.sql"),
    ("migration_v140_gate06_r1a_scrivania_guided_atlas.sql", "migration_v141_gate06_r1b_guided_operational_contracts.sql"),
    ("migration_v141_gate06_r1b_guided_operational_contracts.sql", "migration_v142_gate06_r1c_satellite_contracts.sql"),
    ("migration_v142_gate06_r1c_satellite_contracts.sql", "migration_v143_gate06_r1d_p0_foundation_static_completion.sql"),
    ("migration_v143_gate06_r1d_p0_foundation_static_completion.sql", "migration_v144_gate06_r1e_p1_core_guards_static_completion.sql"),
    ("migration_v144_gate06_r1e_p1_core_guards_static_completion.sql", "migration_v145_gate06_r1f_p2_input_memory_static_completion.sql"),
    ("migration_v145_gate06_r1f_p2_input_memory_static_completion.sql", "migration_v146_gate06_r1g_p3_user_surfaces_static_completion.sql"),
    ("migration_v146_gate06_r1g_p3_user_surfaces_static_completion.sql", "migration_v147_gate06_r1h_p4_localization_static_completion.sql"),
    ("migration_v147_gate06_r1h_p4_localization_static_completion.sql", "migration_v148_gate06_r1i_p5_relations_chat_static_completion.sql"),
    ("migration_v148_gate06_r1i_p5_relations_chat_static_completion.sql", "migration_v149_gate06_r1j_p6_fabric_proof_static_completion.sql"),
    ("migration_v149_gate06_r1j_p6_fabric_proof_static_completion.sql", "migration_v150_gate06_r1k_p7_commercial_distribution_static_completion.sql"),
    ("migration_v150_gate06_r1k_p7_commercial_distribution_static_completion.sql", "migration_v151_gate07a_p0_functional_completion.sql"),
    ("migration_v151_gate07a_p0_functional_completion.sql", "migration_v152_gate07b_p1_core_guards_functional_completion.sql"),
    ("migration_v152_gate07b_p1_core_guards_functional_completion.sql", "migration_v153_gate07c_p2_input_memory_functional_completion.sql"),
    ("migration_v153_gate07c_p2_input_memory_functional_completion.sql", "migration_v154_gate07d_p3_user_surfaces_functional_completion.sql"),
    ("migration_v154_gate07d_p3_user_surfaces_functional_completion.sql", "migration_v155_gate07e_p4_localization_functional_completion.sql"),
    ("migration_v155_gate07e_p4_localization_functional_completion.sql", "migration_v156_gate07f_p5_relations_chat_functional_completion.sql"),
    ("migration_v156_gate07f_p5_relations_chat_functional_completion.sql", "migration_v157_gate07g_p6_fabric_proof_functional_completion.sql"),
    ("migration_v157_gate07g_p6_fabric_proof_functional_completion.sql", "migration_v158_gate07h_p7_commercial_distribution_functional_completion.sql"),
    ("migration_v158_gate07h_p7_commercial_distribution_functional_completion.sql", "migration_v159_gate08_pre_fiduciary_invariants.sql"),
    ("migration_v159_gate08_pre_fiduciary_invariants.sql", "migration_v160_gate08a_source_atlas_provenance.sql"),
    ("migration_v160_gate08a_source_atlas_provenance.sql", "migration_v161_gate08a_r1_relation_source_vertical_guards.sql"),
    ("migration_v161_gate08a_r1_relation_source_vertical_guards.sql", "migration_v162_gate08b_active_workfile.sql"),
    ("migration_v162_gate08b_active_workfile.sql", "migration_v163_gate08b5_device_capability_guide.sql"),
    ("migration_v163_gate08b5_device_capability_guide.sql", "migration_v164_gate08c_document_understanding.sql"),
    ("migration_v164_gate08c_document_understanding.sql", "migration_v165_gate08d_consumer_intelligence_owner_agent.sql"),
    ("migration_v165_gate08d_consumer_intelligence_owner_agent.sql", "migration_v166_gate08e_language_lexicon_translation.sql"),
    ("migration_v166_gate08e_language_lexicon_translation.sql", "migration_v167_gate08f_runtime_modular_probes.sql"),
    ("migration_v167_gate08f_runtime_modular_probes.sql", "migration_v168_gate08g_cerebro_orchestrator.sql"),
    ("migration_v168_gate08g_cerebro_orchestrator.sql", "migration_v169_gate08g_r1_cerebro_engine_policy.sql"),
    ("migration_v169_gate08g_r1_cerebro_engine_policy.sql", "migration_v170_gate08g_r1b_capability_explanation.sql"),
]


def load_managed_migrations() -> list[str]:
    tree = ast.parse(REGISTRY.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.AnnAssign) and getattr(node.target, "id", None) == "MANAGED_MIGRATIONS":
            return [item.value for item in node.value.elts if isinstance(item, ast.Constant) and isinstance(item.value, str)]
    raise RuntimeError("MANAGED_MIGRATIONS not found")


def sql_migration_files() -> list[str]:
    return sorted(path.name for path in DB_DIR.glob("migration*.sql"))


def _version_sort_key(name: str) -> tuple[int, str]:
    match = re.search(r"migration_v(\d+)", name)
    return (int(match.group(1)) if match else 10_000, name)


def build_report() -> dict[str, Any]:
    managed = load_managed_migrations()
    managed_set = set(managed)
    files = sql_migration_files()
    file_set = set(files)

    missing_from_registry = sorted(file_set - managed_set, key=_version_sort_key)
    unmanaged_unexpected = [name for name in missing_from_registry if name not in INTENTIONALLY_UNMANAGED_SQL]
    managed_without_file = [name for name in managed if name not in file_set]

    runtime_critical = {
        name: {"exists": name in file_set, "managed": name in managed_set}
        for name in RUNTIME_CRITICAL_MIGRATIONS
    }

    positions = {name: idx for idx, name in enumerate(managed)}
    order_issues = []
    for before, after in ORDER_CONSTRAINTS:
        if before not in positions or after not in positions:
            order_issues.append({"before": before, "after": after, "issue": "missing_from_managed_list"})
        elif positions[before] >= positions[after]:
            order_issues.append({"before": before, "after": after, "issue": "wrong_order"})

    issues: list[str] = []
    if managed_without_file:
        issues.append("Managed migrations senza file SQL: " + ", ".join(managed_without_file))
    if unmanaged_unexpected:
        issues.append("Migrazioni SQL non gestite dal runner: " + ", ".join(unmanaged_unexpected))
    missing_critical = [name for name, status in runtime_critical.items() if not status["exists"] or not status["managed"]]
    if missing_critical:
        issues.append("Migrazioni runtime critical mancanti/non gestite: " + ", ".join(missing_critical))
    if order_issues:
        issues.append("Ordine dipendenze migration non valido")

    return {
        "ok": not issues,
        "managed_count": len(managed),
        "sql_file_count": len(files),
        "missing_from_registry": missing_from_registry,
        "intentionally_unmanaged_sql": sorted(INTENTIONALLY_UNMANAGED_SQL, key=_version_sort_key),
        "unexpected_unmanaged_sql": unmanaged_unexpected,
        "managed_without_file": managed_without_file,
        "runtime_critical_migrations": runtime_critical,
        "order_issues": order_issues,
        "issues": issues,
    }


if __name__ == "__main__":
    import json
    print(json.dumps(build_report(), ensure_ascii=False, indent=2))
