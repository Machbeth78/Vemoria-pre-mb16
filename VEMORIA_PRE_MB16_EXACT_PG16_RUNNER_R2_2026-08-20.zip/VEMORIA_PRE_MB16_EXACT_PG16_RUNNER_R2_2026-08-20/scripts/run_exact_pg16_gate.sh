#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
LOG="$ROOT/evidence/PRE_MB16_EXACT_PG16_RUNTIME.log"
: > "$LOG"
exec > >(tee -a "$LOG") 2>&1

export PGPASSWORD="${PGPASSWORD:-postgres}"
export PGHOST="${PGHOST:-127.0.0.1}"
export PGPORT="${PGPORT:-5432}"
export PGUSER="${PGUSER:-postgres}"
export VEMORA_DATABASE_URL="postgresql://${PGUSER}:${PGPASSWORD}@${PGHOST}:${PGPORT}/vemoria_test_db"
export PYTHONPATH="$ROOT/backend"

command -v psql >/dev/null || { echo 'FAIL: psql missing'; exit 20; }
command -v python3 >/dev/null || { echo 'FAIL: python3 missing'; exit 21; }
VER="$(psql -d postgres -Atc 'SHOW server_version_num;')"
echo "server_version_num=$VER"
[[ "$VER" =~ ^16[0-9]{4}$ ]] || { echo "FAIL exact PG16: $VER"; exit 22; }

python3 scripts/verify_migration_order.py
PYTHONPATH=backend python3 scripts/check_migration_registry_static.py

psql -v ON_ERROR_STOP=1 -d postgres -c 'DROP DATABASE IF EXISTS vemoria_test_db WITH (FORCE);'
psql -v ON_ERROR_STOP=1 -d postgres -c 'CREATE DATABASE vemoria_test_db;'

# Supabase compatibility role names are needed for exact ACL/revoke semantics.
psql -v ON_ERROR_STOP=1 -d vemoria_test_db <<'SQL'
DO $$ BEGIN
 IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN CREATE ROLE anon NOLOGIN NOSUPERUSER NOBYPASSRLS; END IF;
 IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN CREATE ROLE authenticated NOLOGIN NOSUPERUSER NOBYPASSRLS; END IF;
 IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='service_role') THEN CREATE ROLE service_role NOLOGIN NOSUPERUSER NOBYPASSRLS; END IF;
END $$;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;
SQL

psql -v ON_ERROR_STOP=1 -d vemoria_test_db -f checks/00_PRECHECK.sql
psql -v ON_ERROR_STOP=1 -d vemoria_test_db -f backend/database/init_full.sql
PYTHONPATH=backend VEMORA_DATABASE_URL="$VEMORA_DATABASE_URL" python3 backend/tools/migration_runner.py apply-pending
PYTHONPATH=backend VEMORA_DATABASE_URL="$VEMORA_DATABASE_URL" python3 backend/tools/migration_runner.py status

# v296 runtime closure: inline the frozen pre-v296 authority and then remove transport helpers.
psql -v ON_ERROR_STOP=1 -d vemoria_test_db -f checks/94_V296_FALLBACK_REBIND_CLOSURE.sql
psql -v ON_ERROR_STOP=1 -d vemoria_test_db -c 'DROP FUNCTION IF EXISTS public.mb13_p0_validate_target_pre296(UUID,TEXT,JSONB,BOOLEAN); DROP FUNCTION IF EXISTS public.mb13_p0_lock_and_verify_consents_pre296(UUID,JSONB,TEXT,JSONB,BOOLEAN,BOOLEAN);'

# Reproduce final post-v296 security closure on isolated PG16.
psql -v ON_ERROR_STOP=1 -d vemoria_test_db -f checks/93_POST_V296_SECURITY_CLOSURE_PG16.sql

# Probe the previously broken non-generic branch after helper cleanup.
psql -v ON_ERROR_STOP=1 -d vemoria_test_db -c "SELECT public.mb13_p0_validate_target('11111111-1111-4111-8111-111111111111','rule',jsonb_build_object('id','r','revision',1,'payload_hash',repeat('a',64),'owner_user_id','11111111-1111-4111-8111-111111111111','state','active'),false);"

psql -v ON_ERROR_STOP=1 -d vemoria_test_db -f checks/90_POST_MIGRATION_AUDIT.sql
psql -v ON_ERROR_STOP=1 -d vemoria_test_db -f checks/95_PRE_MB16_SECURITY_RUNTIME_AUDIT.sql
psql -v ON_ERROR_STOP=1 -d vemoria_test_db -f checks/96_V296_RLS_OWNER_ISOLATION_SMOKE.sql

REGCOUNT="$(psql -d vemoria_test_db -Atc 'SELECT count(*) FROM public.schema_migration_state;')"
V296COUNT="$(psql -d vemoria_test_db -Atc \"SELECT count(*) FROM public.schema_migration_state WHERE migration_name='migration_v296_generic_interest_watch.sql';\")"
HELPERS="$(psql -d vemoria_test_db -Atc \"SELECT (to_regprocedure('public.mb13_p0_validate_target_pre296(uuid,text,jsonb,boolean)') IS NULL AND to_regprocedure('public.mb13_p0_lock_and_verify_consents_pre296(uuid,jsonb,text,jsonb,boolean,boolean)') IS NULL)::int;\")"
[[ "$REGCOUNT" == "273" ]] || { echo "FAIL registry_rows=$REGCOUNT expected=273"; exit 31; }
[[ "$V296COUNT" == "1" ]] || { echo "FAIL v296_registry_rows=$V296COUNT expected=1"; exit 32; }
[[ "$HELPERS" == "1" ]] || { echo "FAIL v296 pre296 transport helpers not cleaned"; exit 33; }

python3 - "$VER" "$REGCOUNT" "$V296COUNT" <<'PY'
import hashlib, json, sys, pathlib, datetime
root=pathlib.Path('.')
ver, reg, v296=sys.argv[1:]
files=sorted((root/'backend/database').glob('*.sql'))
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
out={
 'checkpoint_target':'PRE-MB16-FINAL-CLEAN',
 'gate':'EXACT_POSTGRESQL_16',
 'status':'PASS',
 'server_version_num':ver,
 'registry_rows':int(reg),
 'v296_registry_rows':int(v296),
 'v296_transport':'canonical source hash retained; five-to-six argument adaptation executed in memory only',
 'v296_fallback_rebind_closure':'PASS; *_pre296 helpers removed after dependency-free rebind',
 'post_v296_security_closure':'reproduced on isolated PG16',
 'canonical_sql_file_count':len(files),
 'canonical_sql_sha256':hashes,
 'generated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(root/'evidence/PRE_MB16_EXACT_PG16_PROOF.json').write_text(json.dumps(out,indent=2,sort_keys=True),encoding='utf-8')
PY
sha256sum evidence/PRE_MB16_EXACT_PG16_RUNTIME.log evidence/PRE_MB16_EXACT_PG16_PROOF.json > evidence/SHA256SUMS.txt

echo '============================================================'
echo 'PRE_MB16_EXACT_PG16_GATE=PASS'
echo "server_version_num=$VER"
echo "registry_rows=$REGCOUNT v296_registry_rows=$V296COUNT"
echo '============================================================'
