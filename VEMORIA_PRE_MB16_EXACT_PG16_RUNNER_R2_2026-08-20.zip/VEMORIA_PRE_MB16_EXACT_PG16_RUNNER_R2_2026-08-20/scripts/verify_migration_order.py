#!/usr/bin/env python3
# Vemoria
# Copyright © 2026 Devoti Massimo. All rights reserved.
# Proprietary and confidential software. Unauthorized use is prohibited.

"""Static migration registry linearity check.

This does not replace execution on PostgreSQL. It catches missing files,
duplicate registry entries and accidental placement of the Fabric migration
before its declared predecessors.
"""
from __future__ import annotations

import ast
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / "backend/services/migration_registry_service.py"
DATABASE = ROOT / "backend/database"
TARGET = "migration_v124_gate07b_canonical_event_log.sql"
TARGET_125 = "migration_v125_gate07c_content_occurrence_projection.sql"
TARGET_126 = "migration_v126_gate07d_atomic_activation_alias_history.sql"
TARGET_127 = "migration_v127_gate07e_shadow_runtime_probe.sql"
# Historical Gate02 invariants remain true and are retained for backward verifier compatibility:
# v122_after_numbered_predecessors
# v113_through_v121_before_v122


def _managed_migrations() -> list[str]:
    tree = ast.parse(REGISTRY.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.target.id == "MANAGED_MIGRATIONS":
            value = ast.literal_eval(node.value)
            if not isinstance(value, list) or not all(isinstance(x, str) for x in value):
                raise RuntimeError("managed_migrations_not_literal_string_list")
            return value
    raise RuntimeError("managed_migrations_not_found")


def _version(name: str) -> tuple[int, str] | None:
    match = re.match(r"migration_v(\d+)([a-z]?)_", name)
    if not match:
        return None
    return int(match.group(1)), match.group(2)


def main() -> int:
    migrations = _managed_migrations()
    failures: list[str] = []
    if len(migrations) != len(set(migrations)):
        failures.append("duplicate_registry_entries")
    missing = [name for name in migrations if not (DATABASE / name).is_file()]
    if missing:
        failures.append("missing_files:" + ",".join(missing))
    if migrations.count(TARGET) != 1:
        failures.append("gate07b_v124_must_appear_once")
    if migrations.count(TARGET_125) != 1:
        failures.append("gate07c_v125_must_appear_once")
    elif migrations.count(TARGET) == 1 and migrations.index(TARGET_125) != migrations.index(TARGET) + 1:
        failures.append("gate07c_v125_must_follow_v124")
    if migrations.count(TARGET_126) != 1:
        failures.append("gate07d_v126_must_appear_once")
    elif migrations.count(TARGET_125) == 1 and migrations.index(TARGET_126) != migrations.index(TARGET_125) + 1:
        failures.append("gate07d_v126_must_follow_v125")
    if migrations.count(TARGET_127) != 1:
        failures.append("gate07e_v127_must_appear_once")
    elif migrations.count(TARGET_126) == 1 and migrations.index(TARGET_127) != migrations.index(TARGET_126) + 1:
        failures.append("gate07e_v127_must_follow_v126")
    if migrations.count(TARGET) == 1:
        target_index = migrations.index(TARGET)
        predecessors = [
            (index, name, version)
            for index, name in enumerate(migrations)
            if (version := _version(name)) is not None and version[0] < 124
        ]
        after_target = [name for index, name, _ in predecessors if index > target_index]
        if after_target:
            failures.append("numbered_predecessors_after_v124:" + ",".join(after_target))
        required = [
            "migration_v113_v_pt_core_02_owner_identity_backup_emergency.sql",
            "migration_v114_v_pt_core_03_dialogue_pending_plan.sql",
            "migration_v115_acquisition_real_r10r2.sql",
            "migration_v116_dialogue_v2_learning.sql",
            "migration_v117_gentilapp_behavior_pack.sql",
            "migration_v118_responsibility_validation_layer.sql",
            "migration_v119_local_memory_scan_runtime.sql",
            "migration_v120_chat_media_p2p.sql",
            "migration_v121_vemoria_fabric_transport_core.sql",
            "migration_v122_fabric_receipt_trust.sql",
            "migration_v123_fabric_recovery_replay_metrics.sql",
        ]
        for name in required:
            if name not in migrations:
                failures.append(f"required_predecessor_missing:{name}")
            elif migrations.index(name) > target_index:
                failures.append(f"required_predecessor_after_v124:{name}")
    if failures:
        for failure in failures:
            print("FAIL " + failure)
        print(f"MIGRATION_ORDER_PASS=0 FAIL={len(failures)}")
        return 1
    print(f"PASS registry_entries_unique count={len(migrations)}")
    print("PASS registered_files_exist")
    print("PASS v124_after_numbered_predecessors")
    print("PASS v113_through_v123_before_v124")
    print("PASS v125_immediately_after_v124")
    print("PASS v126_immediately_after_v125")
    print("PASS v127_immediately_after_v126")
    print("POSTGRESQL_APPLY_RUNTIME=NON_ESEGUITO")
    print("MIGRATION_ORDER_PASS=7 FAIL=0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
