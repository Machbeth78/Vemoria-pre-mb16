#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DOCKER_COMPOSE_FILE="${REPO_ROOT}/docker-compose.dev.yml"

# Se PostgreSQL è già raggiungibile, usa quello attivo senza tentare Docker.
if PGPASSWORD=postgres pg_isready -h 127.0.0.1 -p 5432 -U postgres >/dev/null 2>&1; then
    echo "[start_test_postgres] PostgreSQL già disponibile su 127.0.0.1:5432"
else
    # Idempotente: se il container esiste già, lo avvia; altrimenti lo crea.
    if docker ps -a --format '{{.Names}}' | grep -qx vemoria-postgres; then
        echo "[start_test_postgres] container vemoria-postgres esistente, avvio..."
        docker start vemoria-postgres >/dev/null 2>&1 || true
    else
        if docker compose version >/dev/null 2>&1; then
            docker compose -f "${DOCKER_COMPOSE_FILE}" up -d
        elif docker-compose version >/dev/null 2>&1; then
            docker-compose -f "${DOCKER_COMPOSE_FILE}" up -d
        else
            echo "[start_test_postgres] docker compose non disponibile; uso docker run fallback"
            docker run -d \
                --name vemoria-postgres \
                -e POSTGRES_USER=postgres \
                -e POSTGRES_PASSWORD=postgres \
                -e POSTGRES_DB=vemoria_test_db \
                -p 127.0.0.1:5432:5432 \
                -v vemoria_postgres_data:/var/lib/postgresql/data \
                postgres:16
        fi
    fi
fi

echo "[start_test_postgres] in attesa di PostgreSQL..."
for i in {1..30}; do
    if PGPASSWORD=postgres pg_isready -h 127.0.0.1 -p 5432 -U postgres >/dev/null 2>&1; then
        break
    fi
    sleep 1
done

if ! PGPASSWORD=postgres pg_isready -h 127.0.0.1 -p 5432 -U postgres >/dev/null 2>&1; then
    echo "[start_test_postgres] ERRORE: PostgreSQL non pronto"
    exit 1
fi

PGPASSWORD=postgres psql -h 127.0.0.1 -U postgres -d postgres -c "SELECT 1" >/dev/null 2>&1 || {
    echo "[start_test_postgres] ERRORE: impossibile connettersi al server"
    exit 1
}

SERVER_VERSION_NUM="$(PGPASSWORD=postgres psql -h 127.0.0.1 -U postgres -d postgres -Atc "SHOW server_version_num;" 2>/dev/null || true)"
if [[ ! "${SERVER_VERSION_NUM}" =~ ^16[0-9]{4}$ ]]; then
    echo "[start_test_postgres] ERRORE: richiesto PostgreSQL server 16, trovato server_version_num=${SERVER_VERSION_NUM:-UNKNOWN}"
    exit 1
fi

PGPASSWORD=postgres psql -h 127.0.0.1 -U postgres -d postgres -tc "SELECT 1 FROM pg_database WHERE datname='vemoria_test_db'" | grep -q 1 || \
    PGPASSWORD=postgres psql -h 127.0.0.1 -U postgres -d postgres -c "CREATE DATABASE vemoria_test_db;"

PGPASSWORD=postgres psql -v ON_ERROR_STOP=1 -h 127.0.0.1 -U postgres -d vemoria_test_db -c 'CREATE EXTENSION IF NOT EXISTS "uuid-ossp";' >/dev/null
PGPASSWORD=postgres psql -v ON_ERROR_STOP=1 -h 127.0.0.1 -U postgres -d vemoria_test_db -c "CREATE EXTENSION IF NOT EXISTS pgcrypto;" >/dev/null
PGPASSWORD=postgres psql -v ON_ERROR_STOP=1 -h 127.0.0.1 -U postgres -d vemoria_test_db -c "CREATE EXTENSION IF NOT EXISTS pg_trgm;" >/dev/null

echo "[start_test_postgres] PostgreSQL 16 pronto su 127.0.0.1:5432/vemoria_test_db"
