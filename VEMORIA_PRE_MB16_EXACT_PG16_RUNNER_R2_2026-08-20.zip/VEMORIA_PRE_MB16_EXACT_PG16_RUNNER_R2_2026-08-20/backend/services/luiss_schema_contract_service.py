# Vemoria
# Copyright © 2026 Devoti Massimo. All rights reserved.
# Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

"""Guardie leggere sui contratti schema critici per LUISS/core datetime."""
from __future__ import annotations

import logging
from typing import Any

from sqlalchemy import text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

logger = logging.getLogger("vemora.luiss_schema_contract")


def _dialect_name(session_or_conn: Session | Any) -> str:
    bind_getter = getattr(session_or_conn, "get_bind", None)
    if callable(bind_getter):
        bind = bind_getter()
        if bind is not None and getattr(bind, "dialect", None) is not None:
            return bind.dialect.name
    dialect = getattr(session_or_conn, "dialect", None)
    if dialect is not None:
        return dialect.name
    engine = getattr(session_or_conn, "engine", None)
    if engine is not None and getattr(engine, "dialect", None) is not None:
        return engine.dialect.name
    return "unknown"


_CRITICAL_COLUMNS: dict[str, tuple[str, str]] = {
    # runtime context LUISS
    "luiss_runtime_context.avviato_il": ("luiss_runtime_context", "avviato_il"),
    "luiss_runtime_context.aggiornato_il": ("luiss_runtime_context", "aggiornato_il"),
    # core entities — datetime foundation V52/V66
    "utenti.creato_il": ("utenti", "creato_il"),
    "utenti.aggiornato_il": ("utenti", "aggiornato_il"),
    "documenti.creato_il": ("documenti", "creato_il"),
    "documenti.aggiornato_il": ("documenti", "aggiornato_il"),
    "memorie.creata_il": ("memorie", "creata_il"),
    "memorie.aggiornato_il": ("memorie", "aggiornato_il"),
    # residui datetime naive segnalati in audit V57 (BUG-3)
    "memorie.data_documento": ("memorie", "data_documento"),
    "memorie.confermata_il": ("memorie", "confermata_il"),
    "eventi_invio.data_scadenza": ("eventi_invio", "data_scadenza"),
    "schema_migration_state.applied_il": ("schema_migration_state", "applied_il"),
}

_REQUIRED_INDEXES: dict[str, str] = {
    "idx_luiss_decision_utente": "idx_luiss_decision_utente",
}

# Tabelle LUISS core che devono esistere per il funzionamento (BUG-5)
_REQUIRED_LUISS_TABLES: list[str] = [
    "luiss_decision_log",
    "luiss_feedback_log",
    "luiss_review_state",
    "luiss_review_event",
]

# Colonne non-datetime la cui presenza è contrattualmente richiesta (BUG-5)
_REQUIRED_COLUMN_PRESENCE: dict[str, tuple[str, str]] = {
    "luiss_review_state.version": ("luiss_review_state", "version"),
}


def _column_signature(session_or_conn: Session | Any, table_name: str, column_name: str) -> dict[str, Any]:
    row = session_or_conn.execute(text(
        """
        SELECT data_type, udt_name
        FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = :table_name
          AND column_name = :column_name
        LIMIT 1
        """
    ), {"table_name": table_name, "column_name": column_name}).mappings().fetchone()
    if not row:
        return {"present": False, "data_type": None, "udt_name": None, "is_timestamptz": False}
    data_type = str(row.get("data_type") or "")
    udt_name = str(row.get("udt_name") or "")
    return {
        "present": True,
        "data_type": data_type,
        "udt_name": udt_name,
        "is_timestamptz": data_type == "timestamp with time zone" or udt_name == "timestamptz",
    }


def _column_present(session_or_conn: Session | Any, table_name: str, column_name: str) -> bool:
    """Verifica solo la presenza di una colonna, senza controllare il tipo."""
    row = session_or_conn.execute(text(
        """
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = :table_name
          AND column_name = :column_name
        LIMIT 1
        """
    ), {"table_name": table_name, "column_name": column_name}).fetchone()
    return bool(row)


def _table_present(session_or_conn: Session | Any, table_name: str) -> bool:
    value = session_or_conn.execute(
        text("SELECT to_regclass(:table_name)"),
        {"table_name": f"public.{table_name}"},
    ).scalar()
    return bool(value)


def _index_exists(session_or_conn: Session | Any, index_name: str) -> bool:
    row = session_or_conn.execute(text(
        """
        SELECT 1
        FROM pg_indexes
        WHERE schemaname = 'public' AND indexname = :index_name
        LIMIT 1
        """
    ), {"index_name": index_name}).fetchone()
    return bool(row)


def build_luiss_schema_contract_status(session_or_conn: Session | Any) -> dict[str, Any]:
    dialect_name = _dialect_name(session_or_conn)
    if dialect_name != 'postgresql':
        return {
            'dialect': dialect_name,
            'critical_columns': {},
            'indexes': {},
            'luiss_tables': {},
            'required_columns': {},
            'contracts': {},
            'residual_datetime': {
                'expected_columns': [],
                'present_columns': [],
                'missing_columns': [],
            },
            'issues': [
                {
                    'kind': 'unsupported_dialect',
                    'dialect': dialect_name,
                    'severity': 'error',
                }
            ],
            'error_count': 1,
            'warning_count': 0,
            'has_warnings': False,
            'is_blocking': True,
            'is_clean': False,
        }
    critical_columns = {
        key: _column_signature(session_or_conn, table_name, column_name)
        for key, (table_name, column_name) in _CRITICAL_COLUMNS.items()
    }
    indexes = {key: _index_exists(session_or_conn, index_name) for key, index_name in _REQUIRED_INDEXES.items()}

    # Tabelle LUISS core (BUG-5)
    luiss_tables = {
        table_name: _table_present(session_or_conn, table_name)
        for table_name in _REQUIRED_LUISS_TABLES
    }

    # Colonne obbligatorie non-datetime (BUG-5 — luiss_review_state.version)
    required_columns_present = {
        key: _column_present(session_or_conn, table_name, column_name)
        for key, (table_name, column_name) in _REQUIRED_COLUMN_PRESENCE.items()
    }

    residual_datetime_keys = [
        "memorie.data_documento",
        "memorie.confermata_il",
        "eventi_invio.data_scadenza",
    ]
    residual_present = [key for key in residual_datetime_keys if critical_columns[key]["present"]]
    residual_missing = [key for key in residual_datetime_keys if not critical_columns[key]["present"]]

    contracts = {
        "luiss_runtime_context_timestamptz": all(
            critical_columns[key]["is_timestamptz"]
            for key in [
                "luiss_runtime_context.avviato_il",
                "luiss_runtime_context.aggiornato_il",
            ]
        ),
        "core_datetime_foundation": all(
            critical_columns[key]["is_timestamptz"]
            for key in [
                "utenti.creato_il",
                "utenti.aggiornato_il",
                "documenti.creato_il",
                "documenti.aggiornato_il",
                "memorie.creata_il",
                "memorie.aggiornato_il",
            ]
        ),
        # colonne residue datetime: il contratto è soddisfatto solo se tutte le colonne attese
        # sono presenti e tutte TIMESTAMPTZ. Se mancano, non è un errore bloccante ma il contratto
        # non deve risultare falsamente True.
        "residual_datetime_columns_timestamptz": bool(residual_present) and not residual_missing and all(
            critical_columns[key]["is_timestamptz"] for key in residual_present
        ),
        "decision_user_index_present": indexes["idx_luiss_decision_utente"],
        # tabelle LUISS core (BUG-5)
        "luiss_core_tables_present": all(luiss_tables.values()),
        "luiss_review_state_version_present": required_columns_present.get("luiss_review_state.version", False),
    }

    issues: list[dict[str, Any]] = []

    # Colonne datetime critiche
    for column_name, info in critical_columns.items():
        if not info["present"]:
            # Le colonne residue opzionali (data_documento, confermata_il, data_scadenza)
            # possono mancare su DB vecchi — segnalare come warning, non errore bloccante
            optional_cols = {"memorie.data_documento", "memorie.confermata_il", "eventi_invio.data_scadenza"}
            issues.append({
                "kind": "missing_column",
                "column": column_name,
                "severity": "warning" if column_name in optional_cols else "error",
            })
        elif not info["is_timestamptz"]:
            issues.append({
                "kind": "non_timestamptz_column",
                "column": column_name,
                "data_type": info.get("data_type"),
                "udt_name": info.get("udt_name"),
                "severity": "error",
            })

    # Indici richiesti
    for index_name, present in indexes.items():
        if not present:
            issues.append({"kind": "missing_index", "index": index_name, "severity": "error"})

    # Tabelle LUISS core mancanti (BUG-5)
    for table_name, present in luiss_tables.items():
        if not present:
            issues.append({"kind": "missing_luiss_table", "table": table_name, "severity": "error"})

    # Colonne non-datetime obbligatorie (BUG-5)
    for col_key, present in required_columns_present.items():
        if not present:
            issues.append({"kind": "missing_required_column", "column": col_key, "severity": "error"})

    error_count = sum(1 for issue in issues if issue.get("severity", "error") == "error")
    warning_count = sum(1 for issue in issues if issue.get("severity", "error") == "warning")
    blocking = error_count > 0

    return {
        'dialect': dialect_name,
        "critical_columns": critical_columns,
        "indexes": indexes,
        "luiss_tables": luiss_tables,
        "required_columns": required_columns_present,
        "contracts": contracts,
        "residual_datetime": {
            "expected_columns": residual_datetime_keys,
            "present_columns": residual_present,
            "missing_columns": residual_missing,
        },
        "issues": issues,
        "error_count": error_count,
        "warning_count": warning_count,
        "has_warnings": warning_count > 0,
        "is_blocking": blocking,
        "is_clean": not blocking,
    }


def log_luiss_schema_contract_health(engine: Engine) -> None:
    try:
        with engine.connect() as conn:
            status = build_luiss_schema_contract_status(conn)
        if status["is_clean"] and not status.get("has_warnings"):
            logger.info(
                "luiss_schema_contract: clean "
                "runtime_context_timestamptz=%s core_datetime_foundation=%s "
                "residual_datetime_columns_timestamptz=%s "
                "decision_user_index_present=%s "
                "luiss_core_tables_present=%s luiss_review_state_version_present=%s",
                status["contracts"].get("luiss_runtime_context_timestamptz"),
                status["contracts"].get("core_datetime_foundation"),
                status["contracts"].get("residual_datetime_columns_timestamptz"),
                status["contracts"].get("decision_user_index_present"),
                status["contracts"].get("luiss_core_tables_present"),
                status["contracts"].get("luiss_review_state_version_present"),
            )
            return
        level = logger.warning if status.get("is_blocking") else logger.info
        level(
            "luiss_schema_contract: issues=%s errors=%s warnings=%s "
            "runtime_context_timestamptz=%s core_datetime_foundation=%s "
            "residual_datetime_columns_timestamptz=%s "
            "decision_user_index_present=%s "
            "luiss_core_tables_present=%s luiss_review_state_version_present=%s",
            len(status["issues"]),
            status.get("error_count", 0),
            status.get("warning_count", 0),
            status["contracts"].get("luiss_runtime_context_timestamptz"),
            status["contracts"].get("core_datetime_foundation"),
            status["contracts"].get("residual_datetime_columns_timestamptz"),
            status["contracts"].get("decision_user_index_present"),
            status["contracts"].get("luiss_core_tables_present"),
            status["contracts"].get("luiss_review_state_version_present"),
        )
        for issue in status["issues"][:15]:
            level("luiss_schema_contract.issue: %s", issue)
    except Exception as exc:
        logger.warning("luiss_schema_contract.health_check_failed: %s", exc)
