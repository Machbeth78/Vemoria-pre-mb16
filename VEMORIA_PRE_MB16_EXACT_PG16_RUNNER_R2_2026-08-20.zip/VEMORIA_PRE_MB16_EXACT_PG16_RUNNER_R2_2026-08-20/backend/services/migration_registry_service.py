# Vemoria
# Copyright © 2026 Devoti Massimo. All rights reserved.
# Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

"""VEMORA — Registry e runner prudente delle migration additive post-init_full."""
from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from sqlalchemy import text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

logger = logging.getLogger("vemora.migrations")

REGISTRY_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS schema_migration_state (
    migration_name       TEXT PRIMARY KEY,
    migration_sha256     TEXT NOT NULL,
    source_path          TEXT NOT NULL,
    applied_by           TEXT NULL,
    applied_notes        TEXT NULL,
    applied_il           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_schema_migration_state_applied_il
    ON schema_migration_state(applied_il DESC);
"""

MANAGED_MIGRATIONS: list[str] = [
    "migration_v27_firma_timestamp.sql",
    "migration_v28_inviti.sql",
    "migration_v29_contatti_rubrica.sql",
    "migration_v30_profilo.sql",
    "migration_v31_email.sql",
    "migration_v32_dati_forti.sql",
    "migration_v33_entity_feedback_eventi.sql",
    "migration_v34_registro_documentale.sql",
    "migration_v35_promuovi_candidato.sql",
    "migration_v36_fraud_patterns.sql",
    "migration_v37_profilo_professione.sql",
    "migration_v38_luiss_behavior.sql",
    "migration_v39_sapere_architettura.sql",
    "migration_v40_radar_v1.sql",
    "migration_v41_desktop_companion.sql",
    "migration_v42_desktop_secure_line.sql",
    "migration_v43_desktop_secure_line_delivery.sql",
    "migration_v44_desktop_secure_line_relay.sql",
    "migration_v45_desktop_secure_line_relay_hardening.sql",
    "migration_v46_extensions_architecture.sql",
    "migration_v47b_user_runtime_profiles.sql",  # NOTA: rinominata da v47 a v47b per risolvere il conflitto di naming con migration_v47_fts_sprint1.sql
    "migration_v47_fts_sprint1.sql",             # FIX HARDENING 2026-04-11: era presente ma non nel registry
    "migration_v48_prisma_v1.sql",
    "migration_v49_prisma_rollups.sql",
    "migration_v50_runtime_sessions.sql",
    # ECO + nucleo_memoria migrations — FIX HARDENING 2026-04-11: erano presenti ma non nel registry (gap v51-v60)
    "migration_v51_eco_premium.sql",
    "migration_v52_eco_runtime_dialog.sql",
    "migration_v53_eco_anchor_time.sql",
    "migration_v54_eco_anchor_maturity.sql",
    "migration_v55_eco_life_events.sql",
    "migration_v56_semantic_anchor_memory.sql",
    "migration_v57_eco_user_adaptation.sql",
    "migration_v58_eco_adaptation_controls.sql",
    "migration_v59_nucleo_memoria_core.sql",
    "migration_v60_nucleo_memoria_hardening.sql",
    "migration_v61_luiss_runtime_context.sql",
    "migration_v62_migration_registry.sql",
    "migration_v63_luiss_review_workflow.sql",
    "migration_v64_luiss_runtime_context_timestamptz.sql",
    "migration_v65_luiss_decision_utente_index.sql",
    "migration_v66_core_datetime_timestamptz.sql",
    "migration_v67_residual_datetime_timestamptz.sql",
    "migration_v68_schema_migration_state_timestamptz.sql",
    "migration_v69_postgres_runtime_datetime_alignment.sql",
    "migration_v70_sapere_catalog_runtime.sql",
    "migration_v71_sapere_catalog_taxonomy.sql",
    "migration_v72_sapere_edilizia_runtime_graph.sql",
    "migration_v73_sapere_taxonomy_templates.sql",
    # V79.2E — DB readiness: colonne runtime invio/proof/stream usate dal codice V74+
    "migration_v74_invio_hardening.sql",
    "migration_v74_sapere_search_terms.sql",
    "migration_v75_sapere_workflow_stage_items.sql",
    "migration_v76_luiss_conversation_state.sql",  # Memoria breve operativa dialogo LUISS
    "migration_v78_luiss_personal_memory.sql",      # Personal Memory V78: alias + role_map per utente
    "migration_v79_luiss_conv_state_pm_tracking.sql", # V79: last_pm_token/type in conversation_state
    "migration_v80_luiss_conv_state_action_slots.sql", # V80: pending_intent/action/entities/candidates
    "migration_v81_nucleo_read_observability.sql",
    "migration_v82_firma_vemora.sql",
    "migration_v83_chat_core.sql",
    "migration_v84_chat_groups.sql",
    "migration_v85_workspaces.sql",
    "migration_v86_firma_counterparty.sql",
    "migration_v87_firma_graphic_pdf_public_messages.sql",
    "migration_v88_user_push_tokens.sql",
    "migration_v89_chat_group_context.sql",
    "migration_v90_public_chat_handoff.sql",
    "migration_v91_billing_meter.sql",
    # V68 — operational chat intelligence + guest handoff + next-action
    "migration_v92_chat_operational_intelligence.sql",
    "migration_v93_guest_handoff_and_trust.sql",
    "migration_v94_thread_next_action_hint.sql",
    # V79.2E — DB readiness: migration recenti già presenti nel pack ma non gestite
    "migration_v95_sensitivity_overrides.sql",
    "migration_v96_user_operational_profile.sql",
    "migration_v97_v77_indexes.sql",
    "migration_v98_legal_acceptances.sql",  # V79.2H — legal document versions + user acceptances
    "migration_v99_legal_evidence_hardening.sql",  # V79.2I — legal evidence hashes + release evidence registry
    "migration_v100_ethical_content_responsibility.sql",  # V79.2J — codice etico + responsabilità contenuti inviati
    "migration_v101_legal_action_gates.sql",  # V79.2K — gate legali azioni rilevanti
    "migration_v102_abuse_recipient_reports.sql",  # V79.2K — abuso/destinatario errato
    "migration_v103_operator_ai_governance.sql",  # V79.2K — governance suggerimenti operatore
    "migration_v104_evidence_hash_chain.sql",  # V79.2K — catena hash eventi prova
    "migration_v105_protected_beta_mode.sql",  # V79.2K — beta protetta
    "migration_v106_v79_2n_desktop_studio.sql",  # V79.2N — Vemoria PC/Desktop Studio: dossier/cartelle con identità digitale
    "migration_v107_v79_2o_desktop_full_body.sql",  # V79.2O — Vemoria PC/Desktop Full Body: chat, sync 360°, dossier inviabili
    "migration_v108_audit01_privacy_gdpr_rights.sql",  # AUDIT 01 — privacy/GDPR rights requests + export evidence
    "migration_v109_source_indexer_v1.sql",  # v109 — Source Indexer V1 (Product Probe): source_connections, source_indexed_items, source_consent_log
    "migration_v110_folder_access_v1.sql",  # v110 — Folder Access V1 (Universal Digital Memory V1.1): folder_access_grants, folder_access_audit_log
    "migration_v111_operational_send_agreements.sql",  # v111 — Operational Sends V1.2 (Search Desk): operational_send_agreements, operational_send_agreement_events
    "migration_v112_v_pt_core_01_quick_notes.sql",  # V-PT-CORE-01 — Vemoria Privacy & Trust: appunti_rapidi, appunto_emergence_trigger
    "migration_v112_memory_operative_layer.sql",  # R1C — Memory Operative Layer: workspace/practice tables; duplicate v112 namespace preserved, additive/idempotent
    "migration_v113_v_pt_core_02_owner_identity_backup_emergency.sql",  # V-PT-CORE-02 — Vemoria Privacy & Trust: owner_identity_state, owner_lock_state, owner_device_registration, backup_session, backup_manifest
    "migration_v113_backend_a_plus.sql",  # R1C — Backend A PLUS: idempotency/rate-limit support; duplicate v113 namespace preserved, additive/idempotent
    "migration_v114_v_pt_core_03_dialogue_pending_plan.sql",  # V-PT-CORE-03 — Scrivania Conversazionale: dialogue_pending_plan
    "migration_v115_acquisition_real_r10r2.sql",  # PATCH-05R2 — acquisizione reale
    "migration_v116_dialogue_v2_learning.sql",  # dialogo V2 e apprendimento
    "migration_v117_gentilapp_behavior_pack.sql",  # comportamento GentilApp
    "migration_v118_responsibility_validation_layer.sql",  # responsabilità e validazione
    "migration_v119_local_memory_scan_runtime.sql",  # runtime scansione memoria locale
    "migration_v120_chat_media_p2p.sql",  # media chat e P2P
    "migration_v121_vemoria_fabric_transport_core.sql",  # R5 Fabric Gate01 — sessioni, tentativi, ricevute e lease ciechi
    "migration_v122_fabric_receipt_trust.sql",  # R5 Fabric Gate02 — trust receipt owner-scoped e revoca chiavi pubbliche
    "migration_v123_fabric_recovery_replay_metrics.sql",  # R5 Fabric Gate03 — crash recovery, anti-replay receipt e metriche assistite
    "migration_v124_gate07b_canonical_event_log.sql",  # Gate07B — event log canonico, Lamport, firma device-set
    "migration_v125_gate07c_content_occurrence_projection.sql",  # Gate07C — proiezione contenuto/occorrenza + watermark
    "migration_v126_gate07d_atomic_activation_alias_history.sql",  # Gate07D — operazioni atomiche, alias nel log, consumer watermark
    "migration_v127_gate07e_shadow_runtime_probe.sql",  # Gate07E — feature flag shadow, audit minimizzato, runtime probe
    # Gate05 R1C — riallineamento registry: migrazioni satellite presenti nei file SQL ma non visibili al runner prudente.
    # Nota: v124-v127 hanno namespace numerico parallelo a Gate07; non si rinumerano retroattivamente.
    "migration_v124_authorized_memory_multi_device_macro_a.sql",
    "migration_v125_authorized_memory_cross_device_identity_macro_b.sql",
    "migration_v126_authorized_memory_selective_secure_line_macro_c.sql",
    "migration_v127_authorized_memory_revocation_propagation_macro_f.sql",
    "migration_v128_authorized_memory_professional_node_macro_d.sql",
    "migration_v129_authorized_memory_owner_control_macro_e.sql",
    "migration_v130_chat_native_macro_b_baseline_lock.sql",
    "migration_v131_chat_native_macro_c_candidates.sql",
    "migration_v132_chat_language_bridge_c1.sql",
    "migration_v133_chat_group_coordinato_visibility_d.sql",
    "migration_v134_chat_proof_ack_e.sql",
    "migration_v135_chat_final_ux_security_f.sql",
    "migration_v136_gate05_recovery_backup_capsula.sql",
    "migration_v137_gate05_r1a_adaptive_profile_encryption_contract.sql",
    "migration_v138_gate05_r1b_restore_preflight.sql",
    "migration_v139_gate06_self_knowledge_atlas.sql",  # Gate06 R1 — Self-Knowledge Atlas + matrice anti-perdita
    "migration_v140_gate06_r1a_scrivania_guided_atlas.sql",  # Gate06 R1A — Scrivania guidata sopra Atlas
    "migration_v141_gate06_r1b_guided_operational_contracts.sql",  # Gate06 R1B — stato parziale, handoff operativo, Atlas per Cerebro
    "migration_v142_gate06_r1c_satellite_contracts.sql",  # Gate06 R1C — contratti satellite e ordine dipendenze per 34 funzioni parziali
    "migration_v143_gate06_r1d_p0_foundation_static_completion.sql",  # Gate06 R1D — P0 foundation static completion, runtime deferred
    "migration_v144_gate06_r1e_p1_core_guards_static_completion.sql",  # Gate06 R1E — P1 core guards static completion, runtime/Cerebro deferred
    "migration_v145_gate06_r1f_p2_input_memory_static_completion.sql",  # Gate06 R1F — P2 input/memory static completion, runtime deferred
    "migration_v146_gate06_r1g_p3_user_surfaces_static_completion.sql",  # Gate06 R1G — P3 user surfaces static completion, runtime deferred
    "migration_v147_gate06_r1h_p4_localization_static_completion.sql",  # Gate06 R1H — P4 localization static completion, runtime deferred
    "migration_v148_gate06_r1i_p5_relations_chat_static_completion.sql",  # Gate06 R1I — P5 relations/chat static completion, runtime deferred
    "migration_v149_gate06_r1j_p6_fabric_proof_static_completion.sql",  # Gate06 R1J — P6 fabric/proof static completion, runtime deferred
    "migration_v150_gate06_r1k_p7_commercial_distribution_static_completion.sql",  # Gate06 R1K — P7 commercial/distribution static completion, runtime deferred
    "migration_v151_gate07a_p0_functional_completion.sql",  # Gate07A — P0 functional code completion, runtime deferred
    "migration_v152_gate07b_p1_core_guards_functional_completion.sql",  # Gate07B — P1 core guards functional code completion, runtime/Cerebro deferred
    "migration_v153_gate07c_p2_input_memory_functional_completion.sql",  # Gate07C — P2 input/memory functional code completion, runtime deferred
    "migration_v154_gate07d_p3_user_surfaces_functional_completion.sql",  # Gate07D — P3 user surfaces functional code completion, runtime/Flutter/billing deferred
    "migration_v155_gate07e_p4_localization_functional_completion.sql",
    "migration_v156_gate07f_p5_relations_chat_functional_completion.sql",  # Gate07F — P5 relations/chat functional code completion, runtime email/chat deferred
    "migration_v157_gate07g_p6_fabric_proof_functional_completion.sql",
    "migration_v158_gate07h_p7_commercial_distribution_functional_completion.sql",  # Gate07H — P7 commercial/distribution functional code completion, runtime deferred
    "migration_v159_gate08_pre_fiduciary_invariants.sql",
    "migration_v160_gate08a_source_atlas_provenance.sql",
    "migration_v161_gate08a_r1_relation_source_vertical_guards.sql",
    "migration_v162_gate08b_active_workfile.sql",
    "migration_v163_gate08b5_device_capability_guide.sql",
    "migration_v164_gate08c_document_understanding.sql",
    "migration_v165_gate08d_consumer_intelligence_owner_agent.sql",
    "migration_v166_gate08e_language_lexicon_translation.sql",  # Gate08D — Consumer Intelligence owner-agent, no paid ranking, runtime deferred,  # Gate08A-R1 — relation source cards, vertical guards, runtime deferred  # Gate08A — Source Atlas provenance / official resolver, runtime deferred  # Gate08-PRE — fiduciary invariants owner-agent, no paid ranking, runtime deferred  # Gate07G — P6 fabric/proof functional code completion, runtime signature/preview deferred
    "migration_v167_gate08f_runtime_modular_probes.sql",  # Gate08F — modular runtime probes, no Cerebro end-to-end
    "migration_v168_gate08g_cerebro_orchestrator.sql",  # Gate08G — Cerebro orchestrator gated, runtime deferred
    "migration_v169_gate08g_r1_cerebro_engine_policy.sql",  # Gate08G-R1 — Cerebro engine policy, LLM implementation deferred
    "migration_v170_gate08g_r1b_capability_explanation.sql",  # Gate08G-R1B — Self-Knowledge capability explanation layer
    "migration_v171_mb11_p2_phase_a_canonical_identity.sql",  # MB11-P2 Phase A — canonical identity ledger projection
    "migration_v172_mb11_p2_phase_a_r1b_corrective.sql",  # MB11-P2 Phase A R1B — corrective migration for merge/split snapshots and RLS
    "migration_v173_mb11_p2_phase_a_r1c_merge_split_governed_state.sql",  # MB11-P2 Phase A R1C — merge/split candidate proposals and rejection records
    "migration_v173_mb11_p2_phase_a_r1d_source_card_authority.sql",  # R1D — trusted R1F source-card authority repository
    "migration_v174_mb11_p2_phase_a_r1d_handoff_outbox.sql",  # R1D — idempotent production handoff outbox to MB9/Gemello
    "migration_v175_mb12_p0_rule_clause_eligibility_foundation.sql",  # MB12-P0 R1 — foundation
    "migration_v176_mb12_p0_r1a_governed_foundation.sql",  # MB12-P0 R1A — governed foundation
    "migration_v177_mb12_p0_r1b_governance_repair.sql",  # MB12-P0 R1B — governance repair
    "migration_v178_mb12_p0_r1c_integrity_closure.sql",  # MB12-P0 R1C — integrity closure
    "migration_v179_mb12_p0_r1d_provenance_replay_closure.sql",  # MB12-P0 R1D — provenance/replay closure
    "migration_v180_mb12_p0_r1e_owner_trust_context_closure.sql",  # MB12-P0 R1E — owner/trust/context closure
    "migration_v181_mb12_p0_r1f_canonical_consent_owner_binding_closure.sql",  # MB12-P0 R1F — canonical consent/owner binding closure
    "migration_v182_mb12_p0_r1g_exact_evidence_context_closure.sql",  # MB12-P0 R1G — exact evidence/context closure
    "migration_v183_mb12_p0_r1h_atomic_trusted_data_closure.sql",  # MB12-P0 R1H — atomic handoff/trusted data closure
    "migration_v184_mb12_p0_r1i_governed_trusted_closure.sql",  # MB12-P0 R1I — governed context append-only history and hardened trusted-data writer
    "migration_v185_mb12_p0_r1j_binding_history_closure.sql",  # MB12-P0 R1J — binding-only trusted writer and serialized governed-context history
    "migration_v186_mb12_p0_r1k_legacy_acl_test_fixture_closure.sql",  # MB12-P0 R1K — revoke obsolete owner-supplied binding writer
    "migration_v187_mb12_p1_offer_contract_normalization.sql",  # MB12-P1 R1 — governed offer/contract normalization
    "migration_v188_mb12_p1_r2_runtime_sql_closure.sql",  # MB12-P1 R2 — qualify PL/pgSQL table columns and close runtime writer ambiguity
    "migration_v189_mb12_p2_governed_comparability_gate.sql",  # MB12-P2 R1 — governed comparability gate
    "migration_v190_mb12_p3_owner_decision_profile.sql",  # MB12-P3 R1 — explicit owner decision profile and constraint applicability
    "migration_v191_mb12_p4_governed_explainable_ranking.sql",  # MB12-P4 R1 — governed explainable ranking and recommendation
    "migration_v192_mb13_p0_universal_monitoring_ledger.sql",  # MB13-P0 R1 — universal monitoring ledger and temporal target foundation
    "migration_v193_mb13_p0_authoritative_monitoring_ledger.sql",  # MB13-P0 R2 — authoritative monitoring ledger closure
    "migration_v194_mb13_p0_r2_final_sprint.sql",  # MB13-P0 R2 final sprint — binding, provenance, temporal closure
    "migration_v195_mb13_p0_consent_transition_binding_closure.sql",  # MB13-P0 R2 consent transition binding closure
    "migration_v196_mb13_p1_universal_diff_engine.sql",  # MB13-P1 R1 universal diff engine
    "migration_v197_mb13_p1_authoritative_deterministic_diff.sql",  # MB13-P1 R2 authoritative deterministic diff closure
    "migration_v198a_mb13_p1_preflight_provenance_document_authority.sql",  # MB13-P1 R2 v198a preflight, provenance and document authority
    "migration_v198b_mb13_p1_worker_queue_executor_roles.sql",  # MB13-P1 R2 v198b worker queue and API/executor role separation
    "migration_v199a_mb13_p1_real_worker_security_boundary.sql",  # MB13-P1 R2 v199a real worker/API boundary and queue authority
    "migration_v199b_mb13_p1_exact_provenance_output_authority.sql",  # MB13-P1 R2 v199b exact provenance, output authority, text locations and materiality
    "migration_v200a_mb13_p1_production_execution_boundary.sql",  # MB13-P1 R2 v200a production execution boundary, dedicated API/worker DSNs
    "migration_v200b_mb13_p1_canonical_data_authority.sql",  # MB13-P1 R2 v200b canonical data authority, job-bound envelope, provenance, document revision, text materiality
    "migration_v201a_mb13_p1_hard_runtime_job_boundary.sql",  # MB13-P1 R2 v201a hard runtime and job boundary
    "migration_v201b_mb13_p1_canonical_authority_closure.sql",  # MB13-P1 R2 v201b canonical authority closure
    "migration_v202_mb13_p1_private_writer_privilege_closure.sql",  # MB13-P1 R2 v202 private writer, privilege boundary and canonical hash closure
    "migration_v203_mb13_p1_document_snapshot_provenance_closure.sql",  # MB13-P1 R2 v203 exact document snapshot and monitor-bound provenance closure
    "migration_v204_mb13_p1_authoritative_rev1_locked_document_provenance.sql",  # MB13-P1 R2 v204 authoritative rev1 snapshot and locked document provenance
    "migration_v205_mb13_p2_timeline_due_state_reminder_retry_infrastructure.sql",  # MB13-P2 v205 timeline, due-state, reminder and retry infrastructure
    "migration_v206_mb13_p2_owner_temporal_provenance_closure.sql",  # MB13-P2 v206 owner-scoped RLS, temporal eligibility and provenance closure
    "migration_v207_mb13_p2_server_time_executor_revision_binding_closure.sql",  # MB13-P2 v207 server-side time, executor boundary, monotonic revision binding and original-event closure
    "migration_v208_mb13_p2_append_only_executor_retry_closure.sql",  # MB13-P2 v208 append-only timeline, dedicated executor retry closure, monitor-first locking
    "migration_v209_mb13_p3_governed_action_pack_framework.sql",  # MB13-P3 R1 governed action pack framework
    "migration_v210_mb13_p3_authorization_evidence_execution_closure.sql",  # MB13-P3 v210 authorization, evidence and execution closure
    "migration_v211_mb13_p3_provenance_receipt_idempotency_closure.sql",  # MB13-P3 v211 provenance, receipt, idempotency and methodological closure
    "migration_v212_mb13_p3_monitor_executor_receipt_closure.sql",  # MB13-P3 v212 exact monitor binding, authoritative executor identity, governed evidence and minimal privileges
    "migration_v213_mb13_p3_evidence_receipt_attempt_cancellation_closure.sql",  # MB13-P3 v213 evidence/receipt binding, executor-revision link, cancellation closure
    "migration_v214_mb13_p3_evidence_semantic_idempotency_audit_closure.sql",  # MB13-P3 v214 evidence semantic idempotency and terminal audit closure
    "migration_v215_mb13_p3_evidence_failure_expiry_provenance_closure.sql",  # MB13-P3 v215 evidence, failure, expiry and terminal provenance closure
    "migration_v216_mb13_p3_coverage_provenance_replay_audit_closure.sql",  # MB13-P3 v216 coverage, provenance, replay audit closure
    "migration_v217_mb13_p3_executor_creation_coverage_owner_closure.sql",  # MB13-P3 v217 executor identity, mandatory idempotency, explicit step coverage, owner-scoped helper
    "migration_v218_mb13_p3_legacy_idempotency_owner_helper_closure.sql",  # MB13-P3 v218 legacy idempotency restoration, payload/revision integrity, helper closure
    "migration_v219_mb13_p3_pack_revision_exact_integrity_legacy_recovery.sql",  # MB13-P3 v219 exact pack/revision integrity, legacy recovery, governed pack mutation
    "migration_v220_mb13_p3_real_legacy_chain_privilege_mutation_closure.sql",  # MB13-P3 v220 real legacy chain, privilege and mutation closure
    "migration_v221_mb13_p3_real_upgrade_chain_revision_history_role_isolation_closure.sql",  # MB13-P3 v221 real upgrade chain, revision-history role isolation closure
    "migration_v222_mb13_p3_full_chain_scan_exact_privilege_allowlist_closure.sql",  # MB13-P3 v222 full chain scan, exact privileges and allowlist closure
    "migration_v223_mb13_p3_recovery_quarantine_exact_object_ownership_test_integrity_closure.sql",  # MB13-P3 v223 recovery quarantine atomicity, exact object allowlist, owner separation
    "migration_v224_mb13_p3_role_gate_acl_normalization_exact_scope_closure.sql",  # MB13-P3 v224 role-based gate, ACL normalization, exact-scope ownership, trigger allowlist, reason-specific recovery
    "migration_v225_mb13_p3_effective_acl_membership_temp_function_owner_isolation_closure.sql",  # MB13-P3 v225 effective ACL closure, membership graph isolation, temporary function cleanup, full ownership inventory
    "migration_v226_mb13_p3_exact_temp_scan_membership_acl_delivery_closure.sql",  # MB13-P3 v226 exact temp-function regex scan, per-table ACL matrix, full cross-schema ownership inventory, membership/SET ROLE isolation
    "migration_v227_mb13_p3_authorization_acl_and_audit_packet_closure.sql",  # MB13-P3 v227 final authorization column-level UPDATE, trigger helper EXECUTE isolation, audit packet closure
    "migration_v228_mb1_mb2_l1_claim_projection.sql",  # MB1-MB2: atomic L1 claim, worker-token invalidation, consent-scoped projection
    "migration_v229_mb3_mb4_internet_consent.sql",  # MB3-MB4: explicit fail-closed Internet consent per owner
    "migration_v230_mb3_mb4_internet_consent_rls.sql",  # MB3-MB4 completion: RLS and granular internet consent
    "migration_v231_mb7_mb8_evidence_timeline_runtime.sql",  # MB7→MB8: evidence graph, provenance and causal timeline runtime
    "migration_v232_mb11_mb12_rls_app_role_minimal_privileges.sql",  # MB7→MB8 R3: minimal per-table privileges for canonical RLS tests
    "migration_v233_mb9_personal_source_canonical_intake.sql",  # MB8→MB9: canonical personal source intake bridge
    "migration_v234_mb9_real_connectors_and_consent.sql",  # MB8→MB9 R1: real connector adapters and canonical consent binding
    "migration_v235_mb10_multivision_source_family.sql",  # MB10-A: extend source_family allowlist for Multi-Vision canonical intake
    "migration_transfer_v1.sql",
    "migration_transfer_v2.sql",
    "migration_unknown_candidates_v1.sql",
    "migration_v236_p0p1_owner_isolation_rls.sql",
    "migration_v237_p0p1_automation_owner.sql",
    "migration_v238_p0p1_nucleo_owner.sql",
    "migration_v239_p0p1_security_log_owner_rls.sql",
    "migration_v240_p0p1_unknown_blocker_resolution.sql",
    "migration_v241_mb13_p3_execution_revocation_closure.sql",
    "migration_v242_p0p1_privacy_closure.sql",
    "migration_v243_mb14_p0_relationship_foundation.sql",  # MB14-P0 — canonical relationship foundation
    "migration_v244_mb14_p1_conversation_core.sql",  # MB14-P1 — conversation core
    "migration_v245_mb14_p2_rich_communication.sql",  # MB14-P2 — rich communication
    "migration_v246_mb14_p3_relationship_memory.sql",  # MB14-P3 — relationship memory + temporal intelligence
    "migration_v247_mb14_p3_r1_source_card.sql",  # MB14-P3-R1 — SOURCE_CARD envelope foundation
    "migration_v248_mb14_p4_relationship_intelligence_vault.sql",  # MB14-P4 — Relationship Intelligence, goal-driven communication and vault foundation
    "migration_v249_mb14_p4_r1_vault_crypto.sql",  # MB14-P4-R1 — Vault security closure: real AES-GCM, key separation, PIN rate-limit
    "migration_v250_mb14_p5_conversation_expressivity.sql",  # MB14-P5 — Conversation expressivity: reactions, emoji recents/favorites, source card UX foundation
    "migration_v251_mb15_p0_device_capability_map.sql",  # MB15-P0 — Device Capability Map foundation
    "migration_v252_mb15_p0_r1_rls_owner_isolation.sql",  # MB15-P0-R1 — Capability snapshot owner RLS isolation
    "migration_v253_mb15_p1_capability_permission_broker.sql",  # MB15-P1 — Capability & Permission Broker
    "migration_v254_mb15_p2_goal_plan_builder.sql",  # MB15-P2 — Environment Intelligence + Goal Plan Builder
    "migration_v255_mb15_p2_r1_force_rls.sql",  # MB15-P2-R1 — Force RLS on goal plan tables
    "migration_v256_mb15_p3_governed_goal_executor.sql",  # MB15-P3 — Governed Goal Executor + execution persistence
    "migration_v257_mb15_p3_r1_governed_goal_executor_final_closure.sql",  # MB15-P3-R1 — idempotency + final closure
    "migration_v258_mb15_p3_r2_atomic_idempotency.sql",  # MB15-P3-R2 — atomic idempotency reservation + key length bound
    "migration_v259_mb15_p4_adaptive_execution.sql",  # MB15-P4 — adaptive execution, provider health, recovery audit
    "migration_v260_mb15_p3_authorization_challenge.sql",  # MB15 R3A/R3B — server-bound single-use authorization + legacy consent narrowing
    "migration_v269_mb0_mb15_memory_scan_rls_hardening.sql",  # MB0→MB15 convergence — memory-scan owner RLS hardening; v261-v268 reserved for historical R5
    "migration_v270_mb0_mb15_desktop_pairing_session_hardening.sql",  # MB0→MB15 convergence — Desktop pairing poll/session secrets hashed and one-shot
    "migration_v271_email_memoria_owner_isolation.sql",  # audit convergence — owner-scoped inbound email + per-owner dedup
    "migration_v272_owner_rls_source_push.sql",  # audit convergence — FORCE RLS for owner-only source index + push tokens
    "migration_v273_adaptive_profile_owner_rls.sql",  # audit convergence — FORCE RLS for private adaptive profile/corrections
    "migration_v274_desktop_owner_data_rls.sql",  # audit convergence — FORCE RLS for post-auth Desktop owner data
    "migration_v275_public_funnel_token_fingerprint.sql",  # audit convergence — purge raw public bearer tokens from funnel analytics
    "migration_v276_scrub_pending_invite_token_copies.sql",  # audit convergence — remove redundant invite bearer copies from chat state
    "migration_v281_mb15_r6_owner_node_product_gateway.sql",  # MB15 R6 recovery — server-authoritative Owner Node product gateway; v277-v280 historical checkpoints
    "migration_v282_mb15_r5h5_r6_result_truth_convergence.sql",  # MB15 6A — R5H5 semantic result anchored to R6 request lifecycle
    "migration_v283_vault_encrypted_backup_recovery.sql",  # PRE-MB16 — ordinary encrypted Vault backup/recovery rollback + idempotency checkpoint
    "migration_v284_identity_claim_security_closure.sql",  # PRE-MB16 — canonical email + verified-mailbox gate + one public token/one account
    "migration_v285_reference_privacy_containment.sql",  # PRE-MB16 — purge legacy contact membership oracle bindings
    "migration_v286_mb15_r6_exact_owner_node_authority.sql",  # PRE-MB16 — exact item/workload/hash authorization before Owner Node prepare
    "migration_v287_mailbox_ownership_verification.sql",  # PRE-MB16 — owner-scoped one-time mailbox verification with fail-closed TLS delivery
    "migration_v288_email_forwarding_canonical_convergence.sql",  # PRE-MB16 — signed live forwarding -> durable canonical MB9 intake outbox
    "migration_v289_pec_transport_verification.sql",  # PRE-MB16 Pass 8N — PEC/REM transport signature verification truth
    "migration_v290_rfc3161_timestamp_provider.sql",  # PRE-MB16 Pass 8O — verified external RFC3161 timestamp evidence
    "migration_v291_fabric_peer_device_identity.sql",  # PRE-MB16 Pass 8U — authenticated Fabric device keys + exact direct-peer visibility
    "migration_v292_fabric_lan_rendezvous.sql",  # PRE-MB16 Pass 8W — short-lived exact-peer LAN rendezvous tickets
    "migration_v293_antifraud_continuous_sentinel.sql",  # PRE-MB16 Pass 8AF — public fraud intelligence snapshots
    "migration_v294_receipt_entity_monitoring.sql",  # PRE-MB16 Pass 8AI — receipt-derived public entity monitoring authorization/checkpoints
    "migration_v295_source_indexer_media_types.sql",  # PRE-MB16 Pass 8AK — first-class local audio/video Source Indexer types
    "migration_v296_generic_interest_watch.sql",  # PRE-MB16 Pass 8AO — explicit owner generic recurring public-search watch + narrow MB13 generic target bridge
]

SEED_FILES: list[str] = [
    "seed_tipi_documento.sql",
    "seed_tipi_documento_ext.sql",
    "seed_registry_rules.sql",
]


REQUIRED_BOOTSTRAP_TABLES: list[str] = [
    "utenti",
    "tipi_documento",
    "documenti",
    "memorie",
    "eventi_invio",
]

REQUIRED_EXTENSIONS: list[str] = [
    "uuid-ossp",
    "pg_trgm",
]


@dataclass
class ManagedMigration:
    name: str
    path: Path
    sha256: str


def _dialect_name(session_or_conn: Session | Any) -> str:
    bind_getter = getattr(session_or_conn, 'get_bind', None)
    if callable(bind_getter):
        bind = bind_getter()
        if bind is not None and getattr(bind, 'dialect', None) is not None:
            return bind.dialect.name
    dialect = getattr(session_or_conn, 'dialect', None)
    if dialect is not None:
        return dialect.name
    engine = getattr(session_or_conn, 'engine', None)
    if engine is not None and getattr(engine, 'dialect', None) is not None:
        return engine.dialect.name
    return 'unknown'


def _ensure_postgres_dialect(session_or_conn: Session | Any) -> None:
    dialect_name = _dialect_name(session_or_conn)
    if dialect_name != 'postgresql':
        raise RuntimeError(
            'Vemora richiede PostgreSQL per bootstrap/migration/runtime contract. '
            f'Dialect rilevato: {dialect_name}'
        )


def _execute_sql_script(conn, sql_text: str) -> None:
    # SQLAlchemy 2.0 + psycopg2: text() con multi-statement funziona meglio
    # di exec_driver_sql, che può confondere parametri vuoti con sequenze.
    conn.execute(text(sql_text))


def _runtime_transport_adapt_sql(migration_name: str, sql_text: str) -> str:
    """Hash-gated transport adaptation for the exact-PG16 proof.

    Canonical SQL files are never modified. v296 was authored against the old
    five-argument consent wrapper, while the frozen pre-v296 authority is the
    six-argument signature introduced by v203. Supabase live required the same
    transport-only adaptation. Registry SHA remains the canonical source SHA.
    """
    if migration_name != 'migration_v296_generic_interest_watch.sql':
        return sql_text
    adapted = sql_text
    adapted = adapted.replace(
        "mb13_p0_lock_and_verify_consents_pre296(uuid,jsonb,text,jsonb,boolean)'",
        "mb13_p0_lock_and_verify_consents_pre296(uuid,jsonb,text,jsonb,boolean,boolean)'",
    )
    adapted = adapted.replace(
        'mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN)\n            RENAME',
        'mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN, BOOLEAN)\n            RENAME',
    )
    adapted = adapted.replace(
        '    p_required BOOLEAN\n)\nRETURNS JSONB AS $$',
        '    p_required BOOLEAN,\n    p_strict_relation BOOLEAN DEFAULT TRUE\n)\nRETURNS JSONB AS $$',
    )
    adapted = adapted.replace(
        '        p_owner, p_consent_refs, p_target_type, p_target_ref, p_required\n    );',
        '        p_owner, p_consent_refs, p_target_type, p_target_ref, p_required, p_strict_relation\n    );',
    )
    adapted = adapted.replace(
        'mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN) FROM PUBLIC;',
        'mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN, BOOLEAN) FROM PUBLIC;',
    )
    return adapted



def _extension_exists(session_or_conn: Session | Any, extension_name: str) -> bool:
    row = session_or_conn.execute(
        text("SELECT 1 FROM pg_extension WHERE extname = :name LIMIT 1"),
        {"name": extension_name},
    ).fetchone()
    return bool(row)


def _table_exists(session_or_conn: Session | Any, table_name: str) -> bool:
    row = session_or_conn.execute(
        text("SELECT to_regclass(:table_name) AS reg"),
        {"table_name": f"public.{table_name}"},
    ).fetchone()
    return bool(row and row.reg)


def build_postgres_bootstrap_status(session_or_conn: Session | Any) -> dict[str, Any]:
    dialect_name = _dialect_name(session_or_conn)
    if dialect_name != 'postgresql':
        return {
            'dialect': dialect_name,
            'extensions': {name: False for name in REQUIRED_EXTENSIONS},
            'tables': {name: False for name in REQUIRED_BOOTSTRAP_TABLES},
            'missing_extensions': list(REQUIRED_EXTENSIONS),
            'missing_tables': list(REQUIRED_BOOTSTRAP_TABLES),
            'ok': False,
            'issues': [
                'Dialect non supportato: '
                + dialect_name
                + '. Vemora richiede PostgreSQL e non supporta bootstrap/migration su altri engine.'
            ],
        }
    extensions = {name: _extension_exists(session_or_conn, name) for name in REQUIRED_EXTENSIONS}
    tables = {name: _table_exists(session_or_conn, name) for name in REQUIRED_BOOTSTRAP_TABLES}
    issues: list[str] = []
    missing_extensions = [name for name, present in extensions.items() if not present]
    missing_tables = [name for name, present in tables.items() if not present]
    if missing_extensions:
        issues.append(
            "Estensioni PostgreSQL mancanti: "
            + ", ".join(missing_extensions)
            + ". Bootstrap richiesto: backend/database/init_full.sql"
        )
    if missing_tables:
        issues.append(
            "Tabelle base assenti: "
            + ", ".join(missing_tables)
            + ". Prima eseguire backend/database/init_full.sql"
        )
    return {
        'dialect': dialect_name,
        "extensions": extensions,
        "tables": tables,
        "missing_extensions": missing_extensions,
        "missing_tables": missing_tables,
        "ok": not issues,
        "issues": issues,
    }


def ensure_postgres_bootstrap_ready(session_or_conn: Session | Any) -> None:
    _ensure_postgres_dialect(session_or_conn)
    status = build_postgres_bootstrap_status(session_or_conn)
    if status["ok"]:
        return
    raise RuntimeError(
        "PostgreSQL bootstrap non pronto per le migration additive: "
        + " | ".join(status["issues"])
    )


def _database_dir(base_dir: str | Path | None = None) -> Path:
    if base_dir is not None:
        return Path(base_dir)
    return Path(__file__).resolve().parents[1] / "database"


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def get_managed_migrations(base_dir: str | Path | None = None) -> list[ManagedMigration]:
    db_dir = _database_dir(base_dir)
    items: list[ManagedMigration] = []
    for name in MANAGED_MIGRATIONS:
        path = db_dir / name
        if not path.exists():
            raise FileNotFoundError(f"Migration gestita non trovata: {path}")
        items.append(ManagedMigration(name=name, path=path, sha256=_sha256(path)))
    return items


def ensure_registry_table_conn(conn) -> None:
    for stmt in [s.strip() for s in REGISTRY_TABLE_SQL.split(';') if s.strip()]:
        conn.execute(text(stmt))


def ensure_registry_table_engine(engine: Engine) -> None:
    with engine.begin() as conn:
        ensure_registry_table_conn(conn)


def registry_table_exists(session_or_conn: Session | Any) -> bool:
    if _dialect_name(session_or_conn) != 'postgresql':
        return False
    row = session_or_conn.execute(text("SELECT to_regclass('public.schema_migration_state') AS reg")).fetchone()
    return bool(row and row.reg)


def fetch_registry_rows(session_or_conn: Session | Any) -> dict[str, dict[str, Any]]:
    if not registry_table_exists(session_or_conn):
        return {}
    rows = session_or_conn.execute(text("""
        SELECT migration_name, migration_sha256, source_path, applied_by, applied_notes, applied_il
        FROM schema_migration_state
        ORDER BY applied_il ASC, migration_name ASC
    """)).mappings().all()
    return {row['migration_name']: dict(row) for row in rows}


def build_registry_status(session_or_conn: Session | Any, base_dir: str | Path | None = None) -> dict[str, Any]:
    managed = get_managed_migrations(base_dir)
    dialect_name = _dialect_name(session_or_conn)
    if dialect_name != 'postgresql':
        return {
            'dialect': dialect_name,
            'registry_present': False,
            'managed_total': len(managed),
            'applied_count': 0,
            'pending_count': len(managed),
            'drift_count': 0,
            'seed_files': SEED_FILES,
            'items': [
                {
                    'migration_name': mig.name,
                    'status': 'unsupported_dialect',
                    'sha256': mig.sha256,
                    'applied_il': None,
                    'applied_by': None,
                    'sha_match': None,
                }
                for mig in managed
            ],
        }
    rows = fetch_registry_rows(session_or_conn)
    items: list[dict[str, Any]] = []
    applied_count = 0
    pending_count = 0
    drift_count = 0
    for mig in managed:
        row = rows.get(mig.name)
        status = 'pending'
        applied_il = None
        applied_by = None
        sha_match = None
        if row:
            applied_count += 1
            applied_il = row.get('applied_il')
            applied_by = row.get('applied_by')
            sha_match = row.get('migration_sha256') == mig.sha256
            if sha_match:
                status = 'applied'
            else:
                status = 'drift'
                drift_count += 1
        else:
            pending_count += 1
        items.append({
            'migration_name': mig.name,
            'status': status,
            'sha256': mig.sha256,
            'applied_il': applied_il.isoformat() if hasattr(applied_il, 'isoformat') else applied_il,
            'applied_by': applied_by,
            'sha_match': sha_match,
        })
    return {
        'dialect': dialect_name,
        'registry_present': registry_table_exists(session_or_conn),
        'managed_total': len(managed),
        'applied_count': applied_count,
        'pending_count': pending_count,
        'drift_count': drift_count,
        'seed_files': SEED_FILES,
        'items': items,
    }


def adopt_existing(engine: Engine, *, base_dir: str | Path | None = None, applied_by: str = 'manual-adopt', note: str = 'Legacy DB adoption') -> dict[str, Any]:
    managed = get_managed_migrations(base_dir)
    with engine.begin() as conn:
        ensure_postgres_bootstrap_ready(conn)
        ensure_registry_table_conn(conn)
        rows = fetch_registry_rows(conn)
        inserted = 0
        for mig in managed:
            if mig.name in rows:
                continue
            conn.execute(text("""
                INSERT INTO schema_migration_state(migration_name, migration_sha256, source_path, applied_by, applied_notes)
                VALUES (:name, :sha, :path, :by, :notes)
            """), {
                'name': mig.name,
                'sha': mig.sha256,
                'path': str(mig.path.relative_to(_database_dir(base_dir).parent)),
                'by': applied_by,
                'notes': note,
            })
            inserted += 1
    logger.warning('migration_registry.adopt_existing inserted=%s', inserted)
    return {'inserted': inserted, 'managed_total': len(managed)}


def apply_pending(engine: Engine, *, base_dir: str | Path | None = None, applied_by: str = 'manual-runner') -> dict[str, Any]:
    managed = get_managed_migrations(base_dir)
    applied: list[str] = []
    with engine.begin() as conn:
        ensure_postgres_bootstrap_ready(conn)
        ensure_registry_table_conn(conn)
        rows = fetch_registry_rows(conn)
        for mig in managed:
            row = rows.get(mig.name)
            if row:
                if row.get('migration_sha256') != mig.sha256:
                    raise RuntimeError(f"Drift migration rilevato per {mig.name}: sha registry diverso dal file")
                continue
            sql_text = mig.path.read_text(encoding='utf-8')
            sql_text = _runtime_transport_adapt_sql(mig.name, sql_text)
            _execute_sql_script(conn, sql_text)
            conn.execute(text("""
                INSERT INTO schema_migration_state(migration_name, migration_sha256, source_path, applied_by, applied_notes)
                VALUES (:name, :sha, :path, :by, :notes)
            """), {
                'name': mig.name,
                'sha': mig.sha256,
                'path': str(mig.path.relative_to(_database_dir(base_dir).parent)),
                'by': applied_by,
                'notes': 'Applied by migration runner',
            })
            applied.append(mig.name)
    logger.info('migration_registry.apply_pending applied=%s', applied)
    return {'applied': applied, 'applied_count': len(applied)}


def log_registry_health(engine: Engine, *, base_dir: str | Path | None = None) -> None:
    try:
        with engine.connect() as conn:
            status = build_registry_status(conn, base_dir=base_dir)
        if not status['registry_present']:
            logger.warning(
                'migration_registry: tabella stato assente. Eseguire migration_v62 o usare backend/tools/migration_runner.py adopt-existing/status'
            )
            return
        logger.info(
            'migration_registry: managed=%s applied=%s pending=%s drift=%s',
            status['managed_total'], status['applied_count'], status['pending_count'], status['drift_count']
        )
        if status['drift_count']:
            logger.error('migration_registry: drift rilevato su %s migration', status['drift_count'])
        elif status['pending_count']:
            logger.warning('migration_registry: %s migration gestite ancora pending', status['pending_count'])
    except Exception as exc:
        logger.warning('migration_registry.health_check_failed: %s', exc)
