#!/usr/bin/env python3
# Vemoria
# Copyright © 2026 Devoti Massimo. All rights reserved.
# Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

"""Vemora PostgreSQL contract smoke check.
Verifica bootstrap DB, estensioni, registry migration e contratti schema LUISS.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

CURRENT = Path(__file__).resolve()
BACKEND_DIR = CURRENT.parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from database.connessione import engine
from services.migration_registry_service import build_postgres_bootstrap_status, build_registry_status
from services.luiss_schema_contract_service import build_luiss_schema_contract_status


def main() -> int:
    try:
        with engine.connect() as conn:
            bootstrap = build_postgres_bootstrap_status(conn)
            if not bootstrap.get('ok'):
                payload = {
                    'ok': False,
                    'dialect': bootstrap.get('dialect'),
                    'postgres_bootstrap': bootstrap,
                    'migration_registry': None,
                    'luiss_schema_contract': None,
                }
                print(json.dumps(payload, indent=2, ensure_ascii=False))
                return 1
            registry = build_registry_status(conn)
            luiss = build_luiss_schema_contract_status(conn)
        payload = {
            "ok": bool(bootstrap.get("ok")) and not bool(luiss.get("is_blocking")),
            'dialect': bootstrap.get('dialect'),
            "postgres_bootstrap": bootstrap,
            "migration_registry": {
                "registry_present": registry.get("registry_present"),
                "managed_total": registry.get("managed_total"),
                "applied_count": registry.get("applied_count"),
                "pending_count": registry.get("pending_count"),
                "drift_count": registry.get("drift_count"),
            },
            "luiss_schema_contract": {
                "is_clean": luiss.get("is_clean"),
                "is_blocking": luiss.get("is_blocking"),
                "error_count": luiss.get("error_count"),
                "warning_count": luiss.get("warning_count"),
                "contracts": luiss.get("contracts"),
            },
        }
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 0 if payload["ok"] else 1
    except Exception as exc:
        payload = {
            "ok": False,
            "stage": "connect",
            "error_type": type(exc).__name__,
            "error": str(exc),
        }
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
