#!/usr/bin/env python3
# Vemoria
# Copyright © 2026 Devoti Massimo. All rights reserved.
# Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

"""Runner prudente per registry migration Vemora."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

CURRENT = Path(__file__).resolve()
BACKEND_DIR = CURRENT.parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from database.connessione import engine
from services.migration_registry_service import (
    adopt_existing,
    apply_pending,
    build_postgres_bootstrap_status,
    build_registry_status,
    ensure_registry_table_engine,
)
from services.luiss_schema_contract_service import build_luiss_schema_contract_status


def main() -> int:
    parser = argparse.ArgumentParser(description='Vemora migration registry runner')
    sub = parser.add_subparsers(dest='cmd', required=True)

    sub.add_parser('status', help='Mostra stato migration registry')
    sub.add_parser('preflight', help='Verifica contratto PostgreSQL/bootstrap prima delle migration additive')
    adopt = sub.add_parser('adopt-existing', help='Marca come applicate le migration gestite su DB già bootstrapato manualmente')
    adopt.add_argument('--applied-by', default='manual-adopt')
    adopt.add_argument('--note', default='Legacy DB adoption')

    apply_p = sub.add_parser('apply-pending', help='Applica le migration pending gestite dal registry')
    apply_p.add_argument('--applied-by', default='manual-runner')

    ensure = sub.add_parser('ensure-registry', help='Crea la tabella registry se manca')

    args = parser.parse_args()
    try:
        if args.cmd == 'ensure-registry':
            ensure_registry_table_engine(engine)
            print(json.dumps({'ok': True, 'action': 'ensure-registry'}))
            return 0
        if args.cmd == 'preflight':
            with engine.connect() as conn:
                status = build_postgres_bootstrap_status(conn)
                status['luiss_schema_contract'] = build_luiss_schema_contract_status(conn)
            print(json.dumps(status, indent=2, ensure_ascii=False))
            return 0 if status.get('ok') else 1
        if args.cmd == 'status':
            with engine.connect() as conn:
                status = build_registry_status(conn)
                status['luiss_schema_contract'] = build_luiss_schema_contract_status(conn)
            print(json.dumps(status, indent=2, ensure_ascii=False))
            return 0
        if args.cmd == 'adopt-existing':
            result = adopt_existing(engine, applied_by=args.applied_by, note=args.note)
            with engine.connect() as conn:
                result['luiss_schema_contract'] = build_luiss_schema_contract_status(conn)
            print(json.dumps(result, indent=2, ensure_ascii=False))
            return 0
        if args.cmd == 'apply-pending':
            result = apply_pending(engine, applied_by=args.applied_by)
            with engine.connect() as conn:
                result['luiss_schema_contract'] = build_luiss_schema_contract_status(conn)
            print(json.dumps(result, indent=2, ensure_ascii=False))
            return 0
        return 1
    except Exception as exc:
        print(json.dumps({
            'ok': False,
            'cmd': args.cmd,
            'error_type': type(exc).__name__,
            'error': str(exc),
        }, indent=2, ensure_ascii=False))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
