-- MB13-P3 v219: exact pack/revision integrity, legacy recovery, governed pack mutation
BEGIN;

-- Add quarantine columns to pack and revision
ALTER TABLE public.mb13_p3_action_pack
    ADD COLUMN IF NOT EXISTS legacy_idempotency_quarantined BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE public.mb13_p3_action_pack
    ADD COLUMN IF NOT EXISTS legacy_idempotency_quarantine_reason TEXT;

ALTER TABLE public.mb13_p3_action_pack_revision
    ADD COLUMN IF NOT EXISTS legacy_idempotency_quarantined BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE public.mb13_p3_action_pack_revision
    ADD COLUMN IF NOT EXISTS legacy_idempotency_quarantine_reason TEXT;

-- Drop functions whose RETURNS TABLE signature changes in v219.
DROP FUNCTION IF EXISTS public.mb13_p3_create_action_pack(
    uuid, uuid, uuid, uuid, text, jsonb, jsonb, jsonb, jsonb, timestamp with time zone, text, text
);
DROP FUNCTION IF EXISTS public.mb13_p3_get_action_pack(uuid, uuid);
DROP FUNCTION IF EXISTS public.mb13_p3_list_action_packs(
    uuid, text, integer, integer
);
DROP FUNCTION IF EXISTS public.mb13_p3_revise_action_pack(
    uuid, uuid, text, jsonb, jsonb, jsonb, jsonb, timestamp with time zone, text
);

-- Legacy idempotency recovery: exact synthetic keys only, no prefix wildcards.
CREATE OR REPLACE FUNCTION public.mb13_p3_legacy_idempotency_recover()
RETURNS TABLE(stage text, item_type text, candidate_count bigint, restored_count bigint, excluded_count bigint, quarantined_count bigint)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'pg_catalog', 'public'
AS $$
DECLARE
    v_pack_rec public.mb13_p3_action_pack%ROWTYPE;
    v_revision_rec public.mb13_p3_action_pack_revision%ROWTYPE;
    v_pack_candidate_count BIGINT := 0;
    v_pack_restored_count BIGINT := 0;
    v_pack_excluded_count BIGINT := 0;
    v_pack_quarantined_count BIGINT := 0;
    v_rev_candidate_count BIGINT := 0;
    v_rev_restored_count BIGINT := 0;
    v_rev_excluded_count BIGINT := 0;
    v_rev_quarantined_count BIGINT := 0;
    v_expected_hash TEXT;
    v_pack_hash TEXT;
    v_rev_hash TEXT;
    v_synthetic_key TEXT;
BEGIN
    -- Prevent concurrent recovery.
    PERFORM pg_advisory_xact_lock(hashtextextended('mb13_p3_legacy_idempotency_recover', 0));

    -- Disable triggers to allow historical revision correction.
    ALTER TABLE public.mb13_p3_action_pack DISABLE TRIGGER ALL;
    ALTER TABLE public.mb13_p3_action_pack_revision DISABLE TRIGGER ALL;

    -- Process pack candidates: exact synthetic v217 key only.
    FOR v_pack_rec IN
        SELECT *
          FROM public.mb13_p3_action_pack
         WHERE idempotency_key = 'legacy-pack-' || pack_id::text
    LOOP
        v_pack_candidate_count := v_pack_candidate_count + 1;

        SELECT * INTO v_revision_rec
          FROM public.mb13_p3_action_pack_revision
         WHERE pack_id = v_pack_rec.pack_id
           AND revision = v_pack_rec.pack_revision;

        IF NOT FOUND THEN
            UPDATE public.mb13_p3_action_pack
               SET legacy_idempotency_quarantined = TRUE,
                   legacy_idempotency_quarantine_reason = 'missing_current_revision'
             WHERE pack_id = v_pack_rec.pack_id;
            v_pack_quarantined_count := v_pack_quarantined_count + 1;
            CONTINUE;
        END IF;

        v_synthetic_key := 'legacy-rev-' || v_revision_rec.revision_id::text;

        -- Ambiguous if the current revision does not carry the expected synthetic key.
        IF v_revision_rec.idempotency_key IS DISTINCT FROM v_synthetic_key THEN
            UPDATE public.mb13_p3_action_pack
               SET legacy_idempotency_quarantined = TRUE,
                   legacy_idempotency_quarantine_reason = 'revision_synthetic_key_mismatch'
             WHERE pack_id = v_pack_rec.pack_id;
            v_pack_quarantined_count := v_pack_quarantined_count + 1;
            CONTINUE;
        END IF;

        -- Exact canonical projection between pack and its current revision (idempotency and payload may differ by design).
        IF v_pack_rec.owner_user_id IS DISTINCT FROM v_revision_rec.owner_user_id
           OR v_pack_rec.pack_id IS DISTINCT FROM v_revision_rec.pack_id
           OR v_pack_rec.pack_revision IS DISTINCT FROM v_revision_rec.revision
           OR v_pack_rec.monitor_revision IS DISTINCT FROM v_revision_rec.monitor_revision
           OR v_pack_rec.trigger_event_id IS DISTINCT FROM v_revision_rec.trigger_event_id
           OR v_pack_rec.diff_result_id IS DISTINCT FROM v_revision_rec.diff_result_id
           OR v_pack_rec.action_type IS DISTINCT FROM v_revision_rec.action_type
           OR v_pack_rec.target_ref IS DISTINCT FROM v_revision_rec.target_ref
           OR v_pack_rec.consent_refs IS DISTINCT FROM v_revision_rec.consent_refs
           OR v_pack_rec.provenance_refs IS DISTINCT FROM v_revision_rec.provenance_refs
           OR v_pack_rec.steps IS DISTINCT FROM v_revision_rec.steps
           OR v_pack_rec.expires_at IS DISTINCT FROM v_revision_rec.expires_at
           OR v_pack_rec.legacy_idempotency_unverified IS DISTINCT FROM v_revision_rec.legacy_idempotency_unverified
           OR COALESCE(v_pack_rec.legacy_idempotency_quarantined, FALSE) IS DISTINCT FROM COALESCE(v_revision_rec.legacy_idempotency_quarantined, FALSE)
        THEN
            UPDATE public.mb13_p3_action_pack
               SET legacy_idempotency_quarantined = TRUE,
                   legacy_idempotency_quarantine_reason = 'pack_revision_canonical_mismatch'
             WHERE pack_id = v_pack_rec.pack_id;
            v_pack_quarantined_count := v_pack_quarantined_count + 1;
            CONTINUE;
        END IF;

        -- Historical payload hash must be coherent with the synthetic idempotency key.
        v_expected_hash := public.mb13_p3_action_pack_payload_hash(
            v_pack_rec.owner_user_id, v_pack_rec.monitor_id, v_pack_rec.monitor_revision,
            v_pack_rec.trigger_event_id, v_pack_rec.diff_result_id, v_pack_rec.action_type,
            v_pack_rec.target_ref, v_pack_rec.consent_refs, v_pack_rec.provenance_refs, v_pack_rec.steps,
            v_pack_rec.expires_at, v_pack_rec.idempotency_key, v_pack_rec.status
        );
        IF v_expected_hash IS DISTINCT FROM v_pack_rec.payload_hash THEN
            UPDATE public.mb13_p3_action_pack
               SET legacy_idempotency_quarantined = TRUE,
                   legacy_idempotency_quarantine_reason = 'pack_payload_hash_synthetic_mismatch'
             WHERE pack_id = v_pack_rec.pack_id;
            v_pack_quarantined_count := v_pack_quarantined_count + 1;
            CONTINUE;
        END IF;

        v_expected_hash := public.mb13_p3_action_pack_payload_hash(
            v_revision_rec.owner_user_id, v_pack_rec.monitor_id, v_revision_rec.monitor_revision,
            v_revision_rec.trigger_event_id, v_revision_rec.diff_result_id, v_revision_rec.action_type,
            v_revision_rec.target_ref, v_revision_rec.consent_refs, v_revision_rec.provenance_refs, v_revision_rec.steps,
            v_revision_rec.expires_at, v_revision_rec.idempotency_key, v_revision_rec.status
        );
        IF v_expected_hash IS DISTINCT FROM v_revision_rec.payload_hash THEN
            UPDATE public.mb13_p3_action_pack
               SET legacy_idempotency_quarantined = TRUE,
                   legacy_idempotency_quarantine_reason = 'revision_payload_hash_synthetic_mismatch'
             WHERE pack_id = v_pack_rec.pack_id;
            v_pack_quarantined_count := v_pack_quarantined_count + 1;
            CONTINUE;
        END IF;

        -- Trigger/diff must still be valid at the historical monitor revision.
        BEGIN
            PERFORM public.mb13_p3_validate_trigger_diff(
                v_pack_rec.owner_user_id, v_pack_rec.monitor_id, v_pack_rec.monitor_revision,
                v_pack_rec.trigger_event_id, v_pack_rec.diff_result_id
            );
        EXCEPTION WHEN OTHERS THEN
            UPDATE public.mb13_p3_action_pack
               SET legacy_idempotency_quarantined = TRUE,
                   legacy_idempotency_quarantine_reason = 'trigger_or_diff_stale'
             WHERE pack_id = v_pack_rec.pack_id;
            v_pack_quarantined_count := v_pack_quarantined_count + 1;
            CONTINUE;
        END;

        -- Recompute the NULL-key historical hash and restore the legacy unverified state.
        v_pack_hash := public.mb13_p3_action_pack_payload_hash(
            v_pack_rec.owner_user_id, v_pack_rec.monitor_id, v_pack_rec.monitor_revision,
            v_pack_rec.trigger_event_id, v_pack_rec.diff_result_id, v_pack_rec.action_type,
            v_pack_rec.target_ref, v_pack_rec.consent_refs, v_pack_rec.provenance_refs, v_pack_rec.steps,
            v_pack_rec.expires_at, NULL, v_pack_rec.status
        );
        v_rev_hash := public.mb13_p3_action_pack_payload_hash(
            v_revision_rec.owner_user_id, v_pack_rec.monitor_id, v_revision_rec.monitor_revision,
            v_revision_rec.trigger_event_id, v_revision_rec.diff_result_id, v_revision_rec.action_type,
            v_revision_rec.target_ref, v_revision_rec.consent_refs, v_revision_rec.provenance_refs, v_revision_rec.steps,
            v_revision_rec.expires_at, NULL, v_revision_rec.status
        );

        UPDATE public.mb13_p3_action_pack
           SET idempotency_key = NULL,
               legacy_idempotency_unverified = TRUE,
               legacy_idempotency_quarantined = FALSE,
               legacy_idempotency_quarantine_reason = NULL,
               payload_hash = v_pack_hash
         WHERE pack_id = v_pack_rec.pack_id;

        UPDATE public.mb13_p3_action_pack_revision
           SET idempotency_key = NULL,
               legacy_idempotency_unverified = TRUE,
               legacy_idempotency_quarantined = FALSE,
               legacy_idempotency_quarantine_reason = NULL,
               payload_hash = v_rev_hash
         WHERE pack_id = v_pack_rec.pack_id
           AND revision = v_pack_rec.pack_revision;

        v_pack_restored_count := v_pack_restored_count + 1;
    END LOOP;

    -- Quarantine ambiguous prefix-like pack rows and count legitimate non-prefix keys.
    FOR v_pack_rec IN
        SELECT *
          FROM public.mb13_p3_action_pack
         WHERE idempotency_key LIKE 'legacy-pack-%'
           AND idempotency_key IS DISTINCT FROM 'legacy-pack-' || pack_id::text
           AND legacy_idempotency_quarantined = FALSE
           AND legacy_idempotency_unverified = FALSE
    LOOP
        v_pack_excluded_count := v_pack_excluded_count + 1;
        UPDATE public.mb13_p3_action_pack
           SET legacy_idempotency_quarantined = TRUE,
               legacy_idempotency_quarantine_reason = 'ambiguous_legacy_prefix'
         WHERE pack_id = v_pack_rec.pack_id;
        v_pack_quarantined_count := v_pack_quarantined_count + 1;
    END LOOP;

    SELECT COUNT(*) INTO v_pack_excluded_count
      FROM public.mb13_p3_action_pack
     WHERE idempotency_key IS NOT NULL
       AND idempotency_key NOT LIKE 'legacy-pack-%'
       AND legacy_idempotency_quarantined = FALSE
       AND legacy_idempotency_unverified = FALSE;

    -- Process orphan revision candidates: exact synthetic v217 key but no matching pack synthetic key.
    FOR v_revision_rec IN
        SELECT *
          FROM public.mb13_p3_action_pack_revision
         WHERE idempotency_key = 'legacy-rev-' || revision_id::text
           AND pack_id NOT IN (
               SELECT pack_id FROM public.mb13_p3_action_pack
                WHERE idempotency_key = 'legacy-pack-' || pack_id::text
           )
    LOOP
        v_rev_candidate_count := v_rev_candidate_count + 1;
        UPDATE public.mb13_p3_action_pack_revision
           SET legacy_idempotency_quarantined = TRUE,
               legacy_idempotency_quarantine_reason = 'orphan_revision_synthetic_key'
         WHERE revision_id = v_revision_rec.revision_id;
        v_rev_quarantined_count := v_rev_quarantined_count + 1;
    END LOOP;

    -- Quarantine ambiguous prefix-like revision rows and count legitimate non-prefix keys.
    FOR v_revision_rec IN
        SELECT *
          FROM public.mb13_p3_action_pack_revision
         WHERE idempotency_key LIKE 'legacy-rev-%'
           AND idempotency_key IS DISTINCT FROM 'legacy-rev-' || revision_id::text
           AND legacy_idempotency_quarantined = FALSE
           AND legacy_idempotency_unverified = FALSE
    LOOP
        v_rev_excluded_count := v_rev_excluded_count + 1;
        UPDATE public.mb13_p3_action_pack_revision
           SET legacy_idempotency_quarantined = TRUE,
               legacy_idempotency_quarantine_reason = 'ambiguous_legacy_prefix'
         WHERE revision_id = v_revision_rec.revision_id;
        v_rev_quarantined_count := v_rev_quarantined_count + 1;
    END LOOP;

    SELECT COUNT(*) INTO v_rev_excluded_count
      FROM public.mb13_p3_action_pack_revision
     WHERE idempotency_key IS NOT NULL
       AND idempotency_key NOT LIKE 'legacy-rev-%'
       AND legacy_idempotency_quarantined = FALSE
       AND legacy_idempotency_unverified = FALSE;

    -- Re-enable triggers.
    ALTER TABLE public.mb13_p3_action_pack ENABLE TRIGGER ALL;
    ALTER TABLE public.mb13_p3_action_pack_revision ENABLE TRIGGER ALL;

    stage := 'legacy_recovery';
    item_type := 'pack';
    candidate_count := v_pack_candidate_count;
    restored_count := v_pack_restored_count;
    excluded_count := v_pack_excluded_count;
    quarantined_count := v_pack_quarantined_count;
    RETURN NEXT;

    item_type := 'revision';
    candidate_count := v_rev_candidate_count;
    restored_count := v_rev_restored_count;
    excluded_count := v_rev_excluded_count;
    quarantined_count := v_rev_quarantined_count;
    RETURN NEXT;
    RETURN;
EXCEPTION WHEN OTHERS THEN
    ALTER TABLE public.mb13_p3_action_pack ENABLE TRIGGER ALL;
    ALTER TABLE public.mb13_p3_action_pack_revision ENABLE TRIGGER ALL;
    RAISE;
END;
$$;

-- Execute recovery during migration.
SELECT * FROM public.mb13_p3_legacy_idempotency_recover();

-- Function: governed pack mutation gate
DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_governed_mutation ON public.mb13_p3_action_pack;
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_governed_mutation()
RETURNS trigger AS $$
BEGIN
    IF current_setting('app.mb13_p3_authorized_pack_mutation', true) = 'true' THEN
        RETURN NEW;
    END IF;
    RAISE EXCEPTION 'mb13_p3_action_pack_direct_mutation_denied';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

CREATE TRIGGER trg_mb13_p3_action_pack_governed_mutation
    BEFORE INSERT OR UPDATE OR DELETE ON public.mb13_p3_action_pack
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p3_action_pack_governed_mutation();

CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_auth_hash(p_pack_id uuid, p_owner_user_id uuid, p_pack_revision integer, p_monitor_revision integer, p_authorized_at timestamp with time zone, p_expires_at timestamp with time zone)
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'pg_catalog', 'public'
AS $function$
BEGIN
    RETURN public.mb13_p0_hash_jsonb(jsonb_build_object(
        'pack_id', p_pack_id,
        'owner_user_id', p_owner_user_id,
        'pack_revision', p_pack_revision,
        'monitor_revision', p_monitor_revision,
        'authorized_at', p_authorized_at,
        'expires_at', p_expires_at
    ));
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_authorization_append_only()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_event_owner UUID;
    v_event_pack UUID;
    v_event_kind TEXT;
BEGIN
    IF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_authorization is append-only'
            USING ERRCODE = 'P3IMM';
    END IF;
    IF TG_OP = 'UPDATE' THEN
        IF NEW.auth_id IS DISTINCT FROM OLD.auth_id
           OR NEW.owner_user_id IS DISTINCT FROM OLD.owner_user_id
           OR NEW.pack_id IS DISTINCT FROM OLD.pack_id
           OR NEW.pack_revision IS DISTINCT FROM OLD.pack_revision
           OR NEW.pack_payload_hash IS DISTINCT FROM OLD.pack_payload_hash
           OR NEW.monitor_revision IS DISTINCT FROM OLD.monitor_revision
           OR NEW.action_type IS DISTINCT FROM OLD.action_type
           OR NEW.target_ref_hash IS DISTINCT FROM OLD.target_ref_hash
           OR NEW.consent_hash IS DISTINCT FROM OLD.consent_hash
           OR NEW.provenance_hash IS DISTINCT FROM OLD.provenance_hash
           OR NEW.authorized_at IS DISTINCT FROM OLD.authorized_at
           OR NEW.expires_at IS DISTINCT FROM OLD.expires_at
           OR NEW.auth_payload_hash IS DISTINCT FROM OLD.auth_payload_hash
           OR NEW.authorization_hash IS DISTINCT FROM OLD.authorization_hash
           OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization is append-only'
                USING ERRCODE = 'P3IMM';
        END IF;

        IF OLD.revoked = true THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_already_revoked'
                USING ERRCODE = 'P3IMM';
        END IF;

        IF NEW.revoked = false THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_revocation_required'
                USING ERRCODE = 'P3IMM';
        END IF;

        IF OLD.revoked_at IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_revoked_at_immutable'
                USING ERRCODE = 'P3IMM';
        END IF;
        IF NEW.revoked_at IS NULL THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_revoked_at_required'
                USING ERRCODE = 'P3IMM';
        END IF;
        IF NEW.revoked_at < OLD.authorized_at THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_revoked_at_invalid'
                USING ERRCODE = 'P3IMM';
        END IF;
        IF NEW.revoked_at > clock_timestamp() + INTERVAL '5 seconds' THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_revoked_at_arbitrary'
                USING ERRCODE = 'P3IMM';
        END IF;

        IF NEW.revocation_event_id IS NULL THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_revocation_event_id_required'
                USING ERRCODE = 'P3IMM';
        END IF;
        SELECT owner_user_id, pack_id, event_kind INTO v_event_owner, v_event_pack, v_event_kind
          FROM public.mb13_p3_action_pack_timeline
         WHERE timeline_event_id = NEW.revocation_event_id;
        IF NOT FOUND
           OR v_event_owner IS DISTINCT FROM NEW.owner_user_id
           OR v_event_pack IS DISTINCT FROM NEW.pack_id
           OR v_event_kind IS DISTINCT FROM 'authorization_revoked' THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_revocation_event_invalid'
                USING ERRCODE = 'P3IMM';
        END IF;
    END IF;
    RETURN NEW;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_authorization_hash(p_pack_id uuid, p_owner_user_id uuid, p_pack_revision integer, p_pack_payload_hash text, p_monitor_revision integer, p_action_type text, p_target_ref_hash text, p_consent_hash text, p_provenance_hash text, p_authorized_at timestamp with time zone, p_expires_at timestamp with time zone)
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'pg_catalog', 'public'
AS $function$
BEGIN
    RETURN public.mb13_p0_hash_jsonb(jsonb_build_object(
        'pack_id', p_pack_id,
        'owner_user_id', p_owner_user_id,
        'pack_revision', p_pack_revision,
        'pack_payload_hash', p_pack_payload_hash,
        'monitor_revision', p_monitor_revision,
        'action_type', p_action_type,
        'target_ref_hash', p_target_ref_hash,
        'consent_hash', p_consent_hash,
        'provenance_hash', p_provenance_hash,
        'authorized_at', p_authorized_at,
        'expires_at', p_expires_at
    ));
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_evidence_immutable()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
BEGIN
    RAISE EXCEPTION 'mb13_p3_action_pack_evidence is append-only'
        USING ERRCODE = 'P3IMM';
    RETURN NULL;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_monitor_policy_hash()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_policy_hash TEXT;
BEGIN
    IF TG_OP = 'INSERT' OR NEW.monitor_revision IS DISTINCT FROM OLD.monitor_revision THEN
        v_policy_hash := public.mb13_p3_get_monitor_policy_hash(NEW.owner_user_id, NEW.monitor_id, NEW.monitor_revision);
        IF v_policy_hash IS NULL THEN
            NEW.monitor_policy_hash := public.mb13_p0_hash_jsonb(jsonb_build_object('provenance_unverified', NEW.monitor_revision));
            NEW.provenance_state := 'unverified';
        ELSE
            NEW.monitor_policy_hash := v_policy_hash;
            NEW.provenance_state := 'verified';
        END IF;
    END IF;
    RETURN NEW;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_payload_hash(p_owner_user_id uuid, p_monitor_id uuid, p_monitor_revision integer, p_trigger_event_id uuid, p_diff_result_id uuid, p_action_type text, p_target_ref jsonb, p_consent_refs jsonb, p_provenance_refs jsonb, p_steps jsonb, p_expires_at timestamp with time zone, p_idempotency_key text, p_status text)
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'pg_catalog', 'public'
AS $function$
BEGIN
    RETURN public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'monitor_id', p_monitor_id,
        'monitor_revision', p_monitor_revision,
        'trigger_event_id', p_trigger_event_id,
        'diff_result_id', p_diff_result_id,
        'action_type', p_action_type,
        'target_ref', COALESCE(p_target_ref, '{}'::jsonb),
        'consent_refs', COALESCE(p_consent_refs, '[]'::jsonb),
        'provenance_refs', COALESCE(p_provenance_refs, '[]'::jsonb),
        'steps', COALESCE(p_steps, '[]'::jsonb),
        'expires_at', p_expires_at,
        'idempotency_key', p_idempotency_key,
        'status', p_status
    ));
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_refs_revoked(p_monitor mb13_p0_monitor_target, p_consent_refs jsonb, p_provenance_refs jsonb)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
BEGIN
    PERFORM public.mb13_p3_validate_source_grant_chain(
        p_monitor.owner_user_id, p_monitor, p_consent_refs, p_provenance_refs, '[]'::jsonb
    );
    RETURN false;
EXCEPTION WHEN OTHERS THEN
    RETURN true;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_result_evidence_guard()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
BEGIN
    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = NEW.attempt_id
       AND owner_user_id = NEW.owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.pack_id IS DISTINCT FROM NEW.pack_id OR v_attempt.attempt_number IS DISTINCT FROM NEW.attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_bound';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = NEW.pack_id
       AND owner_user_id = NEW.owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    IF NEW.outcome IN ('completed','partial') THEN
        PERFORM public.mb13_p3_validate_result_evidence(NEW.owner_user_id, NEW.pack_id, NEW.attempt_id, NEW.result_payload);
    END IF;

    RETURN NEW;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_result_hash(p_owner_user_id uuid, p_pack_id uuid, p_pack_revision integer, p_attempt_id uuid, p_attempt_number integer, p_outcome text, p_executor_identity text, p_result_payload jsonb, p_completed_at timestamp with time zone)
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'pg_catalog', 'public'
AS $function$
BEGIN
    RETURN public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'pack_id', p_pack_id,
        'pack_revision', p_pack_revision,
        'attempt_id', p_attempt_id,
        'attempt_number', p_attempt_number,
        'outcome', p_outcome,
        'executor_identity', p_executor_identity,
        'result_payload', COALESCE(p_result_payload, '{}'::jsonb),
        'completed_at', p_completed_at
    ));
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_result_immutable()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
BEGIN
    RAISE EXCEPTION 'mb13_p3_action_pack_result is append-only'
        USING ERRCODE = 'P3IMM';
    RETURN NULL;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_revision_immutable()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
BEGIN
    RAISE EXCEPTION 'mb13_p3_action_pack_revision is append-only'
        USING ERRCODE = 'P3IMM';
    RETURN NULL;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_now TIMESTAMPTZ := clock_timestamp();
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_transition_policy_hash TEXT;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_event_kind TEXT;
    v_old_status TEXT;
BEGIN
    IF NEW.status IN ('completed','partial','failed','cancelled','revoked','expired')
       AND NEW.status IS DISTINCT FROM OLD.status THEN

        SELECT * INTO v_monitor
          FROM public.mb13_p0_monitor_target
         WHERE owner_user_id = NEW.owner_user_id
           AND monitor_id = NEW.monitor_id
         FOR SHARE;
        IF FOUND THEN
            v_transition_policy_hash := public.mb13_p0_hash_jsonb(COALESCE(v_monitor.monitor_policy, '{}'::jsonb));
        ELSE
            v_transition_policy_hash := NEW.monitor_policy_hash;
        END IF;

        IF NEW.status = 'completed' THEN
            v_event_kind := 'attempt_completed';
        ELSIF NEW.status = 'partial' THEN
            v_event_kind := 'attempt_partial';
        ELSIF NEW.status = 'failed' THEN
            v_event_kind := 'attempt_failed';
        ELSIF NEW.status = 'cancelled' THEN
            v_event_kind := 'attempt_cancelled';
        ELSIF NEW.status = 'revoked' THEN
            v_event_kind := 'attempt_revoked';
        ELSE
            v_event_kind := 'attempt_expired';
        END IF;

        FOR v_attempt IN
            SELECT *
              FROM public.mb13_p3_action_pack_attempt
             WHERE pack_id = NEW.pack_id
               AND owner_user_id = NEW.owner_user_id
               AND status IN ('claimed','executing')
               FOR UPDATE
        LOOP
            v_old_status := v_attempt.status;
            UPDATE public.mb13_p3_action_pack_attempt
               SET status = NEW.status,
                   completed_at = COALESCE(completed_at, v_now)
             WHERE attempt_id = v_attempt.attempt_id
               AND owner_user_id = NEW.owner_user_id;

            INSERT INTO public.mb13_p3_action_pack_timeline (
                owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
                event_time, event_payload, monitor_revision, policy_hash
            ) VALUES (
                NEW.owner_user_id, NEW.pack_id, NEW.monitor_id, v_event_kind, v_old_status, NEW.status,
                v_now, jsonb_build_object(
                    'attempt_id', v_attempt.attempt_id,
                    'attempt_number', v_attempt.attempt_number,
                    'executor_identity', v_attempt.executor_identity,
                    'pack_revision', NEW.pack_revision,
                    'pack_monitor_revision', NEW.monitor_revision,
                    'pack_policy_hash', NEW.monitor_policy_hash,
                    'transition_monitor_revision', v_monitor.current_revision,
                    'transition_policy_hash', v_transition_policy_hash
                ),
                v_monitor.current_revision, v_transition_policy_hash
            );
        END LOOP;
    END IF;
    RETURN NEW;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_timeline_immutable()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
BEGIN
    IF TG_OP = 'INSERT' THEN
        NEW.payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', NEW.owner_user_id,
            'pack_id', NEW.pack_id,
            'monitor_id', NEW.monitor_id,
            'event_kind', NEW.event_kind,
            'from_state', NEW.from_state,
            'to_state', NEW.to_state,
            'event_time', NEW.event_time,
            'event_payload', NEW.event_payload,
            'monitor_revision', NEW.monitor_revision,
            'policy_hash', NEW.policy_hash
        ));
        RETURN NEW;
    END IF;
    RAISE EXCEPTION 'mb13_p3_action_pack_timeline is append-only'
        USING ERRCODE = 'P3IMM';
    RETURN NULL;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_transition_guard()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_step_consents JSONB;
BEGIN
    IF TG_OP = 'UPDATE' THEN
        IF NEW.consent_refs IS NOT DISTINCT FROM OLD.consent_refs
           AND NEW.provenance_refs IS NOT DISTINCT FROM OLD.provenance_refs
           AND NEW.steps IS NOT DISTINCT FROM OLD.steps
           AND NEW.monitor_id IS NOT DISTINCT FROM OLD.monitor_id
           AND NEW.monitor_revision IS NOT DISTINCT FROM OLD.monitor_revision
           AND NEW.monitor_policy_hash IS NOT DISTINCT FROM OLD.monitor_policy_hash
           AND NEW.provenance_state IS NOT DISTINCT FROM OLD.provenance_state
           AND NEW.trigger_event_id IS NOT DISTINCT FROM OLD.trigger_event_id
           AND NEW.diff_result_id IS NOT DISTINCT FROM OLD.diff_result_id
           AND NEW.action_type IS NOT DISTINCT FROM OLD.action_type
           AND NEW.target_ref IS NOT DISTINCT FROM OLD.target_ref
           AND NEW.status IS NOT DISTINCT FROM OLD.status THEN
            RETURN NEW;
        END IF;
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = NEW.owner_user_id
       AND monitor_id = NEW.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF NEW.provenance_state IS DISTINCT FROM 'verified' AND NEW.status NOT IN ('proposed') THEN
        RAISE EXCEPTION 'mb13_p3_pack_provenance_unverified';
    END IF;

    IF NEW.status IN ('proposed','authorized','claimed','executing') THEN
        IF NEW.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
            RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
        END IF;
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        NEW.owner_user_id, NEW.monitor_id, NEW.monitor_revision,
        NEW.trigger_event_id, NEW.diff_result_id
    );

    IF NEW.action_type NOT IN ('simulate','internal') THEN
        RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
    END IF;

    PERFORM public.mb13_p3_validate_steps(NEW.owner_user_id, COALESCE(NEW.steps, '[]'::jsonb));

    SELECT COALESCE(jsonb_agg(elem), '[]'::jsonb) INTO v_step_consents
    FROM (
        SELECT jsonb_array_elements(s->'consent_refs') AS elem
        FROM jsonb_array_elements(COALESCE(NEW.steps, '[]'::jsonb)) AS s
    ) sub;

    PERFORM public.mb13_p3_validate_source_grant_chain(
        NEW.owner_user_id, v_monitor, NEW.consent_refs, NEW.provenance_refs, v_step_consents
    );

    RETURN NEW;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_authorize_action_pack(p_owner_user_id uuid, p_pack_id uuid, p_expires_at timestamp with time zone DEFAULT NULL::timestamp with time zone)
 RETURNS TABLE(pack_id uuid, owner_user_id uuid, status text, pack_revision integer, authorized_at timestamp with time zone, expires_at timestamp with time zone)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_auth_expires TIMESTAMPTZ;
    v_policy_hash TEXT;
    v_auth_hash TEXT;
    v_pack_payload_hash TEXT;
    v_target_ref_hash TEXT;
    v_consent_hash TEXT;
    v_provenance_hash TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.provenance_state IS DISTINCT FROM 'verified' THEN
        RAISE EXCEPTION 'mb13_p3_pack_provenance_unverified';
    END IF;

    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.status NOT IN ('draft','proposed','awaiting_confirmation','authorized') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_cannot_authorize';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth_expires := COALESCE(p_expires_at, v_pack.expires_at, v_now + interval '1 hour');
    IF v_auth_expires <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_authorization_expired';
    END IF;

    v_policy_hash := COALESCE(public.mb13_p3_get_monitor_policy_hash(v_pack.owner_user_id, v_pack.monitor_id, v_pack.monitor_revision), public.mb13_p0_hash_jsonb(v_monitor.monitor_policy));
    v_pack_payload_hash := v_pack.payload_hash;
    v_target_ref_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb));
    v_consent_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb));
    v_provenance_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb));

    v_auth_hash := public.mb13_p3_action_pack_authorization_hash(
        p_pack_id, p_owner_user_id, v_pack.pack_revision, v_pack_payload_hash,
        v_monitor.current_revision, v_pack.action_type, v_target_ref_hash,
        v_consent_hash, v_provenance_hash, v_now, v_auth_expires
    );

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_pack.status, 'authorized',
            v_now, jsonb_build_object('pack_revision', v_pack.pack_revision, 'reason', 'authorize'),
            v_pack.monitor_revision, v_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    INSERT INTO public.mb13_p3_action_pack_authorization (
        owner_user_id, pack_id, pack_revision, authorized_at, expires_at,
        auth_payload_hash, pack_payload_hash, monitor_revision, action_type,
        target_ref_hash, consent_hash, provenance_hash, authorization_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.pack_revision, v_now, v_auth_expires,
        v_auth_hash, v_pack_payload_hash, v_monitor.current_revision, v_pack.action_type,
        v_target_ref_hash, v_consent_hash, v_provenance_hash, v_auth_hash
    );

    PERFORM set_config('app.mb13_p3_authorized_pack_mutation', 'true', true);
    UPDATE public.mb13_p3_action_pack
       SET status = 'authorized',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorized', v_pack.status, 'authorized',
        v_now, jsonb_build_object('pack_revision', v_pack.pack_revision, 'expires_at', v_auth_expires),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.owner_user_id, ap.status, ap.pack_revision, v_now, v_auth_expires
                   FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_cancel_action_pack(p_owner_user_id uuid, p_pack_id uuid)
 RETURNS TABLE(pack_id uuid, status text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_transition_policy_hash TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.status IN ('completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_already_terminal';
    END IF;

    v_transition_policy_hash := public.mb13_p0_hash_jsonb(COALESCE(v_monitor.monitor_policy, '{}'::jsonb));

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_pack.status, 'cancelled',
            v_now, jsonb_build_object(
                'pack_revision', v_pack.pack_revision,
                'pack_monitor_revision', v_pack.monitor_revision,
                'pack_policy_hash', v_pack.monitor_policy_hash,
                'transition_monitor_revision', v_monitor.current_revision,
                'transition_policy_hash', v_transition_policy_hash,
                'reason', 'cancel'
            ),
            v_monitor.current_revision, v_transition_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    PERFORM set_config('app.mb13_p3_authorized_pack_mutation', 'true', true);
    UPDATE public.mb13_p3_action_pack
       SET status = 'cancelled',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'cancelled', v_pack.status, 'cancelled',
        v_now, jsonb_build_object(
            'pack_monitor_revision', v_pack.monitor_revision,
            'pack_policy_hash', v_pack.monitor_policy_hash,
            'transition_monitor_revision', v_monitor.current_revision,
            'transition_policy_hash', v_transition_policy_hash
        ),
        v_monitor.current_revision, v_transition_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.status FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_canonicalize_evidence_payload(p_pack mb13_p3_action_pack, p_evidence_type text, p_evidence_payload jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_schema_version TEXT;
    v_status TEXT;
    v_details JSONB;
    v_action_result JSONB;
    v_required_action_type TEXT;
    v_pack_target_hash TEXT;
    v_target_ref_hash TEXT;
    v_step JSONB;
    v_step_number INTEGER;
    v_covered_steps JSONB;
    v_seen INTEGER[];
    v_n INTEGER;
    v_element TEXT;
    v_step_target_hash TEXT;
    v_failure_code TEXT;
    v_failed_step INTEGER;
    v_allowed_statuses TEXT[];
    v_pack_step_count INTEGER;
BEGIN
    IF p_evidence_payload IS NULL OR jsonb_typeof(p_evidence_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_payload_invalid';
    END IF;
    IF p_evidence_payload = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_payload_empty';
    END IF;

    v_schema_version := NULLIF(p_evidence_payload->>'schema_version', '');
    IF v_schema_version IS DISTINCT FROM 'mb13-p3-evidence/v1' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_schema_version_not_allowed';
    END IF;

    v_status := NULLIF(p_evidence_payload->>'status', '');
    IF v_status IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_evidence_status_required';
    END IF;

    v_details := p_evidence_payload->'details';
    IF v_details IS NULL OR jsonb_typeof(v_details) <> 'object' OR v_details = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_details_required';
    END IF;

    v_action_result := p_evidence_payload->'action_result';
    IF v_action_result IS NULL OR jsonb_typeof(v_action_result) <> 'object' OR v_action_result = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_action_result_required';
    END IF;
    IF v_action_result ? 'status' AND v_action_result->>'status' IS DISTINCT FROM v_status THEN
        RAISE EXCEPTION 'mb13_p3_evidence_action_result_status_mismatch';
    END IF;
    IF NOT (v_action_result ? 'status') THEN
        v_action_result := v_action_result || jsonb_build_object('status', v_status);
    END IF;

    v_pack_target_hash := public.mb13_p0_hash_jsonb(COALESCE(p_pack.target_ref, '{}'::jsonb));

    IF p_evidence_type = 'simulation_receipt' AND p_pack.action_type IS DISTINCT FROM 'simulate' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_type_action_mismatch';
    END IF;
    IF p_evidence_type = 'internal_action_receipt' AND p_pack.action_type IS DISTINCT FROM 'internal' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_type_action_mismatch';
    END IF;

    v_required_action_type := COALESCE(NULLIF(p_evidence_payload->>'action_type', ''), p_pack.action_type);

    v_pack_step_count := COALESCE(jsonb_array_length(COALESCE(p_pack.steps, '[]'::jsonb)), 0);

    IF p_evidence_type = 'step_result' THEN
        IF NOT (p_evidence_payload ? 'step_number') THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_required_for_step_result';
        END IF;
        BEGIN
            v_step_number := NULLIF(p_evidence_payload->>'step_number', '')::INTEGER;
        EXCEPTION WHEN OTHERS THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_invalid';
        END;
        IF v_step_number IS NULL OR v_step_number <= 0 THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_invalid';
        END IF;

        SELECT s INTO v_step
          FROM jsonb_array_elements(COALESCE(p_pack.steps, '[]'::jsonb)) s
         WHERE NULLIF(s->>'step_number', '')::INTEGER = v_step_number
         LIMIT 1;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_not_found';
        END IF;
        IF v_step ? 'action_type' AND v_step->>'action_type' IS DISTINCT FROM p_pack.action_type THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_action_type_mismatch';
        END IF;
        IF v_required_action_type IS DISTINCT FROM COALESCE(v_step->>'action_type', p_pack.action_type) THEN
            RAISE EXCEPTION 'mb13_p3_evidence_payload_action_type_mismatch';
        END IF;

        v_step_target_hash := public.mb13_p0_hash_jsonb(COALESCE(v_step->'target_ref', '{}'::jsonb));
        IF p_evidence_payload ? 'target_ref_hash' AND p_evidence_payload->>'target_ref_hash' IS DISTINCT FROM v_step_target_hash THEN
            RAISE EXCEPTION 'mb13_p3_evidence_target_ref_hash_mismatch';
        END IF;
        v_target_ref_hash := v_step_target_hash;

        v_allowed_statuses := ARRAY['ok','completed','failed','skipped'];
        v_covered_steps := COALESCE(p_evidence_payload->'covered_steps', '[]'::jsonb);
        IF jsonb_typeof(v_covered_steps) <> 'array' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_steps_invalid';
        END IF;
        v_covered_steps := jsonb_build_array(v_step_number);
    ELSIF p_evidence_type IN ('simulation_receipt','internal_action_receipt') THEN
        v_allowed_statuses := ARRAY['ok','completed','partial','failed'];
        IF v_required_action_type IS DISTINCT FROM p_pack.action_type THEN
            RAISE EXCEPTION 'mb13_p3_evidence_payload_action_type_mismatch';
        END IF;
        IF p_evidence_payload ? 'target_ref_hash' AND p_evidence_payload->>'target_ref_hash' IS DISTINCT FROM v_pack_target_hash THEN
            RAISE EXCEPTION 'mb13_p3_evidence_target_ref_hash_mismatch';
        END IF;
        v_target_ref_hash := v_pack_target_hash;

        IF v_pack_step_count > 0 THEN
            IF NOT (p_evidence_payload ? 'covered_steps') THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_steps_required';
            END IF;
        END IF;

        IF NOT (p_evidence_payload ? 'covered_steps') THEN
            v_covered_steps := '[]'::jsonb;
        ELSE
            v_covered_steps := p_evidence_payload->'covered_steps';
            IF v_covered_steps IS NULL OR jsonb_typeof(v_covered_steps) IS NULL OR jsonb_typeof(v_covered_steps) <> 'array' THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_steps_invalid';
            END IF;
        END IF;

        v_seen := ARRAY[]::INTEGER[];
        FOR v_element IN SELECT jsonb_array_elements_text(v_covered_steps) LOOP
            BEGIN
                v_n := NULLIF(v_element, '')::INTEGER;
            EXCEPTION WHEN OTHERS THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
            END;
            IF v_n IS NULL OR v_n <= 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
            END IF;
            IF v_n = ANY(COALESCE(v_seen, ARRAY[]::INTEGER[])) THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_duplicate';
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM jsonb_array_elements(COALESCE(p_pack.steps, '[]'::jsonb)) s
                WHERE NULLIF(s->>'step_number', '')::INTEGER = v_n
            ) THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_not_found';
            END IF;
            v_seen := array_append(v_seen, v_n);
        END LOOP;
        v_covered_steps := to_jsonb(v_seen);
    ELSIF p_evidence_type = 'failure_receipt' THEN
        v_allowed_statuses := ARRAY['failed'];
        IF v_status IS DISTINCT FROM 'failed' THEN
            RAISE EXCEPTION 'mb13_p3_failure_receipt_status_must_be_failed';
        END IF;

        v_failure_code := NULLIF(p_evidence_payload->>'failure_code', '');
        IF v_failure_code IS NULL THEN
            RAISE EXCEPTION 'mb13_p3_failure_receipt_code_required';
        END IF;
        IF v_details IS NULL OR v_details = '{}'::jsonb THEN
            RAISE EXCEPTION 'mb13_p3_failure_receipt_details_required';
        END IF;
        IF v_required_action_type IS DISTINCT FROM p_pack.action_type THEN
            RAISE EXCEPTION 'mb13_p3_evidence_payload_action_type_mismatch';
        END IF;
        IF p_evidence_payload ? 'target_ref_hash' AND p_evidence_payload->>'target_ref_hash' IS DISTINCT FROM v_pack_target_hash THEN
            RAISE EXCEPTION 'mb13_p3_evidence_target_ref_hash_mismatch';
        END IF;
        v_target_ref_hash := v_pack_target_hash;

        v_failed_step := NULLIF(p_evidence_payload->>'failed_step', '')::INTEGER;
        IF v_failed_step IS NOT NULL THEN
            IF NOT EXISTS (
                SELECT 1 FROM jsonb_array_elements(COALESCE(p_pack.steps, '[]'::jsonb)) s
                WHERE NULLIF(s->>'step_number', '')::INTEGER = v_failed_step
            ) THEN
                RAISE EXCEPTION 'mb13_p3_failure_receipt_step_not_found';
            END IF;
        END IF;

        IF NOT (p_evidence_payload ? 'covered_steps') THEN
            IF v_failed_step IS NOT NULL THEN
                v_covered_steps := jsonb_build_array(v_failed_step);
            ELSE
                v_covered_steps := '[]'::jsonb;
            END IF;
        ELSE
            v_covered_steps := p_evidence_payload->'covered_steps';
            IF v_covered_steps IS NULL OR jsonb_typeof(v_covered_steps) IS NULL OR jsonb_typeof(v_covered_steps) <> 'array' THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_steps_invalid';
            END IF;
        END IF;
        v_seen := ARRAY[]::INTEGER[];
        FOR v_element IN SELECT jsonb_array_elements_text(v_covered_steps) LOOP
            BEGIN
                v_n := NULLIF(v_element, '')::INTEGER;
            EXCEPTION WHEN OTHERS THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
            END;
            IF v_n IS NULL OR v_n <= 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
            END IF;
            IF v_n = ANY(COALESCE(v_seen, ARRAY[]::INTEGER[])) THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_duplicate';
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM jsonb_array_elements(COALESCE(p_pack.steps, '[]'::jsonb)) s
                WHERE NULLIF(s->>'step_number', '')::INTEGER = v_n
            ) THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_not_found';
            END IF;
            v_seen := array_append(v_seen, v_n);
        END LOOP;
        v_covered_steps := to_jsonb(v_seen);
    ELSE
        RAISE EXCEPTION 'mb13_p3_evidence_type_not_allowed';
    END IF;

    IF NOT (v_status = ANY (v_allowed_statuses)) THEN
        RAISE EXCEPTION 'mb13_p3_evidence_status_not_allowed_for_type';
    END IF;

    RETURN p_evidence_payload
        || jsonb_build_object(
            'action_type', v_required_action_type,
            'target_ref_hash', v_target_ref_hash,
            'covered_steps', v_covered_steps,
            'action_result', v_action_result
        );
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_canonicalize_result_evidence(p_owner_user_id uuid, p_pack_id uuid, p_attempt_id uuid, p_result_payload jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_evidence JSONB;
    v_evidence_type TEXT;
    v_evidence_id UUID;
    v_receipt_id UUID;
    v_row public.mb13_p3_action_pack_evidence%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_expected_hash TEXT;
    v_canonical JSONB;
BEGIN
    IF p_result_payload IS NULL OR jsonb_typeof(p_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_payload_invalid';
    END IF;

    v_evidence := p_result_payload->'evidence';
    IF v_evidence IS NULL OR jsonb_typeof(v_evidence) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_required';
    END IF;
    IF v_evidence ? 'evidence_hash' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_hash_from_body_forbidden';
    END IF;

    v_evidence_type := NULLIF(v_evidence->>'evidence_type', '');
    v_evidence_id := NULLIF(v_evidence->>'evidence_id', '')::UUID;
    v_receipt_id := NULLIF(v_evidence->>'receipt_id', '')::UUID;

    IF v_evidence_type IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_type_required';
    END IF;
    IF v_evidence_id IS NULL AND v_receipt_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_not_pre_registered';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_evidence_id IS NOT NULL THEN
        SELECT * INTO v_row
          FROM public.mb13_p3_action_pack_evidence
         WHERE evidence_id = v_evidence_id
           AND owner_user_id = p_owner_user_id;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_found';
        END IF;
        IF v_row.pack_id IS DISTINCT FROM p_pack_id OR v_row.attempt_id IS DISTINCT FROM p_attempt_id THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_bound';
        END IF;
        IF v_receipt_id IS NOT NULL AND v_row.receipt_id IS DISTINCT FROM v_receipt_id THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_receipt_mismatch';
        END IF;
    ELSE
        SELECT * INTO v_row
          FROM public.mb13_p3_action_pack_evidence
         WHERE receipt_id = v_receipt_id
           AND owner_user_id = p_owner_user_id;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_found';
        END IF;
        IF v_row.pack_id IS DISTINCT FROM p_pack_id OR v_row.attempt_id IS DISTINCT FROM p_attempt_id THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_bound';
        END IF;
    END IF;

    IF v_row.evidence_state IS DISTINCT FROM 'active' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_quarantined';
    END IF;

    PERFORM public.mb13_p3_canonicalize_evidence_payload(v_pack, v_row.evidence_type, v_row.evidence_payload);

    IF v_row.evidence_type IS DISTINCT FROM v_evidence_type THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_type_mismatch';
    END IF;
    IF v_row.attempt_number IS DISTINCT FROM v_attempt.attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_attempt_number_mismatch';
    END IF;
    IF v_row.pack_revision IS DISTINCT FROM v_pack.pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_pack_revision_mismatch';
    END IF;
    IF v_row.monitor_revision IS DISTINCT FROM v_pack.monitor_revision THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_monitor_revision_mismatch';
    END IF;
    IF v_row.executor_identity IS DISTINCT FROM v_attempt.executor_identity THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_executor_identity_mismatch';
    END IF;
    IF v_row.evidence_schema_version IS DISTINCT FROM 'mb13-p3-evidence/v1' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_schema_version_mismatch';
    END IF;

    v_expected_hash := public.mb13_p0_hash_jsonb(v_row.evidence_payload);
    IF v_row.evidence_hash IS DISTINCT FROM v_expected_hash THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_integrity_failure';
    END IF;

    v_canonical := jsonb_build_object(
        'evidence', jsonb_build_object(
            'evidence_id', v_row.evidence_id,
            'receipt_id', v_row.receipt_id,
            'evidence_type', v_row.evidence_type
        ),
        'evidence_hash', v_row.evidence_hash,
        'evidence_payload', v_row.evidence_payload
    );
    RETURN v_canonical;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_claim_action_pack(p_owner_user_id uuid, p_pack_id uuid, p_expected_pack_revision integer, p_claim_nonce text, p_idempotency_key text)
 RETURNS TABLE(attempt_id uuid, pack_id uuid, attempt_number integer, claim_nonce text, status text, created_at timestamp with time zone)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_existing public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
    v_attempt_number INTEGER;
    v_attempt_id UUID;
    v_request_hash TEXT;
    v_executor_identity TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_idempotency_key IS NULL OR length(COALESCE(p_idempotency_key, '')) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_idempotency_key_required';
    END IF;
    IF p_claim_nonce IS NULL OR length(COALESCE(p_claim_nonce, '')) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_claim_nonce_required';
    END IF;

    v_executor_identity := session_user;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_existing
      FROM public.mb13_p3_action_pack_attempt
     WHERE pack_id = p_pack_id
       AND idempotency_key = p_idempotency_key
     FOR UPDATE;
    IF FOUND THEN
        v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'pack_id', p_pack_id,
            'pack_revision', p_expected_pack_revision,
            'claim_nonce', p_claim_nonce,
            'idempotency_key', p_idempotency_key,
            'executor_identity', v_executor_identity
        ));
        IF v_existing.claim_request_hash IS DISTINCT FROM v_request_hash
           OR v_existing.claim_pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;

    IF v_existing.attempt_id IS NULL AND v_pack.status IS DISTINCT FROM 'authorized' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_authorized';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    IF v_existing.attempt_id IS NOT NULL THEN
        RETURN QUERY SELECT v_existing.attempt_id, v_existing.pack_id, v_existing.attempt_number,
                            v_existing.claim_nonce, v_existing.status, v_existing.created_at;
        RETURN;
    END IF;

    v_policy_hash := COALESCE(public.mb13_p3_get_monitor_policy_hash(v_pack.owner_user_id, v_pack.monitor_id, v_pack.monitor_revision), public.mb13_p0_hash_jsonb(v_monitor.monitor_policy));
    v_attempt_number := COALESCE((SELECT MAX(attempt_number) FROM public.mb13_p3_action_pack_attempt WHERE pack_id = p_pack_id), 0) + 1;
    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'pack_id', p_pack_id,
        'pack_revision', p_expected_pack_revision,
        'claim_nonce', p_claim_nonce,
        'idempotency_key', p_idempotency_key,
        'executor_identity', v_executor_identity
    ));

    PERFORM set_config('app.mb13_p3_authorized_pack_mutation', 'true', true);
        INSERT INTO public.mb13_p3_action_pack_attempt (
        owner_user_id, pack_id, attempt_number, idempotency_key, claim_nonce,
        executor_identity, status, created_at, claim_request_hash, claim_pack_revision
    ) VALUES (
        p_owner_user_id, p_pack_id, v_attempt_number, p_idempotency_key, p_claim_nonce,
        v_executor_identity, 'claimed', v_now, v_request_hash, p_expected_pack_revision
    ) RETURNING public.mb13_p3_action_pack_attempt.attempt_id INTO v_attempt_id;

    PERFORM set_config('app.mb13_p3_authorized_pack_mutation', 'true', true);
    UPDATE public.mb13_p3_action_pack
       SET status = 'claimed',
           claimed_attempt_id = v_attempt_id,
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'claimed', 'authorized', 'claimed',
        v_now, jsonb_build_object('attempt_id', v_attempt_id, 'attempt_number', v_attempt_number, 'claim_nonce', p_claim_nonce, 'executor_identity', v_executor_identity),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt_id, p_pack_id, v_attempt_number, p_claim_nonce, 'claimed'::TEXT, v_now;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_complete_action_pack(p_owner_user_id uuid, p_pack_id uuid, p_attempt_id uuid, p_expected_pack_revision integer, p_expected_attempt_number integer, p_outcome text, p_result_payload jsonb)
 RETURNS TABLE(attempt_id uuid, pack_id uuid, attempt_number integer, status text, result_hash text, completed_at timestamp with time zone)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_existing_result public.mb13_p3_action_pack_result%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_transition_monitor_revision INTEGER;
    v_transition_policy_hash TEXT;
    v_pack_policy_hash TEXT;
    v_result_hash TEXT;
    v_event_kind TEXT;
    v_old_status TEXT;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_canonical_evidence JSONB;
    v_evidence_payload JSONB;
    v_evidence_status TEXT;
    v_covered_steps JSONB;
    v_result_payload JSONB;
    v_status_allowed BOOLEAN;
    v_pack_step_numbers INTEGER[];
    v_covered INTEGER[];
    v_missing INTEGER;
    v_n INTEGER;
    v_element TEXT;
    v_step_consents JSONB := '[]'::jsonb;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_outcome NOT IN ('completed','partial','failed') THEN
        RAISE EXCEPTION 'mb13_p3_invalid_outcome';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.executor_identity IS DISTINCT FROM session_user THEN
        RAISE EXCEPTION 'mb13_p3_executor_identity_mismatch';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;
    IF v_attempt.attempt_number IS DISTINCT FROM p_expected_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.provenance_state IS DISTINCT FROM 'verified' THEN
        RAISE EXCEPTION 'mb13_p3_pack_provenance_unverified';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    IF p_result_payload IS NULL THEN
        v_result_payload := '{}'::jsonb;
    ELSE
        v_result_payload := p_result_payload;
    END IF;
    IF jsonb_typeof(v_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_payload_invalid';
    END IF;

    IF NOT (v_result_payload ? 'evidence') THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_required';
    END IF;

    IF v_result_payload ? 'outcome' THEN
        IF v_result_payload->>'outcome' IS DISTINCT FROM p_outcome THEN
            RAISE EXCEPTION 'mb13_p3_result_payload_outcome_mismatch';
        END IF;
    END IF;

    v_canonical_evidence := public.mb13_p3_canonicalize_result_evidence(p_owner_user_id, p_pack_id, p_attempt_id, v_result_payload);
    v_evidence_payload := v_canonical_evidence->'evidence_payload';
    v_evidence_status := v_evidence_payload->>'status';

    IF p_outcome = 'failed' THEN
        IF v_canonical_evidence->'evidence'->>'evidence_type' IS DISTINCT FROM 'failure_receipt' THEN
            RAISE EXCEPTION 'mb13_p3_result_failure_receipt_required';
        END IF;
    ELSE
        IF v_canonical_evidence->'evidence'->>'evidence_type' IS DISTINCT FROM 'failure_receipt' THEN
            v_status_allowed := false;
            IF p_outcome = 'completed' AND v_evidence_status IN ('ok','completed') THEN
                v_status_allowed := true;
            END IF;
            IF p_outcome = 'partial' AND v_evidence_status IN ('ok','completed','partial') THEN
                v_status_allowed := true;
            END IF;
            IF NOT v_status_allowed THEN
                RAISE EXCEPTION 'mb13_p3_evidence_status_incompatible_with_outcome';
            END IF;
        ELSE
            RAISE EXCEPTION 'mb13_p3_evidence_status_incompatible_with_outcome';
        END IF;
    END IF;

    v_covered_steps := v_evidence_payload->'covered_steps';
    IF v_covered_steps IS NULL OR jsonb_typeof(v_covered_steps) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_covered_steps_invalid';
    END IF;

    SELECT COALESCE(array_agg(NULLIF(s->>'step_number', '')::INTEGER ORDER BY NULLIF(s->>'step_number', '')::INTEGER), ARRAY[]::INTEGER[])
      INTO v_pack_step_numbers
      FROM jsonb_array_elements(COALESCE(v_pack.steps, '[]'::jsonb)) s;

    v_covered := ARRAY[]::INTEGER[];
    FOR v_element IN SELECT jsonb_array_elements_text(v_covered_steps) LOOP
        BEGIN
            v_n := NULLIF(v_element, '')::INTEGER;
        EXCEPTION WHEN OTHERS THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
        END;
        IF v_n IS NULL OR v_n <= 0 THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
        END IF;
        IF v_n = ANY(COALESCE(v_covered, ARRAY[]::INTEGER[])) THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_step_duplicate';
        END IF;
        IF NOT (v_n = ANY(v_pack_step_numbers)) THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_step_not_found';
        END IF;
        v_covered := array_append(v_covered, v_n);
    END LOOP;

    IF p_outcome = 'completed' THEN
        IF array_length(v_pack_step_numbers, 1) > 0 THEN
            IF array_length(v_covered, 1) IS NULL OR array_length(v_covered, 1) = 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_step_coverage_incomplete';
            END IF;
            FOREACH v_missing IN ARRAY v_pack_step_numbers LOOP
                IF NOT (v_missing = ANY(v_covered)) THEN
                    RAISE EXCEPTION 'mb13_p3_evidence_step_coverage_incomplete';
                END IF;
            END LOOP;
        ELSE
            IF array_length(v_covered, 1) > 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_step_coverage_incomplete';
            END IF;
        END IF;
    ELSIF p_outcome = 'partial' THEN
        IF array_length(v_pack_step_numbers, 1) > 0 THEN
            IF array_length(v_covered, 1) IS NULL OR array_length(v_covered, 1) = 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_partial_no_step_covered';
            END IF;
        ELSE
            IF array_length(v_covered, 1) > 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_partial_no_step_covered';
            END IF;
        END IF;
    END IF;

    v_result_payload := v_result_payload - 'evidence_hash' - 'evidence' - 'outcome' - 'evidence_payload';
    v_result_payload := v_result_payload || jsonb_build_object(
        'outcome', p_outcome,
        'evidence', v_canonical_evidence->'evidence',
        'evidence_hash', v_canonical_evidence->'evidence_hash',
        'evidence_payload', v_canonical_evidence->'evidence_payload'
    );

    SELECT * INTO v_existing_result
      FROM public.mb13_p3_action_pack_result
     WHERE attempt_id = p_attempt_id
       AND owner_user_id = p_owner_user_id;
    IF FOUND THEN
        IF v_existing_result.outcome IS DISTINCT FROM p_outcome THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
        IF v_existing_result.result_payload IS DISTINCT FROM v_result_payload THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
        RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                            p_outcome::TEXT, v_existing_result.result_hash, v_existing_result.created_at;
        RETURN;
    END IF;

    v_step_consents := public.mb13_p3_get_covered_step_consents(v_pack, v_evidence_payload);
    PERFORM public.mb13_p3_validate_source_grant_chain(
        p_owner_user_id, v_monitor, v_pack.consent_refs, v_pack.provenance_refs, v_step_consents
    );

    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    v_transition_monitor_revision := v_monitor.current_revision;
    v_transition_policy_hash := COALESCE(public.mb13_p3_get_monitor_policy_hash(v_pack.owner_user_id, v_pack.monitor_id, v_monitor.current_revision), public.mb13_p0_hash_jsonb(COALESCE(v_monitor.monitor_policy, '{}'::jsonb)));
    v_pack_policy_hash := v_pack.monitor_policy_hash;

    v_event_kind := p_outcome;
    v_old_status := v_pack.status;

    v_result_hash := public.mb13_p3_action_pack_result_hash(
        p_owner_user_id, p_pack_id, v_pack.pack_revision, p_attempt_id,
        v_attempt.attempt_number, p_outcome, v_attempt.executor_identity,
        v_result_payload, v_now
    );

    INSERT INTO public.mb13_p3_action_pack_result (
        owner_user_id, pack_id, attempt_id, attempt_number, outcome, executor_identity,
        result_payload, result_hash, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, v_attempt.attempt_number, p_outcome,
        v_attempt.executor_identity, v_result_payload, v_result_hash, v_now
    );

    UPDATE public.mb13_p3_action_pack_attempt
       SET result_payload = v_result_payload,
           result_hash = v_result_hash,
           completed_at = v_now
     WHERE attempt_id = p_attempt_id;

    PERFORM set_config('app.mb13_p3_authorized_pack_mutation', 'true', true);
    UPDATE public.mb13_p3_action_pack
       SET status = p_outcome,
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, v_event_kind, v_old_status, p_outcome,
        v_now, jsonb_build_object(
            'attempt_id', p_attempt_id,
            'attempt_number', v_attempt.attempt_number,
            'result_hash', v_result_hash,
            'pack_monitor_revision', v_pack.monitor_revision,
            'pack_policy_hash', v_pack_policy_hash,
            'transition_monitor_revision', v_transition_monitor_revision,
            'transition_policy_hash', v_transition_policy_hash
        ),
        v_transition_monitor_revision, v_transition_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                        p_outcome::TEXT, v_result_hash, v_now;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_create_action_pack(p_owner_user_id uuid, p_monitor_id uuid, p_trigger_event_id uuid, p_diff_result_id uuid, p_action_type text, p_target_ref jsonb, p_consent_refs jsonb, p_provenance_refs jsonb, p_steps jsonb, p_expires_at timestamp with time zone, p_idempotency_key text, p_initial_status text DEFAULT 'proposed'::text)
 RETURNS TABLE(pack_id uuid, owner_user_id uuid, monitor_id uuid, monitor_revision integer, trigger_event_id uuid, diff_result_id uuid, pack_revision integer, payload_hash text, action_type text, target_ref jsonb, consent_refs jsonb, provenance_refs jsonb, steps jsonb, expires_at timestamp with time zone, idempotency_key text, status text, claimed_attempt_id uuid, created_at timestamp with time zone, updated_at timestamp with time zone, monitor_policy_hash text, provenance_state text, legacy_idempotency_unverified boolean, legacy_idempotency_quarantined boolean, legacy_idempotency_quarantine_reason text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_existing public.mb13_p3_action_pack%ROWTYPE;
    v_pack_id UUID;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
    v_payload_hash TEXT;
    v_status TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_idempotency_key IS NULL OR length(trim(p_idempotency_key)) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_idempotency_key_required';
    END IF;

    -- Serialize concurrent creates with the same owner-scoped idempotency key.
    PERFORM pg_advisory_xact_lock(hashtextextended(p_owner_user_id::text || ':' || p_idempotency_key, 0));

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := COALESCE(public.mb13_p3_get_monitor_policy_hash(p_owner_user_id, p_monitor_id, v_monitor_revision), public.mb13_p0_hash_jsonb(v_monitor.monitor_policy));
    v_status := COALESCE(p_initial_status, 'proposed');

    IF v_status NOT IN ('draft','proposed','awaiting_confirmation') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_invalid_initial_status';
    END IF;

    IF p_action_type NOT IN ('simulate','internal') THEN
        RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
    END IF;

    PERFORM public.mb13_p3_validate_steps(p_owner_user_id, COALESCE(p_steps, '[]'::jsonb));

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, p_monitor_id, v_monitor_revision,
        p_trigger_event_id, p_diff_result_id
    );

    IF p_expires_at IS NOT NULL AND p_expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    SELECT * INTO v_existing
      FROM public.mb13_p3_action_pack
     WHERE owner_user_id = p_owner_user_id
       AND idempotency_key = p_idempotency_key;
    IF FOUND THEN
        v_payload_hash := public.mb13_p3_action_pack_payload_hash(
            p_owner_user_id, p_monitor_id, v_monitor_revision,
            p_trigger_event_id, p_diff_result_id, p_action_type,
            p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
            p_expires_at, p_idempotency_key, v_status
        );
        IF v_existing.payload_hash IS DISTINCT FROM v_payload_hash THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
        RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = v_existing.pack_id AND ap.owner_user_id = p_owner_user_id;
        RETURN;
    END IF;

    v_payload_hash := public.mb13_p3_action_pack_payload_hash(
        p_owner_user_id, p_monitor_id, v_monitor_revision,
        p_trigger_event_id, p_diff_result_id, p_action_type,
        p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
        p_expires_at, p_idempotency_key, v_status
    );

    PERFORM set_config('app.mb13_p3_authorized_pack_mutation', 'true', true);
    INSERT INTO public.mb13_p3_action_pack (
        owner_user_id, monitor_id, monitor_revision, trigger_event_id, diff_result_id,
        pack_revision, payload_hash, action_type, target_ref, consent_refs, provenance_refs,
        steps, expires_at, idempotency_key, status, created_at, updated_at
    ) VALUES (
        p_owner_user_id, p_monitor_id, v_monitor_revision, p_trigger_event_id, p_diff_result_id,
        1, v_payload_hash, p_action_type, COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, p_idempotency_key, v_status, v_now, v_now
    ) RETURNING public.mb13_p3_action_pack.pack_id INTO v_pack_id;

    INSERT INTO public.mb13_p3_action_pack_revision (
        owner_user_id, pack_id, revision, monitor_revision, trigger_event_id, diff_result_id,
        payload_hash, action_type, target_ref, consent_refs, provenance_refs, steps,
        expires_at, idempotency_key, status, created_at
    ) VALUES (
        p_owner_user_id, v_pack_id, 1, v_monitor_revision, p_trigger_event_id, p_diff_result_id,
        v_payload_hash, p_action_type, COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, p_idempotency_key, v_status, v_now
    );

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_pack_id, p_monitor_id, 'pack_created', NULL, v_status,
        v_now, jsonb_build_object('pack_revision', 1),
        v_monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = v_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_expire_action_pack(p_owner_user_id uuid, p_pack_id uuid)
 RETURNS TABLE(pack_id uuid, status text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_transition_policy_hash TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.status IN ('completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_already_terminal';
    END IF;

    IF v_pack.expires_at IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_no_expiry';
    END IF;
    IF v_pack.expires_at > v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_yet_expired';
    END IF;

    v_transition_policy_hash := public.mb13_p0_hash_jsonb(COALESCE(v_monitor.monitor_policy, '{}'::jsonb));

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_pack.status, 'expired',
            v_now, jsonb_build_object(
                'pack_revision', v_pack.pack_revision,
                'pack_monitor_revision', v_pack.monitor_revision,
                'pack_policy_hash', v_pack.monitor_policy_hash,
                'transition_monitor_revision', v_monitor.current_revision,
                'transition_policy_hash', v_transition_policy_hash,
                'reason', 'expire'
            ),
            v_monitor.current_revision, v_transition_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    PERFORM set_config('app.mb13_p3_authorized_pack_mutation', 'true', true);
    UPDATE public.mb13_p3_action_pack
       SET status = 'expired',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'expired', v_pack.status, 'expired',
        v_now, jsonb_build_object(
            'pack_monitor_revision', v_pack.monitor_revision,
            'pack_policy_hash', v_pack.monitor_policy_hash,
            'transition_monitor_revision', v_monitor.current_revision,
            'transition_policy_hash', v_transition_policy_hash
        ),
        v_monitor.current_revision, v_transition_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.status FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_get_action_pack(p_owner_user_id uuid, p_pack_id uuid)
 RETURNS TABLE(pack_id uuid, owner_user_id uuid, monitor_id uuid, monitor_revision integer, trigger_event_id uuid, diff_result_id uuid, pack_revision integer, payload_hash text, action_type text, target_ref jsonb, consent_refs jsonb, provenance_refs jsonb, steps jsonb, expires_at timestamp with time zone, idempotency_key text, status text, claimed_attempt_id uuid, created_at timestamp with time zone, updated_at timestamp with time zone, monitor_policy_hash text, provenance_state text, legacy_idempotency_unverified boolean, legacy_idempotency_quarantined boolean, legacy_idempotency_quarantine_reason text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_get_action_pack_attempts(p_owner_user_id uuid, p_pack_id uuid)
 RETURNS TABLE(attempt_id uuid, attempt_number integer, idempotency_key text, claim_nonce text, executor_identity text, status text, result_payload jsonb, result_hash text, started_at timestamp with time zone, completed_at timestamp with time zone, created_at timestamp with time zone)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    RETURN QUERY
        SELECT a.attempt_id, a.attempt_number, a.idempotency_key, a.claim_nonce,
               a.executor_identity, a.status,
               COALESCE(r.result_payload, a.result_payload),
               COALESCE(r.result_hash, a.result_hash),
               a.started_at, a.completed_at, a.created_at
          FROM public.mb13_p3_action_pack_attempt a
          LEFT JOIN public.mb13_p3_action_pack_result r
                 ON r.attempt_id = a.attempt_id AND r.owner_user_id = a.owner_user_id
         WHERE a.pack_id = p_pack_id
           AND a.owner_user_id = p_owner_user_id
         ORDER BY a.created_at DESC;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_get_action_pack_timeline(p_owner_user_id uuid, p_pack_id uuid, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0)
 RETURNS TABLE(timeline_event_id uuid, event_kind text, from_state text, to_state text, event_time timestamp with time zone, event_payload jsonb, payload_hash text, monitor_revision integer, policy_hash text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    RETURN QUERY
        SELECT t.timeline_event_id, t.event_kind, t.from_state, t.to_state,
               t.event_time, t.event_payload, t.payload_hash, t.monitor_revision, t.policy_hash
          FROM public.mb13_p3_action_pack_timeline t
         WHERE t.pack_id = p_pack_id
           AND t.owner_user_id = p_owner_user_id
         ORDER BY t.event_time DESC, t.timeline_event_id DESC
         LIMIT p_limit OFFSET p_offset;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_get_active_authorization(p_owner_user_id uuid, p_pack_id uuid, p_pack_payload_hash text, p_pack_revision integer, p_action_type text, p_target_ref_hash text, p_consent_hash text, p_provenance_hash text, p_monitor_revision integer)
 RETURNS mb13_p3_action_pack_authorization
 LANGUAGE plpgsql
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
BEGIN
    SELECT * INTO v_auth
      FROM public.mb13_p3_action_pack_authorization
     WHERE owner_user_id = p_owner_user_id
       AND pack_id = p_pack_id
       AND revoked = false
       AND expires_at > v_now
     ORDER BY authorized_at DESC, auth_id DESC
     LIMIT 1
     FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_authorization_invalid';
    END IF;

    IF v_auth.pack_revision IS DISTINCT FROM p_pack_revision
       OR v_auth.pack_payload_hash IS DISTINCT FROM p_pack_payload_hash
       OR v_auth.monitor_revision IS DISTINCT FROM p_monitor_revision
       OR v_auth.action_type IS DISTINCT FROM p_action_type
       OR v_auth.target_ref_hash IS DISTINCT FROM p_target_ref_hash
       OR v_auth.consent_hash IS DISTINCT FROM p_consent_hash
       OR v_auth.provenance_hash IS DISTINCT FROM p_provenance_hash THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_authorization_invalid';
    END IF;

    RETURN v_auth;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_get_covered_step_consents(p_pack mb13_p3_action_pack, p_evidence_payload jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_step_consents JSONB := '[]'::jsonb;
    v_n INTEGER;
    v_failed_step INTEGER;
    v_step JSONB;
    v_covered JSONB;
BEGIN
    v_covered := COALESCE(p_evidence_payload->'covered_steps', '[]'::jsonb);
    IF jsonb_typeof(v_covered) = 'array' THEN
        FOR v_n IN SELECT NULLIF(jt.value, '')::INTEGER FROM jsonb_array_elements_text(v_covered) AS jt(value) LOOP
            IF v_n IS NULL THEN
                CONTINUE;
            END IF;
            SELECT s INTO v_step
              FROM jsonb_array_elements(COALESCE(p_pack.steps, '[]'::jsonb)) s
             WHERE NULLIF(s->>'step_number', '')::INTEGER = v_n
             LIMIT 1;
            IF v_step IS NOT NULL AND jsonb_typeof(v_step->'consent_refs') = 'array' THEN
                v_step_consents := v_step_consents || (v_step->'consent_refs');
            END IF;
        END LOOP;
    END IF;

    IF p_evidence_payload ? 'failed_step' THEN
        BEGIN
            v_failed_step := NULLIF(p_evidence_payload->>'failed_step', '')::INTEGER;
        EXCEPTION WHEN OTHERS THEN
            v_failed_step := NULL;
        END;
        IF v_failed_step IS NOT NULL THEN
            SELECT s INTO v_step
              FROM jsonb_array_elements(COALESCE(p_pack.steps, '[]'::jsonb)) s
             WHERE NULLIF(s->>'step_number', '')::INTEGER = v_failed_step
             LIMIT 1;
            IF v_step IS NOT NULL AND jsonb_typeof(v_step->'consent_refs') = 'array' THEN
                v_step_consents := v_step_consents || (v_step->'consent_refs');
            END IF;
        END IF;
    END IF;

    RETURN v_step_consents;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_get_monitor_policy_hash(p_owner_user_id uuid, p_monitor_id uuid, p_monitor_revision integer)
 RETURNS text
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_policy JSONB;
BEGIN
    SELECT monitor_policy INTO v_policy
      FROM public.mb13_p0_monitor_target_revision
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = p_monitor_id
       AND revision = p_monitor_revision;
    IF FOUND THEN
        RETURN public.mb13_p0_hash_jsonb(v_policy);
    END IF;

    SELECT monitor_policy INTO v_policy
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = p_monitor_id
       AND current_revision = p_monitor_revision;
    IF FOUND THEN
        RETURN public.mb13_p0_hash_jsonb(v_policy);
    END IF;

    RETURN NULL;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_list_action_packs(p_owner_user_id uuid, p_status text DEFAULT NULL::text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0)
 RETURNS TABLE(pack_id uuid, owner_user_id uuid, monitor_id uuid, monitor_revision integer, trigger_event_id uuid, diff_result_id uuid, pack_revision integer, payload_hash text, action_type text, target_ref jsonb, consent_refs jsonb, provenance_refs jsonb, steps jsonb, expires_at timestamp with time zone, idempotency_key text, status text, claimed_attempt_id uuid, created_at timestamp with time zone, updated_at timestamp with time zone, monitor_policy_hash text, provenance_state text, legacy_idempotency_unverified boolean, legacy_idempotency_quarantined boolean, legacy_idempotency_quarantine_reason text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    RETURN QUERY
        SELECT * FROM public.mb13_p3_action_pack ap
        WHERE ap.owner_user_id = p_owner_user_id
          AND (p_status IS NULL OR ap.status = p_status)
        ORDER BY ap.created_at DESC
        LIMIT p_limit OFFSET p_offset;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_record_execution_evidence(p_owner_user_id uuid, p_pack_id uuid, p_attempt_id uuid, p_attempt_number integer, p_evidence_type text, p_evidence_payload jsonb, p_idempotency_key text)
 RETURNS TABLE(evidence_id uuid, receipt_id uuid, evidence_hash text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_executor_identity TEXT := session_user;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_canonical_payload JSONB;
    v_evidence_hash TEXT;
    v_request_hash TEXT;
    v_receipt_id UUID;
    v_new_id UUID;
    v_existing public.mb13_p3_action_pack_evidence%ROWTYPE;
    v_step_consents JSONB := '[]'::jsonb;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    IF p_idempotency_key IS NULL OR p_idempotency_key = '' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_idempotency_key_required';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.attempt_number IS DISTINCT FROM p_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;
    IF v_attempt.executor_identity IS DISTINCT FROM v_executor_identity THEN
        RAISE EXCEPTION 'mb13_p3_executor_identity_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.provenance_state IS DISTINCT FROM 'verified' THEN
        RAISE EXCEPTION 'mb13_p3_pack_provenance_unverified';
    END IF;

    v_canonical_payload := public.mb13_p3_canonicalize_evidence_payload(v_pack, p_evidence_type, p_evidence_payload);

    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'pack_id', p_pack_id,
        'pack_revision', v_pack.pack_revision,
        'attempt_id', p_attempt_id,
        'attempt_number', p_attempt_number,
        'monitor_revision', v_monitor.current_revision,
        'executor_identity', v_executor_identity,
        'evidence_type', p_evidence_type,
        'schema_version', v_canonical_payload->>'schema_version',
        'evidence_payload', v_canonical_payload
    ));

    SELECT * INTO v_existing
      FROM public.mb13_p3_action_pack_evidence
     WHERE owner_user_id = p_owner_user_id
       AND attempt_id = p_attempt_id
       AND idempotency_key = p_idempotency_key
     FOR UPDATE;
    IF FOUND THEN
        IF v_existing.pack_id IS DISTINCT FROM p_pack_id
           OR v_existing.evidence_type IS DISTINCT FROM p_evidence_type
           OR v_existing.attempt_number IS DISTINCT FROM p_attempt_number
           OR v_existing.executor_identity IS DISTINCT FROM v_executor_identity
           OR v_existing.evidence_payload IS DISTINCT FROM v_canonical_payload
           OR v_existing.evidence_state IS DISTINCT FROM 'active' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_idempotency_conflict';
        END IF;

        IF v_pack.status IS DISTINCT FROM 'executing' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
        END IF;
        IF v_attempt.status IS DISTINCT FROM 'executing' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
        END IF;
        IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
            RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
        END IF;
        IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
            RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
        END IF;

        PERFORM public.mb13_p3_validate_trigger_diff(
            p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
            v_pack.trigger_event_id, v_pack.diff_result_id
        );

        v_auth := public.mb13_p3_get_active_authorization(
            p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
            v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
            public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
            public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
            v_monitor.current_revision
        );

        v_step_consents := public.mb13_p3_get_covered_step_consents(v_pack, v_canonical_payload);

        PERFORM public.mb13_p3_validate_source_grant_chain(
            p_owner_user_id, v_monitor, v_pack.consent_refs, v_pack.provenance_refs, v_step_consents
        );

        RETURN QUERY SELECT v_existing.evidence_id, v_existing.receipt_id, v_existing.evidence_hash;
        RETURN;
    END IF;

    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;
    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;
    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    v_step_consents := public.mb13_p3_get_covered_step_consents(v_pack, v_canonical_payload);

    PERFORM public.mb13_p3_validate_source_grant_chain(
        p_owner_user_id, v_monitor, v_pack.consent_refs, v_pack.provenance_refs, v_step_consents
    );

    v_evidence_hash := public.mb13_p0_hash_jsonb(v_canonical_payload);
    v_receipt_id := gen_random_uuid();

    INSERT INTO public.mb13_p3_action_pack_evidence (
        owner_user_id, pack_id, attempt_id, attempt_number, pack_revision, monitor_revision,
        executor_identity, evidence_type, evidence_hash, receipt_id, evidence_payload,
        evidence_schema_version, idempotency_key, evidence_request_hash, evidence_state, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, p_attempt_number, v_pack.pack_revision,
        v_monitor.current_revision, v_executor_identity, p_evidence_type, v_evidence_hash,
        v_receipt_id, v_canonical_payload, 'mb13-p3-evidence/v1', p_idempotency_key,
        v_request_hash, 'active', v_now
    )
    ON CONFLICT ON CONSTRAINT uq_mb13_p3_evidence_owner_attempt_idempotency DO NOTHING
    RETURNING public.mb13_p3_action_pack_evidence.evidence_id INTO v_new_id;

    IF v_new_id IS NULL THEN
        SELECT * INTO v_existing
          FROM public.mb13_p3_action_pack_evidence
         WHERE owner_user_id = p_owner_user_id
           AND attempt_id = p_attempt_id
           AND idempotency_key = p_idempotency_key
         FOR UPDATE;
        IF FOUND THEN
            IF v_existing.pack_id IS DISTINCT FROM p_pack_id
               OR v_existing.evidence_type IS DISTINCT FROM p_evidence_type
               OR v_existing.attempt_number IS DISTINCT FROM p_attempt_number
               OR v_existing.executor_identity IS DISTINCT FROM v_executor_identity
               OR v_existing.evidence_payload IS DISTINCT FROM v_canonical_payload
               OR v_existing.evidence_state IS DISTINCT FROM 'active' THEN
                RAISE EXCEPTION 'mb13_p3_evidence_idempotency_conflict';
            END IF;
            IF v_pack.status IS DISTINCT FROM 'executing' OR v_attempt.status IS DISTINCT FROM 'executing' THEN
                RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
            END IF;
            RETURN QUERY SELECT v_existing.evidence_id, v_existing.receipt_id, v_existing.evidence_hash;
            RETURN;
        END IF;
        RAISE EXCEPTION 'mb13_p3_evidence_insert_failed';
    END IF;

    RETURN QUERY SELECT v_new_id, v_receipt_id, v_evidence_hash;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_revise_action_pack(
    p_owner_user_id uuid,
    p_pack_id uuid,
    p_action_type text,
    p_target_ref jsonb,
    p_consent_refs jsonb,
    p_provenance_refs jsonb,
    p_steps jsonb,
    p_expires_at timestamp with time zone,
    p_idempotency_key text DEFAULT NULL::text
) RETURNS TABLE(
    pack_id uuid, owner_user_id uuid, monitor_id uuid, monitor_revision integer, trigger_event_id uuid, diff_result_id uuid,
    pack_revision integer, payload_hash text, action_type text, target_ref jsonb, consent_refs jsonb, provenance_refs jsonb,
    steps jsonb, expires_at timestamp with time zone, idempotency_key text, status text, claimed_attempt_id uuid,
    created_at timestamp with time zone, updated_at timestamp with time zone, monitor_policy_hash text, provenance_state text,
    legacy_idempotency_unverified boolean, legacy_idempotency_quarantined boolean, legacy_idempotency_quarantine_reason text
) LANGUAGE plpgsql SECURITY DEFINER
SET search_path TO 'pg_catalog', 'public'
AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_revision public.mb13_p3_action_pack_revision%ROWTYPE;
    v_historical_revision public.mb13_p3_action_pack_revision%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_new_revision INTEGER;
    v_payload_hash TEXT;
    v_policy_hash TEXT;
    v_old_status TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
    v_new_idempotency_key TEXT;
    v_new_legacy BOOLEAN;
    v_existing_pack public.mb13_p3_action_pack%ROWTYPE;
    v_historical_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status IN ('claimed','executing','completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_cannot_revise';
    END IF;

    IF v_pack.legacy_idempotency_quarantined THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_quarantined_cannot_revise';
    END IF;

    IF v_pack.legacy_idempotency_unverified THEN
        -- Governed legacy upgrade: validate the entire historical pack/revision snapshot first.
        IF p_idempotency_key IS NULL OR length(trim(p_idempotency_key)) = 0 THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_key_required';
        END IF;

        -- Load the historical revision that the pack claims to be at.
        SELECT * INTO v_historical_revision
          FROM public.mb13_p3_action_pack_revision
         WHERE pack_id = p_pack_id
           AND revision = v_pack.pack_revision;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_revision_not_found';
        END IF;

        -- Exact canonical projection between pack and revision.
        IF v_pack.owner_user_id IS DISTINCT FROM v_historical_revision.owner_user_id
           OR v_pack.pack_id IS DISTINCT FROM v_historical_revision.pack_id
           OR v_pack.pack_revision IS DISTINCT FROM v_historical_revision.revision
           OR v_pack.monitor_revision IS DISTINCT FROM v_historical_revision.monitor_revision
           OR v_pack.trigger_event_id IS DISTINCT FROM v_historical_revision.trigger_event_id
           OR v_pack.diff_result_id IS DISTINCT FROM v_historical_revision.diff_result_id
           OR v_pack.payload_hash IS DISTINCT FROM v_historical_revision.payload_hash
           OR v_pack.action_type IS DISTINCT FROM v_historical_revision.action_type
           OR v_pack.target_ref IS DISTINCT FROM v_historical_revision.target_ref
           OR v_pack.consent_refs IS DISTINCT FROM v_historical_revision.consent_refs
           OR v_pack.provenance_refs IS DISTINCT FROM v_historical_revision.provenance_refs
           OR v_pack.steps IS DISTINCT FROM v_historical_revision.steps
           OR v_pack.expires_at IS DISTINCT FROM v_historical_revision.expires_at
           OR v_pack.idempotency_key IS DISTINCT FROM v_historical_revision.idempotency_key
           OR v_pack.legacy_idempotency_unverified IS DISTINCT FROM v_historical_revision.legacy_idempotency_unverified
        THEN
            RAISE EXCEPTION 'mb13_p3_legacy_upgrade_pack_revision_mismatch';
        END IF;

        -- Historical payload hash must be coherent with the original (NULL idempotency key) payload.
        v_historical_hash := public.mb13_p3_action_pack_payload_hash(
            v_historical_revision.owner_user_id, v_pack.monitor_id, v_historical_revision.monitor_revision,
            v_historical_revision.trigger_event_id, v_historical_revision.diff_result_id, v_historical_revision.action_type,
            v_historical_revision.target_ref, v_historical_revision.consent_refs, v_historical_revision.provenance_refs, v_historical_revision.steps,
            v_historical_revision.expires_at, NULL, v_historical_revision.status
        );
        IF v_historical_hash IS DISTINCT FROM v_historical_revision.payload_hash
           OR v_historical_hash IS DISTINCT FROM v_pack.payload_hash THEN
            RAISE EXCEPTION 'mb13_p3_legacy_upgrade_payload_hash_mismatch';
        END IF;

        -- Trigger/diff must still be valid at the historical monitor revision.
        PERFORM public.mb13_p3_validate_trigger_diff(
            p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
            v_pack.trigger_event_id, v_pack.diff_result_id
        );

        -- If monitor has advanced, require an explicit rebase/revision; refuse silent upgrade.
        IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
            RAISE EXCEPTION 'mb13_p3_legacy_upgrade_monitor_advanced';
        END IF;

        IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
        END IF;

        IF v_pack.provenance_state IS DISTINCT FROM 'verified' THEN
            RAISE EXCEPTION 'mb13_p3_pack_provenance_unverified';
        END IF;

        -- Owner-scoped uniqueness of the new idempotency key.
        SELECT * INTO v_existing_pack
          FROM public.mb13_p3_action_pack
         WHERE owner_user_id = p_owner_user_id
           AND idempotency_key = p_idempotency_key;
        IF FOUND THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;

        v_new_idempotency_key := p_idempotency_key;
        v_new_legacy := FALSE;
    ELSE
        IF p_idempotency_key IS NOT NULL AND length(trim(p_idempotency_key)) > 0
           AND p_idempotency_key IS DISTINCT FROM v_pack.idempotency_key THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_key_immutable';
        END IF;
        PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);
        v_new_idempotency_key := v_pack.idempotency_key;
        v_new_legacy := v_pack.legacy_idempotency_unverified;
    END IF;

    IF p_expires_at IS NOT NULL AND p_expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF p_action_type NOT IN ('simulate','internal') THEN
        RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
    END IF;

    PERFORM public.mb13_p3_validate_steps(p_owner_user_id, COALESCE(p_steps, '[]'::jsonb));

    v_old_status := v_pack.status;
    v_new_revision := v_pack.pack_revision + 1;
    v_payload_hash := public.mb13_p3_action_pack_payload_hash(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id, p_action_type,
        p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
        p_expires_at, v_new_idempotency_key, 'proposed'
    );
    v_policy_hash := COALESCE(public.mb13_p3_get_monitor_policy_hash(v_pack.owner_user_id, v_pack.monitor_id, v_pack.monitor_revision), public.mb13_p0_hash_jsonb(v_monitor.monitor_policy));

    PERFORM set_config('app.mb13_p3_authorized_pack_mutation', 'true', true);
    PERFORM set_config('app.mb13_p3_authorized_pack_mutation', 'true', true);
    UPDATE public.mb13_p3_action_pack
       SET pack_revision = v_new_revision,
           payload_hash = v_payload_hash,
           action_type = p_action_type,
           target_ref = COALESCE(p_target_ref, '{}'::jsonb),
           consent_refs = COALESCE(p_consent_refs, '[]'::jsonb),
           provenance_refs = COALESCE(p_provenance_refs, '[]'::jsonb),
           steps = COALESCE(p_steps, '[]'::jsonb),
           expires_at = p_expires_at,
           idempotency_key = v_new_idempotency_key,
           legacy_idempotency_unverified = v_new_legacy,
           legacy_idempotency_quarantined = FALSE,
           legacy_idempotency_quarantine_reason = NULL,
           status = 'proposed',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_old_status, 'proposed',
            v_now, jsonb_build_object('pack_revision', v_new_revision, 'reason', 'revise'),
            v_pack.monitor_revision, v_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    INSERT INTO public.mb13_p3_action_pack_revision (
        owner_user_id, pack_id, revision, monitor_revision, trigger_event_id, diff_result_id,
        payload_hash, action_type, target_ref, consent_refs, provenance_refs, steps,
        expires_at, idempotency_key, status, created_at, legacy_idempotency_unverified,
        legacy_idempotency_quarantined, legacy_idempotency_quarantine_reason
    ) VALUES (
        p_owner_user_id, p_pack_id, v_new_revision, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id, v_payload_hash, p_action_type,
        COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, v_new_idempotency_key, 'proposed', v_now, v_new_legacy,
        FALSE, NULL
    );

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'pack_revised', v_old_status, 'proposed',
        v_now, jsonb_build_object('pack_revision', v_new_revision),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$;



CREATE OR REPLACE FUNCTION public.mb13_p3_revoke_action_pack(p_owner_user_id uuid, p_pack_id uuid)
 RETURNS TABLE(pack_id uuid, status text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_transition_policy_hash TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.status IN ('completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_already_terminal';
    END IF;

    v_transition_policy_hash := public.mb13_p0_hash_jsonb(COALESCE(v_monitor.monitor_policy, '{}'::jsonb));

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_pack.status, 'revoked',
            v_now, jsonb_build_object(
                'pack_revision', v_pack.pack_revision,
                'pack_monitor_revision', v_pack.monitor_revision,
                'pack_policy_hash', v_pack.monitor_policy_hash,
                'transition_monitor_revision', v_monitor.current_revision,
                'transition_policy_hash', v_transition_policy_hash,
                'reason', 'revoke'
            ),
            v_monitor.current_revision, v_transition_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    -- Mandatory pack-level terminal event even when no active authorization exists.
    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'revoked', v_pack.status, 'revoked',
        v_now, jsonb_build_object(
            'pack_revision', v_pack.pack_revision,
            'pack_monitor_revision', v_pack.monitor_revision,
            'pack_policy_hash', v_pack.monitor_policy_hash,
            'transition_monitor_revision', v_monitor.current_revision,
            'transition_policy_hash', v_transition_policy_hash,
            'reason', 'revoke'
        ),
        v_monitor.current_revision, v_transition_policy_hash
    );

    PERFORM set_config('app.mb13_p3_authorized_pack_mutation', 'true', true);
    UPDATE public.mb13_p3_action_pack
       SET status = 'revoked',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    RETURN QUERY SELECT ap.pack_id, ap.status FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_start_action_pack(p_owner_user_id uuid, p_pack_id uuid, p_attempt_id uuid, p_expected_pack_revision integer)
 RETURNS TABLE(attempt_id uuid, pack_id uuid, attempt_number integer, status text, started_at timestamp with time zone)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.executor_identity IS DISTINCT FROM session_user THEN
        RAISE EXCEPTION 'mb13_p3_executor_identity_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;

    IF v_pack.status NOT IN ('claimed','executing') OR v_attempt.status IS DISTINCT FROM 'claimed' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_claimed';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    PERFORM public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    v_policy_hash := COALESCE(public.mb13_p3_get_monitor_policy_hash(v_pack.owner_user_id, v_pack.monitor_id, v_pack.monitor_revision), public.mb13_p0_hash_jsonb(v_monitor.monitor_policy));

    UPDATE public.mb13_p3_action_pack_attempt
       SET status = 'executing',
           started_at = v_now
     WHERE attempt_id = p_attempt_id;

    PERFORM set_config('app.mb13_p3_authorized_pack_mutation', 'true', true);
    UPDATE public.mb13_p3_action_pack
       SET status = 'executing',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'started', 'claimed', 'executing',
        v_now, jsonb_build_object('attempt_id', p_attempt_id, 'attempt_number', v_attempt.attempt_number),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number, 'executing'::TEXT, v_now;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_validate_action_pack_integrity(
    p_pack public.mb13_p3_action_pack
) RETURNS VOID AS $$
DECLARE
    v_revision public.mb13_p3_action_pack_revision%ROWTYPE;
    v_expected_pack_hash TEXT;
    v_expected_revision_hash TEXT;
BEGIN
    IF p_pack.legacy_idempotency_unverified OR COALESCE(p_pack.legacy_idempotency_quarantined, FALSE) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_legacy_unverified';
    END IF;

    SELECT * INTO v_revision
      FROM public.mb13_p3_action_pack_revision
     WHERE pack_id = p_pack.pack_id
       AND revision = p_pack.pack_revision;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_revision_not_found';
    END IF;

    IF p_pack.idempotency_key IS DISTINCT FROM v_revision.idempotency_key THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_idempotency_mismatch';
    END IF;

    -- pack and current revision canonical fields must be an exact projection
    IF p_pack.owner_user_id IS DISTINCT FROM v_revision.owner_user_id
       OR p_pack.monitor_revision IS DISTINCT FROM v_revision.monitor_revision
       OR p_pack.trigger_event_id IS DISTINCT FROM v_revision.trigger_event_id
       OR p_pack.diff_result_id IS DISTINCT FROM v_revision.diff_result_id
       OR p_pack.action_type IS DISTINCT FROM v_revision.action_type
       OR p_pack.target_ref IS DISTINCT FROM v_revision.target_ref
       OR p_pack.consent_refs IS DISTINCT FROM v_revision.consent_refs
       OR p_pack.provenance_refs IS DISTINCT FROM v_revision.provenance_refs
       OR p_pack.steps IS DISTINCT FROM v_revision.steps
       OR p_pack.expires_at IS DISTINCT FROM v_revision.expires_at
       OR p_pack.legacy_idempotency_unverified IS DISTINCT FROM v_revision.legacy_idempotency_unverified
       OR COALESCE(p_pack.legacy_idempotency_quarantined, FALSE) IS DISTINCT FROM COALESCE(v_revision.legacy_idempotency_quarantined, FALSE)
    THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_revision_canonical_mismatch';
    END IF;

    v_expected_pack_hash := public.mb13_p3_action_pack_payload_hash(
        p_pack.owner_user_id, p_pack.monitor_id, p_pack.monitor_revision,
        p_pack.trigger_event_id, p_pack.diff_result_id, p_pack.action_type,
        p_pack.target_ref, p_pack.consent_refs, p_pack.provenance_refs, p_pack.steps,
        p_pack.expires_at, p_pack.idempotency_key, v_revision.status
    );
    IF v_expected_pack_hash IS DISTINCT FROM p_pack.payload_hash THEN
        RAISE EXCEPTION 'mb13_p3_pack_payload_hash_mismatch';
    END IF;

    v_expected_revision_hash := public.mb13_p3_action_pack_payload_hash(
        v_revision.owner_user_id, p_pack.monitor_id, v_revision.monitor_revision,
        v_revision.trigger_event_id, v_revision.diff_result_id, v_revision.action_type,
        v_revision.target_ref, v_revision.consent_refs, v_revision.provenance_refs, v_revision.steps,
        v_revision.expires_at, v_revision.idempotency_key, v_revision.status
    );
    IF v_expected_revision_hash IS DISTINCT FROM v_revision.payload_hash THEN
        RAISE EXCEPTION 'mb13_p3_revision_payload_hash_mismatch';
    END IF;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = pg_catalog, public;



CREATE OR REPLACE FUNCTION public.mb13_p3_validate_evidence_payload_semantics(p_pack mb13_p3_action_pack, p_evidence_type text, p_evidence_payload jsonb, p_schema_version text)
 RETURNS void
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_step JSONB;
    v_step_number INTEGER;
    v_status TEXT;
    v_allowed_statuses TEXT[];
    v_details JSONB;
    v_action_result JSONB;
BEGIN
    IF p_evidence_payload IS NULL OR jsonb_typeof(p_evidence_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_payload_invalid';
    END IF;
    IF p_evidence_payload = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_payload_empty';
    END IF;

    IF p_schema_version IS DISTINCT FROM 'mb13-p3-evidence/v1' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_schema_version_not_allowed';
    END IF;

    v_status := NULLIF(p_evidence_payload->>'status', '');
    IF v_status IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_evidence_status_required';
    END IF;

    v_details := p_evidence_payload->'details';
    IF v_details IS NULL OR jsonb_typeof(v_details) <> 'object' OR v_details = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_details_required';
    END IF;

    IF (p_evidence_payload ? 'step_number') = false AND (p_evidence_payload ? 'action_result') = false THEN
        RAISE EXCEPTION 'mb13_p3_evidence_step_or_action_required';
    END IF;

    IF p_evidence_type = 'step_result' THEN
        IF (p_evidence_payload ? 'step_number') = false THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_required_for_step_result';
        END IF;
        BEGIN
            v_step_number := NULLIF(p_evidence_payload->>'step_number', '')::INTEGER;
        EXCEPTION WHEN others THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_invalid';
        END;
        IF v_step_number IS NULL OR v_step_number <= 0 THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_invalid';
        END IF;

        SELECT s INTO v_step
          FROM jsonb_array_elements(p_pack.steps) s
         WHERE (s->>'step_number')::INTEGER = v_step_number
         LIMIT 1;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_not_found';
        END IF;
        IF v_step ? 'action_type' AND v_step->>'action_type' IS DISTINCT FROM p_pack.action_type THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_action_type_mismatch';
        END IF;
        IF p_evidence_payload ? 'action_type' AND (p_evidence_payload->>'action_type') IS DISTINCT FROM v_step->>'action_type' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_payload_action_type_mismatch';
        END IF;

        v_allowed_statuses := ARRAY['ok','completed','failed','skipped'];
    ELSIF p_evidence_type IN ('simulation_receipt','internal_action_receipt') THEN
        IF (p_evidence_payload ? 'action_result') = false THEN
            RAISE EXCEPTION 'mb13_p3_evidence_action_result_required';
        END IF;
        v_action_result := p_evidence_payload->'action_result';
        IF v_action_result IS NULL OR jsonb_typeof(v_action_result) <> 'object' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_action_result_invalid';
        END IF;
        v_allowed_statuses := ARRAY['ok','completed','partial','failed'];
    ELSE
        RAISE EXCEPTION 'mb13_p3_evidence_type_not_allowed';
    END IF;

    IF NOT (v_status = ANY (v_allowed_statuses)) THEN
        RAISE EXCEPTION 'mb13_p3_evidence_status_not_allowed_for_type';
    END IF;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_validate_result_evidence(p_result_payload jsonb)
 RETURNS void
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_evidence JSONB;
    v_evidence_type TEXT;
    v_evidence_id TEXT;
    v_receipt_id TEXT;
    v_evidence_hash TEXT;
BEGIN
    IF p_result_payload IS NULL OR jsonb_typeof(p_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_payload_invalid';
    END IF;

    v_evidence := p_result_payload->'evidence';
    IF v_evidence IS NULL OR jsonb_typeof(v_evidence) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_required';
    END IF;

    v_evidence_type := NULLIF(v_evidence->>'evidence_type', '');
    v_evidence_id := NULLIF(v_evidence->>'evidence_id', '');
    v_receipt_id := NULLIF(v_evidence->>'receipt_id', '');
    v_evidence_hash := NULLIF(v_evidence->>'evidence_hash', '');

    IF v_evidence_type IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_type_required';
    END IF;
    IF v_evidence_id IS NULL AND v_receipt_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_id_required';
    END IF;
    IF v_evidence_hash IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_hash_required';
    END IF;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_validate_result_evidence(p_owner_user_id uuid, p_pack_id uuid, p_attempt_id uuid, p_result_payload jsonb)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_canonical JSONB;
BEGIN
    v_canonical := public.mb13_p3_canonicalize_result_evidence(p_owner_user_id, p_pack_id, p_attempt_id, p_result_payload);
    RETURN ((v_canonical->'evidence')->>'evidence_id')::UUID;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_validate_result_evidence(p_result_payload jsonb)
 RETURNS void
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_evidence JSONB;
    v_evidence_type TEXT;
    v_evidence_id TEXT;
    v_receipt_id TEXT;
    v_evidence_hash TEXT;
BEGIN
    IF p_result_payload IS NULL OR jsonb_typeof(p_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_payload_invalid';
    END IF;

    v_evidence := p_result_payload->'evidence';
    IF v_evidence IS NULL OR jsonb_typeof(v_evidence) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_required';
    END IF;

    v_evidence_type := NULLIF(v_evidence->>'evidence_type', '');
    v_evidence_id := NULLIF(v_evidence->>'evidence_id', '');
    v_receipt_id := NULLIF(v_evidence->>'receipt_id', '');
    v_evidence_hash := NULLIF(v_evidence->>'evidence_hash', '');

    IF v_evidence_type IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_type_required';
    END IF;
    IF v_evidence_id IS NULL AND v_receipt_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_id_required';
    END IF;
    IF v_evidence_hash IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_hash_required';
    END IF;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_validate_result_evidence(p_owner_user_id uuid, p_pack_id uuid, p_attempt_id uuid, p_result_payload jsonb)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_canonical JSONB;
BEGIN
    v_canonical := public.mb13_p3_canonicalize_result_evidence(p_owner_user_id, p_pack_id, p_attempt_id, p_result_payload);
    RETURN ((v_canonical->'evidence')->>'evidence_id')::UUID;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_validate_source_grant_chain(p_owner_user_id uuid, p_monitor mb13_p0_monitor_target, p_consent_refs jsonb, p_provenance_refs jsonb, p_step_consent_refs jsonb DEFAULT '[]'::jsonb)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_c JSONB;
    v_p JSONB;
    v_s JSONB;
    v_source_id UUID;
    v_grant_id UUID;
    v_evidence_id UUID;
    v_monitor_consent JSONB := p_monitor.consent_refs;
    v_monitor_evidence JSONB := p_monitor.evidence_refs;
    v_source_row public.authorized_memory_sources%ROWTYPE;
    v_grant_row public.authorized_memory_consent_grants%ROWTYPE;
    v_evidence_row public.authorized_memory_activity_log%ROWTYPE;
BEGIN
    IF p_consent_refs IS NULL OR jsonb_typeof(p_consent_refs) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p3_consent_refs_invalid';
    END IF;
    IF p_provenance_refs IS NULL OR jsonb_typeof(p_provenance_refs) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p3_provenance_refs_invalid';
    END IF;
    IF p_step_consent_refs IS NULL OR jsonb_typeof(p_step_consent_refs) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p3_step_consent_refs_invalid';
    END IF;

    -- step consents must be a subset of pack consent refs
    IF jsonb_array_length(p_step_consent_refs) > 0 THEN
        FOR v_s IN SELECT jsonb_array_elements(p_step_consent_refs) LOOP
            IF NOT EXISTS (
                SELECT 1 FROM jsonb_array_elements(p_consent_refs) c
                WHERE (c->>'source_id')::UUID = (v_s->>'source_id')::UUID
                  AND (c->>'grant_id')::UUID = (v_s->>'grant_id')::UUID
            ) THEN
                RAISE EXCEPTION 'mb13_p3_step_consent_not_in_pack';
            END IF;
        END LOOP;
    END IF;

    -- validate consent_refs and lock source/grant rows
    FOR v_c IN SELECT jsonb_array_elements(p_consent_refs) LOOP
        IF jsonb_typeof(v_c) <> 'object' THEN
            RAISE EXCEPTION 'mb13_p3_consent_ref_invalid';
        END IF;
        v_source_id := NULLIF(v_c->>'source_id', '')::UUID;
        v_grant_id := NULLIF(v_c->>'grant_id', '')::UUID;
        IF v_source_id IS NULL OR v_grant_id IS NULL THEN
            RAISE EXCEPTION 'mb13_p3_consent_ref_invalid';
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM jsonb_array_elements(v_monitor_consent) m
            WHERE (m->>'source_id')::UUID = v_source_id
              AND (m->>'grant_id')::UUID = v_grant_id
        ) THEN
            RAISE EXCEPTION 'mb13_p3_consent_ref_not_in_monitor';
        END IF;
        SELECT * INTO v_source_row
          FROM public.authorized_memory_sources
         WHERE id = v_source_id
           AND user_id = p_owner_user_id
         FOR SHARE;
        IF NOT FOUND OR v_source_row.status <> 'active' OR v_source_row.revoked_at IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p3_consent_source_invalid';
        END IF;
        SELECT * INTO v_grant_row
          FROM public.authorized_memory_consent_grants
         WHERE id = v_grant_id
           AND user_id = p_owner_user_id
           AND source_id = v_source_id
         FOR SHARE;
        IF NOT FOUND OR v_grant_row.status <> 'active' OR v_grant_row.revoked_at IS NOT NULL OR (v_grant_row.expires_at IS NOT NULL AND v_grant_row.expires_at <= clock_timestamp()) THEN
            RAISE EXCEPTION 'mb13_p3_consent_grant_invalid';
        END IF;
    END LOOP;

    -- validate provenance refs exact chain and lock source/grant/evidence
    FOR v_p IN SELECT jsonb_array_elements(p_provenance_refs) LOOP
        IF jsonb_typeof(v_p) <> 'object' THEN
            RAISE EXCEPTION 'mb13_p3_provenance_ref_invalid';
        END IF;
        v_source_id := NULLIF(v_p->>'source_id', '')::UUID;
        v_grant_id := NULLIF(v_p->>'grant_id', '')::UUID;
        v_evidence_id := NULLIF(v_p->>'evidence_id', '')::UUID;
        IF v_source_id IS NULL OR v_grant_id IS NULL OR v_evidence_id IS NULL THEN
            RAISE EXCEPTION 'mb13_p3_provenance_ref_invalid';
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM jsonb_array_elements(v_monitor_consent) m
            WHERE (m->>'source_id')::UUID = v_source_id
              AND (m->>'grant_id')::UUID = v_grant_id
        ) THEN
            RAISE EXCEPTION 'mb13_p3_provenance_consent_not_in_monitor';
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM jsonb_array_elements(v_monitor_evidence) m
            WHERE (m->>'evidence_ref')::UUID = v_evidence_id
        ) THEN
            RAISE EXCEPTION 'mb13_p3_provenance_evidence_not_in_monitor';
        END IF;
        SELECT * INTO v_source_row
          FROM public.authorized_memory_sources
         WHERE id = v_source_id
           AND user_id = p_owner_user_id
         FOR SHARE;
        IF NOT FOUND OR v_source_row.status <> 'active' OR v_source_row.revoked_at IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p3_provenance_source_invalid';
        END IF;
        SELECT * INTO v_grant_row
          FROM public.authorized_memory_consent_grants
         WHERE id = v_grant_id
           AND user_id = p_owner_user_id
           AND source_id = v_source_id
         FOR SHARE;
        IF NOT FOUND OR v_grant_row.status <> 'active' OR v_grant_row.revoked_at IS NOT NULL OR (v_grant_row.expires_at IS NOT NULL AND v_grant_row.expires_at <= clock_timestamp()) THEN
            RAISE EXCEPTION 'mb13_p3_provenance_grant_invalid';
        END IF;
        SELECT * INTO v_evidence_row
          FROM public.authorized_memory_activity_log
         WHERE id = v_evidence_id
           AND user_id = p_owner_user_id
           AND source_id = v_source_id
           AND grant_id = v_grant_id
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_provenance_evidence_invalid';
        END IF;
    END LOOP;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_validate_steps(p_owner_user_id uuid, p_steps jsonb)
 RETURNS void
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_elem JSONB;
    v_step_number INTEGER;
    v_prev INTEGER := 0;
    v_action TEXT;
    v_step_consent JSONB;
    v_c JSONB;
    v_source_id UUID;
    v_grant_id UUID;
BEGIN
    IF p_steps IS NULL OR jsonb_typeof(p_steps) <> 'array' OR jsonb_array_length(p_steps) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_steps_required';
    END IF;

    FOR v_elem IN SELECT jsonb_array_elements(p_steps) LOOP
        IF jsonb_typeof(v_elem) <> 'object' THEN
            RAISE EXCEPTION 'mb13_p3_step_invalid';
        END IF;

        v_step_number := NULLIF(v_elem->>'step_number', '')::INTEGER;
        IF v_step_number IS NULL OR v_step_number <= 0 THEN
            RAISE EXCEPTION 'mb13_p3_step_number_invalid';
        END IF;

        v_action := v_elem->>'action_type';
        IF v_action NOT IN ('simulate','internal') THEN
            RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
        END IF;

        IF jsonb_typeof(COALESCE(v_elem->'target_ref','{}'::jsonb)) IS DISTINCT FROM 'object' THEN
            RAISE EXCEPTION 'mb13_p3_step_target_invalid';
        END IF;

        IF jsonb_typeof(COALESCE(v_elem->'parameters','{}'::jsonb)) IS DISTINCT FROM 'object' THEN
            RAISE EXCEPTION 'mb13_p3_step_parameters_invalid';
        END IF;

        v_step_consent := COALESCE(v_elem->'consent_refs','[]'::jsonb);
        IF jsonb_typeof(v_step_consent) IS DISTINCT FROM 'array' THEN
            RAISE EXCEPTION 'mb13_p3_step_consent_refs_invalid';
        END IF;

        IF jsonb_array_length(v_step_consent) > 0 THEN
            FOR v_c IN SELECT jsonb_array_elements(v_step_consent) LOOP
                v_source_id := NULLIF(v_c->>'source_id', '')::UUID;
                v_grant_id := NULLIF(v_c->>'grant_id', '')::UUID;
                IF v_source_id IS NULL OR v_grant_id IS NULL THEN
                    RAISE EXCEPTION 'mb13_p3_step_consent_ref_invalid';
                END IF;
                IF NOT EXISTS (
                    SELECT 1 FROM public.authorized_memory_sources s
                    WHERE s.id = v_source_id
                      AND s.user_id = p_owner_user_id
                      AND s.status = 'active'
                      AND s.revoked_at IS NULL
                ) THEN
                    RAISE EXCEPTION 'mb13_p3_step_consent_source_invalid';
                END IF;
                IF NOT EXISTS (
                    SELECT 1 FROM public.authorized_memory_consent_grants g
                    WHERE g.id = v_grant_id
                      AND g.user_id = p_owner_user_id
                      AND g.source_id = v_source_id
                      AND g.status = 'active'
                      AND (g.expires_at IS NULL OR g.expires_at > clock_timestamp())
                      AND g.revoked_at IS NULL
                ) THEN
                    RAISE EXCEPTION 'mb13_p3_step_consent_grant_invalid';
                END IF;
            END LOOP;
        END IF;

        -- Non-simulate actions or any action reading/writing data require consent.
        IF jsonb_array_length(v_step_consent) = 0 THEN
            IF v_action <> 'simulate' THEN
                RAISE EXCEPTION 'mb13_p3_step_consent_required_for_non_simulate';
            END IF;
            IF COALESCE(v_elem->'target_ref','{}'::jsonb) <> '{}'::jsonb OR COALESCE(v_elem->'parameters','{}'::jsonb) <> '{}'::jsonb THEN
                RAISE EXCEPTION 'mb13_p3_step_consent_required_for_data';
            END IF;
        END IF;

        IF v_step_number <= v_prev THEN
            RAISE EXCEPTION 'mb13_p3_steps_unordered';
        END IF;
        v_prev := v_step_number;
    END LOOP;

    IF v_prev <> jsonb_array_length(p_steps) THEN
        RAISE EXCEPTION 'mb13_p3_steps_not_contiguous';
    END IF;
END;
$function$;


CREATE OR REPLACE FUNCTION public.mb13_p3_validate_trigger_diff(p_owner_user_id uuid, p_monitor_id uuid, p_monitor_revision integer, p_trigger_event_id uuid, p_diff_result_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_dummy INTEGER;
    v_old_owner TEXT := current_setting('app.owner_id', true);
BEGIN
    PERFORM set_config('app.owner_id', COALESCE(p_owner_user_id::text, ''), true);

    IF p_trigger_event_id IS NULL AND p_diff_result_id IS NULL THEN
        PERFORM set_config('app.owner_id', COALESCE(v_old_owner, ''), true);
        RAISE EXCEPTION 'mb13_p3_trigger_or_diff_required';
    END IF;

    IF p_trigger_event_id IS NOT NULL THEN
        SELECT 1 INTO v_dummy
          FROM public.mb13_p0_monitor_event_ledger
         WHERE owner_user_id = p_owner_user_id
           AND event_id = p_trigger_event_id
           AND monitor_id = p_monitor_id
           AND monitor_revision = p_monitor_revision
           AND event_status NOT IN ('superseded','failed')
         FOR SHARE;
        IF NOT FOUND THEN
            PERFORM set_config('app.owner_id', COALESCE(v_old_owner, ''), true);
            RAISE EXCEPTION 'mb13_p3_trigger_event_invalid';
        END IF;
    END IF;

    IF p_diff_result_id IS NOT NULL THEN
        SELECT 1 INTO v_dummy
          FROM public.mb13_p1_universal_diff
         WHERE owner_user_id = p_owner_user_id
           AND diff_id = p_diff_result_id
           AND monitor_id = p_monitor_id
           AND monitor_revision = p_monitor_revision
           AND diff_state NOT IN ('blocked','invalid')
         FOR SHARE;
        IF NOT FOUND THEN
            PERFORM set_config('app.owner_id', COALESCE(v_old_owner, ''), true);
            RAISE EXCEPTION 'mb13_p3_diff_result_invalid';
        END IF;
    END IF;

    PERFORM set_config('app.owner_id', COALESCE(v_old_owner, ''), true);
END;
$function$;



COMMIT;
