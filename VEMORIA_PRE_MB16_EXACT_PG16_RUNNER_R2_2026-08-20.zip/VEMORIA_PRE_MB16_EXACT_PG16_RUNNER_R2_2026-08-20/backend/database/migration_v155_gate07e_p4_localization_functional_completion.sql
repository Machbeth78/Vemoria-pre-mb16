-- Gate07E — P4 Localization functional completion
-- Static/code integration marker only. Does not claim Flutter Android, translation engine,
-- PostgreSQL or cross-language search runtime execution. Runtime pass remains false.

CREATE TABLE IF NOT EXISTS gate07e_p4_localization_functional_completion (
    id INTEGER PRIMARY KEY,
    gate TEXT NOT NULL DEFAULT 'GATE07E_P4_LOCALIZATION_FUNCTIONAL_COMPLETION',
    version TEXT NOT NULL DEFAULT 'GATE07E_P4_LOCALIZATION_FUNCTIONAL_COMPLETION_V155_2026-06-20',
    p4_vc_ids TEXT NOT NULL DEFAULT 'VC-045,VC-049,VC-047,VC-048',
    integration_state TEXT NOT NULL DEFAULT 'CODICE_INTEGRATO',
    runtime_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE,
    translation_is_derived BOOLEAN NOT NULL DEFAULT TRUE,
    original_is_authoritative BOOLEAN NOT NULL DEFAULT TRUE,
    ui_language_separate_from_operational_country BOOLEAN NOT NULL DEFAULT TRUE,
    CHECK (runtime_pass_claimed = FALSE),
    CHECK (runtime_real <> 'PASS')
);

INSERT INTO gate07e_p4_localization_functional_completion(id) VALUES (1) ON CONFLICT DO NOTHING;
