-- Gate08C — Document Understanding / Spiega documento scannerizzato
-- Runtime deferred: real OCR/camera/source-live/db writes not executed in this static gate.

CREATE TABLE IF NOT EXISTS document_understanding_registry_gate08c (
    id UUID PRIMARY KEY,
    owner_id UUID NOT NULL,
    document_ref_hash TEXT NOT NULL,
    top_class TEXT NOT NULL,
    confidence NUMERIC(5,2) NOT NULL,
    classification_status TEXT NOT NULL,
    risk_level TEXT NOT NULL,
    source_chain JSONB NOT NULL DEFAULT '[]'::jsonb,
    explanation_summary TEXT NOT NULL,
    original_authoritative BOOLEAN NOT NULL DEFAULT TRUE,
    ocr_is_derived BOOLEAN NOT NULL DEFAULT TRUE,
    runtime_executed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS document_understanding_workfile_link_gate08c (
    id UUID PRIMARY KEY,
    owner_id UUID NOT NULL,
    workfile_id UUID NOT NULL,
    document_ref_hash TEXT NOT NULL,
    append_only_checkpoint_required BOOLEAN NOT NULL DEFAULT TRUE,
    source_chain_required BOOLEAN NOT NULL DEFAULT TRUE,
    runtime_db_write_executed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS document_understanding_source_verification_gate08c (
    id UUID PRIMARY KEY,
    owner_id UUID NOT NULL,
    document_ref_hash TEXT NOT NULL,
    requires_source_atlas_reverify BOOLEAN NOT NULL DEFAULT TRUE,
    official_public_reverify_only BOOLEAN NOT NULL DEFAULT TRUE,
    authenticated_context_non_transferable BOOLEAN NOT NULL DEFAULT TRUE,
    runtime_live_fetch_executed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE document_understanding_registry_gate08c IS 'Gate08C static contract: document explanation/classification with confidence, source-chain and no fake certainty. Runtime OCR not executed.';
COMMENT ON TABLE document_understanding_workfile_link_gate08c IS 'Gate08C static contract: document understanding attaches to Active Workfile via append-only checkpoint plan.';
COMMENT ON TABLE document_understanding_source_verification_gate08c IS 'Gate08C static contract: Source Atlas public reverify plan for sensitive/uncertain documents.';
