-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- PRE-MB16 Pass 8W — short-lived authenticated Fabric LAN rendezvous.
--
-- Control-plane only: these tables store ephemeral LAN reachability metadata and
-- one-shot ticket digests. No ciphertext, envelope bytes, plaintext, filenames,
-- message bodies or raw bearer tickets may be persisted here.

CREATE TABLE IF NOT EXISTS fabric_peer_lan_presence (
    id                  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id       UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    auth_device_id      UUID        NOT NULL REFERENCES owner_device_registration(id) ON DELETE CASCADE,
    fabric_device_id    TEXT        NOT NULL,
    lan_host            INET        NOT NULL,
    lan_port            INTEGER     NOT NULL CHECK (lan_port BETWEEN 1024 AND 65535),
    registered_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at          TIMESTAMPTZ NOT NULL,
    last_seen_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (expires_at > registered_at),
    UNIQUE (owner_user_id, fabric_device_id)
);

CREATE INDEX IF NOT EXISTS idx_fabric_lan_presence_active
    ON fabric_peer_lan_presence(owner_user_id, expires_at DESC);

ALTER TABLE fabric_peer_lan_presence ENABLE ROW LEVEL SECURITY;
ALTER TABLE fabric_peer_lan_presence FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS fabric_lan_presence_select_scope ON fabric_peer_lan_presence;
CREATE POLICY fabric_lan_presence_select_scope
ON fabric_peer_lan_presence
FOR SELECT
USING (
    owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
    OR EXISTS (
        SELECT 1
        FROM chat_thread ct
        JOIN chat_partecipanti cp_me
          ON cp_me.thread_id = ct.id
         AND cp_me.user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
         AND cp_me.left_at IS NULL
        JOIN chat_partecipanti cp_peer
          ON cp_peer.thread_id = ct.id
         AND cp_peer.user_id = fabric_peer_lan_presence.owner_user_id
         AND cp_peer.left_at IS NULL
        WHERE ct.thread_type = 'direct'
          AND ct.archived_at IS NULL
          AND (
              SELECT COUNT(*)
              FROM chat_partecipanti cp_count
              WHERE cp_count.thread_id = ct.id
                AND cp_count.left_at IS NULL
          ) = 2
    )
);

DROP POLICY IF EXISTS fabric_lan_presence_insert_owner ON fabric_peer_lan_presence;
CREATE POLICY fabric_lan_presence_insert_owner
ON fabric_peer_lan_presence
FOR INSERT
WITH CHECK (
    owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
);

DROP POLICY IF EXISTS fabric_lan_presence_update_owner ON fabric_peer_lan_presence;
CREATE POLICY fabric_lan_presence_update_owner
ON fabric_peer_lan_presence
FOR UPDATE
USING (
    owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
)
WITH CHECK (
    owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
);

DROP POLICY IF EXISTS fabric_lan_presence_delete_owner ON fabric_peer_lan_presence;
CREATE POLICY fabric_lan_presence_delete_owner
ON fabric_peer_lan_presence
FOR DELETE
USING (
    owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
);

CREATE TABLE IF NOT EXISTS fabric_peer_lan_ticket (
    id                          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    thread_id                   UUID        NOT NULL REFERENCES chat_thread(id) ON DELETE CASCADE,
    sender_owner_id             UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    sender_auth_device_id       UUID        NOT NULL REFERENCES owner_device_registration(id) ON DELETE CASCADE,
    sender_fabric_device_id     TEXT        NOT NULL,
    recipient_owner_id          UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    recipient_auth_device_id    UUID        NOT NULL REFERENCES owner_device_registration(id) ON DELETE CASCADE,
    recipient_fabric_device_id  TEXT        NOT NULL,
    manifest_sha256             TEXT        NOT NULL CHECK (manifest_sha256 ~ '^[0-9a-f]{64}$'),
    ticket_hmac                 TEXT        NOT NULL CHECK (ticket_hmac ~ '^[0-9a-f]{64}$'),
    issued_at                   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at                  TIMESTAMPTZ NOT NULL,
    consumed_at                 TIMESTAMPTZ NULL,
    CHECK (sender_owner_id <> recipient_owner_id),
    CHECK (expires_at > issued_at),
    UNIQUE (ticket_hmac)
);

CREATE INDEX IF NOT EXISTS idx_fabric_lan_ticket_recipient_active
    ON fabric_peer_lan_ticket(recipient_owner_id, recipient_auth_device_id, expires_at DESC)
    WHERE consumed_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_fabric_lan_ticket_sender_recent
    ON fabric_peer_lan_ticket(sender_owner_id, issued_at DESC);

ALTER TABLE fabric_peer_lan_ticket ENABLE ROW LEVEL SECURITY;
ALTER TABLE fabric_peer_lan_ticket FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS fabric_lan_ticket_select_participant ON fabric_peer_lan_ticket;
CREATE POLICY fabric_lan_ticket_select_participant
ON fabric_peer_lan_ticket
FOR SELECT
USING (
    sender_owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
    OR recipient_owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
);

DROP POLICY IF EXISTS fabric_lan_ticket_insert_sender ON fabric_peer_lan_ticket;
CREATE POLICY fabric_lan_ticket_insert_sender
ON fabric_peer_lan_ticket
FOR INSERT
WITH CHECK (
    sender_owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
);

DROP POLICY IF EXISTS fabric_lan_ticket_update_recipient ON fabric_peer_lan_ticket;
CREATE POLICY fabric_lan_ticket_update_recipient
ON fabric_peer_lan_ticket
FOR UPDATE
USING (
    recipient_owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
)
WITH CHECK (
    recipient_owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
);

DROP POLICY IF EXISTS fabric_lan_ticket_delete_participant ON fabric_peer_lan_ticket;
CREATE POLICY fabric_lan_ticket_delete_participant
ON fabric_peer_lan_ticket
FOR DELETE
USING (
    sender_owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
    OR recipient_owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
);

COMMENT ON TABLE fabric_peer_lan_presence IS
'PRE-MB16 Pass 8W: short-lived private-LAN endpoint advertisement for an authenticated Fabric device; exact direct peers may read while active.';

COMMENT ON TABLE fabric_peer_lan_ticket IS
'PRE-MB16 Pass 8W: one-shot rendezvous authority bound to exact direct thread, sender/recipient devices and public Fabric manifest SHA-256. Stores HMAC only, never raw ticket or payload bytes.';
