-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA MB0→MB13 Chaos P0/P1 Closure — v241
-- Goals:
--   1. Server-issued executor capability tokens for MB13-P2/P3 (F-SESSION-001).
--   2. Bind execution-time authorization to current owner lock, token epoch,
--      device authority and confirmation provenance (F-REV-003, F-REV-004).

-- ============================================================================
-- 1. Executor capability token table
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.mb13_p3_executor_capability (
    capability_id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id     UUID NOT NULL,
    target_type       TEXT NOT NULL,
    target_id         UUID NOT NULL,
    operations        TEXT[] NOT NULL,
    issued_at         TIMESTAMPTZ NOT NULL,
    expires_at        TIMESTAMPTZ NOT NULL,
    revoked_at        TIMESTAMPTZ,
    capability_token  TEXT
);

ALTER TABLE public.mb13_p3_executor_capability ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p3_executor_capability FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb13_p3_executor_capability_owner_isolation ON public.mb13_p3_executor_capability;
CREATE POLICY mb13_p3_executor_capability_owner_isolation ON public.mb13_p3_executor_capability
    FOR ALL TO PUBLIC
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

ALTER TABLE public.mb13_p3_executor_capability OWNER TO mb13_p3_pack_data_owner;
GRANT SELECT, INSERT, UPDATE ON TABLE public.mb13_p3_executor_capability TO PUBLIC;


-- ============================================================================
-- 2. Extend action pack authorization with confirmation / epoch metadata
-- ============================================================================
ALTER TABLE public.mb13_p3_action_pack_authorization
    ADD COLUMN IF NOT EXISTS confirmation_evidence_id UUID,
    ADD COLUMN IF NOT EXISTS confirmation_event_id TEXT,
    ADD COLUMN IF NOT EXISTS confirmation_device_id TEXT,
    ADD COLUMN IF NOT EXISTS confirmation_device_set_epoch INTEGER,
    ADD COLUMN IF NOT EXISTS token_epoch INTEGER;


DROP FUNCTION IF EXISTS public.mb13_p3_authorize_action_pack(uuid, uuid, timestamp with time zone) CASCADE;

-- ============================================================================
-- 2.5 Security-state helper: reads owner lock, token epoch, evidence/device state.
-- Owned by the validator role so lifecycle entrypoints never need direct SELECT
-- on non-P3 tables.  RLS is enforced by setting app.owner_id.
-- ============================================================================
CREATE OR REPLACE FUNCTION public.vemoria_mb13_action_pack_security_state(
    p_owner_user_id uuid,
    p_evidence_id uuid DEFAULT NULL,
    p_device_id text DEFAULT NULL,
    p_device_set_epoch integer DEFAULT NULL
)
 RETURNS TABLE(locked boolean, token_epoch integer, evidence_event_type text, device_revoked boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_locked boolean;
    v_token_epoch integer;
    v_evidence_event_type text;
    v_device_revoked boolean := false;
    v_dummy integer;
BEGIN
    PERFORM set_config('app.owner_id', p_owner_user_id::text, true);

    SELECT COALESCE(ols.locked, false) INTO v_locked
      FROM public.owner_lock_state ols
     WHERE ols.utente_id = p_owner_user_id;

    SELECT ois.token_epoch INTO v_token_epoch
      FROM public.owner_identity_state ois
     WHERE ois.utente_id = p_owner_user_id;

    IF p_evidence_id IS NOT NULL THEN
        SELECT en.event_type INTO v_evidence_event_type
          FROM public.mb8_evidence_node en
         WHERE en.owner_user_id = p_owner_user_id
           AND en.evidence_id = p_evidence_id
         ORDER BY en.event_sequence DESC, en.created_at DESC
         LIMIT 1;
    END IF;

    IF p_device_id IS NOT NULL AND p_device_set_epoch IS NOT NULL THEN
        SELECT 1 INTO v_dummy
          FROM public.canonical_device_authority_epochs cdae
         WHERE cdae.owner_user_id = p_owner_user_id
           AND cdae.device_id = p_device_id
           AND cdae.device_status = 'revoked'
           AND cdae.device_set_epoch > p_device_set_epoch
         LIMIT 1;
        v_device_revoked := (v_dummy IS NOT NULL);
    END IF;

    locked := v_locked;
    token_epoch := COALESCE(v_token_epoch, 0);
    evidence_event_type := v_evidence_event_type;
    device_revoked := v_device_revoked;
    RETURN NEXT;
    RETURN;
END;
$function$;

ALTER FUNCTION public.vemoria_mb13_action_pack_security_state(uuid, uuid, text, integer) OWNER TO mb13_p3_validator;
REVOKE ALL ON FUNCTION public.vemoria_mb13_action_pack_security_state(uuid, uuid, text, integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.vemoria_mb13_action_pack_security_state(uuid, uuid, text, integer) TO mb13_p3_pack_lifecycle_executor, mb13_p3_validator;

GRANT SELECT ON TABLE public.owner_lock_state TO mb13_p3_validator;
GRANT SELECT ON TABLE public.owner_identity_state TO mb13_p3_validator;
GRANT SELECT ON TABLE public.mb8_evidence_node TO mb13_p3_validator;
GRANT SELECT ON TABLE public.canonical_device_authority_epochs TO mb13_p3_validator;


-- ============================================================================
-- 3. Recreate authorize with lock/epoch capture and confirmation metadata
-- ============================================================================
CREATE OR REPLACE FUNCTION public.mb13_p3_authorize_action_pack(
    p_owner_user_id uuid,
    p_pack_id uuid,
    p_expires_at timestamp with time zone DEFAULT NULL::timestamp with time zone,
    p_confirmation_evidence_id uuid DEFAULT NULL,
    p_confirmation_event_id text DEFAULT NULL,
    p_confirmation_device_id text DEFAULT NULL,
    p_confirmation_device_set_epoch integer DEFAULT NULL,
    p_token_epoch integer DEFAULT NULL
)
 RETURNS TABLE(pack_id uuid, owner_user_id uuid, status text, pack_revision integer, authorized_at timestamp with time zone, expires_at timestamp with time zone)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_auth_expires TIMESTAMPTZ;
    v_policy_hash TEXT;
    v_auth_hash TEXT;
    v_pack_payload_hash TEXT;
    v_target_ref_hash TEXT;
    v_consent_hash TEXT;
    v_provenance_hash TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
    v_locked BOOLEAN;
    v_token_epoch INTEGER;
BEGIN
    PERFORM set_config('app.owner_id', p_owner_user_id::text, true);

    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.provenance_state IS DISTINCT FROM 'verified' THEN
        RAISE EXCEPTION 'mb13_p3_pack_provenance_unverified';
    END IF;

    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.status NOT IN ('draft','proposed','awaiting_confirmation','authorized') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_cannot_authorize';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth_expires := COALESCE(p_expires_at, v_pack.expires_at, v_now + interval '1 hour');
    IF v_auth_expires <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_authorization_expired';
    END IF;

    -- Fail-closed: owner must be unlocked at authorization time.
    SELECT locked, token_epoch INTO v_locked, v_token_epoch
      FROM public.vemoria_mb13_action_pack_security_state(p_owner_user_id);
    IF v_locked THEN
        RAISE EXCEPTION 'mb13_p3_owner_locked_at_authorize';
    END IF;

    -- Capture current token epoch. If caller supplies one, it must match.
    IF p_token_epoch IS NOT NULL AND p_token_epoch IS DISTINCT FROM v_token_epoch THEN
        RAISE EXCEPTION 'mb13_p3_authorization_token_epoch_mismatch';
    END IF;
    v_token_epoch := COALESCE(p_token_epoch, v_token_epoch);

    v_policy_hash := COALESCE(public.mb13_p3_get_monitor_policy_hash(v_pack.owner_user_id, v_pack.monitor_id, v_pack.monitor_revision), public.mb13_p0_hash_jsonb(v_monitor.monitor_policy));
    v_pack_payload_hash := v_pack.payload_hash;
    v_target_ref_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb));
    v_consent_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb));
    v_provenance_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb));

    v_auth_hash := public.mb13_p3_action_pack_authorization_hash(
        p_pack_id, p_owner_user_id, v_pack.pack_revision, v_pack_payload_hash,
        v_monitor.current_revision, v_pack.action_type, v_target_ref_hash,
        v_consent_hash, v_provenance_hash, v_now, v_auth_expires
    );

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_pack.status, 'authorized',
            v_now, jsonb_build_object('pack_revision', v_pack.pack_revision, 'reason', 'authorize'),
            v_pack.monitor_revision, v_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    INSERT INTO public.mb13_p3_action_pack_authorization (
        owner_user_id, pack_id, pack_revision, authorized_at, expires_at,
        auth_payload_hash, pack_payload_hash, monitor_revision, action_type,
        target_ref_hash, consent_hash, provenance_hash, authorization_hash,
        confirmation_evidence_id, confirmation_event_id, confirmation_device_id,
        confirmation_device_set_epoch, token_epoch
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.pack_revision, v_now, v_auth_expires,
        v_auth_hash, v_pack_payload_hash, v_monitor.current_revision, v_pack.action_type,
        v_target_ref_hash, v_consent_hash, v_provenance_hash, v_auth_hash,
        p_confirmation_evidence_id, p_confirmation_event_id, p_confirmation_device_id,
        p_confirmation_device_set_epoch, v_token_epoch
    );

    PERFORM set_config('app.mb13_p3_authorized_pack_mutation', 'true', true);
    UPDATE public.mb13_p3_action_pack
       SET status = 'authorized',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorized', v_pack.status, 'authorized',
        v_now, jsonb_build_object('pack_revision', v_pack.pack_revision, 'expires_at', v_auth_expires),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.owner_user_id, ap.status, ap.pack_revision, v_now, v_auth_expires
                   FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;

ALTER FUNCTION public.mb13_p3_authorize_action_pack(uuid, uuid, timestamp with time zone, uuid, text, text, integer, integer) OWNER TO mb13_p3_pack_lifecycle_executor;
REVOKE ALL ON FUNCTION public.mb13_p3_authorize_action_pack(uuid, uuid, timestamp with time zone, uuid, text, text, integer, integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_authorize_action_pack(uuid, uuid, timestamp with time zone, uuid, text, text, integer, integer) TO mb13_p3_api, mb13_p3_pack_lifecycle_executor;


-- ============================================================================
-- 4. Recreate get_active_authorization with runtime revocation re-checks
-- ============================================================================
CREATE OR REPLACE FUNCTION public.mb13_p3_get_active_authorization(
    p_owner_user_id uuid,
    p_pack_id uuid,
    p_pack_payload_hash text,
    p_pack_revision integer,
    p_action_type text,
    p_target_ref_hash text,
    p_consent_hash text,
    p_provenance_hash text,
    p_monitor_revision integer
)
 RETURNS mb13_p3_action_pack_authorization
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_current_token_epoch INTEGER;
    v_locked BOOLEAN;
    v_latest_evidence_event_type TEXT;
    v_device_revoked BOOLEAN;
BEGIN
    PERFORM set_config('app.owner_id', p_owner_user_id::text, true);

    SELECT * INTO v_auth
      FROM public.mb13_p3_action_pack_authorization
     WHERE owner_user_id = p_owner_user_id
       AND pack_id = p_pack_id
       AND revoked = false
       AND expires_at > v_now
     ORDER BY authorized_at DESC, auth_id DESC
     LIMIT 1
     FOR KEY SHARE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_authorization_invalid';
    END IF;

    IF v_auth.pack_revision IS DISTINCT FROM p_pack_revision
       OR v_auth.pack_payload_hash IS DISTINCT FROM p_pack_payload_hash
       OR v_auth.monitor_revision IS DISTINCT FROM p_monitor_revision
       OR v_auth.action_type IS DISTINCT FROM p_action_type
       OR v_auth.target_ref_hash IS DISTINCT FROM p_target_ref_hash
       OR v_auth.consent_hash IS DISTINCT FROM p_consent_hash
       OR v_auth.provenance_hash IS DISTINCT FROM p_provenance_hash THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_authorization_invalid';
    END IF;

    -- Runtime re-check: owner lock, token epoch, evidence and device state.
    SELECT locked, token_epoch, evidence_event_type, device_revoked
      INTO v_locked, v_current_token_epoch, v_latest_evidence_event_type, v_device_revoked
      FROM public.vemoria_mb13_action_pack_security_state(
          p_owner_user_id,
          v_auth.confirmation_evidence_id,
          v_auth.confirmation_device_id,
          v_auth.confirmation_device_set_epoch
      );
    IF v_locked THEN
        RAISE EXCEPTION 'mb13_p3_owner_locked';
    END IF;
    IF COALESCE(v_current_token_epoch, 0) IS DISTINCT FROM COALESCE(v_auth.token_epoch, 0) THEN
        RAISE EXCEPTION 'mb13_p3_token_epoch_changed';
    END IF;
    IF v_auth.confirmation_evidence_id IS NOT NULL THEN
        IF v_latest_evidence_event_type IS NULL OR v_latest_evidence_event_type IN ('revoked', 'superseded') THEN
            RAISE EXCEPTION 'mb13_p3_confirmation_evidence_revoked';
        END IF;
    END IF;
    IF v_auth.confirmation_device_id IS NOT NULL AND v_auth.confirmation_device_set_epoch IS NOT NULL THEN
        IF v_device_revoked THEN
            RAISE EXCEPTION 'mb13_p3_confirmation_device_revoked';
        END IF;
    END IF;

    RETURN v_auth;
END;
$function$;

ALTER FUNCTION public.mb13_p3_get_active_authorization(uuid, uuid, text, integer, text, text, text, text, integer) OWNER TO mb13_p3_pack_lifecycle_executor;
REVOKE ALL ON FUNCTION public.mb13_p3_get_active_authorization(uuid, uuid, text, integer, text, text, text, text, integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_active_authorization(uuid, uuid, text, integer, text, text, text, text, integer) TO mb13_p3_pack_lifecycle_executor;

-- Security-state helper is owned by the validator role; grants are issued above.

