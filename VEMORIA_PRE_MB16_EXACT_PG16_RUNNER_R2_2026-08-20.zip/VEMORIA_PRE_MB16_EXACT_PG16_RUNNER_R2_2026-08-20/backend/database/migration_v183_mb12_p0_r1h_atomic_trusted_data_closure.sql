-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB12-P0 R1H — Atomic handoff, trusted-data production truth, FORCE RLS and
-- SECURITY DEFINER hardening.
-- Additive, idempotent migration. Does not modify v176-v182.

BEGIN;

-- Force row-level security for the R1G tables so even the table owner is
-- isolated by app.owner_id when the session opts into RLS.
ALTER TABLE mb12_p0_governed_context FORCE ROW LEVEL SECURITY;
ALTER TABLE mb12_p0_trusted_data_value FORCE ROW LEVEL SECURITY;

-- Hardened trusted-data writer.
-- It derives the normalized value from the evidence payload; it never accepts
-- an arbitrary caller-supplied value.  The caller must prove owner, source,
-- source revision, evidence, content hash, grant and scope.
CREATE OR REPLACE FUNCTION public.mb12_p0_upsert_trusted_data_value(
    p_source_id UUID,
    p_source_revision_id UUID,
    p_evidence_id UUID,
    p_field_name TEXT,
    p_normalized_value TEXT,
    p_content_hash TEXT,
    p_grant_id UUID DEFAULT NULL,
    p_scope TEXT DEFAULT 'source'
) RETURNS VOID AS $$
DECLARE
    v_owner UUID := current_setting('app.owner_id', true)::UUID;
    v_source RECORD;
    v_item RECORD;
    v_evidence RECORD;
    v_payload JSONB;
    v_value TEXT;
    v_expected_hash TEXT;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'authenticated owner missing';
    END IF;

    SELECT user_id, status, revoked_at INTO v_source
      FROM public.authorized_memory_sources
     WHERE id = p_source_id
       AND user_id = v_owner;
    IF NOT FOUND OR v_source.status <> 'active' OR v_source.revoked_at IS NOT NULL THEN
        RAISE EXCEPTION 'source not found, cross-owner, revoked or inactive';
    END IF;

    SELECT content_hash, memory_state, deleted_at INTO v_item
      FROM public.authorized_memory_inventory_items
     WHERE id = p_source_revision_id
       AND user_id = v_owner
       AND source_id = p_source_id;
    IF NOT FOUND OR v_item.deleted_at IS NOT NULL OR v_item.memory_state = 'revoked' OR v_item.content_hash IS NULL THEN
        RAISE EXCEPTION 'source revision not found, cross-owner, revoked or invalid';
    END IF;
    v_expected_hash := v_item.content_hash;

    IF p_content_hash IS DISTINCT FROM v_expected_hash THEN
        RAISE EXCEPTION 'content_hash mismatch for field %', p_field_name;
    END IF;

    SELECT action, plane, technical_payload INTO v_evidence
      FROM public.authorized_memory_activity_log
     WHERE id = p_evidence_id
       AND user_id = v_owner
       AND source_id = p_source_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'evidence not found or cross-owner';
    END IF;
    IF v_evidence.action NOT IN ('read_metadata', 'eligibility_read', 'promote_to_canonical') THEN
        RAISE EXCEPTION 'evidence action not allowed: %', v_evidence.action;
    END IF;
    IF v_evidence.plane NOT IN ('EXISTENCE', 'MEMORY') THEN
        RAISE EXCEPTION 'evidence plane not allowed: %', v_evidence.plane;
    END IF;

    v_payload := COALESCE(v_evidence.technical_payload, '{}'::jsonb);
    IF jsonb_typeof(v_payload) <> 'object' THEN
        RAISE EXCEPTION 'evidence payload is not an object';
    END IF;

    -- For data fields, the value must be present in the evidence payload.
    IF v_payload ? 'fields' AND jsonb_typeof(v_payload->'fields') = 'object' THEN
        IF NOT (v_payload->'fields' ? p_field_name) THEN
            RAISE EXCEPTION 'field % not found in trusted evidence fields', p_field_name;
        END IF;
        v_value := v_payload->'fields'->>p_field_name;
    ELSIF p_scope LIKE 'document:%' THEN
        -- For documents the trusted normalized value is the revision hash.
        v_value := v_expected_hash;
    ELSE
        RAISE EXCEPTION 'evidence payload missing fields object for field %', p_field_name;
    END IF;

    IF p_normalized_value IS DISTINCT FROM v_value THEN
        RAISE EXCEPTION 'normalized value mismatch for field %: expected % got %', p_field_name, v_value, p_normalized_value;
    END IF;

    IF p_grant_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.authorized_memory_consent_grants
             WHERE id = p_grant_id
               AND user_id = v_owner
               AND source_id = p_source_id
               AND status = 'active'
               AND revoked_at IS NULL
               AND (expires_at IS NULL OR expires_at > NOW())
        ) THEN
            RAISE EXCEPTION 'grant not found, cross-owner, revoked or expired';
        END IF;
    END IF;

    INSERT INTO public.mb12_p0_trusted_data_value (
        owner_user_id, source_id, source_revision_id, evidence_id, field_name,
        normalized_value, content_hash, grant_id, scope
    ) VALUES (
        v_owner, p_source_id, p_source_revision_id, p_evidence_id, p_field_name,
        p_normalized_value, p_content_hash, p_grant_id, p_scope
    )
    ON CONFLICT (owner_user_id, source_id, source_revision_id, field_name) DO UPDATE SET
        evidence_id = EXCLUDED.evidence_id,
        normalized_value = EXCLUDED.normalized_value,
        content_hash = EXCLUDED.content_hash,
        grant_id = EXCLUDED.grant_id,
        scope = EXCLUDED.scope,
        created_at = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb12_p0_upsert_trusted_data_value(UUID, UUID, UUID, TEXT, TEXT, TEXT, UUID, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p0_upsert_trusted_data_value(UUID, UUID, UUID, TEXT, TEXT, TEXT, UUID, TEXT) TO mb12_p0_app;

-- The trusted-data table is only writable through the SECURITY DEFINER function.
REVOKE INSERT, UPDATE, DELETE ON public.mb12_p0_trusted_data_value FROM mb12_p0_app;
REVOKE INSERT, UPDATE, DELETE ON public.mb12_p0_trusted_data_value FROM PUBLIC;
GRANT SELECT ON public.mb12_p0_trusted_data_value TO mb12_p0_app;

-- After a source-card binding is created or refreshed, materialize its trusted
-- scalar values into mb12_p0_trusted_data_value.  The writer validates every
-- relationship and derives the value from the evidence payload, so callers
-- cannot fabricate trusted data.
CREATE OR REPLACE FUNCTION public.mb12_p0_trusted_data_from_binding()
RETURNS trigger AS $$
DECLARE
    v_payload JSONB;
    v_field TEXT;
    v_scope TEXT;
    v_fields JSONB;
BEGIN
    SELECT technical_payload INTO v_payload
      FROM public.authorized_memory_activity_log
     WHERE id = NEW.evidence_id
       AND user_id = NEW.owner_user_id
       AND source_id = NEW.source_id;
    IF NOT FOUND THEN
        RETURN NEW;
    END IF;
    IF jsonb_typeof(v_payload) <> 'object' THEN
        RETURN NEW;
    END IF;

    v_fields := v_payload->'fields';
    IF jsonb_typeof(v_fields) = 'object' THEN
        FOR v_field IN SELECT jsonb_object_keys(v_fields) LOOP
            PERFORM public.mb12_p0_upsert_trusted_data_value(
                NEW.source_id,
                NEW.source_revision_id,
                NEW.evidence_id,
                v_field,
                v_fields->>v_field,
                NEW.content_hash,
                NEW.grant_id,
                COALESCE(NEW.scope, 'source')
            );
        END LOOP;
    END IF;

    -- For document scopes, persist a single trusted row keyed by the document type.
    IF NEW.scope LIKE 'document:%' THEN
        PERFORM public.mb12_p0_upsert_trusted_data_value(
            NEW.source_id,
            NEW.source_revision_id,
            NEW.evidence_id,
            substring(NEW.scope from 10),
            NEW.content_hash,
            NEW.content_hash,
            NEW.grant_id,
            NEW.scope
        );
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_mb12_p0_trusted_data_from_binding ON public.mb12_p0_source_card_binding;
CREATE TRIGGER trg_mb12_p0_trusted_data_from_binding
    AFTER INSERT OR UPDATE ON public.mb12_p0_source_card_binding
    FOR EACH ROW EXECUTE FUNCTION public.mb12_p0_trusted_data_from_binding();

-- Governed eligibility context productive writer.  It refuses direct owner
-- forgery because it reads app.owner_id from the authenticated session and
-- validates the state machine.
CREATE OR REPLACE FUNCTION public.mb12_p0_upsert_governed_context(
    p_context_id TEXT,
    p_dossier_id TEXT,
    p_rule_set_id TEXT,
    p_subject_id TEXT,
    p_territory TEXT,
    p_state TEXT DEFAULT 'active',
    p_revoked_at TIMESTAMPTZ DEFAULT NULL
) RETURNS VOID AS $$
DECLARE
    v_owner UUID := current_setting('app.owner_id', true)::UUID;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'authenticated owner missing';
    END IF;
    IF p_state NOT IN ('active', 'revoked', 'superseded') THEN
        RAISE EXCEPTION 'invalid governed context state: %', p_state;
    END IF;
    IF p_state = 'active' AND p_revoked_at IS NOT NULL THEN
        RAISE EXCEPTION 'active context cannot have revoked_at set';
    END IF;

    INSERT INTO public.mb12_p0_governed_context (
        owner_user_id, context_id, dossier_id, rule_set_id, subject_id, territory,
        state, revoked_at, revision, created_at, updated_at
    ) VALUES (
        v_owner, p_context_id, p_dossier_id, p_rule_set_id, p_subject_id, p_territory,
        p_state, p_revoked_at,
        COALESCE((SELECT revision FROM public.mb12_p0_governed_context
                   WHERE owner_user_id = v_owner AND context_id = p_context_id), 0) + 1,
        NOW(), NOW()
    )
    ON CONFLICT (owner_user_id, context_id) DO UPDATE SET
        dossier_id = EXCLUDED.dossier_id,
        rule_set_id = EXCLUDED.rule_set_id,
        subject_id = EXCLUDED.subject_id,
        territory = EXCLUDED.territory,
        state = EXCLUDED.state,
        revoked_at = EXCLUDED.revoked_at,
        revision = EXCLUDED.revision,
        updated_at = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb12_p0_upsert_governed_context(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TIMESTAMPTZ) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p0_upsert_governed_context(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TIMESTAMPTZ) TO mb12_p0_app;

-- The governed-context table is only writable through the SECURITY DEFINER function.
REVOKE INSERT, UPDATE, DELETE ON public.mb12_p0_governed_context FROM mb12_p0_app;
REVOKE INSERT, UPDATE, DELETE ON public.mb12_p0_governed_context FROM PUBLIC;
GRANT SELECT ON public.mb12_p0_governed_context TO mb12_p0_app;

-- Re-affirm SECURITY DEFINER grants for the R1G binding functions.
REVOKE ALL ON FUNCTION public.mb12_p0_validate_source_card_binding() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p0_validate_source_card_binding() TO mb12_p0_app;

REVOKE ALL ON FUNCTION public.mb12_p0_create_source_card_binding(TEXT, UUID, UUID, UUID, TEXT, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p0_create_source_card_binding(TEXT, UUID, UUID, UUID, TEXT, UUID) TO mb12_p0_app;

COMMIT;
