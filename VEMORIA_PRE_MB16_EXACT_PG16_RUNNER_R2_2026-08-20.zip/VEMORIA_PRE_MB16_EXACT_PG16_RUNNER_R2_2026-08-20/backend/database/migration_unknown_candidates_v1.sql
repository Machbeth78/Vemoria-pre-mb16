-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V4.6 — Unknown Document Candidates
-- Tabella per l'apprendimento controllato dei documenti non riconosciuti.
-- Quando il classificatore ottiene confidenza < 0.30, il documento viene
-- salvato qui come candidato. Se un pattern simile si ripete, Vemora
-- lo segnala come "già visto" senza promuoverlo automaticamente in libreria.
--
-- CORREZIONE 2026-04-03: sostituito gen_random_uuid() (pgcrypto) con
-- uuid_generate_v4() (uuid-ossp), coerente con il resto del progetto.
-- Idempotente.

CREATE TABLE IF NOT EXISTS unknown_document_candidates (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    -- Riferimento al documento originale
    documento_id    UUID REFERENCES documenti(id) ON DELETE CASCADE,
    memoria_id      UUID REFERENCES memorie(id)   ON DELETE SET NULL,

    -- Dati OCR e classificazione tentata
    testo_ocr       TEXT,                            -- testo OCR pulito (max 2000 char)
    keyword_estratte TEXT[],                         -- keyword significative trovate nel testo
    tipo_probabile  TEXT,                            -- tipo proposto dal classificatore (es: "generico")
    confidenza      FLOAT NOT NULL DEFAULT 0.0,      -- confidenza ottenuta (< soglia)
    categoria_guess TEXT,                            -- macro-categoria da guess_macro_categoria()

    -- Fingerprint per confronto futuri
    fingerprint     TEXT,                            -- hash SHA-256 delle keyword principali
    nome_file       TEXT,                            -- nome file originale (utile per pattern)

    -- Contatore ricorrenza
    occorrenze      INTEGER NOT NULL DEFAULT 1,      -- quante volte è arrivato un pattern simile
    prima_vista_il  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ultima_vista_il TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    -- Stato del candidato
    stato           TEXT NOT NULL DEFAULT 'candidato'
                    CHECK (stato IN ('candidato', 'ricorrente', 'validato', 'scartato')),
    -- candidato   = visto 1 volta
    -- ricorrente  = visto >= 3 volte, Vemora lo segnala
    -- validato    = promosso manualmente a tipo riconosciuto (futuro admin)
    -- scartato    = escluso manualmente

    note            TEXT,                            -- note manuali (futuro admin)
    creato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index per ricerca per fingerprint (riconoscimento "già visto")
CREATE INDEX IF NOT EXISTS idx_udc_fingerprint
    ON unknown_document_candidates(fingerprint)
    WHERE stato IN ('candidato', 'ricorrente');

-- Index per ricerca per stato
CREATE INDEX IF NOT EXISTS idx_udc_stato
    ON unknown_document_candidates(stato);

-- Index per categoria_guess
CREATE INDEX IF NOT EXISTS idx_udc_categoria
    ON unknown_document_candidates(categoria_guess);

-- Index per ultima visita (pulizia vecchi candidati)
CREATE INDEX IF NOT EXISTS idx_udc_ultima_vista
    ON unknown_document_candidates(ultima_vista_il);
