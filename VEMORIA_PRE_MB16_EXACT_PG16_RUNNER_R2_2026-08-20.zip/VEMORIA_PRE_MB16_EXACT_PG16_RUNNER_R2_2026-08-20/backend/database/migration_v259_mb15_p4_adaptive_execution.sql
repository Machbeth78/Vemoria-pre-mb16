-- MB15-P4 — Adaptive Execution + Retry + Fallback + Circuit Breaker
-- Provider health (global, no owner-private data) and per-owner recovery audit.

BEGIN;

CREATE TABLE IF NOT EXISTS mb15_p4_provider_health (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider_id TEXT NOT NULL,
    operation_class TEXT NOT NULL DEFAULT '',
    failure_count INTEGER NOT NULL DEFAULT 0,
    success_count INTEGER NOT NULL DEFAULT 0,
    consecutive_failures INTEGER NOT NULL DEFAULT 0,
    consecutive_successes INTEGER NOT NULL DEFAULT 0,
    last_failure_at TIMESTAMPTZ,
    last_success_at TIMESTAMPTZ,
    circuit_state TEXT NOT NULL DEFAULT 'CLOSED',
    opened_at TIMESTAMPTZ,
    half_open_probes INTEGER NOT NULL DEFAULT 0,
    latency_ms DOUBLE PRECISION,
    metadata JSONB NOT NULL DEFAULT '{}',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (provider_id, operation_class)
);

CREATE INDEX IF NOT EXISTS idx_mb15_p4_provider_health_provider
    ON mb15_p4_provider_health(provider_id, operation_class);
CREATE INDEX IF NOT EXISTS idx_mb15_p4_provider_health_circuit
    ON mb15_p4_provider_health(circuit_state);

CREATE TABLE IF NOT EXISTS mb15_p4_recovery_audit (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    execution_id UUID,
    plan_id UUID,
    goal_type TEXT,
    attempt_number INTEGER NOT NULL DEFAULT 0,
    replan_number INTEGER NOT NULL DEFAULT 0,
    failure_class TEXT,
    recovery_action TEXT,
    chosen_provider TEXT,
    alternative_provider TEXT,
    result_state TEXT,
    query_count INTEGER NOT NULL DEFAULT 0,
    external_call_count INTEGER NOT NULL DEFAULT 0,
    latency_ms DOUBLE PRECISION,
    provenance JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mb15_p4_recovery_audit_owner
    ON mb15_p4_recovery_audit(owner_id);
CREATE INDEX IF NOT EXISTS idx_mb15_p4_recovery_audit_execution
    ON mb15_p4_recovery_audit(execution_id);
CREATE INDEX IF NOT EXISTS idx_mb15_p4_recovery_audit_created
    ON mb15_p4_recovery_audit(created_at DESC);

ALTER TABLE mb15_p4_recovery_audit ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb15_p4_recovery_audit FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb15_p4_recovery_audit_owner_isolation ON mb15_p4_recovery_audit;
CREATE POLICY mb15_p4_recovery_audit_owner_isolation ON mb15_p4_recovery_audit
    USING (owner_id = _rls_owner_uuid())
    WITH CHECK (owner_id = _rls_owner_uuid());

-- Provider health is intentionally global (no owner_id).  RLS is not enabled.
-- Access is controlled by application role privileges.

COMMIT;
