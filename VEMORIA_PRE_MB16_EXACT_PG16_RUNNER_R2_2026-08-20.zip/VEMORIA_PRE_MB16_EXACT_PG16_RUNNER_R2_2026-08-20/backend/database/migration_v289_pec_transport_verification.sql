-- Vemoria PRE-MB16 Pass 8N — explicit PEC/REM transport verification truth.
BEGIN;

ALTER TABLE email_memora
    ADD COLUMN IF NOT EXISTS pec_verification_state TEXT NOT NULL DEFAULT 'NOT_APPLICABLE',
    ADD COLUMN IF NOT EXISTS pec_verified_at TIMESTAMPTZ NULL;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'email_memora_pec_verification_state_check'
          AND conrelid = 'email_memora'::regclass
    ) THEN
        ALTER TABLE email_memora
            ADD CONSTRAINT email_memora_pec_verification_state_check
            CHECK (pec_verification_state IN (
                'NOT_APPLICABLE',
                'NOT_VERIFIED',
                'STRUCTURE_ONLY',
                'TRUST_CONFIGURATION_UNAVAILABLE',
                'TRANSPORT_SIGNATURE_TRUSTED',
                'SIGNATURE_VALIDITY_OR_TRUST_FAILED',
                'SIGNATURE_INVALID_OR_UNVERIFIABLE',
                'UNSUPPORTED_SMIME_FORMAT',
                'UNSUPPORTED_FORMAT',
                'INVALID_INPUT'
            ));
    END IF;
END $$;

UPDATE email_memora
SET pec_verification_state = 'NOT_VERIFIED'
WHERE source_kind = 'pec_candidate'
  AND pec_verification_state = 'NOT_APPLICABLE';

CREATE INDEX IF NOT EXISTS idx_email_memora_owner_pec_verification
    ON email_memora(utente_id, pec_verification_state, data_email DESC)
    WHERE source_kind = 'pec_candidate';

COMMENT ON COLUMN email_memora.pec_verification_state IS
    'Transport-signature verification only. TRANSPORT_SIGNATURE_TRUSTED never implies delivery-evidence or legal validity.';
COMMENT ON COLUMN email_memora.pec_verified_at IS
    'Time at which the transport S/MIME/CAdES signature was verified against the configured authoritative trust bundle; NULL otherwise.';

COMMIT;
