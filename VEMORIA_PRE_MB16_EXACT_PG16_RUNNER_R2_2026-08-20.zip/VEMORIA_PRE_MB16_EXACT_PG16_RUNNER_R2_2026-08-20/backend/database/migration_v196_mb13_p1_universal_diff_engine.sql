-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
--
-- MB13-P1 R1 — Universal Diff Engine.
-- Forward-only, idempotent migration. Adds diff tables and the authoritative
-- writer that records a diff and the corresponding MB13-P0 lifecycle event.

BEGIN;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p1_app') THEN
        CREATE ROLE mb13_p1_app NOLOGIN;
    END IF;
END
$$;

-- ----------------------------------------------------------------------------
-- Canonical diff tables.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.mb13_p1_universal_diff (
    owner_user_id       UUID NOT NULL,
    diff_id             UUID NOT NULL,
    monitor_id          UUID NOT NULL,
    monitor_revision    INTEGER NOT NULL,
    baseline_ref        JSONB NOT NULL,
    observation_ref     JSONB NOT NULL,
    diff_kind           TEXT NOT NULL CHECK (diff_kind IN ('structured','text')),
    diff_state          TEXT NOT NULL CHECK (diff_state IN ('computed','no_change','ambiguous','blocked','invalid')),
    summary             TEXT NOT NULL,
    change_count        INTEGER NOT NULL DEFAULT 0,
    material_change_count INTEGER NOT NULL DEFAULT 0,
    changes             JSONB NOT NULL DEFAULT '[]'::jsonb,
    source_refs         JSONB NOT NULL DEFAULT '[]'::jsonb,
    evidence_refs       JSONB NOT NULL DEFAULT '[]'::jsonb,
    consent_refs        JSONB NOT NULL DEFAULT '[]'::jsonb,
    algorithm_version   TEXT NOT NULL,
    normalization_version TEXT NOT NULL,
    payload_hash        TEXT NOT NULL,
    current_revision    INTEGER NOT NULL DEFAULT 1,
    request_payload     JSONB NOT NULL DEFAULT '{}'::jsonb,
    result_payload      JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, diff_id),
    CONSTRAINT fk_mb13_p1_diff_monitor
        FOREIGN KEY (owner_user_id, monitor_id)
        REFERENCES public.mb13_p0_monitor_target(owner_user_id, monitor_id)
        ON DELETE RESTRICT,
    CONSTRAINT ck_mb13_p1_diff_state CHECK (
        (diff_state = 'no_change' AND change_count = 0)
        OR diff_state <> 'no_change'
    ),
    CONSTRAINT ck_mb13_p1_change_count_nonnegative CHECK (change_count >= 0),
    CONSTRAINT ck_mb13_p1_material_count_nonnegative CHECK (material_change_count >= 0),
    CONSTRAINT ck_mb13_p1_material_le_change CHECK (material_change_count <= change_count),
    CONSTRAINT ck_mb13_p1_refs_arrays CHECK (
        jsonb_typeof(source_refs) = 'array'
        AND jsonb_typeof(evidence_refs) = 'array'
        AND jsonb_typeof(consent_refs) = 'array'
        AND jsonb_typeof(changes) = 'array'
    )
);

CREATE TABLE IF NOT EXISTS public.mb13_p1_universal_diff_revision (
    owner_user_id       UUID NOT NULL,
    diff_id             UUID NOT NULL,
    revision            INTEGER NOT NULL,
    monitor_revision    INTEGER NOT NULL,
    baseline_ref        JSONB NOT NULL,
    observation_ref     JSONB NOT NULL,
    diff_kind           TEXT NOT NULL,
    diff_state          TEXT NOT NULL,
    summary             TEXT NOT NULL,
    change_count        INTEGER NOT NULL DEFAULT 0,
    material_change_count INTEGER NOT NULL DEFAULT 0,
    changes             JSONB NOT NULL DEFAULT '[]'::jsonb,
    source_refs         JSONB NOT NULL DEFAULT '[]'::jsonb,
    evidence_refs       JSONB NOT NULL DEFAULT '[]'::jsonb,
    consent_refs        JSONB NOT NULL DEFAULT '[]'::jsonb,
    algorithm_version   TEXT NOT NULL,
    normalization_version TEXT NOT NULL,
    payload_hash        TEXT NOT NULL,
    request_payload     JSONB NOT NULL DEFAULT '{}'::jsonb,
    result_payload      JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, diff_id, revision),
    CONSTRAINT fk_mb13_p1_diff_revision
        FOREIGN KEY (owner_user_id, diff_id)
        REFERENCES public.mb13_p1_universal_diff(owner_user_id, diff_id)
        ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS ix_mb13_p1_diff_owner_monitor
    ON public.mb13_p1_universal_diff(owner_user_id, monitor_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_mb13_p1_diff_revision_owner_diff
    ON public.mb13_p1_universal_diff_revision(owner_user_id, diff_id, revision DESC);

-- Append-only history triggers.
CREATE OR REPLACE FUNCTION public.mb13_p1_history_immutable()
RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb13_p1_history_is_append_only';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p1_history_immutable() FROM PUBLIC;

DROP TRIGGER IF EXISTS trg_mb13_p1_revision_immutable ON public.mb13_p1_universal_diff_revision;
CREATE TRIGGER trg_mb13_p1_revision_immutable
    BEFORE UPDATE OR DELETE ON public.mb13_p1_universal_diff_revision
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p1_history_immutable();

-- RLS
ALTER TABLE public.mb13_p1_universal_diff ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p1_universal_diff FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p1_universal_diff_revision ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p1_universal_diff_revision FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb13_p1_diff_owner_isolation ON public.mb13_p1_universal_diff;
CREATE POLICY mb13_p1_diff_owner_isolation ON public.mb13_p1_universal_diff
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

DROP POLICY IF EXISTS mb13_p1_diff_revision_owner_isolation ON public.mb13_p1_universal_diff_revision;
CREATE POLICY mb13_p1_diff_revision_owner_isolation ON public.mb13_p1_universal_diff_revision
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

-- ----------------------------------------------------------------------------
-- Authoritative diff writer.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_write_diff(
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT,
    p_changes JSONB,
    p_change_count INTEGER,
    p_material_change_count INTEGER,
    p_summary TEXT,
    p_diff_state TEXT,
    p_algorithm_version TEXT,
    p_normalization_version TEXT,
    p_source_refs JSONB,
    p_evidence_refs JSONB,
    p_consent_refs JSONB,
    p_request_payload JSONB,
    p_result_payload JSONB
) RETURNS TABLE(diff_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_diff_id UUID;
    v_revision INTEGER := 1;
    v_payload_hash TEXT;
    v_event_id UUID;
    v_event_type TEXT;
    v_event_payload_hash TEXT;
    v_event_time TIMESTAMPTZ := NOW();
    v_canonical_consent_refs JSONB;
    v_canonical_source_refs JSONB;
    v_canonical_evidence_refs JSONB;
    v_canonical JSONB;
    v_event_result_payload JSONB;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'id' IS NULL OR p_observation_ref->>'revision' IS NULL OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;
    IF p_diff_state NOT IN ('computed','no_change','ambiguous','blocked','invalid') THEN
        RAISE EXCEPTION 'mb13_p1_diff_state_invalid';
    END IF;
    IF p_change_count < 0 OR p_material_change_count < 0 OR p_material_change_count > p_change_count THEN
        RAISE EXCEPTION 'mb13_p1_change_count_invalid';
    END IF;

    -- Serialize on monitor to avoid races between diff computation and revocation.
    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_monitor_id::text, 0));

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = v_owner
       AND t.monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_found';
    END IF;
    IF v_current.monitor_state <> 'active' THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;

    -- Validate baseline and observation currentness.
    PERFORM public.mb13_p0_validate_target(v_owner, v_current.target_type, v_current.target_ref, p_for_active => FALSE);
    PERFORM public.mb13_p0_validate_target(v_owner, v_current.target_type, p_observation_ref, p_for_active => FALSE);

    -- Consent must still be active and cover the baseline.
    v_canonical_consent_refs := public.mb13_p0_lock_and_verify_consents(
        v_owner, v_current.consent_refs, v_current.target_type, v_current.target_ref, p_required => TRUE
    );

    v_canonical_source_refs := public.mb13_p0_normalize_jsonb_array(v_current.source_refs);
    v_canonical_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_current.evidence_refs);

    v_diff_id := gen_random_uuid();

    v_canonical := jsonb_build_object(
        'owner_user_id', v_owner,
        'diff_id', v_diff_id,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'baseline_ref', v_current.target_ref,
        'observation_ref', p_observation_ref,
        'diff_kind', p_diff_kind,
        'diff_state', p_diff_state,
        'summary', p_summary,
        'change_count', p_change_count,
        'material_change_count', p_material_change_count,
        'changes', public.mb13_p0_normalize_jsonb_array(p_changes),
        'source_refs', v_canonical_source_refs,
        'evidence_refs', v_canonical_evidence_refs,
        'consent_refs', v_canonical_consent_refs,
        'algorithm_version', p_algorithm_version,
        'normalization_version', p_normalization_version,
        'request_payload', p_request_payload,
        'result_payload', COALESCE(p_result_payload, '{}'::jsonb)
    );
    v_payload_hash := public.mb13_p0_hash_jsonb(v_canonical);

    INSERT INTO public.mb13_p1_universal_diff (
        owner_user_id, diff_id, monitor_id, monitor_revision, baseline_ref, observation_ref,
        diff_kind, diff_state, summary, change_count, material_change_count, changes,
        source_refs, evidence_refs, consent_refs, algorithm_version, normalization_version,
        payload_hash, current_revision, request_payload, result_payload
    ) VALUES (
        v_owner, v_diff_id, p_monitor_id, v_current.current_revision, v_current.target_ref, p_observation_ref,
        p_diff_kind, p_diff_state, p_summary, p_change_count, p_material_change_count, public.mb13_p0_normalize_jsonb_array(p_changes),
        v_canonical_source_refs, v_canonical_evidence_refs, v_canonical_consent_refs,
        p_algorithm_version, p_normalization_version,
        v_payload_hash, v_revision, p_request_payload, COALESCE(p_result_payload, '{}'::jsonb)
    );

    INSERT INTO public.mb13_p1_universal_diff_revision (
        owner_user_id, diff_id, revision, monitor_revision, baseline_ref, observation_ref,
        diff_kind, diff_state, summary, change_count, material_change_count, changes,
        source_refs, evidence_refs, consent_refs, algorithm_version, normalization_version,
        payload_hash, request_payload, result_payload
    ) VALUES (
        v_owner, v_diff_id, v_revision, v_current.current_revision, v_current.target_ref, p_observation_ref,
        p_diff_kind, p_diff_state, p_summary, p_change_count, p_material_change_count, public.mb13_p0_normalize_jsonb_array(p_changes),
        v_canonical_source_refs, v_canonical_evidence_refs, v_canonical_consent_refs,
        p_algorithm_version, p_normalization_version,
        v_payload_hash, p_request_payload, COALESCE(p_result_payload, '{}'::jsonb)
    );

    -- Atomic MB13-P0 event ledger append.
    IF p_diff_state = 'no_change' THEN
        v_event_type := 'NO_CHANGE_RECORDED';
    ELSE
        v_event_type := 'CHANGE_CANDIDATE_RECORDED';
    END IF;

    v_event_id := gen_random_uuid();
    v_event_result_payload := COALESCE(p_result_payload, '{}'::jsonb) || jsonb_build_object(
        'diff_id', v_diff_id,
        'diff_revision', v_revision,
        'diff_hash', v_payload_hash,
        'diff_kind', p_diff_kind,
        'diff_state', p_diff_state,
        'change_count', p_change_count,
        'material_change_count', p_material_change_count,
        'no_auto_action', true,
        'no_auto_notification', true
    );

    v_event_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'event_id', v_event_id,
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'event_type', v_event_type,
        'event_status', 'recorded',
        'event_time', to_jsonb(v_event_time),
        'observed_ref', p_observation_ref,
        'source_refs', v_canonical_source_refs,
        'evidence_refs', v_canonical_evidence_refs,
        'consent_refs', v_canonical_consent_refs,
        'reason', NULL,
        'result_payload', v_event_result_payload
    ));

    INSERT INTO public.mb13_p0_monitor_event_ledger (
        event_id, owner_user_id, monitor_id, monitor_revision, event_type, event_status, event_time,
        observed_ref, source_refs, evidence_refs, consent_refs, reason, result_payload, payload_hash
    ) VALUES (
        v_event_id, v_owner, p_monitor_id, v_current.current_revision, v_event_type, 'recorded', v_event_time,
        p_observation_ref, v_canonical_source_refs, v_canonical_evidence_refs, v_canonical_consent_refs, NULL, v_event_result_payload, v_event_payload_hash
    );

    RETURN QUERY SELECT v_diff_id, v_revision, v_payload_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID,JSONB,TEXT,JSONB,INTEGER,INTEGER,TEXT,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB,JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_write_diff(UUID,JSONB,TEXT,JSONB,INTEGER,INTEGER,TEXT,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB,JSONB) TO mb13_p1_app;

COMMIT;
