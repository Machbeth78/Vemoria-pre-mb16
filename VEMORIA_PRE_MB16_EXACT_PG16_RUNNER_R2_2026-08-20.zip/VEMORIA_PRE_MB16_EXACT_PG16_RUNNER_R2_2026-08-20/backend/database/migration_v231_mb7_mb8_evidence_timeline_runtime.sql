-- Vemoria MB7→MB8 — Evidence graph, provenance and causal timeline runtime.
-- Additive/idempotent. Does not modify previously applied migrations.

BEGIN;

-- ------------------------------------------------------------------
-- Evidence node: append-only events for personal evidence.
-- Each row is an immutable event. The current state of an evidence_id
-- is the latest event for that (owner, evidence_id) pair.
-- ------------------------------------------------------------------
CREATE SEQUENCE IF NOT EXISTS mb8_evidence_node_seq;

CREATE TABLE IF NOT EXISTS mb8_evidence_node (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_sequence      BIGINT NOT NULL DEFAULT nextval('mb8_evidence_node_seq'),
    owner_user_id       UUID NOT NULL,
    evidence_id         UUID NOT NULL,
    operation_id        TEXT NOT NULL,
    event_type          TEXT NOT NULL DEFAULT 'created'
                        CHECK (event_type IN ('created','revoked','used_in_decision','used_in_action')),
    parent_evidence_id  UUID REFERENCES mb8_evidence_node(id) DEFERRABLE INITIALLY DEFERRED,
    source_type         TEXT,
    source_id           TEXT,
    evidence_type       TEXT NOT NULL,
    target_type         TEXT NOT NULL,
    target_id           UUID NOT NULL,
    result_id           UUID,
    payload_hash        TEXT NOT NULL,
    metadata_json       JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mb8_evidence_owner_target
    ON mb8_evidence_node(owner_user_id, target_type, target_id);
CREATE INDEX IF NOT EXISTS idx_mb8_evidence_evidence
    ON mb8_evidence_node(owner_user_id, evidence_id);
CREATE INDEX IF NOT EXISTS idx_mb8_evidence_operation
    ON mb8_evidence_node(owner_user_id, operation_id);
CREATE INDEX IF NOT EXISTS idx_mb8_evidence_created
    ON mb8_evidence_node(owner_user_id, evidence_id, event_sequence DESC, created_at DESC);

-- Uniqueness of an operation/evidence/event triplet guarantees deterministic
-- idempotency: the same logical event can only be recorded once.
CREATE UNIQUE INDEX IF NOT EXISTS ux_mb8_evidence_operation_event
    ON mb8_evidence_node(owner_user_id, operation_id, evidence_id, event_type);

-- ------------------------------------------------------------------
-- Audit log: minimal, owner-scoped, hash-based.
-- Stores event hashes and references, never raw user content.
-- ------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mb8_evidence_audit (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id   UUID NOT NULL,
    evidence_id     UUID NOT NULL,
    node_id         UUID NOT NULL REFERENCES mb8_evidence_node(id) ON DELETE CASCADE,
    operation_id    TEXT NOT NULL,
    event_type      TEXT NOT NULL
                    CHECK (event_type IN ('created','revoked','used_in_decision','used_in_action')),
    result_id       UUID,
    snapshot_hash   TEXT NOT NULL,
    metadata_json   JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mb8_audit_evidence
    ON mb8_evidence_audit(owner_user_id, evidence_id);
CREATE INDEX IF NOT EXISTS idx_mb8_audit_result
    ON mb8_evidence_audit(owner_user_id, result_id);

-- ------------------------------------------------------------------
-- Active evidence view: latest non-revoked event per evidence_id.
-- ------------------------------------------------------------------
CREATE OR REPLACE VIEW mb8_active_evidence AS
WITH latest AS (
    SELECT DISTINCT ON (owner_user_id, evidence_id) *
    FROM mb8_evidence_node
    ORDER BY owner_user_id, evidence_id, event_sequence DESC, created_at DESC
)
SELECT *
FROM latest
WHERE event_type != 'revoked';

-- ------------------------------------------------------------------
-- Row level security: owner isolation on evidence and audit.
-- ------------------------------------------------------------------
ALTER TABLE mb8_evidence_node ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb8_evidence_node FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb8_evidence_node_owner_policy ON mb8_evidence_node;
CREATE POLICY mb8_evidence_node_owner_policy ON mb8_evidence_node
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

ALTER TABLE mb8_evidence_audit ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb8_evidence_audit FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb8_evidence_audit_owner_policy ON mb8_evidence_audit;
CREATE POLICY mb8_evidence_audit_owner_policy ON mb8_evidence_audit
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

-- ------------------------------------------------------------------
-- Application roles for MB8.
-- ------------------------------------------------------------------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb8_app') THEN
        CREATE ROLE mb8_app NOLOGIN NOINHERIT NOBYPASSRLS;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb8_writer') THEN
        CREATE ROLE mb8_writer NOLOGIN NOINHERIT BYPASSRLS;
    END IF;
END $$;

GRANT USAGE ON SCHEMA public TO mb8_app;
GRANT SELECT, INSERT ON mb8_evidence_node TO mb8_app;
GRANT SELECT, INSERT ON mb8_evidence_audit TO mb8_app;

COMMIT;
