-- Vemoria Gate06 R1G - P3 User Surfaces Static Completion
-- © 2026 Devoti Massimo. Tutti i diritti riservati.
-- Static contract only: no runtime PASS, no billing/chat/UI execution.

CREATE TABLE IF NOT EXISTS gate06_r1g_p3_user_surfaces_static_contract (
    vc_id TEXT PRIMARY KEY,
    gate_version TEXT NOT NULL,
    static_completion_state TEXT NOT NULL CHECK (static_completion_state = 'STATIC_COMPLETED_RUNTIME_DEFERRED'),
    runtime_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    flutter_android_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    billing_account_runtime_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO gate06_r1g_p3_user_surfaces_static_contract
    (vc_id, gate_version, static_completion_state, runtime_real, flutter_android_real, billing_account_runtime_real)
VALUES
    ('VC-009', 'GATE06_R1G_P3_USER_SURFACES_STATIC_COMPLETION_V146_2026-06-19', 'STATIC_COMPLETED_RUNTIME_DEFERRED', 'NON_ESEGUITO', 'NON_ESEGUITO', 'NON_APPLICABILE'),
    ('VC-056', 'GATE06_R1G_P3_USER_SURFACES_STATIC_COMPLETION_V146_2026-06-19', 'STATIC_COMPLETED_RUNTIME_DEFERRED', 'NON_ESEGUITO', 'NON_ESEGUITO', 'NON_APPLICABILE'),
    ('VC-010', 'GATE06_R1G_P3_USER_SURFACES_STATIC_COMPLETION_V146_2026-06-19', 'STATIC_COMPLETED_RUNTIME_DEFERRED', 'NON_ESEGUITO', 'NON_ESEGUITO', 'NON_APPLICABILE'),
    ('VC-073', 'GATE06_R1G_P3_USER_SURFACES_STATIC_COMPLETION_V146_2026-06-19', 'STATIC_COMPLETED_RUNTIME_DEFERRED', 'NON_ESEGUITO', 'NON_ESEGUITO', 'NON_ESEGUITO'),
    ('VC-074', 'GATE06_R1G_P3_USER_SURFACES_STATIC_COMPLETION_V146_2026-06-19', 'STATIC_COMPLETED_RUNTIME_DEFERRED', 'NON_ESEGUITO', 'NON_ESEGUITO', 'NON_ESEGUITO'),
    ('VC-012', 'GATE06_R1G_P3_USER_SURFACES_STATIC_COMPLETION_V146_2026-06-19', 'STATIC_COMPLETED_RUNTIME_DEFERRED', 'NON_ESEGUITO', 'NON_ESEGUITO', 'NON_APPLICABILE')
ON CONFLICT (vc_id) DO UPDATE SET
    gate_version = EXCLUDED.gate_version,
    static_completion_state = EXCLUDED.static_completion_state,
    runtime_real = EXCLUDED.runtime_real,
    flutter_android_real = EXCLUDED.flutter_android_real,
    billing_account_runtime_real = EXCLUDED.billing_account_runtime_real;
