-- Vemoria Gate07H P7 Commercial/Distribution functional completion
-- Static/code-integrated record only. Does not claim real billing, entitlement,
-- package install, desktop companion, Android/Flutter, PostgreSQL or production runtime.

CREATE TABLE IF NOT EXISTS gate07h_p7_commercial_distribution_functional_completion (
    id BIGSERIAL PRIMARY KEY,
    vc_id TEXT NOT NULL,
    integration_state TEXT NOT NULL DEFAULT 'CODICE_INTEGRATO',
    runtime_state TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    billing_runtime_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    entitlement_runtime_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    package_install_runtime_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    desktop_companion_runtime_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE,
    owner_scope_required BOOLEAN NOT NULL DEFAULT TRUE,
    valid_title_required BOOLEAN NOT NULL DEFAULT TRUE,
    package_checksum_required BOOLEAN NOT NULL DEFAULT TRUE,
    desktop_companion_probe_required BOOLEAN NOT NULL DEFAULT TRUE,
    completed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (vc_id IN ('VC-075','VC-077','VC-089','VC-090')),
    CHECK (integration_state = 'CODICE_INTEGRATO'),
    CHECK (runtime_pass_claimed = FALSE),
    CHECK (billing_runtime_real <> 'PASS'),
    CHECK (entitlement_runtime_real <> 'PASS'),
    CHECK (package_install_runtime_real <> 'PASS'),
    CHECK (desktop_companion_runtime_real <> 'PASS')
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_gate07h_p7_functional_vc_id
    ON gate07h_p7_commercial_distribution_functional_completion(vc_id);
