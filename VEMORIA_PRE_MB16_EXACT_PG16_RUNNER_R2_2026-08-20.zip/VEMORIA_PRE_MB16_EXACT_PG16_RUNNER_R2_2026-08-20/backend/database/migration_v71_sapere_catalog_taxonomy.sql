-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V71 — metadata catalogo Sapere
-- Obiettivo:
-- 1) conservare la tassonomia canonica del catalogo (macro categoria / famiglia / sottofamiglia)
-- 2) non cambiare la logica prodotto runtime
-- 3) preparare filtri e UI future per categorie professionali/private

ALTER TABLE sapere_documenti
    ADD COLUMN IF NOT EXISTS metadata_catalogo JSONB;

ALTER TABLE sapere_contenuti
    ADD COLUMN IF NOT EXISTS metadata_catalogo JSONB;

UPDATE sapere_documenti
SET metadata_catalogo = COALESCE(metadata_catalogo, jsonb_build_object(
    'macro_category', COALESCE(NULLIF(BTRIM(settore), ''), 'generico'),
    'family', COALESCE(NULLIF(BTRIM(settore), ''), 'generico'),
    'subfamily', COALESCE(NULLIF(BTRIM(settore), ''), 'generico'),
    'audience', '[]'::jsonb,
    'related_documents', '[]'::jsonb
));

UPDATE sapere_contenuti
SET metadata_catalogo = COALESCE(metadata_catalogo, jsonb_build_object(
    'macro_category', COALESCE(NULLIF(BTRIM(settore), ''), 'generico'),
    'family', COALESCE(NULLIF(BTRIM(settore), ''), 'generico'),
    'subfamily', COALESCE(NULLIF(BTRIM(settore), ''), 'generico'),
    'audience', '[]'::jsonb,
    'related_documents', '[]'::jsonb
));

CREATE INDEX IF NOT EXISTS idx_sapere_documenti_metadata_catalogo
    ON sapere_documenti USING GIN (metadata_catalogo);

CREATE INDEX IF NOT EXISTS idx_sapere_contenuti_metadata_catalogo
    ON sapere_contenuti USING GIN (metadata_catalogo);
