-- VEMORIA Chat Macro C1 - Language Bridge static metadata
-- Runtime not executed. Adds optional translation-derived metadata without changing canonical original messages.

CREATE TABLE IF NOT EXISTS chat_message_translation_derivatives (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL,
    thread_id UUID,
    message_id UUID,
    source_language TEXT NOT NULL,
    viewer_language TEXT NOT NULL,
    operational_country TEXT NOT NULL DEFAULT 'IT',
    legal_context_country TEXT NOT NULL DEFAULT 'IT',
    original_text_hash TEXT,
    translated_text_hash TEXT,
    state TEXT NOT NULL DEFAULT 'DERIVED_TRANSLATION_NOT_CANONICAL',
    original_is_canonical BOOLEAN NOT NULL DEFAULT TRUE,
    translation_is_derived BOOLEAN NOT NULL DEFAULT TRUE,
    creates_canonical_fact BOOLEAN NOT NULL DEFAULT FALSE,
    original_always_available BOOLEAN NOT NULL DEFAULT TRUE,
    certified_translation BOOLEAN NOT NULL DEFAULT FALSE,
    requires_original_confirmation_for_sensitive_actions BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (original_is_canonical = TRUE),
    CHECK (translation_is_derived = TRUE),
    CHECK (creates_canonical_fact = FALSE),
    CHECK (original_always_available = TRUE)
);

CREATE INDEX IF NOT EXISTS idx_chat_translation_owner_thread ON chat_message_translation_derivatives(owner_id, thread_id);
CREATE INDEX IF NOT EXISTS idx_chat_translation_message ON chat_message_translation_derivatives(message_id);
