-- VEMORA — Migration v205
-- MB13-P2 — Timeline, Due-State, Reminder and Retry Infrastructure
-- forward-only, idempotent
BEGIN;

-- ----------------------------------------------------------------------------
-- Roles
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p2_writer') THEN
        CREATE ROLE mb13_p2_writer NOLOGIN BYPASSRLS;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p2_executor') THEN
        CREATE ROLE mb13_p2_executor NOLOGIN;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p2_api') THEN
        CREATE ROLE mb13_p2_api NOLOGIN;
    END IF;
END $$;

GRANT USAGE ON SCHEMA public TO mb13_p2_writer, mb13_p2_executor, mb13_p2_api;

-- ----------------------------------------------------------------------------
-- State table: canonical due-state for every monitor target
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.mb13_p2_monitor_state (
    owner_user_id UUID NOT NULL,
    monitor_id UUID NOT NULL,
    due_state TEXT NOT NULL,
    due_at TIMESTAMPTZ,
    grace_until TIMESTAMPTZ,
    next_check_at TIMESTAMPTZ,
    evaluated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    payload_hash TEXT NOT NULL,
    PRIMARY KEY (owner_user_id, monitor_id),
    CONSTRAINT fk_mb13_p2_state_target FOREIGN KEY (owner_user_id, monitor_id)
        REFERENCES public.mb13_p0_monitor_target(owner_user_id, monitor_id) ON DELETE CASCADE,
    CONSTRAINT ck_mb13_p2_due_state CHECK (due_state IN ('not_due','due','grace','expired','completed'))
);

CREATE INDEX IF NOT EXISTS ix_mb13_p2_state_owner_state
    ON public.mb13_p2_monitor_state(owner_user_id, due_state, evaluated_at DESC);
CREATE INDEX IF NOT EXISTS ix_mb13_p2_state_due_at
    ON public.mb13_p2_monitor_state(due_at) WHERE due_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_mb13_p2_state_grace_until
    ON public.mb13_p2_monitor_state(grace_until) WHERE grace_until IS NOT NULL;

-- ----------------------------------------------------------------------------
-- Timeline: append-only record of due-state, reminder and retry events
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.mb13_p2_monitor_timeline (
    timeline_event_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id UUID NOT NULL,
    monitor_id UUID NOT NULL,
    event_kind TEXT NOT NULL,
    from_state TEXT,
    to_state TEXT,
    event_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    event_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    payload_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_mb13_p2_timeline_target FOREIGN KEY (owner_user_id, monitor_id)
        REFERENCES public.mb13_p0_monitor_target(owner_user_id, monitor_id) ON DELETE CASCADE,
    CONSTRAINT ck_mb13_p2_timeline_event_kind CHECK (event_kind IN (
        'state_change','due_entered','grace_entered','expired','reminder','retry_scheduled','retry_fired','completed'
    )),
    CONSTRAINT ck_mb13_p2_timeline_payload_object CHECK (jsonb_typeof(event_payload) = 'object')
);

CREATE INDEX IF NOT EXISTS ix_mb13_p2_timeline_monitor
    ON public.mb13_p2_monitor_timeline(owner_user_id, monitor_id, event_time DESC);

-- ----------------------------------------------------------------------------
-- Reminder schedule
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.mb13_p2_reminder_schedule (
    reminder_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id UUID NOT NULL,
    monitor_id UUID NOT NULL,
    remind_at TIMESTAMPTZ NOT NULL,
    reminder_kind TEXT NOT NULL,
    channel TEXT NOT NULL DEFAULT 'in_app',
    status TEXT NOT NULL DEFAULT 'pending',
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_mb13_p2_reminder_target FOREIGN KEY (owner_user_id, monitor_id)
        REFERENCES public.mb13_p0_monitor_target(owner_user_id, monitor_id) ON DELETE CASCADE,
    CONSTRAINT ck_mb13_p2_reminder_kind CHECK (reminder_kind IN ('pre_due','due','grace','expired','custom')),
    CONSTRAINT ck_mb13_p2_reminder_channel CHECK (channel IN ('in_app','email','push','sms')),
    CONSTRAINT ck_mb13_p2_reminder_status CHECK (status IN ('pending','sent','cancelled','failed')),
    CONSTRAINT ck_mb13_p2_reminder_payload_object CHECK (jsonb_typeof(payload) = 'object')
);

CREATE INDEX IF NOT EXISTS ix_mb13_p2_reminder_status_time
    ON public.mb13_p2_reminder_schedule(owner_user_id, status, remind_at);

-- ----------------------------------------------------------------------------
-- Retry schedule
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.mb13_p2_retry_schedule (
    retry_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id UUID NOT NULL,
    monitor_id UUID NOT NULL,
    original_event_id UUID,
    retry_count INTEGER NOT NULL DEFAULT 0,
    max_retries INTEGER NOT NULL DEFAULT 3,
    next_retry_at TIMESTAMPTZ NOT NULL,
    backoff_kind TEXT NOT NULL DEFAULT 'exponential',
    status TEXT NOT NULL DEFAULT 'pending',
    last_error_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_mb13_p2_retry_target FOREIGN KEY (owner_user_id, monitor_id)
        REFERENCES public.mb13_p0_monitor_target(owner_user_id, monitor_id) ON DELETE CASCADE,
    CONSTRAINT ck_mb13_p2_retry_status CHECK (status IN ('pending','completed','expired','cancelled')),
    CONSTRAINT ck_mb13_p2_retry_backoff_kind CHECK (backoff_kind IN ('fixed','exponential','linear','none')),
    CONSTRAINT ck_mb13_p2_retry_count CHECK (retry_count >= 0 AND retry_count <= max_retries),
    CONSTRAINT ck_mb13_p2_retry_payload_object CHECK (jsonb_typeof(last_error_payload) = 'object')
);

CREATE INDEX IF NOT EXISTS ix_mb13_p2_retry_next
    ON public.mb13_p2_retry_schedule(owner_user_id, status, next_retry_at);

-- ----------------------------------------------------------------------------
-- Helper: compute the due-state for a single point in time
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_compute_due_state(
    p_due_at TIMESTAMPTZ,
    p_grace_until TIMESTAMPTZ,
    p_now TIMESTAMPTZ
) RETURNS TEXT AS $$
BEGIN
    IF p_due_at IS NULL THEN
        RETURN 'not_due';
    END IF;
    IF p_now < p_due_at THEN
        RETURN 'not_due';
    END IF;
    IF p_grace_until IS NULL THEN
        RETURN 'due';
    END IF;
    IF p_now < p_grace_until THEN
        RETURN 'grace';
    END IF;
    RETURN 'expired';
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- ----------------------------------------------------------------------------
-- Canonical hash for timeline events
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_hash_timeline_event(
    p_owner UUID,
    p_monitor_id UUID,
    p_event_kind TEXT,
    p_from_state TEXT,
    p_to_state TEXT,
    p_event_time TIMESTAMPTZ,
    p_event_payload JSONB
) RETURNS TEXT AS $$
BEGIN
    RETURN public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner,
        'monitor_id', p_monitor_id,
        'event_kind', p_event_kind,
        'from_state', p_from_state,
        'to_state', p_to_state,
        'event_time', p_event_time,
        'event_payload', COALESCE(p_event_payload, '{}'::jsonb)
    ));
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- ----------------------------------------------------------------------------
-- Evaluate and persist due-state for a monitor
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_evaluate_due_state(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_now TIMESTAMPTZ DEFAULT NOW()
) RETURNS TABLE(
    monitor_id UUID,
    due_state TEXT,
    previous_state TEXT,
    changed BOOLEAN,
    evaluated_at TIMESTAMPTZ
) AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_target public.mb13_p0_monitor_target%ROWTYPE;
    v_previous_state TEXT := NULL;
    v_new_state TEXT;
    v_payload_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    SELECT * INTO v_target
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = p_owner_user_id
       AND t.monitor_id = p_monitor_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_monitor_not_found';
    END IF;

    IF v_target.monitor_state = 'completed' THEN
        v_new_state := 'completed';
    ELSE
        v_new_state := public.mb13_p2_compute_due_state(
            (v_target.monitor_policy->>'due_at')::TIMESTAMPTZ,
            (v_target.monitor_policy->>'grace_until')::TIMESTAMPTZ,
            p_now
        );
    END IF;

    SELECT s.due_state INTO v_previous_state
      FROM public.mb13_p2_monitor_state s
     WHERE s.owner_user_id = p_owner_user_id
       AND s.monitor_id = p_monitor_id;

    v_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'monitor_id', p_monitor_id,
        'due_state', v_new_state,
        'due_at', (v_target.monitor_policy->>'due_at')::TIMESTAMPTZ,
        'grace_until', (v_target.monitor_policy->>'grace_until')::TIMESTAMPTZ,
        'next_check_at', (v_target.monitor_policy->>'next_check_at')::TIMESTAMPTZ,
        'evaluated_at', p_now
    ));

    INSERT INTO public.mb13_p2_monitor_state (
        owner_user_id, monitor_id, due_state, due_at, grace_until,
        next_check_at, evaluated_at, payload_hash
    ) VALUES (
        p_owner_user_id, p_monitor_id, v_new_state,
        (v_target.monitor_policy->>'due_at')::TIMESTAMPTZ,
        (v_target.monitor_policy->>'grace_until')::TIMESTAMPTZ,
        (v_target.monitor_policy->>'next_check_at')::TIMESTAMPTZ,
        p_now, v_payload_hash
    )
    ON CONFLICT ON CONSTRAINT mb13_p2_monitor_state_pkey DO UPDATE SET
        due_state = EXCLUDED.due_state,
        due_at = EXCLUDED.due_at,
        grace_until = EXCLUDED.grace_until,
        next_check_at = EXCLUDED.next_check_at,
        evaluated_at = EXCLUDED.evaluated_at,
        payload_hash = EXCLUDED.payload_hash;

    IF v_previous_state IS DISTINCT FROM v_new_state THEN
        INSERT INTO public.mb13_p2_monitor_timeline (
            owner_user_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, payload_hash
        ) VALUES (
            p_owner_user_id, p_monitor_id, 'state_change', v_previous_state, v_new_state,
            p_now, jsonb_build_object('evaluated_at', p_now),
            public.mb13_p2_hash_timeline_event(
                p_owner_user_id, p_monitor_id, 'state_change', v_previous_state,
                v_new_state, p_now, jsonb_build_object('evaluated_at', p_now)
            )
        );
    END IF;

    RETURN QUERY SELECT p_monitor_id, v_new_state, v_previous_state,
                        (v_previous_state IS DISTINCT FROM v_new_state), p_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_evaluate_due_state(UUID, UUID, TIMESTAMPTZ) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_evaluate_due_state(UUID, UUID, TIMESTAMPTZ) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_evaluate_due_state(UUID, UUID, TIMESTAMPTZ) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_evaluate_due_state(UUID, UUID, TIMESTAMPTZ) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Read timeline
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_get_timeline(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_limit INTEGER DEFAULT 100,
    p_offset INTEGER DEFAULT 0
) RETURNS TABLE(
    timeline_event_id UUID,
    event_kind TEXT,
    from_state TEXT,
    to_state TEXT,
    event_time TIMESTAMPTZ,
    event_payload JSONB,
    payload_hash TEXT
) AS $$
BEGIN
    IF NULLIF(current_setting('app.owner_id', true), '')::UUID IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    RETURN QUERY
    SELECT t.timeline_event_id, t.event_kind, t.from_state, t.to_state,
           t.event_time, t.event_payload, t.payload_hash
      FROM public.mb13_p2_monitor_timeline t
     WHERE t.owner_user_id = p_owner_user_id
       AND t.monitor_id = p_monitor_id
     ORDER BY t.event_time DESC, t.timeline_event_id DESC
     LIMIT p_limit OFFSET p_offset;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_get_timeline(UUID, UUID, INTEGER, INTEGER) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_get_timeline(UUID, UUID, INTEGER, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_get_timeline(UUID, UUID, INTEGER, INTEGER) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_get_timeline(UUID, UUID, INTEGER, INTEGER) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Schedule a reminder
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_schedule_reminder(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_remind_at TIMESTAMPTZ,
    p_reminder_kind TEXT,
    p_channel TEXT DEFAULT 'in_app',
    p_payload JSONB DEFAULT '{}'::jsonb
) RETURNS UUID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_reminder_id UUID := gen_random_uuid();
    v_target_owner UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;
    IF p_remind_at IS NULL OR p_remind_at <= NOW() THEN
        RAISE EXCEPTION 'mb13_p2_reminder_time_invalid';
    END IF;
    IF p_reminder_kind NOT IN ('pre_due','due','grace','expired','custom') THEN
        RAISE EXCEPTION 'mb13_p2_reminder_kind_invalid';
    END IF;
    IF p_channel NOT IN ('in_app','email','push','sms') THEN
        RAISE EXCEPTION 'mb13_p2_reminder_channel_invalid';
    END IF;

    SELECT t.owner_user_id INTO v_target_owner
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = p_owner_user_id
       AND t.monitor_id = p_monitor_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_monitor_not_found';
    END IF;

    INSERT INTO public.mb13_p2_reminder_schedule (
        reminder_id, owner_user_id, monitor_id, remind_at, reminder_kind,
        channel, status, payload
    ) VALUES (
        v_reminder_id, p_owner_user_id, p_monitor_id, p_remind_at,
        p_reminder_kind, p_channel, 'pending', COALESCE(p_payload, '{}'::jsonb)
    );

    RETURN v_reminder_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_schedule_reminder(UUID, UUID, TIMESTAMPTZ, TEXT, TEXT, JSONB) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_schedule_reminder(UUID, UUID, TIMESTAMPTZ, TEXT, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_schedule_reminder(UUID, UUID, TIMESTAMPTZ, TEXT, TEXT, JSONB) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_schedule_reminder(UUID, UUID, TIMESTAMPTZ, TEXT, TEXT, JSONB) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Fire / cancel reminder
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_fire_reminder(
    p_owner_user_id UUID,
    p_reminder_id UUID
) RETURNS TABLE(
    reminder_id UUID,
    monitor_id UUID,
    status TEXT,
    fired_at TIMESTAMPTZ
) AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_reminder public.mb13_p2_reminder_schedule%ROWTYPE;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    SELECT * INTO v_reminder
      FROM public.mb13_p2_reminder_schedule r
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id
     FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_reminder_not_found';
    END IF;
    IF v_reminder.status <> 'pending' THEN
        RAISE EXCEPTION 'mb13_p2_reminder_already_handled';
    END IF;

    UPDATE public.mb13_p2_reminder_schedule r
       SET status = 'sent'
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id;

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash
    ) VALUES (
        p_owner_user_id, v_reminder.monitor_id, 'reminder', NULL, NULL,
        NOW(), jsonb_build_object('reminder_id', p_reminder_id, 'reminder_kind', v_reminder.reminder_kind, 'channel', v_reminder.channel),
        public.mb13_p2_hash_timeline_event(
            p_owner_user_id, v_reminder.monitor_id, 'reminder', NULL, NULL,
            NOW(), jsonb_build_object('reminder_id', p_reminder_id, 'reminder_kind', v_reminder.reminder_kind, 'channel', v_reminder.channel)
        )
    );

    RETURN QUERY SELECT v_reminder.reminder_id, v_reminder.monitor_id, 'sent'::TEXT, NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_fire_reminder(UUID, UUID) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_fire_reminder(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_fire_reminder(UUID, UUID) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_fire_reminder(UUID, UUID) TO mb13_p2_executor;


CREATE OR REPLACE FUNCTION public.mb13_p2_cancel_reminder(
    p_owner_user_id UUID,
    p_reminder_id UUID
) RETURNS VOID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    UPDATE public.mb13_p2_reminder_schedule r
       SET status = 'cancelled'
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id
       AND r.status = 'pending';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_reminder_not_found_or_already_handled';
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Schedule a retry
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_schedule_retry(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_original_event_id UUID,
    p_next_retry_at TIMESTAMPTZ,
    p_max_retries INTEGER DEFAULT 3,
    p_backoff_kind TEXT DEFAULT 'exponential',
    p_last_error_payload JSONB DEFAULT '{}'::jsonb
) RETURNS UUID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_retry_id UUID := gen_random_uuid();
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;
    IF p_max_retries < 0 OR p_max_retries > 20 THEN
        RAISE EXCEPTION 'mb13_p2_retry_max_invalid';
    END IF;
    IF p_backoff_kind NOT IN ('fixed','exponential','linear','none') THEN
        RAISE EXCEPTION 'mb13_p2_retry_backoff_invalid';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.mb13_p0_monitor_target t
                    WHERE t.owner_user_id = p_owner_user_id
                      AND t.monitor_id = p_monitor_id) THEN
        RAISE EXCEPTION 'mb13_p2_monitor_not_found';
    END IF;

    INSERT INTO public.mb13_p2_retry_schedule (
        retry_id, owner_user_id, monitor_id, original_event_id, retry_count,
        max_retries, next_retry_at, backoff_kind, status, last_error_payload
    ) VALUES (
        v_retry_id, p_owner_user_id, p_monitor_id, p_original_event_id, 0,
        p_max_retries, p_next_retry_at, p_backoff_kind, 'pending', COALESCE(p_last_error_payload, '{}'::jsonb)
    );

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash
    ) VALUES (
        p_owner_user_id, p_monitor_id, 'retry_scheduled', NULL, NULL,
        NOW(), jsonb_build_object('retry_id', v_retry_id, 'max_retries', p_max_retries, 'backoff_kind', p_backoff_kind),
        public.mb13_p2_hash_timeline_event(
            p_owner_user_id, p_monitor_id, 'retry_scheduled', NULL, NULL,
            NOW(), jsonb_build_object('retry_id', v_retry_id, 'max_retries', p_max_retries, 'backoff_kind', p_backoff_kind)
        )
    );

    RETURN v_retry_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Advance retry: fire next attempt or complete / expire
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_advance_retry(
    p_owner_user_id UUID,
    p_retry_id UUID,
    p_success BOOLEAN DEFAULT FALSE
) RETURNS TABLE(
    retry_id UUID,
    monitor_id UUID,
    status TEXT,
    retry_count INTEGER,
    next_retry_at TIMESTAMPTZ
) AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_retry public.mb13_p2_retry_schedule%ROWTYPE;
    v_next_at TIMESTAMPTZ;
    v_new_count INTEGER;
    v_interval INTERVAL;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    SELECT * INTO v_retry
      FROM public.mb13_p2_retry_schedule rz
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id
     FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_retry_not_found';
    END IF;
    IF v_retry.status <> 'pending' THEN
        RAISE EXCEPTION 'mb13_p2_retry_not_pending';
    END IF;

    IF p_success THEN
        UPDATE public.mb13_p2_retry_schedule rz
           SET status = 'completed'
         WHERE rz.owner_user_id = p_owner_user_id
           AND rz.retry_id = p_retry_id;

        INSERT INTO public.mb13_p2_monitor_timeline (
            owner_user_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, payload_hash
        ) VALUES (
            p_owner_user_id, v_retry.monitor_id, 'retry_fired', NULL, 'completed',
            NOW(), jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_retry.retry_count, 'success', true),
            public.mb13_p2_hash_timeline_event(
                p_owner_user_id, v_retry.monitor_id, 'retry_fired', NULL, 'completed',
                NOW(), jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_retry.retry_count, 'success', true)
            )
        );

        RETURN QUERY SELECT p_retry_id, v_retry.monitor_id, 'completed'::TEXT, v_retry.retry_count, v_retry.next_retry_at;
        RETURN;
    END IF;

    -- Failure path: increment and reschedule unless max reached.
    v_new_count := v_retry.retry_count + 1;
    IF v_new_count >= v_retry.max_retries THEN
        UPDATE public.mb13_p2_retry_schedule rz
           SET status = 'expired'
         WHERE rz.owner_user_id = p_owner_user_id
           AND rz.retry_id = p_retry_id;

        INSERT INTO public.mb13_p2_monitor_timeline (
            owner_user_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, payload_hash
        ) VALUES (
            p_owner_user_id, v_retry.monitor_id, 'retry_fired', NULL, 'expired',
            NOW(), jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_retry.max_retries, 'success', false),
            public.mb13_p2_hash_timeline_event(
                p_owner_user_id, v_retry.monitor_id, 'retry_fired', NULL, 'expired',
                NOW(), jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_retry.max_retries, 'success', false)
            )
        );

        RETURN QUERY SELECT p_retry_id, v_retry.monitor_id, 'expired'::TEXT, v_retry.max_retries, v_retry.next_retry_at;
        RETURN;
    END IF;

    -- Compute next interval based on backoff kind and current count.
    IF v_retry.backoff_kind = 'fixed' THEN
        v_interval := '1 minute'::INTERVAL;
    ELSIF v_retry.backoff_kind = 'linear' THEN
        v_interval := (v_new_count * '1 minute'::INTERVAL);
    ELSIF v_retry.backoff_kind = 'exponential' THEN
        v_interval := (POWER(2, v_new_count)::INTEGER * '1 minute'::INTERVAL);
    ELSE
        v_interval := '0 minutes'::INTERVAL;
    END IF;

    v_next_at := v_retry.next_retry_at + v_interval;

    UPDATE public.mb13_p2_retry_schedule rz
       SET retry_count = v_new_count,
           next_retry_at = v_next_at
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id;

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash
    ) VALUES (
        p_owner_user_id, v_retry.monitor_id, 'retry_fired', NULL, 'pending',
        NOW(), jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_new_count, 'success', false, 'next_retry_at', v_next_at),
        public.mb13_p2_hash_timeline_event(
            p_owner_user_id, v_retry.monitor_id, 'retry_fired', NULL, 'pending',
            NOW(), jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_new_count, 'success', false, 'next_retry_at', v_next_at)
        )
    );

    RETURN QUERY SELECT p_retry_id, v_retry.monitor_id, 'pending'::TEXT, v_new_count, v_next_at;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Cancel retry
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_cancel_retry(
    p_owner_user_id UUID,
    p_retry_id UUID
) RETURNS VOID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    UPDATE public.mb13_p2_retry_schedule rz
       SET status = 'cancelled'
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id
       AND rz.status = 'pending';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_retry_not_found_or_not_pending';
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Grants
-- ----------------------------------------------------------------------------
GRANT EXECUTE ON FUNCTION public.mb13_p0_hash_jsonb(JSONB) TO mb13_p2_writer;
GRANT SELECT ON public.mb13_p0_monitor_target TO mb13_p2_writer, mb13_p2_executor, mb13_p2_api;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p2_monitor_state TO mb13_p2_writer;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p2_monitor_timeline TO mb13_p2_writer;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p2_reminder_schedule TO mb13_p2_writer;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p2_retry_schedule TO mb13_p2_writer;

GRANT SELECT ON public.mb13_p2_monitor_state TO mb13_p2_api;
GRANT SELECT ON public.mb13_p2_monitor_timeline TO mb13_p2_api;
GRANT SELECT ON public.mb13_p2_reminder_schedule TO mb13_p2_api;
GRANT SELECT ON public.mb13_p2_retry_schedule TO mb13_p2_api;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p2_monitor_state TO mb13_p2_executor;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p2_monitor_timeline TO mb13_p2_executor;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p2_reminder_schedule TO mb13_p2_executor;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p2_retry_schedule TO mb13_p2_executor;

GRANT mb13_p2_api TO test_app;
GRANT mb13_p2_executor TO test_app;

COMMIT;
