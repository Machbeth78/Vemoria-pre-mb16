-- VEMORA — Migration V91: billing meter + piani + gating base
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
--
-- Introduce la base tecnica della monetizzazione senza imporre un provider.
-- Obiettivo: distinguere piano effettivo, limiti e storico cambi piano.

CREATE TABLE IF NOT EXISTS billing_customer_plans (
    user_id              UUID        PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    plan_code            TEXT        NOT NULL,
    status               TEXT        NOT NULL DEFAULT 'active'
                                    CHECK (status IN ('active', 'paused', 'expired', 'cancelled')),
    billing_provider     TEXT,
    source               TEXT        NOT NULL DEFAULT 'manual'
                                    CHECK (source IN ('manual', 'website', 'store', 'promo', 'legacy', 'system')),
    started_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at           TIMESTAMPTZ,
    grace_until          TIMESTAMPTZ,
    metadata_json        JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_billing_customer_plans_status
    ON billing_customer_plans(status, expires_at);

COMMENT ON TABLE billing_customer_plans IS
    'Piano commerciale effettivo per utente. Una riga per utente: stato attuale del piano.';

CREATE TABLE IF NOT EXISTS billing_plan_events (
    id                   UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id              UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    event_type           TEXT        NOT NULL,
    previous_plan_code   TEXT,
    new_plan_code        TEXT,
    source               TEXT        NOT NULL DEFAULT 'system',
    payload_json         JSONB       NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_billing_plan_events_user_created
    ON billing_plan_events(user_id, created_at DESC);

COMMENT ON TABLE billing_plan_events IS
    'Audit minimale dei cambi piano e delle decisioni commerciali applicate all utente.';

-- Nota: registrazione migration demandata al migration runner/registry service.
-- Se la migration viene applicata manualmente via SQL puro, usare poi adopt-existing o status nel runner.
