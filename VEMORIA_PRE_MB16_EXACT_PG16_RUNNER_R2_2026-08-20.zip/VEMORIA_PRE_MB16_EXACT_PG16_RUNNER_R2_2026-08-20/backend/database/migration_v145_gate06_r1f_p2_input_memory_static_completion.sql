-- Vemoria Gate06 R1F — P2 Input/Memory static completion
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Static metadata migration only: no runtime execution, no device scan, no vault write.

CREATE TABLE IF NOT EXISTS gate06_p2_input_memory_static_completion (
    id BIGSERIAL PRIMARY KEY,
    vc_id TEXT NOT NULL UNIQUE,
    function_name TEXT NOT NULL,
    static_completion_state TEXT NOT NULL,
    runtime_state TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    device_runtime_state TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    completed_in_gate TEXT NOT NULL,
    completed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    notes JSONB NOT NULL DEFAULT '{}'::jsonb,
    CHECK (static_completion_state = 'STATIC_COMPLETED_RUNTIME_DEFERRED'),
    CHECK (runtime_state <> 'PASS')
);

INSERT INTO gate06_p2_input_memory_static_completion
    (vc_id, function_name, static_completion_state, runtime_state, device_runtime_state, completed_in_gate, notes)
VALUES
    ('VC-025', 'OCR multilivello', 'STATIC_COMPLETED_RUNTIME_DEFERRED', 'NON_ESEGUITO', 'NON_ESEGUITO', 'GATE06_R1F_P2_INPUT_MEMORY_STATIC_COMPLETION', '{"scope":"static_bridge_only"}'::jsonb),
    ('VC-027', 'Analisi immagini e foto evento', 'STATIC_COMPLETED_RUNTIME_DEFERRED', 'NON_ESEGUITO', 'NON_ESEGUITO', 'GATE06_R1F_P2_INPUT_MEMORY_STATIC_COMPLETION', '{"scope":"static_bridge_only"}'::jsonb),
    ('VC-035', 'Fast Index', 'STATIC_COMPLETED_RUNTIME_DEFERRED', 'NON_ESEGUITO', 'NON_ESEGUITO', 'GATE06_R1F_P2_INPUT_MEMORY_STATIC_COMPLETION', '{"scope":"static_bridge_only"}'::jsonb),
    ('VC-037', 'Vault copy reale', 'STATIC_COMPLETED_RUNTIME_DEFERRED', 'NON_ESEGUITO', 'NON_ESEGUITO', 'GATE06_R1F_P2_INPUT_MEMORY_STATIC_COMPLETION', '{"scope":"static_bridge_only"}'::jsonb)
ON CONFLICT (vc_id) DO UPDATE SET
    static_completion_state = EXCLUDED.static_completion_state,
    runtime_state = EXCLUDED.runtime_state,
    device_runtime_state = EXCLUDED.device_runtime_state,
    completed_in_gate = EXCLUDED.completed_in_gate,
    notes = EXCLUDED.notes;
