-- Gate06 R1D — P0 Foundation static completion
-- Static bookkeeping only. Does not claim real Android/PostgreSQL/device runtime.

CREATE TABLE IF NOT EXISTS gate06_p0_foundation_static_completion (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vc_id TEXT NOT NULL,
    completion_gate TEXT NOT NULL DEFAULT 'GATE06_R1D_P0_FOUNDATION_STATIC_COMPLETION',
    static_completion_state TEXT NOT NULL DEFAULT 'STATIC_COMPLETED_RUNTIME_DEFERRED',
    runtime_state TEXT NOT NULL,
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE,
    source_atlas_version TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(vc_id, completion_gate),
    CHECK (vc_id IN ('VC-038','VC-039','VC-081','VC-082','VC-086')),
    CHECK (runtime_pass_claimed = FALSE)
);

CREATE INDEX IF NOT EXISTS idx_gate06_p0_foundation_completion_vc
    ON gate06_p0_foundation_static_completion(vc_id, created_at DESC);

CREATE TABLE IF NOT EXISTS gate06_p0_foundation_runtime_probe_requirements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vc_id TEXT NOT NULL,
    required_probe TEXT NOT NULL,
    required_before_runtime_pass BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (vc_id IN ('VC-038','VC-039','VC-081','VC-082','VC-086')),
    CHECK (required_before_runtime_pass = TRUE)
);

CREATE INDEX IF NOT EXISTS idx_gate06_p0_probe_requirements_vc
    ON gate06_p0_foundation_runtime_probe_requirements(vc_id);
