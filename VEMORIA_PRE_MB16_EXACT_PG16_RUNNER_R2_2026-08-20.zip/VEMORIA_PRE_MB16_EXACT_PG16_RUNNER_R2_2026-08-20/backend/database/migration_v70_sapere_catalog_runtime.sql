-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V70 — Sapere catalogo runtime canonico
-- Obiettivo:
-- 1) trasformare il catalogo Sapere in base dati canonica, multilingua e pack-aware
-- 2) mantenere compatibilità con il runtime esistente senza cambiare la logica prodotto
-- 3) preparare il bootstrap/sync dai pack attivi documents + sapere

ALTER TABLE sapere_documenti
    ADD COLUMN IF NOT EXISTS locale TEXT,
    ADD COLUMN IF NOT EXISTS domain TEXT,
    ADD COLUMN IF NOT EXISTS source_pack_id TEXT,
    ADD COLUMN IF NOT EXISTS source_pack_version TEXT,
    ADD COLUMN IF NOT EXISTS source_manifest_version TEXT,
    ADD COLUMN IF NOT EXISTS source_entry_index INTEGER,
    ADD COLUMN IF NOT EXISTS source_checksum TEXT;

ALTER TABLE sapere_contenuti
    ADD COLUMN IF NOT EXISTS locale TEXT,
    ADD COLUMN IF NOT EXISTS domain TEXT,
    ADD COLUMN IF NOT EXISTS source_pack_id TEXT,
    ADD COLUMN IF NOT EXISTS source_pack_version TEXT,
    ADD COLUMN IF NOT EXISTS source_manifest_version TEXT,
    ADD COLUMN IF NOT EXISTS source_entry_index INTEGER,
    ADD COLUMN IF NOT EXISTS source_checksum TEXT;

UPDATE sapere_documenti
SET locale = COALESCE(NULLIF(BTRIM(locale), ''), 'it-IT'),
    domain = COALESCE(NULLIF(BTRIM(domain), ''), 'core'),
    fonte = COALESCE(NULLIF(BTRIM(fonte), ''), 'manuale')
WHERE locale IS NULL OR BTRIM(locale) = '' OR domain IS NULL OR BTRIM(domain) = '' OR fonte IS NULL OR BTRIM(fonte) = '';

UPDATE sapere_contenuti
SET locale = COALESCE(NULLIF(BTRIM(locale), ''), 'it-IT'),
    domain = COALESCE(NULLIF(BTRIM(domain), ''), 'core')
WHERE locale IS NULL OR BTRIM(locale) = '' OR domain IS NULL OR BTRIM(domain) = '';

ALTER TABLE sapere_documenti
    ALTER COLUMN locale SET NOT NULL,
    ALTER COLUMN locale SET DEFAULT 'it-IT',
    ALTER COLUMN domain SET NOT NULL,
    ALTER COLUMN domain SET DEFAULT 'core';

ALTER TABLE sapere_contenuti
    ALTER COLUMN locale SET NOT NULL,
    ALTER COLUMN locale SET DEFAULT 'it-IT',
    ALTER COLUMN domain SET NOT NULL,
    ALTER COLUMN domain SET DEFAULT 'core';

ALTER TABLE sapere_documenti DROP CONSTRAINT IF EXISTS sapere_documenti_documento_id_key;
ALTER TABLE sapere_contenuti DROP CONSTRAINT IF EXISTS sapere_contenuti_sapere_id_key;

DROP INDEX IF EXISTS uq_sapere_documenti_documento_locale_domain;
DROP INDEX IF EXISTS uq_sapere_contenuti_sapere_locale_domain;

CREATE UNIQUE INDEX IF NOT EXISTS uq_sapere_documenti_documento_locale_domain
    ON sapere_documenti (documento_id, locale, domain);

CREATE UNIQUE INDEX IF NOT EXISTS uq_sapere_contenuti_sapere_locale_domain
    ON sapere_contenuti (sapere_id, locale, domain);

CREATE INDEX IF NOT EXISTS idx_sapere_documenti_lookup_locale
    ON sapere_documenti (documento_id, locale, domain)
    WHERE attivo = TRUE;

CREATE INDEX IF NOT EXISTS idx_sapere_documenti_nome_locale
    ON sapere_documenti (nome, locale, domain)
    WHERE attivo = TRUE;

CREATE INDEX IF NOT EXISTS idx_sapere_documenti_pack
    ON sapere_documenti (source_pack_id, locale, domain);

CREATE INDEX IF NOT EXISTS idx_sapere_contenuti_lookup_locale
    ON sapere_contenuti (sapere_id, locale, domain)
    WHERE attivo = TRUE;

CREATE INDEX IF NOT EXISTS idx_sapere_contenuti_documento_locale
    ON sapere_contenuti (documento_id, locale, domain)
    WHERE attivo = TRUE;

CREATE INDEX IF NOT EXISTS idx_sapere_contenuti_pack
    ON sapere_contenuti (source_pack_id, locale, domain);

CREATE INDEX IF NOT EXISTS idx_sapere_sessioni_stato_creato
    ON sapere_sessioni (stato, creato_il DESC);

CREATE INDEX IF NOT EXISTS idx_sapere_sospesi_documento_fingerprint
    ON sapere_sospesi (documento_fisico_id, fingerprint, creato_il DESC);
