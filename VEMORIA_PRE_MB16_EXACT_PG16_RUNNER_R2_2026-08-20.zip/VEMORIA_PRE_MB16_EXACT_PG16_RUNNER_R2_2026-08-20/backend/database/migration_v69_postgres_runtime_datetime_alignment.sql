-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V69 — PostgreSQL runtime alignment
-- Obiettivo:
-- 1) riallineare estensioni PostgreSQL realmente usate dal pack
-- 2) convertire a TIMESTAMPTZ le colonne datetime naive ancora attive
--    nei moduli runtime non coperti da V66/V67
--
-- Regola di conversione: i valori TIMESTAMP legacy vengono interpretati come UTC.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pg_trgm;

DO $$
DECLARE
    rec RECORD;
BEGIN
    FOR rec IN
        SELECT *
        FROM (
            VALUES
                ('eventi_invio', 'creato_il'),
                ('timeline_eventi', 'registrato_il'),
                ('inviti_pendenti', 'creato_il'),
                ('inviti_pendenti', 'scade_il'),
                ('inviti_pendenti', 'accettato_il'),
                ('contatti_rubrica', 'creato_il'),
                ('contatti_rubrica', 'aggiornato_il'),
                ('email_memora', 'data_email'),
                ('email_memora', 'creato_il'),
                ('email_allegati', 'creato_il'),
                ('documento_entity_link', 'creato_il'),
                ('entity_feedback', 'creato_il'),
                ('eventi_documento', 'creato_il'),
                ('document_type_candidates', 'prima_occorrenza'),
                ('document_type_candidates', 'ultima_occorrenza'),
                ('document_type_candidates', 'creato_il'),
                ('document_type_candidates', 'updated_at'),
                ('desktop_pairing_requests', 'requested_at'),
                ('desktop_pairing_requests', 'confirmed_at'),
                ('desktop_pairing_requests', 'expires_at'),
                ('desktop_pairing_requests', 'revoked_at'),
                ('desktop_devices', 'paired_at'),
                ('desktop_devices', 'last_seen_at'),
                ('desktop_devices', 'revoked_at'),
                ('desktop_import_queue', 'received_at'),
                ('desktop_import_queue', 'updated_at'),
                ('desktop_transfer_log', 'started_at'),
                ('desktop_transfer_log', 'completed_at'),
                ('desktop_transfer_log', 'expires_at'),
                ('desktop_document_pins', 'requested_at'),
                ('desktop_document_pins', 'updated_at'),
                ('desktop_document_pins', 'last_opened_at'),
                ('desktop_secure_line_requests', 'created_at'),
                ('desktop_secure_line_requests', 'updated_at'),
                ('desktop_secure_line_requests', 'resolved_at'),
                ('desktop_secure_line_requests', 'expires_at'),
                ('extension_modules', 'active_from'),
                ('extension_modules', 'disabled_at'),
                ('extension_modules', 'created_at'),
                ('extension_modules', 'updated_at'),
                ('eco_dialog_turns', 'created_at'),
                ('eco_policy_events', 'created_at'),
                ('eco_anchor_candidates', 'created_at'),
                ('eco_temporal_resolutions', 'created_at'),
                ('eco_common_ground_states', 'created_at'),
                ('eco_anchor_memories', 'first_seen_at'),
                ('eco_anchor_memories', 'last_seen_at'),
                ('eco_anchor_memories', 'updated_at'),
                ('eco_anchor_memories', 'created_at'),
                ('eco_life_anchor_events', 'first_seen_at'),
                ('eco_life_anchor_events', 'last_seen_at'),
                ('eco_life_anchor_events', 'updated_at'),
                ('eco_life_anchor_events', 'created_at'),
                ('semantic_anchor_events', 'first_seen_at'),
                ('semantic_anchor_events', 'last_seen_at'),
                ('semantic_anchor_events', 'updated_at'),
                ('semantic_anchor_events', 'created_at'),
                ('eco_user_voice_profiles', 'last_seen_at'),
                ('eco_user_voice_profiles', 'updated_at'),
                ('eco_user_voice_profiles', 'created_at'),
                ('eco_adaptation_feedback', 'created_at'),
                ('eco_screen_action_habits', 'last_used_at'),
                ('eco_screen_action_habits', 'updated_at'),
                ('eco_screen_action_habits', 'created_at'),
                ('eco_semantic_ref_learning', 'last_seen_at'),
                ('eco_semantic_ref_learning', 'updated_at'),
                ('eco_semantic_ref_learning', 'created_at'),
                ('nm_static_nodes', 'first_seen_at'),
                ('nm_static_nodes', 'last_seen_at'),
                ('nm_timeline_events', 'event_at'),
                ('nm_timeline_events', 'recorded_at'),
                ('nm_relations', 'first_seen_at'),
                ('nm_relations', 'last_seen_at'),
                ('nm_relations', 'confirmed_at'),
                ('nm_session_context', 'expires_at'),
                ('nm_session_context', 'updated_at'),
                ('nm_anchors', 'start_at'),
                ('nm_anchors', 'end_at'),
                ('nm_action_decisions', 'created_at'),
                ('sapere_documenti', 'creato_il'),
                ('sapere_documenti', 'updated_at'),
                ('sapere_contenuti', 'creato_il'),
                ('sapere_contenuti', 'updated_at'),
                ('sapere_sospesi', 'creato_il'),
                ('sapere_sospesi', 'updated_at'),
                ('sapere_sessioni', 'creato_il'),
                ('sapere_sessioni', 'updated_at')
        ) AS t(table_name, column_name)
    LOOP
        IF EXISTS (
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = 'public'
              AND table_name = rec.table_name
              AND column_name = rec.column_name
              AND data_type <> 'timestamp with time zone'
        ) THEN
            EXECUTE format(
                'ALTER TABLE IF EXISTS %I ALTER COLUMN %I TYPE TIMESTAMPTZ USING %I AT TIME ZONE ''UTC''',
                rec.table_name,
                rec.column_name,
                rec.column_name
            );
        END IF;
    END LOOP;
END $$;
