-- ===========================================================================
-- VEMORA V242 — P0/P1 Privacy Closure: entity + dossier owner isolation
-- ===========================================================================
-- Scope:
--   1. Add device_token_epoch to owner_device_registration for revocation.
--   2. Add deterministic owner columns to entity, entity_link, documento_dossier.
--   3. Backfill owners from canonical paths (documenti, eventi_documento, dossier).
--   4. Enable ROW LEVEL SECURITY + FORCE ROW LEVEL SECURITY on entity,
--      entity_link, dossier, documento_dossier.
--   5. Create an orphan/system owner for rows that cannot be attributed.
--   6. Owner-scope uniqueness for private entities.
--
-- Non tocca le migration storiche; soltanto colonne/RLS additive.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- 1. device epoch per revocation binding
-- ---------------------------------------------------------------------------
ALTER TABLE owner_device_registration
    ADD COLUMN IF NOT EXISTS device_token_epoch BIGINT NOT NULL DEFAULT 0;

-- ---------------------------------------------------------------------------
-- 2. Orphan/system owner for rows that cannot be attributed deterministically
-- ---------------------------------------------------------------------------
INSERT INTO utenti (id, nome, email, password_hash, attivo)
VALUES (
    '00000000-0000-0000-0000-000000000000'::uuid,
    'System Owner',
    'system@vemoria.local',
    '$2b$12$systemplaceholder.systemplaceholder.systempl',
    FALSE
)
ON CONFLICT (id) DO NOTHING;

-- ---------------------------------------------------------------------------
-- 3. entity owner column + backfill + RLS
-- ---------------------------------------------------------------------------
ALTER TABLE entity ADD COLUMN IF NOT EXISTS owner_user_id UUID;

-- Backfill owner from first linked canonical target.
-- Se un entity e' linkata a target di piu' owner, scegliamo deterministicamente
-- il minimo UUID testuale: questo e' un artefatto della transizione, non una
-- policy di condivisione.
UPDATE entity e
SET owner_user_id = sub.owner_id
FROM (
    SELECT
        el.entity_id,
        MIN(COALESCE(
            d.proprietario_id,
            ed.utente_id,
            dos.proprietario_id,
            '00000000-0000-0000-0000-000000000000'::uuid
        )::text)::uuid AS owner_id
    FROM entity_link el
    LEFT JOIN documenti d
        ON el.tipo_target = 'documento' AND d.id = el.target_id
    LEFT JOIN eventi_documento ed
        ON el.tipo_target = 'evento' AND ed.id = el.target_id
    LEFT JOIN dossier dos
        ON el.tipo_target = 'dossier' AND dos.id = el.target_id
    GROUP BY el.entity_id
) sub
WHERE e.id = sub.entity_id
  AND e.owner_user_id IS NULL;

-- Remaining unlinked entities -> orphan/system owner (never visible to users)
UPDATE entity
SET owner_user_id = '00000000-0000-0000-0000-000000000000'::uuid
WHERE owner_user_id IS NULL;

ALTER TABLE entity ALTER COLUMN owner_user_id SET NOT NULL;
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_entity_owner_user') THEN
        ALTER TABLE entity ADD CONSTRAINT fk_entity_owner_user
            FOREIGN KEY (owner_user_id) REFERENCES utenti(id) ON DELETE CASCADE;
    END IF;
END $$;

-- Owner-scoped uniqueness for private entities; orphan rows are not constrained.
ALTER TABLE entity DROP CONSTRAINT IF EXISTS entity_tipo_entity_nome_identificativo_key;
CREATE UNIQUE INDEX IF NOT EXISTS idx_entity_private_unique
    ON entity (tipo_entity, nome, COALESCE(identificativo, '___VEMORIA_NULL___'), owner_user_id)
    WHERE owner_user_id != '00000000-0000-0000-0000-000000000000'::uuid;

-- RLS
ALTER TABLE entity ENABLE ROW LEVEL SECURITY;
ALTER TABLE entity FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS entity_owner_isolation ON entity;
CREATE POLICY entity_owner_isolation ON entity
    FOR ALL
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

-- ---------------------------------------------------------------------------
-- 4. entity_link owner column + backfill + RLS
-- ---------------------------------------------------------------------------
ALTER TABLE entity_link ADD COLUMN IF NOT EXISTS owner_user_id UUID;

UPDATE entity_link el
SET owner_user_id = COALESCE(e.owner_user_id, '00000000-0000-0000-0000-000000000000'::uuid)
FROM entity e
WHERE e.id = el.entity_id;

ALTER TABLE entity_link ALTER COLUMN owner_user_id SET NOT NULL;
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_entity_link_owner_user') THEN
        ALTER TABLE entity_link ADD CONSTRAINT fk_entity_link_owner_user
            FOREIGN KEY (owner_user_id) REFERENCES utenti(id) ON DELETE CASCADE;
    END IF;
END $$;

ALTER TABLE entity_link ENABLE ROW LEVEL SECURITY;
ALTER TABLE entity_link FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS entity_link_owner_isolation ON entity_link;
CREATE POLICY entity_link_owner_isolation ON entity_link
    FOR ALL
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

-- ---------------------------------------------------------------------------
-- 5. dossier RLS (proprietario_id e' gia' canonico)
-- ---------------------------------------------------------------------------
ALTER TABLE dossier ENABLE ROW LEVEL SECURITY;
ALTER TABLE dossier FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS dossier_owner_isolation ON dossier;
CREATE POLICY dossier_owner_isolation ON dossier
    FOR ALL
    USING (proprietario_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (proprietario_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

-- ---------------------------------------------------------------------------
-- 6. documento_dossier owner column + backfill + RLS
-- ---------------------------------------------------------------------------
ALTER TABLE documento_dossier ADD COLUMN IF NOT EXISTS owner_user_id UUID;

UPDATE documento_dossier dd
SET owner_user_id = d.proprietario_id
FROM dossier d
WHERE d.id = dd.dossier_id;

-- In the improbable case a row has no dossier, orphan it.
UPDATE documento_dossier
SET owner_user_id = '00000000-0000-0000-0000-000000000000'::uuid
WHERE owner_user_id IS NULL;

ALTER TABLE documento_dossier ALTER COLUMN owner_user_id SET NOT NULL;
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_documento_dossier_owner_user') THEN
        ALTER TABLE documento_dossier ADD CONSTRAINT fk_documento_dossier_owner_user
            FOREIGN KEY (owner_user_id) REFERENCES utenti(id) ON DELETE CASCADE;
    END IF;
END $$;

ALTER TABLE documento_dossier ENABLE ROW LEVEL SECURITY;
ALTER TABLE documento_dossier FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS documento_dossier_owner_isolation ON documento_dossier;
CREATE POLICY documento_dossier_owner_isolation ON documento_dossier
    FOR ALL
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

-- ---------------------------------------------------------------------------
-- 7. Grants for the dedicated API role when present (production/test boundary)
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p2_api') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE entity TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE entity_link TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE dossier TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE documento_dossier TO mb13_p2_api;
    END IF;
END $$;
