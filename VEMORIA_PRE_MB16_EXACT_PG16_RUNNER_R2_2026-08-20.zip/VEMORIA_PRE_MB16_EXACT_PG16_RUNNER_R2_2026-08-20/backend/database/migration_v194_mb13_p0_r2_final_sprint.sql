-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
--
-- MB13-P0 R2 final sprint — authoritative binding, provenance and temporal closure.
-- Forward-only, idempotent migration.  Supersedes v193 function definitions without
-- touching v193 data or earlier migrations.

BEGIN;

-- ----------------------------------------------------------------------------
-- Canonical temporal policy validation with explicit RFC 3339 contract.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p0_validate_temporal_policy(p_policy JSONB)
RETURNS void AS $$
DECLARE
    v_tz TEXT;
    v_field TEXT;
    v_val TEXT;
    v_ts TIMESTAMPTZ;
    v_valid_from TIMESTAMPTZ;
    v_valid_until TIMESTAMPTZ;
    v_next_check_at TIMESTAMPTZ;
    v_due_at TIMESTAMPTZ;
    v_grace_until TIMESTAMPTZ;
    v_cadence_kind TEXT;
    v_cadence_value TEXT;
    v_fields TEXT[] := ARRAY['valid_from','valid_until','next_check_at','due_at','grace_until'];
BEGIN
    IF jsonb_typeof(p_policy) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p0_policy_invalid';
    END IF;

    v_tz := p_policy->>'timezone';
    IF v_tz IS NULL OR length(trim(v_tz)) = 0 THEN
        RAISE EXCEPTION 'mb13_p0_policy_timezone_required';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_timezone_names WHERE name = v_tz) THEN
        RAISE EXCEPTION 'mb13_p0_policy_timezone_invalid';
    END IF;

    FOREACH v_field IN ARRAY v_fields LOOP
        v_val := p_policy->>v_field;
        IF v_val IS NOT NULL AND length(trim(v_val)) > 0 THEN
            -- RFC 3339 explicit form: date-time with T and Z or numeric offset.
            IF v_val !~ '^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$' THEN
                RAISE EXCEPTION 'mb13_p0_temporal_policy_not_rfc3339:%', v_field;
            END IF;
            BEGIN
                v_ts := v_val::TIMESTAMPTZ;
            EXCEPTION
                WHEN invalid_text_representation OR invalid_datetime_format OR datetime_field_overflow THEN
                    RAISE EXCEPTION 'mb13_p0_temporal_policy_timestamp_invalid:%', v_field;
            END;
            CASE v_field
                WHEN 'valid_from' THEN v_valid_from := v_ts;
                WHEN 'valid_until' THEN v_valid_until := v_ts;
                WHEN 'next_check_at' THEN v_next_check_at := v_ts;
                WHEN 'due_at' THEN v_due_at := v_ts;
                WHEN 'grace_until' THEN v_grace_until := v_ts;
            END CASE;
        END IF;
    END LOOP;

    IF v_valid_from IS NOT NULL AND v_next_check_at IS NOT NULL AND v_valid_from > v_next_check_at THEN
        RAISE EXCEPTION 'mb13_p0_temporal_policy_invalid_order:valid_from_after_next_check_at';
    END IF;
    IF v_valid_from IS NOT NULL AND v_due_at IS NOT NULL AND v_valid_from > v_due_at THEN
        RAISE EXCEPTION 'mb13_p0_temporal_policy_invalid_order:valid_from_after_due_at';
    END IF;
    IF v_due_at IS NOT NULL AND v_grace_until IS NOT NULL AND v_due_at > v_grace_until THEN
        RAISE EXCEPTION 'mb13_p0_temporal_policy_invalid_order:due_at_after_grace_until';
    END IF;
    IF v_valid_from IS NOT NULL AND v_valid_until IS NOT NULL AND v_valid_from > v_valid_until THEN
        RAISE EXCEPTION 'mb13_p0_temporal_policy_invalid_order:valid_from_after_valid_until';
    END IF;
    IF v_next_check_at IS NOT NULL AND v_valid_until IS NOT NULL AND v_next_check_at > v_valid_until THEN
        RAISE EXCEPTION 'mb13_p0_temporal_policy_invalid_order:next_check_at_after_valid_until';
    END IF;

    v_cadence_kind := p_policy->>'cadence_kind';
    IF v_cadence_kind IS NOT NULL AND length(trim(v_cadence_kind)) > 0 THEN
        IF v_cadence_kind NOT IN ('daily','weekly','monthly','quarterly','yearly','one-shot','manual') THEN
            RAISE EXCEPTION 'mb13_p0_policy_cadence_kind_invalid';
        END IF;
        IF v_cadence_kind NOT IN ('one-shot','manual') THEN
            v_cadence_value := p_policy->>'cadence_value';
            IF v_cadence_value IS NULL OR length(trim(v_cadence_value)) = 0 THEN
                RAISE EXCEPTION 'mb13_p0_policy_cadence_value_required';
            END IF;
            IF v_cadence_value !~ '^[1-9][0-9]*$' THEN
                RAISE EXCEPTION 'mb13_p0_policy_cadence_value_invalid';
            END IF;
        ELSIF p_policy->>'cadence_value' IS NOT NULL AND length(trim(p_policy->>'cadence_value')) > 0 THEN
            RAISE EXCEPTION 'mb13_p0_policy_cadence_value_unexpected';
        END IF;
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_validate_temporal_policy(JSONB) FROM PUBLIC;

-- ----------------------------------------------------------------------------
-- State-aware temporal validation (active / resume requires complete contract).
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p0_validate_temporal_policy_for_state(p_policy JSONB, p_state TEXT)
RETURNS void AS $$
BEGIN
    PERFORM public.mb13_p0_validate_temporal_policy(p_policy);

    IF p_state = 'active' THEN
        IF p_policy->>'timezone' IS NULL OR length(trim(p_policy->>'timezone')) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_active_requires_temporal_policy:timezone';
        END IF;
        IF p_policy->>'valid_from' IS NULL OR length(trim(p_policy->>'valid_from')) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_active_requires_temporal_policy:valid_from';
        END IF;
        IF p_policy->>'next_check_at' IS NULL OR length(trim(p_policy->>'next_check_at')) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_active_requires_temporal_policy:next_check_at';
        END IF;
    END IF;

    IF p_policy ? 'retry_policy_ref'
       AND p_policy->'retry_policy_ref' IS NOT NULL
       AND jsonb_typeof(p_policy->'retry_policy_ref') <> 'null'
       AND (p_policy->>'retry_policy_ref' <> '')
    THEN
        IF jsonb_typeof(p_policy->'retry_policy_ref') <> 'object' THEN
            RAISE EXCEPTION 'mb13_p0_retry_policy_ref_invalid:not_object';
        END IF;
        IF (p_policy->'retry_policy_ref'->>'max_retries') IS NULL
           OR (p_policy->'retry_policy_ref'->>'max_retries')::INTEGER < 0 THEN
            RAISE EXCEPTION 'mb13_p0_retry_policy_ref_invalid:max_retries';
        END IF;
        IF p_policy->'retry_policy_ref'->>'backoff_kind' IS NULL
           OR p_policy->'retry_policy_ref'->>'backoff_kind' NOT IN ('fixed','exponential','linear','none') THEN
            RAISE EXCEPTION 'mb13_p0_retry_policy_ref_invalid:backoff_kind';
        END IF;
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_validate_temporal_policy_for_state(JSONB, TEXT) FROM PUBLIC;

-- ----------------------------------------------------------------------------
-- Authoritative provenance for a monitor target.
-- Returns the canonical source_refs and evidence_refs derived from the target
-- itself, protected by row-level shared locks.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p0_get_target_provenance(
    p_owner UUID,
    p_target_type TEXT,
    p_target_ref JSONB
)
RETURNS TABLE(source_refs JSONB, evidence_refs JSONB) AS $$
DECLARE
    v_id TEXT;
    v_revision INTEGER;
    v_source_refs JSONB;
    v_evidence_refs JSONB;
BEGIN
    IF p_target_ref IS NULL OR jsonb_typeof(p_target_ref) <> 'object' THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    v_id := p_target_ref->>'id';
    IF v_id IS NULL OR length(trim(v_id)) = 0 THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    BEGIN
        v_revision := (p_target_ref->>'revision')::INTEGER;
    EXCEPTION WHEN invalid_text_representation THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END;

    -- Source card target: lock and return the binding row as provenance.
    IF p_target_type = 'source' THEN
        SELECT
            jsonb_build_array(jsonb_build_object(
                'source_card_id', b.source_card_id,
                'source_id', b.source_id::text,
                'source_revision_id', b.source_revision_id::text,
                'evidence_id', b.evidence_id::text,
                'grant_id', b.grant_id::text,
                'content_hash', b.content_hash
            )),
            COALESCE((
                SELECT jsonb_agg(jsonb_build_object(
                    'evidence_id', b2.evidence_id::text,
                    'source_id', b2.source_id::text,
                    'source_card_id', b2.source_card_id
                ) ORDER BY b2.evidence_id::text)
                  FROM public.mb12_p0_source_card_binding b2
                 WHERE b2.owner_user_id = p_owner
                   AND b2.source_card_id = v_id
            ), '[]'::jsonb)
          INTO v_source_refs, v_evidence_refs
          FROM public.mb12_p0_source_card_binding b
         WHERE b.owner_user_id = p_owner
           AND b.source_card_id = v_id
         FOR SHARE;
        RETURN QUERY SELECT COALESCE(v_source_refs, '[]'::jsonb), COALESCE(v_evidence_refs, '[]'::jsonb);
        RETURN;
    END IF;

    -- Dossier / contract / offer target: read the exact revision source_refs.
    IF p_target_type IN ('dossier','contract','offer') THEN
        SELECT r.source_refs
          INTO v_source_refs
          FROM public.mb12_p1_offer_contract_revision r
         WHERE r.owner_user_id = p_owner
           AND r.dossier_id = v_id::UUID
           AND r.revision = v_revision;

        IF v_source_refs IS NOT NULL THEN
            v_evidence_refs := COALESCE((
                SELECT jsonb_agg(jsonb_build_object(
                    'evidence_id', (s->>'evidence_id'),
                    'source_id', (s->>'source_id'),
                    'source_card_id', (s->>'source_card_id')
                ) ORDER BY (s->>'evidence_id'))
                  FROM jsonb_array_elements(v_source_refs) AS s
                 WHERE (s->>'evidence_id') IS NOT NULL
            ), '[]'::jsonb);
            RETURN QUERY SELECT public.mb13_p0_normalize_jsonb_array(v_source_refs), public.mb13_p0_normalize_jsonb_array(v_evidence_refs);
            RETURN;
        END IF;
    END IF;

    -- Decision target: lock the ranking and its current revision.
    IF p_target_type = 'decision' THEN
        SELECT rev.result_payload->'source_refs'
          INTO v_source_refs
          FROM public.mb12_p4_governed_explainable_ranking r
          JOIN public.mb12_p4_governed_explainable_ranking_revision rev
            ON rev.owner_user_id = r.owner_user_id
           AND rev.ranking_id = r.ranking_id
           AND rev.revision = r.current_revision
         WHERE r.owner_user_id = p_owner
           AND r.ranking_id = v_id::UUID
         FOR SHARE OF r, rev;

        IF v_source_refs IS NOT NULL THEN
            v_evidence_refs := COALESCE((
                SELECT jsonb_agg(jsonb_build_object(
                    'evidence_id', (s->>'evidence_id'),
                    'source_id', (s->>'source_id'),
                    'source_card_id', (s->>'source_card_id')
                ) ORDER BY (s->>'evidence_id'))
                  FROM jsonb_array_elements(v_source_refs) AS s
                 WHERE (s->>'evidence_id') IS NOT NULL
            ), '[]'::jsonb);
            RETURN QUERY SELECT public.mb13_p0_normalize_jsonb_array(v_source_refs), public.mb13_p0_normalize_jsonb_array(v_evidence_refs);
            RETURN;
        END IF;
    END IF;

    -- Document and generic targets carry no intrinsic provenance.
    RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB) FROM PUBLIC;

-- ----------------------------------------------------------------------------
-- Consent and provenance validation.
-- Grants must be active, owner-scoped, capability-correct and bound to the
-- exact target provenance.  Document grants require the document id to be
-- listed in grant.constraints.data_scope.allowed_documents.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p0_lock_and_verify_consents(
    p_owner UUID,
    p_consent_refs JSONB,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_required BOOLEAN
)
RETURNS JSONB AS $$
DECLARE
    v_ref JSONB;
    v_source_id TEXT;
    v_grant_id TEXT;
    v_grant RECORD;
    v_normalized JSONB;
    v_count INTEGER := 0;
    v_provenance_source_refs JSONB;
    v_provenance_evidence_refs JSONB;
    v_required_pairs TEXT[];
    v_provided_pairs TEXT[];
    v_ps TEXT;
    v_document_id UUID;
    v_allowed_documents JSONB;
BEGIN
    IF p_consent_refs IS NULL OR jsonb_typeof(p_consent_refs) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p0_consent_refs_invalid';
    END IF;
    IF p_required AND jsonb_array_length(p_consent_refs) = 0 THEN
        RAISE EXCEPTION 'mb13_p0_consent_required';
    END IF;

    v_normalized := public.mb13_p0_normalize_jsonb_array(p_consent_refs);

    SELECT source_refs, evidence_refs INTO v_provenance_source_refs, v_provenance_evidence_refs
      FROM public.mb13_p0_get_target_provenance(p_owner, p_target_type, p_target_ref);

    IF p_target_type IN ('dossier','contract','offer','source','decision') THEN
        SELECT array_agg(DISTINCT (((s->>'source_id') || ':' || COALESCE(s->>'grant_id',''))))
          INTO v_required_pairs
          FROM jsonb_array_elements(v_provenance_source_refs) AS s
         WHERE (s->>'source_id') IS NOT NULL
           AND jsonb_typeof(s) = 'object';
    END IF;

    FOR v_ref IN SELECT value FROM jsonb_array_elements(v_normalized) LOOP
        v_source_id := v_ref->>'source_id';
        v_grant_id := v_ref->>'grant_id';
        IF v_source_id IS NULL OR v_grant_id IS NULL THEN
            RAISE EXCEPTION 'mb13_p0_consent_ref_invalid';
        END IF;

        -- Acquire a shared lock on the grant; a concurrent revoke will block.
        SELECT *
          INTO v_grant
          FROM public.authorized_memory_consent_grants
         WHERE user_id = p_owner
           AND source_id = v_source_id::UUID
           AND id = v_grant_id::UUID
           AND status = 'active'
           AND revoked_at IS NULL
           AND (expires_at IS NULL OR expires_at > NOW())
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_consent_revoked_or_invalid';
        END IF;

        IF v_grant.action NOT IN ('read_metadata','inventory_existence')
           OR v_grant.plane <> 'EXISTENCE' THEN
            RAISE EXCEPTION 'mb13_p0_consent_action_incompatible';
        END IF;

        -- Target relation and coverage rules.
        IF p_target_type IN ('dossier','contract','offer','decision') THEN
            v_ps := v_source_id || ':' || v_grant_id;
            IF v_required_pairs IS NULL OR NOT (v_ps = ANY(v_required_pairs)) THEN
                RAISE EXCEPTION 'mb13_p0_provenance_not_related_to_target';
            END IF;
        ELSIF p_target_type = 'source' THEN
            IF NOT EXISTS (
                SELECT 1 FROM public.mb12_p0_source_card_binding b
                 WHERE b.owner_user_id = p_owner
                   AND b.source_card_id = (p_target_ref->>'id')
                   AND b.source_id = v_source_id::UUID
                   AND b.grant_id = v_grant_id::UUID
            ) THEN
                RAISE EXCEPTION 'mb13_p0_provenance_not_related_to_target';
            END IF;
        ELSIF p_target_type = 'document' THEN
            v_document_id := (p_target_ref->>'id')::UUID;
            v_allowed_documents := NULLIF(v_grant.constraints->'data_scope'->'allowed_documents', 'null'::jsonb);
            IF v_allowed_documents IS NULL
               OR jsonb_typeof(v_allowed_documents) <> 'array'
               OR NOT EXISTS (
                    SELECT 1 FROM jsonb_array_elements_text(v_allowed_documents) AS ad
                     WHERE ad = v_document_id::text
                  )
            THEN
                RAISE EXCEPTION 'mb13_p0_document_capability_not_bound';
            END IF;
        END IF;

        v_count := v_count + 1;
    END LOOP;

    -- Full coverage: every required provenance pair must be covered by an active consent.
    IF p_required AND p_target_type IN ('dossier','contract','offer','decision') THEN
        SELECT array_agg(DISTINCT (((c->>'source_id') || ':' || COALESCE(c->>'grant_id',''))))
          INTO v_provided_pairs
          FROM jsonb_array_elements(v_normalized) AS c
         WHERE (c->>'source_id') IS NOT NULL AND (c->>'grant_id') IS NOT NULL;

        IF v_required_pairs IS NOT NULL THEN
            FOREACH v_ps IN ARRAY v_required_pairs LOOP
                IF v_provided_pairs IS NULL OR NOT (v_ps = ANY(v_provided_pairs)) THEN
                    RAISE EXCEPTION 'mb13_p0_consent_coverage_incomplete';
                END IF;
            END LOOP;
        END IF;
    END IF;

    IF p_required AND v_count = 0 THEN
        RAISE EXCEPTION 'mb13_p0_consent_required';
    END IF;

    RETURN v_normalized;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN) FROM PUBLIC;

-- ----------------------------------------------------------------------------
-- Authoritative monitor writer.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p0_write_monitor(
    p_monitor_id UUID,
    p_stable_id TEXT,
    p_title TEXT,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_target_revision INTEGER,
    p_target_payload_hash TEXT,
    p_monitor_reason TEXT,
    p_monitor_state TEXT,
    p_monitor_policy JSONB,
    p_consent_refs JSONB,
    p_source_refs JSONB,
    p_evidence_refs JSONB,
    p_baseline_ref JSONB,
    p_request_payload JSONB,
    p_result_payload JSONB
) RETURNS TABLE(monitor_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_revision INTEGER;
    v_payload_hash TEXT;
    v_result_payload JSONB;
    v_event_type TEXT;
    v_event_id UUID;
    v_event_payload_hash TEXT;
    v_event_time TIMESTAMPTZ := NOW();
    v_event_reason TEXT;
    v_canonical_consent_refs JSONB;
    v_canonical_source_refs JSONB;
    v_canonical_evidence_refs JSONB;
    v_required_target_keys TEXT[] := ARRAY['id','revision','payload_hash','owner_user_id','state'];
    k TEXT;
    v_old_state TEXT;
    v_current_found BOOLEAN;
    v_is_new BOOLEAN;
    v_canonical JSONB;
    v_input_source_refs JSONB;
    v_input_evidence_refs JSONB;
    v_provenance JSONB;
    v_ref_revision INTEGER;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p0_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p0_monitor_identity_invalid';
    END IF;
    IF length(trim(COALESCE(p_stable_id, ''))) = 0 OR length(p_stable_id) > 200 THEN
        RAISE EXCEPTION 'mb13_p0_stable_id_invalid';
    END IF;
    IF length(trim(COALESCE(p_title, ''))) = 0 OR length(p_title) > 300 THEN
        RAISE EXCEPTION 'mb13_p0_title_invalid';
    END IF;
    IF length(trim(COALESCE(p_monitor_reason, ''))) = 0 OR length(p_monitor_reason) > 500 THEN
        RAISE EXCEPTION 'mb13_p0_monitor_reason_invalid';
    END IF;
    IF p_target_type NOT IN ('document','contract','offer','rule','source','dossier','identity','object','decision','generic_entity') THEN
        RAISE EXCEPTION 'mb13_p0_target_type_invalid';
    END IF;
    IF p_monitor_state NOT IN ('draft','active','paused','blocked','revoked','completed') THEN
        RAISE EXCEPTION 'mb13_p0_monitor_state_invalid';
    END IF;

    -- Revocation is only allowed through the dedicated revoke function.
    IF p_monitor_state = 'revoked' THEN
        RAISE EXCEPTION 'mb13_p0_revoke_must_use_revoke_function';
    END IF;

    IF jsonb_typeof(p_target_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p0_target_ref_invalid';
    END IF;
    FOREACH k IN ARRAY v_required_target_keys LOOP
        IF p_target_ref->>k IS NULL OR length(trim(p_target_ref->>k)) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_target_ref_missing:%', k;
        END IF;
    END LOOP;
    IF p_target_ref->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
        RAISE EXCEPTION 'mb13_p0_target_owner_mismatch';
    END IF;

    BEGIN
        v_ref_revision := (p_target_ref->>'revision')::INTEGER;
    EXCEPTION WHEN invalid_text_representation THEN
        RAISE EXCEPTION 'mb13_p0_target_ref_invalid:revision';
    END;
    IF v_ref_revision IS DISTINCT FROM p_target_revision OR p_target_ref->>'payload_hash' IS DISTINCT FROM p_target_payload_hash THEN
        RAISE EXCEPTION 'mb13_p0_target_binding_mismatch';
    END IF;

    IF jsonb_typeof(p_monitor_policy) <> 'object'
       OR jsonb_typeof(p_baseline_ref) <> 'object'
       OR jsonb_typeof(p_request_payload) <> 'object'
       OR jsonb_typeof(p_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p0_payload_shape_invalid';
    END IF;
    IF jsonb_typeof(p_consent_refs) <> 'array' OR jsonb_typeof(p_source_refs) <> 'array' OR jsonb_typeof(p_evidence_refs) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p0_refs_must_be_arrays';
    END IF;

    PERFORM public.mb13_p0_validate_temporal_policy_for_state(p_monitor_policy, p_monitor_state);

    -- Validate and normalize consents; this also acquires shared locks on grants.
    v_canonical_consent_refs := public.mb13_p0_lock_and_verify_consents(v_owner, p_consent_refs, p_target_type, p_target_ref, p_required => FALSE);

    -- Derive canonical source/evidence provenance from the authoritative target.
    SELECT source_refs, evidence_refs INTO v_canonical_source_refs, v_canonical_evidence_refs
      FROM public.mb13_p0_get_target_provenance(v_owner, p_target_type, p_target_ref);
    v_canonical_source_refs := public.mb13_p0_normalize_jsonb_array(v_canonical_source_refs);
    v_canonical_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_canonical_evidence_refs);

    v_input_source_refs := public.mb13_p0_normalize_jsonb_array(p_source_refs);
    v_input_evidence_refs := public.mb13_p0_normalize_jsonb_array(p_evidence_refs);

    -- Validate target currentness only when moving to active.
    IF p_monitor_state = 'active' THEN
        PERFORM public.mb13_p0_validate_target(v_owner, p_target_type, p_target_ref, p_for_active => TRUE);
    END IF;

    -- Consent/capability is required for any operational state.
    IF p_monitor_state IN ('active','paused','blocked','completed') THEN
        v_canonical_consent_refs := public.mb13_p0_lock_and_verify_consents(v_owner, v_canonical_consent_refs, p_target_type, p_target_ref, p_required => TRUE);
    END IF;

    -- Serialize all operations on this owner+stable_id monitor.
    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_stable_id, 0));

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = v_owner
       AND t.stable_id = p_stable_id
     FOR UPDATE;

    v_current_found := FOUND;
    v_is_new := NOT FOUND;

    IF v_current_found THEN
        -- Identity is immutable; normalize caller-provided ids to the stored row.
        p_monitor_id := v_current.monitor_id;
        p_stable_id := v_current.stable_id;
        IF p_target_type IS DISTINCT FROM v_current.target_type THEN
            RAISE EXCEPTION 'mb13_p0_target_type_immutable';
        END IF;

        -- Transition payloads must reproduce the current canonical target/baseline.
        IF p_target_ref IS DISTINCT FROM v_current.target_ref THEN
            RAISE EXCEPTION 'mb13_p0_transition_payload_mismatch';
        END IF;
        IF p_target_revision IS DISTINCT FROM v_current.target_revision THEN
            RAISE EXCEPTION 'mb13_p0_transition_payload_mismatch';
        END IF;
        IF p_target_payload_hash IS DISTINCT FROM v_current.target_payload_hash THEN
            RAISE EXCEPTION 'mb13_p0_transition_payload_mismatch';
        END IF;
        IF p_baseline_ref IS DISTINCT FROM v_current.baseline_ref THEN
            RAISE EXCEPTION 'mb13_p0_transition_payload_mismatch';
        END IF;

        -- Caller-supplied source/evidence refs must be empty or exactly the canonical set.
        IF jsonb_array_length(v_input_source_refs) > 0 AND v_input_source_refs IS DISTINCT FROM v_current.source_refs THEN
            RAISE EXCEPTION 'mb13_p0_source_ref_invalid';
        END IF;
        IF jsonb_array_length(v_input_evidence_refs) > 0 AND v_input_evidence_refs IS DISTINCT FROM v_current.evidence_refs THEN
            RAISE EXCEPTION 'mb13_p0_evidence_ref_invalid';
        END IF;

        -- Reload canonical fields from the database.
        v_canonical_source_refs := public.mb13_p0_normalize_jsonb_array(v_current.source_refs);
        v_canonical_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_current.evidence_refs);
        v_canonical_consent_refs := public.mb13_p0_normalize_jsonb_array(v_current.consent_refs);

        v_old_state := v_current.monitor_state;
        IF v_old_state = 'revoked' AND p_monitor_state <> 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_revoked_monitor_cannot_reactivate';
        END IF;
        IF NOT (
            (v_old_state = p_monitor_state)
         OR (v_old_state = 'draft' AND p_monitor_state IN ('active','revoked'))
         OR (v_old_state = 'active' AND p_monitor_state IN ('paused','blocked','revoked','completed'))
         OR (v_old_state = 'paused' AND p_monitor_state IN ('active','blocked','revoked'))
         OR (v_old_state = 'blocked' AND p_monitor_state IN ('active','revoked'))
         OR (v_old_state = 'completed' AND p_monitor_state IN ('revoked'))
        ) THEN
            RAISE EXCEPTION 'mb13_p0_transition_invalid:%->%', v_old_state, p_monitor_state;
        END IF;

        p_monitor_id := v_current.monitor_id;
        v_revision := v_current.current_revision;
    END IF;

    IF v_is_new THEN
        -- New monitors must be created in draft.
        IF p_monitor_state <> 'draft' THEN
            RAISE EXCEPTION 'mb13_p0_monitor_must_be_created_in_draft';
        END IF;
        IF EXISTS (SELECT 1 FROM public.mb13_p0_monitor_target AS t WHERE t.owner_user_id = v_owner AND t.monitor_id = p_monitor_id) THEN
            RAISE EXCEPTION 'mb13_p0_monitor_id_already_exists';
        END IF;

        -- Caller cannot smuggle unverified provenance for a new monitor.
        IF jsonb_array_length(v_input_source_refs) > 0 AND v_input_source_refs IS DISTINCT FROM v_canonical_source_refs THEN
            RAISE EXCEPTION 'mb13_p0_source_ref_invalid';
        END IF;
        IF jsonb_array_length(v_input_evidence_refs) > 0 AND v_input_evidence_refs IS DISTINCT FROM v_canonical_evidence_refs THEN
            RAISE EXCEPTION 'mb13_p0_evidence_ref_invalid';
        END IF;

        v_old_state := NULL;
        v_revision := 1;
    END IF;

    v_result_payload := p_result_payload || jsonb_build_object(
        'monitor_state', p_monitor_state,
        'no_auto_action', true,
        'no_auto_notification', true
    );

    v_canonical := jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'stable_id', p_stable_id,
        'title', p_title,
        'target_type', p_target_type,
        'target_ref', p_target_ref,
        'target_revision', p_target_revision,
        'target_payload_hash', p_target_payload_hash,
        'monitor_reason', p_monitor_reason,
        'monitor_state', p_monitor_state,
        'monitor_policy', p_monitor_policy,
        'consent_refs', v_canonical_consent_refs,
        'source_refs', v_canonical_source_refs,
        'evidence_refs', v_canonical_evidence_refs,
        'baseline_ref', p_baseline_ref,
        'request_payload', p_request_payload,
        'result_payload', v_result_payload,
        'revision', v_revision
    );
    v_payload_hash := public.mb13_p0_hash_jsonb(v_canonical);

    IF v_current_found AND v_current.payload_hash = v_payload_hash AND v_current.monitor_state = p_monitor_state THEN
        RETURN QUERY SELECT v_current.monitor_id, v_current.current_revision, v_current.payload_hash::TEXT;
        RETURN;
    END IF;

    IF v_current_found THEN
        v_revision := v_current.current_revision + 1;
        v_canonical := jsonb_build_object(
            'owner_user_id', v_owner,
            'monitor_id', p_monitor_id,
            'stable_id', p_stable_id,
            'title', p_title,
            'target_type', p_target_type,
            'target_ref', p_target_ref,
            'target_revision', p_target_revision,
            'target_payload_hash', p_target_payload_hash,
            'monitor_reason', p_monitor_reason,
            'monitor_state', p_monitor_state,
            'monitor_policy', p_monitor_policy,
            'consent_refs', v_canonical_consent_refs,
            'source_refs', v_canonical_source_refs,
            'evidence_refs', v_canonical_evidence_refs,
            'baseline_ref', p_baseline_ref,
            'request_payload', p_request_payload,
            'result_payload', v_result_payload,
            'revision', v_revision
        );
        v_payload_hash := public.mb13_p0_hash_jsonb(v_canonical);
    END IF;

    IF NOT v_current_found THEN
        v_event_type := 'MONITOR_CREATED';
    ELSIF v_old_state = 'draft' AND p_monitor_state = 'active' THEN
        v_event_type := 'MONITOR_ACTIVATED';
    ELSIF v_old_state = 'active' AND p_monitor_state = 'paused' THEN
        v_event_type := 'MONITOR_PAUSED';
    ELSIF v_old_state = 'paused' AND p_monitor_state = 'active' THEN
        v_event_type := 'MONITOR_RESUMED';
    ELSIF p_monitor_state = 'blocked' THEN
        v_event_type := 'MONITOR_BLOCKED';
    ELSIF p_monitor_state = 'revoked' THEN
        v_event_type := 'MONITOR_REVOKED';
    ELSE
        v_event_type := NULL;
    END IF;

    v_event_reason := p_result_payload->>'block_reason';

    IF v_is_new THEN
        INSERT INTO public.mb13_p0_monitor_target (
            owner_user_id, monitor_id, stable_id, title, target_type,
            target_ref, target_revision, target_payload_hash,
            monitor_reason, monitor_state, monitor_policy,
            consent_refs, source_refs, evidence_refs, baseline_ref,
            current_revision, payload_hash
        ) VALUES (
            v_owner, p_monitor_id, p_stable_id, p_title, p_target_type,
            p_target_ref, p_target_revision, p_target_payload_hash,
            p_monitor_reason, p_monitor_state, p_monitor_policy,
            v_canonical_consent_refs, v_canonical_source_refs, v_canonical_evidence_refs, p_baseline_ref,
            v_revision, v_payload_hash
        );
    ELSE
        UPDATE public.mb13_p0_monitor_target AS t
           SET title = p_title,
               target_ref = p_target_ref,
               target_revision = p_target_revision,
               target_payload_hash = p_target_payload_hash,
               monitor_reason = p_monitor_reason,
               monitor_state = p_monitor_state,
               monitor_policy = p_monitor_policy,
               consent_refs = v_canonical_consent_refs,
               source_refs = v_canonical_source_refs,
               evidence_refs = v_canonical_evidence_refs,
               baseline_ref = p_baseline_ref,
               current_revision = v_revision,
               payload_hash = v_payload_hash,
               updated_at = NOW()
         WHERE t.owner_user_id = v_owner
           AND t.monitor_id = p_monitor_id;
    END IF;

    INSERT INTO public.mb13_p0_monitor_target_revision (
        owner_user_id, monitor_id, revision, monitor_state, payload_hash,
        target_ref, target_revision, target_payload_hash,
        monitor_reason, monitor_policy, consent_refs, source_refs, evidence_refs, baseline_ref,
        request_payload, result_payload
    ) VALUES (
        v_owner, p_monitor_id, v_revision, p_monitor_state, v_payload_hash,
        p_target_ref, p_target_revision, p_target_payload_hash,
        p_monitor_reason, p_monitor_policy, v_canonical_consent_refs, v_canonical_source_refs, v_canonical_evidence_refs, p_baseline_ref,
        p_request_payload, v_result_payload
    );

    IF v_event_type IS NOT NULL THEN
        v_event_id := gen_random_uuid();
        v_event_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'event_id', v_event_id,
            'owner_user_id', v_owner,
            'monitor_id', p_monitor_id,
            'monitor_revision', v_revision,
            'event_type', v_event_type,
            'event_status', 'recorded',
            'event_time', to_jsonb(v_event_time),
            'observed_ref', '{}'::jsonb,
            'source_refs', v_canonical_source_refs,
            'evidence_refs', v_canonical_evidence_refs,
            'consent_refs', v_canonical_consent_refs,
            'reason', v_event_reason,
            'result_payload', v_result_payload
        ));
        INSERT INTO public.mb13_p0_monitor_event_ledger (
            event_id, owner_user_id, monitor_id, monitor_revision, event_type, event_status, event_time,
            observed_ref, source_refs, evidence_refs, consent_refs, reason, result_payload, payload_hash
        ) VALUES (
            v_event_id, v_owner, p_monitor_id, v_revision, v_event_type, 'recorded', v_event_time,
            '{}'::jsonb, v_canonical_source_refs, v_canonical_evidence_refs, v_canonical_consent_refs, v_event_reason, v_result_payload, v_event_payload_hash
        );
    END IF;

    RETURN QUERY SELECT p_monitor_id, v_revision, v_payload_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_write_monitor(UUID,TEXT,TEXT,TEXT,JSONB,INTEGER,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB) FROM PUBLIC, mb13_p0_app;
GRANT EXECUTE ON FUNCTION public.mb13_p0_write_monitor(UUID,TEXT,TEXT,TEXT,JSONB,INTEGER,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB) TO mb13_p0_app;

COMMIT;
