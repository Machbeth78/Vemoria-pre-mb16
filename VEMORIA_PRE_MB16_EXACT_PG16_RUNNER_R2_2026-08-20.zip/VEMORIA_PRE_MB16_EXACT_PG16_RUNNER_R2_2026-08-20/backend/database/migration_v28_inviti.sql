-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V4.6 — Migration V28
-- Tabella inviti pendenti per utenti non ancora registrati.
-- Generato da: implementazione flusso invito.
-- Idempotente.

CREATE TABLE IF NOT EXISTS inviti_pendenti (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    token           TEXT NOT NULL UNIQUE,           -- token URL-safe univoco
    mittente_id     UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    destinatario    TEXT NOT NULL,                  -- email o telefono
    canale          TEXT NOT NULL DEFAULT 'link'
                        CHECK (canale IN ('email','sms','whatsapp','link')),
    stato           TEXT NOT NULL DEFAULT 'pendente'
                        CHECK (stato IN ('pendente','accettato','scaduto','revocato')),
    documento_id    UUID REFERENCES documenti(id) ON DELETE SET NULL,
    messaggio       TEXT,                           -- testo opzionale mittente
    creato_il       TIMESTAMP NOT NULL DEFAULT NOW(),
    scade_il        TIMESTAMP NOT NULL DEFAULT NOW() + INTERVAL '7 days',
    accettato_il    TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_inviti_token        ON inviti_pendenti(token);
CREATE INDEX IF NOT EXISTS idx_inviti_destinatario ON inviti_pendenti(destinatario);
CREATE INDEX IF NOT EXISTS idx_inviti_mittente     ON inviti_pendenti(mittente_id);
CREATE INDEX IF NOT EXISTS idx_inviti_stato        ON inviti_pendenti(stato);

COMMENT ON TABLE inviti_pendenti IS
    'Inviti inviati a destinatari non ancora registrati su Vemora. '
    'Token valido 7 giorni. Al momento della registrazione, il destinatario '
    'può riscattare gli inviti pendenti collegati al suo email/telefono.';
