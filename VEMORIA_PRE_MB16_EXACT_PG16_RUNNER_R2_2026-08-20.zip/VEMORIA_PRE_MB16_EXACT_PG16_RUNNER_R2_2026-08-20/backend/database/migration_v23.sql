-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V4.5 Performance Patch — Migration V23
-- Indici mancanti identificati in test di carico (3000 doc, 6000 timeline, 4500 search_index)

-- 1. Archivio: indice composito per query proprietario_id + stato + creata_il
CREATE INDEX IF NOT EXISTS idx_memorie_owner_stato_data
    ON memorie(proprietario_id, stato, creata_il DESC)
    WHERE stato = 'attiva';

-- 2. Duplicate detection: indice funzionale su prefisso testo OCR
CREATE INDEX IF NOT EXISTS idx_doc_testo_prefix
    ON documenti(LEFT(testo_grezzo, 200))
    WHERE testo_grezzo IS NOT NULL;

-- 3. Search FTS: aggiunge indice pg_trgm per ILIKE efficiente
-- (fallback se GIN tsvector non usato dalla query ILIKE)
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE INDEX IF NOT EXISTS idx_search_trgm
    ON search_index USING gin(contenuto gin_trgm_ops);

-- 4. Performance stats: indici parziali per COUNT veloci
CREATE INDEX IF NOT EXISTS idx_timeline_count
    ON timeline_event(target_tipo) INCLUDE (id);

CREATE INDEX IF NOT EXISTS idx_insight_count
    ON document_insight(documento_id) INCLUDE (id);

-- 5. Document event: indice su documento_id per hook lookup rapido
CREATE INDEX IF NOT EXISTS idx_doc_event_documento
    ON document_event(documento_id, creato_il DESC);

-- 6. Metadata per utente: lookup preferenze localization
CREATE INDEX IF NOT EXISTS idx_metadata_origine
    ON document_metadata(origine);
