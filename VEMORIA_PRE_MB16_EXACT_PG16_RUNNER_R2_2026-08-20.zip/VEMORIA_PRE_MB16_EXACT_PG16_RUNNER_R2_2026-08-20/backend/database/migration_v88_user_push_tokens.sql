-- VEMORA — Migration V88: Push notification tokens
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
--
-- Registra i token push dei device per utente.
-- Supporta FCM (Android/Web) e APNs (iOS).
-- Integrato con notification_hub: quando un evento viene pubblicato,
-- il push_service inoltra al provider se configurato.

CREATE TABLE IF NOT EXISTS user_push_tokens (
    id              UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id         UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    platform        TEXT        NOT NULL
                                CHECK (platform IN ('ios', 'android', 'web')),
    token           TEXT        NOT NULL,
    device_label    TEXT,                           -- es. "iPhone 14 - Massimo"
    app_version     TEXT,
    stato           TEXT        NOT NULL DEFAULT 'attivo'
                                CHECK (stato IN ('attivo', 'sospeso', 'revocato', 'invalido')),
    last_used_at    TIMESTAMPTZ,
    fallito_count   INTEGER     NOT NULL DEFAULT 0,
    ultimo_errore   TEXT,
    creato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (user_id, platform, token)
);

CREATE INDEX IF NOT EXISTS idx_user_push_tokens_user_active
    ON user_push_tokens(user_id, stato)
    WHERE stato = 'attivo';

COMMENT ON TABLE user_push_tokens IS
    'Token push per device. Rimossi o marcati invalidi se provider restituisce NotRegistered/InvalidToken.';

-- Nota: registrazione migration demandata al migration runner/registry service.
-- Se la migration viene applicata manualmente via SQL puro, usare poi adopt-existing o status nel runner.
