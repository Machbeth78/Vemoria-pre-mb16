-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB12-P0 R1D — Provenance, trusted authority and legacy replay closure.
-- Additive, idempotent migration. Does not modify v176/v177/v178.

BEGIN;

-- Trusted binding between a source card business key and real MB9/MB10/MB11
-- persisted records: authorized source, inventory item revision and evidence.
CREATE TABLE IF NOT EXISTS mb12_p0_source_card_binding (
    source_card_id      TEXT NOT NULL,
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    source_id           UUID NOT NULL REFERENCES authorized_memory_sources(id) ON DELETE CASCADE,
    source_revision_id  UUID NOT NULL REFERENCES authorized_memory_inventory_items(id) ON DELETE CASCADE,
    evidence_id         UUID NOT NULL REFERENCES authorized_memory_activity_log(id) ON DELETE CASCADE,
    content_hash        TEXT NOT NULL DEFAULT '',
    status              TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','revoked','suspended')),
    revoked_at          TIMESTAMPTZ NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, source_card_id)
);

ALTER TABLE mb12_p0_source_card_binding ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb12_p0_source_card_binding FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb12_p0_source_card_binding_owner_policy ON mb12_p0_source_card_binding;
CREATE POLICY mb12_p0_source_card_binding_owner_policy ON mb12_p0_source_card_binding
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

-- Trusted promotion authority registry. Each capability is tied to an
-- actor + device + epoch + owner. The audit ref must exist as an activity log id.
CREATE TABLE IF NOT EXISTS mb12_p0_trusted_promotion_authority (
    actor_id        TEXT NOT NULL,
    device_id       TEXT NOT NULL,
    epoch           TEXT NOT NULL,
    capability      TEXT NOT NULL,
    owner_user_id   UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    status          TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','revoked','suspended','expired')),
    expires_at      TIMESTAMPTZ NULL,
    revoked_at      TIMESTAMPTZ NULL,
    audit_ref       UUID NULL REFERENCES authorized_memory_activity_log(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, actor_id, device_id, epoch, capability)
);

ALTER TABLE mb12_p0_trusted_promotion_authority ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb12_p0_trusted_promotion_authority FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb12_p0_trusted_promotion_authority_owner_policy ON mb12_p0_trusted_promotion_authority;
CREATE POLICY mb12_p0_trusted_promotion_authority_owner_policy ON mb12_p0_trusted_promotion_authority
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

-- Allow the MB12-P0 application role to resolve bindings and verify authority.
GRANT USAGE ON SCHEMA public TO mb12_p0_app;
GRANT SELECT, INSERT ON mb12_p0_source_card_binding TO mb12_p0_app;
GRANT SELECT ON mb12_p0_trusted_promotion_authority TO mb12_p0_app;

COMMIT;
