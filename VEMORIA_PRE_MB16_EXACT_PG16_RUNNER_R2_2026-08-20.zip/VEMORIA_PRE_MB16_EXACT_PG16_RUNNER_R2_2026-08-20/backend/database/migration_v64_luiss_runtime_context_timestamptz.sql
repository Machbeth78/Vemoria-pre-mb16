-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- database/migration_v64_luiss_runtime_context_timestamptz.sql
-- Allinea luiss_runtime_context a TIMESTAMP WITH TIME ZONE per coerenza con le superfici LUISS più recenti.
-- Interpretazione prudente dei valori legacy: i timestamp esistenti vengono trattati come UTC.

ALTER TABLE IF EXISTS luiss_runtime_context
    ALTER COLUMN avviato_il TYPE TIMESTAMP WITH TIME ZONE
    USING (avviato_il AT TIME ZONE 'UTC');

ALTER TABLE IF EXISTS luiss_runtime_context
    ALTER COLUMN aggiornato_il TYPE TIMESTAMP WITH TIME ZONE
    USING (aggiornato_il AT TIME ZONE 'UTC');

ALTER TABLE IF EXISTS luiss_runtime_context
    ALTER COLUMN avviato_il SET DEFAULT NOW();

ALTER TABLE IF EXISTS luiss_runtime_context
    ALTER COLUMN aggiornato_il SET DEFAULT NOW();
