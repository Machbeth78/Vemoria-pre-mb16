-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification,
-- distribution or use is prohibited.
--
-- migration_v110_folder_access_v1.sql
-- Universal Digital Memory Access V1.1 — FASE 3
-- Folder Access Grants: tabella schema-only (CRUD IMPLEMENTED, refresh loop SPEC_ONLY).
--
-- Filosofia:
-- - L'utente concede UNA VOLTA accesso a una cartella/source (Storage Access
--   Framework Android tramite tree_uri persistente, oppure path quando applicabile).
-- - Vemoria memorizza il grant come dichiarazione di autorizzazione + metadata
--   per future refresh manuali.
-- - In V1.1 NESSUN indexing automatico: il refresh è solo "marcato" come
--   richiesto/eseguito; il loop incrementale è SPEC_ONLY.
--
-- Sicurezza:
-- - FK owner_user_id → utenti(id) ON DELETE CASCADE: cancellando l'utente,
--   spariscono i grant (privacy).
-- - status enum stretto con CHECK constraint per evitare valori arbitrari.
-- - revoked_at separato da updated_at per audit log temporale.
-- - source_type validato a livello applicativo contro source_connector_registry.
--   NON un foreign key (il registry è codice, non DB), ma testabile via service.

BEGIN;

-- ===========================================================================
-- folder_access_grants
-- ===========================================================================

CREATE TABLE IF NOT EXISTS folder_access_grants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    -- Owner: identità derivata sempre da JWT current_user, mai dal body.
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,

    -- Source type DEVE essere un source_key del registry V1.1
    -- (es. 'downloads', 'whatsapp', 'documents', 'screenshots', ...).
    -- Validazione applicativa contro source_connector_registry.
    source_type TEXT NOT NULL,

    -- Path o tree_uri persistente.
    -- Android Storage Access Framework: stringa "content://..." con flag persistent.
    -- Desktop/Linux: path assoluto.
    -- iOS: bookmark URL serializzato in base64.
    -- Backend NON deve sapere come interpretarlo: lo gira al client al refresh.
    path TEXT NULL,
    tree_uri TEXT NULL,

    -- Label umana scelta dall'utente (es. "Download lavoro", "WhatsApp Media").
    label TEXT NULL,

    -- Frequenza di refresh richiesta dall'utente.
    -- Valori sentinella; il loop di refresh in V1.1 NON è attivo.
    refresh_frequency TEXT NOT NULL DEFAULT 'manual'
        CHECK (refresh_frequency IN ('manual','daily','weekly','monthly','wifi_only','charging_only','disabled')),

    -- Stato del grant (stretto ENUM via CHECK).
    status TEXT NOT NULL DEFAULT 'authorized'
        CHECK (status IN ('authorized','indexing','indexed','needs_refresh','revoked','error')),

    -- Timeline operativa.
    last_indexed_at TIMESTAMPTZ NULL,
    last_seen_hash TEXT NULL,
    indexed_count INTEGER NOT NULL DEFAULT 0,
    changed_count INTEGER NOT NULL DEFAULT 0,
    deleted_count INTEGER NOT NULL DEFAULT 0,

    -- Errore opzionale (codice + messaggio brevissimo).
    last_error_code TEXT NULL,
    last_error_message TEXT NULL,

    -- Metadata libero (es. priorità, note utente, suggerimenti).
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,

    -- Audit
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revoked_at TIMESTAMPTZ NULL,

    -- Vincolo: almeno uno fra path e tree_uri DEVE essere valorizzato.
    CONSTRAINT chk_fag_path_or_tree CHECK (
        path IS NOT NULL OR tree_uri IS NOT NULL
    ),

    -- Vincolo: revoked → revoked_at DEVE essere valorizzato.
    CONSTRAINT chk_fag_revoked_consistency CHECK (
        (status <> 'revoked') OR (status = 'revoked' AND revoked_at IS NOT NULL)
    )
);

-- Indici di lookup. Tutti filtrati su grant NON revocati per efficienza.
CREATE INDEX IF NOT EXISTS idx_fag_user_status
    ON folder_access_grants(owner_user_id, status)
    WHERE status <> 'revoked';

CREATE INDEX IF NOT EXISTS idx_fag_user_source_type
    ON folder_access_grants(owner_user_id, source_type)
    WHERE status <> 'revoked';

CREATE INDEX IF NOT EXISTS idx_fag_user_created
    ON folder_access_grants(owner_user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_fag_last_indexed
    ON folder_access_grants(last_indexed_at DESC NULLS LAST)
    WHERE status <> 'revoked';


-- ===========================================================================
-- folder_access_audit_log (append-only audit)
-- ===========================================================================
-- Tracciamento eventi sui grant. Append-only per audit GDPR/forense.
-- Non aggiornato mai dopo INSERT.

CREATE TABLE IF NOT EXISTS folder_access_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    grant_id UUID NULL REFERENCES folder_access_grants(id) ON DELETE SET NULL,
    user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,

    action TEXT NOT NULL CHECK (action IN (
        'created','revoked','refresh_requested','refresh_completed',
        'indexed','error','metadata_updated','frequency_changed'
    )),

    -- Snapshot opzionale di info al momento dell'evento.
    snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,

    -- Note umana opzionale.
    note TEXT NULL,

    -- Timestamp evento.
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_fag_audit_user_ts
    ON folder_access_audit_log(user_id, timestamp DESC);

CREATE INDEX IF NOT EXISTS idx_fag_audit_grant_ts
    ON folder_access_audit_log(grant_id, timestamp DESC)
    WHERE grant_id IS NOT NULL;


-- ===========================================================================
-- Trigger updated_at automatico su folder_access_grants
-- ===========================================================================
-- Coerente con la convenzione altre tabelle Vemoria post-V62.

CREATE OR REPLACE FUNCTION trg_folder_access_grants_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS folder_access_grants_set_updated_at ON folder_access_grants;
CREATE TRIGGER folder_access_grants_set_updated_at
    BEFORE UPDATE ON folder_access_grants
    FOR EACH ROW
    EXECUTE FUNCTION trg_folder_access_grants_set_updated_at();


COMMIT;

-- Note per Devin (runtime):
-- 1. Per Android, persistere flag FLAG_GRANT_PERSISTABLE_URI_PERMISSION lato app.
--    Il tree_uri DEVE essere ottenuto via ACTION_OPEN_DOCUMENT_TREE.
-- 2. In V1.1 il refresh loop NON è attivo. Una eventuale chiamata POST
--    /api/v1/sources/folders/{id}/refresh in V1.1 si limita a:
--      - aggiornare status='indexing' poi 'needs_refresh' o 'indexed'
--      - NON eseguire scansione filesystem reale
--    Il vero indexing arriverà in versione successiva.
-- 3. La cancellazione grant è SOFT (status='revoked' + revoked_at).
--    Hard-delete ammesso via endpoint dedicato con flag esplicito hard=true.
