"""
VEMORA
Creatore e proprietario: Devoti Massimo
Copyright (c) 2026 Devoti Massimo
Tutti i diritti riservati.
Uso consentito solo su autorizzazione del proprietario.
"""
"""
VEMORA — Connessione Database
Gestione sessioni SQLAlchemy per PostgreSQL
"""

import logging
import os

from sqlalchemy import create_engine, text, event
from sqlalchemy.orm import sessionmaker, Session
from typing import Generator

from services.migration_registry_service import log_registry_health
from services.luiss_schema_contract_service import log_luiss_schema_contract_health

logger = logging.getLogger("vemora.db")

# ============================================================
# URL connessione — letta da variabile d'ambiente
# ============================================================
DATABASE_URL = os.getenv("VEMORA_DATABASE_URL")
LEGACY_DATABASE_URL = os.getenv("DATABASE_URL")

if not DATABASE_URL and LEGACY_DATABASE_URL:
    DATABASE_URL = LEGACY_DATABASE_URL
    logger.warning(
        "Usata variabile legacy DATABASE_URL. "
        "Migrare a VEMORA_DATABASE_URL per coerenza con il backend."
    )

if not DATABASE_URL:
    # Nessuna password o credenziale incorporata nel codice. In sviluppo locale
    # PostgreSQL può usare autenticazione peer/pgpass; in produzione la variabile
    # VEMORA_DATABASE_URL è obbligatoria.
    if os.getenv("VEMORIA_ENV", "development").lower() in {"production", "prod"}:
        raise RuntimeError("VEMORA_DATABASE_URL_obbligatoria_in_produzione")
    DATABASE_URL = "postgresql://localhost:5432/vemora_db"
    logger.warning("VEMORA_DATABASE_URL assente: uso DSN locale senza credenziali incorporate.")

# MB13-P1 production boundary: the API process uses only the API DSN.
# The worker DSN must never be loaded by the API module.
MB13_P1_API_DATABASE_URL = os.getenv("VEMORA_MB13_P1_API_DATABASE_URL")
MB13_P2_EXECUTOR_DATABASE_URL = os.getenv("VEMORA_MB13_P2_EXECUTOR_DATABASE_URL")

def _require_mb13_p1_api_url() -> None:
    if not MB13_P1_API_DATABASE_URL:
        raise RuntimeError("VEMORA_MB13_P1_API_DATABASE_URL obbligatoria per MB13-P1")

def _require_mb13_p2_executor_url() -> None:
    if not MB13_P2_EXECUTOR_DATABASE_URL:
        raise RuntimeError("VEMORA_MB13_P2_EXECUTOR_DATABASE_URL obbligatoria per MB13-P2 executor")

mb13_p1_api_engine = (
    create_engine(
        MB13_P1_API_DATABASE_URL,
        pool_pre_ping=True,
        pool_size=5,
        max_overflow=5,
        echo=False,
    )
    if MB13_P1_API_DATABASE_URL
    else None
)

SessionLocalMb13P1Api = (
    sessionmaker(autocommit=False, autoflush=False, bind=mb13_p1_api_engine)
    if mb13_p1_api_engine
    else None
)

mb13_p2_executor_engine = (
    create_engine(
        MB13_P2_EXECUTOR_DATABASE_URL,
        pool_pre_ping=True,
        pool_size=5,
        max_overflow=5,
        echo=False,
    )
    if MB13_P2_EXECUTOR_DATABASE_URL
    else None
)

SessionLocalMb13P2Executor = (
    sessionmaker(autocommit=False, autoflush=False, bind=mb13_p2_executor_engine)
    if mb13_p2_executor_engine
    else None
)


def get_mb13_p1_api_db():
    if SessionLocalMb13P1Api is None:
        raise RuntimeError("VEMORA_MB13_P1_API_DATABASE_URL obbligatoria")
    db = SessionLocalMb13P1Api()
    try:
        yield db
    finally:
        db.close()


def get_mb13_p2_executor_db():
    if SessionLocalMb13P2Executor is None:
        raise RuntimeError("VEMORA_MB13_P2_EXECUTOR_DATABASE_URL obbligatoria")
    db = SessionLocalMb13P2Executor()
    try:
        yield db
    finally:
        db.close()


engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,      # verifica connessione prima di usarla
    pool_size=10,            # connessioni nel pool
    max_overflow=20,         # connessioni extra in picco
    echo=False               # True per debug SQL
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)


def bind_authenticated_request_context(
    db: Session,
    *,
    owner_id: str | None,
    device_id: str | None = None,
) -> None:
    """Bind authenticated request authority to the SQLAlchemy session.

    ``app.owner_id``/``app.device_id`` are transaction-local PostgreSQL GUCs.
    Session metadata survives a commit, and the ``after_begin`` listener below
    reapplies the same authority to the next transaction. This makes RLS a
    request invariant instead of something every service must remember to set.
    """
    owner = str(owner_id or '').strip()
    device = str(device_id or '').strip()
    if not owner:
        raise RuntimeError('authenticated_owner_required_for_db_context')
    db.info['vemoria_authenticated_owner_id'] = owner
    db.info['vemoria_authenticated_device_id'] = device or None

    bind = db.get_bind()
    if bind is not None and bind.dialect.name == 'postgresql':
        # Authentication queries may already have opened the current transaction,
        # so apply the GUC immediately as well as on future transaction begins.
        db.execute(text("SELECT set_config('app.owner_id', :owner, true)"), {'owner': owner})
        db.execute(text("SELECT set_config('app.device_id', :device, true)"), {'device': device})


def authenticated_request_device_id(db: Session) -> str | None:
    value = db.info.get('vemoria_authenticated_device_id')
    value = str(value or '').strip()
    return value or None


def bind_owner_operation_context(db: Session, *, owner_id: str) -> None:
    """Bind one explicit owner to an internal owner-scoped DB operation.

    Unlike :func:`bind_authenticated_request_context`, this helper does not
    invent or clear device authority.  It exists for background/internal
    services that already receive an owner id from a trusted caller and need
    FORCE-RLS tables to remain usable outside the HTTP dependency graph.

    A SQLAlchemy session already bound to a different owner fails closed.
    Reusing one owner-bound session across owners would otherwise turn RLS
    context into ambient, cross-owner authority.
    """
    owner = str(owner_id or '').strip()
    if not owner:
        raise RuntimeError('owner_required_for_db_operation_context')
    existing = str(db.info.get('vemoria_authenticated_owner_id') or '').strip()
    if existing and existing != owner:
        raise RuntimeError('owner_operation_context_mismatch')
    db.info['vemoria_authenticated_owner_id'] = owner

    bind = db.get_bind()
    if bind is not None and bind.dialect.name == 'postgresql':
        db.execute(text("SELECT set_config('app.owner_id', :owner, true)"), {'owner': owner})


@event.listens_for(Session, 'after_begin')
def _reapply_authenticated_request_context(session: Session, transaction, connection) -> None:
    """Reapply request-local security GUCs after commit/new transaction."""
    if connection.dialect.name != 'postgresql':
        return
    owner = str(session.info.get('vemoria_authenticated_owner_id') or '').strip()
    if not owner:
        return
    device = str(session.info.get('vemoria_authenticated_device_id') or '').strip()
    connection.execute(text("SELECT set_config('app.owner_id', :owner, true)"), {'owner': owner})
    connection.execute(text("SELECT set_config('app.device_id', :device, true)"), {'device': device})


def _database_role_security(db_engine, *, label: str) -> dict[str, object]:
    """Return the actual PostgreSQL role security attributes for an engine."""
    if db_engine is None:
        raise RuntimeError(f'{label}_database_engine_missing')
    with db_engine.connect() as conn:
        row = conn.execute(text("""
            SELECT current_user AS role_name, r.rolsuper, r.rolbypassrls
            FROM pg_roles r
            WHERE r.rolname = current_user
        """)).mappings().one()
    return {
        'role_name': str(row['role_name']),
        'superuser': bool(row['rolsuper']),
        'bypassrls': bool(row['rolbypassrls']),
    }


def _require_role_cannot_bypass_rls(db_engine, *, label: str) -> dict[str, object]:
    """Fail closed when the connected role can bypass PostgreSQL RLS."""
    info = _database_role_security(db_engine, label=label)
    if info['superuser'] or info['bypassrls']:
        raise RuntimeError(
            f"{label}_database_role_can_bypass_rls:"
            f"{info['role_name']}:superuser={info['superuser']}:bypassrls={info['bypassrls']}"
        )
    logger.info('%s DB role verified non-bypass: %s', label, info['role_name'])
    return info


def verify_runtime_database_roles() -> None:
    """Verify RLS is meaningful for the roles used by the running product.

    Main/API role enforcement is mandatory in production (or when explicitly
    requested in other environments). The MB13 executor is always checked when
    configured because it processes owner-scoped consequential work and must
    never obtain SUPERUSER/BYPASSRLS authority.
    """
    env = os.getenv('VEMORIA_ENV', 'development').strip().lower()
    strict_main = env in {'production', 'prod'} or os.getenv('VEMORIA_ENFORCE_RLS_ROLE', '').strip() == '1'
    if strict_main:
        _require_role_cannot_bypass_rls(engine, label='main')
        if mb13_p1_api_engine is not None:
            _require_role_cannot_bypass_rls(mb13_p1_api_engine, label='mb13_p1_api')
    elif engine.url.get_backend_name() == 'postgresql':
        # Development may intentionally use a local superuser, but make the
        # weakened defense explicit instead of silently calling RLS proven.
        info = _database_role_security(engine, label='main')
        if info['superuser'] or info['bypassrls']:
            logger.warning('Development DB role bypasses RLS: %s', info['role_name'])

    if mb13_p2_executor_engine is not None:
        _require_role_cannot_bypass_rls(mb13_p2_executor_engine, label='mb13_p2_executor')


def verifica_connessione_db() -> None:
    """
    Verifica la raggiungibilità del DB al bootstrap.

    NON crea tabelle. NON esegue migration.
    Se le migration SQL non sono state applicate prima dell'avvio,
    il backend si avvierà ma gli endpoint non-ORM crasheranno
    su 'relation X does not exist'.

    Per inizializzare il DB: seguire SETUP.md e CHECKLIST_BOOTSTRAP.md.
    """
    try:
        backend_name = engine.url.get_backend_name()
        if backend_name != 'postgresql':
            raise RuntimeError(
                'Vemora richiede PostgreSQL come backend ufficiale. '
                f'Dialect rilevato: {backend_name}'
            )
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        verify_runtime_database_roles()
        logger.info("Vemora DB: connessione verificata.")
        logger.warning(
            "Vemora DB: verifica connessione OK. "
            "Le migration SQL devono essere già state applicate "
            "(vedi SETUP.md). Il backend NON crea tabelle automaticamente."
        )
        log_registry_health(engine)
        log_luiss_schema_contract_health(engine)
        # MB13-P1 production boundary: the API process must not load worker credentials.
        _require_mb13_p1_api_url()
        if MB13_P1_API_DATABASE_URL:
            with mb13_p1_api_engine.connect() as conn:
                conn.execute(text("SELECT 1"))
        logger.info("MB13-P1 production boundary connections verified.")
    except Exception as exc:
        logger.critical(
            "Vemora DB: impossibile raggiungere il database. "
            "Controllare VEMORA_DATABASE_URL e che PostgreSQL sia attivo. "
            "Errore: %s", exc
        )
        raise


def ottieni_db() -> Generator[Session, None, None]:
    """
    Dependency FastAPI — fornisce una sessione DB per request.
    La sessione viene chiusa automaticamente alla fine della request.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
