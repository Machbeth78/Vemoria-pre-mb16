-- Vemoria Gate05 R1 — Recupero / Backup / Capsula
-- Additiva, owner-scoped, no plaintext server-side.
-- Runtime PostgreSQL reale: NON ESEGUITO in questo pacchetto statico.

BEGIN;

-- 1. Stato radice recuperabile. Server vede solo materiale pubblico e fingerprint.
CREATE TABLE IF NOT EXISTS owner_root_recovery_state (
    utente_id UUID PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    root_algorithm TEXT NOT NULL DEFAULT 'ed25519'
        CHECK (root_algorithm IN ('ed25519')),
    root_public_key_b64 TEXT NOT NULL,
    root_public_fingerprint TEXT NOT NULL,
    root_epoch INTEGER NOT NULL DEFAULT 1 CHECK (root_epoch >= 1),
    latest_device_set_digest TEXT NULL,
    export_policy TEXT NOT NULL DEFAULT 'encrypted_export_only'
        CHECK (export_policy IN ('encrypted_export_only')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_owner_root_recovery_fingerprint
    ON owner_root_recovery_state(root_public_fingerprint);

-- 2. Export cifrati della radice. Blob opaco, mai private key in chiaro.
CREATE TABLE IF NOT EXISTS owner_root_encrypted_export (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    export_id TEXT NOT NULL,
    root_public_fingerprint TEXT NOT NULL,
    envelope_version TEXT NOT NULL DEFAULT 'vemoria.root_export.v1',
    encrypted_root_blob BYTEA NOT NULL,
    export_blob_sha256 TEXT NOT NULL,
    kdf_algorithm TEXT NOT NULL DEFAULT 'argon2id'
        CHECK (kdf_algorithm IN ('argon2id')),
    kdf_params_json JSONB NOT NULL,
    status TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'revoked')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revoked_at TIMESTAMPTZ NULL,
    UNIQUE (utente_id, export_id)
);

CREATE INDEX IF NOT EXISTS idx_owner_root_export_owner_status
    ON owner_root_encrypted_export(utente_id, status, created_at DESC);

-- 3. Anchor device-set Gate05. Epoch e digest impediscono rollback logico.
CREATE TABLE IF NOT EXISTS owner_device_set_epoch_anchor (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    epoch INTEGER NOT NULL CHECK (epoch >= 1),
    digest TEXT NOT NULL,
    previous_digest TEXT NULL,
    signed_device_set_json JSONB NOT NULL,
    active_device_count INTEGER NOT NULL DEFAULT 0 CHECK (active_device_count >= 0),
    revoked_device_count INTEGER NOT NULL DEFAULT 0 CHECK (revoked_device_count >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, epoch),
    UNIQUE (utente_id, digest)
);

CREATE INDEX IF NOT EXISTS idx_owner_device_set_anchor_latest
    ON owner_device_set_epoch_anchor(utente_id, epoch DESC);

-- 4. Manifest backup recuperabile V2. Server vede hash e wrapper opachi.
CREATE TABLE IF NOT EXISTS owner_backup_recovery_manifest_v2 (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    backup_id TEXT NOT NULL,
    manifest_ciphertext_sha256 TEXT NOT NULL,
    wrapped_keys_json JSONB NOT NULL,
    includes_adaptive_profile BOOLEAN NOT NULL DEFAULT FALSE,
    adaptive_profile_policy_version TEXT NULL,
    status TEXT NOT NULL DEFAULT 'prepared'
        CHECK (status IN ('prepared', 'sealed', 'restored', 'revoked', 'failed')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    restored_at TIMESTAMPTZ NULL,
    revoked_at TIMESTAMPTZ NULL,
    UNIQUE (utente_id, backup_id)
);

CREATE INDEX IF NOT EXISTS idx_owner_backup_recovery_owner_status
    ON owner_backup_recovery_manifest_v2(utente_id, status, created_at DESC);

-- 5. Profilo adattivo: registry ciphertext-only per categoria.
CREATE TABLE IF NOT EXISTS owner_adaptive_profile_bundle_registry (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    bundle_id TEXT NOT NULL,
    category TEXT NOT NULL CHECK (category IN (
        'voice', 'command_style', 'operational_habits', 'relations',
        'preferences', 'routines', 'historical_corrections',
        'movement_behavior', 'ux_configuration'
    )),
    policy_version TEXT NOT NULL DEFAULT 'adaptive_profile.v1',
    root_required BOOLEAN NOT NULL DEFAULT TRUE CHECK (root_required = TRUE),
    explicit_consent BOOLEAN NOT NULL DEFAULT TRUE CHECK (explicit_consent = TRUE),
    ciphertext_sha256 TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'revoked', 'deleted')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revoked_at TIMESTAMPTZ NULL,
    deleted_at TIMESTAMPTZ NULL,
    UNIQUE (utente_id, bundle_id, category)
);

CREATE INDEX IF NOT EXISTS idx_owner_adaptive_profile_owner_status
    ON owner_adaptive_profile_bundle_registry(utente_id, status, category);

-- 6. Capsula Pro Shamir 2-su-3. Server registra solo metadata e digest quote.
CREATE TABLE IF NOT EXISTS owner_capsula_share_registry (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    recovery_set_id TEXT NOT NULL,
    threshold INTEGER NOT NULL DEFAULT 2 CHECK (threshold = 2),
    total_shares INTEGER NOT NULL DEFAULT 3 CHECK (total_shares = 3),
    share_label TEXT NOT NULL,
    share_digest TEXT NOT NULL,
    storage_hint TEXT NULL,
    status TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'lost', 'replaced', 'revoked')),
    last_verified_at TIMESTAMPTZ NULL,
    next_check_due_at TIMESTAMPTZ NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, recovery_set_id, share_label)
);

CREATE INDEX IF NOT EXISTS idx_owner_capsula_share_check_due
    ON owner_capsula_share_registry(utente_id, next_check_due_at)
    WHERE status = 'active';

-- 7. Registro eventi recupero, separato da prova Fabric.
CREATE TABLE IF NOT EXISTS owner_recovery_event_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    event_kind TEXT NOT NULL CHECK (event_kind IN (
        'root_created', 'root_exported_encrypted', 'device_certified',
        'device_revoked', 'backup_manifest_sealed', 'restore_started',
        'restore_completed', 'adaptive_profile_restored', 'adaptive_profile_category_revoked',
        'capsula_share_verified', 'capsula_share_replaced', 'recovery_failed_closed'
    )),
    event_authority TEXT NOT NULL CHECK (event_authority IN (
        'owner_root', 'owner_device', 'owner_confirmed', 'system_technical'
    )),
    related_digest TEXT NULL,
    metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_owner_recovery_event_owner_time
    ON owner_recovery_event_log(utente_id, created_at DESC);

COMMIT;
