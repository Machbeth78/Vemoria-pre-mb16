-- Vemoria Gate06 R1K P7 Commercial/Distribution static completion
-- Runtime remains NON_ESEGUITO. This migration records metadata only.

CREATE TABLE IF NOT EXISTS gate06_r1k_p7_commercial_distribution_static_completion (
    id INTEGER PRIMARY KEY,
    gate TEXT NOT NULL,
    version TEXT NOT NULL,
    static_completion_state TEXT NOT NULL,
    runtime_real TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    notes TEXT NOT NULL
);

INSERT INTO gate06_r1k_p7_commercial_distribution_static_completion (
    id, gate, version, static_completion_state, runtime_real, notes
) VALUES (
    1,
    'GATE06_R1K_P7_COMMERCIAL_DISTRIBUTION_STATIC_COMPLETION',
    'GATE06_R1K_P7_COMMERCIAL_DISTRIBUTION_STATIC_COMPLETION_V150_2026-06-19',
    'STATIC_COMPLETED_RUNTIME_DEFERRED',
    'NON_ESEGUITO',
    'Static completion for VC-075, VC-077, VC-089 and VC-090. Commercial/distribution contracts are closed statically; no entitlement without valid title, package checksum required, Desktop Companion runtime deferred. No real billing, entitlement, package install, Desktop Companion, PostgreSQL or Android/Flutter runtime executed.'
) ON CONFLICT(id) DO UPDATE SET
    version=excluded.version,
    static_completion_state=excluded.static_completion_state,
    runtime_real=excluded.runtime_real,
    notes=excluded.notes;
