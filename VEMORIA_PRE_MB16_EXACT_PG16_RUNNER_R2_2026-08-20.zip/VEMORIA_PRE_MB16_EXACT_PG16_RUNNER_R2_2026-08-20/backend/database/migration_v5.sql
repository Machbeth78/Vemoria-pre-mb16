-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- ============================================================
-- VEMORA — Migration V5 — Relazioni documento
-- ============================================================
CREATE TABLE IF NOT EXISTS relazioni_documento (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id    UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    tipo_relazione  TEXT NOT NULL,   -- persona | luogo | evento
    riferimento     TEXT NOT NULL,   -- nome, luogo, descrizione evento
    note            TEXT,
    creato_il       TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_relazioni_documento ON relazioni_documento(documento_id);
CREATE INDEX IF NOT EXISTS idx_relazioni_tipo      ON relazioni_documento(tipo_relazione);
