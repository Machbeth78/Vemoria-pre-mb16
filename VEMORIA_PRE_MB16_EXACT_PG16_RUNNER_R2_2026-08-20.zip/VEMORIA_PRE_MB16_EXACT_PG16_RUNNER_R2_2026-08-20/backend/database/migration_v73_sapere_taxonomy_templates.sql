-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V73 — Sapere taxonomy + template items canonici
-- Obiettivo:
-- 1) normalizzare nel DB la tassonomia e i template semantici statici del catalogo Sapere
-- 2) rendere queryabili audience, controlli, next actions e altri gruppi della logica edilizia/core
-- 3) mantenere compatibilità col runtime esistente e col sync catalogo

CREATE TABLE IF NOT EXISTS sapere_tassonomie (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id            TEXT NOT NULL,
    sapere_id               TEXT NULL,
    locale                  TEXT NOT NULL DEFAULT 'it-IT',
    domain                  TEXT NOT NULL DEFAULT 'core',
    macro_category          TEXT NULL,
    family                  TEXT NULL,
    subfamily               TEXT NULL,
    metadata_tassonomia     JSONB NOT NULL DEFAULT '{}'::jsonb,
    source_pack_id          TEXT NULL,
    source_pack_version     TEXT NULL,
    source_manifest_version TEXT NULL,
    source_entry_index      INTEGER NULL,
    source_checksum         TEXT NULL,
    attivo                  BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_sapere_tassonomie_documento_locale_domain
    ON sapere_tassonomie (documento_id, locale, domain);

CREATE INDEX IF NOT EXISTS idx_sapere_tassonomie_lookup
    ON sapere_tassonomie (documento_id, locale, domain)
    WHERE attivo = TRUE;

CREATE INDEX IF NOT EXISTS idx_sapere_tassonomie_macro
    ON sapere_tassonomie (macro_category, family, subfamily, locale, domain)
    WHERE attivo = TRUE;

CREATE INDEX IF NOT EXISTS idx_sapere_tassonomie_metadata
    ON sapere_tassonomie USING GIN (metadata_tassonomia);

CREATE TABLE IF NOT EXISTS sapere_template_items (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id            TEXT NOT NULL,
    sapere_id               TEXT NULL,
    locale                  TEXT NOT NULL DEFAULT 'it-IT',
    domain                  TEXT NOT NULL DEFAULT 'core',
    item_group              TEXT NOT NULL,
    item_key                TEXT NOT NULL,
    item_text               TEXT NOT NULL,
    item_rank               INTEGER NOT NULL DEFAULT 0,
    metadata_item           JSONB NOT NULL DEFAULT '{}'::jsonb,
    source_pack_id          TEXT NULL,
    source_pack_version     TEXT NULL,
    source_manifest_version TEXT NULL,
    source_entry_index      INTEGER NULL,
    source_checksum         TEXT NULL,
    attivo                  BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_sapere_template_items_doc_group_key_locale_domain
    ON sapere_template_items (documento_id, locale, domain, item_group, item_key);

CREATE INDEX IF NOT EXISTS idx_sapere_template_items_lookup
    ON sapere_template_items (documento_id, locale, domain, item_group, item_rank)
    WHERE attivo = TRUE;

CREATE INDEX IF NOT EXISTS idx_sapere_template_items_pack
    ON sapere_template_items (source_pack_id, locale, domain);

CREATE INDEX IF NOT EXISTS idx_sapere_template_items_metadata
    ON sapere_template_items USING GIN (metadata_item);
