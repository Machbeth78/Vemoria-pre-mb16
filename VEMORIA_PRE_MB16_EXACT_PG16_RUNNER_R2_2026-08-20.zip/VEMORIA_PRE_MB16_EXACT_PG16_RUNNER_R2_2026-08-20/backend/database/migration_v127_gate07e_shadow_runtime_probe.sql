-- Vemoria Gate07E — audit shadow feature-flagged e preparazione runtime probe.
-- Additiva. Nessun consumer reattivo/outbox, nessuna timeline/ricerca/Cerebro.
BEGIN;

CREATE TABLE IF NOT EXISTS canonical_shadow_activation_audit (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    run_id UUID NOT NULL,
    source_content_id_hash TEXT NOT NULL CHECK (source_content_id_hash ~ '^[0-9a-f]{64}$'),
    canonical_content_id TEXT,
    operation_id TEXT,
    mode TEXT NOT NULL CHECK (mode IN ('OFF','SHADOW','STRICT_PROBE')),
    status TEXT NOT NULL CHECK (status IN ('DISABLED','OWNER_NOT_ALLOWED','MATCH','MISMATCH','FAILED')),
    error_code TEXT,
    event_count INTEGER NOT NULL DEFAULT 0 CHECK (event_count >= 0),
    projection_lamport_clock BIGINT CHECK (projection_lamport_clock IS NULL OR projection_lamport_clock >= 0),
    recorded_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY(owner_user_id, run_id),
    CHECK (canonical_content_id IS NULL OR canonical_content_id ~ '^cnt_[0-9a-f]{64}$'),
    CHECK (error_code IS NULL OR length(error_code) <= 120)
);

CREATE INDEX IF NOT EXISTS idx_canonical_shadow_audit_owner_status
    ON canonical_shadow_activation_audit(owner_user_id, status, recorded_at DESC);
CREATE INDEX IF NOT EXISTS idx_canonical_shadow_audit_owner_operation
    ON canonical_shadow_activation_audit(owner_user_id, operation_id)
    WHERE operation_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_canonical_shadow_audit_source_hash
    ON canonical_shadow_activation_audit(owner_user_id, source_content_id_hash, recorded_at DESC);

ALTER TABLE canonical_shadow_activation_audit ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS canonical_shadow_activation_audit_owner_policy
    ON canonical_shadow_activation_audit;
CREATE POLICY canonical_shadow_activation_audit_owner_policy
    ON canonical_shadow_activation_audit
    USING (owner_user_id::text = current_setting('app.owner_id', true))
    WITH CHECK (owner_user_id::text = current_setting('app.owner_id', true));

COMMENT ON TABLE canonical_shadow_activation_audit IS
    'Gate07E rollout telemetry only: no raw path, no description, no canonical truth.';
COMMENT ON COLUMN canonical_shadow_activation_audit.source_content_id_hash IS
    'Owner-salted SHA-256 of legacy source_content_id; raw identifier is not stored.';

COMMIT;
