-- Vemoria PRE-MB16 — live email forwarding convergence into canonical MB9.
BEGIN;

ALTER TABLE utenti
    ADD COLUMN IF NOT EXISTS email_source_connection_id UUID NULL
    REFERENCES source_connections(id) ON DELETE SET NULL;

ALTER TABLE email_memora
    ADD COLUMN IF NOT EXISTS source_kind TEXT NOT NULL DEFAULT 'email',
    ADD COLUMN IF NOT EXISTS source_evidence JSONB NOT NULL DEFAULT '{}'::jsonb;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'email_memora_source_kind_check'
          AND conrelid = 'email_memora'::regclass
    ) THEN
        ALTER TABLE email_memora
            ADD CONSTRAINT email_memora_source_kind_check
            CHECK (source_kind IN ('email','pec_candidate'));
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS email_canonical_ingest_outbox (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    email_id UUID NOT NULL REFERENCES email_memora(id) ON DELETE CASCADE,
    source_connection_id UUID NOT NULL REFERENCES source_connections(id) ON DELETE RESTRICT,
    state TEXT NOT NULL DEFAULT 'PENDING'
        CHECK (state IN ('PENDING','RETRY_PENDING','COMPLETED','BLOCKED_CONSENT','FAILED')),
    attempt_count INTEGER NOT NULL DEFAULT 0 CHECK (attempt_count >= 0),
    next_retry_at TIMESTAMPTZ NULL,
    canonical_source_item_pk UUID NULL,
    last_error_code TEXT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ NULL,
    UNIQUE(owner_id, email_id)
);

CREATE INDEX IF NOT EXISTS idx_email_canonical_outbox_owner_pending
    ON email_canonical_ingest_outbox(owner_id, next_retry_at, created_at)
    WHERE state IN ('PENDING','RETRY_PENDING');

ALTER TABLE email_canonical_ingest_outbox ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_canonical_ingest_outbox FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS email_canonical_ingest_outbox_owner_policy ON email_canonical_ingest_outbox;
CREATE POLICY email_canonical_ingest_outbox_owner_policy
    ON email_canonical_ingest_outbox
    FOR ALL
    USING (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

COMMENT ON COLUMN email_memora.source_kind IS
    'email or pec_candidate. pec_candidate is heuristic transport classification only, never legal/certificate verification.';
COMMENT ON COLUMN email_memora.source_evidence IS
    'Non-secret structural signals supporting source_kind; certification state remains NOT_VERIFIED until a dedicated verifier succeeds.';
COMMENT ON TABLE email_canonical_ingest_outbox IS
    'Durable anti-loss bridge from real inbound email rows to canonical MB9 intake after owner source consent.';

COMMIT;
