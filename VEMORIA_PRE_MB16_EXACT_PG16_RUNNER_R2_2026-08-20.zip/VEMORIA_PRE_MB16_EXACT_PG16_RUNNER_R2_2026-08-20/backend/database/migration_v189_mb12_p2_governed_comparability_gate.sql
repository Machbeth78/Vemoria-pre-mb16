-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- MB12-P2 R1 — governed comparability gate.
-- No ranking, recommendation, winner selection or implicit FX conversion.

BEGIN;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb12_p2_app') THEN
        CREATE ROLE mb12_p2_app NOLOGIN;
    END IF;
END
$$;

CREATE TABLE IF NOT EXISTS public.mb12_p2_comparability_assessment (
    owner_user_id      UUID NOT NULL,
    comparison_id      UUID NOT NULL,
    stable_id          TEXT NOT NULL,
    current_revision   INTEGER NOT NULL DEFAULT 1,
    state              TEXT NOT NULL,
    payload_hash       TEXT NOT NULL,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, comparison_id),
    UNIQUE (owner_user_id, stable_id),
    CONSTRAINT ck_mb12_p2_stable_id_nonempty CHECK (length(trim(stable_id)) > 0),
    CONSTRAINT ck_mb12_p2_state CHECK (state IN ('comparable','not_comparable','incomplete','revoked')),
    CONSTRAINT ck_mb12_p2_revision_positive CHECK (current_revision >= 1)
);

CREATE TABLE IF NOT EXISTS public.mb12_p2_comparability_revision (
    owner_user_id      UUID NOT NULL,
    comparison_id      UUID NOT NULL,
    revision           INTEGER NOT NULL,
    state              TEXT NOT NULL,
    payload_hash       TEXT NOT NULL,
    request_payload    JSONB NOT NULL,
    result_payload     JSONB NOT NULL,
    dossier_refs       JSONB NOT NULL,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, comparison_id, revision),
    CONSTRAINT fk_mb12_p2_revision_assessment
        FOREIGN KEY (owner_user_id, comparison_id)
        REFERENCES public.mb12_p2_comparability_assessment(owner_user_id, comparison_id)
        ON DELETE RESTRICT,
    CONSTRAINT ck_mb12_p2_revision_state CHECK (state IN ('comparable','not_comparable','incomplete','revoked')),
    CONSTRAINT ck_mb12_p2_revision_positive_2 CHECK (revision >= 1),
    CONSTRAINT ck_mb12_p2_request_object CHECK (jsonb_typeof(request_payload) = 'object'),
    CONSTRAINT ck_mb12_p2_result_object CHECK (jsonb_typeof(result_payload) = 'object'),
    CONSTRAINT ck_mb12_p2_dossier_refs_array CHECK (jsonb_typeof(dossier_refs) = 'array')
);

CREATE TABLE IF NOT EXISTS public.mb12_p2_comparability_item (
    owner_user_id         UUID NOT NULL,
    comparison_id         UUID NOT NULL,
    revision              INTEGER NOT NULL,
    dossier_id            UUID NOT NULL,
    dossier_revision      INTEGER NOT NULL,
    dossier_payload_hash  TEXT NOT NULL,
    item_payload           JSONB NOT NULL,
    created_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, comparison_id, revision, dossier_id),
    CONSTRAINT fk_mb12_p2_item_revision
        FOREIGN KEY (owner_user_id, comparison_id, revision)
        REFERENCES public.mb12_p2_comparability_revision(owner_user_id, comparison_id, revision)
        ON DELETE RESTRICT,
    CONSTRAINT ck_mb12_p2_item_payload_object CHECK (jsonb_typeof(item_payload) = 'object'),
    CONSTRAINT ck_mb12_p2_item_revision_positive CHECK (dossier_revision >= 1)
);

CREATE INDEX IF NOT EXISTS ix_mb12_p2_assessment_owner_state
    ON public.mb12_p2_comparability_assessment(owner_user_id, state, updated_at DESC);
CREATE INDEX IF NOT EXISTS ix_mb12_p2_revision_owner_comparison
    ON public.mb12_p2_comparability_revision(owner_user_id, comparison_id, revision DESC);
CREATE INDEX IF NOT EXISTS ix_mb12_p2_item_owner_dossier
    ON public.mb12_p2_comparability_item(owner_user_id, dossier_id, dossier_revision DESC);

ALTER TABLE public.mb12_p2_comparability_assessment ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p2_comparability_assessment FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p2_comparability_revision ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p2_comparability_revision FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p2_comparability_item ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p2_comparability_item FORCE ROW LEVEL SECURITY;

DO $$
DECLARE
    table_name TEXT;
BEGIN
    FOREACH table_name IN ARRAY ARRAY[
        'mb12_p2_comparability_assessment',
        'mb12_p2_comparability_revision',
        'mb12_p2_comparability_item'
    ] LOOP
        EXECUTE format('DROP POLICY IF EXISTS mb12_p2_owner_isolation ON public.%I', table_name);
        EXECUTE format(
            'CREATE POLICY mb12_p2_owner_isolation ON public.%I '
            'USING (owner_user_id = NULLIF(current_setting(''app.owner_id'', true), '''')::uuid) '
            'WITH CHECK (owner_user_id = NULLIF(current_setting(''app.owner_id'', true), '''')::uuid)',
            table_name
        );
    END LOOP;
END
$$;

CREATE OR REPLACE FUNCTION public.mb12_p2_history_immutable()
RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb12_p2_history_is_append_only';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb12_p2_history_immutable() FROM PUBLIC;

DROP TRIGGER IF EXISTS trg_mb12_p2_revision_immutable ON public.mb12_p2_comparability_revision;
CREATE TRIGGER trg_mb12_p2_revision_immutable
BEFORE UPDATE OR DELETE ON public.mb12_p2_comparability_revision
FOR EACH ROW EXECUTE FUNCTION public.mb12_p2_history_immutable();

DROP TRIGGER IF EXISTS trg_mb12_p2_item_immutable ON public.mb12_p2_comparability_item;
CREATE TRIGGER trg_mb12_p2_item_immutable
BEFORE UPDATE OR DELETE ON public.mb12_p2_comparability_item
FOR EACH ROW EXECUTE FUNCTION public.mb12_p2_history_immutable();

CREATE OR REPLACE FUNCTION public.mb12_p2_write_assessment(
    p_comparison_id UUID,
    p_stable_id TEXT,
    p_state TEXT,
    p_request_payload JSONB,
    p_result_payload JSONB,
    p_dossier_refs JSONB,
    p_items JSONB
) RETURNS TABLE(comparison_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb12_p2_comparability_assessment%ROWTYPE;
    v_revision INTEGER;
    v_payload_hash TEXT;
    v_ref JSONB;
    v_item JSONB;
    v_source_ref JSONB;
    v_dossier_revision public.mb12_p1_offer_contract_revision%ROWTYPE;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p2_authenticated_owner_missing';
    END IF;
    IF p_comparison_id IS NULL OR length(trim(COALESCE(p_stable_id, ''))) = 0 OR length(p_stable_id) > 200 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p2_identity_invalid';
    END IF;
    IF p_state NOT IN ('comparable','not_comparable','incomplete','revoked') THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p2_state_invalid';
    END IF;
    IF jsonb_typeof(p_request_payload) <> 'object'
       OR jsonb_typeof(p_result_payload) <> 'object'
       OR jsonb_typeof(p_dossier_refs) <> 'array'
       OR jsonb_typeof(p_items) <> 'array'
       OR jsonb_array_length(p_dossier_refs) < 2
       OR jsonb_array_length(p_dossier_refs) > 20
       OR jsonb_array_length(p_items) <> jsonb_array_length(p_dossier_refs) THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p2_payload_shape_invalid';
    END IF;
    IF p_result_payload->'ranking' IS DISTINCT FROM 'null'::jsonb
       OR p_result_payload->'recommendation' IS DISTINCT FROM 'null'::jsonb
       OR p_result_payload->'winner' IS DISTINCT FROM 'null'::jsonb
       OR COALESCE((p_result_payload->>'no_auto_decision')::boolean, FALSE) IS NOT TRUE
       OR COALESCE((p_result_payload->>'sponsored_ranking')::boolean, TRUE) IS NOT FALSE
       OR p_result_payload->>'engine_version' IS DISTINCT FROM 'mb12-p2-r1' THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p2_neutrality_invariant_invalid';
    END IF;
    IF p_request_payload ?| ARRAY['score','ranking','recommendation','winner','exchange_rate','paid_placement']
       OR p_result_payload ?| ARRAY['score','sponsor','paid_placement'] THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p2_forbidden_decision_field';
    END IF;

    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_stable_id, 0));

    FOR v_ref IN SELECT value FROM jsonb_array_elements(p_dossier_refs) LOOP
        SELECT r.* INTO v_dossier_revision
          FROM public.mb12_p1_offer_contract d
          JOIN public.mb12_p1_offer_contract_revision r
            ON r.owner_user_id = d.owner_user_id
           AND r.dossier_id = d.dossier_id
           AND r.revision = d.current_revision
         WHERE d.owner_user_id = v_owner
           AND d.dossier_id = NULLIF(v_ref->>'dossier_id', '')::uuid
           AND d.current_revision = NULLIF(v_ref->>'revision', '')::integer
           AND d.payload_hash = v_ref->>'payload_hash'
           AND d.state <> 'revoked';
        IF NOT FOUND THEN
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p2_current_p1_revision_required';
        END IF;

        FOR v_source_ref IN SELECT value FROM jsonb_array_elements(v_dossier_revision.source_refs) LOOP
            IF NOT EXISTS (
                SELECT 1
                  FROM public.mb12_p0_source_card_binding b
                  JOIN public.mb12_p0_trusted_data_value t
                    ON t.owner_user_id = b.owner_user_id
                   AND t.source_id = b.source_id
                   AND t.source_revision_id = b.source_revision_id
                   AND t.evidence_id = b.evidence_id
                   AND t.content_hash = b.content_hash
                   AND t.grant_id IS NOT DISTINCT FROM b.grant_id
                  JOIN public.canonical_source_card_authority a
                    ON a.owner_user_id = b.owner_user_id
                   AND a.source_card_id = b.source_card_id
                  JOIN public.authorized_memory_sources s
                    ON s.id = b.source_id AND s.user_id = b.owner_user_id
                  JOIN public.authorized_memory_inventory_items i
                    ON i.id = b.source_revision_id
                   AND i.user_id = b.owner_user_id
                   AND i.source_id = b.source_id
                  JOIN public.authorized_memory_activity_log l
                    ON l.id = b.evidence_id
                   AND l.user_id = b.owner_user_id
                   AND l.source_id = b.source_id
                  LEFT JOIN public.authorized_memory_consent_grants g
                    ON g.id = b.grant_id
                   AND g.user_id = b.owner_user_id
                   AND g.source_id = b.source_id
                 WHERE b.owner_user_id = v_owner
                   AND b.source_card_id = v_source_ref->>'source_card_id'
                   AND b.source_id = NULLIF(v_source_ref->>'source_id', '')::uuid
                   AND b.source_revision_id = NULLIF(v_source_ref->>'source_revision_id', '')::uuid
                   AND b.evidence_id = NULLIF(v_source_ref->>'evidence_id', '')::uuid
                   AND b.content_hash = v_source_ref->>'content_hash'
                   AND b.grant_id IS NOT DISTINCT FROM NULLIF(v_source_ref->>'grant_id', '')::uuid
                   AND b.scope = v_source_ref->>'scope'
                   AND b.status = 'active'
                   AND b.revoked_at IS NULL
                   AND a.status = 'active'
                   AND a.source_state = 'active'
                   AND COALESCE(a.revocation_state, '') <> 'revoked'
                   AND s.status = 'active'
                   AND s.revoked_at IS NULL
                   AND i.deleted_at IS NULL
                   AND i.memory_state <> 'revoked'
                   AND l.id = t.evidence_id
                   AND t.field_name = v_source_ref->>'field_name'
                   AND t.normalized_value = v_source_ref->>'trusted_value'
                   AND (
                        b.grant_id IS NULL
                        OR (
                            g.status = 'active'
                            AND g.revoked_at IS NULL
                            AND (g.expires_at IS NULL OR g.expires_at > NOW())
                        )
                   )
            ) THEN
                RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p2_live_p0_provenance_required';
            END IF;
        END LOOP;
    END LOOP;

    FOR v_item IN SELECT value FROM jsonb_array_elements(p_items) LOOP
        IF NOT (p_dossier_refs @> jsonb_build_array(jsonb_build_object(
            'dossier_id', v_item->>'dossier_id',
            'revision', (v_item->>'dossier_revision')::integer,
            'payload_hash', v_item->>'dossier_payload_hash'
        ))) THEN
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p2_item_dossier_ref_mismatch';
        END IF;
    END LOOP;

    v_payload_hash := encode(
        digest(convert_to((p_request_payload || jsonb_build_object('result', p_result_payload))::text, 'UTF8'), 'sha256'),
        'hex'
    );

    SELECT * INTO v_current
      FROM public.mb12_p2_comparability_assessment a
     WHERE a.owner_user_id = v_owner
       AND a.stable_id = p_stable_id
     FOR UPDATE;

    IF FOUND THEN
        IF v_current.payload_hash = v_payload_hash AND v_current.state = p_state THEN
            RETURN QUERY SELECT v_current.comparison_id, v_current.current_revision, v_current.payload_hash;
            RETURN;
        END IF;
        IF v_current.state = 'revoked' AND p_state <> 'revoked' THEN
            RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb12_p2_revoked_assessment_cannot_reactivate';
        END IF;
        p_comparison_id := v_current.comparison_id;
        v_revision := v_current.current_revision + 1;
    ELSE
        v_revision := 1;
        INSERT INTO public.mb12_p2_comparability_assessment (
            owner_user_id, comparison_id, stable_id, current_revision, state, payload_hash
        ) VALUES (
            v_owner, p_comparison_id, p_stable_id, v_revision, p_state, v_payload_hash
        );
    END IF;

    INSERT INTO public.mb12_p2_comparability_revision (
        owner_user_id, comparison_id, revision, state, payload_hash,
        request_payload, result_payload, dossier_refs
    ) VALUES (
        v_owner, p_comparison_id, v_revision, p_state, v_payload_hash,
        p_request_payload, p_result_payload, p_dossier_refs
    );

    FOR v_item IN SELECT value FROM jsonb_array_elements(p_items) LOOP
        INSERT INTO public.mb12_p2_comparability_item (
            owner_user_id, comparison_id, revision, dossier_id,
            dossier_revision, dossier_payload_hash, item_payload
        ) VALUES (
            v_owner, p_comparison_id, v_revision,
            (v_item->>'dossier_id')::uuid,
            (v_item->>'dossier_revision')::integer,
            v_item->>'dossier_payload_hash',
            v_item
        );
    END LOOP;

    UPDATE public.mb12_p2_comparability_assessment AS a
       SET current_revision = v_revision,
           state = p_state,
           payload_hash = v_payload_hash,
           updated_at = NOW()
     WHERE a.owner_user_id = v_owner
       AND a.comparison_id = p_comparison_id;

    RETURN QUERY SELECT p_comparison_id, v_revision, v_payload_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION public.mb12_p2_revoke_assessment(
    p_comparison_id UUID,
    p_reason TEXT
) RETURNS TABLE(comparison_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb12_p2_comparability_assessment%ROWTYPE;
    v_previous public.mb12_p2_comparability_revision%ROWTYPE;
    v_revision INTEGER;
    v_result JSONB;
    v_hash TEXT;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p2_authenticated_owner_missing';
    END IF;
    IF p_comparison_id IS NULL OR length(trim(COALESCE(p_reason, ''))) = 0 OR length(p_reason) > 500 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p2_revocation_invalid';
    END IF;

    SELECT * INTO v_current
      FROM public.mb12_p2_comparability_assessment a
     WHERE a.owner_user_id = v_owner
       AND a.comparison_id = p_comparison_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = 'P0002', MESSAGE = 'mb12_p2_assessment_not_found';
    END IF;
    IF v_current.state = 'revoked' THEN
        RETURN QUERY SELECT v_current.comparison_id, v_current.current_revision, v_current.payload_hash;
        RETURN;
    END IF;

    SELECT * INTO v_previous
      FROM public.mb12_p2_comparability_revision r
     WHERE r.owner_user_id = v_owner
       AND r.comparison_id = p_comparison_id
       AND r.revision = v_current.current_revision;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb12_p2_current_revision_missing';
    END IF;

    v_revision := v_current.current_revision + 1;
    v_result := v_previous.result_payload || jsonb_build_object(
        'state', 'revoked',
        'revocation_reason', trim(p_reason),
        'revoked_from_revision', v_current.current_revision
    );
    v_hash := encode(digest(convert_to((v_previous.request_payload || jsonb_build_object('result', v_result))::text, 'UTF8'), 'sha256'), 'hex');

    INSERT INTO public.mb12_p2_comparability_revision (
        owner_user_id, comparison_id, revision, state, payload_hash,
        request_payload, result_payload, dossier_refs
    ) VALUES (
        v_owner, p_comparison_id, v_revision, 'revoked', v_hash,
        v_previous.request_payload, v_result, v_previous.dossier_refs
    );

    UPDATE public.mb12_p2_comparability_assessment AS a
       SET current_revision = v_revision,
           state = 'revoked',
           payload_hash = v_hash,
           updated_at = NOW()
     WHERE a.owner_user_id = v_owner
       AND a.comparison_id = p_comparison_id;

    RETURN QUERY SELECT p_comparison_id, v_revision, v_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb12_p2_write_assessment(UUID,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb12_p2_revoke_assessment(UUID,TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p2_write_assessment(UUID,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB) TO mb12_p2_app;
GRANT EXECUTE ON FUNCTION public.mb12_p2_revoke_assessment(UUID,TEXT) TO mb12_p2_app;

REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER
    ON public.mb12_p2_comparability_assessment,
       public.mb12_p2_comparability_revision,
       public.mb12_p2_comparability_item
    FROM PUBLIC, mb12_p2_app;
GRANT SELECT
    ON public.mb12_p2_comparability_assessment,
       public.mb12_p2_comparability_revision,
       public.mb12_p2_comparability_item
    TO mb12_p2_app;

COMMIT;
