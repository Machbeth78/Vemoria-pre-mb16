-- VEMORA — Migration V86: Firma Vemora controparte + hash recheck
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
--
-- Estende firma_sessioni con token pubblico per controparte, re-verifica hash,
-- snapshot risposta controparte e dati minimi shareable.

ALTER TABLE firma_sessioni
    ADD COLUMN IF NOT EXISTS public_token TEXT,
    ADD COLUMN IF NOT EXISTS public_expires_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS public_revoked_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS counterparty_email TEXT,
    ADD COLUMN IF NOT EXISTS counterparty_name TEXT,
    ADD COLUMN IF NOT EXISTS counterparty_signed_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS counterparty_response TEXT
        CHECK (counterparty_response IS NULL OR counterparty_response IN ('accepted', 'rejected')),
    ADD COLUMN IF NOT EXISTS verified_document_hash TEXT,
    ADD COLUMN IF NOT EXISTS verification_status TEXT NOT NULL DEFAULT 'not_checked'
        CHECK (verification_status IN ('not_checked', 'ok', 'mismatch'));

CREATE UNIQUE INDEX IF NOT EXISTS idx_firma_sessioni_public_token
    ON firma_sessioni(public_token)
    WHERE public_token IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_firma_sessioni_public_open
    ON firma_sessioni(public_expires_at)
    WHERE public_token IS NOT NULL AND public_revoked_at IS NULL;

COMMENT ON COLUMN firma_sessioni.public_token IS
    'Token pubblico shareable per controparte. Non sostituisce autenticazione forte.';
COMMENT ON COLUMN firma_sessioni.verification_status IS
    'Esito del ricalcolo hash al momento della firma: ok/mismatch/not_checked.';

-- Nota: registrazione migration demandata al migration runner/registry service.
-- Se la migration viene applicata manualmente via SQL puro, usare poi adopt-existing o status nel runner.
