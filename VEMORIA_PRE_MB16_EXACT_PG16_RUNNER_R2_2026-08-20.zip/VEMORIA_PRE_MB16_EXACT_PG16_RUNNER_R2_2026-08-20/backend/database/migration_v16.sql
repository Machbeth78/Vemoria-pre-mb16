-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V3.5 — Migration V16 — Document Intelligence Layer
CREATE TABLE IF NOT EXISTS document_insight (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id UUID NOT NULL,
    tipo_insight TEXT NOT NULL,
    valore       TEXT NOT NULL,
    confidenza   FLOAT NOT NULL DEFAULT 0.5,
    creato_il    TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_insight_documento ON document_insight(documento_id);
CREATE INDEX IF NOT EXISTS idx_insight_tipo      ON document_insight(tipo_insight);
