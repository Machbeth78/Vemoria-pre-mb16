-- Gate07A — P0 Foundation Functional Completion
-- Code-level completion metadata only. This migration does not claim Android,
-- PostgreSQL, hardware-backed-key, backup-restore, or release runtime PASS.

CREATE TABLE IF NOT EXISTS gate07a_p0_functional_completion_status (
    vc_id TEXT PRIMARY KEY,
    function_name TEXT NOT NULL,
    completion_state TEXT NOT NULL CHECK (completion_state = 'FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED'),
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE CHECK (runtime_pass_claimed = FALSE),
    runtime_state TEXT NOT NULL,
    completed_gate TEXT NOT NULL DEFAULT 'GATE07A_P0_FUNCTIONAL_COMPLETION',
    completed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    evidence JSONB NOT NULL DEFAULT '{}'::jsonb
);

INSERT INTO gate07a_p0_functional_completion_status
    (vc_id, function_name, completion_state, runtime_state, evidence)
VALUES
    ('VC-038', 'Device & Runtime Capability Layer', 'FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED', 'NON_ESEGUITO', '{"service":"foundation_p0_functional_service","endpoint":"/api/v1/foundation-p0-functional/capability-profile"}'::jsonb),
    ('VC-039', 'Multi-device owner profile', 'FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED', 'NON_ESEGUITO', '{"service":"foundation_p0_functional_service","policy":"epoch_monotonic_device_set"}'::jsonb),
    ('VC-081', 'Cifratura a riposo', 'FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED', 'FLUTTER_ANDROID_HARDWARE_NON_ESEGUITO', '{"service":"foundation_p0_functional_service","policy":"AES-256-GCM_at_rest"}'::jsonb),
    ('VC-082', 'Backup e recovery owner-controlled', 'FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED', 'NON_ESEGUITO', '{"service":"foundation_p0_functional_service","endpoint":"/api/v1/foundation-p0-functional/backup-recovery-readiness"}'::jsonb),
    ('VC-086', 'Release hardening e integrità device', 'FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED', 'NON_ESEGUITO', '{"service":"foundation_p0_functional_service","endpoint":"/api/v1/foundation-p0-functional/release-hardening"}'::jsonb)
ON CONFLICT (vc_id) DO UPDATE SET
    completion_state = EXCLUDED.completion_state,
    runtime_pass_claimed = FALSE,
    runtime_state = EXCLUDED.runtime_state,
    completed_gate = EXCLUDED.completed_gate,
    completed_at = NOW(),
    evidence = EXCLUDED.evidence;
