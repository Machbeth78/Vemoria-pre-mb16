-- Gate08B.5 — Device Knowledge & Capability Guide / Device Capability Map
-- Static contract migration. Runtime Android/Desktop probe non eseguito.

CREATE TABLE IF NOT EXISTS device_capability_map_gate08b5 (
    id UUID PRIMARY KEY,
    owner_id UUID NOT NULL,
    device_id_hash TEXT NOT NULL,
    map_version TEXT NOT NULL DEFAULT 'GATE08B5_DEVICE_CAPABILITY_GUIDE_V163_2026-06-20',
    consent_record_hash TEXT NOT NULL,
    capability_summary JSONB NOT NULL DEFAULT '{}'::jsonb,
    stores_private_content BOOLEAN NOT NULL DEFAULT FALSE,
    owner_scoped BOOLEAN NOT NULL DEFAULT TRUE,
    encrypted_at_rest_required BOOLEAN NOT NULL DEFAULT TRUE,
    runtime_probe_executed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS device_capability_suggestion_gate08b5 (
    id UUID PRIMARY KEY,
    owner_id UUID NOT NULL,
    device_map_id UUID NULL REFERENCES device_capability_map_gate08b5(id),
    task_summary TEXT NOT NULL,
    capability_id TEXT NOT NULL,
    recommendation_type TEXT NOT NULL,
    prefer_native BOOLEAN NOT NULL DEFAULT TRUE,
    explanation TEXT NOT NULL,
    owner_confirmation_required BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS device_guided_open_plan_gate08b5 (
    id UUID PRIMARY KEY,
    owner_id UUID NOT NULL,
    capability_id TEXT NOT NULL,
    action TEXT NOT NULL,
    owner_confirmation_present BOOLEAN NOT NULL DEFAULT FALSE,
    silent_control_allowed BOOLEAN NOT NULL DEFAULT FALSE,
    runtime_executed BOOLEAN NOT NULL DEFAULT FALSE,
    risk_level TEXT NOT NULL DEFAULT 'NORMAL',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE device_capability_map_gate08b5 IS 'Gate08B.5 static contract: owner-scoped Device Capability Map. Stores capabilities, not content/secrets. Runtime probe non eseguito.';
COMMENT ON TABLE device_capability_suggestion_gate08b5 IS 'Gate08B.5 static contract: prefer native capability over rebuilding when safe. Runtime execution non eseguito.';
COMMENT ON TABLE device_guided_open_plan_gate08b5 IS 'Gate08B.5 static contract: guided open requires owner confirmation; silent control not allowed.';
