-- VEMORA MB13-P3 v212 — Monitor, executor and receipt closure
-- Non modificare MB13-P1/MB13-P2. Non aprire R3. Non produrre APK/AAB.

BEGIN;

-- 1. Cross-macroblock validator role and evidence payload column
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p3_validator') THEN
        CREATE ROLE mb13_p3_validator NOLOGIN;
    END IF;
END $$;

GRANT USAGE ON SCHEMA public TO mb13_p3_validator;

ALTER TABLE public.mb13_p3_action_pack_evidence
    ADD COLUMN IF NOT EXISTS evidence_payload JSONB NOT NULL DEFAULT '{}'::jsonb;

-- 2. Core validator: exact source/grant/evidence chain bound to monitor revision and refs.
CREATE OR REPLACE FUNCTION public.mb13_p3_validate_source_grant_chain(
    p_owner_user_id UUID,
    p_monitor public.mb13_p0_monitor_target,
    p_consent_refs JSONB,
    p_provenance_refs JSONB,
    p_step_consent_refs JSONB DEFAULT '[]'::jsonb
) RETURNS VOID AS $$
DECLARE
    v_c JSONB;
    v_p JSONB;
    v_s JSONB;
    v_source_id UUID;
    v_grant_id UUID;
    v_evidence_id UUID;
    v_monitor_consent JSONB := p_monitor.consent_refs;
    v_monitor_evidence JSONB := p_monitor.evidence_refs;
    v_source_row public.authorized_memory_sources%ROWTYPE;
    v_grant_row public.authorized_memory_consent_grants%ROWTYPE;
    v_evidence_row public.authorized_memory_activity_log%ROWTYPE;
BEGIN
    IF p_consent_refs IS NULL OR jsonb_typeof(p_consent_refs) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p3_consent_refs_invalid';
    END IF;
    IF p_provenance_refs IS NULL OR jsonb_typeof(p_provenance_refs) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p3_provenance_refs_invalid';
    END IF;
    IF p_step_consent_refs IS NULL OR jsonb_typeof(p_step_consent_refs) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p3_step_consent_refs_invalid';
    END IF;

    -- step consents must be a subset of pack consent refs
    IF jsonb_array_length(p_step_consent_refs) > 0 THEN
        FOR v_s IN SELECT jsonb_array_elements(p_step_consent_refs) LOOP
            IF NOT EXISTS (
                SELECT 1 FROM jsonb_array_elements(p_consent_refs) c
                WHERE (c->>'source_id')::UUID = (v_s->>'source_id')::UUID
                  AND (c->>'grant_id')::UUID = (v_s->>'grant_id')::UUID
            ) THEN
                RAISE EXCEPTION 'mb13_p3_step_consent_not_in_pack';
            END IF;
        END LOOP;
    END IF;

    -- validate consent_refs and lock source/grant rows
    FOR v_c IN SELECT jsonb_array_elements(p_consent_refs) LOOP
        IF jsonb_typeof(v_c) <> 'object' THEN
            RAISE EXCEPTION 'mb13_p3_consent_ref_invalid';
        END IF;
        v_source_id := NULLIF(v_c->>'source_id', '')::UUID;
        v_grant_id := NULLIF(v_c->>'grant_id', '')::UUID;
        IF v_source_id IS NULL OR v_grant_id IS NULL THEN
            RAISE EXCEPTION 'mb13_p3_consent_ref_invalid';
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM jsonb_array_elements(v_monitor_consent) m
            WHERE (m->>'source_id')::UUID = v_source_id
              AND (m->>'grant_id')::UUID = v_grant_id
        ) THEN
            RAISE EXCEPTION 'mb13_p3_consent_ref_not_in_monitor';
        END IF;
        SELECT * INTO v_source_row
          FROM public.authorized_memory_sources
         WHERE id = v_source_id
           AND user_id = p_owner_user_id
         FOR SHARE;
        IF NOT FOUND OR v_source_row.status <> 'active' OR v_source_row.revoked_at IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p3_consent_source_invalid';
        END IF;
        SELECT * INTO v_grant_row
          FROM public.authorized_memory_consent_grants
         WHERE id = v_grant_id
           AND user_id = p_owner_user_id
           AND source_id = v_source_id
         FOR SHARE;
        IF NOT FOUND OR v_grant_row.status <> 'active' OR v_grant_row.revoked_at IS NOT NULL OR (v_grant_row.expires_at IS NOT NULL AND v_grant_row.expires_at <= clock_timestamp()) THEN
            RAISE EXCEPTION 'mb13_p3_consent_grant_invalid';
        END IF;
    END LOOP;

    -- validate provenance refs exact chain and lock source/grant/evidence
    FOR v_p IN SELECT jsonb_array_elements(p_provenance_refs) LOOP
        IF jsonb_typeof(v_p) <> 'object' THEN
            RAISE EXCEPTION 'mb13_p3_provenance_ref_invalid';
        END IF;
        v_source_id := NULLIF(v_p->>'source_id', '')::UUID;
        v_grant_id := NULLIF(v_p->>'grant_id', '')::UUID;
        v_evidence_id := NULLIF(v_p->>'evidence_id', '')::UUID;
        IF v_source_id IS NULL OR v_grant_id IS NULL OR v_evidence_id IS NULL THEN
            RAISE EXCEPTION 'mb13_p3_provenance_ref_invalid';
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM jsonb_array_elements(v_monitor_consent) m
            WHERE (m->>'source_id')::UUID = v_source_id
              AND (m->>'grant_id')::UUID = v_grant_id
        ) THEN
            RAISE EXCEPTION 'mb13_p3_provenance_consent_not_in_monitor';
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM jsonb_array_elements(v_monitor_evidence) m
            WHERE (m->>'evidence_ref')::UUID = v_evidence_id
        ) THEN
            RAISE EXCEPTION 'mb13_p3_provenance_evidence_not_in_monitor';
        END IF;
        SELECT * INTO v_source_row
          FROM public.authorized_memory_sources
         WHERE id = v_source_id
           AND user_id = p_owner_user_id
         FOR SHARE;
        IF NOT FOUND OR v_source_row.status <> 'active' OR v_source_row.revoked_at IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p3_provenance_source_invalid';
        END IF;
        SELECT * INTO v_grant_row
          FROM public.authorized_memory_consent_grants
         WHERE id = v_grant_id
           AND user_id = p_owner_user_id
           AND source_id = v_source_id
         FOR SHARE;
        IF NOT FOUND OR v_grant_row.status <> 'active' OR v_grant_row.revoked_at IS NOT NULL OR (v_grant_row.expires_at IS NOT NULL AND v_grant_row.expires_at <= clock_timestamp()) THEN
            RAISE EXCEPTION 'mb13_p3_provenance_grant_invalid';
        END IF;
        SELECT * INTO v_evidence_row
          FROM public.authorized_memory_activity_log
         WHERE id = v_evidence_id
           AND user_id = p_owner_user_id
           AND source_id = v_source_id
           AND grant_id = v_grant_id
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_provenance_evidence_invalid';
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql VOLATILE SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_validate_source_grant_chain(UUID, public.mb13_p0_monitor_target, JSONB, JSONB, JSONB) OWNER TO mb13_p3_validator;
REVOKE ALL ON FUNCTION public.mb13_p3_validate_source_grant_chain(UUID, public.mb13_p0_monitor_target, JSONB, JSONB, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_source_grant_chain(UUID, public.mb13_p0_monitor_target, JSONB, JSONB, JSONB) TO mb13_p3_writer;

-- 3. Trigger/diff validator with exact monitor revision and row locking.
CREATE OR REPLACE FUNCTION public.mb13_p3_validate_trigger_diff(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_monitor_revision INTEGER,
    p_trigger_event_id UUID,
    p_diff_result_id UUID
) RETURNS VOID AS $$
DECLARE
    v_dummy INTEGER;
BEGIN
    IF p_trigger_event_id IS NULL AND p_diff_result_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_trigger_or_diff_required';
    END IF;

    IF p_trigger_event_id IS NOT NULL THEN
        SELECT 1 INTO v_dummy
          FROM public.mb13_p0_monitor_event_ledger
         WHERE owner_user_id = p_owner_user_id
           AND event_id = p_trigger_event_id
           AND monitor_id = p_monitor_id
           AND monitor_revision = p_monitor_revision
           AND event_status NOT IN ('superseded','failed')
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_trigger_event_invalid';
        END IF;
    END IF;

    IF p_diff_result_id IS NOT NULL THEN
        SELECT 1 INTO v_dummy
          FROM public.mb13_p1_universal_diff
         WHERE owner_user_id = p_owner_user_id
           AND diff_id = p_diff_result_id
           AND monitor_id = p_monitor_id
           AND monitor_revision = p_monitor_revision
           AND diff_state NOT IN ('blocked','invalid')
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_diff_result_invalid';
        END IF;
    END IF;
END;
$$ LANGUAGE plpgsql VOLATILE SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_validate_trigger_diff(UUID, UUID, INTEGER, UUID, UUID) OWNER TO mb13_p3_validator;
REVOKE ALL ON FUNCTION public.mb13_p3_validate_trigger_diff(UUID, UUID, INTEGER, UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_trigger_diff(UUID, UUID, INTEGER, UUID, UUID) TO mb13_p3_writer;

-- 4. Refs_revoked uses the governed validator; returns true if chain is revoked/invalid.
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_refs_revoked(
    p_monitor public.mb13_p0_monitor_target,
    p_consent_refs JSONB,
    p_provenance_refs JSONB
) RETURNS BOOLEAN AS $$
BEGIN
    PERFORM public.mb13_p3_validate_source_grant_chain(
        p_monitor.owner_user_id, p_monitor, p_consent_refs, p_provenance_refs, '[]'::jsonb
    );
    RETURN false;
EXCEPTION WHEN OTHERS THEN
    RETURN true;
END;
$$ LANGUAGE plpgsql VOLATILE SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_refs_revoked(public.mb13_p0_monitor_target, JSONB, JSONB) OWNER TO mb13_p3_validator;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_refs_revoked(public.mb13_p0_monitor_target, JSONB, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_refs_revoked(public.mb13_p0_monitor_target, JSONB, JSONB) TO mb13_p3_writer;

-- 5. Evidence registration by the executor; canonical hash from server-side payload.
CREATE OR REPLACE FUNCTION public.mb13_p3_record_execution_evidence(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_attempt_number INTEGER,
    p_evidence_type TEXT,
    p_evidence_payload JSONB
) RETURNS TABLE(
    evidence_id UUID,
    receipt_id UUID,
    evidence_hash TEXT
) AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_evidence_hash TEXT;
    v_new_id UUID;
    v_receipt_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.attempt_number IS DISTINCT FROM p_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    IF p_evidence_payload IS NULL OR jsonb_typeof(p_evidence_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_payload_invalid';
    END IF;

    v_evidence_hash := public.mb13_p0_hash_jsonb(p_evidence_payload);
    v_receipt_id := gen_random_uuid();

    INSERT INTO public.mb13_p3_action_pack_evidence (
        owner_user_id, pack_id, attempt_id, evidence_type, evidence_hash, receipt_id, evidence_payload, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, p_evidence_type, v_evidence_hash, v_receipt_id, p_evidence_payload, v_now
    ) RETURNING public.mb13_p3_action_pack_evidence.evidence_id INTO v_new_id;

    RETURN QUERY SELECT v_new_id, v_receipt_id, v_evidence_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_record_execution_evidence(UUID, UUID, UUID, INTEGER, TEXT, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_record_execution_evidence(UUID, UUID, UUID, INTEGER, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_record_execution_evidence(UUID, UUID, UUID, INTEGER, TEXT, JSONB) TO mb13_p3_executor, mb13_p3_writer;

-- 6. Result evidence validation: only pre-registered evidence/receipt, no auto-creation, no body hash.
CREATE OR REPLACE FUNCTION public.mb13_p3_validate_result_evidence(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_result_payload JSONB
) RETURNS UUID AS $$
DECLARE
    v_evidence JSONB;
    v_evidence_id UUID;
    v_receipt_id UUID;
    v_evidence_type TEXT;
    v_row public.mb13_p3_action_pack_evidence%ROWTYPE;
    v_expected_hash TEXT;
BEGIN
    IF p_result_payload IS NULL OR jsonb_typeof(p_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_payload_invalid';
    END IF;

    v_evidence := p_result_payload->'evidence';
    IF v_evidence IS NULL OR jsonb_typeof(v_evidence) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_required';
    END IF;

    IF v_evidence ? 'evidence_hash' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_hash_from_body_forbidden';
    END IF;

    v_evidence_type := NULLIF(v_evidence->>'evidence_type', '');
    v_evidence_id := NULLIF(v_evidence->>'evidence_id', '')::UUID;
    v_receipt_id := NULLIF(v_evidence->>'receipt_id', '')::UUID;

    IF v_evidence_type IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_type_required';
    END IF;
    IF v_evidence_id IS NULL AND v_receipt_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_not_pre_registered';
    END IF;

    IF v_evidence_id IS NOT NULL THEN
        SELECT * INTO v_row
          FROM public.mb13_p3_action_pack_evidence
         WHERE evidence_id = v_evidence_id
           AND owner_user_id = p_owner_user_id
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_found';
        END IF;
        IF v_row.pack_id IS DISTINCT FROM p_pack_id OR v_row.attempt_id IS DISTINCT FROM p_attempt_id THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_bound';
        END IF;
        IF v_row.evidence_type IS DISTINCT FROM v_evidence_type THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_type_mismatch';
        END IF;
        v_expected_hash := public.mb13_p0_hash_jsonb(v_row.evidence_payload);
        IF v_row.evidence_hash IS DISTINCT FROM v_expected_hash THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_integrity_failure';
        END IF;
        RETURN v_evidence_id;
    END IF;

    -- lookup by receipt_id
    SELECT * INTO v_row
      FROM public.mb13_p3_action_pack_evidence
     WHERE receipt_id = v_receipt_id
       AND owner_user_id = p_owner_user_id
     FOR SHARE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_not_found';
    END IF;
    IF v_row.pack_id IS DISTINCT FROM p_pack_id OR v_row.attempt_id IS DISTINCT FROM p_attempt_id THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_not_bound';
    END IF;
    IF v_row.evidence_type IS DISTINCT FROM v_evidence_type THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_type_mismatch';
    END IF;
    v_expected_hash := public.mb13_p0_hash_jsonb(v_row.evidence_payload);
    IF v_row.evidence_hash IS DISTINCT FROM v_expected_hash THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_integrity_failure';
    END IF;
    RETURN v_row.evidence_id;
END;
$$ LANGUAGE plpgsql VOLATILE SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_validate_result_evidence(UUID, UUID, UUID, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_validate_result_evidence(UUID, UUID, UUID, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_result_evidence(UUID, UUID, UUID, JSONB) TO mb13_p3_writer;

-- 7. Authorization revocation trigger: enforce event linkage and server-side revoked_at.
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_authorization_append_only()
RETURNS TRIGGER AS $$
DECLARE
    v_event_owner UUID;
    v_event_pack UUID;
    v_event_kind TEXT;
BEGIN
    IF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_authorization is append-only'
            USING ERRCODE = 'P3IMM';
    END IF;
    IF TG_OP = 'UPDATE' THEN
        IF NEW.auth_id IS DISTINCT FROM OLD.auth_id
           OR NEW.owner_user_id IS DISTINCT FROM OLD.owner_user_id
           OR NEW.pack_id IS DISTINCT FROM OLD.pack_id
           OR NEW.pack_revision IS DISTINCT FROM OLD.pack_revision
           OR NEW.pack_payload_hash IS DISTINCT FROM OLD.pack_payload_hash
           OR NEW.monitor_revision IS DISTINCT FROM OLD.monitor_revision
           OR NEW.action_type IS DISTINCT FROM OLD.action_type
           OR NEW.target_ref_hash IS DISTINCT FROM OLD.target_ref_hash
           OR NEW.consent_hash IS DISTINCT FROM OLD.consent_hash
           OR NEW.provenance_hash IS DISTINCT FROM OLD.provenance_hash
           OR NEW.authorized_at IS DISTINCT FROM OLD.authorized_at
           OR NEW.expires_at IS DISTINCT FROM OLD.expires_at
           OR NEW.auth_payload_hash IS DISTINCT FROM OLD.auth_payload_hash
           OR NEW.authorization_hash IS DISTINCT FROM OLD.authorization_hash
           OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization is append-only'
                USING ERRCODE = 'P3IMM';
        END IF;

        IF OLD.revoked = true THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_already_revoked'
                USING ERRCODE = 'P3IMM';
        END IF;

        IF NEW.revoked = false THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_revocation_required'
                USING ERRCODE = 'P3IMM';
        END IF;

        IF OLD.revoked_at IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_revoked_at_immutable'
                USING ERRCODE = 'P3IMM';
        END IF;
        IF NEW.revoked_at IS NULL THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_revoked_at_required'
                USING ERRCODE = 'P3IMM';
        END IF;
        IF NEW.revoked_at < OLD.authorized_at THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_revoked_at_invalid'
                USING ERRCODE = 'P3IMM';
        END IF;
        IF NEW.revoked_at > clock_timestamp() + INTERVAL '5 seconds' THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_revoked_at_arbitrary'
                USING ERRCODE = 'P3IMM';
        END IF;

        IF NEW.revocation_event_id IS NULL THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_revocation_event_id_required'
                USING ERRCODE = 'P3IMM';
        END IF;
        SELECT owner_user_id, pack_id, event_kind INTO v_event_owner, v_event_pack, v_event_kind
          FROM public.mb13_p3_action_pack_timeline
         WHERE timeline_event_id = NEW.revocation_event_id;
        IF NOT FOUND
           OR v_event_owner IS DISTINCT FROM NEW.owner_user_id
           OR v_event_pack IS DISTINCT FROM NEW.pack_id
           OR v_event_kind IS DISTINCT FROM 'authorization_revoked' THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization_revocation_event_invalid'
                USING ERRCODE = 'P3IMM';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_authorization_append_only() OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_authorization_append_only() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_authorization_append_only() TO mb13_p3_writer;

-- 8. Transition guard: exact monitor binding on every insert/update of an action pack.
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_transition_guard()
RETURNS TRIGGER AS $$
DECLARE
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_step_consents JSONB;
BEGIN
    IF TG_OP = 'UPDATE' THEN
        IF NEW.consent_refs IS NOT DISTINCT FROM OLD.consent_refs
           AND NEW.provenance_refs IS NOT DISTINCT FROM OLD.provenance_refs
           AND NEW.steps IS NOT DISTINCT FROM OLD.steps
           AND NEW.monitor_id IS NOT DISTINCT FROM OLD.monitor_id
           AND NEW.monitor_revision IS NOT DISTINCT FROM OLD.monitor_revision
           AND NEW.trigger_event_id IS NOT DISTINCT FROM OLD.trigger_event_id
           AND NEW.diff_result_id IS NOT DISTINCT FROM OLD.diff_result_id
           AND NEW.action_type IS NOT DISTINCT FROM OLD.action_type
           AND NEW.target_ref IS NOT DISTINCT FROM OLD.target_ref
           AND NEW.status IS NOT DISTINCT FROM OLD.status THEN
            RETURN NEW;
        END IF;
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = NEW.owner_user_id
       AND monitor_id = NEW.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF NEW.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        NEW.owner_user_id, NEW.monitor_id, NEW.monitor_revision,
        NEW.trigger_event_id, NEW.diff_result_id
    );

    IF NEW.action_type NOT IN ('simulate','internal') THEN
        RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
    END IF;

    PERFORM public.mb13_p3_validate_steps(NEW.owner_user_id, COALESCE(NEW.steps, '[]'::jsonb));

    SELECT COALESCE(jsonb_agg(elem), '[]'::jsonb) INTO v_step_consents
    FROM (
        SELECT jsonb_array_elements(s->'consent_refs') AS elem
        FROM jsonb_array_elements(COALESCE(NEW.steps, '[]'::jsonb)) AS s
    ) sub;

    PERFORM public.mb13_p3_validate_source_grant_chain(
        NEW.owner_user_id, v_monitor, NEW.consent_refs, NEW.provenance_refs, v_step_consents
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_transition_guard() OWNER TO mb13_p3_validator;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_transition_guard() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_transition_guard() TO mb13_p3_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_steps(UUID, JSONB) TO mb13_p3_validator;

DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_transition_guard ON public.mb13_p3_action_pack;
CREATE TRIGGER trg_mb13_p3_action_pack_transition_guard
    BEFORE INSERT OR UPDATE ON public.mb13_p3_action_pack
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p3_action_pack_transition_guard();

-- 9. Result evidence guard on result table.
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_result_evidence_guard()
RETURNS TRIGGER AS $$
DECLARE
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
BEGIN
    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = NEW.attempt_id
       AND owner_user_id = NEW.owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.pack_id IS DISTINCT FROM NEW.pack_id OR v_attempt.attempt_number IS DISTINCT FROM NEW.attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_bound';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = NEW.pack_id
       AND owner_user_id = NEW.owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;

    IF NEW.outcome IN ('completed','partial') THEN
        PERFORM public.mb13_p3_validate_result_evidence(NEW.owner_user_id, NEW.pack_id, NEW.attempt_id, NEW.result_payload);
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_result_evidence_guard() OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_result_evidence_guard() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_result_evidence_guard() TO mb13_p3_writer;

DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_result_evidence_guard ON public.mb13_p3_action_pack_result;
CREATE TRIGGER trg_mb13_p3_action_pack_result_evidence_guard
    BEFORE INSERT ON public.mb13_p3_action_pack_result
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p3_action_pack_result_evidence_guard();

-- 10. Claim: authoritative executor identity from session_user, fail-closed replay.
DROP FUNCTION IF EXISTS public.mb13_p3_claim_action_pack(UUID, UUID, INTEGER, TEXT, TEXT, TEXT) CASCADE;

CREATE OR REPLACE FUNCTION public.mb13_p3_claim_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_expected_pack_revision INTEGER,
    p_claim_nonce TEXT,
    p_idempotency_key TEXT
) RETURNS TABLE(
    attempt_id UUID,
    pack_id UUID,
    attempt_number INTEGER,
    claim_nonce TEXT,
    status TEXT,
    created_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_existing public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
    v_attempt_number INTEGER;
    v_attempt_id UUID;
    v_request_hash TEXT;
    v_executor_identity TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_idempotency_key IS NULL OR length(COALESCE(p_idempotency_key, '')) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_idempotency_key_required';
    END IF;
    IF p_claim_nonce IS NULL OR length(COALESCE(p_claim_nonce, '')) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_claim_nonce_required';
    END IF;

    v_executor_identity := session_user;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_existing
      FROM public.mb13_p3_action_pack_attempt
     WHERE pack_id = p_pack_id
       AND idempotency_key = p_idempotency_key
     FOR UPDATE;
    IF FOUND THEN
        v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'pack_id', p_pack_id,
            'pack_revision', p_expected_pack_revision,
            'claim_nonce', p_claim_nonce,
            'idempotency_key', p_idempotency_key,
            'executor_identity', v_executor_identity
        ));
        IF v_existing.claim_request_hash IS DISTINCT FROM v_request_hash
           OR v_existing.claim_pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;

    IF v_existing.attempt_id IS NULL AND v_pack.status IS DISTINCT FROM 'authorized' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_authorized';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    IF v_existing.attempt_id IS NOT NULL THEN
        RETURN QUERY SELECT v_existing.attempt_id, v_existing.pack_id, v_existing.attempt_number,
                            v_existing.claim_nonce, v_existing.status, v_existing.created_at;
        RETURN;
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);
    v_attempt_number := COALESCE((SELECT MAX(attempt_number) FROM public.mb13_p3_action_pack_attempt WHERE pack_id = p_pack_id), 0) + 1;
    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'pack_id', p_pack_id,
        'pack_revision', p_expected_pack_revision,
        'claim_nonce', p_claim_nonce,
        'idempotency_key', p_idempotency_key,
        'executor_identity', v_executor_identity
    ));

    INSERT INTO public.mb13_p3_action_pack_attempt (
        owner_user_id, pack_id, attempt_number, idempotency_key, claim_nonce,
        executor_identity, status, created_at, claim_request_hash, claim_pack_revision
    ) VALUES (
        p_owner_user_id, p_pack_id, v_attempt_number, p_idempotency_key, p_claim_nonce,
        v_executor_identity, 'claimed', v_now, v_request_hash, p_expected_pack_revision
    ) RETURNING public.mb13_p3_action_pack_attempt.attempt_id INTO v_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = 'claimed',
           claimed_attempt_id = v_attempt_id,
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'claimed', 'authorized', 'claimed',
        v_now, jsonb_build_object('attempt_id', v_attempt_id, 'attempt_number', v_attempt_number, 'claim_nonce', p_claim_nonce, 'executor_identity', v_executor_identity),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt_id, p_pack_id, v_attempt_number, p_claim_nonce, 'claimed'::TEXT, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_claim_action_pack(UUID, UUID, INTEGER, TEXT, TEXT) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_claim_action_pack(UUID, UUID, INTEGER, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_claim_action_pack(UUID, UUID, INTEGER, TEXT, TEXT) TO mb13_p3_executor;

-- 11. Complete: re-validate before idempotent replay, governed evidence.
CREATE OR REPLACE FUNCTION public.mb13_p3_complete_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_expected_pack_revision INTEGER,
    p_expected_attempt_number INTEGER,
    p_outcome TEXT,
    p_result_payload JSONB
) RETURNS TABLE(
    attempt_id UUID,
    pack_id UUID,
    attempt_number INTEGER,
    status TEXT,
    result_hash TEXT,
    completed_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_existing_result public.mb13_p3_action_pack_result%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
    v_result_hash TEXT;
    v_event_kind TEXT;
    v_old_status TEXT;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_outcome NOT IN ('completed','partial','failed') THEN
        RAISE EXCEPTION 'mb13_p3_invalid_outcome';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;

    IF v_attempt.attempt_number IS DISTINCT FROM p_expected_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    -- Idempotent replay after full validation.
    SELECT * INTO v_existing_result
      FROM public.mb13_p3_action_pack_result
     WHERE attempt_id = p_attempt_id
       AND owner_user_id = p_owner_user_id;
    IF FOUND THEN
        v_result_hash := public.mb13_p3_action_pack_result_hash(
            p_owner_user_id, p_pack_id, v_pack.pack_revision, p_attempt_id,
            v_attempt.attempt_number, p_outcome, v_attempt.executor_identity,
            p_result_payload, v_existing_result.created_at
        );
        IF v_existing_result.outcome = p_outcome AND v_existing_result.result_hash = v_result_hash THEN
            RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                                p_outcome::TEXT, v_result_hash, v_attempt.completed_at;
            RETURN;
        END IF;
        RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
    END IF;

    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    IF p_outcome IN ('completed','partial') THEN
        PERFORM public.mb13_p3_validate_result_evidence(p_owner_user_id, p_pack_id, p_attempt_id, p_result_payload);
    END IF;

    v_result_hash := public.mb13_p3_action_pack_result_hash(
        p_owner_user_id, p_pack_id, v_pack.pack_revision, p_attempt_id,
        v_attempt.attempt_number, p_outcome, v_attempt.executor_identity,
        p_result_payload, v_now
    );
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);
    v_event_kind := p_outcome;
    v_old_status := v_pack.status;

    INSERT INTO public.mb13_p3_action_pack_result (
        owner_user_id, pack_id, attempt_id, attempt_number, outcome, executor_identity,
        result_payload, result_hash, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, v_attempt.attempt_number, p_outcome,
        v_attempt.executor_identity, COALESCE(p_result_payload, '{}'::jsonb), v_result_hash, v_now
    );

    UPDATE public.mb13_p3_action_pack_attempt
       SET status = p_outcome,
           result_payload = COALESCE(p_result_payload, '{}'::jsonb),
           result_hash = v_result_hash,
           completed_at = v_now
     WHERE attempt_id = p_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = p_outcome,
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, v_event_kind, 'executing', p_outcome,
        v_now, jsonb_build_object('attempt_id', p_attempt_id, 'attempt_number', v_attempt.attempt_number, 'result_hash', v_result_hash),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                        p_outcome::TEXT, v_result_hash, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) TO mb13_p3_executor;

-- 12. Cancel: authorization revocation event must be linked.
CREATE OR REPLACE FUNCTION public.mb13_p3_cancel_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID
) RETURNS TABLE(pack_id UUID, status TEXT) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status IN ('completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_already_terminal';
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_pack.status, 'cancelled',
            v_now, jsonb_build_object('pack_revision', v_pack.pack_revision, 'reason', 'cancel'),
            v_pack.monitor_revision, v_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    UPDATE public.mb13_p3_action_pack
       SET status = 'cancelled',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'cancelled', v_pack.status, 'cancelled',
        v_now, '{}'::jsonb, v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.status FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_cancel_action_pack(UUID, UUID) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_cancel_action_pack(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_cancel_action_pack(UUID, UUID) TO mb13_p3_api;

-- 13. Privilege minimization: P3 writer no longer updates cross-macroblock tables.
REVOKE UPDATE ON public.mb13_p0_monitor_event_ledger FROM mb13_p3_writer;
REVOKE UPDATE ON public.mb13_p1_universal_diff FROM mb13_p3_writer;
REVOKE UPDATE ON public.authorized_memory_sources FROM mb13_p3_writer;
REVOKE UPDATE ON public.authorized_memory_consent_grants FROM mb13_p3_writer;
REVOKE UPDATE ON public.authorized_memory_activity_log FROM mb13_p3_writer;

GRANT SELECT, UPDATE ON public.mb13_p0_monitor_target TO mb13_p3_validator;
GRANT SELECT, UPDATE ON public.mb13_p0_monitor_event_ledger TO mb13_p3_validator;
GRANT SELECT, UPDATE ON public.mb13_p1_universal_diff TO mb13_p3_validator;
GRANT SELECT, UPDATE ON public.authorized_memory_sources TO mb13_p3_validator;
GRANT SELECT, UPDATE ON public.authorized_memory_consent_grants TO mb13_p3_validator;
GRANT SELECT, UPDATE ON public.authorized_memory_activity_log TO mb13_p3_validator;

GRANT SELECT ON public.mb13_p3_action_pack TO mb13_p3_validator;

-- 14. Core functions updated to use governed validator instead of direct cross-macroblock locks.
CREATE OR REPLACE FUNCTION public.mb13_p3_create_action_pack(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_trigger_event_id UUID,
    p_diff_result_id UUID,
    p_action_type TEXT,
    p_target_ref JSONB,
    p_consent_refs JSONB,
    p_provenance_refs JSONB,
    p_steps JSONB,
    p_expires_at TIMESTAMPTZ,
    p_idempotency_key TEXT,
    p_initial_status TEXT DEFAULT 'proposed'
) RETURNS TABLE(
    pack_id UUID,
    owner_user_id UUID,
    monitor_id UUID,
    monitor_revision INTEGER,
    trigger_event_id UUID,
    diff_result_id UUID,
    pack_revision INTEGER,
    payload_hash TEXT,
    action_type TEXT,
    target_ref JSONB,
    consent_refs JSONB,
    provenance_refs JSONB,
    steps JSONB,
    expires_at TIMESTAMPTZ,
    idempotency_key TEXT,
    status TEXT,
    claimed_attempt_id UUID,
    created_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_existing public.mb13_p3_action_pack%ROWTYPE;
    v_pack_id UUID;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
    v_payload_hash TEXT;
    v_status TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);
    v_status := COALESCE(p_initial_status, 'proposed');

    IF v_status NOT IN ('draft','proposed','awaiting_confirmation') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_invalid_initial_status';
    END IF;

    IF p_action_type NOT IN ('simulate','internal') THEN
        RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
    END IF;

    PERFORM public.mb13_p3_validate_steps(p_owner_user_id, COALESCE(p_steps, '[]'::jsonb));

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, p_monitor_id, v_monitor_revision,
        p_trigger_event_id, p_diff_result_id
    );

    IF p_expires_at IS NOT NULL AND p_expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF p_idempotency_key IS NOT NULL THEN
        SELECT * INTO v_existing
          FROM public.mb13_p3_action_pack
         WHERE owner_user_id = p_owner_user_id
           AND idempotency_key = p_idempotency_key;
        IF FOUND THEN
            v_payload_hash := public.mb13_p3_action_pack_payload_hash(
                p_owner_user_id, p_monitor_id, v_monitor_revision,
                p_trigger_event_id, p_diff_result_id, p_action_type,
                p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
                p_expires_at, p_idempotency_key, v_status
            );
            IF v_existing.payload_hash IS DISTINCT FROM v_payload_hash THEN
                RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
            END IF;
            RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = v_existing.pack_id AND ap.owner_user_id = p_owner_user_id;
            RETURN;
        END IF;
    END IF;

    v_payload_hash := public.mb13_p3_action_pack_payload_hash(
        p_owner_user_id, p_monitor_id, v_monitor_revision,
        p_trigger_event_id, p_diff_result_id, p_action_type,
        p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
        p_expires_at, p_idempotency_key, v_status
    );

    INSERT INTO public.mb13_p3_action_pack (
        owner_user_id, monitor_id, monitor_revision, trigger_event_id, diff_result_id,
        pack_revision, payload_hash, action_type, target_ref, consent_refs, provenance_refs,
        steps, expires_at, idempotency_key, status, created_at, updated_at
    ) VALUES (
        p_owner_user_id, p_monitor_id, v_monitor_revision, p_trigger_event_id, p_diff_result_id,
        1, v_payload_hash, p_action_type, COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, p_idempotency_key, v_status, v_now, v_now
    ) RETURNING public.mb13_p3_action_pack.pack_id INTO v_pack_id;

    INSERT INTO public.mb13_p3_action_pack_revision (
        owner_user_id, pack_id, revision, monitor_revision, trigger_event_id, diff_result_id,
        payload_hash, action_type, target_ref, consent_refs, provenance_refs, steps,
        expires_at, idempotency_key, status, created_at
    ) VALUES (
        p_owner_user_id, v_pack_id, 1, v_monitor_revision, p_trigger_event_id, p_diff_result_id,
        v_payload_hash, p_action_type, COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, p_idempotency_key, v_status, v_now
    );

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_pack_id, p_monitor_id, 'pack_created', NULL, v_status,
        v_now, jsonb_build_object('pack_revision', 1),
        v_monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = v_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) TO mb13_p3_api;

CREATE OR REPLACE FUNCTION public.mb13_p3_revise_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_action_type TEXT,
    p_target_ref JSONB,
    p_consent_refs JSONB,
    p_provenance_refs JSONB,
    p_steps JSONB,
    p_expires_at TIMESTAMPTZ
) RETURNS TABLE(
    pack_id UUID,
    owner_user_id UUID,
    monitor_id UUID,
    monitor_revision INTEGER,
    pack_revision INTEGER,
    payload_hash TEXT,
    action_type TEXT,
    status TEXT
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_new_revision INTEGER;
    v_payload_hash TEXT;
    v_policy_hash TEXT;
    v_old_status TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status IN ('claimed','executing','completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_cannot_revise';
    END IF;

    IF p_expires_at IS NOT NULL AND p_expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF p_action_type NOT IN ('simulate','internal') THEN
        RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
    END IF;

    PERFORM public.mb13_p3_validate_steps(p_owner_user_id, COALESCE(p_steps, '[]'::jsonb));

    v_old_status := v_pack.status;
    v_new_revision := v_pack.pack_revision + 1;
    v_payload_hash := public.mb13_p3_action_pack_payload_hash(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id, p_action_type,
        p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
        p_expires_at, v_pack.idempotency_key, 'proposed'
    );
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    UPDATE public.mb13_p3_action_pack
       SET pack_revision = v_new_revision,
           payload_hash = v_payload_hash,
           action_type = p_action_type,
           target_ref = COALESCE(p_target_ref, '{}'::jsonb),
           consent_refs = COALESCE(p_consent_refs, '[]'::jsonb),
           provenance_refs = COALESCE(p_provenance_refs, '[]'::jsonb),
           steps = COALESCE(p_steps, '[]'::jsonb),
           expires_at = p_expires_at,
           status = 'proposed',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_old_status, 'proposed',
            v_now, jsonb_build_object('pack_revision', v_new_revision, 'reason', 'revise'),
            v_pack.monitor_revision, v_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    INSERT INTO public.mb13_p3_action_pack_revision (
        owner_user_id, pack_id, revision, monitor_revision, trigger_event_id, diff_result_id,
        payload_hash, action_type, target_ref, consent_refs, provenance_refs, steps,
        expires_at, idempotency_key, status, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, v_new_revision, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id, v_payload_hash, p_action_type,
        COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, v_pack.idempotency_key, 'proposed', v_now
    );

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'pack_revised', v_old_status, 'proposed',
        v_now, jsonb_build_object('pack_revision', v_new_revision),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.owner_user_id, ap.monitor_id, ap.monitor_revision,
                        ap.pack_revision, ap.payload_hash, ap.action_type, ap.status
                   FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ) TO mb13_p3_api;

CREATE OR REPLACE FUNCTION public.mb13_p3_authorize_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_expires_at TIMESTAMPTZ DEFAULT NULL
) RETURNS TABLE(
    pack_id UUID,
    owner_user_id UUID,
    status TEXT,
    pack_revision INTEGER,
    authorized_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_auth_expires TIMESTAMPTZ;
    v_policy_hash TEXT;
    v_auth_hash TEXT;
    v_pack_payload_hash TEXT;
    v_target_ref_hash TEXT;
    v_consent_hash TEXT;
    v_provenance_hash TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status NOT IN ('draft','proposed','awaiting_confirmation','authorized') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_cannot_authorize';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth_expires := COALESCE(p_expires_at, v_pack.expires_at, v_now + interval '1 hour');
    IF v_auth_expires <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_authorization_expired';
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);
    v_pack_payload_hash := v_pack.payload_hash;
    v_target_ref_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb));
    v_consent_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb));
    v_provenance_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb));

    v_auth_hash := public.mb13_p3_action_pack_authorization_hash(
        p_pack_id, p_owner_user_id, v_pack.pack_revision, v_pack_payload_hash,
        v_monitor.current_revision, v_pack.action_type, v_target_ref_hash,
        v_consent_hash, v_provenance_hash, v_now, v_auth_expires
    );

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_pack.status, 'authorized',
            v_now, jsonb_build_object('pack_revision', v_pack.pack_revision, 'reason', 'authorize'),
            v_pack.monitor_revision, v_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    INSERT INTO public.mb13_p3_action_pack_authorization (
        owner_user_id, pack_id, pack_revision, authorized_at, expires_at,
        auth_payload_hash, pack_payload_hash, monitor_revision, action_type,
        target_ref_hash, consent_hash, provenance_hash, authorization_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.pack_revision, v_now, v_auth_expires,
        v_auth_hash, v_pack_payload_hash, v_monitor.current_revision, v_pack.action_type,
        v_target_ref_hash, v_consent_hash, v_provenance_hash, v_auth_hash
    );

    UPDATE public.mb13_p3_action_pack
       SET status = 'authorized',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorized', v_pack.status, 'authorized',
        v_now, jsonb_build_object('pack_revision', v_pack.pack_revision, 'expires_at', v_auth_expires),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.owner_user_id, ap.status, ap.pack_revision, v_now, v_auth_expires
                   FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_authorize_action_pack(UUID, UUID, TIMESTAMPTZ) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_authorize_action_pack(UUID, UUID, TIMESTAMPTZ) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_authorize_action_pack(UUID, UUID, TIMESTAMPTZ) TO mb13_p3_api;

-- 15. Start: use governed validator instead of direct cross-macroblock locks.
CREATE OR REPLACE FUNCTION public.mb13_p3_start_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_expected_pack_revision INTEGER
) RETURNS TABLE(
    attempt_id UUID,
    pack_id UUID,
    attempt_number INTEGER,
    status TEXT,
    started_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;

    IF v_pack.status NOT IN ('claimed','executing') OR v_attempt.status IS DISTINCT FROM 'claimed' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_claimed';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    PERFORM public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    UPDATE public.mb13_p3_action_pack_attempt
       SET status = 'executing',
           started_at = v_now
     WHERE attempt_id = p_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = 'executing',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'started', 'claimed', 'executing',
        v_now, jsonb_build_object('attempt_id', p_attempt_id, 'attempt_number', v_attempt.attempt_number),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number, 'executing'::TEXT, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_start_action_pack(UUID, UUID, UUID, INTEGER) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_start_action_pack(UUID, UUID, UUID, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_start_action_pack(UUID, UUID, UUID, INTEGER) TO mb13_p3_executor;

COMMIT;
