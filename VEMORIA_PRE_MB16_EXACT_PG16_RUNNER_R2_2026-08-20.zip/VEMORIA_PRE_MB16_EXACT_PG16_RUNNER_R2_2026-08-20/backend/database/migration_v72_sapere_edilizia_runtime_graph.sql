-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V72 — Sapere runtime graph/workflow canonico
-- Obiettivo:
-- 1) normalizzare nel DB la logica relazionale/workflow dei cataloghi Sapere
-- 2) dare al ramo edilizia una base queryable reale, non solo metadata JSONB
-- 3) mantenere compatibilità col runtime esistente e con il sync catalogo

CREATE TABLE IF NOT EXISTS sapere_relazioni (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id            TEXT NOT NULL,
    related_document_id     TEXT NOT NULL,
    sapere_id               TEXT NULL,
    related_sapere_id       TEXT NULL,
    locale                  TEXT NOT NULL DEFAULT 'it-IT',
    domain                  TEXT NOT NULL DEFAULT 'core',
    relation_type           TEXT NOT NULL DEFAULT 'explicit',
    relation_reason         TEXT NULL,
    workflow_hint           TEXT NULL,
    target_locale           TEXT NOT NULL DEFAULT 'it-IT',
    target_domain           TEXT NOT NULL DEFAULT 'core',
    relation_strength       TEXT NULL,
    metadata_relazione      JSONB NOT NULL DEFAULT '{}'::jsonb,
    source_pack_id          TEXT NULL,
    source_pack_version     TEXT NULL,
    source_manifest_version TEXT NULL,
    source_entry_index      INTEGER NULL,
    source_checksum         TEXT NULL,
    attivo                  BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_sapere_relazioni_doc_related_locale_domain_type_target
    ON sapere_relazioni (documento_id, related_document_id, locale, domain, relation_type, target_locale, target_domain);

CREATE INDEX IF NOT EXISTS idx_sapere_relazioni_documento_lookup
    ON sapere_relazioni (documento_id, locale, domain)
    WHERE attivo = TRUE;

CREATE INDEX IF NOT EXISTS idx_sapere_relazioni_related_lookup
    ON sapere_relazioni (related_document_id, locale, domain)
    WHERE attivo = TRUE;

CREATE INDEX IF NOT EXISTS idx_sapere_relazioni_pack
    ON sapere_relazioni (source_pack_id, locale, domain);

CREATE INDEX IF NOT EXISTS idx_sapere_relazioni_metadata
    ON sapere_relazioni USING GIN (metadata_relazione);

CREATE TABLE IF NOT EXISTS sapere_workflow_profili (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id            TEXT NOT NULL,
    sapere_id               TEXT NULL,
    locale                  TEXT NOT NULL DEFAULT 'it-IT',
    domain                  TEXT NOT NULL DEFAULT 'core',
    phase_code              TEXT NULL,
    phase_label             TEXT NULL,
    phase_rank              INTEGER NOT NULL DEFAULT 0,
    stage_labels            JSONB NOT NULL DEFAULT '[]'::jsonb,
    workflow_profile        JSONB NOT NULL DEFAULT '{}'::jsonb,
    source_pack_id          TEXT NULL,
    source_pack_version     TEXT NULL,
    source_manifest_version TEXT NULL,
    source_entry_index      INTEGER NULL,
    source_checksum         TEXT NULL,
    attivo                  BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_sapere_workflow_profili_documento_locale_domain
    ON sapere_workflow_profili (documento_id, locale, domain);

CREATE INDEX IF NOT EXISTS idx_sapere_workflow_profili_phase
    ON sapere_workflow_profili (phase_code, locale, domain)
    WHERE attivo = TRUE;

CREATE INDEX IF NOT EXISTS idx_sapere_workflow_profili_pack
    ON sapere_workflow_profili (source_pack_id, locale, domain);

CREATE INDEX IF NOT EXISTS idx_sapere_workflow_profili_profile
    ON sapere_workflow_profili USING GIN (workflow_profile);
