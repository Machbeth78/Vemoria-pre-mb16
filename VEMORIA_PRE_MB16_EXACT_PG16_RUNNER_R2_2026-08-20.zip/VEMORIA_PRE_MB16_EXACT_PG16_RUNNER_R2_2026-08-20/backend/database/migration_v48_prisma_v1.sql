-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V48 — Prisma V1
-- Metadati d'uso non sensibili separati da Radar e Sentinella

CREATE TABLE IF NOT EXISTS prisma_sessions (
    session_id              UUID PRIMARY KEY,
    flow_type               TEXT NOT NULL,
    actor_kind              TEXT NULL,
    actor_hash              TEXT NULL,
    entry_screen            TEXT NULL,
    entry_channel           TEXT NULL,
    source_module           TEXT NULL,
    final_status            TEXT NOT NULL DEFAULT 'running',
    started_at_utc          TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    started_at_local        TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    finished_at_utc         TIMESTAMP WITH TIME ZONE NULL,
    finished_at_local       TIMESTAMP WITH TIME ZONE NULL,
    app_context_json        JSONB NULL,
    device_context_json     JSONB NULL,
    summary_json            JSONB NULL,
    created_at              TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_prisma_sessions_flow_status
    ON prisma_sessions (flow_type, final_status, started_at_utc DESC);

CREATE INDEX IF NOT EXISTS idx_prisma_sessions_actor_hash
    ON prisma_sessions (actor_hash, started_at_utc DESC);

CREATE TABLE IF NOT EXISTS prisma_batches (
    batch_id                 UUID PRIMARY KEY,
    event_count              INTEGER NOT NULL DEFAULT 0,
    batch_hash               TEXT NOT NULL,
    upload_attempts          INTEGER NOT NULL DEFAULT 0,
    upload_status            TEXT NOT NULL DEFAULT 'created',
    created_at               TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    last_upload_at           TIMESTAMP WITH TIME ZONE NULL,
    summary_json             JSONB NULL
);

CREATE INDEX IF NOT EXISTS idx_prisma_batches_status_created
    ON prisma_batches (upload_status, created_at DESC);

CREATE TABLE IF NOT EXISTS prisma_usage_events (
    event_id                 UUID PRIMARY KEY,
    session_id               UUID NOT NULL REFERENCES prisma_sessions(session_id) ON DELETE CASCADE,
    batch_id                 UUID NULL REFERENCES prisma_batches(batch_id) ON DELETE SET NULL,
    area                     TEXT NOT NULL,
    feature                  TEXT NOT NULL,
    action                   TEXT NOT NULL,
    outcome                  TEXT NOT NULL,
    screen                   TEXT NULL,
    flow_step                TEXT NULL,
    channel                  TEXT NULL,
    input_mode               TEXT NULL,
    sequence_number          INTEGER NOT NULL,
    fingerprint              TEXT NOT NULL,
    timestamp_utc            TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    timestamp_local          TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    duration_ms              INTEGER NULL,
    app_version              TEXT NULL,
    os_version               TEXT NULL,
    device_model             TEXT NULL,
    locale                   TEXT NULL,
    network_state            TEXT NULL,
    payload_json             JSONB NULL,
    upload_status            TEXT NOT NULL DEFAULT 'pending',
    created_at               TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at               TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_prisma_usage_events_session_seq
    ON prisma_usage_events (session_id, sequence_number, timestamp_utc);

CREATE INDEX IF NOT EXISTS idx_prisma_usage_events_fingerprint
    ON prisma_usage_events (fingerprint, timestamp_utc DESC);

CREATE INDEX IF NOT EXISTS idx_prisma_usage_events_upload_status
    ON prisma_usage_events (upload_status, timestamp_utc DESC);

CREATE INDEX IF NOT EXISTS idx_prisma_usage_events_feature_action
    ON prisma_usage_events (feature, action, timestamp_utc DESC);

CREATE TABLE IF NOT EXISTS prisma_usage_groups (
    group_id                  UUID PRIMARY KEY,
    fingerprint               TEXT NOT NULL UNIQUE,
    area                      TEXT NULL,
    feature                   TEXT NULL,
    action                    TEXT NULL,
    channel                   TEXT NULL,
    input_mode                TEXT NULL,
    outcome                   TEXT NULL,
    total_occurrences         INTEGER NOT NULL DEFAULT 0,
    total_successes           INTEGER NOT NULL DEFAULT 0,
    total_abandons            INTEGER NOT NULL DEFAULT 0,
    total_failures            INTEGER NOT NULL DEFAULT 0,
    avg_duration_ms           DOUBLE PRECISION NULL,
    first_seen_at             TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    last_seen_at              TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    affected_versions_json    JSONB NULL,
    affected_locales_json     JSONB NULL,
    last_payload_sample_json  JSONB NULL,
    created_at                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_prisma_usage_groups_last_seen
    ON prisma_usage_groups (last_seen_at DESC, total_occurrences DESC);

CREATE INDEX IF NOT EXISTS idx_prisma_usage_groups_feature
    ON prisma_usage_groups (feature, total_occurrences DESC);
