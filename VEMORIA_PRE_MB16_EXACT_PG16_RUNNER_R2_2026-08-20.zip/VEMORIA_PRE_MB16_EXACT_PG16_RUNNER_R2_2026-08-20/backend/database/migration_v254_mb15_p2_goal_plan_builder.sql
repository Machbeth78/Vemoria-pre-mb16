-- MB15-P2 — Environment Intelligence + Goal Plan Builder
-- GoalSession and GoalExecutionPlan storage with owner/device scoping and RLS.

BEGIN;

CREATE TABLE IF NOT EXISTS mb15_p2_goal_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    device_ref_hash TEXT NOT NULL DEFAULT '',
    current_goal TEXT NOT NULL,
    payload JSONB NOT NULL DEFAULT '{}',
    current_plan_id UUID,
    plan_revision INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'active',
    last_updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mb15_p2_goal_sessions_owner ON mb15_p2_goal_sessions(owner_id);
CREATE INDEX IF NOT EXISTS idx_mb15_p2_goal_sessions_device ON mb15_p2_goal_sessions(device_ref_hash);

CREATE TABLE IF NOT EXISTS mb15_p2_goal_execution_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    device_ref_hash TEXT NOT NULL DEFAULT '',
    goal_type TEXT NOT NULL,
    session_id UUID REFERENCES mb15_p2_goal_sessions(id) ON DELETE SET NULL,
    plan_state TEXT NOT NULL,
    plan_version INTEGER NOT NULL DEFAULT 1,
    payload JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    validated_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_mb15_p2_goal_execution_plans_owner ON mb15_p2_goal_execution_plans(owner_id);
CREATE INDEX IF NOT EXISTS idx_mb15_p2_goal_execution_plans_session ON mb15_p2_goal_execution_plans(session_id);

ALTER TABLE mb15_p2_goal_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb15_p2_goal_execution_plans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb15_p2_goal_sessions_owner_isolation ON mb15_p2_goal_sessions;
CREATE POLICY mb15_p2_goal_sessions_owner_isolation ON mb15_p2_goal_sessions
    USING (owner_id = _rls_owner_uuid())
    WITH CHECK (owner_id = _rls_owner_uuid());

DROP POLICY IF EXISTS mb15_p2_goal_execution_plans_owner_isolation ON mb15_p2_goal_execution_plans;
CREATE POLICY mb15_p2_goal_execution_plans_owner_isolation ON mb15_p2_goal_execution_plans
    USING (owner_id = _rls_owner_uuid())
    WITH CHECK (owner_id = _rls_owner_uuid());

COMMIT;
