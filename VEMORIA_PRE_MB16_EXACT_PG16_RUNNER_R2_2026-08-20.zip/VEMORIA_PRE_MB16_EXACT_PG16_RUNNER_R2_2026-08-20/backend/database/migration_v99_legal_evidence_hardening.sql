-- VEMORIA V79.2I — Legal evidence hardening
-- Additive migration: stronger legal acceptance evidence + release evidence registry.

ALTER TABLE legal_acceptances
    ADD COLUMN IF NOT EXISTS registry_hash TEXT NULL,
    ADD COLUMN IF NOT EXISTS acceptance_hash TEXT NULL,
    ADD COLUMN IF NOT EXISTS previous_acceptance_hash TEXT NULL,
    ADD COLUMN IF NOT EXISTS evidence_version TEXT NOT NULL DEFAULT 'V79.2I',
    ADD COLUMN IF NOT EXISTS source_context TEXT NULL;

CREATE INDEX IF NOT EXISTS idx_legal_acceptances_acceptance_hash
    ON legal_acceptances(acceptance_hash)
    WHERE acceptance_hash IS NOT NULL;

CREATE TABLE IF NOT EXISTS legal_release_evidence (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    release_id           TEXT NOT NULL,
    pack_name            TEXT NOT NULL,
    pack_sha256          TEXT NOT NULL,
    patch_name           TEXT NULL,
    patch_sha256         TEXT NULL,
    base_release_id      TEXT NULL,
    evidence_manifest_sha256 TEXT NULL,
    created_by           TEXT NULL,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    validation_status    TEXT NOT NULL DEFAULT 'static_only' CHECK (validation_status IN ('static_only', 'runtime_verified', 'legal_validated', 'archived')),
    notes                TEXT NULL,
    metadata_json        JSONB NULL,
    UNIQUE(release_id, pack_name, pack_sha256)
);

CREATE INDEX IF NOT EXISTS idx_legal_release_evidence_release
    ON legal_release_evidence(release_id, created_at DESC);

CREATE TABLE IF NOT EXISTS legal_chain_of_custody_events (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    release_id           TEXT NOT NULL,
    event_type           TEXT NOT NULL,
    actor_name           TEXT NULL,
    counterparty_name    TEXT NULL,
    artifact_name        TEXT NULL,
    artifact_sha256      TEXT NULL,
    occurred_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    event_hash           TEXT NULL,
    previous_event_hash  TEXT NULL,
    notes                TEXT NULL,
    metadata_json        JSONB NULL
);

CREATE INDEX IF NOT EXISTS idx_legal_chain_release_time
    ON legal_chain_of_custody_events(release_id, occurred_at DESC);
