BEGIN;

-- ----------------------------------------------------------------------------
-- v204 — Authoritative rev1 snapshot and locked document provenance
-- ----------------------------------------------------------------------------
-- Applies limited Class-A corrections to MB13-P1 R2:
--   * Server-derived revision 1 snapshot from public.documenti.
--   * Source/grant and monitor revision are required and locked for
--     local_document_revision provenance.
--   * Exact relational chain including grant.source_id = source.id,
--     allowed_documents containment and active state.
--   * monitor_revision binding propagated and verified.
-- ----------------------------------------------------------------------------

-- ----------------------------------------------------------------------------
-- 1. Snapshot helper: ensure revision 1 exists and is derived from documenti.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_ensure_document_revision1_snapshot(
    p_document_id UUID
) RETURNS TABLE(
    id UUID,
    revision INTEGER,
    payload_hash TEXT,
    owner_user_id UUID,
    state TEXT
) AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_doc_owner UUID;
    v_doc_state TEXT;
    v_doc_dati JSONB;
    v_doc_testo TEXT;
    v_existing public.mb13_p1_document_revision%ROWTYPE;
    v_payload_hash TEXT;
    v_revision_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;

    SELECT proprietario_id, stato_elaborazione, dati_strutturati, testo_grezzo
      INTO v_doc_owner, v_doc_state, v_doc_dati, v_doc_testo
      FROM public.documenti
     WHERE id = p_document_id
     FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_document_not_found';
    END IF;
    IF v_doc_owner IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p1_document_not_found_or_owner_mismatch';
    END IF;
    IF v_doc_state NOT IN ('memorizzato','valido','in_elaborazione','elaborato') THEN
        RAISE EXCEPTION 'mb13_p1_document_state_not_available';
    END IF;

    SELECT * INTO v_existing
      FROM public.mb13_p1_document_revision
     WHERE owner_user_id = v_session_owner
       AND document_id = p_document_id
       AND revision = 1
     FOR UPDATE;

    IF FOUND THEN
        RETURN QUERY SELECT v_existing.document_id, v_existing.revision, v_existing.payload_hash, v_existing.owner_user_id, v_existing.state;
        RETURN;
    END IF;

    v_doc_testo := COALESCE(v_doc_testo, '');
    v_doc_dati := COALESCE(v_doc_dati, '{}'::jsonb);

    v_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_doc_owner,
        'document_id', p_document_id,
        'revision', 1,
        'state', 'memorizzato',
        'dati_strutturati', v_doc_dati,
        'testo_grezzo', v_doc_testo,
        'supersedes_revision', NULL
    ));

    INSERT INTO public.mb13_p1_document_revision (
        owner_user_id, document_id, revision, state, payload_hash,
        dati_strutturati, testo_grezzo, supersedes_revision, created_at
    ) VALUES (
        v_doc_owner, p_document_id, 1, 'memorizzato', v_payload_hash,
        v_doc_dati, v_doc_testo, NULL, NOW()
    ) RETURNING revision_id INTO v_revision_id;

    RETURN QUERY SELECT p_document_id, 1, v_payload_hash, v_doc_owner, 'memorizzato'::TEXT;
    RETURN;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_ensure_document_revision1_snapshot(UUID) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_ensure_document_revision1_snapshot(UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_ensure_document_revision1_snapshot(UUID) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p1_ensure_document_revision1_snapshot(UUID) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_ensure_document_revision1_snapshot(UUID) TO mb13_p1_api;

-- ----------------------------------------------------------------------------
-- 2. Document revision append: revision 1 is always server-derived from documenti.
--    Caller-supplied payload/state/hash for revision 1 are ignored or rejected.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_append_document_revision(
    p_owner_user_id UUID,
    p_document_id UUID,
    p_revision INTEGER,
    p_state TEXT,
    p_payload_hash TEXT,
    p_dati_strutturati JSONB,
    p_testo_grezzo TEXT,
    p_supersedes_revision INTEGER DEFAULT NULL
) RETURNS UUID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_doc_owner UUID;
    v_doc_state TEXT;
    v_doc_dati JSONB;
    v_doc_testo TEXT;
    v_last_revision INTEGER := 0;
    v_last_hash TEXT;
    v_revision INTEGER := p_revision;
    v_supersedes INTEGER := p_supersedes_revision;
    v_payload_hash TEXT;
    v_revision_id UUID := gen_random_uuid();
    v_snapshot_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_owner_param_mismatch';
    END IF;
    IF p_state NOT IN ('memorizzato','revoked') THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_state_invalid';
    END IF;

    -- Lock the authoritative document row first.
    SELECT proprietario_id, stato_elaborazione, dati_strutturati, testo_grezzo
      INTO v_doc_owner, v_doc_state, v_doc_dati, v_doc_testo
      FROM public.documenti
     WHERE id = p_document_id
     FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_document_not_found';
    END IF;
    IF v_doc_owner IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p1_document_not_found_or_owner_mismatch';
    END IF;
    IF v_doc_state NOT IN ('memorizzato','valido','in_elaborazione','elaborato') THEN
        RAISE EXCEPTION 'mb13_p1_document_state_not_available';
    END IF;

    -- Lock the highest existing revision for ordering.
    SELECT revision, payload_hash
      INTO v_last_revision, v_last_hash
      FROM public.mb13_p1_document_revision
     WHERE owner_user_id = p_owner_user_id
       AND document_id = p_document_id
     ORDER BY revision DESC
     LIMIT 1
     FOR UPDATE;

    IF NOT FOUND THEN
        v_last_revision := 0;
        v_last_hash := NULL;
    END IF;

    IF v_revision IS NULL THEN
        v_revision := v_last_revision + 1;
    END IF;
    IF v_revision < 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_invalid';
    END IF;

    -- For revisions > 1, auto-snapshot revision 1 from documenti if it does not exist yet.
    IF v_revision > 1 AND v_last_revision = 0 THEN
        v_doc_testo := COALESCE(v_doc_testo, '');
        v_doc_dati := COALESCE(v_doc_dati, '{}'::jsonb);

        v_snapshot_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', v_doc_owner,
            'document_id', p_document_id,
            'revision', 1,
            'state', 'memorizzato',
            'dati_strutturati', v_doc_dati,
            'testo_grezzo', v_doc_testo,
            'supersedes_revision', NULL
        ));

        INSERT INTO public.mb13_p1_document_revision (
            owner_user_id, document_id, revision, state, payload_hash,
            dati_strutturati, testo_grezzo, supersedes_revision, created_at
        ) VALUES (
            v_doc_owner, p_document_id, 1, 'memorizzato', v_snapshot_hash,
            v_doc_dati, v_doc_testo, NULL, NOW()
        );

        v_last_revision := 1;
        v_last_hash := v_snapshot_hash;
    END IF;

    IF v_revision <> v_last_revision + 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_skipped';
    END IF;

    -- Revision 1 must be a server-derived snapshot from documenti.
    IF v_revision = 1 THEN
        IF v_last_revision >= 1 THEN
            RAISE EXCEPTION 'mb13_p1_document_revision_already_exists';
        END IF;

        v_doc_testo := COALESCE(v_doc_testo, '');
        v_doc_dati := COALESCE(v_doc_dati, '{}'::jsonb);

        v_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', v_doc_owner,
            'document_id', p_document_id,
            'revision', 1,
            'state', 'memorizzato',
            'dati_strutturati', v_doc_dati,
            'testo_grezzo', v_doc_testo,
            'supersedes_revision', NULL
        ));

        INSERT INTO public.mb13_p1_document_revision (
            owner_user_id, document_id, revision, state, payload_hash,
            dati_strutturati, testo_grezzo, supersedes_revision, created_at
        ) VALUES (
            v_doc_owner, p_document_id, 1, 'memorizzato', v_payload_hash,
            v_doc_dati, v_doc_testo, NULL, NOW()
        )
        RETURNING revision_id INTO v_revision_id;

        RETURN v_revision_id;
    END IF;

    IF v_supersedes IS NULL THEN
        v_supersedes := v_last_revision;
    END IF;
    IF v_supersedes IS DISTINCT FROM v_last_revision THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_supersedes_mismatch';
    END IF;
    IF v_last_hash IS NULL AND v_last_revision >= 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_baseline_hash_missing';
    END IF;

    IF EXISTS (
        SELECT 1 FROM public.mb13_p1_document_revision
         WHERE owner_user_id = p_owner_user_id
           AND document_id = p_document_id
           AND revision = v_revision
    ) THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_already_exists';
    END IF;

    v_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_doc_owner,
        'document_id', p_document_id,
        'revision', v_revision,
        'state', p_state,
        'dati_strutturati', COALESCE(p_dati_strutturati, '{}'::jsonb),
        'testo_grezzo', COALESCE(p_testo_grezzo, ''),
        'supersedes_revision', v_supersedes
    ));

    INSERT INTO public.mb13_p1_document_revision (
        owner_user_id, document_id, revision, state, payload_hash,
        dati_strutturati, testo_grezzo, supersedes_revision, created_at
    ) VALUES (
        v_doc_owner, p_document_id, v_revision, p_state, v_payload_hash,
        p_dati_strutturati, p_testo_grezzo, v_supersedes, NOW()
    )
    RETURNING revision_id INTO v_revision_id;

    RETURN v_revision_id;
EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION 'mb13_p1_document_revision_concurrent_insert';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) TO mb13_p1_api;

-- ----------------------------------------------------------------------------
-- 3. Monitor-bound document provenance: include monitor_revision and require
--    a non-empty consent chain.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p0_get_target_provenance(
    p_owner UUID,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_monitor_id UUID,
    p_consent_refs JSONB DEFAULT '[]'::jsonb
)
RETURNS TABLE(source_refs JSONB, evidence_refs JSONB) AS $$
DECLARE
    v_id TEXT;
    v_revision INTEGER;
    v_hash TEXT;
    v_owner_text TEXT;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_source_refs JSONB;
BEGIN
    IF p_target_ref IS NULL OR jsonb_typeof(p_target_ref) <> 'object' THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    v_id := p_target_ref->>'id';
    IF v_id IS NULL OR length(trim(v_id)) = 0 THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    BEGIN
        v_revision := (p_target_ref->>'revision')::INTEGER;
    EXCEPTION WHEN invalid_text_representation THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END;

    v_hash := p_target_ref->>'payload_hash';
    v_owner_text := COALESCE(p_target_ref->>'owner_user_id', p_owner::text);

    IF p_target_type <> 'document' THEN
        RETURN QUERY SELECT * FROM public.mb13_p0_get_target_provenance(p_owner, p_target_type, p_target_ref);
        RETURN;
    END IF;

    IF p_monitor_id IS NULL THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner
       AND monitor_id = p_monitor_id
       AND monitor_state = 'active'
       AND target_type = 'document'
       AND target_ref->>'id' = v_id
     FOR SHARE;
    IF NOT FOUND THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    IF jsonb_array_length(COALESCE(p_consent_refs, '[]'::jsonb)) = 0 THEN
        RAISE EXCEPTION 'mb13_p1_provenance_consent_refs_required';
    END IF;

    IF EXISTS (
        SELECT 1
          FROM jsonb_array_elements(p_consent_refs) c
         WHERE jsonb_typeof(c) <> 'object'
    ) THEN
        RAISE EXCEPTION 'mb13_p1_provenance_consent_refs_invalid';
    END IF;

    v_source_refs := COALESCE((
        SELECT jsonb_agg(jsonb_build_object(
            'provenance_kind', 'local_document_revision',
            'document_id', v_id,
            'document_revision', v_revision,
            'document_payload_hash', v_hash,
            'owner_user_id', v_owner_text,
            'monitor_id', p_monitor_id,
            'monitor_revision', v_monitor.current_revision,
            'source_id', c->>'source_id',
            'grant_id', c->>'grant_id'
        ) ORDER BY c->>'source_id', c->>'grant_id')
          FROM jsonb_array_elements(COALESCE(p_consent_refs, '[]'::jsonb)) c
         WHERE jsonb_typeof(c) = 'object'
    ), '[]'::jsonb);

    IF jsonb_array_length(v_source_refs) = 0 THEN
        RAISE EXCEPTION 'mb13_p1_provenance_source_grant_required';
    END IF;

    RETURN QUERY SELECT public.mb13_p0_normalize_jsonb_array(v_source_refs), '[]'::jsonb;
    RETURN;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB, UUID, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB, UUID, JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB, UUID, JSONB) TO mb13_p1_executor;

-- ----------------------------------------------------------------------------
-- 4. Exact provenance resolver: lock and verify source/grant, monitor revision,
--    target type and allowed_documents for local_document_revision.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_resolve_exact_provenance(
    p_owner UUID,
    p_source_refs JSONB,
    p_evidence_refs JSONB
) RETURNS TABLE(
    source_id UUID,
    source_card_id TEXT,
    source_revision_id UUID,
    evidence_id UUID,
    grant_id UUID,
    source_status TEXT,
    evidence_status TEXT,
    grant_status TEXT,
    binding_status TEXT,
    inventory_state TEXT,
    content_hash TEXT
) AS $$
DECLARE
    v_input INTEGER;
    v_distinct INTEGER;
    v_ref JSONB;
    v_kind TEXT;
    v_source_card_count INTEGER;
    v_local_count INTEGER;
    v_resolved INTEGER;
BEGIN
    v_input := COALESCE(jsonb_array_length(COALESCE(p_source_refs, '[]'::jsonb)), 0)
             + COALESCE(jsonb_array_length(COALESCE(p_evidence_refs, '[]'::jsonb)), 0);
    IF v_input = 0 THEN
        RETURN;
    END IF;

    FOR v_ref IN
        SELECT value FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb))
        UNION ALL
        SELECT value FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb))
    LOOP
        IF jsonb_typeof(v_ref) <> 'object' OR v_ref = '{}'::jsonb THEN
            RAISE EXCEPTION 'mb13_p1_provenance_ref_empty';
        END IF;
        v_kind := v_ref->>'provenance_kind';
        IF v_kind IS NULL OR length(trim(v_kind)) = 0 THEN
            RAISE EXCEPTION 'mb13_p1_provenance_kind_missing';
        END IF;
        IF v_kind NOT IN ('source_card', 'local_document_revision') THEN
            RAISE EXCEPTION 'mb13_p1_provenance_kind_unsupported:%', v_kind;
        END IF;
        IF v_kind = 'source_card' THEN
            IF NULLIF(v_ref->>'source_id', '') IS NULL
               OR NULLIF(v_ref->>'source_card_id', '') IS NULL
               OR NULLIF(v_ref->>'source_revision_id', '') IS NULL
               OR NULLIF(v_ref->>'evidence_id', '') IS NULL
               OR NULLIF(v_ref->>'grant_id', '') IS NULL THEN
                RAISE EXCEPTION 'mb13_p1_provenance_source_card_incomplete';
            END IF;
        ELSIF v_kind = 'local_document_revision' THEN
            IF NULLIF(v_ref->>'document_id', '') IS NULL
               OR NULLIF(v_ref->>'document_revision', '') IS NULL
               OR NULLIF(v_ref->>'document_payload_hash', '') IS NULL
               OR NULLIF(v_ref->>'owner_user_id', '') IS NULL
               OR NULLIF(v_ref->>'monitor_id', '') IS NULL
               OR NULLIF(v_ref->>'monitor_revision', '') IS NULL
               OR NULLIF(v_ref->>'source_id', '') IS NULL
               OR NULLIF(v_ref->>'grant_id', '') IS NULL THEN
                RAISE EXCEPTION 'mb13_p1_provenance_local_document_incomplete';
            END IF;
        END IF;
    END LOOP;

    SELECT
        (SELECT COUNT(DISTINCT value) FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)))
      + (SELECT COUNT(DISTINCT value) FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)))
      INTO v_distinct;
    IF v_distinct <> v_input THEN
        RAISE EXCEPTION 'mb13_p1_provenance_duplicate_refs';
    END IF;

    -- ------------------------------------------------------------------------
    -- source_card provenance (unchanged)
    -- ------------------------------------------------------------------------
    SELECT
        (SELECT COUNT(*) FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) WHERE value->>'provenance_kind' = 'source_card')
      + (SELECT COUNT(*) FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) WHERE value->>'provenance_kind' = 'source_card')
      INTO v_source_card_count;

    IF v_source_card_count > 0 THEN
        PERFORM s.id
          FROM public.authorized_memory_sources s
         WHERE s.user_id = p_owner
           AND s.id IN (
               SELECT NULLIF(el.value->>'source_id', '')::UUID
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'source_card'
           )
         ORDER BY s.id
         FOR UPDATE OF s;

        PERFORM g.id
          FROM public.authorized_memory_consent_grants g
         WHERE g.user_id = p_owner
           AND g.id IN (
               SELECT NULLIF(el.value->>'grant_id', '')::UUID
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'source_card'
           )
         ORDER BY g.id
         FOR UPDATE OF g;

        PERFORM i.id
          FROM public.authorized_memory_inventory_items i
         WHERE i.user_id = p_owner
           AND i.id IN (
               SELECT NULLIF(el.value->>'source_revision_id', '')::UUID
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'source_card'
           )
         ORDER BY i.id
         FOR UPDATE OF i;

        PERFORM e.id
          FROM public.authorized_memory_activity_log e
         WHERE e.user_id = p_owner
           AND e.id IN (
               SELECT NULLIF(el.value->>'evidence_id', '')::UUID
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'source_card'
           )
         ORDER BY e.id
         FOR UPDATE OF e;

        PERFORM b.source_card_id
          FROM public.mb12_p0_source_card_binding b
         WHERE b.owner_user_id = p_owner
           AND b.source_card_id IN (
               SELECT el.value->>'source_card_id'
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'source_card'
           )
         ORDER BY b.source_card_id
         FOR UPDATE OF b;

        SELECT COUNT(*) INTO v_resolved
          FROM (
            SELECT el.value
              FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
             WHERE el.value->>'provenance_kind' = 'source_card'
          ) q
          JOIN public.authorized_memory_sources s
            ON s.id = NULLIF(q.value->>'source_id', '')::UUID
           AND s.user_id = p_owner
          JOIN public.authorized_memory_consent_grants g
            ON g.id = NULLIF(q.value->>'grant_id', '')::UUID
           AND g.user_id = p_owner
          JOIN public.authorized_memory_inventory_items i
            ON i.id = NULLIF(q.value->>'source_revision_id', '')::UUID
           AND i.user_id = p_owner
          JOIN public.authorized_memory_activity_log e
            ON e.id = NULLIF(q.value->>'evidence_id', '')::UUID
           AND e.user_id = p_owner
          JOIN public.mb12_p0_source_card_binding b
            ON b.source_card_id = q.value->>'source_card_id'
           AND b.owner_user_id = p_owner
         WHERE s.status = 'active' AND s.revoked_at IS NULL
           AND g.status = 'active' AND g.revoked_at IS NULL AND (g.expires_at IS NULL OR g.expires_at > NOW())
           AND i.deleted_at IS NULL AND i.identity_state <> 'revoked' AND i.memory_state <> 'revoked'
           AND (g.source_id IS NOT DISTINCT FROM s.id)
           AND (i.source_id = s.id)
           AND (i.grant_id IS NOT DISTINCT FROM g.id)
           AND (e.source_id = s.id)
           AND (e.grant_id IS NOT DISTINCT FROM g.id)
           AND b.status = 'active' AND b.revoked_at IS NULL
           AND (b.source_id = s.id)
           AND (b.source_revision_id = i.id)
           AND (b.evidence_id IS NOT DISTINCT FROM e.id)
           AND (b.grant_id IS NOT DISTINCT FROM g.id);

        IF v_resolved <> v_source_card_count THEN
            RAISE EXCEPTION 'mb13_p1_provenance_source_card_unresolved';
        END IF;
    END IF;

    -- ------------------------------------------------------------------------
    -- local_document_revision provenance
    -- ------------------------------------------------------------------------
    SELECT
        (SELECT COUNT(*) FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) WHERE value->>'provenance_kind' = 'local_document_revision')
      + (SELECT COUNT(*) FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) WHERE value->>'provenance_kind' = 'local_document_revision')
      INTO v_local_count;

    IF v_local_count > 0 THEN
        -- Lock source, grant, document revision and monitor in deterministic order.
        PERFORM s.id
          FROM public.authorized_memory_sources s
         WHERE s.user_id = p_owner
           AND s.id IN (
               SELECT DISTINCT NULLIF(el.value->>'source_id', '')::UUID
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'local_document_revision'
           )
         ORDER BY s.id
         FOR UPDATE OF s;

        PERFORM g.id
          FROM public.authorized_memory_consent_grants g
         WHERE g.user_id = p_owner
           AND g.id IN (
               SELECT DISTINCT NULLIF(el.value->>'grant_id', '')::UUID
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'local_document_revision'
           )
         ORDER BY g.id
         FOR UPDATE OF g;

        PERFORM dr.document_id, dr.revision
          FROM public.mb13_p1_document_revision dr
         WHERE dr.owner_user_id = p_owner
           AND (dr.document_id, dr.revision) IN (
               SELECT NULLIF(el.value->>'document_id', '')::UUID, NULLIF(el.value->>'document_revision', '')::INTEGER
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'local_document_revision'
           )
         ORDER BY dr.document_id, dr.revision
         FOR UPDATE OF dr;

        PERFORM t.monitor_id
          FROM public.mb13_p0_monitor_target t
         WHERE t.owner_user_id = p_owner
           AND t.monitor_id IN (
               SELECT DISTINCT NULLIF(el.value->>'monitor_id', '')::UUID
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'local_document_revision'
           )
         ORDER BY t.monitor_id
         FOR UPDATE OF t;

        SELECT COUNT(*) INTO v_resolved
          FROM (
            SELECT el.value
              FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
             WHERE el.value->>'provenance_kind' = 'local_document_revision'
          ) q
          JOIN public.mb13_p1_document_revision dr
            ON dr.document_id = NULLIF(q.value->>'document_id', '')::UUID
           AND dr.owner_user_id = p_owner
           AND dr.revision = NULLIF(q.value->>'document_revision', '')::INTEGER
          JOIN public.mb13_p0_monitor_target t
            ON t.monitor_id = NULLIF(q.value->>'monitor_id', '')::UUID
           AND t.owner_user_id = p_owner
           AND t.monitor_state = 'active'
           AND t.target_type = 'document'
           AND t.target_ref->>'id' = q.value->>'document_id'
           AND t.current_revision = NULLIF(q.value->>'monitor_revision', '')::INTEGER
          JOIN public.authorized_memory_sources s
            ON s.id = NULLIF(q.value->>'source_id', '')::UUID
           AND s.user_id = p_owner
          JOIN public.authorized_memory_consent_grants g
            ON g.id = NULLIF(q.value->>'grant_id', '')::UUID
           AND g.user_id = p_owner
           AND g.source_id = s.id
         WHERE dr.state = 'memorizzato'
           AND dr.payload_hash = q.value->>'document_payload_hash'
           AND s.status = 'active'
           AND s.revoked_at IS NULL
           AND g.status = 'active'
           AND g.revoked_at IS NULL
           AND (g.expires_at IS NULL OR g.expires_at > NOW())
           AND COALESCE(g.constraints->'data_scope'->'allowed_documents', '[]'::jsonb) @> jsonb_build_array(q.value->>'document_id');

        IF v_resolved <> v_local_count THEN
            RAISE EXCEPTION 'mb13_p1_provenance_local_document_unresolved';
        END IF;
    END IF;

    RETURN QUERY
    WITH all_refs AS (
        SELECT value FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb))
        UNION ALL
        SELECT value FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb))
    )
    SELECT
        s.id,
        b.source_card_id,
        i.id,
        e.id,
        g.id,
        s.status,
        'active'::text,
        g.status,
        b.status,
        i.identity_state,
        i.content_hash
    FROM all_refs el
    JOIN public.authorized_memory_sources s
      ON s.id = NULLIF(el.value->>'source_id', '')::UUID
     AND s.user_id = p_owner
    JOIN public.authorized_memory_consent_grants g
      ON g.id = NULLIF(el.value->>'grant_id', '')::UUID
     AND g.user_id = p_owner
    JOIN public.authorized_memory_inventory_items i
      ON i.id = NULLIF(el.value->>'source_revision_id', '')::UUID
     AND i.user_id = p_owner
    JOIN public.authorized_memory_activity_log e
      ON e.id = NULLIF(el.value->>'evidence_id', '')::UUID
     AND e.user_id = p_owner
    JOIN public.mb12_p0_source_card_binding b
      ON b.source_card_id = el.value->>'source_card_id'
     AND b.owner_user_id = p_owner
    WHERE el.value->>'provenance_kind' = 'source_card'
      AND s.status = 'active' AND s.revoked_at IS NULL
      AND g.status = 'active' AND g.revoked_at IS NULL AND (g.expires_at IS NULL OR g.expires_at > NOW())
      AND i.deleted_at IS NULL AND i.identity_state <> 'revoked' AND i.memory_state <> 'revoked'
      AND (g.source_id IS NOT DISTINCT FROM s.id)
      AND (i.source_id = s.id)
      AND (i.grant_id IS NOT DISTINCT FROM g.id)
      AND (e.source_id = s.id)
      AND (e.grant_id IS NOT DISTINCT FROM g.id)
      AND b.status = 'active' AND b.revoked_at IS NULL
      AND (b.source_id = s.id)
      AND (b.source_revision_id = i.id)
      AND (b.evidence_id IS NOT DISTINCT FROM e.id)
      AND (b.grant_id IS NOT DISTINCT FROM g.id)
    UNION ALL
    SELECT
        NULLIF(el.value->>'source_id', '')::UUID,
        NULL::TEXT,
        NULL::UUID,
        NULL::UUID,
        NULLIF(el.value->>'grant_id', '')::UUID,
        NULL::TEXT,
        NULL::TEXT,
        NULL::TEXT,
        NULL::TEXT,
        dr.state,
        dr.payload_hash
    FROM all_refs el
    JOIN public.mb13_p1_document_revision dr
      ON dr.document_id = NULLIF(el.value->>'document_id', '')::UUID
     AND dr.owner_user_id = p_owner
     AND dr.revision = NULLIF(el.value->>'document_revision', '')::INTEGER
    JOIN public.mb13_p0_monitor_target t
      ON t.monitor_id = NULLIF(el.value->>'monitor_id', '')::UUID
     AND t.owner_user_id = p_owner
     AND t.monitor_state = 'active'
     AND t.target_type = 'document'
     AND t.target_ref->>'id' = el.value->>'document_id'
     AND t.current_revision = NULLIF(el.value->>'monitor_revision', '')::INTEGER
    WHERE el.value->>'provenance_kind' = 'local_document_revision'
      AND dr.state = 'memorizzato'
      AND dr.payload_hash = el.value->>'document_payload_hash';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) TO mb13_p1_executor;

-- ----------------------------------------------------------------------------
-- 5. Authorized payload loader: verify monitor revision and lock monitor and
--    revision rows.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_get_authorized_document_payload(
    p_job_id UUID,
    p_preflight_id UUID,
    p_claim_nonce TEXT,
    p_document_id UUID,
    p_revision INTEGER
) RETURNS JSONB AS $$
DECLARE
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_job public.mb13_p1_diff_job_queue%ROWTYPE;
    v_preflight public.mb13_p1_preflight_state%ROWTYPE;
    v_target_ref JSONB;
    v_doc public.mb13_p1_document_revision%ROWTYPE;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    IF p_job_id IS NULL OR p_preflight_id IS NULL OR p_claim_nonce IS NULL OR p_document_id IS NULL OR p_revision IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_parameters_required';
    END IF;

    SELECT * INTO v_job
      FROM public.mb13_p1_diff_job_queue
     WHERE job_id = p_job_id
     FOR SHARE;
    IF NOT FOUND OR v_job.status <> 'claimed' OR v_job.claimed_by IS DISTINCT FROM v_session_user
       OR v_job.claim_nonce IS DISTINCT FROM p_claim_nonce OR v_job.envelope_id IS NOT NULL THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_job_invalid';
    END IF;

    SELECT * INTO v_preflight
      FROM public.mb13_p1_preflight_state
     WHERE preflight_id = p_preflight_id
     FOR SHARE;
    IF NOT FOUND OR v_preflight.job_id IS DISTINCT FROM p_job_id OR v_preflight.used THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_preflight_invalid';
    END IF;
    IF v_preflight.expires_at <= NOW() THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_preflight_expired';
    END IF;

    -- The requested revision must be one of the two refs bound to the preflight.
    IF (v_preflight.baseline_ref->>'id')::UUID = p_document_id
       AND (v_preflight.baseline_ref->>'revision')::INTEGER = p_revision THEN
        v_target_ref := v_preflight.baseline_ref;
    ELSIF (v_preflight.observation_ref->>'id')::UUID = p_document_id
          AND (v_preflight.observation_ref->>'revision')::INTEGER = p_revision THEN
        v_target_ref := v_preflight.observation_ref;
    ELSE
        RAISE EXCEPTION 'mb13_p1_authorized_payload_target_not_in_preflight';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = v_preflight.owner_user_id
       AND monitor_id = v_preflight.monitor_id
     FOR SHARE;
    IF NOT FOUND OR v_monitor.monitor_state <> 'active' OR v_monitor.target_type <> 'document'
       OR (v_monitor.target_ref->>'id')::UUID IS DISTINCT FROM p_document_id THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_monitor_mismatch';
    END IF;
    IF v_preflight.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p1_monitor_revision_changed_between_preflight_and_payload';
    END IF;

    SELECT * INTO v_doc
      FROM public.mb13_p1_document_revision
     WHERE owner_user_id = v_preflight.owner_user_id
       AND document_id = p_document_id
       AND revision = p_revision
       AND state = 'memorizzato'
     FOR SHARE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_document_revision_not_found';
    END IF;
    IF v_doc.payload_hash IS DISTINCT FROM v_target_ref->>'payload_hash' THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_hash_mismatch';
    END IF;
    IF v_doc.owner_user_id IS DISTINCT FROM v_preflight.owner_user_id THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_owner_mismatch';
    END IF;

    RETURN jsonb_build_object(
        'dati_strutturati', COALESCE(v_doc.dati_strutturati, '{}'::jsonb),
        'testo_grezzo', COALESCE(v_doc.testo_grezzo, ''),
        'payload_hash', v_doc.payload_hash,
        'state', v_doc.state
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_get_authorized_document_payload(UUID, UUID, TEXT, UUID, INTEGER) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_get_authorized_document_payload(UUID, UUID, TEXT, UUID, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_get_authorized_document_payload(UUID, UUID, TEXT, UUID, INTEGER) TO mb13_p1_worker;

-- The executor must be able to lock the preflight state and job queue rows.
GRANT SELECT, UPDATE ON public.mb13_p1_preflight_state TO mb13_p1_executor;

COMMIT;
