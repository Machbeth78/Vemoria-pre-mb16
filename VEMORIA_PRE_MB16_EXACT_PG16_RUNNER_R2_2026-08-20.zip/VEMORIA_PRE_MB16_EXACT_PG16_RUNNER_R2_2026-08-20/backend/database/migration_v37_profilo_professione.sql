-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V37 — Profilo Professione + Filtro Tipi Documento
-- Portata dal consolidato V4.6 nel pack Prisma 2026-04-03.
-- Idempotente (ADD COLUMN IF NOT EXISTS).

-- ── 1. Estende utenti con dati professione ───────────────────────────────────
ALTER TABLE utenti
    ADD COLUMN IF NOT EXISTS professione                TEXT,
    -- es: "elettricista", "avvocato", "commercialista", "privato"

    ADD COLUMN IF NOT EXISTS categoria_professione      TEXT,
    -- slug per filtro: "edilizia", "legale", "sanitario", "trasporti", "privato", ...

    ADD COLUMN IF NOT EXISTS sottocategoria_professione TEXT,
    -- opzionale, es: "impiantistica", "diritto_civile"

    ADD COLUMN IF NOT EXISTS mostra_tutti_documenti     BOOLEAN NOT NULL DEFAULT FALSE;
    -- se TRUE: bypass filtro per categoria, mostra tutti i tipi documento

-- ── 2. Estende tipi_documento con compatibilità professioni ─────────────────
ALTER TABLE tipi_documento
    ADD COLUMN IF NOT EXISTS categorie_professioni_compatibili TEXT[];
    -- NULL = visibile a tutti
    -- es: ARRAY['edilizia','elettricista','idraulico']
    -- GIN index per ricerche efficaci

CREATE INDEX IF NOT EXISTS idx_tipodoc_professioni
    ON tipi_documento USING GIN (categorie_professioni_compatibili)
    WHERE categorie_professioni_compatibili IS NOT NULL;
