-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA Migration V50
-- Recovery hook sessioni runtime
--
-- Scopo: persistere lo stato minimo delle sessioni runtime in-memory
-- per consentire il ripristino al riavvio del backend.
--
-- La tabella non è la fonte di verità delle sessioni — quella resta
-- il dizionario in memoria di SessionManager. È solo un checkpoint
-- di recovery: al riavvio, AvvioApp legge le sessioni recenti e
-- le reinserisce nel dizionario in-memoria, evitando che gli utenti
-- attivi si trovino con il contesto azzerato.
--
-- Non va confusa con:
--   - user_runtime_profiles (v47): preferenze lingua/locale utente
--   - trace_sessions (Radar): tracce diagnostiche
--   - la sessione JWT di autenticazione (layer sicurezza separato)
--
-- Idempotente: CREATE TABLE IF NOT EXISTS + IF NOT EXISTS sugli indici.

CREATE TABLE IF NOT EXISTS runtime_sessions (
    utente_id           UUID        PRIMARY KEY
                                    REFERENCES utenti(id) ON DELETE CASCADE,
    documento_corrente  UUID        NULL,           -- nessun FK: documento può essere stato eliminato
    stato               TEXT        NOT NULL DEFAULT 'attiva'
                                    CHECK (stato IN ('attiva', 'in_pausa')),
    avviata_il          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ultimo_accesso      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indice su ultimo_accesso per filtrare rapidamente le sessioni recenti
-- durante il recovery (WHERE ultimo_accesso > NOW() - INTERVAL '...')
CREATE INDEX IF NOT EXISTS idx_runtime_sessions_ultimo_accesso
    ON runtime_sessions (ultimo_accesso DESC);
