-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
--
-- MB13-P1 R2 -- v201b Canonical authority closure.
-- Forward-only, idempotent. Does not modify v196-v200b or v201a.

BEGIN;

-- ----------------------------------------------------------------------------
-- Grant UPDATE on provenance tables so the writer role can acquire real row locks.
-- ----------------------------------------------------------------------------
GRANT UPDATE ON public.authorized_memory_sources TO mb13_p1_writer;
GRANT UPDATE ON public.authorized_memory_consent_grants TO mb13_p1_writer;
GRANT UPDATE ON public.authorized_memory_inventory_items TO mb13_p1_writer;
GRANT UPDATE ON public.authorized_memory_activity_log TO mb13_p1_writer;
GRANT UPDATE ON public.mb12_p0_source_card_binding TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_typed_hash(JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_canonical_jsonb(JSONB) TO mb13_p1_writer;

-- ----------------------------------------------------------------------------
-- Helpers for canonical hashing and schema validation.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_hash_with_absent(p_value JSONB, p_absent BOOLEAN)
RETURNS TEXT AS $$
BEGIN
    IF p_absent OR p_value IS NULL THEN
        RETURN public.mb13_p0_hash_jsonb(jsonb_build_object('t','absent','v',NULL));
    END IF;
    RETURN public.mb13_p1_typed_hash(p_value);
END;
$$ LANGUAGE plpgsql IMMUTABLE
SET search_path = pg_catalog, public;
REVOKE ALL ON FUNCTION public.mb13_p1_hash_with_absent(JSONB, BOOLEAN) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_hash_with_absent(JSONB, BOOLEAN) TO mb13_p1_writer;

CREATE OR REPLACE FUNCTION public.mb13_p1_validate_change_schema(p_changes JSONB)
RETURNS VOID AS $$
DECLARE
    c JSONB;
    v_change_type TEXT;
    v_materiality TEXT;
    v_order_semantics TEXT;
    v_confidence NUMERIC;
    v_before_absent BOOLEAN;
    v_after_absent BOOLEAN;
    v_expected_before_hash TEXT;
    v_expected_after_hash TEXT;
    v_path TEXT;
    v_bstart INTEGER;
    v_bend INTEGER;
    v_astart INTEGER;
    v_aend INTEGER;
BEGIN
    IF jsonb_typeof(COALESCE(p_changes, '[]'::jsonb)) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p1_change_schema_not_array';
    END IF;

    FOR c IN SELECT value FROM jsonb_array_elements(p_changes)
    LOOP
        IF jsonb_typeof(c) <> 'object' THEN
            RAISE EXCEPTION 'mb13_p1_change_schema_element_not_object';
        END IF;

        IF NOT (c ?& ARRAY['path','change_type','before','after','before_absent','after_absent','before_hash','after_hash','materiality','materiality_rule_id','materiality_reason','order_semantics','confidence','source_refs','evidence_refs']) THEN
            RAISE EXCEPTION 'mb13_p1_change_schema_missing_keys';
        END IF;

        v_path := c->>'path';
        IF v_path IS NULL THEN
            RAISE EXCEPTION 'mb13_p1_change_schema_invalid_path';
        END IF;

        v_change_type := c->>'change_type';
        IF v_change_type NOT IN ('ADDED','REMOVED','MODIFIED','UNCHANGED','TYPE_CHANGED','ORDER_CHANGED','AMBIGUOUS') THEN
            RAISE EXCEPTION 'mb13_p1_change_schema_invalid_change_type';
        END IF;

        v_materiality := c->>'materiality';
        IF v_materiality NOT IN ('NONE','COSMETIC','STRUCTURAL','POTENTIALLY_MATERIAL','UNKNOWN') THEN
            RAISE EXCEPTION 'mb13_p1_change_schema_invalid_materiality';
        END IF;

        v_order_semantics := c->>'order_semantics';
        IF v_order_semantics NOT IN ('unknown','keyed_ordered','keyed_unordered','unordered') THEN
            RAISE EXCEPTION 'mb13_p1_change_schema_invalid_order_semantics';
        END IF;

        BEGIN
            v_confidence := (c->>'confidence')::NUMERIC;
            IF v_confidence < 0 OR v_confidence > 1 THEN
                RAISE EXCEPTION 'mb13_p1_change_schema_invalid_confidence';
            END IF;
        EXCEPTION WHEN invalid_text_representation THEN
            RAISE EXCEPTION 'mb13_p1_change_schema_invalid_confidence';
        END;

        IF jsonb_typeof(c->'source_refs') <> 'array' OR jsonb_typeof(c->'evidence_refs') <> 'array' THEN
            RAISE EXCEPTION 'mb13_p1_change_schema_refs_not_array';
        END IF;

        v_before_absent := COALESCE((c->>'before_absent')::BOOLEAN, FALSE);
        v_after_absent := COALESCE((c->>'after_absent')::BOOLEAN, FALSE);

        IF v_before_absent AND (c->'before' IS DISTINCT FROM 'null'::jsonb) THEN
            RAISE EXCEPTION 'mb13_p1_change_schema_absent_before_not_null';
        END IF;
        IF v_after_absent AND (c->'after' IS DISTINCT FROM 'null'::jsonb) THEN
            RAISE EXCEPTION 'mb13_p1_change_schema_absent_after_not_null';
        END IF;

        v_expected_before_hash := public.mb13_p1_hash_with_absent(c->'before', v_before_absent);
        v_expected_after_hash := public.mb13_p1_hash_with_absent(c->'after', v_after_absent);

        IF c->>'before_hash' IS DISTINCT FROM v_expected_before_hash THEN
            RAISE EXCEPTION 'mb13_p1_change_schema_before_hash_mismatch';
        END IF;
        IF c->>'after_hash' IS DISTINCT FROM v_expected_after_hash THEN
            RAISE EXCEPTION 'mb13_p1_change_schema_after_hash_mismatch';
        END IF;

        IF v_change_type <> 'UNCHANGED' AND v_before_absent AND v_after_absent THEN
            RAISE EXCEPTION 'mb13_p1_change_schema_both_absent';
        END IF;

        IF c ? 'before_start' THEN
            BEGIN
                v_bstart := (c->>'before_start')::INTEGER;
                v_bend := (c->>'before_end')::INTEGER;
                IF v_bstart <> -1 AND v_bend <> -1 AND v_bstart > v_bend THEN
                    RAISE EXCEPTION 'mb13_p1_change_schema_invalid_before_range';
                END IF;
            EXCEPTION WHEN invalid_text_representation THEN
                RAISE EXCEPTION 'mb13_p1_change_schema_invalid_before_range';
            END;
        END IF;

        IF c ? 'after_start' THEN
            BEGIN
                v_astart := (c->>'after_start')::INTEGER;
                v_aend := (c->>'after_end')::INTEGER;
                IF v_astart <> -1 AND v_aend <> -1 AND v_astart > v_aend THEN
                    RAISE EXCEPTION 'mb13_p1_change_schema_invalid_after_range';
                END IF;
            EXCEPTION WHEN invalid_text_representation THEN
                RAISE EXCEPTION 'mb13_p1_change_schema_invalid_after_range';
            END;
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql IMMUTABLE
SET search_path = pg_catalog, public;
REVOKE ALL ON FUNCTION public.mb13_p1_validate_change_schema(JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_validate_change_schema(JSONB) TO mb13_p1_writer;

-- ----------------------------------------------------------------------------
-- Strict relational provenance resolver with INNER JOIN semantics, explicit
-- per-column checks and real FOR UPDATE row locks.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_resolve_exact_provenance(
    p_owner UUID,
    p_source_refs JSONB,
    p_evidence_refs JSONB
) RETURNS TABLE(
    source_id UUID,
    source_card_id TEXT,
    source_revision_id UUID,
    evidence_id UUID,
    grant_id UUID,
    source_status TEXT,
    evidence_status TEXT,
    grant_status TEXT,
    binding_status TEXT,
    inventory_state TEXT,
    content_hash TEXT
) AS $$
DECLARE
    v_input_count INTEGER;
    v_distinct_count INTEGER;
    v_resolved_count INTEGER;
BEGIN
    v_input_count := COALESCE(jsonb_array_length(COALESCE(p_source_refs, '[]'::jsonb)), 0)
                   + COALESCE(jsonb_array_length(COALESCE(p_evidence_refs, '[]'::jsonb)), 0);

    SELECT COUNT(*) INTO v_distinct_count
      FROM (
        SELECT DISTINCT r.*
          FROM (
            SELECT
                NULLIF((sr->>'source_id')::text, '')::UUID AS r_source_id,
                NULLIF(sr->>'source_card_id', '') AS r_source_card_id,
                NULLIF((sr->>'source_revision_id')::text, '')::UUID AS r_source_revision_id,
                NULLIF((sr->>'evidence_id')::text, '')::UUID AS r_evidence_id,
                NULLIF((sr->>'grant_id')::text, '')::UUID AS r_grant_id
              FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) sr
            UNION ALL
            SELECT
                NULLIF((er->>'source_id')::text, '')::UUID,
                NULLIF(er->>'source_card_id', ''),
                NULLIF((er->>'source_revision_id')::text, '')::UUID,
                NULLIF((er->>'evidence_id')::text, '')::UUID,
                NULLIF((er->>'grant_id')::text, '')::UUID
              FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) er
          ) r
      ) d;

    IF v_distinct_count <> v_input_count THEN
        RAISE EXCEPTION 'mb13_p1_provenance_duplicate_refs';
    END IF;

    -- Acquire real FOR UPDATE row locks on every referenced provenance row,
    -- in a deterministic table order, before validating and returning them.
    PERFORM s.id
      FROM public.authorized_memory_sources s
     WHERE s.id IN (
        WITH refs AS (
            SELECT NULLIF((x->>'source_id')::text, '')::UUID AS id
              FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) x
            UNION ALL
            SELECT NULLIF((x->>'source_id')::text, '')::UUID
              FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) x
        ) SELECT id FROM refs WHERE id IS NOT NULL
     )
       AND s.user_id = p_owner
     ORDER BY s.id
     FOR UPDATE OF s;

    PERFORM g.id
      FROM public.authorized_memory_consent_grants g
     WHERE g.id IN (
        WITH refs AS (
            SELECT NULLIF((x->>'grant_id')::text, '')::UUID AS id
              FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) x
            UNION ALL
            SELECT NULLIF((x->>'grant_id')::text, '')::UUID
              FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) x
        ) SELECT id FROM refs WHERE id IS NOT NULL
     )
       AND g.user_id = p_owner
     ORDER BY g.id
     FOR UPDATE OF g;

    PERFORM i.id
      FROM public.authorized_memory_inventory_items i
     WHERE i.id IN (
        WITH refs AS (
            SELECT NULLIF((x->>'source_revision_id')::text, '')::UUID AS id
              FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) x
            UNION ALL
            SELECT NULLIF((x->>'source_revision_id')::text, '')::UUID
              FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) x
        ) SELECT id FROM refs WHERE id IS NOT NULL
     )
       AND i.user_id = p_owner
     ORDER BY i.id
     FOR UPDATE OF i;

    PERFORM e.id
      FROM public.authorized_memory_activity_log e
     WHERE e.id IN (
        WITH refs AS (
            SELECT NULLIF((x->>'evidence_id')::text, '')::UUID AS id
              FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) x
            UNION ALL
            SELECT NULLIF((x->>'evidence_id')::text, '')::UUID
              FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) x
        ) SELECT id FROM refs WHERE id IS NOT NULL
     )
       AND e.user_id = p_owner
     ORDER BY e.id
     FOR UPDATE OF e;

    PERFORM b.source_card_id
      FROM public.mb12_p0_source_card_binding b
     WHERE b.source_card_id IN (
        WITH refs AS (
            SELECT NULLIF(x->>'source_card_id', '') AS id
              FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) x
            UNION ALL
            SELECT NULLIF(x->>'source_card_id', '')
              FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) x
        ) SELECT id FROM refs WHERE id IS NOT NULL
     )
       AND b.owner_user_id = p_owner
     ORDER BY b.source_card_id
     FOR UPDATE OF b;

    RETURN QUERY
    WITH refs AS (
        SELECT
            NULLIF((sr->>'source_id')::text, '')::UUID AS r_source_id,
            NULLIF(sr->>'source_card_id', '') AS r_source_card_id,
            NULLIF((sr->>'source_revision_id')::text, '')::UUID AS r_source_revision_id,
            NULLIF((sr->>'evidence_id')::text, '')::UUID AS r_evidence_id,
            NULLIF((sr->>'grant_id')::text, '')::UUID AS r_grant_id
          FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) sr
        UNION ALL
        SELECT
            NULLIF((er->>'source_id')::text, '')::UUID,
            NULLIF(er->>'source_card_id', ''),
            NULLIF((er->>'source_revision_id')::text, '')::UUID,
            NULLIF((er->>'evidence_id')::text, '')::UUID,
            NULLIF((er->>'grant_id')::text, '')::UUID
          FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) er
    )
    SELECT
        s.id,
        b.source_card_id,
        i.id,
        e.id,
        g.id,
        s.status,
        'active'::text,
        g.status,
        b.status,
        i.identity_state,
        i.content_hash
    FROM refs r
    LEFT JOIN public.authorized_memory_sources s
           ON s.id = r.r_source_id
          AND s.user_id = p_owner
    LEFT JOIN public.authorized_memory_consent_grants g
           ON g.id = r.r_grant_id
          AND g.user_id = p_owner
    LEFT JOIN public.authorized_memory_inventory_items i
           ON i.id = r.r_source_revision_id
          AND i.user_id = p_owner
    LEFT JOIN public.authorized_memory_activity_log e
           ON e.id = r.r_evidence_id
          AND e.user_id = p_owner
    LEFT JOIN public.mb12_p0_source_card_binding b
           ON b.source_card_id = r.r_source_card_id
          AND b.owner_user_id = p_owner
    WHERE
      (r.r_source_id IS NULL OR (s.id IS NOT NULL AND s.status = 'active' AND s.revoked_at IS NULL))
      AND (r.r_grant_id IS NULL OR (g.id IS NOT NULL AND g.status = 'active' AND g.revoked_at IS NULL AND (g.expires_at IS NULL OR g.expires_at > NOW())))
      AND (r.r_grant_id IS NULL OR r.r_source_id IS NULL OR g.source_id = r.r_source_id)
      AND (r.r_source_revision_id IS NULL OR (i.id IS NOT NULL AND i.deleted_at IS NULL AND i.identity_state <> 'revoked' AND i.memory_state <> 'revoked'))
      AND (r.r_source_revision_id IS NULL OR r.r_source_id IS NULL OR i.source_id = r.r_source_id)
      AND (r.r_source_revision_id IS NULL OR r.r_grant_id IS NULL OR i.grant_id IS NOT DISTINCT FROM r.r_grant_id)
      AND (r.r_evidence_id IS NULL OR e.id IS NOT NULL)
      AND (r.r_evidence_id IS NULL OR r.r_source_id IS NULL OR e.source_id = r.r_source_id)
      AND (r.r_evidence_id IS NULL OR r.r_grant_id IS NULL OR e.grant_id IS NOT DISTINCT FROM r.r_grant_id)
      AND (r.r_source_card_id IS NULL OR (b.source_card_id IS NOT NULL AND b.status = 'active' AND b.revoked_at IS NULL))
      AND (r.r_source_card_id IS NULL OR r.r_source_id IS NULL OR b.source_id = r.r_source_id)
      AND (r.r_source_card_id IS NULL OR r.r_source_revision_id IS NULL OR b.source_revision_id = r.r_source_revision_id)
      AND (r.r_source_card_id IS NULL OR r.r_evidence_id IS NULL OR b.evidence_id IS NOT DISTINCT FROM r.r_evidence_id)
      AND (r.r_source_card_id IS NULL OR r.r_grant_id IS NULL OR b.grant_id IS NOT DISTINCT FROM r.r_grant_id);

    GET DIAGNOSTICS v_resolved_count = ROW_COUNT;

    IF v_resolved_count <> v_input_count THEN
        RAISE EXCEPTION 'mb13_p1_provenance_count_mismatch';
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;
ALTER FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) TO mb13_p1_executor;



CREATE OR REPLACE FUNCTION public.mb13_p1_verify_exact_provenance(
    p_owner UUID,
    p_source_refs JSONB,
    p_evidence_refs JSONB
) RETURNS VOID AS $$
BEGIN
    PERFORM * FROM public.mb13_p1_resolve_exact_provenance(p_owner, p_source_refs, p_evidence_refs);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;
ALTER FUNCTION public.mb13_p1_verify_exact_provenance(UUID, JSONB, JSONB) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_verify_exact_provenance(UUID, JSONB, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_verify_exact_provenance(UUID, JSONB, JSONB) TO mb13_p1_executor;

-- ----------------------------------------------------------------------------
-- 3-argument preflight: authoritative provenance validation before payload read.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_preflight(
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT
) RETURNS UUID AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_baseline_source_refs JSONB;
    v_baseline_evidence_refs JSONB;
    v_observation_source_refs JSONB;
    v_observation_evidence_refs JSONB;
    v_baseline_rev INTEGER;
    v_observation_rev INTEGER;
    v_preflight_id UUID := gen_random_uuid();
    v_request_hash TEXT;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object'
       OR p_observation_ref->>'id' IS NULL
       OR p_observation_ref->>'revision' IS NULL
       OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
        RAISE EXCEPTION 'mb13_p1_target_owner_mismatch';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;

    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_monitor_id::text, 0));

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = v_owner
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_found';
    END IF;
    IF v_current.monitor_state <> 'active' THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;

    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, v_current.target_ref);
    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, p_observation_ref);

    IF (v_current.target_ref->>'id') IS DISTINCT FROM (p_observation_ref->>'id') THEN
        RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
    END IF;

    v_baseline_rev := (v_current.target_ref->>'revision')::INTEGER;
    v_observation_rev := (p_observation_ref->>'revision')::INTEGER;

    IF v_observation_rev < v_baseline_rev THEN
        RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
    END IF;

    IF v_observation_rev = v_baseline_rev THEN
        IF (v_current.target_ref->>'payload_hash') IS DISTINCT FROM (p_observation_ref->>'payload_hash')
           OR (v_current.target_ref->>'state') IS DISTINCT FROM (p_observation_ref->>'state') THEN
            RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
        END IF;
    END IF;

    PERFORM public.mb13_p0_lock_and_verify_consents(
        v_owner, v_current.consent_refs, v_current.target_type, v_current.target_ref,
        p_required => TRUE, p_strict_relation => FALSE
    );
    PERFORM public.mb13_p0_lock_and_verify_consents(
        v_owner, v_current.consent_refs, v_current.target_type, p_observation_ref,
        p_required => TRUE, p_strict_relation => FALSE
    );

    SELECT source_refs, evidence_refs INTO v_baseline_source_refs, v_baseline_evidence_refs
      FROM public.mb13_p0_get_target_provenance(v_owner, v_current.target_type, v_current.target_ref);
    SELECT source_refs, evidence_refs INTO v_observation_source_refs, v_observation_evidence_refs
      FROM public.mb13_p0_get_target_provenance(v_owner, v_current.target_type, p_observation_ref);

    -- Strict relational provenance: acquires real row locks and raises on any mismatch.
    PERFORM * FROM public.mb13_p1_resolve_exact_provenance(v_owner, v_baseline_source_refs, v_baseline_evidence_refs);
    PERFORM * FROM public.mb13_p1_resolve_exact_provenance(v_owner, v_observation_source_refs, v_observation_evidence_refs);

    IF v_current.target_type NOT IN ('document') THEN
        IF jsonb_array_length(COALESCE(v_baseline_source_refs, '[]'::jsonb)) = 0
           AND jsonb_array_length(COALESCE(v_baseline_evidence_refs, '[]'::jsonb)) = 0 THEN
            RAISE EXCEPTION 'mb13_p1_baseline_provenance_empty';
        END IF;
        IF jsonb_array_length(COALESCE(v_observation_source_refs, '[]'::jsonb)) = 0
           AND jsonb_array_length(COALESCE(v_observation_evidence_refs, '[]'::jsonb)) = 0 THEN
            RAISE EXCEPTION 'mb13_p1_observation_provenance_empty';
        END IF;
    END IF;

    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'baseline_ref', v_current.target_ref,
        'observation_ref', p_observation_ref,
        'diff_kind', p_diff_kind,
        'baseline_source_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs), '[]'::jsonb),
        'baseline_evidence_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs), '[]'::jsonb),
        'observation_source_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_source_refs), '[]'::jsonb),
        'observation_evidence_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_evidence_refs), '[]'::jsonb),
        'consent_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_current.consent_refs), '[]'::jsonb)
    ));

    INSERT INTO public.mb13_p1_preflight_state (
        preflight_id, owner_user_id, monitor_id, observation_ref, diff_kind,
        baseline_source_refs, baseline_evidence_refs,
        observation_source_refs, observation_evidence_refs,
        consent_refs, monitor_revision, baseline_ref, request_hash
    ) VALUES (
        v_preflight_id, v_owner, p_monitor_id, p_observation_ref, p_diff_kind,
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_source_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_evidence_refs), '[]'::jsonb),
        public.mb13_p0_normalize_jsonb_array(v_current.consent_refs),
        v_current.current_revision,
        v_current.target_ref,
        v_request_hash
    );

    RETURN v_preflight_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;
ALTER FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) TO mb13_p1_writer;

-- ----------------------------------------------------------------------------
-- 14-argument canonical diff writer: schema validation, canonical content hash
-- computed after provenance overwrite, and per-job idempotency.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_write_diff(
    p_preflight_id UUID,
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT,
    p_changes JSONB,
    p_change_count INTEGER,
    p_material_change_count INTEGER,
    p_diff_state TEXT,
    p_summary TEXT,
    p_algorithm_version TEXT,
    p_normalization_version TEXT,
    p_request_payload JSONB,
    p_result_payload JSONB,
    p_worker_result_envelope JSONB DEFAULT NULL
) RETURNS TABLE(diff_id UUID, revision INTEGER, content_hash TEXT, diff_state TEXT, change_count INTEGER, material_change_count INTEGER, summary TEXT, changes JSONB) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_preflight public.mb13_p1_preflight_state%ROWTYPE;
    v_baseline_source_refs JSONB;
    v_baseline_evidence_refs JSONB;
    v_observation_source_refs JSONB;
    v_observation_evidence_refs JSONB;
    v_canonical_consent_refs JSONB;
    v_canonical_changes JSONB;
    v_change_count INTEGER;
    v_material_change_count INTEGER;
    v_diff_state TEXT;
    v_summary TEXT;
    v_content_hash TEXT;
    v_input_hash TEXT;
    v_output_hash TEXT;
    v_envelope_input_hash TEXT;
    v_envelope_output_hash TEXT;
    v_existing_diff_id UUID;
    v_existing_revision INTEGER;
    v_diff_id UUID;
    v_revision INTEGER := 1;
    v_event_type TEXT;
    v_event_id UUID;
    v_event_time TIMESTAMPTZ := NOW();
    v_event_payload_hash TEXT;
    v_event_result_payload JSONB;
    v_expected_algorithm TEXT;
    v_job_id UUID;
    v_envelope_id UUID;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_preflight_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_preflight_required';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'id' IS NULL OR p_observation_ref->>'revision' IS NULL OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;

    v_expected_algorithm := CASE p_diff_kind
        WHEN 'structured' THEN 'mb13-p1-r2-structured'
        WHEN 'text' THEN 'mb13-p1-r2-text'
    END;

    IF p_algorithm_version IS NULL OR p_algorithm_version <> v_expected_algorithm THEN
        RAISE EXCEPTION 'mb13_p1_algorithm_version_invalid';
    END IF;
    IF p_normalization_version IS NULL OR p_normalization_version <> 'mb13-p1-r2' THEN
        RAISE EXCEPTION 'mb13_p1_normalization_version_invalid';
    END IF;

    -- Server-side schema validation for every change.
    PERFORM public.mb13_p1_validate_change_schema(p_changes);

    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_monitor_id::text, 0));

    SELECT * INTO v_preflight
      FROM public.mb13_p1_preflight_state
     WHERE preflight_id = p_preflight_id
       AND owner_user_id = v_owner
       AND monitor_id = p_monitor_id
       AND used = FALSE
       AND expires_at > NOW()
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_preflight_invalid_or_expired';
    END IF;

    IF v_preflight.observation_ref IS DISTINCT FROM p_observation_ref
       OR v_preflight.diff_kind IS DISTINCT FROM p_diff_kind THEN
        RAISE EXCEPTION 'mb13_p1_preflight_mismatch';
    END IF;

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = v_owner
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_found';
    END IF;
    IF v_current.monitor_state <> 'active' THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;
    IF v_preflight.monitor_revision IS DISTINCT FROM v_current.current_revision THEN
        RAISE EXCEPTION 'mb13_p1_monitor_revision_changed_between_preflight_and_write';
    END IF;
    IF v_preflight.baseline_ref IS DISTINCT FROM v_current.target_ref THEN
        RAISE EXCEPTION 'mb13_p1_baseline_changed_between_preflight_and_write';
    END IF;

    UPDATE public.mb13_p1_preflight_state
       SET used = TRUE
     WHERE preflight_id = p_preflight_id;

    v_baseline_source_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.baseline_source_refs);
    v_baseline_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.baseline_evidence_refs);
    v_observation_source_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.observation_source_refs);
    v_observation_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.observation_evidence_refs);
    v_canonical_consent_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.consent_refs);

    v_canonical_changes := public.mb13_p0_normalize_jsonb_array(p_changes);

    -- Server-side provenance replaces any client-supplied source/evidence refs.
    v_canonical_changes := COALESCE((
        SELECT jsonb_agg(
            jsonb_set(
                jsonb_set(c.value, '{source_refs}', COALESCE(v_baseline_source_refs, '[]'::jsonb) || COALESCE(v_observation_source_refs, '[]'::jsonb)),
                '{evidence_refs}', COALESCE(v_baseline_evidence_refs, '[]'::jsonb) || COALESCE(v_observation_evidence_refs, '[]'::jsonb))
        )
        FROM jsonb_array_elements(v_canonical_changes) c
    ), '[]'::jsonb);

    v_change_count := jsonb_array_length(v_canonical_changes);

    SELECT COUNT(*) INTO v_material_change_count
      FROM jsonb_array_elements(v_canonical_changes) AS c
     WHERE (c.value->>'materiality') = 'POTENTIALLY_MATERIAL';

    IF v_change_count = 0 THEN
        v_diff_state := 'no_change';
    ELSE
        SELECT CASE WHEN EXISTS (
            SELECT 1 FROM jsonb_array_elements(v_canonical_changes) c
             WHERE (c.value->>'change_type') = 'AMBIGUOUS'
        ) THEN 'ambiguous' ELSE 'computed' END INTO v_diff_state;
    END IF;

    v_summary := CASE WHEN v_change_count = 0
        THEN 'No changes detected'
        ELSE format('Detected %s change(s), %s material', v_change_count, v_material_change_count)
    END;

    IF p_change_count IS DISTINCT FROM v_change_count THEN
        RAISE EXCEPTION 'mb13_p1_change_count_mismatch';
    END IF;
    IF p_material_change_count IS DISTINCT FROM v_material_change_count THEN
        RAISE EXCEPTION 'mb13_p1_material_change_count_mismatch';
    END IF;
    IF p_diff_state IS DISTINCT FROM v_diff_state THEN
        RAISE EXCEPTION 'mb13_p1_diff_state_mismatch';
    END IF;
    IF p_summary IS DISTINCT FROM v_summary THEN
        RAISE EXCEPTION 'mb13_p1_summary_mismatch';
    END IF;

    -- Canonical content hash is computed AFTER provenance overwrite and derived state.
    v_content_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'baseline_ref', v_current.target_ref,
        'observation_ref', p_observation_ref,
        'diff_kind', p_diff_kind,
        'changes', v_canonical_changes,
        'algorithm_version', p_algorithm_version,
        'normalization_version', p_normalization_version,
        'source_refs', public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs),
        'evidence_refs', public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs),
        'consent_refs', v_canonical_consent_refs
    ));

    IF p_worker_result_envelope IS NOT NULL THEN
        v_envelope_input_hash := p_worker_result_envelope->>'input_hash';
        v_envelope_output_hash := p_worker_result_envelope->>'output_hash';
        v_job_id := NULLIF(p_worker_result_envelope->>'job_id', '')::UUID;
        v_envelope_id := NULLIF(p_worker_result_envelope->>'envelope_id', '')::UUID;

        v_input_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'monitor_revision', v_current.current_revision,
            'baseline_ref', v_current.target_ref,
            'observation_ref', p_observation_ref,
            'baseline_source_refs', v_baseline_source_refs,
            'baseline_evidence_refs', v_baseline_evidence_refs,
            'observation_source_refs', v_observation_source_refs,
            'observation_evidence_refs', v_observation_evidence_refs,
            'consent_refs', v_canonical_consent_refs,
            'request_hash', v_preflight.request_hash,
            'algorithm_version', p_algorithm_version,
            'normalization_version', p_normalization_version
        ));

        v_output_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'changes', v_canonical_changes,
            'change_count', v_change_count,
            'material_change_count', v_material_change_count,
            'diff_state', v_diff_state,
            'summary', v_summary
        ));

        IF v_input_hash IS DISTINCT FROM v_envelope_input_hash THEN
            RAISE EXCEPTION 'mb13_p1_worker_envelope_input_hash_mismatch';
        END IF;
        IF v_output_hash IS DISTINCT FROM v_envelope_output_hash THEN
            RAISE EXCEPTION 'mb13_p1_worker_envelope_output_hash_mismatch';
        END IF;

        -- Per-job idempotency: one diff per job.
        IF v_job_id IS NOT NULL THEN
            SELECT d.diff_id, d.current_revision
              INTO v_existing_diff_id, v_existing_revision
              FROM public.mb13_p1_universal_diff d
             WHERE d.owner_user_id = v_owner
               AND d.job_id = v_job_id
               AND d.content_hash = v_content_hash;
            IF FOUND THEN
                RETURN QUERY SELECT v_existing_diff_id, v_existing_revision, v_content_hash, v_diff_state, v_change_count, v_material_change_count, v_summary, v_canonical_changes;
                RETURN;
            END IF;
        END IF;
    END IF;

    -- Global idempotency on content hash: identical canonical inputs yield the same diff.
    SELECT d.diff_id, d.current_revision
      INTO v_existing_diff_id, v_existing_revision
      FROM public.mb13_p1_universal_diff d
     WHERE d.owner_user_id = v_owner
       AND d.content_hash = v_content_hash
     LIMIT 1;
    IF FOUND THEN
        RETURN QUERY SELECT v_existing_diff_id, v_existing_revision, v_content_hash, v_diff_state, v_change_count, v_material_change_count, v_summary, v_canonical_changes;
        RETURN;
    END IF;

    v_diff_id := gen_random_uuid();

    v_event_result_payload := COALESCE(p_result_payload, '{}'::jsonb) || jsonb_build_object(
        'diff_id', v_diff_id,
        'diff_revision', v_revision,
        'diff_content_hash', v_content_hash,
        'diff_kind', p_diff_kind,
        'diff_state', v_diff_state,
        'change_count', v_change_count,
        'material_change_count', v_material_change_count,
        'no_auto_action', true,
        'no_auto_notification', true,
        'baseline_source_refs', v_baseline_source_refs,
        'baseline_evidence_refs', v_baseline_evidence_refs,
        'observation_source_refs', v_observation_source_refs,
        'observation_evidence_refs', v_observation_evidence_refs,
        'effective_consent_refs', v_canonical_consent_refs
    );

    INSERT INTO public.mb13_p1_universal_diff (
        owner_user_id, diff_id, monitor_id, monitor_revision, baseline_ref, observation_ref,
        diff_kind, diff_state, summary, change_count, material_change_count, changes,
        source_refs, evidence_refs, consent_refs, algorithm_version, normalization_version,
        payload_hash, content_hash, current_revision, request_payload, result_payload,
        envelope_id, job_id
    ) VALUES (
        v_owner, v_diff_id, p_monitor_id, v_current.current_revision, v_current.target_ref, p_observation_ref,
        p_diff_kind, v_diff_state, v_summary, v_change_count, v_material_change_count, v_canonical_changes,
        public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs),
        public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs),
        v_canonical_consent_refs,
        p_algorithm_version, p_normalization_version,
        v_content_hash, v_content_hash, v_revision, COALESCE(p_request_payload, '{}'::jsonb), v_event_result_payload,
        v_envelope_id, v_job_id
    );

    INSERT INTO public.mb13_p1_universal_diff_revision (
        owner_user_id, diff_id, revision, monitor_revision, baseline_ref, observation_ref,
        diff_kind, diff_state, summary, change_count, material_change_count, changes,
        source_refs, evidence_refs, consent_refs, algorithm_version, normalization_version,
        payload_hash, content_hash, request_payload, result_payload,
        envelope_id, job_id
    ) VALUES (
        v_owner, v_diff_id, v_revision, v_current.current_revision, v_current.target_ref, p_observation_ref,
        p_diff_kind, v_diff_state, v_summary, v_change_count, v_material_change_count, v_canonical_changes,
        public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs),
        public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs),
        v_canonical_consent_refs,
        p_algorithm_version, p_normalization_version,
        v_content_hash, v_content_hash, COALESCE(p_request_payload, '{}'::jsonb), v_event_result_payload,
        v_envelope_id, v_job_id
    );

    IF v_diff_state = 'no_change' THEN
        v_event_type := 'NO_CHANGE_RECORDED';
    ELSE
        v_event_type := 'CHANGE_CANDIDATE_RECORDED';
    END IF;

    v_event_id := gen_random_uuid();
    v_event_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'event_id', v_event_id,
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'event_type', v_event_type,
        'event_status', 'recorded',
        'event_time', to_jsonb(v_event_time),
        'observed_ref', p_observation_ref,
        'source_refs', public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs),
        'evidence_refs', public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs),
        'consent_refs', v_canonical_consent_refs,
        'reason', NULL,
        'result_payload', v_event_result_payload
    ));

    INSERT INTO public.mb13_p0_monitor_event_ledger (
        event_id, owner_user_id, monitor_id, monitor_revision, event_type, event_status, event_time,
        observed_ref, source_refs, evidence_refs, consent_refs, reason, result_payload, payload_hash
    ) VALUES (
        v_event_id, v_owner, p_monitor_id, v_current.current_revision, v_event_type, 'recorded', v_event_time,
        p_observation_ref,
        public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs),
        public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs),
        v_canonical_consent_refs, NULL, v_event_result_payload, v_event_payload_hash
    );

    RETURN QUERY SELECT v_diff_id, v_revision, v_content_hash, v_diff_state, v_change_count, v_material_change_count, v_summary, v_canonical_changes;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;
ALTER FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) TO mb13_p1_writer;

-- ----------------------------------------------------------------------------
-- Content-hash recalculation function for audit/verification.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_verify_content_hash(p_diff_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
    v_diff public.mb13_p1_universal_diff%ROWTYPE;
    v_recomputed TEXT;
BEGIN
    SELECT * INTO v_diff
      FROM public.mb13_p1_universal_diff
     WHERE diff_id = p_diff_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_diff_not_found';
    END IF;

    v_recomputed := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'algorithm_version', v_diff.algorithm_version,
        'baseline_ref', v_diff.baseline_ref,
        'change_count', v_diff.change_count,
        'changes', v_diff.changes,
        'consent_refs', v_diff.consent_refs,
        'diff_kind', v_diff.diff_kind,
        'diff_state', v_diff.diff_state,
        'evidence_refs', v_diff.evidence_refs,
        'material_change_count', v_diff.material_change_count,
        'monitor_id', v_diff.monitor_id,
        'monitor_revision', v_diff.monitor_revision,
        'normalization_version', v_diff.normalization_version,
        'observation_ref', v_diff.observation_ref,
        'owner_user_id', v_diff.owner_user_id,
        'source_refs', v_diff.source_refs,
        'summary', v_diff.summary
    ));

    RETURN v_recomputed = v_diff.content_hash;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = pg_catalog, public;
ALTER FUNCTION public.mb13_p1_verify_content_hash(UUID) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_verify_content_hash(UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_verify_content_hash(UUID) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_verify_content_hash(UUID) TO mb13_p1_api;

-- ----------------------------------------------------------------------------
-- Document revision guard: only the executor-owned function may insert.
-- UPDATE and DELETE remain unconditionally blocked by the immutable guard.
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_mb13_p1_document_revision_guard ON public.mb13_p1_document_revision;
CREATE OR REPLACE FUNCTION public.mb13_p1_document_revision_guard()
RETURNS trigger AS $$
DECLARE
    v_is_superuser BOOLEAN;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = current_user;
    IF current_user = 'mb13_p1_executor' OR COALESCE(v_is_superuser, FALSE) THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;
    RAISE EXCEPTION 'mb13_p1_document_revision_direct_dml_blocked';
END;
$$ LANGUAGE plpgsql
SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_mb13_p1_document_revision_guard ON public.mb13_p1_document_revision;
CREATE TRIGGER trg_mb13_p1_document_revision_guard
    BEFORE INSERT OR DELETE OR UPDATE ON public.mb13_p1_document_revision
    FOR EACH STATEMENT
    EXECUTE FUNCTION public.mb13_p1_document_revision_guard();

-- ----------------------------------------------------------------------------
-- Document revision append: server-derived owner/hash, automatic rev1 snapshot,
-- monotonic revision sequence and optimistic row locking.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_append_document_revision(
    p_owner_user_id UUID,
    p_document_id UUID,
    p_revision INTEGER,
    p_state TEXT,
    p_payload_hash TEXT,
    p_dati_strutturati JSONB,
    p_testo_grezzo TEXT,
    p_supersedes_revision INTEGER DEFAULT NULL
) RETURNS UUID AS $$
DECLARE
    v_doc_owner UUID;
    v_last_revision INTEGER := 0;
    v_last_hash TEXT;
    v_revision INTEGER := p_revision;
    v_supersedes INTEGER := p_supersedes_revision;
    v_payload_hash TEXT;
    v_revision_id UUID := gen_random_uuid();
    v_doc_dati JSONB;
    v_doc_testo TEXT;
BEGIN
    IF p_state NOT IN ('memorizzato','revoked') THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_state_invalid';
    END IF;

    -- Owner is derived from the document, not the caller.
    SELECT proprietario_id, dati_strutturati, testo_grezzo
      INTO v_doc_owner, v_doc_dati, v_doc_testo
      FROM public.documenti
     WHERE id = p_document_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_document_not_found';
    END IF;
    IF v_doc_owner IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p1_document_not_found_or_owner_mismatch';
    END IF;

    -- Optimistic lock on the previous revision row (if any).
    SELECT revision, payload_hash INTO v_last_revision, v_last_hash
      FROM public.mb13_p1_document_revision
     WHERE owner_user_id = p_owner_user_id
       AND document_id = p_document_id
     ORDER BY revision DESC
     LIMIT 1
     FOR UPDATE;

    IF v_last_revision IS NULL THEN
        v_last_revision := 0;
    END IF;

    IF v_revision IS NULL THEN
        v_revision := v_last_revision + 1;
    END IF;
    IF v_revision < 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_invalid';
    END IF;

    -- Automatic rev1 snapshot from the documenti row before a higher revision.
    IF v_revision > 1 AND v_last_revision = 0 THEN
        INSERT INTO public.mb13_p1_document_revision (
            owner_user_id, document_id, revision, state, payload_hash,
            dati_strutturati, testo_grezzo, supersedes_revision, created_at
        ) VALUES (
            v_doc_owner, p_document_id, 1, 'memorizzato',
            public.mb13_p0_hash_jsonb(jsonb_build_object(
                'owner_user_id', v_doc_owner,
                'document_id', p_document_id,
                'revision', 1,
                'state', 'memorizzato',
                'dati_strutturati', COALESCE(v_doc_dati, '{}'::jsonb),
                'testo_grezzo', COALESCE(v_doc_testo, ''),
                'supersedes_revision', NULL
            )),
            COALESCE(v_doc_dati, '{}'::jsonb), COALESCE(v_doc_testo, ''), NULL, NOW()
        );
        v_last_revision := 1;
        v_last_hash := (
            SELECT payload_hash FROM public.mb13_p1_document_revision
             WHERE owner_user_id = v_doc_owner AND document_id = p_document_id AND revision = 1
        );
    END IF;

    IF v_revision <> v_last_revision + 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_skipped';
    END IF;

    IF v_supersedes IS NULL THEN
        v_supersedes := v_last_revision;
    END IF;
    IF v_supersedes IS DISTINCT FROM v_last_revision THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_supersedes_mismatch';
    END IF;
    IF v_last_hash IS NULL AND v_last_revision >= 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_baseline_hash_missing';
    END IF;

    IF EXISTS (
        SELECT 1 FROM public.mb13_p1_document_revision
         WHERE owner_user_id = p_owner_user_id
           AND document_id = p_document_id
           AND revision = v_revision
    ) THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_already_exists';
    END IF;

    -- Payload hash is derived server-side; the caller-supplied value is ignored.
    v_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_doc_owner,
        'document_id', p_document_id,
        'revision', v_revision,
        'state', p_state,
        'dati_strutturati', COALESCE(p_dati_strutturati, '{}'::jsonb),
        'testo_grezzo', COALESCE(p_testo_grezzo, ''),
        'supersedes_revision', v_supersedes
    ));

    INSERT INTO public.mb13_p1_document_revision (
        owner_user_id, document_id, revision, state, payload_hash,
        dati_strutturati, testo_grezzo, supersedes_revision, created_at
    ) VALUES (
        v_doc_owner, p_document_id, v_revision, p_state, v_payload_hash,
        p_dati_strutturati, p_testo_grezzo, v_supersedes, NOW()
    )
    RETURNING revision_id INTO v_revision_id;

    RETURN v_revision_id;
EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION 'mb13_p1_document_revision_concurrent_insert';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;
ALTER FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) TO mb13_p1_executor;

COMMIT;
