-- ===========================================================================
-- VEMORA V248 — MB14-P4 Relationship Intelligence, Goal-Driven Communication
-- and Protected Content / Private Vault Foundation
-- ===========================================================================
-- Scope:
--   1. Add PROTECTED_VAULT privacy classification to conversation/card/message.
--   2. Add vault session, protected-content vault and access-log tables.
--   3. Extend relationship memory/commitment/open-loop/status with privacy flags.
--   4. Provide RLS owner isolation and grants.
--
-- NON modifica MB0→MB13 / MB14-P0/P1/P2/P3; solo additive.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- 1. Vault foundation tables (created first because conversation tables FK them)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vault_pin (
    owner_user_id       UUID PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    pin_hash            TEXT NOT NULL,
    salt                TEXT NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS vault_session (
    session_id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    device_id           TEXT NOT NULL,
    auth_method         TEXT NOT NULL
        CHECK (auth_method IN ('biometric','pin','foundation')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at          TIMESTAMPTZ NOT NULL,
    revoked_at          TIMESTAMPTZ,
    UNIQUE (owner_user_id, device_id, session_id)
);

CREATE INDEX IF NOT EXISTS idx_vault_session_owner
    ON vault_session(owner_user_id, revoked_at, expires_at);

CREATE TABLE IF NOT EXISTS vault_item (
    vault_item_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id     UUID REFERENCES relationship(relationship_id) ON DELETE SET NULL,
    conversation_id     UUID REFERENCES conversation(conversation_id) ON DELETE CASCADE,
    message_id          UUID REFERENCES conversation_message(message_id) ON DELETE SET NULL,
    card_id             UUID REFERENCES conversation_card(card_id) ON DELETE SET NULL,
    item_type           TEXT NOT NULL
        CHECK (item_type IN ('message','card','attachment')),
    protected_body      TEXT,
    protected_payload   JSONB NOT NULL DEFAULT '{}'::jsonb,
    protected_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    restored_at         TIMESTAMPTZ,
    sort_timestamp      TIMESTAMPTZ NOT NULL,
    provenance          JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_vault_item_owner
    ON vault_item(owner_user_id, protected_at DESC);
CREATE INDEX IF NOT EXISTS idx_vault_item_message
    ON vault_item(owner_user_id, message_id);
CREATE INDEX IF NOT EXISTS idx_vault_item_card
    ON vault_item(owner_user_id, card_id);

CREATE TABLE IF NOT EXISTS vault_access_log (
    log_id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    session_id          UUID REFERENCES vault_session(session_id) ON DELETE SET NULL,
    action              TEXT NOT NULL,
    item_type           TEXT,
    item_id             TEXT,
    success             BOOLEAN NOT NULL DEFAULT TRUE,
    error               TEXT,
    timestamp_utc       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_vault_access_log_owner
    ON vault_access_log(owner_user_id, timestamp_utc DESC);

-- ---------------------------------------------------------------------------
-- 1b. Extend message_type enum to include SOURCE_CARD (needed for Desk source-card send).
-- ---------------------------------------------------------------------------
ALTER TABLE conversation_message
    DROP CONSTRAINT IF EXISTS conversation_message_message_type_check;
ALTER TABLE conversation_message
    ADD CONSTRAINT conversation_message_message_type_check
    CHECK (message_type IN (
        'TEXT','ATTACHMENT','CARD','SYSTEM_EVENT',
        'DOCUMENT_CARD','CONTACT_CARD','EVIDENCE_CARD','ACTION_CARD',
        'PROCEDURE_CARD','SAFETY_CARD','THREAT_CARD','INCIDENT_CARD',
        'EXPERIENCE_CAPSULE','SOURCE_CARD'
    ));

ALTER TABLE conversation_draft
    DROP CONSTRAINT IF EXISTS conversation_draft_message_type_check;
ALTER TABLE conversation_draft
    ADD CONSTRAINT conversation_draft_message_type_check
    CHECK (message_type IN (
        'TEXT','ATTACHMENT','CARD','SYSTEM_EVENT',
        'DOCUMENT_CARD','CONTACT_CARD','EVIDENCE_CARD','ACTION_CARD',
        'PROCEDURE_CARD','SAFETY_CARD','THREAT_CARD','INCIDENT_CARD',
        'EXPERIENCE_CAPSULE','SOURCE_CARD'
    ));

-- ---------------------------------------------------------------------------
-- 2. Extend conversation_message with protected-content columns
-- ---------------------------------------------------------------------------
ALTER TABLE conversation_message
    ADD COLUMN IF NOT EXISTS privacy_classification TEXT NOT NULL DEFAULT 'NORMAL';

ALTER TABLE conversation_message
    DROP CONSTRAINT IF EXISTS conversation_message_privacy_classification_check;
ALTER TABLE conversation_message
    ADD CONSTRAINT conversation_message_privacy_classification_check
    CHECK (privacy_classification IN ('NORMAL','SENSITIVE','HIGH_PRIVACY','PROTECTED_VAULT'));

ALTER TABLE conversation_message
    ADD COLUMN IF NOT EXISTS is_vault_protected BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE conversation_message
    ADD COLUMN IF NOT EXISTS vault_item_id UUID REFERENCES vault_item(vault_item_id) ON DELETE SET NULL;

-- ---------------------------------------------------------------------------
-- 3. Extend conversation_card with protected-content columns
-- ---------------------------------------------------------------------------
ALTER TABLE conversation_card
    DROP CONSTRAINT IF EXISTS conversation_card_privacy_classification_check;
ALTER TABLE conversation_card
    ADD CONSTRAINT conversation_card_privacy_classification_check
    CHECK (privacy_classification IN ('NORMAL','SENSITIVE','HIGH_PRIVACY','PROTECTED_VAULT'));

ALTER TABLE conversation_card
    ADD COLUMN IF NOT EXISTS is_vault_protected BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE conversation_card
    ADD COLUMN IF NOT EXISTS vault_item_id UUID REFERENCES vault_item(vault_item_id) ON DELETE SET NULL;

-- ---------------------------------------------------------------------------
-- 4. Extend conversation_draft with privacy classification
-- ---------------------------------------------------------------------------
ALTER TABLE conversation_draft
    ADD COLUMN IF NOT EXISTS privacy_classification TEXT NOT NULL DEFAULT 'NORMAL';

ALTER TABLE conversation_draft
    DROP CONSTRAINT IF EXISTS conversation_draft_privacy_classification_check;
ALTER TABLE conversation_draft
    ADD CONSTRAINT conversation_draft_privacy_classification_check
    CHECK (privacy_classification IN ('NORMAL','SENSITIVE','HIGH_PRIVACY','PROTECTED_VAULT'));

-- ---------------------------------------------------------------------------
-- 5. Extend message_attachment_reference with protected-content columns
-- ---------------------------------------------------------------------------
ALTER TABLE message_attachment_reference
    ADD COLUMN IF NOT EXISTS privacy_classification TEXT NOT NULL DEFAULT 'NORMAL';

ALTER TABLE message_attachment_reference
    DROP CONSTRAINT IF EXISTS message_attachment_reference_privacy_classification_check;
ALTER TABLE message_attachment_reference
    ADD CONSTRAINT message_attachment_reference_privacy_classification_check
    CHECK (privacy_classification IN ('NORMAL','SENSITIVE','HIGH_PRIVACY','PROTECTED_VAULT'));

ALTER TABLE message_attachment_reference
    ADD COLUMN IF NOT EXISTS is_vault_protected BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE message_attachment_reference
    ADD COLUMN IF NOT EXISTS vault_item_id UUID REFERENCES vault_item(vault_item_id) ON DELETE SET NULL;

-- ---------------------------------------------------------------------------
-- 6. Extend relationship memory surfaces with privacy flags
-- ---------------------------------------------------------------------------
ALTER TABLE relationship_memory_item
    ADD COLUMN IF NOT EXISTS privacy_classification TEXT NOT NULL DEFAULT 'NORMAL';

ALTER TABLE relationship_memory_item
    DROP CONSTRAINT IF EXISTS relationship_memory_item_privacy_classification_check;
ALTER TABLE relationship_memory_item
    ADD CONSTRAINT relationship_memory_item_privacy_classification_check
    CHECK (privacy_classification IN ('NORMAL','SENSITIVE','HIGH_PRIVACY','PROTECTED_VAULT'));

ALTER TABLE relationship_memory_item
    ADD COLUMN IF NOT EXISTS is_vault_protected BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE relationship_memory_item
    ADD COLUMN IF NOT EXISTS vault_item_id UUID REFERENCES vault_item(vault_item_id) ON DELETE SET NULL;

ALTER TABLE relationship_commitment
    ADD COLUMN IF NOT EXISTS privacy_classification TEXT NOT NULL DEFAULT 'NORMAL';

ALTER TABLE relationship_commitment
    DROP CONSTRAINT IF EXISTS relationship_commitment_privacy_classification_check;
ALTER TABLE relationship_commitment
    ADD CONSTRAINT relationship_commitment_privacy_classification_check
    CHECK (privacy_classification IN ('NORMAL','SENSITIVE','HIGH_PRIVACY','PROTECTED_VAULT'));

ALTER TABLE relationship_commitment
    ADD COLUMN IF NOT EXISTS is_vault_protected BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE relationship_commitment
    ADD COLUMN IF NOT EXISTS vault_item_id UUID REFERENCES vault_item(vault_item_id) ON DELETE SET NULL;

ALTER TABLE relationship_open_loop
    ADD COLUMN IF NOT EXISTS privacy_classification TEXT NOT NULL DEFAULT 'NORMAL';

ALTER TABLE relationship_open_loop
    DROP CONSTRAINT IF EXISTS relationship_open_loop_privacy_classification_check;
ALTER TABLE relationship_open_loop
    ADD CONSTRAINT relationship_open_loop_privacy_classification_check
    CHECK (privacy_classification IN ('NORMAL','SENSITIVE','HIGH_PRIVACY','PROTECTED_VAULT'));

ALTER TABLE relationship_open_loop
    ADD COLUMN IF NOT EXISTS is_vault_protected BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE relationship_open_loop
    ADD COLUMN IF NOT EXISTS vault_item_id UUID REFERENCES vault_item(vault_item_id) ON DELETE SET NULL;

ALTER TABLE relationship_status
    ADD COLUMN IF NOT EXISTS privacy_classification TEXT NOT NULL DEFAULT 'NORMAL';

ALTER TABLE relationship_status
    DROP CONSTRAINT IF EXISTS relationship_status_privacy_classification_check;
ALTER TABLE relationship_status
    ADD CONSTRAINT relationship_status_privacy_classification_check
    CHECK (privacy_classification IN ('NORMAL','SENSITIVE','HIGH_PRIVACY','PROTECTED_VAULT'));

-- ---------------------------------------------------------------------------
-- 7. RLS owner isolation for vault and protected-content tables
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    ALTER TABLE vault_pin ENABLE ROW LEVEL SECURITY;
    ALTER TABLE vault_pin FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS vault_pin_owner_isolation ON vault_pin;
    CREATE POLICY vault_pin_owner_isolation ON vault_pin
        FOR ALL
        USING (owner_user_id = _rls_owner_uuid())
        WITH CHECK (owner_user_id = _rls_owner_uuid());

    ALTER TABLE vault_session ENABLE ROW LEVEL SECURITY;
    ALTER TABLE vault_session FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS vault_session_owner_isolation ON vault_session;
    CREATE POLICY vault_session_owner_isolation ON vault_session
        FOR ALL
        USING (owner_user_id = _rls_owner_uuid())
        WITH CHECK (owner_user_id = _rls_owner_uuid());

    ALTER TABLE vault_item ENABLE ROW LEVEL SECURITY;
    ALTER TABLE vault_item FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS vault_item_owner_isolation ON vault_item;
    CREATE POLICY vault_item_owner_isolation ON vault_item
        FOR ALL
        USING (owner_user_id = _rls_owner_uuid())
        WITH CHECK (owner_user_id = _rls_owner_uuid());

    ALTER TABLE vault_access_log ENABLE ROW LEVEL SECURITY;
    ALTER TABLE vault_access_log FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS vault_access_log_owner_isolation ON vault_access_log;
    CREATE POLICY vault_access_log_owner_isolation ON vault_access_log
        FOR ALL
        USING (owner_user_id = _rls_owner_uuid())
        WITH CHECK (owner_user_id = _rls_owner_uuid());
END $$;

-- ---------------------------------------------------------------------------
-- 8. Least-privilege grants
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'vemoria_app_user') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON vault_pin TO vemoria_app_user;
        GRANT SELECT, INSERT, UPDATE, DELETE ON vault_session TO vemoria_app_user;
        GRANT SELECT, INSERT, UPDATE, DELETE ON vault_item TO vemoria_app_user;
        GRANT SELECT, INSERT, UPDATE, DELETE ON vault_access_log TO vemoria_app_user;
    END IF;

    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p2_api') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON vault_pin TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON vault_session TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON vault_item TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON vault_access_log TO mb13_p2_api;
    END IF;
END $$;
