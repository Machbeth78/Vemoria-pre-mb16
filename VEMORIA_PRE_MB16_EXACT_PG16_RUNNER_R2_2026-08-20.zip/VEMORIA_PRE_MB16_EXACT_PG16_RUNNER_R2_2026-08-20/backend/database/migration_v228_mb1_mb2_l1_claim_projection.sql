-- Vemoria — MB1-MB2 atomic L1 claim, worker-token invalidation, consent-scoped projection
-- Adds per-item worker claim state without altering existing rows.

ALTER TABLE memory_scan_items
ADD COLUMN IF NOT EXISTS worker_id TEXT,
ADD COLUMN IF NOT EXISTS claim_token TEXT,
ADD COLUMN IF NOT EXISTS claimed_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS attempts INTEGER NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS error_code TEXT,
ADD COLUMN IF NOT EXISTS error_message TEXT,
ADD COLUMN IF NOT EXISTS session_consent_version TEXT;

-- Existing rows start clean: no worker can hold a stale claim.
UPDATE memory_scan_items
SET worker_id = NULL, claim_token = NULL, claimed_at = NULL,
    session_consent_version = NULL, attempts = 0
WHERE claim_token IS NOT NULL OR worker_id IS NOT NULL;

-- Owner-scoped partial index for the L1 work queue.
-- No JOIN or subquery; filters are explicit and sargable.
CREATE INDEX IF NOT EXISTS idx_memory_scan_items_l1_claim_queue
ON memory_scan_items(owner_user_id, session_id, importance_score DESC, last_seen_at DESC)
WHERE scan_level = 'L0'
  AND scan_state = 'deep_read_queued'
  AND needs_deep_scan = TRUE
  AND claim_token IS NULL;
