-- MB13-P3 v221 — real upgrade chain, revision-history classification and role isolation closure
-- Corrections from v220:
--   * Migration test uses the real migration runner, not manual SQL simulation.
--   * Classification iterates every historical revision, not only the current one.
--   * Legacy recovery and classification surfaces are removed after the migration.
--   * Pack mutations are gated by a dedicated lifecycle role, not a shared writer.
--   * A persistent append-only audit table records the recovery outcome.

-- ============================================================================
-- 1. Append-only recovery audit table
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.mb13_p3_recovery_audit (
    audit_id BIGSERIAL PRIMARY KEY,
    migration_name TEXT NOT NULL,
    run_id UUID NOT NULL DEFAULT gen_random_uuid(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    pack_id_hash TEXT NOT NULL,
    pack_revision INTEGER,
    revision INTEGER,
    classification TEXT NOT NULL CHECK (classification IN ('candidate','verified','ambiguous','skipped','quarantined','upgraded')),
    reason_code TEXT,
    before_hash TEXT,
    after_hash TEXT
);

ALTER TABLE public.mb13_p3_recovery_audit OWNER TO postgres;

CREATE OR REPLACE FUNCTION public.mb13_p3_recovery_audit_immutable()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $func$
BEGIN
    RAISE EXCEPTION 'mb13_p3_recovery_audit is append-only'
        USING ERRCODE = 'P3IMM';
    RETURN NULL;
END;
$func$;

ALTER FUNCTION public.mb13_p3_recovery_audit_immutable() OWNER TO postgres;

DROP TRIGGER IF EXISTS trg_mb13_p3_recovery_audit_immutable ON public.mb13_p3_recovery_audit;
CREATE TRIGGER trg_mb13_p3_recovery_audit_immutable
    BEFORE UPDATE OR DELETE ON public.mb13_p3_recovery_audit
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p3_recovery_audit_immutable();

-- ============================================================================
-- 2. Dedicated lifecycle owner role
-- ============================================================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p3_pack_lifecycle_owner') THEN
        CREATE ROLE mb13_p3_pack_lifecycle_owner NOLOGIN NOINHERIT NOBYPASSRLS;
    END IF;
END $$;

ALTER ROLE mb13_p3_pack_lifecycle_owner NOLOGIN NOINHERIT NOBYPASSRLS;
GRANT USAGE ON SCHEMA public TO mb13_p3_pack_lifecycle_owner;

-- ============================================================================
-- 3. Restore writer inheritance and remove the spurious mutator membership
-- ============================================================================
DO $$
BEGIN
    REVOKE mb13_p3_pack_mutator FROM mb13_p3_writer;
EXCEPTION WHEN undefined_object THEN
    NULL;
END $$;

ALTER ROLE mb13_p3_writer INHERIT;

-- ============================================================================
-- 4. Transfer pack/revision ownership to the dedicated lifecycle role
--    and lock down direct DML on those two tables.
-- ============================================================================
ALTER TABLE public.mb13_p3_action_pack OWNER TO mb13_p3_pack_lifecycle_owner;
ALTER TABLE public.mb13_p3_action_pack_revision OWNER TO mb13_p3_pack_lifecycle_owner;

-- The remaining mb13_p3_action_pack_* tables are owned by mb13_p3_writer.
-- The lifecycle role needs DML on them; the writer role needs ALL so that
-- its existing SECURITY DEFINER trigger functions (terminal sync, guards)
-- can acquire row locks and append timeline rows.
GRANT ALL PRIVILEGES ON TABLE public.mb13_p3_action_pack_authorization,
    public.mb13_p3_action_pack_attempt,
    public.mb13_p3_action_pack_evidence,
    public.mb13_p3_action_pack_result,
    public.mb13_p3_action_pack_timeline
TO mb13_p3_pack_lifecycle_owner, mb13_p3_writer;

DO $$
DECLARE
    r RECORD;
    v_pack_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_revision'
    ];
BEGIN
    FOR r IN
        SELECT relname
          FROM pg_class
         WHERE relnamespace = 'public'::regnamespace
           AND relkind = 'r'
           AND relname LIKE 'mb13_p3_action_pack%'
    LOOP
        IF r.relname = ANY(v_pack_tables) THEN
            EXECUTE format('REVOKE ALL ON public.%I FROM PUBLIC, mb13_p3_writer, mb13_p3_api, mb13_p3_executor, test_app, mb13_p3_pack_mutator', r.relname);
            EXECUTE format('GRANT SELECT ON public.%I TO mb13_p3_writer, mb13_p3_validator, mb13_p3_api, mb13_p3_executor', r.relname);
        ELSE
            EXECUTE format('REVOKE ALL ON public.%I FROM PUBLIC, mb13_p3_api, mb13_p3_executor, test_app, mb13_p3_pack_mutator', r.relname);
            EXECUTE format('GRANT SELECT ON public.%I TO mb13_p3_validator, mb13_p3_api, mb13_p3_executor', r.relname);
        END IF;
    END LOOP;
END $$;

-- ============================================================================
-- 5. Grant lifecycle role the privileges it needs on the rest of the schema
-- ============================================================================
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO mb13_p3_pack_lifecycle_owner;

-- ============================================================================
-- 6. Pack mutation gate: only the lifecycle role may mutate the pack table
-- ============================================================================
DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_governed_mutation ON public.mb13_p3_action_pack;
DROP FUNCTION IF EXISTS public.mb13_p3_action_pack_governed_mutation();

CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_governed_mutation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = pg_catalog, public
AS $func$
BEGIN
    IF current_user = 'mb13_p3_pack_lifecycle_owner' THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;
    RAISE EXCEPTION 'mb13_p3_action_pack_direct_mutation_denied'
        USING ERRCODE = '42501';
END;
$func$;

ALTER FUNCTION public.mb13_p3_action_pack_governed_mutation() OWNER TO mb13_p3_pack_lifecycle_owner;

CREATE TRIGGER trg_mb13_p3_action_pack_governed_mutation
    BEFORE INSERT OR UPDATE OR DELETE ON public.mb13_p3_action_pack
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p3_action_pack_governed_mutation();

REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_governed_mutation() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_governed_mutation() TO mb13_p3_pack_lifecycle_owner;

-- ============================================================================
-- 7. Reassign lifecycle functions to the dedicated role
-- ============================================================================
DO $$
DECLARE
    r RECORD;
    v_lifecycle_funcs TEXT[] := ARRAY[
        'mb13_p3_create_action_pack',
        'mb13_p3_revise_action_pack',
        'mb13_p3_authorize_action_pack',
        'mb13_p3_claim_action_pack',
        'mb13_p3_start_action_pack',
        'mb13_p3_record_execution_evidence',
        'mb13_p3_complete_action_pack',
        'mb13_p3_cancel_action_pack',
        'mb13_p3_revoke_action_pack',
        'mb13_p3_expire_action_pack'
    ];
BEGIN
    FOR r IN
        SELECT proname, pg_get_function_identity_arguments(oid) AS args
        FROM pg_proc
        WHERE proname = ANY(v_lifecycle_funcs)
          AND pronamespace = 'public'::regnamespace
    LOOP
        EXECUTE format('ALTER FUNCTION public.%I(%s) OWNER TO mb13_p3_pack_lifecycle_owner', r.proname, r.args);
    END LOOP;
END $$;

-- ============================================================================
-- 8. Allow the lifecycle role to execute all helpers it may call
-- ============================================================================
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO mb13_p3_pack_lifecycle_owner;

-- ============================================================================
-- 9. Grant execute on lifecycle functions to the calling roles
-- ============================================================================
DO $$
DECLARE
    r RECORD;
    v_api_funcs TEXT[] := ARRAY[
        'mb13_p3_create_action_pack',
        'mb13_p3_revise_action_pack',
        'mb13_p3_authorize_action_pack',
        'mb13_p3_cancel_action_pack',
        'mb13_p3_revoke_action_pack'
    ];
    v_executor_funcs TEXT[] := ARRAY[
        'mb13_p3_claim_action_pack',
        'mb13_p3_start_action_pack',
        'mb13_p3_record_execution_evidence',
        'mb13_p3_complete_action_pack',
        'mb13_p3_expire_action_pack'
    ];
    v_func TEXT;
    v_roles TEXT;
BEGIN
    FOR r IN
        SELECT proname, pg_get_function_identity_arguments(oid) AS args
        FROM pg_proc
        WHERE proname = ANY(v_api_funcs || v_executor_funcs)
          AND pronamespace = 'public'::regnamespace
    LOOP
        EXECUTE format('REVOKE ALL ON FUNCTION public.%I(%s) FROM PUBLIC, mb13_p3_writer, mb13_p3_api, mb13_p3_executor, test_app', r.proname, r.args);
        IF r.proname = ANY(v_api_funcs) THEN
            v_roles := 'mb13_p3_writer, mb13_p3_api';
        ELSE
            v_roles := 'mb13_p3_writer, mb13_p3_executor';
        END IF;
        EXECUTE format('GRANT EXECUTE ON FUNCTION public.%I(%s) TO %s', r.proname, r.args, v_roles);
    END LOOP;
END $$;

-- ============================================================================
-- 10. Real revision-history classification inside the migration body
-- ============================================================================
DO $$
DECLARE
    v_run_id UUID := gen_random_uuid();
    v_pack RECORD;
    v_rev RECORD;
    v_expected TEXT;
    v_pack_hash_expected TEXT;
    v_quarantine BOOLEAN;
    v_reason TEXT;
    v_classification TEXT;
    v_pack_hash TEXT;
BEGIN
    -- Disable user triggers so the migration can update quarantine flags
    -- without being blocked by the append-only and role-based gates.
    ALTER TABLE public.mb13_p3_action_pack DISABLE TRIGGER USER;
    ALTER TABLE public.mb13_p3_action_pack_revision DISABLE TRIGGER USER;

    FOR v_pack IN
        SELECT * FROM public.mb13_p3_action_pack
         WHERE legacy_idempotency_unverified = TRUE
            OR legacy_idempotency_quarantined = TRUE
            OR idempotency_key IS NULL
    LOOP
        v_quarantine := FALSE;
        v_reason := NULL;

        -- Current revision must project canonically onto the pack row.
        SELECT * INTO v_rev
          FROM public.mb13_p3_action_pack_revision
         WHERE pack_id = v_pack.pack_id
           AND revision = v_pack.pack_revision;

        IF NOT FOUND THEN
            v_quarantine := TRUE;
            v_reason := 'legacy_recovery_current_revision_missing';
        ELSE
            IF v_pack.owner_user_id IS DISTINCT FROM v_rev.owner_user_id
               OR v_pack.pack_id IS DISTINCT FROM v_rev.pack_id
               OR v_pack.pack_revision IS DISTINCT FROM v_rev.revision
               OR v_pack.monitor_revision IS DISTINCT FROM v_rev.monitor_revision
               OR v_pack.trigger_event_id IS DISTINCT FROM v_rev.trigger_event_id
               OR v_pack.diff_result_id IS DISTINCT FROM v_rev.diff_result_id
               OR v_pack.action_type IS DISTINCT FROM v_rev.action_type
               OR v_pack.target_ref IS DISTINCT FROM v_rev.target_ref
               OR v_pack.consent_refs IS DISTINCT FROM v_rev.consent_refs
               OR v_pack.provenance_refs IS DISTINCT FROM v_rev.provenance_refs
               OR v_pack.steps IS DISTINCT FROM v_rev.steps
               OR v_pack.expires_at IS DISTINCT FROM v_rev.expires_at
            THEN
                v_quarantine := TRUE;
                v_reason := 'legacy_recovery_canonical_mismatch';
            END IF;

            IF v_pack.idempotency_key IS DISTINCT FROM v_rev.idempotency_key
               OR v_pack.payload_hash IS DISTINCT FROM v_rev.payload_hash THEN
                v_quarantine := TRUE;
                v_reason := 'legacy_recovery_current_revision_key_hash_mismatch';
            END IF;

            BEGIN
                v_pack_hash_expected := public.mb13_p3_action_pack_payload_hash(
                    v_pack.owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
                    v_pack.trigger_event_id, v_pack.diff_result_id, v_pack.action_type,
                    v_pack.target_ref, v_pack.consent_refs, v_pack.provenance_refs, v_pack.steps,
                    v_pack.expires_at, v_pack.idempotency_key, v_pack.status
                );
            EXCEPTION WHEN OTHERS THEN
                v_pack_hash_expected := NULL;
            END;

            IF v_pack_hash_expected IS DISTINCT FROM v_pack.payload_hash THEN
                v_quarantine := TRUE;
                v_reason := 'legacy_recovery_pack_hash_mismatch';
            END IF;
        END IF;

        -- Verify every historical revision using the key that was actually stored.
        FOR v_rev IN
            SELECT * FROM public.mb13_p3_action_pack_revision
             WHERE pack_id = v_pack.pack_id
             ORDER BY revision ASC
        LOOP
            BEGIN
                v_expected := public.mb13_p3_action_pack_payload_hash(
                    v_rev.owner_user_id, v_pack.monitor_id, v_rev.monitor_revision,
                    v_rev.trigger_event_id, v_rev.diff_result_id, v_rev.action_type,
                    v_rev.target_ref, v_rev.consent_refs, v_rev.provenance_refs, v_rev.steps,
                    v_rev.expires_at, v_rev.idempotency_key, v_rev.status
                );
            EXCEPTION WHEN OTHERS THEN
                v_expected := NULL;
            END;

            v_pack_hash := encode(digest(v_pack.pack_id::text, 'sha256'), 'hex');

            IF v_rev.idempotency_key LIKE 'legacy-%' THEN
                v_quarantine := TRUE;
                v_reason := 'legacy_recovery_key_prefix_ambiguous';
                v_classification := 'ambiguous';

                UPDATE public.mb13_p3_action_pack_revision
                   SET legacy_idempotency_quarantined = TRUE,
                       legacy_idempotency_quarantine_reason = 'legacy_recovery_key_prefix_ambiguous'
                 WHERE pack_id = v_rev.pack_id
                   AND revision = v_rev.revision;
            ELSIF v_expected IS DISTINCT FROM v_rev.payload_hash THEN
                v_quarantine := TRUE;
                v_reason := 'legacy_recovery_hash_mismatch';
                v_classification := 'ambiguous';

                UPDATE public.mb13_p3_action_pack_revision
                   SET legacy_idempotency_quarantined = TRUE,
                       legacy_idempotency_quarantine_reason = 'legacy_recovery_hash_mismatch'
                 WHERE pack_id = v_rev.pack_id
                   AND revision = v_rev.revision;
            ELSE
                v_classification := 'verified';

                UPDATE public.mb13_p3_action_pack_revision
                   SET legacy_idempotency_quarantined = FALSE,
                       legacy_idempotency_quarantine_reason = NULL
                 WHERE pack_id = v_rev.pack_id
                   AND revision = v_rev.revision;
            END IF;

            INSERT INTO public.mb13_p3_recovery_audit (
                migration_name, run_id, pack_id_hash, pack_revision, revision,
                classification, reason_code, before_hash, after_hash
            ) VALUES (
                'migration_v221_mb13_p3_real_upgrade_chain_revision_history_role_isolation_closure.sql',
                v_run_id, v_pack_hash, v_pack.pack_revision, v_rev.revision,
                v_classification,
                CASE
                    WHEN v_classification = 'ambiguous' AND v_rev.idempotency_key LIKE 'legacy-%' THEN 'legacy_recovery_key_prefix_ambiguous'
                    WHEN v_classification = 'ambiguous' THEN 'legacy_recovery_hash_mismatch'
                    ELSE 'legacy_recovery_hash_verified'
                END,
                v_rev.payload_hash, v_expected
            );
        END LOOP;

        -- Reflect the pack-level outcome.
        IF v_quarantine THEN
            UPDATE public.mb13_p3_action_pack
               SET legacy_idempotency_quarantined = TRUE,
                   legacy_idempotency_quarantine_reason = v_reason
             WHERE pack_id = v_pack.pack_id;

            INSERT INTO public.mb13_p3_recovery_audit (
                migration_name, run_id, pack_id_hash, pack_revision, revision,
                classification, reason_code, before_hash, after_hash
            ) VALUES (
                'migration_v221_mb13_p3_real_upgrade_chain_revision_history_role_isolation_closure.sql',
                v_run_id, v_pack_hash, v_pack.pack_revision, NULL,
                'quarantined', v_reason, v_pack.payload_hash, NULL
            );
        ELSE
            UPDATE public.mb13_p3_action_pack
               SET legacy_idempotency_quarantined = FALSE,
                   legacy_idempotency_quarantine_reason = NULL
             WHERE pack_id = v_pack.pack_id;

            INSERT INTO public.mb13_p3_recovery_audit (
                migration_name, run_id, pack_id_hash, pack_revision, revision,
                classification, reason_code, before_hash, after_hash
            ) VALUES (
                'migration_v221_mb13_p3_real_upgrade_chain_revision_history_role_isolation_closure.sql',
                v_run_id, v_pack_hash, v_pack.pack_revision, NULL,
                'candidate', 'legacy_recovery_chain_verified', v_pack.payload_hash, NULL
            );
        END IF;
    END LOOP;

    -- Record all non-legacy packs as skipped.
    FOR v_pack IN
        SELECT * FROM public.mb13_p3_action_pack
         WHERE NOT (legacy_idempotency_unverified = TRUE
                    OR legacy_idempotency_quarantined = TRUE
                    OR idempotency_key IS NULL)
    LOOP
        INSERT INTO public.mb13_p3_recovery_audit (
            migration_name, run_id, pack_id_hash, pack_revision, revision,
            classification, reason_code, before_hash, after_hash
        ) VALUES (
            'migration_v221_mb13_p3_real_upgrade_chain_revision_history_role_isolation_closure.sql',
            v_run_id, encode(digest(v_pack.pack_id::text, 'sha256'), 'hex'),
            v_pack.pack_revision, NULL, 'skipped', 'legacy_recovery_skipped', v_pack.payload_hash, NULL
        );
    END LOOP;

    ALTER TABLE public.mb13_p3_action_pack ENABLE TRIGGER USER;
    ALTER TABLE public.mb13_p3_action_pack_revision ENABLE TRIGGER USER;
END $$;

-- ============================================================================
-- 11. Remove one-shot recovery surfaces after the migration
-- ============================================================================
DROP FUNCTION IF EXISTS public.mb13_p3_real_legacy_classify();
DROP FUNCTION IF EXISTS public.mb13_p3_legacy_idempotency_recover();
