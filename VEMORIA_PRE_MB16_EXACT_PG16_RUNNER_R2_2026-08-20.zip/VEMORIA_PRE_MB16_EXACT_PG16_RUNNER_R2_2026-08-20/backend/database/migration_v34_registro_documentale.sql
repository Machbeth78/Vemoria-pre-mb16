-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V34 — Registro Documentale Intelligente
-- Estende tipi_documento con campi regole.
-- Crea document_type_candidates per documenti non riconosciuti.
-- Idempotente (ADD COLUMN IF NOT EXISTS, CREATE TABLE IF NOT EXISTS).

-- ── 1. Estende tipi_documento con campi regole ───────────────────────────────
-- I campi esistenti (codice, etichetta, categoria, parole_chiave, has_scadenza)
-- vengono mantenuti intatti.

ALTER TABLE tipi_documento
    ADD COLUMN IF NOT EXISTS campi_attesi         JSONB,
    -- { "nome_campo": "descrizione", ... }
    -- Es: {"targa": "targa veicolo", "data_scadenza": "data entro cui pagare"}

    ADD COLUMN IF NOT EXISTS campi_forti          TEXT[],
    -- campi identitari del tipo: se trovati → classificazione rafforzata
    -- Es: ARRAY['targa', 'numero_verbale']

    ADD COLUMN IF NOT EXISTS pattern_date         JSONB,
    -- { "data_scadenza": ["entro il", "pagare entro", "scadenza"], ... }
    -- label di testo che precedono le date rilevanti per questo tipo

    ADD COLUMN IF NOT EXISTS pattern_importo      JSONB,
    -- { "importo_principale": ["importo", "sanzione", "totale da pagare"] }

    ADD COLUMN IF NOT EXISTS pattern_identificativi JSONB,
    -- { "numero_verbale": "\\b[A-Z]{2}[0-9]{6,9}\\b", "targa": "..." }

    ADD COLUMN IF NOT EXISTS regole_eventi        JSONB,
    -- [{"tipo_evento": "PAGAMENTO", "campo_data": "data_scadenza",
    --   "campo_importo": "importo_principale", "condizione": "importo > 0"}]

    ADD COLUMN IF NOT EXISTS priorita_ricerca     SMALLINT DEFAULT 50,
    -- 1-100: più alto = più probabile come tipo corretto
    -- usato per disambiguare quando più tipi matchano

    ADD COLUMN IF NOT EXISTS fonte               TEXT DEFAULT 'seed',
    -- 'seed' | 'promozione' | 'manuale'

    ADD COLUMN IF NOT EXISTS updated_at          TIMESTAMP DEFAULT NOW();

CREATE INDEX IF NOT EXISTS idx_tipodoc_priorita
    ON tipi_documento (priorita_ricerca DESC)
    WHERE attivo = TRUE;

-- ── 2. Tabella candidati — documenti non riconosciuti ────────────────────────
CREATE TABLE IF NOT EXISTS document_type_candidates (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    -- Fingerprint del documento (primi 300 chars di testo normalizzato)
    fingerprint         TEXT,

    -- Parole chiave rilevate nel testo (array, da classificatore)
    parole_chiave       TEXT[],

    -- Struttura rilevata (JSON libero: campi trovati, pattern, ecc.)
    struttura_rilevata  JSONB,

    -- Campi forti trovati nel documento
    campi_trovati       JSONB,
    -- Es: {"importo": 145.50, "targa": "AB123CD", "data_scadenza": "2026-04-15"}

    -- Pattern trovati
    pattern_date        TEXT[],
    pattern_importo     TEXT[],

    -- Conteggio occorrenze documenti simili
    conteggio_occorrenze INTEGER NOT NULL DEFAULT 1,
    prima_occorrenza     TIMESTAMP NOT NULL DEFAULT NOW(),
    ultima_occorrenza    TIMESTAMP NOT NULL DEFAULT NOW(),

    -- Tipo suggerito dal classificatore (può essere "generico")
    tipo_suggerito      TEXT,
    confidenza_suggerita FLOAT,

    -- Stato del ciclo di vita
    stato               TEXT NOT NULL DEFAULT 'nuovo',
    -- 'nuovo' | 'osservato' | 'confermato' | 'promosso' | 'scartato'

    -- Se promosso: link al tipo ufficiale creato
    tipo_promosso_id    UUID REFERENCES tipi_documento(id) ON DELETE SET NULL,

    -- Note utente / admin
    note                TEXT,

    creato_il           TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_candidates_stato
    ON document_type_candidates (stato);
CREATE INDEX IF NOT EXISTS idx_candidates_tipo_suggerito
    ON document_type_candidates (tipo_suggerito)
    WHERE tipo_suggerito IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_candidates_conteggio
    ON document_type_candidates (conteggio_occorrenze DESC);
CREATE INDEX IF NOT EXISTS idx_candidates_fingerprint
    ON document_type_candidates (fingerprint)
    WHERE fingerprint IS NOT NULL;
