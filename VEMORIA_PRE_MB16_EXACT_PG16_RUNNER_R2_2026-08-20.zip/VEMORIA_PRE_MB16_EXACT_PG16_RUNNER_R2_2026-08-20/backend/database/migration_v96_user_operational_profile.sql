-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- ============================================================================
-- VEMORA V76 — Intelligenza Adattiva
-- migration_v96_user_operational_profile.sql
-- ----------------------------------------------------------------------------
-- Crea due tabelle nuove per il delfino adattivo:
--   - user_operational_profile  : snapshot JSON del profilo per utente
--   - user_corrections          : log correzioni esplicite del proprietario
--
-- Entrambe sono PRIVATE all'utente (FK su utenti.id, scope per-utente).
-- Idempotente. Sicura da rieseguire.
-- V79.2E: usa uuid_generate_v4() per coerenza con init_full.sql/uuid-ossp,
-- evitando una dipendenza implicita da pgcrypto/gen_random_uuid().
-- ============================================================================

CREATE TABLE IF NOT EXISTS user_operational_profile (
    utente_id      UUID         PRIMARY KEY
                                REFERENCES utenti(id) ON DELETE CASCADE,
    profile_json   JSONB        NOT NULL DEFAULT '{}'::jsonb,
    updated_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_user_operational_profile_updated
    ON user_operational_profile(updated_at DESC);

COMMENT ON TABLE  user_operational_profile IS
    'V76 — snapshot JSON del profilo operativo per-utente (mai esposto a controparti).';
COMMENT ON COLUMN user_operational_profile.profile_json IS
    'Vedi services/user_operational_profile_service.py per lo schema atteso.';


CREATE TABLE IF NOT EXISTS user_corrections (
    id             UUID         PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id      UUID         NOT NULL
                                REFERENCES utenti(id) ON DELETE CASCADE,
    kind           TEXT         NOT NULL,
    scope          TEXT         NOT NULL DEFAULT 'global',
    target_key     TEXT,
    target_label   TEXT,
    old_value      JSONB,
    new_value      JSONB,
    confidence     NUMERIC(4,3) NOT NULL DEFAULT 1.000,
    source         TEXT         NOT NULL DEFAULT 'user_correction',
    created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_user_corrections_utente_created
    ON user_corrections(utente_id, created_at DESC);

CREATE INDEX IF NOT EXISTS ix_user_corrections_utente_scope
    ON user_corrections(utente_id, scope);

CREATE INDEX IF NOT EXISTS ix_user_corrections_target_key
    ON user_corrections(utente_id, target_key)
    WHERE target_key IS NOT NULL;

COMMENT ON TABLE  user_corrections IS
    'V76 — log delle correzioni esplicite del proprietario (source=user_correction).';
COMMENT ON COLUMN user_corrections.kind IS
    'Vedi services/correction_memory_service.py: rename_entity, mark_private, ecc.';
COMMENT ON COLUMN user_corrections.scope IS
    'global | contact | doc_type | dossier | pratica | send | sign | proof';
