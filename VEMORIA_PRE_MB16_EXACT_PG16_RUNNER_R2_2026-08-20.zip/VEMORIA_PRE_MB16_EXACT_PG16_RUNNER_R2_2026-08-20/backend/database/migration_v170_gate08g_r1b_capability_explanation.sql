-- Vemoria Gate08G-R1B - Self-Knowledge Capability Explanation Layer
-- Static schema contract only. It extends the existing Self-Knowledge Atlas use,
-- without creating a second source of truth and without claiming runtime PASS.

CREATE TABLE IF NOT EXISTS gate08g_r1b_capability_explanation_snapshots (
    id TEXT PRIMARY KEY,
    capability_version TEXT NOT NULL,
    source_atlas_version TEXT NOT NULL,
    uses_existing_self_knowledge_atlas BOOLEAN NOT NULL DEFAULT TRUE CHECK (uses_existing_self_knowledge_atlas = TRUE),
    creates_second_capability_map BOOLEAN NOT NULL DEFAULT FALSE CHECK (creates_second_capability_map = FALSE),
    runtime_pass_claim_allowed BOOLEAN NOT NULL DEFAULT FALSE CHECK (runtime_pass_claim_allowed = FALSE),
    capability_explanation_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    contains_secret BOOLEAN NOT NULL DEFAULT FALSE CHECK (contains_secret = FALSE),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_gate08g_r1b_capability_version
    ON gate08g_r1b_capability_explanation_snapshots(capability_version);

CREATE TABLE IF NOT EXISTS gate08g_r1b_contextual_capability_answer_contracts (
    contract_id TEXT PRIMARY KEY,
    capability_version TEXT NOT NULL,
    must_include_possible_actions BOOLEAN NOT NULL DEFAULT TRUE CHECK (must_include_possible_actions = TRUE),
    must_include_real_status BOOLEAN NOT NULL DEFAULT TRUE CHECK (must_include_real_status = TRUE),
    must_include_limits BOOLEAN NOT NULL DEFAULT TRUE CHECK (must_include_limits = TRUE),
    must_include_permissions BOOLEAN NOT NULL DEFAULT TRUE CHECK (must_include_permissions = TRUE),
    must_include_fallback_without_llm BOOLEAN NOT NULL DEFAULT TRUE CHECK (must_include_fallback_without_llm = TRUE),
    must_not_claim_runtime_pass BOOLEAN NOT NULL DEFAULT TRUE CHECK (must_not_claim_runtime_pass = TRUE),
    action_contracts_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    contains_secret BOOLEAN NOT NULL DEFAULT FALSE CHECK (contains_secret = FALSE),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
