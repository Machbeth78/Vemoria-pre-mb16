-- Vemoria PRE-MB16 Pass 8O — verified external RFC3161 timestamp evidence.
BEGIN;

ALTER TABLE eventi_invio
    ADD COLUMN IF NOT EXISTS timestamp_imprint_sha256 TEXT NULL,
    ADD COLUMN IF NOT EXISTS timestamp_token_sha256 TEXT NULL,
    ADD COLUMN IF NOT EXISTS timestamp_provider TEXT NULL,
    ADD COLUMN IF NOT EXISTS timestamp_gen_time TIMESTAMPTZ NULL,
    ADD COLUMN IF NOT EXISTS timestamp_verified_at TIMESTAMPTZ NULL,
    ADD COLUMN IF NOT EXISTS timestamp_evidence JSONB NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE eventi_invio
    DROP CONSTRAINT IF EXISTS eventi_invio_timestamp_imprint_sha256_format;
ALTER TABLE eventi_invio
    ADD CONSTRAINT eventi_invio_timestamp_imprint_sha256_format
    CHECK (timestamp_imprint_sha256 IS NULL OR timestamp_imprint_sha256 ~ '^[0-9a-f]{64}$');

ALTER TABLE eventi_invio
    DROP CONSTRAINT IF EXISTS eventi_invio_timestamp_token_sha256_format;
ALTER TABLE eventi_invio
    ADD CONSTRAINT eventi_invio_timestamp_token_sha256_format
    CHECK (timestamp_token_sha256 IS NULL OR timestamp_token_sha256 ~ '^[0-9a-f]{64}$');

COMMENT ON COLUMN eventi_invio.timestamp_imprint_sha256 IS
    'SHA-256 canonical event imprint submitted to the external RFC3161 TSA.';
COMMENT ON COLUMN eventi_invio.timestamp_token IS
    'Base64 DER RFC3161 TimeStampResp only after cryptographic verification against the configured server trust bundle.';
COMMENT ON COLUMN eventi_invio.timestamp_evidence IS
    'Bounded provider/serial/policy/trust metadata. qualified_eidas remains false until qualified-service status is independently verified.';

COMMIT;
