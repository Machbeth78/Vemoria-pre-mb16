-- Vemoria V79.2K — Tamper-evident evidence hash chain
CREATE TABLE IF NOT EXISTS evidence_hash_chain_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    chain_scope TEXT NOT NULL,
    event_type TEXT NOT NULL,
    subject_ref TEXT NULL,
    payload_hash TEXT NOT NULL,
    previous_event_hash TEXT NULL,
    event_hash TEXT NOT NULL,
    evidence_version TEXT NOT NULL DEFAULT 'V79.2K',
    metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_evidence_hash_chain_scope_created ON evidence_hash_chain_events(chain_scope, created_at ASC);
CREATE UNIQUE INDEX IF NOT EXISTS ux_evidence_hash_chain_event_hash ON evidence_hash_chain_events(event_hash);
