-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- database/migration_v68_schema_migration_state_timestamptz.sql
-- Allinea schema_migration_state.applied_il a TIMESTAMP WITH TIME ZONE
-- per coerenza con il foundation UTC-aware del core.

ALTER TABLE schema_migration_state
    ALTER COLUMN applied_il TYPE TIMESTAMP WITH TIME ZONE
    USING applied_il AT TIME ZONE 'UTC';
