-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB12-P1 R1 — governed offer/contract normalization and factual comparison.
-- Candidate-only data: no ranking, no recommendation, no automatic decision.

BEGIN;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb12_p1_app') THEN
        CREATE ROLE mb12_p1_app NOLOGIN;
    END IF;
END
$$;

CREATE TABLE IF NOT EXISTS public.mb12_p1_offer_contract (
    owner_user_id       UUID NOT NULL,
    dossier_id          UUID NOT NULL,
    stable_id           TEXT NOT NULL,
    document_kind       TEXT NOT NULL,
    title               TEXT NOT NULL,
    current_revision    INTEGER NOT NULL DEFAULT 1,
    state               TEXT NOT NULL,
    payload_hash        TEXT NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, dossier_id),
    UNIQUE (owner_user_id, stable_id),
    CONSTRAINT ck_mb12_p1_document_kind CHECK (
        document_kind IN ('offer','contract','tariff','insurance_policy','service_terms','quote')
    ),
    CONSTRAINT ck_mb12_p1_state CHECK (
        state IN ('normalized','incomplete','conflicting','revoked')
    ),
    CONSTRAINT ck_mb12_p1_revision_positive CHECK (current_revision >= 1),
    CONSTRAINT ck_mb12_p1_stable_id_nonempty CHECK (length(trim(stable_id)) > 0),
    CONSTRAINT ck_mb12_p1_title_nonempty CHECK (length(trim(title)) > 0)
);

CREATE TABLE IF NOT EXISTS public.mb12_p1_offer_contract_revision (
    owner_user_id       UUID NOT NULL,
    dossier_id          UUID NOT NULL,
    revision            INTEGER NOT NULL,
    state               TEXT NOT NULL,
    payload_hash        TEXT NOT NULL,
    normalized_payload  JSONB NOT NULL,
    source_refs         JSONB NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, dossier_id, revision),
    CONSTRAINT fk_mb12_p1_revision_dossier
        FOREIGN KEY (owner_user_id, dossier_id)
        REFERENCES public.mb12_p1_offer_contract(owner_user_id, dossier_id)
        ON DELETE RESTRICT,
    CONSTRAINT ck_mb12_p1_revision_state CHECK (
        state IN ('normalized','incomplete','conflicting','revoked')
    ),
    CONSTRAINT ck_mb12_p1_revision_positive_2 CHECK (revision >= 1),
    CONSTRAINT ck_mb12_p1_payload_object CHECK (jsonb_typeof(normalized_payload) = 'object'),
    CONSTRAINT ck_mb12_p1_source_refs_array CHECK (jsonb_typeof(source_refs) = 'array')
);

CREATE TABLE IF NOT EXISTS public.mb12_p1_normalized_term (
    owner_user_id       UUID NOT NULL,
    candidate_id        UUID NOT NULL,
    dossier_id          UUID NOT NULL,
    revision            INTEGER NOT NULL,
    canonical_key       TEXT NOT NULL,
    clause_type         TEXT NOT NULL,
    normalized_value    JSONB NULL,
    alternatives        JSONB NOT NULL DEFAULT '[]'::jsonb,
    currency            TEXT NOT NULL DEFAULT '',
    unit                TEXT NOT NULL DEFAULT '',
    period              TEXT NOT NULL DEFAULT '',
    confidence          NUMERIC(5,4) NOT NULL DEFAULT 1.0,
    conflicted          BOOLEAN NOT NULL DEFAULT FALSE,
    raw_values          JSONB NOT NULL DEFAULT '[]'::jsonb,
    source_refs         JSONB NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, candidate_id),
    UNIQUE (owner_user_id, dossier_id, revision, canonical_key),
    CONSTRAINT fk_mb12_p1_term_revision
        FOREIGN KEY (owner_user_id, dossier_id, revision)
        REFERENCES public.mb12_p1_offer_contract_revision(owner_user_id, dossier_id, revision)
        ON DELETE RESTRICT,
    CONSTRAINT ck_mb12_p1_clause_type CHECK (
        clause_type IN (
            'identity','price','duration','renewal','cancellation','penalty',
            'exclusion','obligation','eligibility','required_document','territory',
            'validity','included_benefit','other'
        )
    ),
    CONSTRAINT ck_mb12_p1_confidence CHECK (confidence >= 0 AND confidence <= 1),
    CONSTRAINT ck_mb12_p1_alternatives_array CHECK (jsonb_typeof(alternatives) = 'array'),
    CONSTRAINT ck_mb12_p1_raw_values_array CHECK (jsonb_typeof(raw_values) = 'array'),
    CONSTRAINT ck_mb12_p1_term_source_refs_array CHECK (jsonb_typeof(source_refs) = 'array')
);

CREATE INDEX IF NOT EXISTS ix_mb12_p1_offer_contract_owner_state
    ON public.mb12_p1_offer_contract(owner_user_id, state, updated_at DESC);
CREATE INDEX IF NOT EXISTS ix_mb12_p1_revision_owner_dossier
    ON public.mb12_p1_offer_contract_revision(owner_user_id, dossier_id, revision DESC);
CREATE INDEX IF NOT EXISTS ix_mb12_p1_term_owner_key
    ON public.mb12_p1_normalized_term(owner_user_id, canonical_key);

ALTER TABLE public.mb12_p1_offer_contract ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p1_offer_contract FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p1_offer_contract_revision ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p1_offer_contract_revision FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p1_normalized_term ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p1_normalized_term FORCE ROW LEVEL SECURITY;

DO $$
DECLARE
    table_name TEXT;
BEGIN
    FOREACH table_name IN ARRAY ARRAY[
        'mb12_p1_offer_contract',
        'mb12_p1_offer_contract_revision',
        'mb12_p1_normalized_term'
    ] LOOP
        EXECUTE format('DROP POLICY IF EXISTS mb12_p1_owner_isolation ON public.%I', table_name);
        EXECUTE format(
            'CREATE POLICY mb12_p1_owner_isolation ON public.%I '
            'USING (owner_user_id = NULLIF(current_setting(''app.owner_id'', true), '''')::uuid) '
            'WITH CHECK (owner_user_id = NULLIF(current_setting(''app.owner_id'', true), '''')::uuid)',
            table_name
        );
    END LOOP;
END
$$;

CREATE OR REPLACE FUNCTION public.mb12_p1_revision_immutable()
RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb12_p1_revision_history_is_append_only';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb12_p1_revision_immutable() FROM PUBLIC;

DROP TRIGGER IF EXISTS trg_mb12_p1_revision_immutable
    ON public.mb12_p1_offer_contract_revision;
CREATE TRIGGER trg_mb12_p1_revision_immutable
BEFORE UPDATE OR DELETE ON public.mb12_p1_offer_contract_revision
FOR EACH ROW EXECUTE FUNCTION public.mb12_p1_revision_immutable();

DROP TRIGGER IF EXISTS trg_mb12_p1_term_immutable
    ON public.mb12_p1_normalized_term;
CREATE TRIGGER trg_mb12_p1_term_immutable
BEFORE UPDATE OR DELETE ON public.mb12_p1_normalized_term
FOR EACH ROW EXECUTE FUNCTION public.mb12_p1_revision_immutable();

CREATE OR REPLACE FUNCTION public.mb12_p1_write_normalization(
    p_dossier_id UUID,
    p_stable_id TEXT,
    p_document_kind TEXT,
    p_title TEXT,
    p_state TEXT,
    p_normalized_payload JSONB,
    p_source_refs JSONB,
    p_terms JSONB
) RETURNS TABLE(dossier_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_dossier public.mb12_p1_offer_contract%ROWTYPE;
    v_revision INTEGER;
    v_payload_hash TEXT;
    v_ref JSONB;
    v_term JSONB;
    v_terms_without_ids JSONB;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_authenticated_owner_missing';
    END IF;
    IF p_document_kind NOT IN ('offer','contract','tariff','insurance_policy','service_terms','quote') THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_document_kind_invalid';
    END IF;
    IF p_state NOT IN ('normalized','incomplete','conflicting','revoked') THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_state_invalid';
    END IF;
    IF length(trim(COALESCE(p_stable_id, ''))) = 0 OR length(p_stable_id) > 200 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_stable_id_invalid';
    END IF;
    IF length(trim(COALESCE(p_title, ''))) = 0 OR length(p_title) > 300 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_title_invalid';
    END IF;
    IF p_dossier_id IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_dossier_id_missing';
    END IF;
    IF p_normalized_payload IS NULL OR jsonb_typeof(p_normalized_payload) <> 'object' THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_payload_not_object';
    END IF;
    IF p_source_refs IS NULL OR jsonb_typeof(p_source_refs) <> 'array' OR jsonb_array_length(p_source_refs) = 0 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_source_refs_invalid';
    END IF;
    IF p_terms IS NULL OR jsonb_typeof(p_terms) <> 'array' THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_terms_invalid';
    END IF;
    IF COALESCE((p_normalized_payload->>'no_auto_decision')::boolean, FALSE) IS NOT TRUE
       OR COALESCE((p_normalized_payload->>'sponsored_ranking')::boolean, TRUE) IS NOT FALSE THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_neutrality_invariant_missing';
    END IF;

    IF p_normalized_payload->>'normalizer_version' IS DISTINCT FROM 'mb12-p1-r1' THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_normalizer_version_invalid';
    END IF;
    IF p_normalized_payload ?| ARRAY['ranking','recommendation','score','sponsor','sponsored'] THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_forbidden_decision_field';
    END IF;

    SELECT COALESCE(jsonb_agg(value - 'candidate_id' ORDER BY value->>'canonical_key'), '[]'::jsonb)
      INTO v_terms_without_ids
      FROM jsonb_array_elements(p_terms);
    IF COALESCE(p_normalized_payload->'terms', '[]'::jsonb) IS DISTINCT FROM v_terms_without_ids THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p1_payload_terms_mismatch';
    END IF;

    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_stable_id, 0));

    FOR v_ref IN SELECT value FROM jsonb_array_elements(p_source_refs) LOOP
        IF NOT EXISTS (
            SELECT 1
              FROM public.mb12_p0_source_card_binding b
              JOIN public.mb12_p0_trusted_data_value t
                ON t.owner_user_id = b.owner_user_id
               AND t.source_id = b.source_id
               AND t.source_revision_id = b.source_revision_id
               AND t.evidence_id = b.evidence_id
               AND t.content_hash = b.content_hash
               AND t.grant_id IS NOT DISTINCT FROM b.grant_id
              JOIN public.canonical_source_card_authority a
                ON a.owner_user_id = b.owner_user_id
               AND a.source_card_id = b.source_card_id
              JOIN public.authorized_memory_sources s
                ON s.id = b.source_id
               AND s.user_id = b.owner_user_id
              JOIN public.authorized_memory_inventory_items i
                ON i.id = b.source_revision_id
               AND i.user_id = b.owner_user_id
               AND i.source_id = b.source_id
              JOIN public.authorized_memory_activity_log l
                ON l.id = b.evidence_id
               AND l.user_id = b.owner_user_id
               AND l.source_id = b.source_id
              LEFT JOIN public.authorized_memory_consent_grants g
                ON g.id = b.grant_id
               AND g.user_id = b.owner_user_id
               AND g.source_id = b.source_id
             WHERE b.owner_user_id = v_owner
               AND b.source_card_id = v_ref->>'source_card_id'
               AND b.source_id = NULLIF(v_ref->>'source_id', '')::uuid
               AND b.source_revision_id = NULLIF(v_ref->>'source_revision_id', '')::uuid
               AND b.evidence_id = NULLIF(v_ref->>'evidence_id', '')::uuid
               AND b.content_hash = v_ref->>'content_hash'
               AND b.grant_id IS NOT DISTINCT FROM NULLIF(v_ref->>'grant_id', '')::uuid
               AND b.scope = v_ref->>'scope'
               AND b.status = 'active'
               AND b.revoked_at IS NULL
               AND a.status = 'active'
               AND a.source_state = 'active'
               AND COALESCE(a.revocation_state, '') <> 'revoked'
               AND s.status = 'active'
               AND s.revoked_at IS NULL
               AND i.deleted_at IS NULL
               AND i.memory_state <> 'revoked'
               AND l.id = t.evidence_id
               AND (
                    b.grant_id IS NULL
                    OR (
                        g.status = 'active'
                        AND g.revoked_at IS NULL
                        AND (g.expires_at IS NULL OR g.expires_at > NOW())
                    )
               )
               AND t.field_name = v_ref->>'field_name'
               AND t.normalized_value = v_ref->>'trusted_value'
        ) THEN
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p1_source_ref_not_trusted';
        END IF;
    END LOOP;

    FOR v_term IN SELECT value FROM jsonb_array_elements(p_terms) LOOP
        IF length(trim(COALESCE(v_term->>'canonical_key', ''))) = 0 THEN
            RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_term_key_missing';
        END IF;
        IF jsonb_typeof(COALESCE(v_term->'source_refs', 'null'::jsonb)) <> 'array'
           OR jsonb_array_length(v_term->'source_refs') = 0
           OR NOT (p_source_refs @> (v_term->'source_refs')) THEN
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p1_term_source_refs_invalid';
        END IF;
        IF COALESCE((v_term->>'conflicted')::boolean, FALSE)
           AND v_term->'value' IS NOT NULL
           AND v_term->'value' <> 'null'::jsonb THEN
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p1_conflict_cannot_choose_value';
        END IF;
    END LOOP;

    v_payload_hash := encode(
        digest(convert_to(p_normalized_payload::text, 'UTF8'), 'sha256'),
        'hex'
    );

    SELECT * INTO v_dossier
      FROM public.mb12_p1_offer_contract d
     WHERE d.owner_user_id = v_owner
       AND d.stable_id = p_stable_id
     FOR UPDATE;

    IF FOUND THEN
        IF v_dossier.payload_hash = v_payload_hash AND v_dossier.state = p_state THEN
            RETURN QUERY SELECT v_dossier.dossier_id, v_dossier.current_revision, v_dossier.payload_hash;
            RETURN;
        END IF;
        IF v_dossier.state = 'revoked' AND p_state <> 'revoked' THEN
            RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb12_p1_revoked_dossier_cannot_reactivate';
        END IF;
        v_revision := v_dossier.current_revision + 1;
        p_dossier_id := v_dossier.dossier_id;
    ELSE
        v_revision := 1;
        INSERT INTO public.mb12_p1_offer_contract (
            owner_user_id, dossier_id, stable_id, document_kind, title,
            current_revision, state, payload_hash
        ) VALUES (
            v_owner, p_dossier_id, p_stable_id, p_document_kind, p_title,
            v_revision, p_state, v_payload_hash
        );
    END IF;

    INSERT INTO public.mb12_p1_offer_contract_revision (
        owner_user_id, dossier_id, revision, state, payload_hash,
        normalized_payload, source_refs
    ) VALUES (
        v_owner, p_dossier_id, v_revision, p_state, v_payload_hash,
        p_normalized_payload, p_source_refs
    );

    FOR v_term IN SELECT value FROM jsonb_array_elements(p_terms) LOOP
        INSERT INTO public.mb12_p1_normalized_term (
            owner_user_id, candidate_id, dossier_id, revision, canonical_key,
            clause_type, normalized_value, alternatives, currency, unit, period,
            confidence, conflicted, raw_values, source_refs
        ) VALUES (
            v_owner,
            (v_term->>'candidate_id')::uuid,
            p_dossier_id,
            v_revision,
            v_term->>'canonical_key',
            v_term->>'clause_type',
            v_term->'value',
            COALESCE(v_term->'alternatives', '[]'::jsonb),
            COALESCE(v_term->>'currency', ''),
            COALESCE(v_term->>'unit', ''),
            COALESCE(v_term->>'period', ''),
            COALESCE((v_term->>'confidence')::numeric, 1.0),
            COALESCE((v_term->>'conflicted')::boolean, FALSE),
            COALESCE(v_term->'raw_values', '[]'::jsonb),
            v_term->'source_refs'
        );
    END LOOP;

    UPDATE public.mb12_p1_offer_contract
       SET document_kind = p_document_kind,
           title = p_title,
           current_revision = v_revision,
           state = p_state,
           payload_hash = v_payload_hash,
           updated_at = NOW()
     WHERE owner_user_id = v_owner
       AND dossier_id = p_dossier_id;

    RETURN QUERY SELECT p_dossier_id, v_revision, v_payload_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION public.mb12_p1_revoke_dossier(
    p_dossier_id UUID,
    p_reason TEXT
) RETURNS TABLE(dossier_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_dossier public.mb12_p1_offer_contract%ROWTYPE;
    v_previous public.mb12_p1_offer_contract_revision%ROWTYPE;
    v_revision INTEGER;
    v_payload JSONB;
    v_payload_hash TEXT;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_authenticated_owner_missing';
    END IF;
    IF p_dossier_id IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_dossier_id_missing';
    END IF;
    IF length(trim(COALESCE(p_reason, ''))) = 0 OR length(p_reason) > 500 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p1_revocation_reason_invalid';
    END IF;

    SELECT * INTO v_dossier
      FROM public.mb12_p1_offer_contract d
     WHERE d.owner_user_id = v_owner
       AND d.dossier_id = p_dossier_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = 'P0002', MESSAGE = 'mb12_p1_dossier_not_found';
    END IF;
    IF v_dossier.state = 'revoked' THEN
        RETURN QUERY SELECT v_dossier.dossier_id, v_dossier.current_revision, v_dossier.payload_hash;
        RETURN;
    END IF;

    SELECT * INTO v_previous
      FROM public.mb12_p1_offer_contract_revision r
     WHERE r.owner_user_id = v_owner
       AND r.dossier_id = p_dossier_id
       AND r.revision = v_dossier.current_revision;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb12_p1_current_revision_missing';
    END IF;

    v_revision := v_dossier.current_revision + 1;
    v_payload := v_previous.normalized_payload
        || jsonb_build_object(
            'state', 'revoked',
            'revocation_reason', trim(p_reason),
            'revoked_from_revision', v_dossier.current_revision
        );
    v_payload_hash := encode(
        digest(convert_to(v_payload::text, 'UTF8'), 'sha256'),
        'hex'
    );

    INSERT INTO public.mb12_p1_offer_contract_revision (
        owner_user_id, dossier_id, revision, state, payload_hash,
        normalized_payload, source_refs
    ) VALUES (
        v_owner, p_dossier_id, v_revision, 'revoked', v_payload_hash,
        v_payload, v_previous.source_refs
    );

    INSERT INTO public.mb12_p1_normalized_term (
        owner_user_id, candidate_id, dossier_id, revision, canonical_key,
        clause_type, normalized_value, alternatives, currency, unit, period,
        confidence, conflicted, raw_values, source_refs
    )
    SELECT
        owner_user_id, gen_random_uuid(), dossier_id, v_revision, canonical_key,
        clause_type, normalized_value, alternatives, currency, unit, period,
        confidence, conflicted, raw_values, source_refs
      FROM public.mb12_p1_normalized_term
     WHERE owner_user_id = v_owner
       AND dossier_id = p_dossier_id
       AND revision = v_dossier.current_revision;

    UPDATE public.mb12_p1_offer_contract
       SET current_revision = v_revision,
           state = 'revoked',
           payload_hash = v_payload_hash,
           updated_at = NOW()
     WHERE owner_user_id = v_owner
       AND dossier_id = p_dossier_id;

    RETURN QUERY SELECT p_dossier_id, v_revision, v_payload_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb12_p1_revoke_dossier(UUID, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p1_revoke_dossier(UUID, TEXT) TO mb12_p1_app;

REVOKE ALL ON FUNCTION public.mb12_p1_write_normalization(
    UUID, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB
) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p1_write_normalization(
    UUID, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB
) TO mb12_p1_app;

REVOKE INSERT, UPDATE, DELETE ON public.mb12_p1_offer_contract FROM PUBLIC, mb12_p1_app;
REVOKE INSERT, UPDATE, DELETE ON public.mb12_p1_offer_contract_revision FROM PUBLIC, mb12_p1_app;
REVOKE INSERT, UPDATE, DELETE ON public.mb12_p1_normalized_term FROM PUBLIC, mb12_p1_app;
GRANT SELECT ON public.mb12_p1_offer_contract TO mb12_p1_app;
GRANT SELECT ON public.mb12_p1_offer_contract_revision TO mb12_p1_app;
GRANT SELECT ON public.mb12_p1_normalized_term TO mb12_p1_app;

COMMENT ON TABLE public.mb12_p1_offer_contract IS
    'Owner-scoped current projection of candidate offer/contract normalization; never an automatic decision.';
COMMENT ON TABLE public.mb12_p1_offer_contract_revision IS
    'Append-only normalization revisions derived from MB12-P0 trusted data.';
COMMENT ON TABLE public.mb12_p1_normalized_term IS
    'Candidate normalized terms with exact source provenance and conflict preservation.';

COMMIT;
