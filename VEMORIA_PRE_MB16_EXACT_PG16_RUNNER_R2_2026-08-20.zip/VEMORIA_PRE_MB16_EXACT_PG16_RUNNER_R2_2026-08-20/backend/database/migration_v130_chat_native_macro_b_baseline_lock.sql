-- Vemoria — Migration V130: Chat Native Macro B baseline lock
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
--
-- Scopo: congelare la baseline canonica di Vemoria Chat senza costruire Macro C/D/E/F.
-- Macro B supporta solo:
--   - ONE_TO_ONE   (thread_type = 'direct')
--   - GROUP_CONDIVISO (thread_type = 'group', visibilita' tutti-a-tutti)
-- GROUP_COORDINATO, visibilita' a tre stati, estrazione candidata e presa visione
-- distinta restano riservati alle macro successive.

ALTER TABLE chat_thread ADD COLUMN IF NOT EXISTS native_chat_topology TEXT;
ALTER TABLE chat_thread ADD COLUMN IF NOT EXISTS native_chat_surface TEXT NOT NULL DEFAULT 'relationship_desk';
ALTER TABLE chat_thread ADD COLUMN IF NOT EXISTS native_chat_contract_version TEXT NOT NULL DEFAULT 'VEMORIA_CHAT_NATIVE_RELATION_MEMORY_BLOCK_MACRO_B_V1';
ALTER TABLE chat_thread ADD COLUMN IF NOT EXISTS opens_in_scrivania_context BOOLEAN NOT NULL DEFAULT TRUE;
ALTER TABLE chat_thread ADD COLUMN IF NOT EXISTS creates_second_chat_home BOOLEAN NOT NULL DEFAULT FALSE;

UPDATE chat_thread
   SET native_chat_topology = CASE
        WHEN thread_type = 'direct' THEN 'ONE_TO_ONE'
        WHEN thread_type = 'group'  THEN 'GROUP_CONDIVISO'
        ELSE native_chat_topology
   END
 WHERE native_chat_topology IS NULL;

ALTER TABLE chat_thread DROP CONSTRAINT IF EXISTS chat_thread_native_chat_topology_check;
ALTER TABLE chat_thread ADD CONSTRAINT chat_thread_native_chat_topology_check CHECK (
    native_chat_topology IS NULL OR native_chat_topology IN ('ONE_TO_ONE','GROUP_CONDIVISO')
);

ALTER TABLE chat_thread DROP CONSTRAINT IF EXISTS chat_thread_native_chat_surface_check;
ALTER TABLE chat_thread ADD CONSTRAINT chat_thread_native_chat_surface_check CHECK (
    native_chat_surface = 'relationship_desk'
);

ALTER TABLE chat_thread DROP CONSTRAINT IF EXISTS chat_thread_no_second_chat_home_check;
ALTER TABLE chat_thread ADD CONSTRAINT chat_thread_no_second_chat_home_check CHECK (
    creates_second_chat_home = FALSE
);

ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS memory_promotion_state TEXT NOT NULL DEFAULT 'CHAT_ONLY';
ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS candidate_extraction_state TEXT NOT NULL DEFAULT 'NOT_ENABLED_MACRO_B';
ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS read_semantics_version TEXT NOT NULL DEFAULT 'READ_ONLY_NOT_ACK_NOT_PROOF';

ALTER TABLE chat_messaggi DROP CONSTRAINT IF EXISTS chat_messaggi_memory_promotion_state_check;
ALTER TABLE chat_messaggi ADD CONSTRAINT chat_messaggi_memory_promotion_state_check CHECK (
    memory_promotion_state IN ('CHAT_ONLY','NOT_PROMOTED_TO_MEMORY')
);

ALTER TABLE chat_messaggi DROP CONSTRAINT IF EXISTS chat_messaggi_candidate_extraction_state_check;
ALTER TABLE chat_messaggi ADD CONSTRAINT chat_messaggi_candidate_extraction_state_check CHECK (
    candidate_extraction_state = 'NOT_ENABLED_MACRO_B'
);

ALTER TABLE chat_messaggi DROP CONSTRAINT IF EXISTS chat_messaggi_read_semantics_version_check;
ALTER TABLE chat_messaggi ADD CONSTRAINT chat_messaggi_read_semantics_version_check CHECK (
    read_semantics_version = 'READ_ONLY_NOT_ACK_NOT_PROOF'
);

COMMENT ON COLUMN chat_thread.native_chat_topology IS
    'Macro B topology lock: ONE_TO_ONE or GROUP_CONDIVISO only. GROUP_COORDINATO reserved for Macro D.';
COMMENT ON COLUMN chat_thread.native_chat_surface IS
    'Vemoria Chat opens inside Contatti/Relazioni -> Scrivania; no second chat home.';
COMMENT ON COLUMN chat_messaggi.memory_promotion_state IS
    'Macro B: message remains chat-only; no automatic canonical memory promotion.';
COMMENT ON COLUMN chat_messaggi.candidate_extraction_state IS
    'Macro B: CandidateExtraction deliberately disabled; introduced in Macro C.';
COMMENT ON COLUMN chat_messaggi.read_semantics_version IS
    'Read is not presa visione and not proof. Macro E will extend states.';
