-- Vemoria PRE-MB16 — real mailbox ownership verification.
-- Verification challenges are owner-scoped, short-lived and never store the
-- plaintext code. A verified mailbox is identity authority for invite/public
-- claim flows; merely importing or forwarding mail is not verification.
BEGIN;

CREATE TABLE IF NOT EXISTS mailbox_verification_challenges (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    email_canonical TEXT NOT NULL,
    code_hmac TEXT NOT NULL CHECK (length(code_hmac) = 64),
    state TEXT NOT NULL DEFAULT 'PENDING'
        CHECK (state IN ('PENDING','VERIFIED','EXPIRED','LOCKED','REVOKED')),
    attempt_count INTEGER NOT NULL DEFAULT 0 CHECK (attempt_count >= 0),
    max_attempts INTEGER NOT NULL DEFAULT 5 CHECK (max_attempts BETWEEN 1 AND 10),
    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    completed_at TIMESTAMPTZ NULL,
    delivery_provider TEXT NOT NULL DEFAULT 'smtp_tls',
    CHECK (expires_at > requested_at)
);

CREATE INDEX IF NOT EXISTS idx_mailbox_verify_owner_recent
    ON mailbox_verification_challenges(owner_id, requested_at DESC);

CREATE INDEX IF NOT EXISTS idx_mailbox_verify_owner_pending
    ON mailbox_verification_challenges(owner_id, expires_at)
    WHERE state = 'PENDING';

ALTER TABLE mailbox_verification_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE mailbox_verification_challenges FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS mailbox_verification_owner_policy ON mailbox_verification_challenges;
CREATE POLICY mailbox_verification_owner_policy
    ON mailbox_verification_challenges
    FOR ALL
    USING (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

COMMENT ON TABLE mailbox_verification_challenges IS
    'Owner-scoped short-lived mailbox ownership challenges. Plain verification codes must never be persisted.';
COMMENT ON COLUMN mailbox_verification_challenges.code_hmac IS
    'HMAC-SHA256 digest of challenge id + canonical email + one-time code using server-only key; never plaintext.';

COMMIT;
