-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V4.3 — Migration V22 — Document + Search + Memory Final

-- Document duplicates + versions
ALTER TABLE documenti
    ADD COLUMN IF NOT EXISTS is_duplicate    BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS originale_id    UUID REFERENCES documenti(id),
    ADD COLUMN IF NOT EXISTS versione_doc    INTEGER NOT NULL DEFAULT 1,
    ADD COLUMN IF NOT EXISTS parent_version_id UUID REFERENCES documenti(id),
    ADD COLUMN IF NOT EXISTS location_tag   TEXT;

-- Memory enhancements
ALTER TABLE memorie
    ADD COLUMN IF NOT EXISTS location_tag   TEXT,
    ADD COLUMN IF NOT EXISTS is_deleted     BOOLEAN NOT NULL DEFAULT FALSE;

CREATE INDEX IF NOT EXISTS idx_doc_duplicate    ON documenti(is_duplicate);
CREATE INDEX IF NOT EXISTS idx_doc_originale    ON documenti(originale_id);
CREATE INDEX IF NOT EXISTS idx_doc_parent_ver   ON documenti(parent_version_id);
CREATE INDEX IF NOT EXISTS idx_doc_location     ON documenti(location_tag);
CREATE INDEX IF NOT EXISTS idx_mem_location     ON memorie(location_tag);
CREATE INDEX IF NOT EXISTS idx_mem_deleted      ON memorie(is_deleted);
