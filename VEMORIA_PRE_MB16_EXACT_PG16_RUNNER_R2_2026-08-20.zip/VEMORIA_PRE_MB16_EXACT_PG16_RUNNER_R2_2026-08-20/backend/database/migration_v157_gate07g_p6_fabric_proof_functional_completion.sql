-- Gate07G — P6 Fabric/Proof functional completion
-- Code integration marker only. Does not claim real transfer, real signature,
-- protected preview runtime, PostgreSQL, Android/Flutter or recipient receipt.

CREATE TABLE IF NOT EXISTS gate07g_p6_fabric_proof_functional_completion (
    id INTEGER PRIMARY KEY,
    gate TEXT NOT NULL DEFAULT 'GATE07G_P6_FABRIC_PROOF_FUNCTIONAL_COMPLETION',
    version TEXT NOT NULL DEFAULT 'GATE07G_P6_FABRIC_PROOF_FUNCTIONAL_COMPLETION_V157_2026-06-20',
    p6_vc_ids TEXT NOT NULL DEFAULT 'VC-063,VC-067',
    integration_state TEXT NOT NULL DEFAULT 'CODICE_INTEGRATO',
    runtime_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE,
    fabric_transfer_runtime_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    signature_acceptance_runtime_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    protected_preview_runtime_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    deposited_is_delivered BOOLEAN NOT NULL DEFAULT FALSE,
    sender_can_fabricate_recipient_receipt BOOLEAN NOT NULL DEFAULT FALSE,
    protected_preview_is_derivative BOOLEAN NOT NULL DEFAULT TRUE,
    original_remains_authoritative BOOLEAN NOT NULL DEFAULT TRUE,
    owner_confirmation_required BOOLEAN NOT NULL DEFAULT TRUE,
    CHECK (runtime_pass_claimed = FALSE),
    CHECK (runtime_real <> 'PASS'),
    CHECK (deposited_is_delivered = FALSE),
    CHECK (sender_can_fabricate_recipient_receipt = FALSE)
);

INSERT INTO gate07g_p6_fabric_proof_functional_completion(id) VALUES (1) ON CONFLICT DO NOTHING;
