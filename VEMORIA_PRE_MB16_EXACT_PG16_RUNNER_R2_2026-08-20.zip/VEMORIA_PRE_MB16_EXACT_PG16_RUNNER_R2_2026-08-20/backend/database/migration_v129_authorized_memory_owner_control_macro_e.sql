-- Vemoria Authorized Memory Macro E
-- UX controllo proprietario: stati leggibili, azioni esplicite, privacy log.
-- Additive static contract. Runtime PostgreSQL non eseguito in ChatGPT.

CREATE TABLE IF NOT EXISTS authorized_memory_owner_control_cards (
    owner_id TEXT NOT NULL,
    card_id TEXT NOT NULL,
    control_device_id TEXT NOT NULL,
    card_kind TEXT NOT NULL CHECK (card_kind IN ('device','source','grant','sync','heavy_work','revocation','review','privacy_log')),
    status TEXT NOT NULL CHECK (status IN (
        'indexed_only',
        'identity_computed',
        'derivatives_created',
        'content_copied_to_vault',
        'canonical_review_required',
        'revoked_or_neutralized',
        'paused',
        'offline_queued',
        'blocked'
    )),
    severity TEXT NOT NULL CHECK (severity IN ('info','attention','warning','blocked','success')),
    title TEXT NOT NULL,
    summary TEXT NOT NULL,
    primary_ref TEXT NOT NULL,
    allowed_actions JSONB NOT NULL DEFAULT '[]'::jsonb,
    blocked_actions JSONB NOT NULL DEFAULT '{}'::jsonb,
    did_do JSONB NOT NULL DEFAULT '[]'::jsonb,
    did_not_do JSONB NOT NULL DEFAULT '[]'::jsonb,
    source_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
    device_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
    grant_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
    visible_to_owner BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (owner_id, card_id),
    CHECK (card_id LIKE 'uiref:%'),
    CHECK (primary_ref LIKE 'uiref:%' OR primary_ref LIKE 'sourceref:%' OR primary_ref LIKE 'devref:%' OR primary_ref LIKE 'grantref:%' OR primary_ref LIKE 'revref:%' OR primary_ref LIKE 'workref:%' OR primary_ref LIKE 'fabricref:%'),
    CHECK (visible_to_owner = TRUE),
    CHECK (jsonb_array_length(did_do) + jsonb_array_length(did_not_do) > 0)
);

CREATE TABLE IF NOT EXISTS authorized_memory_owner_control_requests (
    owner_id TEXT NOT NULL,
    request_id TEXT NOT NULL,
    requested_by_device_id TEXT NOT NULL,
    surface TEXT NOT NULL CHECK (surface IN ('mobile','desktop','tablet','vault','server_admin')),
    action TEXT NOT NULL CHECK (action IN (
        'pause_grant',
        'resume_grant',
        'revoke_grant',
        'delete_derived_results',
        'exclude_source',
        'change_schedule',
        'cancel_queued_work',
        'open_owner_review',
        'confirm_promote_to_canonical'
    )),
    target_ref TEXT NOT NULL,
    owner_visible_label TEXT NOT NULL,
    requires_second_confirm BOOLEAN NOT NULL DEFAULT FALSE,
    revocation_id TEXT,
    state TEXT NOT NULL DEFAULT 'ready' CHECK (state IN ('ready','needs_owner_confirmation','blocked_by_policy','blocked_missing_revocation_plan','queued_offline')),
    safe_to_execute_without_more_input BOOLEAN NOT NULL DEFAULT FALSE,
    visible_effects JSONB NOT NULL DEFAULT '[]'::jsonb,
    invisible_effects_forbidden JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (owner_id, request_id),
    CHECK (request_id LIKE 'uiref:%'),
    CHECK (target_ref LIKE 'uiref:%' OR target_ref LIKE 'sourceref:%' OR target_ref LIKE 'devref:%' OR target_ref LIKE 'grantref:%' OR target_ref LIKE 'revref:%' OR target_ref LIKE 'workref:%' OR target_ref LIKE 'fabricref:%'),
    CHECK (action NOT IN ('revoke_grant','delete_derived_results','exclude_source','confirm_promote_to_canonical') OR requires_second_confirm = TRUE),
    CHECK (action <> 'revoke_grant' OR revocation_id IS NOT NULL),
    CHECK (action <> 'revoke_grant' OR state = 'needs_owner_confirmation'),
    CHECK (safe_to_execute_without_more_input = FALSE OR state = 'ready')
);

CREATE TABLE IF NOT EXISTS authorized_memory_owner_privacy_log (
    owner_id TEXT NOT NULL,
    log_id TEXT NOT NULL,
    source_ref TEXT,
    device_ref TEXT,
    grant_ref TEXT,
    action TEXT NOT NULL,
    did_do JSONB NOT NULL DEFAULT '[]'::jsonb,
    did_not_do JSONB NOT NULL DEFAULT '[]'::jsonb,
    runtime_verified BOOLEAN NOT NULL DEFAULT FALSE,
    owner_visible BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (owner_id, log_id),
    CHECK (log_id LIKE 'uiref:%'),
    CHECK (owner_visible = TRUE),
    CHECK (jsonb_array_length(did_do) + jsonb_array_length(did_not_do) > 0),
    CHECK (source_ref IS NULL OR source_ref LIKE 'sourceref:%'),
    CHECK (device_ref IS NULL OR device_ref LIKE 'devref:%'),
    CHECK (grant_ref IS NULL OR grant_ref LIKE 'grantref:%')
);

CREATE INDEX IF NOT EXISTS idx_auth_mem_owner_cards_owner_kind
    ON authorized_memory_owner_control_cards(owner_id, card_kind, status);

CREATE INDEX IF NOT EXISTS idx_auth_mem_owner_requests_owner_action
    ON authorized_memory_owner_control_requests(owner_id, action, state);

CREATE INDEX IF NOT EXISTS idx_auth_mem_owner_privacy_log_owner_time
    ON authorized_memory_owner_privacy_log(owner_id, created_at DESC);
