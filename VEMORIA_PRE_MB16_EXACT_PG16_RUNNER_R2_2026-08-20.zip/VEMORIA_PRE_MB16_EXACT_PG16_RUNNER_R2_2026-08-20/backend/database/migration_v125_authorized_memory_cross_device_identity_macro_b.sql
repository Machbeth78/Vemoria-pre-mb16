-- Vemoria R5 — Authorized Memory Macro B
-- Identità contenuto e deduplica cross-device.
-- Additiva: non sostituisce Source Indexer v109 né Macro A v124.

CREATE TABLE IF NOT EXISTS authorized_memory_content_identities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    content_id TEXT NOT NULL,
    content_sha256 TEXT NOT NULL,
    authority TEXT NOT NULL DEFAULT 'TECHNICAL_FACT',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (content_id ~ '^cnt_[0-9a-f]{64}$'),
    CHECK (content_sha256 ~ '^[0-9a-f]{64}$'),
    CHECK (content_id = 'cnt_' || content_sha256),
    CHECK (authority IN ('TECHNICAL_FACT','PIPELINE_OBSERVATION','OWNER_CONFIRMED')),
    UNIQUE(owner_id, content_id)
);

CREATE TABLE IF NOT EXISTS authorized_memory_content_locations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    content_id TEXT NOT NULL,
    location_id TEXT NOT NULL,
    device_id TEXT NOT NULL,
    source_id TEXT NOT NULL,
    opaque_item_ref TEXT NOT NULL,
    location_role TEXT NOT NULL DEFAULT 'INDEXED_LOCATION',
    size_bytes BIGINT,
    mime_type TEXT,
    observed_filename_redacted TEXT,
    grant_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (content_id ~ '^cnt_[0-9a-f]{64}$'),
    CHECK (location_id ~ '^loc_[0-9a-f]{64}$'),
    CHECK (opaque_item_ref ~ '^(sourceref:|devref:|vaultref:|localref:|contentref:|derivref:)'),
    CHECK (opaque_item_ref !~ '(^/|^[A-Za-z]:\\|/Users/|/home/|/storage/|/sdcard/|content://|file://|smb://|\\\\)'),
    CHECK (location_role IN ('INDEXED_LOCATION','VAULT_COPY_LOCATION','CANONICAL_LOCATION','DERIVATIVE_LOCATION')),
    CHECK (size_bytes IS NULL OR size_bytes >= 0),
    UNIQUE(owner_id, location_id)
);

CREATE TABLE IF NOT EXISTS authorized_memory_derivative_links (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    parent_content_id TEXT NOT NULL,
    derivative_content_id TEXT NOT NULL,
    derivative_sha256 TEXT NOT NULL,
    derivative_kind TEXT NOT NULL,
    parent_location_id TEXT,
    transform_profile_ref TEXT,
    authority TEXT NOT NULL DEFAULT 'TECHNICAL_FACT',
    never_promote_to_original BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (parent_content_id ~ '^cnt_[0-9a-f]{64}$'),
    CHECK (derivative_content_id ~ '^cnt_[0-9a-f]{64}$'),
    CHECK (derivative_sha256 ~ '^[0-9a-f]{64}$'),
    CHECK (derivative_content_id = 'cnt_' || derivative_sha256),
    CHECK (derivative_content_id <> parent_content_id),
    CHECK (derivative_kind IN ('redaction','ocr_text','thumbnail','proxy','normalized_export','format_conversion','user_edit','unknown_derivative')),
    CHECK (authority IN ('TECHNICAL_FACT','PIPELINE_OBSERVATION','OWNER_CONFIRMED')),
    CHECK (derivative_kind <> 'redaction' OR never_promote_to_original = TRUE),
    CHECK (parent_location_id IS NULL OR parent_location_id ~ '^loc_[0-9a-f]{64}$'),
    CHECK (transform_profile_ref IS NULL OR transform_profile_ref ~ '^(sourceref:|devref:|vaultref:|localref:|contentref:|derivref:)')
);

CREATE TABLE IF NOT EXISTS authorized_memory_similarity_candidates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    candidate_id TEXT NOT NULL,
    left_content_id TEXT NOT NULL,
    right_content_id TEXT NOT NULL,
    signal_kind TEXT NOT NULL,
    signal_ref TEXT NOT NULL,
    confidence NUMERIC NOT NULL,
    authority TEXT NOT NULL DEFAULT 'PIPELINE_OBSERVATION',
    owner_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
    merge_allowed BOOLEAN NOT NULL DEFAULT FALSE,
    explanation TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (candidate_id ~ '^sim_[0-9a-f]{64}$'),
    CHECK (left_content_id ~ '^cnt_[0-9a-f]{64}$'),
    CHECK (right_content_id ~ '^cnt_[0-9a-f]{64}$'),
    CHECK (left_content_id <> right_content_id),
    CHECK (signal_ref ~ '^(sourceref:|devref:|vaultref:|localref:|contentref:|derivref:)'),
    CHECK (confidence >= 0 AND confidence <= 1),
    CHECK (signal_kind IN ('perceptual_hash','ocr_fingerprint','audio_fingerprint','video_temporal_fingerprint','metadata_similarity','manual_hint')),
    CHECK (authority IN ('TECHNICAL_FACT','PIPELINE_OBSERVATION','OWNER_CONFIRMED')),
    CHECK (merge_allowed = FALSE OR (authority = 'OWNER_CONFIRMED' AND owner_confirmed = TRUE)),
    UNIQUE(owner_id, candidate_id)
);

CREATE TABLE IF NOT EXISTS authorized_memory_owner_equivalences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    left_content_id TEXT NOT NULL,
    right_content_id TEXT NOT NULL,
    confirmation_event_ref TEXT NOT NULL,
    confirmed_by_device_id TEXT NOT NULL,
    reason TEXT NOT NULL,
    authority TEXT NOT NULL DEFAULT 'OWNER_CONFIRMED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (left_content_id ~ '^cnt_[0-9a-f]{64}$'),
    CHECK (right_content_id ~ '^cnt_[0-9a-f]{64}$'),
    CHECK (left_content_id <> right_content_id),
    CHECK (confirmation_event_ref ~ '^(sourceref:|devref:|vaultref:|localref:|contentref:|derivref:)'),
    CHECK (authority = 'OWNER_CONFIRMED')
);

CREATE INDEX IF NOT EXISTS idx_auth_mem_content_identity_owner_sha
ON authorized_memory_content_identities(owner_id, content_sha256);

CREATE INDEX IF NOT EXISTS idx_auth_mem_content_locations_owner_content
ON authorized_memory_content_locations(owner_id, content_id);

CREATE INDEX IF NOT EXISTS idx_auth_mem_derivative_parent
ON authorized_memory_derivative_links(owner_id, parent_content_id);

CREATE INDEX IF NOT EXISTS idx_auth_mem_similarity_pair
ON authorized_memory_similarity_candidates(owner_id, left_content_id, right_content_id);
