-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.

-- Gate03: crash-recovery metadata, verified receipt replay anchors and
-- privacy-minimised assisted-route usage observations. Metadata only: no
-- plaintext, filenames, MIME types, contacts, content keys or binaries.

ALTER TABLE fabric_transfer_sessions
    ADD COLUMN IF NOT EXISTS state_version BIGINT NOT NULL DEFAULT 0;
ALTER TABLE fabric_transfer_sessions
    ADD COLUMN IF NOT EXISTS recovery_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE fabric_transfer_sessions
    ADD COLUMN IF NOT EXISTS last_recovered_at TIMESTAMPTZ;

ALTER TABLE fabric_route_attempts
    DROP CONSTRAINT IF EXISTS fabric_route_attempts_result_check;
ALTER TABLE fabric_route_attempts
    ADD CONSTRAINT fabric_route_attempts_result_check
    CHECK (result IN ('in_progress','started','connected','connect_failed',
                      'paused','interrupted','integrity_failed',
                      'verification_failed','failed','deposited','delivered'));

CREATE TABLE IF NOT EXISTS fabric_transfer_recovery_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    transfer_session_id UUID NOT NULL REFERENCES fabric_transfer_sessions(id) ON DELETE CASCADE,
    previous_state TEXT NOT NULL
        CHECK (previous_state IN ('discovering','connecting','transferring','verifying')),
    recovered_state TEXT NOT NULL DEFAULT 'paused'
        CHECK (recovered_state = 'paused'),
    reason_code TEXT NOT NULL DEFAULT 'process_interrupted',
    recovered_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_fabric_recovery_owner_transfer
    ON fabric_transfer_recovery_events(owner_user_id, transfer_session_id, recovered_at DESC);

CREATE TABLE IF NOT EXISTS fabric_verified_receipt_anchors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    transfer_session_id UUID NOT NULL REFERENCES fabric_transfer_sessions(id) ON DELETE CASCADE,
    receipt_id TEXT NOT NULL,
    receipt_digest_sha256 CHAR(64) NOT NULL,
    issuer_key_fingerprint CHAR(64) NOT NULL,
    receipt_status TEXT NOT NULL,
    observed_at TIMESTAMPTZ NOT NULL,
    anchored_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_user_id, receipt_id),
    UNIQUE(owner_user_id, receipt_digest_sha256)
);
CREATE INDEX IF NOT EXISTS idx_fabric_receipt_anchor_owner_transfer
    ON fabric_verified_receipt_anchors(owner_user_id, transfer_session_id, anchored_at DESC);

CREATE TABLE IF NOT EXISTS fabric_assisted_route_usage_observations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    transfer_session_id UUID REFERENCES fabric_transfer_sessions(id) ON DELETE SET NULL,
    route TEXT NOT NULL CHECK (route IN ('blind_relay','blind_deposit')),
    event_kind TEXT NOT NULL
        CHECK (event_kind IN ('accepted','transferred','stored','retrieved','expired','deleted')),
    ciphertext_bytes BIGINT NOT NULL DEFAULT 0 CHECK (ciphertext_bytes >= 0),
    storage_seconds BIGINT CHECK (storage_seconds IS NULL OR storage_seconds >= 0),
    observed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_fabric_assisted_usage_owner_time
    ON fabric_assisted_route_usage_observations(owner_user_id, observed_at DESC);

COMMENT ON TABLE fabric_verified_receipt_anchors IS
    'Owner-scoped replay anchors for receipts already verified while the issuer key was trusted.';
COMMENT ON TABLE fabric_assisted_route_usage_observations IS
    'Ciphertext byte/storage observations for Product Probe cost measurement; no content or contact metadata.';
