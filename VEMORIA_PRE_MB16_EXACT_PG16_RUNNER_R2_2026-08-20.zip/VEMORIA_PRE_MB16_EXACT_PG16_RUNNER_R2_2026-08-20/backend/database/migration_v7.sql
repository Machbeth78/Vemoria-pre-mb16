-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V2.5 — Migration V7 — Notifiche eventi invio
CREATE TABLE IF NOT EXISTS notifiche_invio (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    evento_id   UUID NOT NULL REFERENCES eventi_invio(id) ON DELETE CASCADE,
    tipo        TEXT NOT NULL,   -- 'scaduto' | 'distrutto'
    messaggio   TEXT NOT NULL,
    registrata_il TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_notifiche_evento ON notifiche_invio(evento_id);
