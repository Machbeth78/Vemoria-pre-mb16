-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V3.0 — Migration V11 — Document Lifecycle System
CREATE TABLE IF NOT EXISTS document_lifecycle (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    stato        TEXT NOT NULL,
    descrizione  TEXT,
    creato_il    TIMESTAMP NOT NULL DEFAULT NOW(),
    origine      TEXT NOT NULL DEFAULT 'sistema'
);
CREATE INDEX IF NOT EXISTS idx_lifecycle_documento ON document_lifecycle(documento_id);
CREATE INDEX IF NOT EXISTS idx_lifecycle_stato     ON document_lifecycle(stato);
CREATE INDEX IF NOT EXISTS idx_lifecycle_creato    ON document_lifecycle(creato_il DESC);
