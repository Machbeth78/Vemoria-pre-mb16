-- Vemoria MB15 R5H5/R6 result-truth convergence.
--
-- R6 owns the product request lifecycle. R5H5 owns the semantic derived result.
-- A request is not considered successfully resolved until the exact R5H5 result
-- is durably anchored. Legacy SUCCEEDED rows are deliberately NOT promoted to a
-- canonical result because this recovery line has no durable proof payload for them.

ALTER TABLE mb15_r6_owner_node_product_requests
    ADD COLUMN IF NOT EXISTS attempt_count INTEGER NOT NULL DEFAULT 1 CHECK (attempt_count >= 1);

ALTER TABLE mb15_r6_owner_node_product_requests
    DROP CONSTRAINT IF EXISTS mb15_r6_owner_node_product_requests_state_check;

UPDATE mb15_r6_owner_node_product_requests
SET state = 'LEGACY_UNANCHORED'
WHERE state = 'SUCCEEDED';

ALTER TABLE mb15_r6_owner_node_product_requests
    ADD CONSTRAINT mb15_r6_owner_node_product_requests_state_check
    CHECK (state IN ('RUNNING','RESULT_ANCHORED','FAILED','LEGACY_UNANCHORED'));

CREATE TABLE IF NOT EXISTS mb15_r5h5_owner_node_result_ledger (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    product_request_id UUID NOT NULL UNIQUE REFERENCES mb15_r6_owner_node_product_requests(id) ON DELETE CASCADE,
    binding_id UUID NOT NULL REFERENCES mb15_r6_owner_node_product_bindings(id) ON DELETE CASCADE,
    r5h5_request_id TEXT NOT NULL,
    workload_id TEXT NOT NULL CHECK (workload_id IN ('MASS_OCR','MASS_DOCUMENT_ANALYSIS','MASS_VIDEO_ANALYSIS')),
    source_revision_id UUID NOT NULL REFERENCES authorized_memory_inventory_items(id) ON DELETE CASCADE,
    source_sha256 TEXT NOT NULL CHECK (source_sha256 ~ '^[0-9a-f]{64}$'),
    runtime_id TEXT NOT NULL,
    runtime_version TEXT NOT NULL,
    result_state TEXT NOT NULL CHECK (result_state = 'DERIVED_REVIEW_REQUIRED'),
    derived_payload JSONB NOT NULL,
    derived_sha256 TEXT NOT NULL CHECK (derived_sha256 ~ '^[0-9a-f]{64}$'),
    canonical_promotion BOOLEAN NOT NULL DEFAULT FALSE CHECK (canonical_promotion = FALSE),
    search_visible BOOLEAN NOT NULL DEFAULT FALSE CHECK (search_visible = FALSE),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_id, r5h5_request_id),
    UNIQUE(owner_id, product_request_id)
);

CREATE INDEX IF NOT EXISTS idx_mb15_r5h5_owner_node_result_ledger_owner_time
    ON mb15_r5h5_owner_node_result_ledger(owner_id, created_at DESC);

ALTER TABLE mb15_r5h5_owner_node_result_ledger ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb15_r5h5_owner_node_result_ledger FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS mb15_r5h5_owner_node_result_ledger_owner_policy
    ON mb15_r5h5_owner_node_result_ledger;
CREATE POLICY mb15_r5h5_owner_node_result_ledger_owner_policy
    ON mb15_r5h5_owner_node_result_ledger
    USING (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);
