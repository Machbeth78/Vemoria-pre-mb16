-- ============================================================
-- VEMORA — Migration V3
-- Ideatore: Devoti Massimo
-- Nuove tabelle: settori professionali, paesi, libreria
--                documentale, dispositivi utente
-- ============================================================

-- ============================================================
-- TABELLA: settori_professionali
-- Categorie professionali per la libreria documentale
-- ============================================================
CREATE TABLE IF NOT EXISTS settori_professionali (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    codice      TEXT NOT NULL UNIQUE,   -- es: "edilizia", "legale", "fiscale"
    etichetta   JSONB NOT NULL,         -- {"it": "Edilizia", "en": "Construction", ...}
    icona       TEXT,                   -- nome icona UI
    attivo      BOOLEAN NOT NULL DEFAULT TRUE,
    ordine      INTEGER NOT NULL DEFAULT 0,
    creato_il   TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABELLA: paesi
-- Paesi supportati nella libreria documentale
-- ============================================================
CREATE TABLE IF NOT EXISTS paesi (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    codice_iso      TEXT NOT NULL UNIQUE,   -- es: "IT", "FR", "DE", "ES", "GB"
    nome            JSONB NOT NULL,          -- {"it": "Italia", "en": "Italy", ...}
    lingua_default  TEXT NOT NULL DEFAULT 'it',
    attivo          BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il       TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABELLA: libreria_documenti
-- Documento tipo nella libreria per settore + paese + lingua
-- ============================================================
CREATE TABLE IF NOT EXISTS libreria_documenti (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    codice                  TEXT NOT NULL,          -- es: "scia", "permesso_costruire"
    nome                    JSONB NOT NULL,          -- {"it": "SCIA", "en": "Building Notice"}
    descrizione             JSONB,                   -- descrizione multilingua
    settore_id              UUID REFERENCES settori_professionali(id) ON DELETE SET NULL,
    paese_id                UUID REFERENCES paesi(id) ON DELETE SET NULL,
    tipo_documento_id       UUID REFERENCES tipi_documento(id) ON DELETE SET NULL,
    parole_chiave           JSONB,                   -- ["scia", "inizio attività", ...]
    professioni_target      JSONB,                   -- ["geometra", "architetto", ...]
    globale                 BOOLEAN NOT NULL DEFAULT FALSE,  -- valido per tutti i paesi
    sovranazionale          BOOLEAN NOT NULL DEFAULT FALSE,  -- UE, ONU ecc.
    attivo                  BOOLEAN NOT NULL DEFAULT TRUE,
    ordine                  INTEGER NOT NULL DEFAULT 0,
    creato_il               TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_libreria_settore  ON libreria_documenti(settore_id);
CREATE INDEX IF NOT EXISTS idx_libreria_paese    ON libreria_documenti(paese_id);
CREATE INDEX IF NOT EXISTS idx_libreria_globale  ON libreria_documenti(globale);

-- ============================================================
-- TABELLA: dispositivi_utente
-- Info dispositivo per ottimizzazione fotocamera/voce
-- ============================================================
CREATE TABLE IF NOT EXISTS dispositivi_utente (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    marca               TEXT,
    modello             TEXT,
    sistema_operativo   TEXT,           -- "android" | "ios"
    versione_os         TEXT,
    risoluzione_camera  TEXT,           -- es: "12MP"
    zoom_ottico         REAL,
    microfoni           INTEGER,
    supporto_voce       BOOLEAN NOT NULL DEFAULT TRUE,
    raw_info            JSONB,          -- tutti i dati grezzi dal device
    registrato_il       TIMESTAMP NOT NULL DEFAULT NOW(),
    aggiornato_il       TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_dispositivi_utente ON dispositivi_utente(utente_id);

-- ============================================================
-- DATI: settori professionali
-- ============================================================
INSERT INTO settori_professionali (codice, etichetta, icona, ordine) VALUES
    ('personale',   '{"it":"Documenti Personali","en":"Personal Documents","fr":"Documents Personnels","de":"Persönliche Dokumente","es":"Documentos Personales"}', 'person',           1),
    ('edilizia',    '{"it":"Edilizia e Tecnici","en":"Construction","fr":"Construction","de":"Bauwesen","es":"Construcción"}',                                       'construction',     2),
    ('legale',      '{"it":"Area Legale","en":"Legal","fr":"Juridique","de":"Recht","es":"Legal"}',                                                                  'gavel',            3),
    ('fiscale',     '{"it":"Area Fiscale","en":"Tax & Finance","fr":"Fiscal","de":"Steuer","es":"Fiscal"}',                                                          'receipt_long',     4),
    ('lavoro',      '{"it":"Lavoro","en":"Employment","fr":"Emploi","de":"Arbeit","es":"Trabajo"}',                                                                  'work',             5),
    ('sanitario',   '{"it":"Sanitario","en":"Medical","fr":"Médical","de":"Medizinisch","es":"Médico"}',                                                             'local_hospital',   6),
    ('casa',        '{"it":"Casa e Immobili","en":"Home & Property","fr":"Maison","de":"Immobilien","es":"Hogar"}',                                                  'home',             7),
    ('auto',        '{"it":"Auto e Veicoli","en":"Vehicles","fr":"Véhicules","de":"Fahrzeuge","es":"Vehículos"}',                                                    'directions_car',   8),
    ('banca',       '{"it":"Banca e Finanza","en":"Banking","fr":"Banque","de":"Bank","es":"Banca"}',                                                                'account_balance',  9),
    ('scuola',      '{"it":"Scuola e Formazione","en":"Education","fr":"Éducation","de":"Bildung","es":"Educación"}',                                                'school',           10)
ON CONFLICT (codice) DO NOTHING;

-- ============================================================
-- DATI: paesi supportati
-- ============================================================
INSERT INTO paesi (codice_iso, nome, lingua_default) VALUES
    ('IT', '{"it":"Italia","en":"Italy","fr":"Italie","de":"Italien","es":"Italia"}',           'it'),
    ('FR', '{"it":"Francia","en":"France","fr":"France","de":"Frankreich","es":"Francia"}',     'fr'),
    ('DE', '{"it":"Germania","en":"Germany","fr":"Allemagne","de":"Deutschland","es":"Alemania"}','de'),
    ('ES', '{"it":"Spagna","en":"Spain","fr":"Espagne","de":"Spanien","es":"España"}',           'es'),
    ('GB', '{"it":"Regno Unito","en":"United Kingdom","fr":"Royaume-Uni","de":"Vereinigtes Königreich","es":"Reino Unido"}', 'en'),
    ('US', '{"it":"Stati Uniti","en":"United States","fr":"États-Unis","de":"Vereinigte Staaten","es":"Estados Unidos"}',   'en'),
    ('EU', '{"it":"Unione Europea","en":"European Union","fr":"Union Européenne","de":"Europäische Union","es":"Unión Europea"}', 'en')
ON CONFLICT (codice_iso) DO NOTHING;

-- ============================================================
-- DATI: libreria documenti (IT — Documenti Personali)
-- ============================================================
INSERT INTO libreria_documenti (codice, nome, descrizione, settore_id, paese_id, parole_chiave, professioni_target, globale) VALUES

-- Documenti personali globali
('carta_identita',
 '{"it":"Carta d''Identità","en":"Identity Card","fr":"Carte d''Identité","de":"Personalausweis","es":"Documento de Identidad"}',
 '{"it":"Documento di riconoscimento personale","en":"Personal identification document"}',
 (SELECT id FROM settori_professionali WHERE codice='personale'),
 NULL, '["carta identità","documento riconoscimento","identità"]', '[]', TRUE),

('patente_guida',
 '{"it":"Patente di Guida","en":"Driving Licence","fr":"Permis de Conduire","de":"Führerschein","es":"Permiso de Conducir"}',
 '{"it":"Licenza di guida per veicoli a motore","en":"Motor vehicle driving licence"}',
 (SELECT id FROM settori_professionali WHERE codice='personale'),
 NULL, '["patente","guida","motorizzazione","licenza guida"]', '[]', TRUE),

('passaporto',
 '{"it":"Passaporto","en":"Passport","fr":"Passeport","de":"Reisepass","es":"Pasaporte"}',
 '{"it":"Documento di viaggio internazionale","en":"International travel document"}',
 (SELECT id FROM settori_professionali WHERE codice='personale'),
 NULL, '["passaporto","viaggio","internazionale"]', '[]', TRUE),

('tessera_sanitaria',
 '{"it":"Tessera Sanitaria","en":"Health Card","fr":"Carte Vitale","de":"Krankenversicherungskarte","es":"Tarjeta Sanitaria"}',
 '{"it":"Codice fiscale e accesso al SSN","en":"Health insurance card"}',
 (SELECT id FROM settori_professionali WHERE codice='personale'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["tessera sanitaria","codice fiscale","ssn","asl"]', '[]', FALSE),

-- IT — Edilizia
('scia',
 '{"it":"SCIA — Segnalazione Certificata di Inizio Attività","en":"SCIA — Certified Notice of Start of Activity"}',
 '{"it":"Procedura edilizia per lavori non soggetti a permesso di costruire","en":"Building procedure for minor works"}',
 (SELECT id FROM settori_professionali WHERE codice='edilizia'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["scia","inizio attività","sportello unico edilizia","sue"]',
 '["geometra","architetto","ingegnere","impresa edile"]', FALSE),

('cila',
 '{"it":"CILA — Comunicazione Inizio Lavori Asseverata","en":"CILA — Certified Works Start Notice"}',
 '{"it":"Comunicazione per interventi di manutenzione straordinaria","en":"Notice for minor maintenance works"}',
 (SELECT id FROM settori_professionali WHERE codice='edilizia'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["cila","manutenzione straordinaria","comunicazione lavori"]',
 '["geometra","architetto","ingegnere"]', FALSE),

('permesso_costruire',
 '{"it":"Permesso di Costruire","en":"Building Permit","fr":"Permis de Construire","de":"Baugenehmigung","es":"Permiso de Construcción"}',
 '{"it":"Autorizzazione per nuove costruzioni o ristrutturazioni rilevanti","en":"Authorization for new buildings or major renovations"}',
 (SELECT id FROM settori_professionali WHERE codice='edilizia'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["permesso costruire","concessione edilizia","edificazione"]',
 '["geometra","architetto","ingegnere","impresa edile"]', FALSE),

('dia',
 '{"it":"DIA — Denuncia di Inizio Attività","en":"DIA — Declaration of Activity Start"}',
 '{"it":"Procedura edilizia alternativa al permesso di costruire","en":"Alternative building procedure"}',
 (SELECT id FROM settori_professionali WHERE codice='edilizia'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["dia","denuncia inizio attività"]',
 '["geometra","architetto","ingegnere"]', FALSE),

('certificato_agibilita',
 '{"it":"Certificato di Agibilità","en":"Habitability Certificate","fr":"Certificat d''Habitabilité"}',
 '{"it":"Attestazione che l''immobile rispetta le norme igienico-sanitarie e di sicurezza","en":"Certificate that building meets safety standards"}',
 (SELECT id FROM settori_professionali WHERE codice='edilizia'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["agibilità","abitabilità","collaudo","sicurezza edificio"]',
 '["geometra","architetto","ingegnere"]', FALSE),

('ape',
 '{"it":"APE — Attestato di Prestazione Energetica","en":"Energy Performance Certificate","fr":"DPE — Diagnostic de Performance Énergétique","de":"Energieausweis"}',
 '{"it":"Classificazione energetica dell''immobile","en":"Building energy rating certificate"}',
 (SELECT id FROM settori_professionali WHERE codice='edilizia'),
 NULL, '["ape","prestazione energetica","classe energetica","certificazione energetica"]',
 '["geometra","architetto","ingegnere","certificatore energetico"]', FALSE),

('relazione_asseverata',
 '{"it":"Relazione Asseverata","en":"Certified Technical Report"}',
 '{"it":"Relazione tecnica firmata e asseverata da professionista abilitato","en":"Technical report certified by a qualified professional"}',
 (SELECT id FROM settori_professionali WHERE codice='edilizia'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["relazione asseverata","relazione tecnica","asseverazione"]',
 '["geometra","architetto","ingegnere"]', FALSE),

-- IT — Legale
('atto_giudiziario',
 '{"it":"Atto Giudiziario","en":"Court Document","fr":"Acte Judiciaire","de":"Gerichtsdokument","es":"Acto Judicial"}',
 '{"it":"Documento prodotto nell''ambito di un procedimento giudiziario","en":"Document produced in court proceedings"}',
 (SELECT id FROM settori_professionali WHERE codice='legale'),
 NULL, '["atto giudiziario","tribunale","procedimento","udienza"]',
 '["avvocato","magistrato","studio legale"]', FALSE),

('ricorso',
 '{"it":"Ricorso","en":"Appeal","fr":"Recours","de":"Beschwerde","es":"Recurso"}',
 '{"it":"Atto con cui si impugna una decisione davanti a un''autorità superiore","en":"Document challenging a decision before a higher authority"}',
 (SELECT id FROM settori_professionali WHERE codice='legale'),
 NULL, '["ricorso","impugnazione","appello","opposizione"]',
 '["avvocato","studio legale"]', FALSE),

('citazione',
 '{"it":"Citazione in Giudizio","en":"Court Summons","fr":"Citation en Justice","de":"Klage"}',
 '{"it":"Atto con cui si convoca la controparte davanti al giudice","en":"Document summoning a party to court"}',
 (SELECT id FROM settori_professionali WHERE codice='legale'),
 NULL, '["citazione","atto di citazione","udienza","convenuto"]',
 '["avvocato"]', FALSE),

('procura',
 '{"it":"Procura","en":"Power of Attorney","fr":"Procuration","de":"Vollmacht","es":"Poder Notarial"}',
 '{"it":"Atto con cui si conferisce a un terzo il potere di agire in nome proprio","en":"Document granting authority to act on someone''s behalf"}',
 (SELECT id FROM settori_professionali WHERE codice='legale'),
 NULL, '["procura","delega","rappresentanza","mandato"]',
 '["avvocato","notaio"]', TRUE),

-- IT — Fiscale
('dichiarazione_redditi',
 '{"it":"Dichiarazione dei Redditi","en":"Tax Return","fr":"Déclaration de Revenus","de":"Steuererklärung","es":"Declaración de la Renta"}',
 '{"it":"Modello 730 o Redditi PF — dichiarazione annuale all''Agenzia delle Entrate","en":"Annual income tax declaration"}',
 (SELECT id FROM settori_professionali WHERE codice='fiscale'),
 NULL, '["730","dichiarazione redditi","modello unico","irpef","agenzia entrate"]',
 '["commercialista","consulente fiscale","caf"]', FALSE),

('f24',
 '{"it":"Modello F24","en":"F24 Payment Form","fr":"Formulaire F24"}',
 '{"it":"Modello per il pagamento di imposte, contributi e premi","en":"Italian tax payment form"}',
 (SELECT id FROM settori_professionali WHERE codice='fiscale'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["f24","versamento","imposte","contributi","agenzia entrate"]',
 '["commercialista","consulente fiscale"]', FALSE),

('bilancio',
 '{"it":"Bilancio d''Esercizio","en":"Financial Statements","fr":"Bilan Comptable","de":"Jahresabschluss","es":"Balance de Ejercicio"}',
 '{"it":"Stato patrimoniale e conto economico dell''impresa","en":"Company balance sheet and income statement"}',
 (SELECT id FROM settori_professionali WHERE codice='fiscale'),
 NULL, '["bilancio","stato patrimoniale","conto economico","esercizio"]',
 '["commercialista","revisore contabile"]', FALSE),

('nota_spese',
 '{"it":"Nota Spese","en":"Expense Report","fr":"Note de Frais","de":"Spesenabrechnung","es":"Nota de Gastos"}',
 '{"it":"Riepilogo delle spese sostenute per conto dell''azienda","en":"Summary of business expenses incurred"}',
 (SELECT id FROM settori_professionali WHERE codice='fiscale'),
 NULL, '["nota spese","rimborso spese","spese aziendali","trasferta"]',
 '[]', TRUE),

-- Lavoro
('busta_paga',
 '{"it":"Busta Paga","en":"Payslip","fr":"Fiche de Paie","de":"Gehaltsabrechnung","es":"Nómina"}',
 '{"it":"Cedolino paga mensile del lavoratore dipendente","en":"Monthly salary statement"}',
 (SELECT id FROM settori_professionali WHERE codice='lavoro'),
 NULL, '["busta paga","cedolino","stipendio","retribuzione","netto","lordo"]',
 '[]', TRUE),

('contratto_lavoro',
 '{"it":"Contratto di Lavoro","en":"Employment Contract","fr":"Contrat de Travail","de":"Arbeitsvertrag","es":"Contrato de Trabajo"}',
 '{"it":"Accordo tra datore di lavoro e dipendente","en":"Agreement between employer and employee"}',
 (SELECT id FROM settori_professionali WHERE codice='lavoro'),
 NULL, '["contratto lavoro","rapporto lavoro","assunzione","mansione","ccnl"]',
 '[]', TRUE),

-- Sanitario
('referto_medico',
 '{"it":"Referto Medico","en":"Medical Report","fr":"Rapport Médical","de":"Ärztlicher Bericht","es":"Informe Médico"}',
 '{"it":"Documento rilasciato da un medico con esito di una visita o esame","en":"Document issued by a doctor with examination results"}',
 (SELECT id FROM settori_professionali WHERE codice='sanitario'),
 NULL, '["referto","visita medica","diagnosi","terapia","medico"]',
 '["medico","specialista"]', TRUE),

('prescrizione_medica',
 '{"it":"Ricetta Medica","en":"Prescription","fr":"Ordonnance","de":"Rezept","es":"Receta Médica"}',
 '{"it":"Prescrizione farmaceutica o di esami diagnostici","en":"Medical prescription for drugs or diagnostic tests"}',
 (SELECT id FROM settori_professionali WHERE codice='sanitario'),
 NULL, '["ricetta","prescrizione","farmaco","dosaggio","medico curante"]',
 '["medico","specialista"]', TRUE),

-- Casa
('contratto_affitto',
 '{"it":"Contratto di Locazione","en":"Rental Agreement","fr":"Bail Locatif","de":"Mietvertrag","es":"Contrato de Alquiler"}',
 '{"it":"Contratto tra locatore e conduttore per uso abitativo o commerciale","en":"Contract between landlord and tenant"}',
 (SELECT id FROM settori_professionali WHERE codice='casa'),
 NULL, '["affitto","locazione","contratto affitto","locatore","conduttore","canone"]',
 '["agente immobiliare"]', TRUE),

('atto_notarile',
 '{"it":"Rogito Notarile","en":"Notarial Deed","fr":"Acte Notarié","de":"Notarieller Akt","es":"Escritura Notarial"}',
 '{"it":"Atto pubblico redatto da un notaio per compravendita immobiliare o altro","en":"Public deed drafted by a notary"}',
 (SELECT id FROM settori_professionali WHERE codice='casa'),
 NULL, '["rogito","atto notarile","compravendita","notaio","ipoteca"]',
 '["notaio","agente immobiliare"]', TRUE),

-- Auto
('assicurazione_auto',
 '{"it":"Polizza RCA — Assicurazione Auto","en":"Car Insurance","fr":"Assurance Auto","de":"Kfz-Versicherung","es":"Seguro de Coche"}',
 '{"it":"Responsabilità civile auto obbligatoria per legge","en":"Mandatory car liability insurance"}',
 (SELECT id FROM settori_professionali WHERE codice='auto'),
 NULL, '["rca","assicurazione auto","polizza auto","attestato rischio","classe merito"]',
 '[]', FALSE),

('libretto_circolazione',
 '{"it":"Carta di Circolazione","en":"Vehicle Registration","fr":"Carte Grise","de":"Fahrzeugbrief","es":"Permiso de Circulación"}',
 '{"it":"Documento che certifica la registrazione del veicolo","en":"Document certifying vehicle registration"}',
 (SELECT id FROM settori_professionali WHERE codice='auto'),
 NULL, '["libretto circolazione","carta circolazione","targa","immatricolazione","telaio"]',
 '[]', FALSE),

-- Banca
('estratto_conto',
 '{"it":"Estratto Conto Bancario","en":"Bank Statement","fr":"Relevé de Compte","de":"Kontoauszug","es":"Extracto Bancario"}',
 '{"it":"Riepilogo movimenti del conto corrente","en":"Summary of bank account transactions"}',
 (SELECT id FROM settori_professionali WHERE codice='banca'),
 NULL, '["estratto conto","movimenti","saldo","banca","conto corrente","iban"]',
 '[]', TRUE),

('bonifico',
 '{"it":"Bonifico Bancario","en":"Bank Transfer","fr":"Virement Bancaire","de":"Banküberweisung","es":"Transferencia Bancaria"}',
 '{"it":"Ordine di pagamento tra conti correnti","en":"Payment order between bank accounts"}',
 (SELECT id FROM settori_professionali WHERE codice='banca'),
 NULL, '["bonifico","trasferimento","iban","sepa","beneficiario"]',
 '[]', TRUE)

ON CONFLICT DO NOTHING;

-- ============================================================
-- TRIGGER aggiornamento dispositivi
-- ============================================================
CREATE OR REPLACE FUNCTION aggiorna_timestamp_dispositivo()
RETURNS TRIGGER AS $$
BEGIN
    NEW.aggiornato_il = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_dispositivi_aggiornato
    BEFORE UPDATE ON dispositivi_utente
    FOR EACH ROW EXECUTE FUNCTION aggiorna_timestamp_dispositivo();
