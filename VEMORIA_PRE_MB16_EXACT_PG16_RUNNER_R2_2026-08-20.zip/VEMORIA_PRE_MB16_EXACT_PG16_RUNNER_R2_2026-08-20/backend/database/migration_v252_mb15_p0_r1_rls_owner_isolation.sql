-- MB15-P0-R1 — Capability snapshot owner RLS isolation
-- Purpose: enforce owner-scoped RLS on mb15_p0_capability_snapshots and ensure owner_id is NOT NULL.

-- Owner-private snapshots must never be unowned.
UPDATE mb15_p0_capability_snapshots SET owner_id = '00000000-0000-0000-0000-000000000000'::uuid WHERE owner_id IS NULL;

ALTER TABLE mb15_p0_capability_snapshots
    ALTER COLUMN owner_id SET NOT NULL;

-- Row-level security for owner-scoped snapshots.
ALTER TABLE mb15_p0_capability_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb15_p0_capability_snapshots FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb15_p0_capability_snapshots_owner_isolation ON mb15_p0_capability_snapshots;
CREATE POLICY mb15_p0_capability_snapshots_owner_isolation ON mb15_p0_capability_snapshots
    FOR ALL
    USING (owner_id = _rls_owner_uuid())
    WITH CHECK (owner_id = _rls_owner_uuid());
