-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V3.7 — Migration V18 — Metadata Engine
CREATE TABLE IF NOT EXISTS document_metadata (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id UUID NOT NULL,
    chiave       TEXT NOT NULL,
    valore       TEXT NOT NULL,
    origine      TEXT NOT NULL DEFAULT 'sistema',
    creato_il    TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (documento_id, chiave)
);
CREATE INDEX IF NOT EXISTS idx_metadata_documento ON document_metadata(documento_id);
CREATE INDEX IF NOT EXISTS idx_metadata_chiave    ON document_metadata(chiave);
CREATE INDEX IF NOT EXISTS idx_metadata_valore    ON document_metadata(valore);
