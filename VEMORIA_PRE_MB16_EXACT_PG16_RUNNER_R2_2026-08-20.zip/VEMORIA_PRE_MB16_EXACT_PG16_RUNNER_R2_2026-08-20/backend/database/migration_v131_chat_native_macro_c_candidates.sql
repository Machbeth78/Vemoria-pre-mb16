-- Vemoria — Migration V131: Chat Native Macro C candidate extraction + allegati
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
--
-- Scopo: introdurre lo stato candidato per messaggi/allegati chat senza
-- promuovere nulla a memoria canonica e senza costruire il Gruppo Coordinato.

ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS candidate_extraction_state TEXT NOT NULL DEFAULT 'CANDIDATE_ONLY_MACRO_C';
ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS candidate_extraction_summary JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS source_indexer_link_state TEXT NOT NULL DEFAULT 'SOURCE_INDEXER_CANDIDATE_LINK_ONLY';
ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS dedup_state TEXT NOT NULL DEFAULT 'DEDUP_CANDIDATE_NOT_MERGED';
ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS owner_confirmation_required BOOLEAN NOT NULL DEFAULT TRUE;

ALTER TABLE chat_messaggi DROP CONSTRAINT IF EXISTS chat_messaggi_candidate_extraction_state_check;
ALTER TABLE chat_messaggi ADD CONSTRAINT chat_messaggi_candidate_extraction_state_check CHECK (
    candidate_extraction_state IN ('NOT_ENABLED_MACRO_B','CANDIDATE_ONLY_MACRO_C')
);

ALTER TABLE chat_messaggi DROP CONSTRAINT IF EXISTS chat_messaggi_source_indexer_link_state_check;
ALTER TABLE chat_messaggi ADD CONSTRAINT chat_messaggi_source_indexer_link_state_check CHECK (
    source_indexer_link_state = 'SOURCE_INDEXER_CANDIDATE_LINK_ONLY'
);

ALTER TABLE chat_messaggi DROP CONSTRAINT IF EXISTS chat_messaggi_dedup_state_check;
ALTER TABLE chat_messaggi ADD CONSTRAINT chat_messaggi_dedup_state_check CHECK (
    dedup_state = 'DEDUP_CANDIDATE_NOT_MERGED'
);

ALTER TABLE chat_messaggi DROP CONSTRAINT IF EXISTS chat_messaggi_owner_confirmation_required_check;
ALTER TABLE chat_messaggi ADD CONSTRAINT chat_messaggi_owner_confirmation_required_check CHECK (
    owner_confirmation_required = TRUE
);

COMMENT ON COLUMN chat_messaggi.candidate_extraction_state IS
    'Macro C: extraction is candidate-only; candidate is not confirmed fact.';
COMMENT ON COLUMN chat_messaggi.candidate_extraction_summary IS
    'Macro C: optional candidate summary. No canonical memory promotion without owner confirmation.';
COMMENT ON COLUMN chat_messaggi.source_indexer_link_state IS
    'Macro C: chat attachment/message may link to Source Indexer only as candidate.';
COMMENT ON COLUMN chat_messaggi.dedup_state IS
    'Macro C: attachment SHA creates dedup candidate, not automatic merge.';
COMMENT ON COLUMN chat_messaggi.owner_confirmation_required IS
    'Macro C: owner confirmation required before persistence, timeline/practice link, memory promotion or proof.';
