-- Vemoria V79.2K — Operator / AI governance
CREATE TABLE IF NOT EXISTS operator_recommendation_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NULL,
    recommendation_type TEXT NOT NULL,
    risk_level TEXT NOT NULL DEFAULT 'low',
    subject_ref TEXT NULL,
    relation_ref TEXT NULL,
    rationale TEXT NULL,
    suggested_action TEXT NULL,
    user_decision TEXT NULL,
    requires_confirmation BOOLEAN NOT NULL DEFAULT TRUE,
    executed BOOLEAN NOT NULL DEFAULT FALSE,
    policy_version TEXT NOT NULL DEFAULT 'V79.2K',
    evidence_hash TEXT NOT NULL,
    metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_operator_recommendation_events_user_created ON operator_recommendation_events(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_operator_recommendation_events_risk ON operator_recommendation_events(risk_level, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS ux_operator_recommendation_events_hash ON operator_recommendation_events(evidence_hash);
