-- Vemoria Gate06 R1 - Self-Knowledge Atlas and anti-loss matrix
-- Static schema contract only. Runtime PostgreSQL execution not performed here.
-- The tables store product capability metadata and redacted user-facing explanation state.
-- They must not contain document content, secrets, keys, chat plaintext, photos, audio or adaptive profile values.

CREATE TABLE IF NOT EXISTS gate06_self_knowledge_atlas_snapshots (
    id TEXT PRIMARY KEY,
    atlas_version TEXT NOT NULL,
    source_catalog_version TEXT NOT NULL,
    source_runtime_status_version TEXT NOT NULL,
    function_count INTEGER NOT NULL CHECK (function_count = 92),
    satellite_count INTEGER NOT NULL CHECK (satellite_count >= 1),
    missing_declared_files_count INTEGER NOT NULL DEFAULT 0 CHECK (missing_declared_files_count >= 0),
    runtime_pass_claim_count INTEGER NOT NULL DEFAULT 0 CHECK (runtime_pass_claim_count = 0),
    summary_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    contains_secret BOOLEAN NOT NULL DEFAULT FALSE CHECK (contains_secret = FALSE),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_gate06_self_knowledge_atlas_version
    ON gate06_self_knowledge_atlas_snapshots(atlas_version);

CREATE TABLE IF NOT EXISTS gate06_self_knowledge_function_cards (
    vc_id TEXT PRIMARY KEY,
    atlas_version TEXT NOT NULL,
    name TEXT NOT NULL,
    area TEXT NOT NULL,
    satellite_family TEXT NOT NULL,
    integration_state TEXT NOT NULL,
    runtime_state TEXT NOT NULL,
    wiring_class TEXT NOT NULL,
    all_declared_files_present BOOLEAN NOT NULL DEFAULT FALSE,
    requires_explicit_confirmation BOOLEAN NOT NULL DEFAULT FALSE,
    can_claim_runtime_pass BOOLEAN NOT NULL DEFAULT FALSE CHECK (can_claim_runtime_pass = FALSE),
    must_not_overpromise BOOLEAN NOT NULL DEFAULT TRUE,
    permissions_likely_required JSONB NOT NULL DEFAULT '[]'::jsonb,
    prerequisites_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    explanation_contract_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    contains_secret BOOLEAN NOT NULL DEFAULT FALSE CHECK (contains_secret = FALSE),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_gate06_function_cards_atlas
        FOREIGN KEY(atlas_version) REFERENCES gate06_self_knowledge_atlas_snapshots(atlas_version)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_gate06_self_knowledge_function_area
    ON gate06_self_knowledge_function_cards(area, integration_state, runtime_state);

CREATE INDEX IF NOT EXISTS idx_gate06_self_knowledge_function_satellite
    ON gate06_self_knowledge_function_cards(satellite_family, integration_state);

CREATE TABLE IF NOT EXISTS gate06_self_knowledge_satellite_cards (
    satellite_id TEXT PRIMARY KEY,
    atlas_version TEXT NOT NULL,
    function_count INTEGER NOT NULL CHECK (function_count >= 1),
    vc_ids_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    runtime_disclaimer TEXT NOT NULL,
    canonical_inputs_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    canonical_outputs_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    must_not_do_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    contains_secret BOOLEAN NOT NULL DEFAULT FALSE CHECK (contains_secret = FALSE),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_gate06_satellite_cards_atlas
        FOREIGN KEY(atlas_version) REFERENCES gate06_self_knowledge_atlas_snapshots(atlas_version)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_gate06_self_knowledge_satellite_atlas
    ON gate06_self_knowledge_satellite_cards(atlas_version, satellite_id);
