-- VEMORA — Nucleo Memoria Operativa (shadow mode)
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo

CREATE TABLE IF NOT EXISTS nm_static_nodes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    node_type TEXT NOT NULL,
    canonical_label TEXT NOT NULL,
    aliases_json JSONB,
    stability_score DOUBLE PRECISION NOT NULL DEFAULT 0,
    first_seen_at TIMESTAMP NOT NULL DEFAULT NOW(),
    last_seen_at TIMESTAMP NOT NULL DEFAULT NOW(),
    source_signals_json JSONB,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (node_type, canonical_label)
);

CREATE TABLE IF NOT EXISTS nm_timeline_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_type TEXT NOT NULL,
    event_subtype TEXT,
    event_at TIMESTAMP NOT NULL,
    recorded_at TIMESTAMP NOT NULL DEFAULT NOW(),
    source_module TEXT NOT NULL,
    primary_document_id UUID NULL REFERENCES documenti(id) ON DELETE SET NULL,
    primary_entity_ref TEXT NULL,
    primary_dossier_id UUID NULL REFERENCES dossier(id) ON DELETE SET NULL,
    payload_json JSONB,
    confidence DOUBLE PRECISION NOT NULL DEFAULT 0,
    trace_id TEXT
);

CREATE TABLE IF NOT EXISTS nm_relations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    left_type TEXT NOT NULL,
    left_id TEXT NOT NULL,
    relation_type TEXT NOT NULL,
    right_type TEXT NOT NULL,
    right_id TEXT NOT NULL,
    state TEXT NOT NULL,
    score DOUBLE PRECISION NOT NULL DEFAULT 0,
    evidence_json JSONB,
    first_seen_at TIMESTAMP NOT NULL DEFAULT NOW(),
    last_seen_at TIMESTAMP NOT NULL DEFAULT NOW(),
    confirmed_at TIMESTAMP NULL
);

CREATE TABLE IF NOT EXISTS nm_session_context (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id TEXT,
    user_ref TEXT,
    device_ref TEXT,
    context_key TEXT NOT NULL,
    context_value_json JSONB,
    priority INTEGER NOT NULL DEFAULT 0,
    expires_at TIMESTAMP NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS nm_anchors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    anchor_type TEXT NOT NULL,
    anchor_label TEXT NOT NULL,
    strength TEXT NOT NULL,
    start_at TIMESTAMP NULL,
    end_at TIMESTAMP NULL,
    related_nodes_json JSONB,
    evidence_json JSONB,
    is_user_confirmed BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS nm_action_decisions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    action_type TEXT NOT NULL,
    target_type TEXT,
    target_id TEXT,
    decision TEXT NOT NULL,
    confidence DOUBLE PRECISION NOT NULL DEFAULT 0,
    candidate_gap DOUBLE PRECISION NOT NULL DEFAULT 0,
    reason_json JSONB,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_nm_timeline_event_at ON nm_timeline_events(event_at DESC);
CREATE INDEX IF NOT EXISTS idx_nm_timeline_source_module ON nm_timeline_events(source_module);
CREATE INDEX IF NOT EXISTS idx_nm_relations_left ON nm_relations(left_type, left_id);
CREATE INDEX IF NOT EXISTS idx_nm_relations_right ON nm_relations(right_type, right_id);
CREATE INDEX IF NOT EXISTS idx_nm_relations_state ON nm_relations(state);
CREATE INDEX IF NOT EXISTS idx_nm_session_context_session_id ON nm_session_context(session_id);
CREATE INDEX IF NOT EXISTS idx_nm_session_context_user_ref ON nm_session_context(user_ref);
CREATE INDEX IF NOT EXISTS idx_nm_static_nodes_type_label ON nm_static_nodes(node_type, canonical_label);
