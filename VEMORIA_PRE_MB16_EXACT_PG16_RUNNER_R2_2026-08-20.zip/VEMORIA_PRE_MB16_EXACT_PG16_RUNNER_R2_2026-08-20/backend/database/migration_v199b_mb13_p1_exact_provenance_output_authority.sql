-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
--
-- MB13-P1 R2 — v199b Exact provenance, output authority, text locations and materiality.
-- Forward-only, idempotent. Does not modify v196, v197, v198a, v198b or v199a.

BEGIN;

-- ----------------------------------------------------------------------------
-- Dedicated writer role for document revisions and diff output.
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p1_writer') THEN
        CREATE ROLE mb13_p1_writer NOLOGIN;
    END IF;
END
$$;

ALTER ROLE mb13_p1_writer BYPASSRLS;

-- Worker must be able to execute the writer-owned functions.
GRANT mb13_p1_writer TO mb13_p1_worker;

-- ----------------------------------------------------------------------------
-- Document revisions: unconditional UPDATE/DELETE guard.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_document_revision_immutable_guard()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'UPDATE' OR TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_update_or_delete_blocked';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_mb13_p1_document_revision_immutable_guard ON public.mb13_p1_document_revision;
CREATE TRIGGER trg_mb13_p1_document_revision_immutable_guard
    BEFORE UPDATE OR DELETE ON public.mb13_p1_document_revision
    FOR EACH STATEMENT
    EXECUTE FUNCTION public.mb13_p1_document_revision_immutable_guard();

-- Only the writer role (via SECURITY DEFINER function) may INSERT.
ALTER TABLE public.mb13_p1_document_revision OWNER TO mb13_p1_writer;

REVOKE ALL ON public.mb13_p1_document_revision FROM mb13_p1_api;
REVOKE ALL ON public.mb13_p1_document_revision FROM mb13_p1_app;
REVOKE ALL ON public.mb13_p1_document_revision FROM mb13_p1_executor;
REVOKE ALL ON public.mb13_p1_document_revision FROM PUBLIC;

GRANT SELECT ON public.mb13_p1_document_revision TO mb13_p1_api;

-- ----------------------------------------------------------------------------
-- Authoritative document revision append (writer-owned, server-side hash).
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_append_document_revision(
    p_owner_user_id UUID,
    p_document_id UUID,
    p_revision INTEGER,
    p_state TEXT,
    p_payload_hash TEXT,
    p_dati_strutturati JSONB,
    p_testo_grezzo TEXT,
    p_supersedes_revision INTEGER DEFAULT NULL,
    p_expected_previous_hash TEXT DEFAULT NULL
) RETURNS UUID AS $$
DECLARE
    v_last_revision INTEGER;
    v_last_hash TEXT;
    v_doc_owner UUID;
    v_revision_id UUID := gen_random_uuid();
    v_expected_hash TEXT;
BEGIN
    IF p_state NOT IN ('memorizzato','revoked','superseded') THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_state_invalid';
    END IF;

    IF p_revision < 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_invalid';
    END IF;

    SELECT proprietario_id INTO v_doc_owner
      FROM public.documenti
     WHERE id = p_document_id
       AND proprietario_id = p_owner_user_id
     FOR SHARE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_document_not_found_or_owner_mismatch';
    END IF;

    v_expected_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'document_id', p_document_id,
        'revision', p_revision,
        'state', p_state,
        'dati_strutturati', COALESCE(p_dati_strutturati, '{}'::jsonb),
        'testo_grezzo', COALESCE(p_testo_grezzo, ''),
        'supersedes_revision', p_supersedes_revision
    ));

    IF p_revision > 1 THEN
        SELECT revision, payload_hash INTO v_last_revision, v_last_hash
          FROM public.mb13_p1_document_revision
         WHERE owner_user_id = p_owner_user_id
           AND document_id = p_document_id
         ORDER BY revision DESC
         LIMIT 1
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p1_document_revision_skipped';
        END IF;
        IF p_supersedes_revision IS DISTINCT FROM v_last_revision THEN
            RAISE EXCEPTION 'mb13_p1_document_revision_supersedes_mismatch';
        END IF;
        IF p_expected_previous_hash IS DISTINCT FROM v_last_hash THEN
            RAISE EXCEPTION 'mb13_p1_document_revision_previous_hash_mismatch';
        END IF;
        IF p_revision <> v_last_revision + 1 THEN
            RAISE EXCEPTION 'mb13_p1_document_revision_not_monotonic';
        END IF;
    END IF;

    IF EXISTS (
        SELECT 1 FROM public.mb13_p1_document_revision
         WHERE owner_user_id = p_owner_user_id
           AND document_id = p_document_id
           AND revision = p_revision
    ) THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_already_exists';
    END IF;

    INSERT INTO public.mb13_p1_document_revision (
        owner_user_id, document_id, revision, state, payload_hash,
        dati_strutturati, testo_grezzo, supersedes_revision, created_at
    ) VALUES (
        p_owner_user_id, p_document_id, p_revision, p_state, v_expected_hash,
        p_dati_strutturati, p_testo_grezzo, p_supersedes_revision, NOW()
    )
    RETURNING revision_id INTO v_revision_id;

    RETURN v_revision_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER, TEXT) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER, TEXT) TO mb13_p1_writer;

-- ----------------------------------------------------------------------------
-- Preflight state: bind exact provenance token fields.
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p1_preflight_state
    ADD COLUMN IF NOT EXISTS monitor_revision INTEGER,
    ADD COLUMN IF NOT EXISTS baseline_ref JSONB,
    ADD COLUMN IF NOT EXISTS request_hash TEXT;

-- ----------------------------------------------------------------------------
-- Authoritative single-relation provenance resolver.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_resolve_exact_provenance(
    p_owner UUID,
    p_source_refs JSONB,
    p_evidence_refs JSONB
) RETURNS TABLE(
    source_id UUID,
    source_card_id TEXT,
    source_revision_id UUID,
    evidence_id UUID,
    grant_id UUID,
    source_status TEXT,
    evidence_status TEXT,
    grant_status TEXT,
    binding_status TEXT,
    inventory_state TEXT,
    content_hash TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        s.id,
        b.source_card_id,
        i.id,
        e.id,
        g.id,
        s.status,
        'active'::text,
        g.status,
        b.status,
        i.identity_state,
        i.content_hash
    FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) AS sr
    LEFT JOIN public.authorized_memory_sources s
           ON s.id = NULLIF((sr->>'source_id')::text, '')::UUID
          AND s.user_id = p_owner
    LEFT JOIN public.mb12_p0_source_card_binding b
           ON b.source_card_id = NULLIF(sr->>'source_card_id', '')
          AND b.owner_user_id = p_owner
    LEFT JOIN public.authorized_memory_inventory_items i
           ON i.id = NULLIF((sr->>'source_revision_id')::text, '')::UUID
          AND i.user_id = p_owner
    LEFT JOIN public.authorized_memory_activity_log e
           ON e.id = NULLIF((sr->>'evidence_id')::text, '')::UUID
          AND e.user_id = p_owner
    LEFT JOIN public.authorized_memory_consent_grants g
           ON g.id = NULLIF((sr->>'grant_id')::text, '')::UUID
          AND g.user_id = p_owner;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) TO mb13_p1_writer;

-- ----------------------------------------------------------------------------
-- Preflight: lock authoritative rows and store the exact provenance token.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_preflight(UUID, JSONB, TEXT);
CREATE OR REPLACE FUNCTION public.mb13_p1_preflight(
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT
) RETURNS UUID AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_baseline_source_refs JSONB;
    v_baseline_evidence_refs JSONB;
    v_observation_source_refs JSONB;
    v_observation_evidence_refs JSONB;
    v_baseline_rev INTEGER;
    v_observation_rev INTEGER;
    v_preflight_id UUID := gen_random_uuid();
    v_request_hash TEXT;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object'
       OR p_observation_ref->>'id' IS NULL
       OR p_observation_ref->>'revision' IS NULL
       OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
        RAISE EXCEPTION 'mb13_p1_target_owner_mismatch';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;

    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_monitor_id::text, 0));

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = v_owner
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_found';
    END IF;
    IF v_current.monitor_state <> 'active' THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;

    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, v_current.target_ref);
    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, p_observation_ref);

    IF (v_current.target_ref->>'id') IS DISTINCT FROM (p_observation_ref->>'id') THEN
        RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
    END IF;

    v_baseline_rev := (v_current.target_ref->>'revision')::INTEGER;
    v_observation_rev := (p_observation_ref->>'revision')::INTEGER;

    IF v_observation_rev < v_baseline_rev THEN
        RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
    END IF;

    IF v_observation_rev = v_baseline_rev THEN
        IF (v_current.target_ref->>'payload_hash') IS DISTINCT FROM (p_observation_ref->>'payload_hash')
           OR (v_current.target_ref->>'state') IS DISTINCT FROM (p_observation_ref->>'state') THEN
            RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
        END IF;
    END IF;

    PERFORM public.mb13_p0_lock_and_verify_consents(
        v_owner, v_current.consent_refs, v_current.target_type, v_current.target_ref,
        p_required => TRUE, p_strict_relation => FALSE
    );
    PERFORM public.mb13_p0_lock_and_verify_consents(
        v_owner, v_current.consent_refs, v_current.target_type, p_observation_ref,
        p_required => TRUE, p_strict_relation => FALSE
    );

    SELECT source_refs, evidence_refs INTO v_baseline_source_refs, v_baseline_evidence_refs
      FROM public.mb13_p0_get_target_provenance(v_owner, v_current.target_type, v_current.target_ref);
    SELECT source_refs, evidence_refs INTO v_observation_source_refs, v_observation_evidence_refs
      FROM public.mb13_p0_get_target_provenance(v_owner, v_current.target_type, p_observation_ref);

    -- Authoritative single-relation lock and verification.
    PERFORM public.mb13_p1_verify_exact_provenance(v_owner, v_baseline_source_refs, v_baseline_evidence_refs);
    PERFORM public.mb13_p1_verify_exact_provenance(v_owner, v_observation_source_refs, v_observation_evidence_refs);

    PERFORM *
      FROM public.mb13_p1_resolve_exact_provenance(v_owner, v_baseline_source_refs, v_baseline_evidence_refs) r
     WHERE r.source_status = 'active'
        AND (r.grant_status IS NULL OR r.grant_status = 'active')
        AND (r.grant_id IS NULL OR (
            SELECT c.expires_at
              FROM public.authorized_memory_consent_grants c
             WHERE c.id = r.grant_id
        ) IS NULL OR (
            SELECT c.expires_at
              FROM public.authorized_memory_consent_grants c
             WHERE c.id = r.grant_id
        ) > NOW())
        AND (r.binding_status IS NULL OR r.binding_status = 'active')
        AND (r.inventory_state IS NULL OR r.inventory_state <> 'revoked')
      FOR SHARE;

    PERFORM *
      FROM public.mb13_p1_resolve_exact_provenance(v_owner, v_observation_source_refs, v_observation_evidence_refs) r
     WHERE r.source_status = 'active'
        AND (r.grant_status IS NULL OR r.grant_status = 'active')
        AND (r.grant_id IS NULL OR (
            SELECT c.expires_at
              FROM public.authorized_memory_consent_grants c
             WHERE c.id = r.grant_id
        ) IS NULL OR (
            SELECT c.expires_at
              FROM public.authorized_memory_consent_grants c
             WHERE c.id = r.grant_id
        ) > NOW())
        AND (r.binding_status IS NULL OR r.binding_status = 'active')
        AND (r.inventory_state IS NULL OR r.inventory_state <> 'revoked')
      FOR SHARE;

    -- Empty or unrelated provenance fails for targets that require provenance.
    IF v_current.target_type NOT IN ('document') THEN
        IF jsonb_array_length(COALESCE(v_baseline_source_refs, '[]'::jsonb)) = 0
           AND jsonb_array_length(COALESCE(v_baseline_evidence_refs, '[]'::jsonb)) = 0 THEN
            RAISE EXCEPTION 'mb13_p1_baseline_provenance_empty';
        END IF;
        IF jsonb_array_length(COALESCE(v_observation_source_refs, '[]'::jsonb)) = 0
           AND jsonb_array_length(COALESCE(v_observation_evidence_refs, '[]'::jsonb)) = 0 THEN
            RAISE EXCEPTION 'mb13_p1_observation_provenance_empty';
        END IF;
    END IF;

    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'baseline_ref', v_current.target_ref,
        'observation_ref', p_observation_ref,
        'diff_kind', p_diff_kind,
        'baseline_source_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs), '[]'::jsonb),
        'baseline_evidence_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs), '[]'::jsonb),
        'observation_source_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_source_refs), '[]'::jsonb),
        'observation_evidence_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_evidence_refs), '[]'::jsonb),
        'consent_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_current.consent_refs), '[]'::jsonb)
    ));

    INSERT INTO public.mb13_p1_preflight_state (
        preflight_id, owner_user_id, monitor_id, observation_ref, diff_kind,
        baseline_source_refs, baseline_evidence_refs,
        observation_source_refs, observation_evidence_refs,
        consent_refs, monitor_revision, baseline_ref, request_hash
    ) VALUES (
        v_preflight_id, v_owner, p_monitor_id, p_observation_ref, p_diff_kind,
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_source_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_evidence_refs), '[]'::jsonb),
        public.mb13_p0_normalize_jsonb_array(v_current.consent_refs),
        v_current.current_revision,
        v_current.target_ref,
        v_request_hash
    );

    RETURN v_preflight_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) TO mb13_p1_writer;

-- ----------------------------------------------------------------------------
-- Writer with worker-result envelope verification.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB);
CREATE OR REPLACE FUNCTION public.mb13_p1_write_diff(
    p_preflight_id UUID,
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT,
    p_changes JSONB,
    p_change_count INTEGER,
    p_material_change_count INTEGER,
    p_diff_state TEXT,
    p_summary TEXT,
    p_algorithm_version TEXT,
    p_normalization_version TEXT,
    p_request_payload JSONB,
    p_result_payload JSONB,
    p_worker_result_envelope JSONB DEFAULT NULL
) RETURNS TABLE(diff_id UUID, revision INTEGER, content_hash TEXT, diff_state TEXT, change_count INTEGER, material_change_count INTEGER, summary TEXT, changes JSONB) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_preflight public.mb13_p1_preflight_state%ROWTYPE;
    v_baseline_source_refs JSONB;
    v_baseline_evidence_refs JSONB;
    v_observation_source_refs JSONB;
    v_observation_evidence_refs JSONB;
    v_canonical_consent_refs JSONB;
    v_canonical_changes JSONB;
    v_change_count INTEGER;
    v_material_change_count INTEGER;
    v_diff_state TEXT;
    v_summary TEXT;
    v_content_hash TEXT;
    v_input_hash TEXT;
    v_output_hash TEXT;
    v_envelope_input_hash TEXT;
    v_envelope_output_hash TEXT;
    v_existing_diff_id UUID;
    v_existing_revision INTEGER;
    v_diff_id UUID;
    v_revision INTEGER := 1;
    v_event_type TEXT;
    v_event_id UUID;
    v_event_time TIMESTAMPTZ := NOW();
    v_event_payload_hash TEXT;
    v_event_result_payload JSONB;
    v_expected_algorithm TEXT;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_preflight_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_preflight_required';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'id' IS NULL OR p_observation_ref->>'revision' IS NULL OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;

    v_expected_algorithm := CASE p_diff_kind
        WHEN 'structured' THEN 'mb13-p1-r2-structured'
        WHEN 'text' THEN 'mb13-p1-r2-text'
    END;

    IF p_algorithm_version IS NULL OR p_algorithm_version <> v_expected_algorithm THEN
        RAISE EXCEPTION 'mb13_p1_algorithm_version_invalid';
    END IF;
    IF p_normalization_version IS NULL OR p_normalization_version <> 'mb13-p1-r2' THEN
        RAISE EXCEPTION 'mb13_p1_normalization_version_invalid';
    END IF;

    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_monitor_id::text, 0));

    SELECT * INTO v_preflight
      FROM public.mb13_p1_preflight_state
     WHERE preflight_id = p_preflight_id
       AND owner_user_id = v_owner
       AND monitor_id = p_monitor_id
       AND used = FALSE
       AND expires_at > NOW()
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_preflight_invalid_or_expired';
    END IF;

    IF v_preflight.observation_ref IS DISTINCT FROM p_observation_ref
       OR v_preflight.diff_kind IS DISTINCT FROM p_diff_kind THEN
        RAISE EXCEPTION 'mb13_p1_preflight_mismatch';
    END IF;

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = v_owner
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_found';
    END IF;
    IF v_current.monitor_state <> 'active' THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;
    IF v_preflight.monitor_revision IS DISTINCT FROM v_current.current_revision THEN
        RAISE EXCEPTION 'mb13_p1_monitor_revision_changed_between_preflight_and_write';
    END IF;
    IF v_preflight.baseline_ref IS DISTINCT FROM v_current.target_ref THEN
        RAISE EXCEPTION 'mb13_p1_baseline_changed_between_preflight_and_write';
    END IF;

    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, v_current.target_ref);
    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, p_observation_ref);

    UPDATE public.mb13_p1_preflight_state
       SET used = TRUE
     WHERE preflight_id = p_preflight_id;

    v_baseline_source_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.baseline_source_refs);
    v_baseline_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.baseline_evidence_refs);
    v_observation_source_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.observation_source_refs);
    v_observation_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.observation_evidence_refs);
    v_canonical_consent_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.consent_refs);

    v_canonical_changes := public.mb13_p0_normalize_jsonb_array(p_changes);
    v_change_count := jsonb_array_length(v_canonical_changes);

    SELECT COUNT(*) INTO v_material_change_count
      FROM jsonb_array_elements(v_canonical_changes) AS c
     WHERE (c.value->>'materiality') = 'POTENTIALLY_MATERIAL';

    IF v_change_count = 0 THEN
        v_diff_state := 'no_change';
    ELSE
        SELECT CASE WHEN EXISTS (
            SELECT 1 FROM jsonb_array_elements(v_canonical_changes) c
             WHERE (c.value->>'change_type') = 'AMBIGUOUS'
        ) THEN 'ambiguous' ELSE 'computed' END INTO v_diff_state;
    END IF;

    v_summary := CASE WHEN v_change_count = 0
        THEN 'No changes detected'
        ELSE format('Detected %s change(s), %s material', v_change_count, v_material_change_count)
    END;

    IF p_change_count IS DISTINCT FROM v_change_count THEN
        RAISE EXCEPTION 'mb13_p1_change_count_mismatch';
    END IF;
    IF p_material_change_count IS DISTINCT FROM v_material_change_count THEN
        RAISE EXCEPTION 'mb13_p1_material_change_count_mismatch';
    END IF;
    IF p_diff_state IS DISTINCT FROM v_diff_state THEN
        RAISE EXCEPTION 'mb13_p1_diff_state_mismatch';
    END IF;
    IF p_summary IS DISTINCT FROM v_summary THEN
        RAISE EXCEPTION 'mb13_p1_summary_mismatch';
    END IF;

    v_content_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'baseline_ref', v_current.target_ref,
        'observation_ref', p_observation_ref,
        'diff_kind', p_diff_kind,
        'changes', v_canonical_changes,
        'algorithm_version', p_algorithm_version,
        'normalization_version', p_normalization_version,
        'source_refs', public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs),
        'evidence_refs', public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs),
        'consent_refs', v_canonical_consent_refs
    ));

    -- Server-side provenance replaces any client-supplied source/evidence refs in changes.
    v_canonical_changes := COALESCE((
        SELECT jsonb_agg(
            jsonb_set(
                jsonb_set(c.value, '{source_refs}', COALESCE(v_baseline_source_refs, '[]'::jsonb) || COALESCE(v_observation_source_refs, '[]'::jsonb)),
                '{evidence_refs}', COALESCE(v_baseline_evidence_refs, '[]'::jsonb) || COALESCE(v_observation_evidence_refs, '[]'::jsonb)
            )
        )
        FROM jsonb_array_elements(v_canonical_changes) c
    ), '[]'::jsonb);

    -- Envelope verification.
    IF p_worker_result_envelope IS NOT NULL THEN
        v_envelope_input_hash := p_worker_result_envelope->>'input_hash';
        v_envelope_output_hash := p_worker_result_envelope->>'output_hash';

        v_input_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'monitor_revision', v_current.current_revision,
            'baseline_ref', v_current.target_ref,
            'observation_ref', p_observation_ref,
            'baseline_source_refs', v_baseline_source_refs,
            'baseline_evidence_refs', v_baseline_evidence_refs,
            'observation_source_refs', v_observation_source_refs,
            'observation_evidence_refs', v_observation_evidence_refs,
            'consent_refs', v_canonical_consent_refs,
            'request_hash', v_preflight.request_hash,
            'algorithm_version', p_algorithm_version,
            'normalization_version', p_normalization_version
        ));

        v_output_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'changes', v_canonical_changes,
            'change_count', v_change_count,
            'material_change_count', v_material_change_count,
            'diff_state', v_diff_state,
            'summary', v_summary
        ));

        IF v_input_hash IS DISTINCT FROM v_envelope_input_hash THEN
            RAISE EXCEPTION 'mb13_p1_worker_envelope_input_hash_mismatch';
        END IF;
        IF v_output_hash IS DISTINCT FROM v_envelope_output_hash THEN
            RAISE EXCEPTION 'mb13_p1_worker_envelope_output_hash_mismatch';
        END IF;

        IF EXISTS (
            SELECT 1 FROM public.mb13_p1_universal_diff d
             WHERE d.owner_user_id = v_owner
               AND d.content_hash = v_content_hash
               AND d.diff_id <> COALESCE((p_worker_result_envelope->>'diff_id')::UUID, v_diff_id)
        ) THEN
            RAISE EXCEPTION 'mb13_p1_worker_envelope_replay_detected';
        END IF;
    END IF;

    -- Idempotency: same canonical inputs yield the same identity.
    SELECT d.diff_id, d.current_revision
      INTO v_existing_diff_id, v_existing_revision
      FROM public.mb13_p1_universal_diff d
     WHERE d.owner_user_id = v_owner
       AND d.content_hash = v_content_hash
     LIMIT 1;

    IF FOUND THEN
        RETURN QUERY SELECT v_existing_diff_id, v_existing_revision, v_content_hash, v_diff_state, v_change_count, v_material_change_count, v_summary, v_canonical_changes;
        RETURN;
    END IF;

    v_diff_id := gen_random_uuid();

    v_event_result_payload := COALESCE(p_result_payload, '{}'::jsonb) || jsonb_build_object(
        'diff_id', v_diff_id,
        'diff_revision', v_revision,
        'diff_content_hash', v_content_hash,
        'diff_kind', p_diff_kind,
        'diff_state', v_diff_state,
        'change_count', v_change_count,
        'material_change_count', v_material_change_count,
        'no_auto_action', true,
        'no_auto_notification', true,
        'baseline_source_refs', v_baseline_source_refs,
        'baseline_evidence_refs', v_baseline_evidence_refs,
        'observation_source_refs', v_observation_source_refs,
        'observation_evidence_refs', v_observation_evidence_refs,
        'effective_consent_refs', v_canonical_consent_refs
    );

    INSERT INTO public.mb13_p1_universal_diff (
        owner_user_id, diff_id, monitor_id, monitor_revision, baseline_ref, observation_ref,
        diff_kind, diff_state, summary, change_count, material_change_count, changes,
        source_refs, evidence_refs, consent_refs, algorithm_version, normalization_version,
        payload_hash, content_hash, current_revision, request_payload, result_payload
    ) VALUES (
        v_owner, v_diff_id, p_monitor_id, v_current.current_revision, v_current.target_ref, p_observation_ref,
        p_diff_kind, v_diff_state, v_summary, v_change_count, v_material_change_count, v_canonical_changes,
        public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs),
        public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs),
        v_canonical_consent_refs,
        p_algorithm_version, p_normalization_version,
        v_content_hash, v_content_hash, v_revision, COALESCE(p_request_payload, '{}'::jsonb), v_event_result_payload
    );

    INSERT INTO public.mb13_p1_universal_diff_revision (
        owner_user_id, diff_id, revision, monitor_revision, baseline_ref, observation_ref,
        diff_kind, diff_state, summary, change_count, material_change_count, changes,
        source_refs, evidence_refs, consent_refs, algorithm_version, normalization_version,
        payload_hash, content_hash, request_payload, result_payload
    ) VALUES (
        v_owner, v_diff_id, v_revision, v_current.current_revision, v_current.target_ref, p_observation_ref,
        p_diff_kind, v_diff_state, v_summary, v_change_count, v_material_change_count, v_canonical_changes,
        public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs),
        public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs),
        v_canonical_consent_refs,
        p_algorithm_version, p_normalization_version,
        v_content_hash, v_content_hash, COALESCE(p_request_payload, '{}'::jsonb), v_event_result_payload
    );

    IF v_diff_state = 'no_change' THEN
        v_event_type := 'NO_CHANGE_RECORDED';
    ELSE
        v_event_type := 'CHANGE_CANDIDATE_RECORDED';
    END IF;

    v_event_id := gen_random_uuid();
    v_event_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'event_id', v_event_id,
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'event_type', v_event_type,
        'event_status', 'recorded',
        'event_time', to_jsonb(v_event_time),
        'observed_ref', p_observation_ref,
        'source_refs', public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs),
        'evidence_refs', public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs),
        'consent_refs', v_canonical_consent_refs,
        'reason', NULL,
        'result_payload', v_event_result_payload
    ));

    INSERT INTO public.mb13_p0_monitor_event_ledger (
        event_id, owner_user_id, monitor_id, monitor_revision, event_type, event_status, event_time,
        observed_ref, source_refs, evidence_refs, consent_refs, reason, result_payload, payload_hash
    ) VALUES (
        v_event_id, v_owner, p_monitor_id, v_current.current_revision, v_event_type, 'recorded', v_event_time,
        p_observation_ref,
        public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs),
        public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs),
        v_canonical_consent_refs, NULL, v_event_result_payload, v_event_payload_hash
    );

    RETURN QUERY SELECT v_diff_id, v_revision, v_content_hash, v_diff_state, v_change_count, v_material_change_count, v_summary, v_canonical_changes;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) TO mb13_p1_writer;

-- ----------------------------------------------------------------------------
-- Grant worker access to the new writer-owned functions.
-- ----------------------------------------------------------------------------
GRANT EXECUTE ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) TO mb13_p1_worker;
GRANT EXECUTE ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) TO mb13_p1_worker;
GRANT EXECUTE ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER, TEXT) TO mb13_p1_worker;

-- Ensure old executor-owned signatures are no longer reachable by API/app.
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) FROM mb13_p1_app;
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) FROM mb13_p1_api;
REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) FROM mb13_p1_app;
REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) FROM mb13_p1_api;

-- ----------------------------------------------------------------------------
-- Writer role privileges for authoritative diff output and payload reads.
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p1_universal_diff OWNER TO mb13_p1_writer;
ALTER TABLE public.mb13_p1_universal_diff_revision OWNER TO mb13_p1_writer;
ALTER TABLE public.mb13_p1_preflight_state OWNER TO mb13_p1_writer;

GRANT USAGE ON SCHEMA public TO mb13_p1_writer;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO mb13_p1_writer;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p1_universal_diff TO mb13_p1_writer;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p1_universal_diff_revision TO mb13_p1_writer;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p1_preflight_state TO mb13_p1_writer;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p1_document_revision TO mb13_p1_writer;

GRANT SELECT, UPDATE ON public.mb13_p0_monitor_target TO mb13_p1_writer;
GRANT SELECT, INSERT ON public.mb13_p0_monitor_event_ledger TO mb13_p1_writer;

GRANT SELECT ON public.documenti TO mb13_p1_writer;
GRANT SELECT ON public.mb12_p1_offer_contract_revision TO mb13_p1_writer;
GRANT SELECT ON public.mb12_p4_governed_explainable_ranking_revision TO mb13_p1_writer;
GRANT SELECT ON public.authorized_memory_consent_grants TO mb13_p1_writer;
GRANT SELECT ON public.authorized_memory_sources TO mb13_p1_writer;
GRANT SELECT ON public.authorized_memory_inventory_items TO mb13_p1_writer;
GRANT SELECT ON public.authorized_memory_activity_log TO mb13_p1_writer;
GRANT SELECT ON public.mb12_p0_source_card_binding TO mb13_p1_writer;

GRANT EXECUTE ON FUNCTION public.mb13_p1_resolve_target(UUID, TEXT, JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN, BOOLEAN) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_verify_exact_provenance(UUID, JSONB, JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p0_hash_jsonb(JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p0_normalize_jsonb_array(JSONB) TO mb13_p1_writer;

-- Legacy executor-owned verifier still needs to read memory tables.
GRANT SELECT ON public.authorized_memory_sources TO mb13_p1_executor;
GRANT SELECT ON public.authorized_memory_inventory_items TO mb13_p1_executor;
GRANT SELECT ON public.authorized_memory_activity_log TO mb13_p1_executor;
GRANT SELECT ON public.authorized_memory_consent_grants TO mb13_p1_executor;
GRANT SELECT ON public.mb12_p0_source_card_binding TO mb13_p1_executor;

-- Executor-owned resolver still needs to read authoritative tables after ownership moved to writer.
-- FOR SHARE/FOR UPDATE require UPDATE privilege in addition to SELECT.
GRANT SELECT, UPDATE ON public.mb13_p1_document_revision TO mb13_p1_executor;
GRANT SELECT, UPDATE ON public.documenti TO mb13_p1_executor;
GRANT SELECT, UPDATE ON public.mb12_p1_offer_contract TO mb13_p1_executor;
GRANT SELECT, UPDATE ON public.mb12_p1_offer_contract_revision TO mb13_p1_executor;
GRANT SELECT, UPDATE ON public.mb12_p4_governed_explainable_ranking TO mb13_p1_executor;
GRANT SELECT, UPDATE ON public.mb12_p4_governed_explainable_ranking_revision TO mb13_p1_executor;

COMMIT;
