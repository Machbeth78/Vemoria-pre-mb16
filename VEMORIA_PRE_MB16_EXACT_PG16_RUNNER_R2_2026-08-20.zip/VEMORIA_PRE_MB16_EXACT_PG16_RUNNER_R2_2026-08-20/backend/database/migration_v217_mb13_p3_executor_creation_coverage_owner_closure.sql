-- VEMORA MB13-P3 v217 — Executor identity, mandatory idempotency, explicit step coverage, owner-scoped helper
-- Non modificare MB13-P1/MB13-P2. Non aprire R3. Non produrre APK/AAB.

BEGIN;

-- ----------------------------------------------------------------------------
-- 1. Backfill and harden idempotency_key for action packs
-- ----------------------------------------------------------------------------
UPDATE public.mb13_p3_action_pack
   SET idempotency_key = 'legacy-pack-' || pack_id::text
 WHERE idempotency_key IS NULL OR length(trim(idempotency_key)) = 0;

ALTER TABLE public.mb13_p3_action_pack_revision DISABLE TRIGGER trg_mb13_p3_revision_immutable;
UPDATE public.mb13_p3_action_pack_revision
   SET idempotency_key = 'legacy-rev-' || revision_id::text
 WHERE idempotency_key IS NULL OR length(trim(idempotency_key)) = 0;
ALTER TABLE public.mb13_p3_action_pack_revision ENABLE TRIGGER trg_mb13_p3_revision_immutable;

ALTER TABLE public.mb13_p3_action_pack
    ALTER COLUMN idempotency_key SET NOT NULL;
ALTER TABLE public.mb13_p3_action_pack
    DROP CONSTRAINT IF EXISTS ck_mb13_p3_pack_idempotency_key;
ALTER TABLE public.mb13_p3_action_pack
    ADD CONSTRAINT ck_mb13_p3_pack_idempotency_key CHECK (length(trim(idempotency_key)) > 0);

ALTER TABLE public.mb13_p3_action_pack_revision
    ALTER COLUMN idempotency_key SET NOT NULL;

DROP INDEX IF EXISTS ix_mb13_p3_pack_idempotency;
CREATE UNIQUE INDEX IF NOT EXISTS ix_mb13_p3_pack_idempotency
    ON public.mb13_p3_action_pack(owner_user_id, idempotency_key);

-- ----------------------------------------------------------------------------
-- 2. Owner-scoped helper for monitor policy hash
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_get_monitor_policy_hash(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_monitor_revision INTEGER
) RETURNS TEXT AS $$
DECLARE
    v_session_owner TEXT := NULLIF(current_setting('app.owner_id', true), '');
    v_policy JSONB;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id::text IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT monitor_policy INTO v_policy
      FROM public.mb13_p0_monitor_target_revision
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = p_monitor_id
       AND revision = p_monitor_revision;
    IF FOUND THEN
        RETURN public.mb13_p0_hash_jsonb(v_policy);
    END IF;

    SELECT monitor_policy INTO v_policy
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = p_monitor_id
       AND current_revision = p_monitor_revision;
    IF FOUND THEN
        RETURN public.mb13_p0_hash_jsonb(v_policy);
    END IF;

    RETURN NULL;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_get_monitor_policy_hash(UUID, UUID, INTEGER) OWNER TO postgres;
REVOKE ALL ON FUNCTION public.mb13_p3_get_monitor_policy_hash(UUID, UUID, INTEGER) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p3_get_monitor_policy_hash(UUID, UUID, INTEGER) FROM mb13_p3_api;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_monitor_policy_hash(UUID, UUID, INTEGER) TO mb13_p3_writer, mb13_p3_validator, mb13_p3_executor;

-- ----------------------------------------------------------------------------
-- 3. Ensure policy-hash trigger binds the owner GUC before calling helper
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_monitor_policy_hash()
RETURNS TRIGGER AS $$
DECLARE
    v_policy_hash TEXT;
BEGIN
    IF TG_OP = 'INSERT' OR NEW.monitor_revision IS DISTINCT FROM OLD.monitor_revision THEN
        PERFORM set_config('app.owner_id', NEW.owner_user_id::text, true);
        v_policy_hash := public.mb13_p3_get_monitor_policy_hash(NEW.owner_user_id, NEW.monitor_id, NEW.monitor_revision);
        IF v_policy_hash IS NULL THEN
            NEW.monitor_policy_hash := public.mb13_p0_hash_jsonb(jsonb_build_object('provenance_unverified', NEW.monitor_revision));
            NEW.provenance_state := 'unverified';
        ELSE
            NEW.monitor_policy_hash := v_policy_hash;
            NEW.provenance_state := 'verified';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 4. Evidence payload canonicalizer: explicit covered_steps, no autofill
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_canonicalize_evidence_payload(
    p_pack public.mb13_p3_action_pack,
    p_evidence_type TEXT,
    p_evidence_payload JSONB
) RETURNS JSONB AS $$
DECLARE
    v_schema_version TEXT;
    v_status TEXT;
    v_details JSONB;
    v_action_result JSONB;
    v_required_action_type TEXT;
    v_pack_target_hash TEXT;
    v_target_ref_hash TEXT;
    v_step JSONB;
    v_step_number INTEGER;
    v_covered_steps JSONB;
    v_seen INTEGER[];
    v_n INTEGER;
    v_element TEXT;
    v_step_target_hash TEXT;
    v_failure_code TEXT;
    v_failed_step INTEGER;
    v_allowed_statuses TEXT[];
    v_pack_step_count INTEGER;
BEGIN
    IF p_evidence_payload IS NULL OR jsonb_typeof(p_evidence_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_payload_invalid';
    END IF;
    IF p_evidence_payload = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_payload_empty';
    END IF;

    v_schema_version := NULLIF(p_evidence_payload->>'schema_version', '');
    IF v_schema_version IS DISTINCT FROM 'mb13-p3-evidence/v1' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_schema_version_not_allowed';
    END IF;

    v_status := NULLIF(p_evidence_payload->>'status', '');
    IF v_status IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_evidence_status_required';
    END IF;

    v_details := p_evidence_payload->'details';
    IF v_details IS NULL OR jsonb_typeof(v_details) <> 'object' OR v_details = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_details_required';
    END IF;

    v_action_result := p_evidence_payload->'action_result';
    IF v_action_result IS NULL OR jsonb_typeof(v_action_result) <> 'object' OR v_action_result = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_action_result_required';
    END IF;
    IF v_action_result ? 'status' AND v_action_result->>'status' IS DISTINCT FROM v_status THEN
        RAISE EXCEPTION 'mb13_p3_evidence_action_result_status_mismatch';
    END IF;
    IF NOT (v_action_result ? 'status') THEN
        v_action_result := v_action_result || jsonb_build_object('status', v_status);
    END IF;

    v_pack_target_hash := public.mb13_p0_hash_jsonb(COALESCE(p_pack.target_ref, '{}'::jsonb));

    IF p_evidence_type = 'simulation_receipt' AND p_pack.action_type IS DISTINCT FROM 'simulate' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_type_action_mismatch';
    END IF;
    IF p_evidence_type = 'internal_action_receipt' AND p_pack.action_type IS DISTINCT FROM 'internal' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_type_action_mismatch';
    END IF;

    v_required_action_type := COALESCE(NULLIF(p_evidence_payload->>'action_type', ''), p_pack.action_type);

    v_pack_step_count := COALESCE(jsonb_array_length(COALESCE(p_pack.steps, '[]'::jsonb)), 0);

    IF p_evidence_type = 'step_result' THEN
        IF NOT (p_evidence_payload ? 'step_number') THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_required_for_step_result';
        END IF;
        BEGIN
            v_step_number := NULLIF(p_evidence_payload->>'step_number', '')::INTEGER;
        EXCEPTION WHEN OTHERS THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_invalid';
        END;
        IF v_step_number IS NULL OR v_step_number <= 0 THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_invalid';
        END IF;

        SELECT s INTO v_step
          FROM jsonb_array_elements(COALESCE(p_pack.steps, '[]'::jsonb)) s
         WHERE NULLIF(s->>'step_number', '')::INTEGER = v_step_number
         LIMIT 1;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_not_found';
        END IF;
        IF v_step ? 'action_type' AND v_step->>'action_type' IS DISTINCT FROM p_pack.action_type THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_action_type_mismatch';
        END IF;
        IF v_required_action_type IS DISTINCT FROM COALESCE(v_step->>'action_type', p_pack.action_type) THEN
            RAISE EXCEPTION 'mb13_p3_evidence_payload_action_type_mismatch';
        END IF;

        v_step_target_hash := public.mb13_p0_hash_jsonb(COALESCE(v_step->'target_ref', '{}'::jsonb));
        IF p_evidence_payload ? 'target_ref_hash' AND p_evidence_payload->>'target_ref_hash' IS DISTINCT FROM v_step_target_hash THEN
            RAISE EXCEPTION 'mb13_p3_evidence_target_ref_hash_mismatch';
        END IF;
        v_target_ref_hash := v_step_target_hash;

        v_allowed_statuses := ARRAY['ok','completed','failed','skipped'];
        v_covered_steps := COALESCE(p_evidence_payload->'covered_steps', '[]'::jsonb);
        IF jsonb_typeof(v_covered_steps) <> 'array' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_steps_invalid';
        END IF;
        v_covered_steps := jsonb_build_array(v_step_number);
    ELSIF p_evidence_type IN ('simulation_receipt','internal_action_receipt') THEN
        v_allowed_statuses := ARRAY['ok','completed','partial','failed'];
        IF v_required_action_type IS DISTINCT FROM p_pack.action_type THEN
            RAISE EXCEPTION 'mb13_p3_evidence_payload_action_type_mismatch';
        END IF;
        IF p_evidence_payload ? 'target_ref_hash' AND p_evidence_payload->>'target_ref_hash' IS DISTINCT FROM v_pack_target_hash THEN
            RAISE EXCEPTION 'mb13_p3_evidence_target_ref_hash_mismatch';
        END IF;
        v_target_ref_hash := v_pack_target_hash;

        IF v_pack_step_count > 0 THEN
            IF NOT (p_evidence_payload ? 'covered_steps') THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_steps_required';
            END IF;
        END IF;

        IF NOT (p_evidence_payload ? 'covered_steps') THEN
            v_covered_steps := '[]'::jsonb;
        ELSE
            v_covered_steps := p_evidence_payload->'covered_steps';
            IF v_covered_steps IS NULL OR jsonb_typeof(v_covered_steps) IS NULL OR jsonb_typeof(v_covered_steps) <> 'array' THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_steps_invalid';
            END IF;
        END IF;

        v_seen := ARRAY[]::INTEGER[];
        FOR v_element IN SELECT jsonb_array_elements_text(v_covered_steps) LOOP
            BEGIN
                v_n := NULLIF(v_element, '')::INTEGER;
            EXCEPTION WHEN OTHERS THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
            END;
            IF v_n IS NULL OR v_n <= 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
            END IF;
            IF v_n = ANY(COALESCE(v_seen, ARRAY[]::INTEGER[])) THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_duplicate';
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM jsonb_array_elements(COALESCE(p_pack.steps, '[]'::jsonb)) s
                WHERE NULLIF(s->>'step_number', '')::INTEGER = v_n
            ) THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_not_found';
            END IF;
            v_seen := array_append(v_seen, v_n);
        END LOOP;
        v_covered_steps := to_jsonb(v_seen);
    ELSIF p_evidence_type = 'failure_receipt' THEN
        v_allowed_statuses := ARRAY['failed'];
        IF v_status IS DISTINCT FROM 'failed' THEN
            RAISE EXCEPTION 'mb13_p3_failure_receipt_status_must_be_failed';
        END IF;

        v_failure_code := NULLIF(p_evidence_payload->>'failure_code', '');
        IF v_failure_code IS NULL THEN
            RAISE EXCEPTION 'mb13_p3_failure_receipt_code_required';
        END IF;
        IF v_details IS NULL OR v_details = '{}'::jsonb THEN
            RAISE EXCEPTION 'mb13_p3_failure_receipt_details_required';
        END IF;
        IF v_required_action_type IS DISTINCT FROM p_pack.action_type THEN
            RAISE EXCEPTION 'mb13_p3_evidence_payload_action_type_mismatch';
        END IF;
        IF p_evidence_payload ? 'target_ref_hash' AND p_evidence_payload->>'target_ref_hash' IS DISTINCT FROM v_pack_target_hash THEN
            RAISE EXCEPTION 'mb13_p3_evidence_target_ref_hash_mismatch';
        END IF;
        v_target_ref_hash := v_pack_target_hash;

        v_failed_step := NULLIF(p_evidence_payload->>'failed_step', '')::INTEGER;
        IF v_failed_step IS NOT NULL THEN
            IF NOT EXISTS (
                SELECT 1 FROM jsonb_array_elements(COALESCE(p_pack.steps, '[]'::jsonb)) s
                WHERE NULLIF(s->>'step_number', '')::INTEGER = v_failed_step
            ) THEN
                RAISE EXCEPTION 'mb13_p3_failure_receipt_step_not_found';
            END IF;
        END IF;

        IF NOT (p_evidence_payload ? 'covered_steps') THEN
            IF v_failed_step IS NOT NULL THEN
                v_covered_steps := jsonb_build_array(v_failed_step);
            ELSE
                v_covered_steps := '[]'::jsonb;
            END IF;
        ELSE
            v_covered_steps := p_evidence_payload->'covered_steps';
            IF v_covered_steps IS NULL OR jsonb_typeof(v_covered_steps) IS NULL OR jsonb_typeof(v_covered_steps) <> 'array' THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_steps_invalid';
            END IF;
        END IF;
        v_seen := ARRAY[]::INTEGER[];
        FOR v_element IN SELECT jsonb_array_elements_text(v_covered_steps) LOOP
            BEGIN
                v_n := NULLIF(v_element, '')::INTEGER;
            EXCEPTION WHEN OTHERS THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
            END;
            IF v_n IS NULL OR v_n <= 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
            END IF;
            IF v_n = ANY(COALESCE(v_seen, ARRAY[]::INTEGER[])) THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_duplicate';
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM jsonb_array_elements(COALESCE(p_pack.steps, '[]'::jsonb)) s
                WHERE NULLIF(s->>'step_number', '')::INTEGER = v_n
            ) THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_not_found';
            END IF;
            v_seen := array_append(v_seen, v_n);
        END LOOP;
        v_covered_steps := to_jsonb(v_seen);
    ELSE
        RAISE EXCEPTION 'mb13_p3_evidence_type_not_allowed';
    END IF;

    IF NOT (v_status = ANY (v_allowed_statuses)) THEN
        RAISE EXCEPTION 'mb13_p3_evidence_status_not_allowed_for_type';
    END IF;

    RETURN p_evidence_payload
        || jsonb_build_object(
            'action_type', v_required_action_type,
            'target_ref_hash', v_target_ref_hash,
            'covered_steps', v_covered_steps,
            'action_result', v_action_result
        );
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_canonicalize_evidence_payload(public.mb13_p3_action_pack, TEXT, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_canonicalize_evidence_payload(public.mb13_p3_action_pack, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_canonicalize_evidence_payload(public.mb13_p3_action_pack, TEXT, JSONB) TO mb13_p3_writer, mb13_p3_executor;

-- ----------------------------------------------------------------------------
-- 5. Start: verify executor identity matches the claim
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_start_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_expected_pack_revision INTEGER
) RETURNS TABLE(
    attempt_id UUID,
    pack_id UUID,
    attempt_number INTEGER,
    status TEXT,
    started_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.executor_identity IS DISTINCT FROM session_user THEN
        RAISE EXCEPTION 'mb13_p3_executor_identity_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;

    IF v_pack.status NOT IN ('claimed','executing') OR v_attempt.status IS DISTINCT FROM 'claimed' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_claimed';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    PERFORM public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    UPDATE public.mb13_p3_action_pack_attempt
       SET status = 'executing',
           started_at = v_now
     WHERE attempt_id = p_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = 'executing',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'started', 'claimed', 'executing',
        v_now, jsonb_build_object('attempt_id', p_attempt_id, 'attempt_number', v_attempt.attempt_number),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number, 'executing'::TEXT, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_start_action_pack(UUID, UUID, UUID, INTEGER) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_start_action_pack(UUID, UUID, UUID, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_start_action_pack(UUID, UUID, UUID, INTEGER) TO mb13_p3_executor;

-- ----------------------------------------------------------------------------
-- 6. Complete: verify executor identity matches the claim
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_complete_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_expected_pack_revision INTEGER,
    p_expected_attempt_number INTEGER,
    p_outcome TEXT,
    p_result_payload JSONB
) RETURNS TABLE(
    attempt_id UUID,
    pack_id UUID,
    attempt_number INTEGER,
    status TEXT,
    result_hash TEXT,
    completed_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_existing_result public.mb13_p3_action_pack_result%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_transition_monitor_revision INTEGER;
    v_transition_policy_hash TEXT;
    v_pack_policy_hash TEXT;
    v_result_hash TEXT;
    v_event_kind TEXT;
    v_old_status TEXT;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_canonical_evidence JSONB;
    v_evidence_payload JSONB;
    v_evidence_status TEXT;
    v_covered_steps JSONB;
    v_result_payload JSONB;
    v_status_allowed BOOLEAN;
    v_pack_step_numbers INTEGER[];
    v_covered INTEGER[];
    v_missing INTEGER;
    v_n INTEGER;
    v_element TEXT;
    v_step_consents JSONB := '[]'::jsonb;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_outcome NOT IN ('completed','partial','failed') THEN
        RAISE EXCEPTION 'mb13_p3_invalid_outcome';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.executor_identity IS DISTINCT FROM session_user THEN
        RAISE EXCEPTION 'mb13_p3_executor_identity_mismatch';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;
    IF v_attempt.attempt_number IS DISTINCT FROM p_expected_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.provenance_state IS DISTINCT FROM 'verified' THEN
        RAISE EXCEPTION 'mb13_p3_pack_provenance_unverified';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    IF p_result_payload IS NULL THEN
        v_result_payload := '{}'::jsonb;
    ELSE
        v_result_payload := p_result_payload;
    END IF;
    IF jsonb_typeof(v_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_payload_invalid';
    END IF;

    IF NOT (v_result_payload ? 'evidence') THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_required';
    END IF;

    IF v_result_payload ? 'outcome' THEN
        IF v_result_payload->>'outcome' IS DISTINCT FROM p_outcome THEN
            RAISE EXCEPTION 'mb13_p3_result_payload_outcome_mismatch';
        END IF;
    END IF;

    v_canonical_evidence := public.mb13_p3_canonicalize_result_evidence(p_owner_user_id, p_pack_id, p_attempt_id, v_result_payload);
    v_evidence_payload := v_canonical_evidence->'evidence_payload';
    v_evidence_status := v_evidence_payload->>'status';

    IF p_outcome = 'failed' THEN
        IF v_canonical_evidence->'evidence'->>'evidence_type' IS DISTINCT FROM 'failure_receipt' THEN
            RAISE EXCEPTION 'mb13_p3_result_failure_receipt_required';
        END IF;
    ELSE
        IF v_canonical_evidence->'evidence'->>'evidence_type' IS DISTINCT FROM 'failure_receipt' THEN
            v_status_allowed := false;
            IF p_outcome = 'completed' AND v_evidence_status IN ('ok','completed') THEN
                v_status_allowed := true;
            END IF;
            IF p_outcome = 'partial' AND v_evidence_status IN ('ok','completed','partial') THEN
                v_status_allowed := true;
            END IF;
            IF NOT v_status_allowed THEN
                RAISE EXCEPTION 'mb13_p3_evidence_status_incompatible_with_outcome';
            END IF;
        ELSE
            RAISE EXCEPTION 'mb13_p3_evidence_status_incompatible_with_outcome';
        END IF;
    END IF;

    v_covered_steps := v_evidence_payload->'covered_steps';
    IF v_covered_steps IS NULL OR jsonb_typeof(v_covered_steps) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_covered_steps_invalid';
    END IF;

    SELECT COALESCE(array_agg(NULLIF(s->>'step_number', '')::INTEGER ORDER BY NULLIF(s->>'step_number', '')::INTEGER), ARRAY[]::INTEGER[])
      INTO v_pack_step_numbers
      FROM jsonb_array_elements(COALESCE(v_pack.steps, '[]'::jsonb)) s;

    v_covered := ARRAY[]::INTEGER[];
    FOR v_element IN SELECT jsonb_array_elements_text(v_covered_steps) LOOP
        BEGIN
            v_n := NULLIF(v_element, '')::INTEGER;
        EXCEPTION WHEN OTHERS THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
        END;
        IF v_n IS NULL OR v_n <= 0 THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
        END IF;
        IF v_n = ANY(COALESCE(v_covered, ARRAY[]::INTEGER[])) THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_step_duplicate';
        END IF;
        IF NOT (v_n = ANY(v_pack_step_numbers)) THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_step_not_found';
        END IF;
        v_covered := array_append(v_covered, v_n);
    END LOOP;

    IF p_outcome = 'completed' THEN
        IF array_length(v_pack_step_numbers, 1) > 0 THEN
            IF array_length(v_covered, 1) IS NULL OR array_length(v_covered, 1) = 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_step_coverage_incomplete';
            END IF;
            FOREACH v_missing IN ARRAY v_pack_step_numbers LOOP
                IF NOT (v_missing = ANY(v_covered)) THEN
                    RAISE EXCEPTION 'mb13_p3_evidence_step_coverage_incomplete';
                END IF;
            END LOOP;
        ELSE
            IF array_length(v_covered, 1) > 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_step_coverage_incomplete';
            END IF;
        END IF;
    ELSIF p_outcome = 'partial' THEN
        IF array_length(v_pack_step_numbers, 1) > 0 THEN
            IF array_length(v_covered, 1) IS NULL OR array_length(v_covered, 1) = 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_partial_no_step_covered';
            END IF;
        ELSE
            IF array_length(v_covered, 1) > 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_partial_no_step_covered';
            END IF;
        END IF;
    END IF;

    v_result_payload := v_result_payload - 'evidence_hash' - 'evidence' - 'outcome' - 'evidence_payload';
    v_result_payload := v_result_payload || jsonb_build_object(
        'outcome', p_outcome,
        'evidence', v_canonical_evidence->'evidence',
        'evidence_hash', v_canonical_evidence->'evidence_hash',
        'evidence_payload', v_canonical_evidence->'evidence_payload'
    );

    SELECT * INTO v_existing_result
      FROM public.mb13_p3_action_pack_result
     WHERE attempt_id = p_attempt_id
       AND owner_user_id = p_owner_user_id;
    IF FOUND THEN
        IF v_existing_result.outcome IS DISTINCT FROM p_outcome THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
        IF v_existing_result.result_payload IS DISTINCT FROM v_result_payload THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
        RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                            p_outcome::TEXT, v_existing_result.result_hash, v_existing_result.created_at;
        RETURN;
    END IF;

    v_step_consents := public.mb13_p3_get_covered_step_consents(v_pack, v_evidence_payload);
    PERFORM public.mb13_p3_validate_source_grant_chain(
        p_owner_user_id, v_monitor, v_pack.consent_refs, v_pack.provenance_refs, v_step_consents
    );

    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    v_transition_monitor_revision := v_monitor.current_revision;
    v_transition_policy_hash := public.mb13_p0_hash_jsonb(COALESCE(v_monitor.monitor_policy, '{}'::jsonb));
    v_pack_policy_hash := v_pack.monitor_policy_hash;

    v_event_kind := p_outcome;
    v_old_status := v_pack.status;

    v_result_hash := public.mb13_p3_action_pack_result_hash(
        p_owner_user_id, p_pack_id, v_pack.pack_revision, p_attempt_id,
        v_attempt.attempt_number, p_outcome, v_attempt.executor_identity,
        v_result_payload, v_now
    );

    INSERT INTO public.mb13_p3_action_pack_result (
        owner_user_id, pack_id, attempt_id, attempt_number, outcome, executor_identity,
        result_payload, result_hash, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, v_attempt.attempt_number, p_outcome,
        v_attempt.executor_identity, v_result_payload, v_result_hash, v_now
    );

    UPDATE public.mb13_p3_action_pack_attempt
       SET result_payload = v_result_payload,
           result_hash = v_result_hash,
           completed_at = v_now
     WHERE attempt_id = p_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = p_outcome,
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, v_event_kind, v_old_status, p_outcome,
        v_now, jsonb_build_object(
            'attempt_id', p_attempt_id,
            'attempt_number', v_attempt.attempt_number,
            'result_hash', v_result_hash,
            'pack_monitor_revision', v_pack.monitor_revision,
            'pack_policy_hash', v_pack_policy_hash,
            'transition_monitor_revision', v_transition_monitor_revision,
            'transition_policy_hash', v_transition_policy_hash
        ),
        v_transition_monitor_revision, v_transition_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                        p_outcome::TEXT, v_result_hash, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) TO mb13_p3_executor;

-- ----------------------------------------------------------------------------
-- 7. Create action pack: mandatory idempotency_key, no fallback
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_create_action_pack(
    p_owner_user_id uuid,
    p_monitor_id uuid,
    p_trigger_event_id uuid,
    p_diff_result_id uuid,
    p_action_type text,
    p_target_ref jsonb,
    p_consent_refs jsonb,
    p_provenance_refs jsonb,
    p_steps jsonb,
    p_expires_at timestamp with time zone,
    p_idempotency_key text,
    p_initial_status text DEFAULT 'proposed'::text
) RETURNS TABLE(
    pack_id uuid,
    owner_user_id uuid,
    monitor_id uuid,
    monitor_revision integer,
    trigger_event_id uuid,
    diff_result_id uuid,
    pack_revision integer,
    payload_hash text,
    action_type text,
    target_ref jsonb,
    consent_refs jsonb,
    provenance_refs jsonb,
    steps jsonb,
    expires_at timestamp with time zone,
    idempotency_key text,
    status text,
    claimed_attempt_id uuid,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    monitor_policy_hash text,
    provenance_state text
) LANGUAGE plpgsql SECURITY DEFINER
SET search_path TO pg_catalog, public
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_existing public.mb13_p3_action_pack%ROWTYPE;
    v_pack_id UUID;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
    v_payload_hash TEXT;
    v_status TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_idempotency_key IS NULL OR length(trim(p_idempotency_key)) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_idempotency_key_required';
    END IF;

    -- Serialize concurrent creates with the same owner-scoped idempotency key.
    PERFORM pg_advisory_xact_lock(hashtextextended(p_owner_user_id::text || ':' || p_idempotency_key, 0));

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := COALESCE(public.mb13_p3_get_monitor_policy_hash(p_owner_user_id, p_monitor_id, v_monitor_revision), public.mb13_p0_hash_jsonb(v_monitor.monitor_policy));
    v_status := COALESCE(p_initial_status, 'proposed');

    IF v_status NOT IN ('draft','proposed','awaiting_confirmation') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_invalid_initial_status';
    END IF;

    IF p_action_type NOT IN ('simulate','internal') THEN
        RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
    END IF;

    PERFORM public.mb13_p3_validate_steps(p_owner_user_id, COALESCE(p_steps, '[]'::jsonb));

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, p_monitor_id, v_monitor_revision,
        p_trigger_event_id, p_diff_result_id
    );

    IF p_expires_at IS NOT NULL AND p_expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    SELECT * INTO v_existing
      FROM public.mb13_p3_action_pack
     WHERE owner_user_id = p_owner_user_id
       AND idempotency_key = p_idempotency_key;
    IF FOUND THEN
        v_payload_hash := public.mb13_p3_action_pack_payload_hash(
            p_owner_user_id, p_monitor_id, v_monitor_revision,
            p_trigger_event_id, p_diff_result_id, p_action_type,
            p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
            p_expires_at, p_idempotency_key, v_status
        );
        IF v_existing.payload_hash IS DISTINCT FROM v_payload_hash THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
        RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = v_existing.pack_id AND ap.owner_user_id = p_owner_user_id;
        RETURN;
    END IF;

    v_payload_hash := public.mb13_p3_action_pack_payload_hash(
        p_owner_user_id, p_monitor_id, v_monitor_revision,
        p_trigger_event_id, p_diff_result_id, p_action_type,
        p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
        p_expires_at, p_idempotency_key, v_status
    );

    INSERT INTO public.mb13_p3_action_pack (
        owner_user_id, monitor_id, monitor_revision, trigger_event_id, diff_result_id,
        pack_revision, payload_hash, action_type, target_ref, consent_refs, provenance_refs,
        steps, expires_at, idempotency_key, status, created_at, updated_at
    ) VALUES (
        p_owner_user_id, p_monitor_id, v_monitor_revision, p_trigger_event_id, p_diff_result_id,
        1, v_payload_hash, p_action_type, COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, p_idempotency_key, v_status, v_now, v_now
    ) RETURNING public.mb13_p3_action_pack.pack_id INTO v_pack_id;

    INSERT INTO public.mb13_p3_action_pack_revision (
        owner_user_id, pack_id, revision, monitor_revision, trigger_event_id, diff_result_id,
        payload_hash, action_type, target_ref, consent_refs, provenance_refs, steps,
        expires_at, idempotency_key, status, created_at
    ) VALUES (
        p_owner_user_id, v_pack_id, 1, v_monitor_revision, p_trigger_event_id, p_diff_result_id,
        v_payload_hash, p_action_type, COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, p_idempotency_key, v_status, v_now
    );

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_pack_id, p_monitor_id, 'pack_created', NULL, v_status,
        v_now, jsonb_build_object('pack_revision', 1),
        v_monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = v_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;

ALTER FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) TO mb13_p3_api;

COMMIT;
