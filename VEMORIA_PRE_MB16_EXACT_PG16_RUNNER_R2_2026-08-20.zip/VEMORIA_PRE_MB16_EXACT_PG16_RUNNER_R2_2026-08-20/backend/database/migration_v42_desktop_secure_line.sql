-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V42 — Desktop Secure Line / Device Contacts

CREATE TABLE IF NOT EXISTS desktop_secure_line_requests (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id               UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    requester_channel       TEXT NOT NULL DEFAULT 'mobile',
    requester_device_id     UUID REFERENCES desktop_devices(id) ON DELETE SET NULL,
    target_channel          TEXT NOT NULL DEFAULT 'desktop',
    target_device_id        UUID REFERENCES desktop_devices(id) ON DELETE SET NULL,
    request_kind            TEXT NOT NULL,
    requested_document_id   UUID REFERENCES documenti(id) ON DELETE SET NULL,
    requested_filename      TEXT,
    requested_query         TEXT,
    message                 TEXT,
    status                  TEXT NOT NULL DEFAULT 'pending',
    payload                 JSONB,
    fulfillment_queue_id    UUID REFERENCES desktop_import_queue(id) ON DELETE SET NULL,
    fulfillment_document_id UUID REFERENCES documenti(id) ON DELETE SET NULL,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    resolved_at             TIMESTAMP,
    expires_at              TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_secure_line_user          ON desktop_secure_line_requests(utente_id);
CREATE INDEX IF NOT EXISTS idx_secure_line_target_device ON desktop_secure_line_requests(target_device_id);
CREATE INDEX IF NOT EXISTS idx_secure_line_status        ON desktop_secure_line_requests(status);
CREATE INDEX IF NOT EXISTS idx_secure_line_created       ON desktop_secure_line_requests(created_at DESC);
