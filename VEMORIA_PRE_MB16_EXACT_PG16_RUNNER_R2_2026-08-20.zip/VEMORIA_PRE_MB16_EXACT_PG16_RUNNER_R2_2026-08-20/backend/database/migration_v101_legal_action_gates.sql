-- Vemoria V79.2K — Legal UX action gates
CREATE TABLE IF NOT EXISTS legal_action_gate_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NULL,
    action_type TEXT NOT NULL,
    area TEXT NOT NULL,
    content_ref TEXT NULL,
    document_ref TEXT NULL,
    recipient_ref TEXT NULL,
    risk_level TEXT NULL,
    gate_context JSONB NOT NULL DEFAULT '{}'::jsonb,
    registry_hash TEXT NOT NULL,
    event_hash TEXT NOT NULL,
    previous_event_hash TEXT NULL,
    evidence_version TEXT NOT NULL DEFAULT 'V79.2K',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_legal_action_gate_events_user_created ON legal_action_gate_events(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_legal_action_gate_events_content ON legal_action_gate_events(content_ref);
CREATE UNIQUE INDEX IF NOT EXISTS ux_legal_action_gate_events_hash ON legal_action_gate_events(event_hash);
