-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V90: handoff chat pubblica firma -> thread registrato

ALTER TABLE public_session_messages
    ADD COLUMN IF NOT EXISTS imported_at TIMESTAMPTZ;

ALTER TABLE public_session_messages
    ADD COLUMN IF NOT EXISTS imported_thread_id UUID;

ALTER TABLE public_session_messages
    ADD COLUMN IF NOT EXISTS imported_chat_message_id UUID;

CREATE INDEX IF NOT EXISTS idx_public_session_messages_imported_thread
    ON public_session_messages(imported_thread_id);

-- Nota: registrazione migration demandata al migration runner/registry service.
-- Se la migration viene applicata manualmente via SQL puro, usare poi adopt-existing o status nel runner.
