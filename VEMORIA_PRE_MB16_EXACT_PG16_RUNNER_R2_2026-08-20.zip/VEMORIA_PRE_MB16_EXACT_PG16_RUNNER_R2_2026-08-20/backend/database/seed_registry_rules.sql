-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Seed Registry Rules V34
-- Popola i campi regole in tipi_documento per i tipi principali.
-- Idempotente: UPDATE ... WHERE codice = ...
-- Eseguire dopo migration_v34.

-- ── MULTA / VERBALE ──────────────────────────────────────────────────────────
UPDATE tipi_documento SET
    campi_attesi = '{
        "numero_verbale": "Numero identificativo del verbale",
        "data_violazione": "Data in cui è avvenuta la violazione",
        "data_scadenza": "Data entro cui pagare senza maggiorazione",
        "importo_base": "Importo sanzione base",
        "importo_ridotto": "Importo con riduzione se pagamento entro 5gg",
        "targa": "Targa del veicolo coinvolto",
        "articolo_violato": "Articolo del codice della strada violato"
    }'::jsonb,
    campi_forti          = ARRAY['targa', 'numero_verbale', 'importo_base'],
    pattern_date         = '{
        "data_scadenza": ["pagare entro", "entro e non oltre", "scadenza", "termine pagamento"],
        "data_violazione": ["il giorno", "data della violazione", "accertata in data"]
    }'::jsonb,
    pattern_importo      = '{
        "importo_base": ["sanzione", "ammontare", "importo"],
        "importo_ridotto": ["ridotto", "se pagato entro 5", "pagamento entro"]
    }'::jsonb,
    pattern_identificativi = '{
        "numero_verbale": "\\\\b[A-Z]{1,3}[0-9]{5,9}\\\\b",
        "targa": "\\\\b[A-Z]{2}[0-9]{3}[A-Z]{2}\\\\b"
    }'::jsonb,
    regole_eventi        = '[{
        "tipo_evento": "PAGAMENTO",
        "campo_data": "data_scadenza",
        "campo_importo": "importo_base",
        "descrizione_template": "Scadenza multa {numero_verbale}: €{importo_base} entro {data_scadenza}"
    }]'::jsonb,
    priorita_ricerca     = 85,
    fonte                = 'seed',
    updated_at           = NOW()
WHERE codice IN ('multa_verbale', 'multa', 'verbale');

-- ── FATTURA ──────────────────────────────────────────────────────────────────
UPDATE tipi_documento SET
    campi_attesi = '{
        "numero_fattura": "Numero progressivo fattura",
        "data_fattura": "Data di emissione",
        "data_scadenza": "Data di pagamento",
        "importo_imponibile": "Imponibile IVA esclusa",
        "importo_iva": "Importo IVA",
        "importo_totale": "Totale da pagare IVA inclusa",
        "partita_iva_emittente": "P.IVA del fornitore",
        "numero_ordine": "Numero ordine di riferimento"
    }'::jsonb,
    campi_forti          = ARRAY['numero_fattura', 'partita_iva_emittente', 'importo_totale'],
    pattern_date         = '{
        "data_scadenza": ["scadenza pagamento", "pagare entro", "data pagamento", "bonifico entro"],
        "data_fattura": ["data fattura", "emessa il", "data emissione", "del"]
    }'::jsonb,
    pattern_importo      = '{
        "importo_totale": ["totale fattura", "totale da pagare", "importo totale", "totale ivato"],
        "importo_iva": ["iva", "imposta"]
    }'::jsonb,
    pattern_identificativi = '{
        "numero_fattura": "(?:fattura|n\\\\.)\\\\s*[A-Z0-9/\\\\-]{2,20}",
        "partita_iva_emittente": "(?:p\\\\.?iva|partita iva)\\\\s*:?\\\\s*([0-9]{11})"
    }'::jsonb,
    regole_eventi        = '[{
        "tipo_evento": "PAGAMENTO",
        "campo_data": "data_scadenza",
        "campo_importo": "importo_totale",
        "descrizione_template": "Pagamento fattura {numero_fattura}: €{importo_totale}"
    }]'::jsonb,
    priorita_ricerca     = 90,
    fonte                = 'seed',
    updated_at           = NOW()
WHERE codice = 'fattura';

-- ── VISITA SANITARIA / APPUNTAMENTO MEDICO ───────────────────────────────────
UPDATE tipi_documento SET
    campi_attesi = '{
        "data_appuntamento": "Data della visita",
        "ora_appuntamento": "Ora della visita",
        "struttura": "Nome ospedale / ambulatorio / studio",
        "medico": "Nome del medico / specialista",
        "tipo_visita": "Tipo di prestazione (visita, esame, ecc.)",
        "numero_prenotazione": "Codice prenotazione CUP o interno"
    }'::jsonb,
    campi_forti          = ARRAY['data_appuntamento', 'numero_prenotazione'],
    pattern_date         = '{
        "data_appuntamento": ["appuntamento", "prenotazione per", "visita il", "ore", "il giorno"]
    }'::jsonb,
    pattern_importo      = '{}'::jsonb,
    pattern_identificativi = '{
        "numero_prenotazione": "(?:prenotazione|codice|cup)\\\\s*[:#]?\\\\s*([A-Z0-9]{6,20})"
    }'::jsonb,
    regole_eventi        = '[{
        "tipo_evento": "APPUNTAMENTO",
        "campo_data": "data_appuntamento",
        "campo_importo": null,
        "descrizione_template": "Appuntamento medico: {tipo_visita} il {data_appuntamento}"
    }]'::jsonb,
    priorita_ricerca     = 80,
    fonte                = 'seed',
    updated_at           = NOW()
WHERE codice IN ('visita_sanitaria', 'referto_medico', 'appuntamento_medico');

-- ── CARTA D'IDENTITA ─────────────────────────────────────────────────────────
UPDATE tipi_documento SET
    campi_attesi = '{
        "numero_documento": "Numero carta d identità (es: CA12345AA)",
        "data_nascita": "Data di nascita del titolare",
        "data_rilascio": "Data di rilascio",
        "data_scadenza": "Data di scadenza",
        "codice_fiscale": "Codice fiscale del titolare",
        "comune_rilascio": "Comune che ha rilasciato il documento"
    }'::jsonb,
    campi_forti          = ARRAY['numero_documento', 'codice_fiscale', 'data_scadenza'],
    pattern_date         = '{
        "data_scadenza": ["scade il", "valida fino al", "scadenza"],
        "data_rilascio": ["rilasciata il", "data rilascio", "emessa il"]
    }'::jsonb,
    pattern_importo      = '{}'::jsonb,
    pattern_identificativi = '{
        "numero_documento": "[A-Z]{2}[0-9]{5}[A-Z]{2}|[A-Z][A-Z0-9]{8}",
        "codice_fiscale": "[A-Z]{6}[0-9]{2}[A-Z][0-9]{2}[A-Z][0-9]{3}[A-Z]"
    }'::jsonb,
    regole_eventi        = '[{
        "tipo_evento": "SCADENZA",
        "campo_data": "data_scadenza",
        "campo_importo": null,
        "descrizione_template": "Scadenza carta d identità {numero_documento}: {data_scadenza}"
    }]'::jsonb,
    priorita_ricerca     = 88,
    fonte                = 'seed',
    updated_at           = NOW()
WHERE codice IN ('carta_identita', 'documento_identita');

-- ── PATENTE DI GUIDA ─────────────────────────────────────────────────────────
UPDATE tipi_documento SET
    campi_attesi = '{
        "numero_patente": "Numero della patente",
        "categoria": "Categoria (A, B, C, ecc.)",
        "data_rilascio": "Data di rilascio",
        "data_scadenza": "Data di scadenza",
        "codice_fiscale": "Codice fiscale del titolare"
    }'::jsonb,
    campi_forti          = ARRAY['numero_patente', 'data_scadenza'],
    pattern_date         = '{
        "data_scadenza": ["scadenza", "valida fino", "scade il"],
        "data_rilascio": ["rilasciata", "data rilascio"]
    }'::jsonb,
    pattern_importo      = '{}'::jsonb,
    pattern_identificativi = '{
        "numero_patente": "[A-Z]{2}[0-9]{7}[A-Z]|[A-Z0-9]{9,12}"
    }'::jsonb,
    regole_eventi        = '[{
        "tipo_evento": "SCADENZA",
        "campo_data": "data_scadenza",
        "campo_importo": null,
        "descrizione_template": "Rinnovo patente {numero_patente}: scadenza {data_scadenza}"
    }]'::jsonb,
    priorita_ricerca     = 85,
    fonte                = 'seed',
    updated_at           = NOW()
WHERE codice IN ('patente', 'patente_guida');
