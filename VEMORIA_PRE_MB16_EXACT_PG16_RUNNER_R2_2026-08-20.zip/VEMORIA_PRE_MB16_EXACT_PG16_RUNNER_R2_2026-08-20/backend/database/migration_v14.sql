-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V3.3 — Migration V14 — Automation / Workflow Engine
CREATE TABLE IF NOT EXISTS automation_rule (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tipo_trigger TEXT NOT NULL,
    tipo_target  TEXT NOT NULL,
    condizione   JSONB,
    azione       TEXT NOT NULL,
    attiva       BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il    TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_rule_trigger ON automation_rule(tipo_trigger);
CREATE INDEX IF NOT EXISTS idx_rule_target  ON automation_rule(tipo_target);
CREATE INDEX IF NOT EXISTS idx_rule_attiva  ON automation_rule(attiva);

CREATE TABLE IF NOT EXISTS automation_event (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rule_id     UUID NOT NULL REFERENCES automation_rule(id) ON DELETE CASCADE,
    target_tipo TEXT NOT NULL,
    target_id   UUID NOT NULL,
    stato       TEXT NOT NULL DEFAULT 'eseguito',
    creato_il   TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_event_rule   ON automation_event(rule_id);
CREATE INDEX IF NOT EXISTS idx_event_target ON automation_event(target_id);
