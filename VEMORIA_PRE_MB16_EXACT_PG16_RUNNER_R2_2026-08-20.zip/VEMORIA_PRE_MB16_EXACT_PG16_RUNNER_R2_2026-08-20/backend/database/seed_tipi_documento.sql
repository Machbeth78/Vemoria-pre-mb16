-- ============================================================
-- VEMORA V4.5.1 — seed_tipi_documento.sql
-- Tassonomia documentale italiana estesa
-- ~270 tipi documento organizzati per macro-categoria
-- UPSERT idempotente — non rompe i 9 tipi esistenti
-- Copyright © 2026 Devoti Massimo
-- ============================================================

-- Requires migration_v25.sql (sottocategoria, parole_chiave, has_scadenza, macro_categoria)

INSERT INTO tipi_documento (codice, etichetta, categoria, macro_categoria, sottocategoria, parole_chiave, has_scadenza)
VALUES

-- ============================================================
-- A. IDENTITÀ PERSONALE
-- ============================================================
('carta_identita',          'Carta d''Identità',                    'identita',   'identita',   'documenti_riconoscimento',  ARRAY['carta identità','CI','documento riconoscimento','scadenza'],                 TRUE),
('passaporto',              'Passaporto',                           'identita',   'identita',   'documenti_riconoscimento',  ARRAY['passaporto','passport','espatrio','AIRE'],                                    TRUE),
('patente_guida',           'Patente di Guida',                     'identita',   'identita',   'documenti_guida',           ARRAY['patente','guida','A1','A2','B','BE','C','D','revisione'],                     TRUE),
('codice_fiscale',          'Tessera Codice Fiscale',               'identita',   'identita',   'documenti_riconoscimento',  ARRAY['codice fiscale','CF','tessera','Agenzia Entrate'],                           FALSE),
('tessera_sanitaria',       'Tessera Sanitaria / TEAM',             'identita',   'identita',   'documenti_sanitari',        ARRAY['tessera sanitaria','TEAM','europea','ASL','SSN'],                            TRUE),
('permesso_soggiorno',      'Permesso di Soggiorno',                'identita',   'identita',   'documenti_riconoscimento',  ARRAY['permesso soggiorno','straniero','questura','rinnovo'],                       TRUE),
('carta_soggiorno',         'Carta di Soggiorno / Lungo Residenza', 'identita',   'identita',   'documenti_riconoscimento',  ARRAY['carta soggiorno','lungo residenza','UE','prefettura'],                      TRUE),
('stato_famiglia',          'Stato di Famiglia',                    'identita',   'identita',   'anagrafe',                  ARRAY['stato famiglia','comune','nucleo familiare','anagrafe'],                    FALSE),
('certificato_nascita',     'Certificato di Nascita',               'identita',   'identita',   'anagrafe',                  ARRAY['nascita','certificato','comune','atto di nascita'],                         FALSE),
('certificato_residenza',   'Certificato di Residenza',             'identita',   'identita',   'anagrafe',                  ARRAY['residenza','comune','anagrafe','domicilio'],                                FALSE),
('certificato_cittadinanza','Certificato di Cittadinanza',          'identita',   'identita',   'anagrafe',                  ARRAY['cittadinanza','comune','italiana'],                                          FALSE),
('certificato_matrimonio',  'Certificato di Matrimonio',            'identita',   'identita',   'stato_civile',              ARRAY['matrimonio','sposi','comune','atto matrimonio'],                            FALSE),
('atto_nascita',            'Atto di Nascita',                      'identita',   'identita',   'stato_civile',              ARRAY['atto nascita','comune','registro stato civile'],                            FALSE),
('atto_morte',              'Atto di Morte',                        'identita',   'identita',   'stato_civile',              ARRAY['atto morte','decesso','comune','stato civile'],                             FALSE),
('atto_divorzio',           'Atto di Divorzio / Separazione',       'legale',     'identita',   'stato_civile',              ARRAY['divorzio','separazione','tribunale','sentenza'],                            FALSE),
('delega',                  'Delega / Procura Semplice',            'legale',     'identita',   'atti_personali',            ARRAY['delega','procura','rappresentanza','firma'],                                FALSE),
('autocertificazione',      'Autocertificazione',                   'identita',   'identita',   'dichiarazioni',             ARRAY['autocertificazione','DPR 445','dichiarazione sostitutiva'],                 FALSE),

-- ============================================================
-- B. LAVORO E REDDITO
-- ============================================================
('busta_paga',              'Busta Paga / Cedolino',                'lavoro',     'lavoro',       'redditi_dipendente',        ARRAY['busta paga','cedolino','stipendio','INPS','trattenute','RAL'],              FALSE),
('contratto_lavoro',        'Contratto di Lavoro',                  'lavoro',     'lavoro',       'contratti_lavoro',          ARRAY['contratto lavoro','assunzione','CCNL','indeterminato','determinato'],        FALSE),
('lettera_assunzione',      'Lettera di Assunzione',                'lavoro',     'lavoro',       'contratti_lavoro',          ARRAY['lettera assunzione','offerta lavoro','inquadramento'],                      FALSE),
('lettera_licenziamento',   'Lettera di Licenziamento',             'lavoro',     'lavoro',       'contratti_lavoro',          ARRAY['licenziamento','recesso','preavviso','TFR'],                                FALSE),
('dimissioni',              'Lettera di Dimissioni',                'lavoro',     'lavoro',       'contratti_lavoro',          ARRAY['dimissioni','volontarie','preavviso','resignazione'],                       FALSE),
('certificazione_unica',    'Certificazione Unica (CU)',            'fisco',      'lavoro',       'dichiarazione_fiscale',     ARRAY['CU','certificazione unica','sostituto imposta','730'],                      FALSE),
('modello_730',             'Modello 730',                          'fisco',      'lavoro',       'dichiarazione_fiscale',     ARRAY['730','dichiarazione redditi','dipendente','rimborso IRPEF'],                FALSE),
('modello_unico',           'Modello Redditi (ex Unico)',           'fisco',      'lavoro',       'dichiarazione_fiscale',     ARRAY['unico','redditi','partita IVA','persone fisiche'],                          FALSE),
('slip_tfr',                'Prospetto TFR',                        'lavoro',     'lavoro',       'redditi_dipendente',        ARRAY['TFR','trattamento fine rapporto','liquidazione','fondo'],                   FALSE),
('estratto_previdenziale',  'Estratto Conto Previdenziale INPS',    'lavoro',     'lavoro',       'lavoro',                ARRAY['INPS','estratto conto','contributi','pensione','fascicolo'],               FALSE),
('contributi_inps',         'Prospetto Contributi INPS',            'lavoro',     'lavoro',       'lavoro',                ARRAY['contributi','INPS','versamento','F24 INPS'],                                FALSE),
('iscrizione_albo',         'Iscrizione Albo / Ordine Professionale','lavoro',    'lavoro',       'professioni',               ARRAY['albo','ordine','iscrizione','professionista'],                              TRUE),
('nulla_osta_lavoro',       'Nulla Osta Lavoro',                    'lavoro',     'lavoro',       'contratti_lavoro',          ARRAY['nulla osta','lavoro','straniero','autorizzazione'],                         TRUE),
('libretto_lavoro',         'Libretto di Lavoro',                   'lavoro',     'lavoro',       'contratti_lavoro',          ARRAY['libretto lavoro','mansioni','storico'],                                     FALSE),
('attestazione_servizio',   'Attestazione di Servizio',             'lavoro',     'lavoro',       'dichiarazioni',             ARRAY['attestazione servizio','anzianità','datore lavoro'],                       FALSE),
('visura_camerale',         'Visura Camerale',                      'impresa',    'lavoro',       'documenti_impresa',         ARRAY['visura camerale','CCIAA','camera commercio','partita IVA','codice fiscale'],TRUE),
('certificato_carichi_pendenti','Certificato Carichi Pendenti',     'legale',     'lavoro',       'dichiarazioni',             ARRAY['carichi pendenti','casellario','penale','tribunale'],                       FALSE),

-- ============================================================
-- C. CASA E IMMOBILI
-- ============================================================
('contratto_affitto',       'Contratto di Locazione / Affitto',     'casa',       'casa',        'locazione',                 ARRAY['affitto','locazione','canone','inquilino','proprietario','cedolare'],       TRUE),
('atto_notarile',           'Atto Notarile',                        'legale',     'casa',        'compravendita',             ARRAY['atto notarile','rogito','notaio','trascrizione','ipoteca'],                 FALSE),
('rogito',                  'Rogito Notarile di Compravendita',     'legale',     'casa',        'compravendita',             ARRAY['rogito','compravendita','immobile','notaio','catasto'],                    FALSE),
('visura_catastale',        'Visura Catastale',                     'casa',       'casa',        'catasto',                   ARRAY['visura catastale','catasto','foglio','particella','rendita'],               FALSE),
('planimetria',             'Planimetria Catastale',                'casa',       'casa',        'catasto',                   ARRAY['planimetria','catasto','mappa','piantina','superficie'],                    FALSE),
('ape',                     'Attestato Prestazione Energetica (APE)','casa',      'casa',        'certificazioni_immobili',   ARRAY['APE','attestato energetico','classe energetica','certificazione'],          TRUE),
('permesso_costruire',      'Permesso di Costruire',                'casa',       'casa',        'cantiere_edilizia',                  ARRAY['permesso costruire','concessione','DIA','comune','urbanistica'],            TRUE),
('scia_edilizia',           'SCIA Edilizia',                        'casa',       'casa',        'cantiere_edilizia',                  ARRAY['SCIA','segnalazione inizio attività','cantiere_edilizia','comune'],                 FALSE),
('cila',                    'CILA - Comunicazione Inizio Lavori',   'casa',       'casa',        'cantiere_edilizia',                  ARRAY['CILA','comunicazione inizio lavori','manutenzione','comune'],              FALSE),
('agibilita',               'Certificato di Agibilità',             'casa',       'casa',        'certificazioni_immobili',   ARRAY['agibilità','abitabilità','comune','conformità'],                           FALSE),
('imu_tasi',                'Dichiarazione IMU / TASI',             'fisco',      'casa',        'tributi_immobiliari',       ARRAY['IMU','TASI','comune','imposta municipale','immobile'],                     FALSE),
('spese_condominio',        'Rendiconto Spese Condominiali',        'casa',       'casa',        'condominio',                ARRAY['spese condominio','rendiconto','amministratore','millesimi','preventivo'],  FALSE),
('verbale_assemblea',       'Verbale Assemblea Condominiale',       'casa',       'casa',        'condominio',                ARRAY['verbale assemblea','condominio','delibera','riunione'],                    FALSE),
('mutuo',                   'Contratto Mutuo Ipotecario',           'banca',      'casa',        'finanziamenti',             ARRAY['mutuo','ipoteca','banca','ammortamento','tasso','rata'],                   FALSE),
('piano_ammortamento',      'Piano di Ammortamento Mutuo',          'banca',      'casa',        'finanziamenti',             ARRAY['ammortamento','rate','mutuo','capitale','interessi','TAN','TAEG'],          FALSE),
('contratto_comodato',      'Contratto di Comodato d''Uso',         'legale',     'casa',        'locazione',                 ARRAY['comodato','uso gratuito','immobile','contratto'],                          FALSE),
('denuncia_inizio_attivita','DIA - Denuncia Inizio Attività',       'casa',       'casa',        'cantiere_edilizia',                  ARRAY['DIA','denuncia inizio attività','cantiere_edilizia'],                               FALSE),

-- ============================================================
-- D. FISCO E PAGAMENTI
-- ============================================================
('f24',                     'Modello F24',                          'fisco',      'fisco',      'tributi',                   ARRAY['F24','Agenzia Entrate','versamento','codice tributo','IRPEF','IVA'],         FALSE),
('f23',                     'Modello F23',                          'fisco',      'fisco',      'tributi',                   ARRAY['F23','concessioni governative','bollo','imposta registro'],                 FALSE),
('fattura',                 'Fattura',                              'finanziario','fisco',      'fatturazione',              ARRAY['fattura','IVA','imponibile','fornitore','numero fattura'],                  FALSE),
('fattura_acquisto',        'Fattura di Acquisto',                  'finanziario','fisco',      'fatturazione',              ARRAY['fattura acquisto','IVA','fornitore','spesa'],                              FALSE),
('fattura_vendita',         'Fattura di Vendita',                   'finanziario','fisco',      'fatturazione',              ARRAY['fattura vendita','cliente','ricavo','IVA'],                                FALSE),
('nota_credito',            'Nota di Credito',                      'finanziario','fisco',      'fatturazione',              ARRAY['nota credito','storno','rimborso','rettifica fattura'],                    FALSE),
('ricevuta',                'Ricevuta di Pagamento',                'finanziario','fisco',      'pagamenti',                 ARRAY['ricevuta','pagamento','quietanza','saldo'],                                FALSE),
('ricevuta_bonifico',       'Ricevuta Bonifico',                    'banca',      'fisco',      'pagamenti',                 ARRAY['bonifico','IBAN','causale','valuta','accredito'],                          FALSE),
('dichiarazione_redditi',   'Dichiarazione dei Redditi',            'fisco',      'fisco',      'dichiarazione_fiscale',     ARRAY['dichiarazione redditi','730','unico','IRPEF','quadro'],                    FALSE),
('avviso_accertamento',     'Avviso di Accertamento Fiscale',       'fisco',      'fisco',      'contenzioso_fiscale',       ARRAY['accertamento','Agenzia Entrate','rettifica','imposta','sanzione'],          TRUE),
('cartella_esattoriale',    'Cartella Esattoriale',                 'fisco',      'fisco',      'contenzioso_fiscale',       ARRAY['cartella','Equitalia','Agenzia Riscossione','debito','rateazione'],         TRUE),
('dichiarazione_iva',       'Dichiarazione IVA',                    'fisco',      'fisco',      'dichiarazione_fiscale',     ARRAY['IVA','dichiarazione','partita IVA','annuale','liquidazione'],              FALSE),
('modello_imu',             'Dichiarazione IMU',                    'fisco',      'fisco',      'tributi_immobiliari',       ARRAY['IMU','dichiarazione','comune','imposta municipale','F24'],                 FALSE),
('bollettino_postale',      'Bollettino Postale',                   'fisco',      'fisco',      'pagamenti',                 ARRAY['bollettino','postale','CCB','conto corrente','versamento'],                FALSE),
('quietanza',               'Quietanza di Pagamento',               'finanziario','fisco',      'pagamenti',                 ARRAY['quietanza','saldo','pagato','liberatoria'],                                FALSE),
('rimborso',                'Richiesta/Nota Rimborso',              'finanziario','fisco',      'rimborsi',                  ARRAY['rimborso','restituzione','accredito','nota spese'],                        FALSE),
('nota_spese',              'Nota Spese',                           'lavoro',     'fisco',      'rimborsi',                  ARRAY['nota spese','rimborso spese','trasferta','dipendente'],                    FALSE),
('spesometro',              'Comunicazione Spesometro',             'fisco',      'fisco',      'dichiarazione_fiscale',     ARRAY['spesometro','comunicazione IVA','operazioni rilevanti'],                   FALSE),
('esterometro',             'Esterometro',                          'fisco',      'fisco',      'dichiarazione_fiscale',     ARRAY['esterometro','operazioni estero','IVA','fattura estera'],                  FALSE),

-- ============================================================
-- E. BANCA E ASSICURAZIONI
-- ============================================================
('estratto_conto',          'Estratto Conto Bancario',              'banca',      'banca',  'conti_bancari',             ARRAY['estratto conto','saldo','movimenti','IBAN','banca'],                       FALSE),
('estratto_conto_bancario', 'Estratto Conto Bancario Dettagliato',  'banca',      'banca',  'conti_bancari',             ARRAY['estratto conto','movimenti bancari','accrediti','addebiti'],               FALSE),
('contratto_conto_corrente','Contratto Conto Corrente',             'banca',      'banca',  'conti_bancari',             ARRAY['conto corrente','contratto','banca','IBAN','apertura'],                    FALSE),
('carta_credito_estratto',  'Estratto Conto Carta di Credito',      'banca',      'banca',  'carte_credito',             ARRAY['carta credito','estratto','limite','rate','saldo'],                        FALSE),
('polizza_vita',            'Polizza Assicurativa Vita',            'assicurazioni','banca', 'polizze',                   ARRAY['polizza vita','assicurazione','premio','beneficiario','morte'],            TRUE),
('polizza_auto',            'Polizza RC Auto / Kasko',              'assicurazioni','banca', 'polizze',                   ARRAY['RC auto','polizza','targa','massimale','scadenza','bollo'],                TRUE),
('polizza_casa',            'Polizza Assicurativa Casa',            'assicurazioni','banca', 'polizze',                   ARRAY['polizza casa','incendio','furto','danni','responsabilità civile'],          TRUE),
('polizza_salute',          'Polizza Sanitaria / Salute',           'assicurazioni','banca', 'polizze',                   ARRAY['polizza salute','sanitaria','rimborso spese mediche','ticket'],             TRUE),
('polizza_infortuni',       'Polizza Infortuni',                    'assicurazioni','banca', 'polizze',                   ARRAY['polizza infortuni','invalidità','indennizzo','INA'],                       TRUE),
('polizza_viaggio',         'Assicurazione Viaggio',                'assicurazioni','banca', 'polizze',                   ARRAY['assicurazione viaggio','annullamento','emergenza medica','bagaglio'],       TRUE),
('sinistro',                'Denuncia Sinistro',                    'assicurazioni','banca', 'sinistri',                  ARRAY['sinistro','denuncia','danno','assicurazione','rimborso','perizia'],         FALSE),
('perizia_danno',           'Perizia Danno',                        'assicurazioni','banca', 'sinistri',                  ARRAY['perizia','danno','liquidazione','assicuratore','tecnico'],                 FALSE),
('attestato_rischio',       'Attestato di Rischio RC Auto',         'assicurazioni','banca', 'polizze',                   ARRAY['attestato rischio','classe','bonus malus','sinistri','RC auto'],           TRUE),
('fideiussione',            'Fideiussione Bancaria',                'banca',      'banca',  'garanzie',                  ARRAY['fideiussione','garanzia','banca','cauzione','locazione'],                  TRUE),
('bonifico',                'Bonifico Bancario',                    'banca',      'banca',  'transazioni',               ARRAY['bonifico','IBAN','causale','ordinante','beneficiario'],                    FALSE),
('rendiconto_fondo',        'Rendiconto Fondo Pensione',            'banca',      'banca',  'previdenza_complementare',  ARRAY['fondo pensione','rendiconto','posizione','rendimento','TFR'],              FALSE),

-- ============================================================
-- F. SALUTE
-- ============================================================
('referto_medico',          'Referto Medico / Visita',              'sanitario',  'salute',               'referti',                   ARRAY['referto','medico','visita','diagnosi','dottore','specialista'],             FALSE),
('prescrizione_medica',     'Ricetta Medica / Prescrizione',        'sanitario',  'salute',               'prescrizioni',              ARRAY['ricetta','prescrizione','farmaco','medico','SSN','bianca rossa'],           TRUE),
('analisi_cliniche',        'Esami del Sangue / Analisi',           'sanitario',  'salute',               'esami_diagnostici',         ARRAY['analisi','sangue','esami','laboratorio','referti','valori'],               FALSE),
('referto_radiologico',     'Referto Radiologico / Ecografia',      'sanitario',  'salute',               'esami_diagnostici',         ARRAY['radiologia','ecografia','TAC','RMN','radiografia','referto'],              FALSE),
('cartella_clinica',        'Cartella Clinica / Dimissione',        'sanitario',  'salute',               'ricoveri',                  ARRAY['cartella clinica','dimissione','ricovero','ospedale','diagnosi dimissione'], FALSE),
('verbale_pronto_soccorso', 'Verbale Pronto Soccorso',              'sanitario',  'salute',               'ricoveri',                  ARRAY['pronto soccorso','PS','verbale','triage','accesso'],                       FALSE),
('certificato_medico',      'Certificato Medico',                   'sanitario',  'salute',               'certificati_sanitari',      ARRAY['certificato medico','idoneità','malattia','inidoneità'],                   TRUE),
('certificato_invalidita',  'Certificato Invalidità / Disabilità',  'sanitario',  'salute',               'certificati_sanitari',      ARRAY['invalidità','disabilità','legge 104','INPS','percentuale','verbale INPS'],  TRUE),
('piano_terapeutico',       'Piano Terapeutico',                    'sanitario',  'salute',               'prescrizioni',              ARRAY['piano terapeutico','farmaco','specialista','SSN','esenzione'],              TRUE),
('esenzione_ticket',        'Esenzione Ticket Sanitario',           'sanitario',  'salute',               'prescrizioni',              ARRAY['esenzione','ticket','patologia','reddito','ASL','codice esenzione'],        TRUE),
('vaccinazione',            'Libretto / Certificato Vaccinazioni',  'sanitario',  'salute',               'certificati_sanitari',      ARRAY['vaccino','vaccinazione','libretto','certificato','green pass'],             TRUE),
('consenso_informato',      'Consenso Informato',                   'sanitario',  'salute',               'atti_sanitari',             ARRAY['consenso informato','intervento','firma','medico','trattamento'],          FALSE),
('dichiarazione_anticipata','Dichiarazione Anticipata di Trattamento (DAT)','legale','salute',            'atti_sanitari',             ARRAY['DAT','testamento biologico','biotestamento','disposizioni anticipate'],     FALSE),

-- ============================================================
-- G. AUTO E MOBILITÀ
-- ============================================================
('libretto_circolazione',   'Libretto di Circolazione',             'auto',       'veicoli',        'documenti_veicolo',         ARRAY['libretto','circolazione','targa','veicolo','intestatario'],                FALSE),
('carta_proprietà_auto',    'Carta di Proprietà del Veicolo',       'auto',       'veicoli',        'documenti_veicolo',         ARRAY['carta proprietà','veicolo','proprietario','PRA','ACI'],                   FALSE),
('bollo_auto',              'Bollo Auto / Tassa Automobilistica',   'fisco',      'veicoli',        'tributi_veicolo',           ARRAY['bollo auto','tassa automobilistica','scadenza','regione'],                 TRUE),
('revisione_auto',          'Verbale Revisione Veicolo',            'auto',       'veicoli',        'documenti_veicolo',         ARRAY['revisione','collaudo','ministeriale','scadenza','targa'],                  TRUE),
('assicurazione_auto',      'Contrassegno Assicurazione Auto',      'assicurazioni','veicoli',      'polizze',                   ARRAY['RC auto','assicurazione','targa','contraente','scadenza'],                  TRUE),
('multa',                   'Verbale di Accertamento (Multa)',       'legale',     'veicoli',        'sanzioni',                  ARRAY['multa','verbale','infrazione','CDS','sanzione','pagamento'],               TRUE),
('foglio_rosa',             'Foglio Rosa / Autorizzazione Guida',   'identita',   'veicoli',        'documenti_guida',           ARRAY['foglio rosa','guida accompagnata','scuola guida','esame'],                 TRUE),
('certificato_proprieta',   'Certificato di Proprietà Veicolo',     'auto',       'veicoli',        'documenti_veicolo',         ARRAY['certificato proprietà','veicolo','trascrizione','PRA'],                   FALSE),
('atto_vendita_auto',       'Atto di Vendita Veicolo',              'auto',       'veicoli',        'compravendita_veicolo',     ARRAY['vendita auto','passaggio proprietà','ACI','PRA','trasferimento'],          FALSE),
('collaudo_veicolo',        'Collaudo Veicolo',                     'auto',       'veicoli',        'documenti_veicolo',         ARRAY['collaudo','nuovo veicolo','immatricolazione','targa','ministero'],         FALSE),
('abbonamento_trasporti',   'Abbonamento Trasporti Pubblici',       'auto',       'veicoli',        'trasporti_pubblici',        ARRAY['abbonamento','ATM','mezzi pubblici','mensile','annuale'],                  TRUE),
('rimborso_sinistro_auto',  'Liquidazione Sinistro Auto',           'assicurazioni','veicoli',      'sinistri',                  ARRAY['liquidazione','sinistro','RC auto','risarcimento','perizia'],              FALSE),

-- ============================================================
-- H. SCUOLA E FORMAZIONE
-- ============================================================
('diploma',                 'Diploma di Maturità',                  'formazione', 'scuola',    'titoli_studio',             ARRAY['diploma','maturità','liceo','istituto','voto','commissione'],              FALSE),
('laurea',                  'Pergamena / Diploma di Laurea',        'formazione', 'scuola',    'titoli_studio',             ARRAY['laurea','università','pergamena','110','cum laude','tesi'],                FALSE),
('certificato_scolastico',  'Certificato Scolastico',               'formazione', 'scuola',    'certificati_scolastici',    ARRAY['certificato scolastico','frequenza','iscrizione','voti'],                 FALSE),
('pagella',                 'Pagella Scolastica',                   'formazione', 'scuola',    'valutazioni',               ARRAY['pagella','voti','giudizio','materie','promosso'],                         FALSE),
('certificato_corso',       'Attestato / Certificato di Corso',     'formazione', 'scuola',    'formazione_professionale',  ARRAY['attestato','corso','formazione','frequenza','ore','ente'],                FALSE),
('iscrizione_universita',   'Iscrizione Universitaria',             'formazione', 'scuola',    'universitario',             ARRAY['iscrizione','università','matricola','anno accademico','facoltà'],         TRUE),
('piano_studi',             'Piano di Studi Universitario',         'formazione', 'scuola',    'universitario',             ARRAY['piano studi','esami','CFU','corso di laurea','curriculum'],               FALSE),
('libretto_universitario',  'Libretto Universitario',               'formazione', 'scuola',    'universitario',             ARRAY['libretto','esami','voti','universitario','carriera'],                     FALSE),
('borsa_studio',            'Borsa di Studio / DSU',                'formazione', 'scuola',    'agevolazioni_studio',       ARRAY['borsa studio','DSU','ISEE','agevolazione','regione','università'],         TRUE),
('diploma_specializzazione','Diploma di Specializzazione',          'formazione', 'scuola',    'titoli_studio',             ARRAY['specializzazione','diploma','master','professionale'],                     FALSE),
('dottorato',               'Titolo di Dottorato di Ricerca',       'formazione', 'scuola',    'titoli_studio',             ARRAY['dottorato','PhD','ricerca','università','tesi dottorato'],                FALSE),
('certificazione_lingua',   'Certificazione Linguistica',           'formazione', 'scuola',    'certificazioni',            ARRAY['IELTS','TOEFL','Cambridge','DELF','Goethe','certificazione lingua'],       TRUE),
('master',                  'Attestato Master',                     'formazione', 'scuola',    'formazione_professionale',  ARRAY['master','MBA','attestato','università','post lauream'],                   FALSE),
('riconoscimento_titolo',   'Riconoscimento Titolo Estero',         'formazione', 'scuola',    'titoli_studio',             ARRAY['riconoscimento','titolo estero','MIUR','equipollenza'],                   FALSE),
('documento_scolastico',    'Documento Scolastico Generico',        'formazione', 'scuola',    'documenti_scolastici',      ARRAY['scuola','documento','istruzione'],                                        FALSE),

-- ============================================================
-- I. IMPRESA E PROFESSIONISTI
-- ============================================================
('partita_iva',             'Apertura / Chiusura Partita IVA',      'impresa',    'impresa','fiscalita_impresa',         ARRAY['partita IVA','apertura','chiusura','Agenzia Entrate','regime forfettario'], FALSE),
('bilancio_aziendale',      'Bilancio d''Esercizio',                'impresa',    'impresa','contabilita',               ARRAY['bilancio','stato patrimoniale','conto economico','nota integrativa'],     FALSE),
('statuto',                 'Statuto Societario',                   'impresa',    'impresa','atti_societari',            ARRAY['statuto','SRL','SPA','associazione','fondazione','atto costitutivo'],     FALSE),
('atto_costitutivo',        'Atto Costitutivo Società',             'impresa',    'impresa','atti_societari',            ARRAY['atto costitutivo','società','notaio','capitale sociale'],                 FALSE),
('verbale_cda',             'Verbale Consiglio di Amministrazione', 'impresa',    'impresa','atti_societari',            ARRAY['verbale CdA','consiglio amministrazione','delibera','assemblea soci'],    FALSE),
('procura_notarile',        'Procura Notarile Speciale/Generale',   'legale',     'impresa','atti_notarili',             ARRAY['procura','notarile','rappresentanza','potere firma','delegato'],          FALSE),
('contratto_fornitura',     'Contratto di Fornitura',               'impresa',    'impresa','contratti_commerciali',     ARRAY['fornitura','contratto','fornitore','cliente','beni','servizi'],           FALSE),
('contratto_servizi',       'Contratto di Prestazione di Servizi',  'impresa',    'impresa','contratti_commerciali',     ARRAY['prestazione servizi','contratto','consulenza','incarico','professionista'],FALSE),
('offerta_commerciale',     'Offerta Commerciale / Preventivo',     'impresa',    'impresa','documenti_commerciali',     ARRAY['offerta','preventivo','quotazione','proposta commerciale'],               FALSE),
('ordine_acquisto_biz',     'Ordine di Acquisto',                   'impresa',    'impresa','documenti_commerciali',     ARRAY['ordine acquisto','PO','purchase order','fornitore'],                     FALSE),
('ddt',                     'Documento di Trasporto (DDT)',          'impresa',    'impresa','documenti_commerciali',     ARRAY['DDT','documento trasporto','bolla','consegna','merci'],                   FALSE),
('sdi_xml',                 'Fattura Elettronica SDI (XML)',        'fisco',      'impresa','fatturazione_elettronica',  ARRAY['fattura elettronica','SDI','XML','e-fattura','Agenzia Entrate','codice SDI'],FALSE),
('libro_giornale',          'Libro Giornale Contabile',             'impresa',    'impresa','contabilita',               ARRAY['libro giornale','contabilità','prima nota','partita doppia'],             FALSE),
('registro_iva',            'Registro IVA Acquisti/Vendite',        'impresa',    'impresa','contabilita',               ARRAY['registro IVA','acquisti','vendite','liquidazione','periodica'],           FALSE),
('licenza_attivita',        'Licenza / Autorizzazione Attività',    'impresa',    'impresa','autorizzazioni',            ARRAY['licenza','SCIA','autorizzazione','comune','attività commerciale'],         TRUE),
('certificato_antimafia',   'Certificato Antimafia / Casellario',   'impresa',    'impresa','certificazioni_impresa',    ARRAY['antimafia','casellario','prefettura','appalto','iscrizione'],             FALSE),
('durc',                    'DURC - Documento Unico Regolarità',    'lavoro',     'impresa','certificazioni_impresa',    ARRAY['DURC','regolarità contributiva','INPS','INAIL','Cassa edile'],            TRUE),
('fideiussione_bancaria',   'Fideiussione / Polizza Cauzionale',    'impresa',    'impresa','garanzie',                  ARRAY['fideiussione','cauzione','garanzia','appalto','banca'],                   TRUE),
('contratto_agenzia',       'Contratto di Agenzia / Mandato',       'impresa',    'impresa','contratti_commerciali',     ARRAY['agenzia','mandato','agente','provvigione','monomandatario'],              FALSE),
('nda',                     'NDA / Accordo Riservatezza',           'impresa',    'impresa','contratti_commerciali',     ARRAY['NDA','riservatezza','confidenzialità','segreto aziendale'],              FALSE),
('privacy_gdpr',            'Informativa Privacy / GDPR',           'impresa',    'impresa','compliance',                ARRAY['GDPR','privacy','informativa','trattamento dati','consenso','DPO'],       FALSE),
('notifica_sinistro_biz',   'Notifica Sinistro Aziendale',          'assicurazioni','impresa','sinistri',               ARRAY['sinistro','danno','notifica','assicurazione aziendale'],                  FALSE),

-- ============================================================
-- J. LEGALE E GIUDIZIARIO
-- ============================================================
('sentenza',                'Sentenza / Decreto',                   'legale',     'legale',   'atti_giudiziari',           ARRAY['sentenza','decreto','tribunale','giudice','dispositivo'],                  FALSE),
('atto_giudiziario',        'Atto Giudiziario / Citazione',         'legale',     'legale',   'atti_giudiziari',           ARRAY['citazione','atto giudiziario','udienza','tribunale'],                     FALSE),
('ricorso',                 'Ricorso / Appello',                    'legale',     'legale',   'atti_giudiziari',           ARRAY['ricorso','appello','Cassazione','TAR','giudice'],                          TRUE),
('diffida',                 'Diffida / Messa in Mora',              'legale',     'legale',   'corrispondenza_legale',     ARRAY['diffida','messa in mora','avvocato','inadempimento','termine'],            FALSE),
('ingiunzione',             'Decreto Ingiuntivo / Ingiunzione',     'legale',     'legale',   'atti_giudiziari',           ARRAY['ingiunzione','decreto','tribunale','credito','opposizione'],               TRUE),
('atto_notifica',           'Atto di Notifica / Notificazione',     'legale',     'legale',   'atti_giudiziari',           ARRAY['notifica','ufficiale giudiziario','UNEP','atto'],                          FALSE),
('procura',                 'Procura Legale',                       'legale',     'legale',   'atti_notarili',             ARRAY['procura','avvocato','rappresentanza','difesa','giudizio'],                 FALSE),
('verbale',                 'Verbale',                              'legale',     'legale',   'verbali',                   ARRAY['verbale','accertamento','sanzione','redatto da','agente'],                 FALSE),
('accordo_transazione',     'Accordo Transattivo',                  'legale',     'legale',   'accordi',                   ARRAY['transazione','accordo','rinuncia','controversia','bonario'],               FALSE),
('testamento',              'Testamento Olografo / Notarile',       'legale',     'legale',   'successioni',               ARRAY['testamento','successione','erede','notaio','olografo'],                    FALSE),
('successione',             'Dichiarazione di Successione',         'fisco',      'legale',   'successioni',               ARRAY['successione','erede','dichiarazione','Agenzia Entrate','eredità'],         FALSE),
('atto_donazione',          'Atto di Donazione',                    'legale',     'legale',   'atti_notarili',             ARRAY['donazione','atto','notaio','bene','beneficiario'],                        FALSE),
('separazione_beni',        'Atto di Separazione dei Beni',         'legale',     'legale',   'stato_civile',              ARRAY['separazione beni','regime patrimoniale','coniugi','notaio'],              FALSE),

-- ============================================================
-- K. COMUNICAZIONI E CORRISPONDENZA
-- ============================================================
('lettera',                 'Lettera / Comunicazione Scritta',      'corrispondenza','utenze',     'corrispondenza',            ARRAY['lettera','comunicazione','mittente','destinatario'],                       FALSE),
('raccomandata',            'Raccomandata / PEC',                   'corrispondenza','utenze',     'corrispondenza',            ARRAY['raccomandata','PEC','posta certificata','avviso ricevimento','AR'],        FALSE),
('pec',                     'PEC - Posta Elettronica Certificata',  'corrispondenza','utenze',     'corrispondenza_digitale',   ARRAY['PEC','posta certificata','elettronica','ricevuta','consegna'],             FALSE),
('comunicazione_ente',      'Comunicazione da Ente Pubblico',       'corrispondenza','utenze',     'enti_pubblici',             ARRAY['INPS','Agenzia Entrate','comune','comunicazione','ente pubblico'],         FALSE),
('ingiunzione_comune',      'Ingiunzione / Avviso Comune',          'legale',     'utenze',        'enti_pubblici',             ARRAY['comune','ingiunzione','avviso','TARI','IMU','tributo'],                    TRUE),
('dichiarazione',           'Dichiarazione Generica',               'corrispondenza','utenze',     'dichiarazioni',             ARRAY['dichiarazione','attestazione','firma'],                                    FALSE),
('modulo',                  'Modulo / Formulario',                  'corrispondenza','utenze',     'moduli',                    ARRAY['modulo','formulario','compilazione','domanda'],                            FALSE),
('notifica',                'Notifica / Avviso di Pagamento',       'corrispondenza','utenze',     'notifiche',                 ARRAY['notifica','avviso','pagamento','scadenza','sollecito'],                    TRUE),
('sollecito',               'Sollecito di Pagamento',               'corrispondenza','utenze',     'notifiche',                 ARRAY['sollecito','pagamento','mora','inadempienza','scaduto'],                   TRUE),

-- ============================================================
-- L. UTILITIES E BOLLETTE
-- ============================================================
('bolletta_luce',           'Bolletta Energia Elettrica',           'utenze',     'utenze',            'utenze',                    ARRAY['bolletta','luce','energia elettrica','kWh','ENEL','Edison','scadenza'],    TRUE),
('bolletta_gas',            'Bolletta Gas',                         'utenze',     'utenze',            'utenze',                    ARRAY['bolletta','gas','Smc','contatore','fornitore','scadenza'],                 TRUE),
('bolletta_acqua',          'Bolletta Acqua / TARI',                'utenze',     'utenze',            'utenze',                    ARRAY['bolletta','acqua','TARI','rifiuti','gestore','comune'],                    TRUE),
('bolletta_telefono',       'Bolletta Telefono / Internet',         'utenze',     'utenze',            'utenze',                    ARRAY['bolletta','telefono','internet','TIM','Vodafone','Wind','Fastweb'],        TRUE),
('contratto_fornitura_luce','Contratto Fornitura Energia',          'utenze',     'utenze',            'contratti_fornitura',       ARRAY['contratto','luce','energia','fornitore','codice POD'],                    FALSE),
('contratto_fornitura_gas', 'Contratto Fornitura Gas',              'utenze',     'utenze',            'contratti_fornitura',       ARRAY['contratto','gas','fornitore','codice PDR','contatore'],                   FALSE),

-- ============================================================
-- M. PREVIDENZA E PENSIONI
-- ============================================================
('domanda_pensione',        'Domanda di Pensionamento INPS',        'lavoro',     'lavoro',           'pensioni',                  ARRAY['pensione','domanda','INPS','anzianità','vecchiaia','anticipata'],          FALSE),
('comunicazione_inps',      'Comunicazione INPS',                   'lavoro',     'lavoro',           'pensioni',                  ARRAY['INPS','comunicazione','prestazione','NASpI','CIGO','assegno'],             FALSE),
('mod_obis_m',              'Mod. OBIS-M Pensione',                 'lavoro',     'lavoro',           'pensioni',                  ARRAY['OBIS-M','cedolino pensione','INPS','importo netto'],                       FALSE),
('naspi',                   'Domanda NASpI / Disoccupazione',       'lavoro',     'lavoro',           'ammortizzatori',            ARRAY['NASpI','disoccupazione','sussidio','INPS','domanda'],                     TRUE),
('cigo_cigs',               'CIG - Cassa Integrazione',             'lavoro',     'lavoro',           'ammortizzatori',            ARRAY['CIG','cassa integrazione','ordinaria','straordinaria','INPS'],             FALSE),
('isee',                    'ISEE / DSU',                           'fisco',      'lavoro',           'agevolazioni',              ARRAY['ISEE','DSU','reddito','patrimonio','CAF','dichiarazione sostitutiva'],     TRUE),
('reddito_cittadinanza',    'Reddito di Cittadinanza / Supporto',   'lavoro',     'lavoro',           'agevolazioni',              ARRAY['reddito cittadinanza','supporto formazione','INPS','sussidio'],            TRUE),

-- ============================================================
-- N. VIAGGI E INTERNAZIONALE
-- ============================================================
('visto',                   'Visto d''Ingresso',                    'identita',   'identita','documenti_viaggio',         ARRAY['visto','ingresso','consolato','ambasciata','scadenza','Schengen'],         TRUE),
('biglietto_aereo',         'Biglietto Aereo / Boarding Pass',      'viaggi',     'identita','viaggi',                    ARRAY['biglietto aereo','volo','boarding pass','prenotazione'],                   FALSE),
('prenotazione_hotel',      'Prenotazione Hotel / Alloggio',        'viaggi',     'identita','viaggi',                    ARRAY['prenotazione','hotel','albergo','check-in','check-out'],                   FALSE),
('dichiarazione_doganale',  'Dichiarazione Doganale',               'fisco',      'identita','dogana',                    ARRAY['dogana','dichiarazione','import','export','merci','valore'],               FALSE),
('traduzione_giurata',      'Traduzione Giurata / Apostille',       'legale',     'identita','documenti_internazionali',  ARRAY['traduzione giurata','apostille','Aja','legalizzazione','autentica'],       FALSE),
('visto_studente',          'Visto per Studio',                     'identita',   'identita','documenti_viaggio',         ARRAY['visto studio','studente','università','consolato'],                        TRUE),

-- ============================================================
-- O. DOCUMENTI DIGITALI E TECNOLOGIA
-- ============================================================
('firma_digitale',          'Documento con Firma Digitale',         'digitale',   'impresa',   'firme_digitali',            ARRAY['firma digitale','CAdES','PAdES','CRS','CNS','SPID'],                       FALSE),
('spid_identita',           'Identità SPID',                        'digitale',   'impresa',   'identita_digitale',         ARRAY['SPID','identità digitale','provider','livello 1 2 3'],                     TRUE),
('cie',                     'CIE - Carta d''Identità Elettronica',  'identita',   'impresa',   'identita_digitale',         ARRAY['CIE','carta identità elettronica','chip','NFC','IPZS'],                    TRUE),
('contratto_digitale',      'Contratto Digitale / E-contract',      'digitale',   'impresa',   'contratti_digitali',        ARRAY['contratto digitale','firma elettronica','DocuSign','OTP'],                 FALSE),
('ricevuta_digitale',       'Ricevuta Digitale / Scontrino Elettr.','digitale',   'impresa',   'pagamenti_digitali',        ARRAY['ricevuta digitale','scontrino elettronico','RT','registratore'],           FALSE),

-- ============================================================
-- P. MISCELLANEA E GENERICI
-- ============================================================
('certificato',             'Certificato',                          'ufficiale',  'generico',          'certificati',               ARRAY['certificato','attestazione','ente','ufficiale'],                           FALSE),
('contratto',               'Contratto',                            'legale',     'generico',          'contratti',                 ARRAY['contratto','accordo','parti','firme','obbligazioni'],                       FALSE),
('preventivo',              'Preventivo / Offerta',                 'finanziario','generico',          'preventivi',                ARRAY['preventivo','offerta','preventivazione','prezzo','lavori'],                 FALSE),
('verbale_riunione',        'Verbale di Riunione',                  'corrispondenza','generico',       'verbali',                   ARRAY['verbale','riunione','decisioni','presenti','OdG'],                         FALSE),
('relazione_tecnica',       'Relazione Tecnica',                    'tecnico',    'generico',          'documenti_tecnici',         ARRAY['relazione tecnica','perizia','indagine','professionale'],                  FALSE),
('perizia',                 'Perizia Tecnica',                      'tecnico',    'generico',          'documenti_tecnici',         ARRAY['perizia','tecnico','CTU','stima','valutazione'],                          FALSE),
('capitolato',              'Capitolato d''Appalto',                'impresa',    'generico',          'documenti_tecnici',         ARRAY['capitolato','appalto','specifiche','lavori','requisiti'],                 FALSE),
('generico',                'Documento Generico',                   'generico',   'generico',          NULL,                        ARRAY['documento','generico'],                                                    FALSE)

-- ============================================================
-- AGGIUNTE V2 — completamento a ~270 tipi
-- ============================================================

-- Identità aggiuntivi
,('tessera_elettorale',      'Tessera Elettorale',                  'identita',  'identita',   'documenti_riconoscimento',  ARRAY['tessera elettorale','voto','comune','sezione'],                            FALSE)
,('libretto_sanitario',      'Libretto Sanitario Personale',        'sanitario', 'identita',   'documenti_sanitari',        ARRAY['libretto sanitario','vaccinazioni','storia clinica','medico base'],        FALSE)
,('certificato_penale',      'Casellario Penale / Carichi Pendenti','legale',    'identita',   'dichiarazioni',             ARRAY['casellario penale','fedina','carichi pendenti','tribunale'],               FALSE)

-- Lavoro aggiuntivi
,('accordo_sindacale',       'Accordo Sindacale / RSU',             'lavoro',    'lavoro',       'contratti_lavoro',          ARRAY['sindacato','accordo','RSU','contratto aziendale','premio'],                FALSE)
,('registro_ore',            'Registro Presenze / Ore Lavoro',      'lavoro',    'lavoro',       'redditi_dipendente',        ARRAY['presenze','ore lavoro','straordinari','registro','cartellino'],            FALSE)
,('modello_disoccupazione',  'Domanda Disoccupazione / Contributi', 'lavoro',    'lavoro',       'lavoro',                ARRAY['disoccupazione','contributi','modello','INPS','requisiti'],                FALSE)
,('nulla_osta_part_time',    'Autorizzazione / Nulla Osta Lavoro Autonomo','lavoro','lavoro',    'contratti_lavoro',          ARRAY['nulla osta','part time','attività secondaria','datore'],                   FALSE)

-- Casa aggiuntivi
,('ricevuta_affitto',        'Ricevuta Pagamento Affitto',          'casa',      'casa',        'locazione',                 ARRAY['ricevuta affitto','canone','inquilino','quietanza','mensilità'],           FALSE)
,('verbale_consegna_chiavi', 'Verbale Consegna Immobile',           'casa',      'casa',        'locazione',                 ARRAY['consegna chiavi','verbale','immobile','stato','locatore'],                 FALSE)
,('denuncia_infortuni_casa', 'Denuncia Infortunio in Casa',         'assicurazioni','casa',     'sinistri',                  ARRAY['infortunio','casa','denuncia','assicurazione','danno'],                    FALSE)
,('ordinanza_comune',        'Ordinanza Comunale',                  'legale',    'casa',        'enti_pubblici',             ARRAY['ordinanza','comune','sindaco','lavori','immobile'],                        TRUE)
,('preventivo_lavori',       'Preventivo Lavori Edili / Ristrutturazione','casa','casa',        'cantiere_edilizia',                  ARRAY['preventivo','lavori','ristrutturazione','impresa edile','preventivo'],     FALSE)
,('collaudo_impianti',       'Certificato Collaudo Impianti',       'casa',      'casa',        'certificazioni_immobili',   ARRAY['collaudo','impianti','idraulico','elettrico','gas','norma'],              TRUE)
,('contratto_manutenzione',  'Contratto Manutenzione Impianti',     'casa',      'casa',        'contratti_fornitura',       ARRAY['manutenzione','caldaia','impianti','contratto','assistenza'],              TRUE)

-- Fisco aggiuntivi
,('delega_fiscale',          'Delega Fiscale / Cassetto Fiscale',   'fisco',     'fisco',      'tributi',                   ARRAY['delega','cassetto fiscale','intermediario','Agenzia Entrate'],             FALSE)
,('comunicazione_agenzia',   'Comunicazione Agenzia delle Entrate', 'fisco',     'fisco',      'contenzioso_fiscale',       ARRAY['Agenzia Entrate','comunicazione','controllo','richiesta dati'],           TRUE)
,('studi_settore',           'Indici Sintetici Affidabilità (ISA)', 'fisco',     'fisco',      'dichiarazione_fiscale',     ARRAY['ISA','indici sintetici','studi settore','affidabilità','voto'],           FALSE)
,('liquidazione_iva',        'Liquidazione IVA Periodica',          'fisco',     'fisco',      'tributi',                   ARRAY['liquidazione IVA','trimestrale','mensile','credito','debito'],             FALSE)
,('ravvedimento',            'Ravvedimento Operoso',                 'fisco',     'fisco',      'tributi',                   ARRAY['ravvedimento','sanzione ridotta','tardivo','regolarizzazione'],            FALSE)

-- Banca aggiuntivi
,('conto_deposito',          'Estratto Conto Deposito Titoli',      'banca',     'banca',  'conti_bancari',             ARRAY['conto deposito','titoli','azioni','fondi','dossier','estratto'],          FALSE)
,('apertura_conto',          'Contratto Apertura Conto',            'banca',     'banca',  'conti_bancari',             ARRAY['apertura conto','IBAN','banca','firma','contratto'],                       FALSE)
,('estratto_buoni',          'Estratto Buoni Postali / Libretti',   'banca',     'banca',  'risparmio',                 ARRAY['buoni postali','Poste Italiane','libretto','risparmio','rendimento'],     FALSE)
,('polizza_rc_professionale','Polizza RC Professionale',            'assicurazioni','banca','polizze',                  ARRAY['RC professionale','responsabilità','tecnico','medico','avvocato'],         TRUE)
,('ricevuta_pagamento_polizza','Ricevuta Premio Assicurativo',       'assicurazioni','banca','polizze',                 ARRAY['premio','polizza','pagamento','ricevuta','scadenza'],                      FALSE)

-- Salute aggiuntivi
,('foglio_dimissione',        'Foglio di Dimissione Ospedaliera',   'sanitario', 'salute',               'ricoveri',                  ARRAY['dimissione','ospedale','diagnosi','terapia','lettera'],                   FALSE)
,('referto_ginecologico',     'Referto Ginecologico / Ostetrico',   'sanitario', 'salute',               'esami_diagnostici',         ARRAY['ginecologia','visita','pap test','ecografia','gravidanza'],               FALSE)
,('certificato_gravidanza',   'Certificato Gravidanza / Maternità', 'sanitario', 'salute',               'certificati_sanitari',      ARRAY['gravidanza','maternità','medico','astensione','INPS'],                    TRUE)
,('referto_ottico',           'Prescrizione Ottica / Visita Oculistica','sanitario','salute',            'prescrizioni',              ARRAY['occhiali','lenti','prescrizione','oculista','diottrie'],                   FALSE)
,('piano_riabilitativo',      'Piano Riabilitativo',                'sanitario', 'salute',               'prescrizioni',              ARRAY['riabilitazione','fisioterapia','piano','SSN','sedute'],                    TRUE)

-- Auto aggiuntivi
,('ricevuta_bollo',           'Ricevuta Pagamento Bollo Auto',      'fisco',     'veicoli',        'tributi_veicolo',           ARRAY['bollo','pagamento','ACI','F24','targa','ricevuta'],                       FALSE)
,('perizia_veicolo',          'Perizia Veicolo / Stima',            'auto',      'veicoli',        'documenti_veicolo',         ARRAY['perizia','veicolo','stima','valore','CTU','incidente'],                   FALSE)
,('noleggio_veicolo',         'Contratto Noleggio Auto',            'auto',      'veicoli',        'noleggio',                  ARRAY['noleggio','auto','contratto','rent','km illimitati'],                     FALSE)
,('autorizzazione_circolazione','Autorizzazione Circolazione Speciale','auto',  'veicoli',        'documenti_veicolo',         ARRAY['autorizzazione','trasporto eccezionale','circolazione','prefettura'],     TRUE)
,('libretto_manutenzione',    'Libretto Tagliandi / Manutenzione',  'auto',      'veicoli',        'documenti_veicolo',         ARRAY['tagliando','manutenzione','officina','km','revisione'],                   FALSE)

-- Scuola aggiuntivi
,('verbale_esame',            'Verbale Esame',                      'formazione','scuola',    'valutazioni',               ARRAY['verbale esame','commissione','voto','sessione'],                          FALSE)
,('tesi',                     'Tesi di Laurea / Dottorato',         'formazione','scuola',    'universitario',             ARRAY['tesi','laurea','dottorato','elaborato','relatore'],                       FALSE)
,('formulario_iscrizione',    'Formulario Iscrizione Scolastica',   'formazione','scuola',    'documenti_scolastici',      ARRAY['iscrizione','scuola','formulario','anno scolastico'],                     FALSE)
,('contratto_tirocinio',      'Contratto Tirocinio / Stage',        'lavoro',    'scuola',    'contratti_lavoro',          ARRAY['tirocinio','stage','alternanza','convenzione','tutor'],                   FALSE)
,('riconoscimento_crediti',   'Riconoscimento Crediti Formativi',   'formazione','scuola',    'universitario',             ARRAY['CFU','crediti','riconoscimento','trasferimento','carriera'],              FALSE)

-- Impresa aggiuntivi
,('comunicazione_cciaa',      'Comunicazione CCIAA / Registro Imprese','impresa','impresa','atti_societari',           ARRAY['CCIAA','registro imprese','comunicazione','sede','variazione'],           FALSE)
,('modello_redditi_sc',       'Modello Redditi Società Capitali',   'fisco',     'impresa','dichiarazione_fiscale',    ARRAY['redditi SC','IRES','società','dichiarazione','730 società'],              FALSE)
,('dichiarazione_inps_biz',   'Denuncia Contributiva INPS Azienda', 'impresa',   'impresa','contabilita',              ARRAY['contributi','INPS','azienda','denuncia','F24'],                           FALSE)
,('comunicazione_dipendenti', 'Comunicazione Variazioni Dipendenti','lavoro',    'impresa','contratti_lavoro',         ARRAY['assunzione','cessazione','UNILAV','COB','dipendente'],                    FALSE)
,('contratto_leasing',        'Contratto di Leasing',               'banca',     'impresa','finanziamenti',            ARRAY['leasing','finanziamento','canone','bene strumentale','riscatto'],         FALSE)

-- Viaggi aggiuntivi
,('lasciapassare',            'Lasciapassare / Safe Conduct',       'identita',  'identita','documenti_viaggio',        ARRAY['lasciapassare','confine','autorizzazione','ingresso'],                    TRUE)
,('assicurazione_sanitaria_viaggio','Assicurazione Sanitaria per Viaggio','assicurazioni','identita','polizze',         ARRAY['assicurazione','viaggio','emergenza medica','rimpatrio'],                 TRUE)

-- Digitale aggiuntivi
,('backup_recovery',          'Piano Backup / Recovery',            'digitale',  'impresa',   'documenti_tecnici',        ARRAY['backup','recovery','piano','dati','DR'],                                  FALSE)
,('policy_aziendale',         'Policy / Regolamento Aziendale',     'impresa',   'impresa',   'compliance',               ARRAY['policy','regolamento','aziendale','dipendenti','mansionario'],            FALSE)

ON CONFLICT (codice) DO UPDATE SET
    etichetta       = EXCLUDED.etichetta,
    categoria       = EXCLUDED.categoria,
    macro_categoria = EXCLUDED.macro_categoria,
    sottocategoria  = EXCLUDED.sottocategoria,
    parole_chiave   = EXCLUDED.parole_chiave,
    has_scadenza    = EXCLUDED.has_scadenza;
