-- Vemoria audit convergence v271 — Email→Memoria owner isolation.
BEGIN;

-- The legacy schema made Message-ID globally unique. RFC Message-IDs should be
-- globally unique, but they are untrusted inbound data and therefore cannot be
-- allowed to create a cross-owner denial-of-intake boundary.
ALTER TABLE email_memora DROP CONSTRAINT IF EXISTS email_memora_message_id_key;
DROP INDEX IF EXISTS email_memora_message_id_key;
CREATE UNIQUE INDEX IF NOT EXISTS idx_email_memora_owner_message_id
    ON email_memora(utente_id, message_id)
    WHERE message_id IS NOT NULL;

ALTER TABLE email_memora ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_memora FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS email_memora_owner_isolation ON email_memora;
CREATE POLICY email_memora_owner_isolation ON email_memora
    FOR ALL
    USING (utente_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (utente_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

COMMIT;
