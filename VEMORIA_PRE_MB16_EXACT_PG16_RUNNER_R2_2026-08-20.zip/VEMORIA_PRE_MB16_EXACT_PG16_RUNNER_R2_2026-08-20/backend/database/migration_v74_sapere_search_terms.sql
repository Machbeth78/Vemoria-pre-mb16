-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V74 — Sapere search terms canonici
-- Obiettivo:
-- 1) normalizzare alias, keyword e match terms del catalogo/document packs nel DB
-- 2) rendere DB-first la risoluzione documentale senza dipendere solo dai JSON runtime
-- 3) mantenere compatibilità con i pack attivi e con il sync catalogo

CREATE TABLE IF NOT EXISTS sapere_search_terms (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id            TEXT NOT NULL,
    sapere_id               TEXT NULL,
    locale                  TEXT NOT NULL DEFAULT 'it-IT',
    domain                  TEXT NOT NULL DEFAULT 'core',
    term_group              TEXT NOT NULL,
    term_key                TEXT NOT NULL,
    term_text               TEXT NOT NULL,
    term_rank               INTEGER NOT NULL DEFAULT 0,
    metadata_term           JSONB NOT NULL DEFAULT '{}'::jsonb,
    source_pack_id          TEXT NULL,
    source_pack_version     TEXT NULL,
    source_manifest_version TEXT NULL,
    source_entry_index      INTEGER NULL,
    source_checksum         TEXT NULL,
    attivo                  BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_sapere_search_terms_doc_group_key_locale_domain
    ON sapere_search_terms (documento_id, locale, domain, term_group, term_key);

CREATE INDEX IF NOT EXISTS idx_sapere_search_terms_lookup
    ON sapere_search_terms (term_key, locale, domain, term_group, term_rank)
    WHERE attivo = TRUE;

CREATE INDEX IF NOT EXISTS idx_sapere_search_terms_documento
    ON sapere_search_terms (documento_id, locale, domain)
    WHERE attivo = TRUE;

CREATE INDEX IF NOT EXISTS idx_sapere_search_terms_pack
    ON sapere_search_terms (source_pack_id, locale, domain);

CREATE INDEX IF NOT EXISTS idx_sapere_search_terms_metadata
    ON sapere_search_terms USING GIN (metadata_term);
