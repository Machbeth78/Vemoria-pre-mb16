-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB12-P0 R1E — Owner, trust and context closure.
-- Additive, idempotent migration. Does not modify v176/v177/v178.

BEGIN;

-- Source-card authority can explicitly classify a source as non-personal public evidence.
ALTER TABLE canonical_source_card_authority
    ADD COLUMN IF NOT EXISTS is_public_evidence BOOLEAN NOT NULL DEFAULT FALSE;

-- Binding can carry a scope tag (e.g. 'document:passport', 'data:age').
ALTER TABLE mb12_p0_source_card_binding
    ADD COLUMN IF NOT EXISTS scope TEXT NOT NULL DEFAULT 'source';

-- Eligibility evaluation can store the request territory and per-rule result lists.
ALTER TABLE mb12_p0_eligibility_evaluation
    ADD COLUMN IF NOT EXISTS territory TEXT NOT NULL DEFAULT '';

ALTER TABLE mb12_p0_eligibility_evaluation
    ADD COLUMN IF NOT EXISTS evaluated_rules JSONB NOT NULL DEFAULT '[]'::jsonb;

ALTER TABLE mb12_p0_eligibility_evaluation
    ADD COLUMN IF NOT EXISTS per_rule_results JSONB NOT NULL DEFAULT '[]'::jsonb;

-- Capability value restriction for trusted promotion authority.
-- Normalize existing R1D capabilities to the exact operation map before enforcing.
UPDATE mb12_p0_trusted_promotion_authority
   SET capability = CASE
       WHEN capability = 'promote' THEN 'mb12.promote'
       WHEN capability = 'revise' THEN 'mb12.revise'
       WHEN capability = 'revoke' THEN 'mb12.revoke'
       ELSE capability
   END;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conrelid = 'mb12_p0_trusted_promotion_authority'::regclass
          AND conname = 'chk_mb12_p0_trusted_promotion_authority_capability'
    ) THEN
        ALTER TABLE mb12_p0_trusted_promotion_authority
            ADD CONSTRAINT chk_mb12_p0_trusted_promotion_authority_capability
                CHECK (capability IN ('mb12.promote','mb12.revise','mb12.revoke'));
    END IF;
END $$;

-- Validation trigger: binding owner/source/revision/evidence integrity and hash.
CREATE OR REPLACE FUNCTION mb12_p0_validate_source_card_binding()
RETURNS trigger AS $$
BEGIN
    IF NEW.owner_user_id IS NULL THEN
        RAISE EXCEPTION 'binding owner missing';
    END IF;
    -- Source ownership and state.
    IF NOT EXISTS (
        SELECT 1 FROM authorized_memory_sources s
         WHERE s.id = NEW.source_id
           AND s.user_id = NEW.owner_user_id
           AND s.status = 'active'
           AND s.revoked_at IS NULL
    ) THEN
        RAISE EXCEPTION 'binding source not found, cross-owner, revoked or inactive';
    END IF;
    -- Inventory item ownership, source link and state.
    IF NOT EXISTS (
        SELECT 1 FROM authorized_memory_inventory_items i
         WHERE i.id = NEW.source_revision_id
           AND i.user_id = NEW.owner_user_id
           AND i.source_id = NEW.source_id
           AND i.deleted_at IS NULL
           AND i.memory_state <> 'revoked'
    ) THEN
        RAISE EXCEPTION 'binding revision not found, cross-owner, wrong source or revoked';
    END IF;
    -- Content-hash integrity when both sides provide a hash.
    IF NEW.content_hash IS NOT NULL AND length(NEW.content_hash) > 0 THEN
        IF EXISTS (
            SELECT 1 FROM authorized_memory_inventory_items i
             WHERE i.id = NEW.source_revision_id
               AND i.content_hash IS NOT NULL
               AND length(i.content_hash) > 0
               AND i.content_hash <> NEW.content_hash
        ) THEN
            RAISE EXCEPTION 'binding content_hash mismatch';
        END IF;
    END IF;
    -- Evidence ownership, source link and relevance.
    IF NOT EXISTS (
        SELECT 1 FROM authorized_memory_activity_log l
         WHERE l.id = NEW.evidence_id
           AND l.user_id = NEW.owner_user_id
           AND (l.source_id = NEW.source_id OR l.source_id IS NULL)
           AND l.action IN ('promote_to_canonical','read_metadata','eligibility_read')
    ) THEN
        RAISE EXCEPTION 'binding evidence not found, cross-owner, wrong source or irrelevant action';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_mb12_p0_validate_source_card_binding ON mb12_p0_source_card_binding;
CREATE TRIGGER trg_mb12_p0_validate_source_card_binding
    BEFORE INSERT OR UPDATE ON mb12_p0_source_card_binding
    FOR EACH ROW EXECUTE FUNCTION mb12_p0_validate_source_card_binding();

-- Governed writer function for the application role.
-- SECURITY DEFINER lets the app role insert a binding only when every relationship
-- is valid. The application role must not have direct INSERT on the binding table.
CREATE OR REPLACE FUNCTION mb12_p0_create_source_card_binding(
    p_source_card_id TEXT,
    p_owner_user_id UUID,
    p_source_id UUID,
    p_source_revision_id UUID,
    p_evidence_id UUID,
    p_content_hash TEXT DEFAULT '',
    p_scope TEXT DEFAULT 'source'
) RETURNS VOID AS $$
BEGIN
    INSERT INTO mb12_p0_source_card_binding (
        source_card_id, owner_user_id, source_id, source_revision_id, evidence_id, content_hash, scope, status
    ) VALUES (
        p_source_card_id, p_owner_user_id, p_source_id, p_source_revision_id, p_evidence_id, p_content_hash, p_scope, 'active'
    )
    ON CONFLICT (owner_user_id, source_card_id) DO UPDATE SET
        source_id = EXCLUDED.source_id,
        source_revision_id = EXCLUDED.source_revision_id,
        evidence_id = EXCLUDED.evidence_id,
        content_hash = EXCLUDED.content_hash,
        scope = EXCLUDED.scope,
        status = 'active',
        revoked_at = NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Application role may read bindings and authority, but may only insert bindings
-- through the governed writer function.
REVOKE INSERT ON mb12_p0_source_card_binding FROM mb12_p0_app;
GRANT EXECUTE ON FUNCTION mb12_p0_create_source_card_binding(TEXT, UUID, UUID, UUID, UUID, TEXT, TEXT) TO mb12_p0_app;

COMMIT;
