-- MB15-P2-R1 — Force Row Level Security on Goal Plan Builder tables.
-- Ensures owner policies apply even to table owners and superusers through standard queries.

BEGIN;

ALTER TABLE mb15_p2_goal_sessions FORCE ROW LEVEL SECURITY;
ALTER TABLE mb15_p2_goal_execution_plans FORCE ROW LEVEL SECURITY;

COMMIT;
