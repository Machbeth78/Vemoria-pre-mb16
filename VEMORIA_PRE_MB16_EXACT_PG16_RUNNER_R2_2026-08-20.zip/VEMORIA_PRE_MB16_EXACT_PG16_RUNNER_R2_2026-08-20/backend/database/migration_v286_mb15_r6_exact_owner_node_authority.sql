-- Vemoria PRE-MB16 — MB15 R6 exact Owner Node authorization closure.
--
-- A generic source-level `heavy_analysis` grant is only the foundation.  The
-- exact inventory item, exact current item revision/hash and exact workload are
-- frozen by a short-lived owner/device-scoped authorization before /prepare.
-- /prepare consumes only that server record; it no longer accepts item/workload.

CREATE TABLE IF NOT EXISTS mb15_r6_owner_node_exact_authorizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    authorized_by_device_id UUID NOT NULL,
    owner_node_id TEXT NOT NULL,
    inventory_item_id UUID NOT NULL REFERENCES authorized_memory_inventory_items(id) ON DELETE CASCADE,
    source_id UUID NOT NULL REFERENCES authorized_memory_sources(id) ON DELETE CASCADE,
    grant_id UUID NOT NULL REFERENCES authorized_memory_consent_grants(id) ON DELETE CASCADE,
    workload_id TEXT NOT NULL CHECK (workload_id IN ('MASS_OCR','MASS_DOCUMENT_ANALYSIS','MASS_VIDEO_ANALYSIS')),
    source_sha256 TEXT NOT NULL CHECK (source_sha256 ~ '^[0-9a-f]{64}$'),
    inventory_revision_at TIMESTAMPTZ NOT NULL,
    consent_revision INTEGER NOT NULL CHECK (consent_revision >= 1),
    grant_issued_at TIMESTAMPTZ NOT NULL,
    explicit_user_ack BOOLEAN NOT NULL CHECK (explicit_user_ack = TRUE),
    expires_at TIMESTAMPTZ NOT NULL,
    consumed_at TIMESTAMPTZ NULL,
    revoked_at TIMESTAMPTZ NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (expires_at > created_at)
);

CREATE INDEX IF NOT EXISTS idx_mb15_r6_exact_auth_owner_active
    ON mb15_r6_owner_node_exact_authorizations(owner_id, expires_at)
    WHERE consumed_at IS NULL AND revoked_at IS NULL;

ALTER TABLE mb15_r6_owner_node_exact_authorizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb15_r6_owner_node_exact_authorizations FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS mb15_r6_exact_auth_owner_policy ON mb15_r6_owner_node_exact_authorizations;
CREATE POLICY mb15_r6_exact_auth_owner_policy
    ON mb15_r6_owner_node_exact_authorizations
    USING (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

ALTER TABLE mb15_r6_owner_node_product_bindings
    ADD COLUMN IF NOT EXISTS exact_authorization_id UUID NULL
    REFERENCES mb15_r6_owner_node_exact_authorizations(id) ON DELETE RESTRICT;

CREATE INDEX IF NOT EXISTS idx_mb15_r6_binding_exact_authorization
    ON mb15_r6_owner_node_product_bindings(owner_id, exact_authorization_id)
    WHERE exact_authorization_id IS NOT NULL;

-- Pre-v286 bindings that never reached an anchored semantic result cannot
-- authorize a new computation after this security boundary.  Already anchored
-- results remain replayable through the 6A result ledger without recomputation;
-- their semantic evidence is preserved instead of being silently deleted.
UPDATE mb15_r6_owner_node_product_bindings b
SET revoked_at = COALESCE(b.revoked_at, NOW())
WHERE b.exact_authorization_id IS NULL
  AND NOT EXISTS (
      SELECT 1
      FROM mb15_r6_owner_node_product_requests r
      WHERE r.binding_id = b.id
        AND r.owner_id = b.owner_id
        AND r.state = 'RESULT_ANCHORED'
  );
