-- ============================================================
-- VEMORA V4.6 — Database Init Completo
-- Eseguire UNA SOLA VOLTA su un database vuoto.
-- Contiene: schema base + migrazioni V2 → V26
-- ============================================================

-- ============================================================
-- PARTE 1: Schema base
-- ============================================================
-- ============================================================
-- VEMORA — Schema PostgreSQL Completo
-- Ideatore: Devoti Massimo
-- Generato da: architettura FROZEN V1
-- ============================================================

-- Estensione UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Estensione pgcrypto: garantisce gen_random_uuid() anche su PostgreSQL <= 14.
-- PATCH V79.2E (innestato in V79.2M): in V79.2L 20 migration usano
-- gen_random_uuid() senza dichiarare l'extension. PostgreSQL 15+ la fornisce
-- nel core, ma su 13/14 va caricata esplicitamente. Idempotente, nessun effetto
-- su PG 15+. Non sovrascrive nulla di V79.2L.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Estensione pg_trgm: usata da indici testuali e ricerche fuzzy.
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ============================================================
-- TABELLA: utenti
-- ============================================================
CREATE TABLE utenti (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome            TEXT NOT NULL,
    email           TEXT NOT NULL UNIQUE,
    password_hash   TEXT NOT NULL,
    creato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    attivo          BOOLEAN NOT NULL DEFAULT TRUE
);

-- ============================================================
-- TABELLA: tipi_documento
-- Libreria modelli — popolata al bootstrap
-- ============================================================
CREATE TABLE tipi_documento (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    codice      TEXT NOT NULL UNIQUE,   -- es: "fattura", "contratto", "generico"
    etichetta   TEXT NOT NULL,          -- es: "Fattura", "Contratto"
    categoria   TEXT NOT NULL,          -- es: "finanziario", "legale", "sanitario"
    attivo      BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABELLA: documenti
-- Documento fisico ricevuto dal sistema
-- ============================================================
CREATE TABLE documenti (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    proprietario_id         UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    nome_file_originale     TEXT NOT NULL,
    stato_elaborazione      TEXT NOT NULL DEFAULT 'ricevuto',
                            -- ricevuto | in_acquisizione | in_comprensione
                            -- in_costruzione | in_qualita | memorizzato
                            -- in_errore | in_attesa_utente
    tipo_documento_id       UUID REFERENCES tipi_documento(id),
    percorso_storage        TEXT,           -- path relativo in originali/
    hash_file               TEXT,           -- SHA-256 del file originale
    testo_grezzo            TEXT,           -- testo estratto dall'OCR
    lingua_rilevata         TEXT,           -- codice ISO 639-1 es: "it"
    tentativi_correnti      INTEGER NOT NULL DEFAULT 0,
    dati_strutturati        JSONB,          -- PacchettoDocumento serializzato
    creato_il               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_documenti_proprietario    ON documenti(proprietario_id);
CREATE INDEX idx_documenti_stato           ON documenti(stato_elaborazione);
CREATE INDEX idx_documenti_tipo            ON documenti(tipo_documento_id);
CREATE INDEX idx_documenti_aggiornato      ON documenti(aggiornato_il DESC);

-- ============================================================
-- TABELLA: memorie
-- Memoria strutturata e approvata dalla pipeline
-- ============================================================
CREATE TABLE memorie (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    proprietario_id         UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    documento_sorgente_id   UUID REFERENCES documenti(id) ON DELETE SET NULL,

    -- Contenuto principale
    titolo                  TEXT NOT NULL,
    riassunto               TEXT,
    testo_completo          TEXT,

    -- Classificazione
    tipo_documento          TEXT NOT NULL DEFAULT 'generico',
    categoria_documento     TEXT NOT NULL DEFAULT 'generico',
    sottocategoria          TEXT,
    codice_lingua           TEXT NOT NULL DEFAULT 'it',

    -- Qualità
    score_qualita           REAL NOT NULL DEFAULT 0.0,
    livello_affidabilita    REAL NOT NULL DEFAULT 0.0,
    approvata_con_riserva   BOOLEAN NOT NULL DEFAULT FALSE,

    -- Dati strutturati (entità, metadati, qualità)
    dati_strutturati        JSONB,
    metadati_ricerca        JSONB,

    -- Stato
    stato                   TEXT NOT NULL DEFAULT 'attiva',
                            -- attiva | archiviata | eliminata
    versione                INTEGER NOT NULL DEFAULT 1,

    creata_il               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    confermata_il           TIMESTAMPTZ
);

CREATE INDEX idx_memorie_proprietario      ON memorie(proprietario_id);
CREATE INDEX idx_memorie_tipo              ON memorie(tipo_documento);
CREATE INDEX idx_memorie_categoria         ON memorie(categoria_documento);
CREATE INDEX idx_memorie_stato             ON memorie(stato);
CREATE INDEX idx_memorie_creata            ON memorie(creata_il DESC);
CREATE INDEX idx_memorie_documento_src     ON memorie(documento_sorgente_id);

-- Ricerca full-text sul titolo e riassunto
CREATE INDEX idx_memorie_fts ON memorie
    USING GIN (to_tsvector('italian', coalesce(titolo,'') || ' ' || coalesce(riassunto,'')));

-- ============================================================
-- TABELLA: cronologia_eventi
-- Log immutabile di ogni step della pipeline
-- ============================================================
CREATE TABLE cronologia_eventi (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id        UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    nome_camera         TEXT NOT NULL,
    tipo_evento         TEXT NOT NULL,
    numero_tentativo    INTEGER NOT NULL DEFAULT 1,
    dati_evento         JSONB,
    messaggio_errore    TEXT,
    timestamp           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_cronologia_documento  ON cronologia_eventi(documento_id);
CREATE INDEX idx_cronologia_timestamp  ON cronologia_eventi(timestamp DESC);
CREATE INDEX idx_cronologia_camera     ON cronologia_eventi(nome_camera);

-- ============================================================
-- TABELLA: problemi
-- Documenti che la pipeline non è riuscita a gestire
-- ============================================================
CREATE TABLE problemi (
    id                          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id                UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    camera_origine              TEXT NOT NULL,
    tipo_problema               TEXT NOT NULL,
    motivazione_principale      TEXT,
    dettaglio_tecnico           TEXT,
    tentativi_effettuati        INTEGER NOT NULL DEFAULT 0,
    richiede_intervento_utente  BOOLEAN NOT NULL DEFAULT FALSE,
    risolto                     BOOLEAN NOT NULL DEFAULT FALSE,
    creato_il                   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    risolto_il                  TIMESTAMPTZ
);

CREATE INDEX idx_problemi_documento    ON problemi(documento_id);
CREATE INDEX idx_problemi_risolto      ON problemi(risolto);

-- ============================================================
-- TABELLA: identita_digitale
-- Impronta SHA-256 verificabile di ogni documento
-- ============================================================
CREATE TABLE identita_digitale (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id        UUID NOT NULL UNIQUE REFERENCES documenti(id) ON DELETE CASCADE,
    hash_documento      TEXT NOT NULL,
    percorso_file       TEXT NOT NULL,
    stato_identita      TEXT NOT NULL DEFAULT 'attiva',
                        -- attiva | revocata | aggiornata
    versione_identita   TEXT NOT NULL DEFAULT '1.0',
    firma_identita      TEXT,           -- campo riservato per futura firma crittografica
    metadati            JSONB,
    creata_il           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_identita_documento ON identita_digitale(documento_id);
CREATE INDEX idx_identita_stato     ON identita_digitale(stato_identita);

-- ============================================================
-- DATI INIZIALI: tipi_documento (Libreria Modelli)
-- ============================================================
INSERT INTO tipi_documento (codice, etichetta, categoria) VALUES
    ('fattura',         'Fattura',              'finanziario'),
    ('ricevuta',        'Ricevuta',             'finanziario'),
    ('contratto',       'Contratto',            'legale'),
    ('lettera',         'Lettera',              'corrispondenza'),
    ('referto_medico',  'Referto Medico',       'sanitario'),
    ('preventivo',      'Preventivo',           'finanziario'),
    ('verbale',         'Verbale',              'legale'),
    ('certificato',     'Certificato',          'ufficiale'),
    ('generico',        'Documento Generico',   'generico');

-- ============================================================
-- FUNZIONE: aggiorna aggiornato_il automaticamente
-- ============================================================
CREATE OR REPLACE FUNCTION aggiorna_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.aggiornato_il = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_documenti_aggiornato
    BEFORE UPDATE ON documenti
    FOR EACH ROW EXECUTE FUNCTION aggiorna_timestamp();

CREATE TRIGGER trigger_memorie_aggiornato
    BEFORE UPDATE ON memorie
    FOR EACH ROW EXECUTE FUNCTION aggiorna_timestamp();

-- ============================================================
-- MIGRAZIONE: migration_v2.sql
-- ============================================================
-- ============================================================
-- VEMORA V2 — Migration Additiva
-- IMPORTANTE: NON modifica le tabelle core esistenti
-- Aggiunge solo nuove tabelle e colonne opzionali
-- ============================================================

-- ============================================================
-- Aggiunte alle tabelle esistenti (opzionali, nullable)
-- ============================================================

-- Aggiungi categoria_colore a memorie (derivata dalla pipeline)
ALTER TABLE memorie
    ADD COLUMN IF NOT EXISTS categoria_colore TEXT DEFAULT 'white',
    ADD COLUMN IF NOT EXISTS tags             JSONB DEFAULT '[]',
    ADD COLUMN IF NOT EXISTS dossier_id_principale UUID,
    ADD COLUMN IF NOT EXISTS data_documento   TIMESTAMPTZ;

-- Aggiungi tipo_contenuto a documenti (distingue documento vs foto evento)
ALTER TABLE documenti
    ADD COLUMN IF NOT EXISTS tipo_contenuto  TEXT DEFAULT 'documento',
                                             -- documento | foto_evento
    ADD COLUMN IF NOT EXISTS gps_lat         REAL,
    ADD COLUMN IF NOT EXISTS gps_lon         REAL,
    ADD COLUMN IF NOT EXISTS descrizione     TEXT;

-- ============================================================
-- TABELLA: dossier
-- Raccoglitori logici di documenti correlati
-- ============================================================
CREATE TABLE IF NOT EXISTS dossier (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    proprietario_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    titolo          TEXT NOT NULL,
    descrizione     TEXT,
    colore          TEXT NOT NULL DEFAULT 'blue',
    icona           TEXT NOT NULL DEFAULT 'folder',
    keywords        JSONB DEFAULT '[]',     -- parole chiave per auto-assegnazione
    stato           TEXT NOT NULL DEFAULT 'attivo',
    creato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_dossier_proprietario ON dossier(proprietario_id);
CREATE INDEX IF NOT EXISTS idx_dossier_stato        ON dossier(stato);

-- ============================================================
-- TABELLA: documento_dossier
-- Relazione N:N tra memorie e dossier
-- ============================================================
CREATE TABLE IF NOT EXISTS documento_dossier (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    memoria_id  UUID NOT NULL REFERENCES memorie(id) ON DELETE CASCADE,
    dossier_id  UUID NOT NULL REFERENCES dossier(id) ON DELETE CASCADE,
    principale  BOOLEAN NOT NULL DEFAULT FALSE,
    aggiunto_il TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(memoria_id, dossier_id)
);

CREATE INDEX IF NOT EXISTS idx_doc_dossier_memoria  ON documento_dossier(memoria_id);
CREATE INDEX IF NOT EXISTS idx_doc_dossier_dossier  ON documento_dossier(dossier_id);

-- ============================================================
-- FUNZIONE aggiornamento timestamp per dossier
-- ============================================================
CREATE OR REPLACE FUNCTION aggiorna_timestamp_dossier()
RETURNS TRIGGER AS $$
BEGIN
    NEW.aggiornato_il = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_dossier_aggiornato ON dossier;
CREATE TRIGGER trigger_dossier_aggiornato
    BEFORE UPDATE ON dossier
    FOR EACH ROW EXECUTE FUNCTION aggiorna_timestamp_dossier();

-- ============================================================
-- V2.1 ESTENSIONE ADDITIVE — Note Vocali
-- Aggiunge campi opzionali per la nota vocale alla tabella memorie
-- NON modifica struttura esistente
-- ============================================================

ALTER TABLE memorie
    ADD COLUMN IF NOT EXISTS audio_nota_path            TEXT,      -- path relativo nel filesystem storage
    ADD COLUMN IF NOT EXISTS audio_nota_testo           TEXT,      -- testo trascritto (se disponibile)
    ADD COLUMN IF NOT EXISTS audio_nota_durata_secondi  INTEGER;   -- durata in secondi

-- Indice per ricerca sul testo trascritto
CREATE INDEX IF NOT EXISTS idx_memorie_audio_nota_testo
    ON memorie(audio_nota_path)
    WHERE audio_nota_path IS NOT NULL;

-- ============================================================
-- MIGRAZIONE: migration_v3.sql
-- ============================================================
-- ============================================================
-- VEMORA — Migration V3
-- Ideatore: Devoti Massimo
-- Nuove tabelle: settori professionali, paesi, libreria
--                documentale, dispositivi utente
-- ============================================================

-- ============================================================
-- TABELLA: settori_professionali
-- Categorie professionali per la libreria documentale
-- ============================================================
CREATE TABLE IF NOT EXISTS settori_professionali (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    codice      TEXT NOT NULL UNIQUE,   -- es: "edilizia", "legale", "fiscale"
    etichetta   JSONB NOT NULL,         -- {"it": "Edilizia", "en": "Construction", ...}
    icona       TEXT,                   -- nome icona UI
    attivo      BOOLEAN NOT NULL DEFAULT TRUE,
    ordine      INTEGER NOT NULL DEFAULT 0,
    creato_il   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABELLA: paesi
-- Paesi supportati nella libreria documentale
-- ============================================================
CREATE TABLE IF NOT EXISTS paesi (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    codice_iso      TEXT NOT NULL UNIQUE,   -- es: "IT", "FR", "DE", "ES", "GB"
    nome            JSONB NOT NULL,          -- {"it": "Italia", "en": "Italy", ...}
    lingua_default  TEXT NOT NULL DEFAULT 'it',
    attivo          BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABELLA: libreria_documenti
-- Documento tipo nella libreria per settore + paese + lingua
-- ============================================================
CREATE TABLE IF NOT EXISTS libreria_documenti (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    codice                  TEXT NOT NULL,          -- es: "scia", "permesso_costruire"
    nome                    JSONB NOT NULL,          -- {"it": "SCIA", "en": "Building Notice"}
    descrizione             JSONB,                   -- descrizione multilingua
    settore_id              UUID REFERENCES settori_professionali(id) ON DELETE SET NULL,
    paese_id                UUID REFERENCES paesi(id) ON DELETE SET NULL,
    tipo_documento_id       UUID REFERENCES tipi_documento(id) ON DELETE SET NULL,
    parole_chiave           JSONB,                   -- ["scia", "inizio attività", ...]
    professioni_target      JSONB,                   -- ["geometra", "architetto", ...]
    globale                 BOOLEAN NOT NULL DEFAULT FALSE,  -- valido per tutti i paesi
    sovranazionale          BOOLEAN NOT NULL DEFAULT FALSE,  -- UE, ONU ecc.
    attivo                  BOOLEAN NOT NULL DEFAULT TRUE,
    ordine                  INTEGER NOT NULL DEFAULT 0,
    creato_il               TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_libreria_settore  ON libreria_documenti(settore_id);
CREATE INDEX IF NOT EXISTS idx_libreria_paese    ON libreria_documenti(paese_id);
CREATE INDEX IF NOT EXISTS idx_libreria_globale  ON libreria_documenti(globale);

-- ============================================================
-- TABELLA: dispositivi_utente
-- Info dispositivo per ottimizzazione fotocamera/voce
-- ============================================================
CREATE TABLE IF NOT EXISTS dispositivi_utente (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    marca               TEXT,
    modello             TEXT,
    sistema_operativo   TEXT,           -- "android" | "ios"
    versione_os         TEXT,
    risoluzione_camera  TEXT,           -- es: "12MP"
    zoom_ottico         REAL,
    microfoni           INTEGER,
    supporto_voce       BOOLEAN NOT NULL DEFAULT TRUE,
    raw_info            JSONB,          -- tutti i dati grezzi dal device
    registrato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_dispositivi_utente ON dispositivi_utente(utente_id);

-- ============================================================
-- DATI: settori professionali
-- ============================================================
INSERT INTO settori_professionali (codice, etichetta, icona, ordine) VALUES
    ('personale',   '{"it":"Documenti Personali","en":"Personal Documents","fr":"Documents Personnels","de":"Persönliche Dokumente","es":"Documentos Personales"}', 'person',           1),
    ('edilizia',    '{"it":"Edilizia e Tecnici","en":"Construction","fr":"Construction","de":"Bauwesen","es":"Construcción"}',                                       'construction',     2),
    ('legale',      '{"it":"Area Legale","en":"Legal","fr":"Juridique","de":"Recht","es":"Legal"}',                                                                  'gavel',            3),
    ('fiscale',     '{"it":"Area Fiscale","en":"Tax & Finance","fr":"Fiscal","de":"Steuer","es":"Fiscal"}',                                                          'receipt_long',     4),
    ('lavoro',      '{"it":"Lavoro","en":"Employment","fr":"Emploi","de":"Arbeit","es":"Trabajo"}',                                                                  'work',             5),
    ('sanitario',   '{"it":"Sanitario","en":"Medical","fr":"Médical","de":"Medizinisch","es":"Médico"}',                                                             'local_hospital',   6),
    ('casa',        '{"it":"Casa e Immobili","en":"Home & Property","fr":"Maison","de":"Immobilien","es":"Hogar"}',                                                  'home',             7),
    ('auto',        '{"it":"Auto e Veicoli","en":"Vehicles","fr":"Véhicules","de":"Fahrzeuge","es":"Vehículos"}',                                                    'directions_car',   8),
    ('banca',       '{"it":"Banca e Finanza","en":"Banking","fr":"Banque","de":"Bank","es":"Banca"}',                                                                'account_balance',  9),
    ('scuola',      '{"it":"Scuola e Formazione","en":"Education","fr":"Éducation","de":"Bildung","es":"Educación"}',                                                'school',           10)
ON CONFLICT (codice) DO NOTHING;

-- ============================================================
-- DATI: paesi supportati
-- ============================================================
INSERT INTO paesi (codice_iso, nome, lingua_default) VALUES
    ('IT', '{"it":"Italia","en":"Italy","fr":"Italie","de":"Italien","es":"Italia"}',           'it'),
    ('FR', '{"it":"Francia","en":"France","fr":"France","de":"Frankreich","es":"Francia"}',     'fr'),
    ('DE', '{"it":"Germania","en":"Germany","fr":"Allemagne","de":"Deutschland","es":"Alemania"}','de'),
    ('ES', '{"it":"Spagna","en":"Spain","fr":"Espagne","de":"Spanien","es":"España"}',           'es'),
    ('GB', '{"it":"Regno Unito","en":"United Kingdom","fr":"Royaume-Uni","de":"Vereinigtes Königreich","es":"Reino Unido"}', 'en'),
    ('US', '{"it":"Stati Uniti","en":"United States","fr":"États-Unis","de":"Vereinigte Staaten","es":"Estados Unidos"}',   'en'),
    ('EU', '{"it":"Unione Europea","en":"European Union","fr":"Union Européenne","de":"Europäische Union","es":"Unión Europea"}', 'en')
ON CONFLICT (codice_iso) DO NOTHING;

-- ============================================================
-- DATI: libreria documenti (IT — Documenti Personali)
-- ============================================================
INSERT INTO libreria_documenti (codice, nome, descrizione, settore_id, paese_id, parole_chiave, professioni_target, globale) VALUES

-- Documenti personali globali
('carta_identita',
 '{"it":"Carta d''Identità","en":"Identity Card","fr":"Carte d''Identité","de":"Personalausweis","es":"Documento de Identidad"}',
 '{"it":"Documento di riconoscimento personale","en":"Personal identification document"}',
 (SELECT id FROM settori_professionali WHERE codice='personale'),
 NULL, '["carta identità","documento riconoscimento","identità"]', '[]', TRUE),

('patente_guida',
 '{"it":"Patente di Guida","en":"Driving Licence","fr":"Permis de Conduire","de":"Führerschein","es":"Permiso de Conducir"}',
 '{"it":"Licenza di guida per veicoli a motore","en":"Motor vehicle driving licence"}',
 (SELECT id FROM settori_professionali WHERE codice='personale'),
 NULL, '["patente","guida","motorizzazione","licenza guida"]', '[]', TRUE),

('passaporto',
 '{"it":"Passaporto","en":"Passport","fr":"Passeport","de":"Reisepass","es":"Pasaporte"}',
 '{"it":"Documento di viaggio internazionale","en":"International travel document"}',
 (SELECT id FROM settori_professionali WHERE codice='personale'),
 NULL, '["passaporto","viaggio","internazionale"]', '[]', TRUE),

('tessera_sanitaria',
 '{"it":"Tessera Sanitaria","en":"Health Card","fr":"Carte Vitale","de":"Krankenversicherungskarte","es":"Tarjeta Sanitaria"}',
 '{"it":"Codice fiscale e accesso al SSN","en":"Health insurance card"}',
 (SELECT id FROM settori_professionali WHERE codice='personale'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["tessera sanitaria","codice fiscale","ssn","asl"]', '[]', FALSE),

-- IT — Edilizia
('scia',
 '{"it":"SCIA — Segnalazione Certificata di Inizio Attività","en":"SCIA — Certified Notice of Start of Activity"}',
 '{"it":"Procedura edilizia per lavori non soggetti a permesso di costruire","en":"Building procedure for minor works"}',
 (SELECT id FROM settori_professionali WHERE codice='edilizia'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["scia","inizio attività","sportello unico edilizia","sue"]',
 '["geometra","architetto","ingegnere","impresa edile"]', FALSE),

('cila',
 '{"it":"CILA — Comunicazione Inizio Lavori Asseverata","en":"CILA — Certified Works Start Notice"}',
 '{"it":"Comunicazione per interventi di manutenzione straordinaria","en":"Notice for minor maintenance works"}',
 (SELECT id FROM settori_professionali WHERE codice='edilizia'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["cila","manutenzione straordinaria","comunicazione lavori"]',
 '["geometra","architetto","ingegnere"]', FALSE),

('permesso_costruire',
 '{"it":"Permesso di Costruire","en":"Building Permit","fr":"Permis de Construire","de":"Baugenehmigung","es":"Permiso de Construcción"}',
 '{"it":"Autorizzazione per nuove costruzioni o ristrutturazioni rilevanti","en":"Authorization for new buildings or major renovations"}',
 (SELECT id FROM settori_professionali WHERE codice='edilizia'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["permesso costruire","concessione edilizia","edificazione"]',
 '["geometra","architetto","ingegnere","impresa edile"]', FALSE),

('dia',
 '{"it":"DIA — Denuncia di Inizio Attività","en":"DIA — Declaration of Activity Start"}',
 '{"it":"Procedura edilizia alternativa al permesso di costruire","en":"Alternative building procedure"}',
 (SELECT id FROM settori_professionali WHERE codice='edilizia'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["dia","denuncia inizio attività"]',
 '["geometra","architetto","ingegnere"]', FALSE),

('certificato_agibilita',
 '{"it":"Certificato di Agibilità","en":"Habitability Certificate","fr":"Certificat d''Habitabilité"}',
 '{"it":"Attestazione che l''immobile rispetta le norme igienico-sanitarie e di sicurezza","en":"Certificate that building meets safety standards"}',
 (SELECT id FROM settori_professionali WHERE codice='edilizia'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["agibilità","abitabilità","collaudo","sicurezza edificio"]',
 '["geometra","architetto","ingegnere"]', FALSE),

('ape',
 '{"it":"APE — Attestato di Prestazione Energetica","en":"Energy Performance Certificate","fr":"DPE — Diagnostic de Performance Énergétique","de":"Energieausweis"}',
 '{"it":"Classificazione energetica dell''immobile","en":"Building energy rating certificate"}',
 (SELECT id FROM settori_professionali WHERE codice='edilizia'),
 NULL, '["ape","prestazione energetica","classe energetica","certificazione energetica"]',
 '["geometra","architetto","ingegnere","certificatore energetico"]', FALSE),

('relazione_asseverata',
 '{"it":"Relazione Asseverata","en":"Certified Technical Report"}',
 '{"it":"Relazione tecnica firmata e asseverata da professionista abilitato","en":"Technical report certified by a qualified professional"}',
 (SELECT id FROM settori_professionali WHERE codice='edilizia'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["relazione asseverata","relazione tecnica","asseverazione"]',
 '["geometra","architetto","ingegnere"]', FALSE),

-- IT — Legale
('atto_giudiziario',
 '{"it":"Atto Giudiziario","en":"Court Document","fr":"Acte Judiciaire","de":"Gerichtsdokument","es":"Acto Judicial"}',
 '{"it":"Documento prodotto nell''ambito di un procedimento giudiziario","en":"Document produced in court proceedings"}',
 (SELECT id FROM settori_professionali WHERE codice='legale'),
 NULL, '["atto giudiziario","tribunale","procedimento","udienza"]',
 '["avvocato","magistrato","studio legale"]', FALSE),

('ricorso',
 '{"it":"Ricorso","en":"Appeal","fr":"Recours","de":"Beschwerde","es":"Recurso"}',
 '{"it":"Atto con cui si impugna una decisione davanti a un''autorità superiore","en":"Document challenging a decision before a higher authority"}',
 (SELECT id FROM settori_professionali WHERE codice='legale'),
 NULL, '["ricorso","impugnazione","appello","opposizione"]',
 '["avvocato","studio legale"]', FALSE),

('citazione',
 '{"it":"Citazione in Giudizio","en":"Court Summons","fr":"Citation en Justice","de":"Klage"}',
 '{"it":"Atto con cui si convoca la controparte davanti al giudice","en":"Document summoning a party to court"}',
 (SELECT id FROM settori_professionali WHERE codice='legale'),
 NULL, '["citazione","atto di citazione","udienza","convenuto"]',
 '["avvocato"]', FALSE),

('procura',
 '{"it":"Procura","en":"Power of Attorney","fr":"Procuration","de":"Vollmacht","es":"Poder Notarial"}',
 '{"it":"Atto con cui si conferisce a un terzo il potere di agire in nome proprio","en":"Document granting authority to act on someone''s behalf"}',
 (SELECT id FROM settori_professionali WHERE codice='legale'),
 NULL, '["procura","delega","rappresentanza","mandato"]',
 '["avvocato","notaio"]', TRUE),

-- IT — Fiscale
('dichiarazione_redditi',
 '{"it":"Dichiarazione dei Redditi","en":"Tax Return","fr":"Déclaration de Revenus","de":"Steuererklärung","es":"Declaración de la Renta"}',
 '{"it":"Modello 730 o Redditi PF — dichiarazione annuale all''Agenzia delle Entrate","en":"Annual income tax declaration"}',
 (SELECT id FROM settori_professionali WHERE codice='fiscale'),
 NULL, '["730","dichiarazione redditi","modello unico","irpef","agenzia entrate"]',
 '["commercialista","consulente fiscale","caf"]', FALSE),

('f24',
 '{"it":"Modello F24","en":"F24 Payment Form","fr":"Formulaire F24"}',
 '{"it":"Modello per il pagamento di imposte, contributi e premi","en":"Italian tax payment form"}',
 (SELECT id FROM settori_professionali WHERE codice='fiscale'),
 (SELECT id FROM paesi WHERE codice_iso='IT'), '["f24","versamento","imposte","contributi","agenzia entrate"]',
 '["commercialista","consulente fiscale"]', FALSE),

('bilancio',
 '{"it":"Bilancio d''Esercizio","en":"Financial Statements","fr":"Bilan Comptable","de":"Jahresabschluss","es":"Balance de Ejercicio"}',
 '{"it":"Stato patrimoniale e conto economico dell''impresa","en":"Company balance sheet and income statement"}',
 (SELECT id FROM settori_professionali WHERE codice='fiscale'),
 NULL, '["bilancio","stato patrimoniale","conto economico","esercizio"]',
 '["commercialista","revisore contabile"]', FALSE),

('nota_spese',
 '{"it":"Nota Spese","en":"Expense Report","fr":"Note de Frais","de":"Spesenabrechnung","es":"Nota de Gastos"}',
 '{"it":"Riepilogo delle spese sostenute per conto dell''azienda","en":"Summary of business expenses incurred"}',
 (SELECT id FROM settori_professionali WHERE codice='fiscale'),
 NULL, '["nota spese","rimborso spese","spese aziendali","trasferta"]',
 '[]', TRUE),

-- Lavoro
('busta_paga',
 '{"it":"Busta Paga","en":"Payslip","fr":"Fiche de Paie","de":"Gehaltsabrechnung","es":"Nómina"}',
 '{"it":"Cedolino paga mensile del lavoratore dipendente","en":"Monthly salary statement"}',
 (SELECT id FROM settori_professionali WHERE codice='lavoro'),
 NULL, '["busta paga","cedolino","stipendio","retribuzione","netto","lordo"]',
 '[]', TRUE),

('contratto_lavoro',
 '{"it":"Contratto di Lavoro","en":"Employment Contract","fr":"Contrat de Travail","de":"Arbeitsvertrag","es":"Contrato de Trabajo"}',
 '{"it":"Accordo tra datore di lavoro e dipendente","en":"Agreement between employer and employee"}',
 (SELECT id FROM settori_professionali WHERE codice='lavoro'),
 NULL, '["contratto lavoro","rapporto lavoro","assunzione","mansione","ccnl"]',
 '[]', TRUE),

-- Sanitario
('referto_medico',
 '{"it":"Referto Medico","en":"Medical Report","fr":"Rapport Médical","de":"Ärztlicher Bericht","es":"Informe Médico"}',
 '{"it":"Documento rilasciato da un medico con esito di una visita o esame","en":"Document issued by a doctor with examination results"}',
 (SELECT id FROM settori_professionali WHERE codice='sanitario'),
 NULL, '["referto","visita medica","diagnosi","terapia","medico"]',
 '["medico","specialista"]', TRUE),

('prescrizione_medica',
 '{"it":"Ricetta Medica","en":"Prescription","fr":"Ordonnance","de":"Rezept","es":"Receta Médica"}',
 '{"it":"Prescrizione farmaceutica o di esami diagnostici","en":"Medical prescription for drugs or diagnostic tests"}',
 (SELECT id FROM settori_professionali WHERE codice='sanitario'),
 NULL, '["ricetta","prescrizione","farmaco","dosaggio","medico curante"]',
 '["medico","specialista"]', TRUE),

-- Casa
('contratto_affitto',
 '{"it":"Contratto di Locazione","en":"Rental Agreement","fr":"Bail Locatif","de":"Mietvertrag","es":"Contrato de Alquiler"}',
 '{"it":"Contratto tra locatore e conduttore per uso abitativo o commerciale","en":"Contract between landlord and tenant"}',
 (SELECT id FROM settori_professionali WHERE codice='casa'),
 NULL, '["affitto","locazione","contratto affitto","locatore","conduttore","canone"]',
 '["agente immobiliare"]', TRUE),

('atto_notarile',
 '{"it":"Rogito Notarile","en":"Notarial Deed","fr":"Acte Notarié","de":"Notarieller Akt","es":"Escritura Notarial"}',
 '{"it":"Atto pubblico redatto da un notaio per compravendita immobiliare o altro","en":"Public deed drafted by a notary"}',
 (SELECT id FROM settori_professionali WHERE codice='casa'),
 NULL, '["rogito","atto notarile","compravendita","notaio","ipoteca"]',
 '["notaio","agente immobiliare"]', TRUE),

-- Auto
('assicurazione_auto',
 '{"it":"Polizza RCA — Assicurazione Auto","en":"Car Insurance","fr":"Assurance Auto","de":"Kfz-Versicherung","es":"Seguro de Coche"}',
 '{"it":"Responsabilità civile auto obbligatoria per legge","en":"Mandatory car liability insurance"}',
 (SELECT id FROM settori_professionali WHERE codice='auto'),
 NULL, '["rca","assicurazione auto","polizza auto","attestato rischio","classe merito"]',
 '[]', FALSE),

('libretto_circolazione',
 '{"it":"Carta di Circolazione","en":"Vehicle Registration","fr":"Carte Grise","de":"Fahrzeugbrief","es":"Permiso de Circulación"}',
 '{"it":"Documento che certifica la registrazione del veicolo","en":"Document certifying vehicle registration"}',
 (SELECT id FROM settori_professionali WHERE codice='auto'),
 NULL, '["libretto circolazione","carta circolazione","targa","immatricolazione","telaio"]',
 '[]', FALSE),

-- Banca
('estratto_conto',
 '{"it":"Estratto Conto Bancario","en":"Bank Statement","fr":"Relevé de Compte","de":"Kontoauszug","es":"Extracto Bancario"}',
 '{"it":"Riepilogo movimenti del conto corrente","en":"Summary of bank account transactions"}',
 (SELECT id FROM settori_professionali WHERE codice='banca'),
 NULL, '["estratto conto","movimenti","saldo","banca","conto corrente","iban"]',
 '[]', TRUE),

('bonifico',
 '{"it":"Bonifico Bancario","en":"Bank Transfer","fr":"Virement Bancaire","de":"Banküberweisung","es":"Transferencia Bancaria"}',
 '{"it":"Ordine di pagamento tra conti correnti","en":"Payment order between bank accounts"}',
 (SELECT id FROM settori_professionali WHERE codice='banca'),
 NULL, '["bonifico","trasferimento","iban","sepa","beneficiario"]',
 '[]', TRUE)

ON CONFLICT DO NOTHING;

-- ============================================================
-- TRIGGER aggiornamento dispositivi
-- ============================================================
CREATE OR REPLACE FUNCTION aggiorna_timestamp_dispositivo()
RETURNS TRIGGER AS $$
BEGIN
    NEW.aggiornato_il = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_dispositivi_aggiornato
    BEFORE UPDATE ON dispositivi_utente
    FOR EACH ROW EXECUTE FUNCTION aggiorna_timestamp_dispositivo();

-- ============================================================
-- MIGRAZIONE: migration_v4.sql
-- ============================================================
-- ============================================================
-- VEMORA — Migration V4 — Modulo Invio (engine interno)
-- Ideatore: Devoti Massimo
-- Regola: tutte le tabelle sono append-only — nessun UPDATE.
-- ============================================================

-- ── Tabella eventi invio ────────────────────────────────────
CREATE TABLE IF NOT EXISTS eventi_invio (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    mittente_id     UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    documento_id    UUID REFERENCES documenti(id) ON DELETE SET NULL,
    destinatario    TEXT NOT NULL,
    oggetto         TEXT,
    corpo           TEXT,
    allegato_nome   TEXT,
    allegato_hash   TEXT,
    stato           TEXT NOT NULL DEFAULT 'creato',
    token_invio     TEXT UNIQUE,
    creato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_eventi_mittente ON eventi_invio(mittente_id);
CREATE INDEX IF NOT EXISTS idx_eventi_stato    ON eventi_invio(stato);
CREATE INDEX IF NOT EXISTS idx_eventi_token    ON eventi_invio(token_invio);
CREATE INDEX IF NOT EXISTS idx_eventi_creato   ON eventi_invio(creato_il DESC);

-- ── Tabella timeline — separata, immutabile, append-only ────
-- Ogni cambio di stato è una nuova riga. Nessun UPDATE.
CREATE TABLE IF NOT EXISTS timeline_eventi (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    evento_id       UUID NOT NULL REFERENCES eventi_invio(id) ON DELETE CASCADE,
    stato           TEXT NOT NULL,
                    -- creato | inviato | consegnato | aperto | scaduto | errore
    dettaglio       TEXT,
    registrato_il   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_timeline_evento    ON timeline_eventi(evento_id);
CREATE INDEX IF NOT EXISTS idx_timeline_registrato ON timeline_eventi(registrato_il);

-- ============================================================
-- MIGRAZIONE: migration_v4b.sql
-- ============================================================
-- ============================================================
-- VEMORA — Migration V4b
-- Aggiunge allegato_hash a timeline_eventi
-- La timeline diventa autosufficiente per il proof bundle.
-- ============================================================
ALTER TABLE timeline_eventi
    ADD COLUMN IF NOT EXISTS allegato_hash TEXT;

-- ============================================================
-- MIGRAZIONE: migration_v5.sql
-- ============================================================
-- ============================================================
-- VEMORA — Migration V5 — Relazioni documento
-- ============================================================
CREATE TABLE IF NOT EXISTS relazioni_documento (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id    UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    tipo_relazione  TEXT NOT NULL,   -- persona | luogo | evento
    riferimento     TEXT NOT NULL,   -- nome, luogo, descrizione evento
    note            TEXT,
    creato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_relazioni_documento ON relazioni_documento(documento_id);
CREATE INDEX IF NOT EXISTS idx_relazioni_tipo      ON relazioni_documento(tipo_relazione);

-- ============================================================
-- MIGRAZIONE: migration_v6.sql
-- ============================================================
-- ============================================================
-- VEMORA V2.5 — Migration V6
-- Aggiunge stato_evento e data_scadenza a eventi_invio.
-- Append-only: nessun UPDATE sui record esistenti.
-- ============================================================

ALTER TABLE eventi_invio
    ADD COLUMN IF NOT EXISTS stato_evento  TEXT NOT NULL DEFAULT 'in_attesa',
    ADD COLUMN IF NOT EXISTS data_scadenza TIMESTAMPTZ;

-- Aggiorna i record esistenti con scadenza 72h da creato_il
UPDATE eventi_invio
   SET stato_evento  = 'in_attesa',
       data_scadenza = creato_il + INTERVAL '72 hours'
 WHERE data_scadenza IS NULL;

CREATE INDEX IF NOT EXISTS idx_eventi_stato_evento  ON eventi_invio(stato_evento);
CREATE INDEX IF NOT EXISTS idx_eventi_data_scadenza ON eventi_invio(data_scadenza);

COMMENT ON COLUMN eventi_invio.stato_evento IS
    'Ciclo di vita VERO: in_attesa | archiviato | scaduto | distrutto';
COMMENT ON COLUMN eventi_invio.data_scadenza IS
    'Scadenza accesso: creato_il + 72h (calcolata automaticamente)';

-- ============================================================
-- MIGRAZIONE: migration_v7.sql
-- ============================================================
-- VEMORA V2.5 — Migration V7 — Notifiche eventi invio
CREATE TABLE IF NOT EXISTS notifiche_invio (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    evento_id   UUID NOT NULL REFERENCES eventi_invio(id) ON DELETE CASCADE,
    tipo        TEXT NOT NULL,   -- 'scaduto' | 'distrutto'
    messaggio   TEXT NOT NULL,
    registrata_il TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_notifiche_evento ON notifiche_invio(evento_id);

-- ============================================================
-- MIGRAZIONE: migration_v8.sql
-- ============================================================
-- VEMORA V2.6 — Migration V8 — Capacità dispositivo
ALTER TABLE dispositivi_utente
    ADD COLUMN IF NOT EXISTS camera_ok  BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS mic_ok     BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS file_ok    BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS pdf_ok     BOOLEAN NOT NULL DEFAULT TRUE;

-- ============================================================
-- MIGRAZIONE: migration_v9.sql
-- ============================================================
-- VEMORA V2.8 — Migration V9
-- Relazioni doc-to-doc + entità estratte

-- Relazioni documento ↔ documento/evento/dossier/entità
CREATE TABLE IF NOT EXISTS relazioni_documenti (
    relazione_id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_origine   UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    documento_destinazione UUID,          -- NULL se destinazione non è un documento
    tipo_relazione      TEXT NOT NULL,    -- 'documento'|'evento'|'dossier'|'entita'
    etichetta           TEXT,             -- descrizione libera del legame
    data_creazione      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_reldoc_origine ON relazioni_documenti(documento_origine);
CREATE INDEX IF NOT EXISTS idx_reldoc_dest    ON relazioni_documenti(documento_destinazione);

-- ============================================================
-- MIGRAZIONE: migration_v10.sql
-- ============================================================
-- VEMORA V2.9 — Migration V10
-- Alert documenti + indici ottimizzazione archivio

CREATE TABLE IF NOT EXISTS document_alert (
    alert_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id   UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    tipo_alert     TEXT NOT NULL,   -- 'scadenza_vicina'|'scaduto'|'azione_richiesta'
    messaggio      TEXT NOT NULL,
    data_creazione TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    letto          BOOLEAN NOT NULL DEFAULT FALSE
);
CREATE INDEX IF NOT EXISTS idx_alert_documento ON document_alert(documento_id);
CREATE INDEX IF NOT EXISTS idx_alert_letto     ON document_alert(letto);

-- Indici ottimizzazione archivio
CREATE INDEX IF NOT EXISTS idx_memorie_tipo_documento ON memorie(tipo_documento);
CREATE INDEX IF NOT EXISTS idx_memorie_creata_il      ON memorie(creata_il DESC);
CREATE INDEX IF NOT EXISTS idx_documenti_tipo_id      ON documenti(tipo_documento_id);

-- ============================================================
-- MIGRAZIONE: migration_v11.sql
-- ============================================================
-- VEMORA V3.0 — Migration V11 — Document Lifecycle System
CREATE TABLE IF NOT EXISTS document_lifecycle (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    stato        TEXT NOT NULL,
    descrizione  TEXT,
    creato_il    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    origine      TEXT NOT NULL DEFAULT 'sistema'
);
CREATE INDEX IF NOT EXISTS idx_lifecycle_documento ON document_lifecycle(documento_id);
CREATE INDEX IF NOT EXISTS idx_lifecycle_stato     ON document_lifecycle(stato);
CREATE INDEX IF NOT EXISTS idx_lifecycle_creato    ON document_lifecycle(creato_il DESC);

-- ============================================================
-- MIGRAZIONE: migration_v12.sql
-- ============================================================
-- VEMORA V3.1 — Migration V12 — Document Event Engine
CREATE TABLE IF NOT EXISTS document_event (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tipo_evento  TEXT NOT NULL,
    descrizione  TEXT,
    foto_path    TEXT,
    documento_id UUID REFERENCES documenti(id) ON DELETE SET NULL,
    dossier_id   UUID REFERENCES dossier(id)   ON DELETE SET NULL,
    utente_id    UUID NOT NULL,
    creato_il    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_doc_event_documento ON document_event(documento_id);
CREATE INDEX IF NOT EXISTS idx_doc_event_dossier   ON document_event(dossier_id);
CREATE INDEX IF NOT EXISTS idx_doc_event_utente    ON document_event(utente_id);
CREATE INDEX IF NOT EXISTS idx_doc_event_creato    ON document_event(creato_il DESC);

-- ============================================================
-- MIGRAZIONE: migration_v13.sql
-- ============================================================
-- VEMORA V3.2 — Migration V13 — Entity Engine
CREATE TABLE IF NOT EXISTS entity (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tipo_entity   TEXT NOT NULL,   -- persona|azienda|ente
    nome          TEXT NOT NULL,
    identificativo TEXT,           -- CF, P.IVA, codice ente
    note          TEXT,
    creato_il     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tipo_entity, nome, identificativo)
);
CREATE INDEX IF NOT EXISTS idx_entity_tipo ON entity(tipo_entity);
CREATE INDEX IF NOT EXISTS idx_entity_nome ON entity(nome);

CREATE TABLE IF NOT EXISTS entity_link (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_id   UUID NOT NULL REFERENCES entity(id) ON DELETE CASCADE,
    tipo_target TEXT NOT NULL,  -- documento|evento|dossier
    target_id   UUID NOT NULL,
    ruolo       TEXT,
    creato_il   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_entity_link_entity ON entity_link(entity_id);
CREATE INDEX IF NOT EXISTS idx_entity_link_target ON entity_link(target_id);

-- ============================================================
-- MIGRAZIONE: migration_v14.sql
-- ============================================================
-- VEMORA V3.3 — Migration V14 — Automation / Workflow Engine
CREATE TABLE IF NOT EXISTS automation_rule (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tipo_trigger TEXT NOT NULL,
    tipo_target  TEXT NOT NULL,
    condizione   JSONB,
    azione       TEXT NOT NULL,
    attiva       BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_rule_trigger ON automation_rule(tipo_trigger);
CREATE INDEX IF NOT EXISTS idx_rule_target  ON automation_rule(tipo_target);
CREATE INDEX IF NOT EXISTS idx_rule_attiva  ON automation_rule(attiva);

CREATE TABLE IF NOT EXISTS automation_event (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rule_id     UUID NOT NULL REFERENCES automation_rule(id) ON DELETE CASCADE,
    target_tipo TEXT NOT NULL,
    target_id   UUID NOT NULL,
    stato       TEXT NOT NULL DEFAULT 'eseguito',
    creato_il   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_event_rule   ON automation_event(rule_id);
CREATE INDEX IF NOT EXISTS idx_event_target ON automation_event(target_id);

-- ============================================================
-- MIGRAZIONE: migration_v15.sql
-- ============================================================
-- VEMORA V3.4 — Migration V15 — Document Timeline Engine
CREATE TABLE IF NOT EXISTS timeline_event (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    target_tipo TEXT NOT NULL,
    target_id   UUID NOT NULL,
    tipo_evento TEXT NOT NULL,
    origine     TEXT NOT NULL,
    descrizione TEXT,
    metadata    JSONB,
    creato_il   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_timeline_target ON timeline_event(target_tipo, target_id);
CREATE INDEX IF NOT EXISTS idx_timeline_tipo   ON timeline_event(tipo_evento);
CREATE INDEX IF NOT EXISTS idx_timeline_data   ON timeline_event(creato_il DESC);

-- ============================================================
-- MIGRAZIONE: migration_v16.sql
-- ============================================================
-- VEMORA V3.5 — Migration V16 — Document Intelligence Layer
CREATE TABLE IF NOT EXISTS document_insight (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id UUID NOT NULL,
    tipo_insight TEXT NOT NULL,
    valore       TEXT NOT NULL,
    confidenza   FLOAT NOT NULL DEFAULT 0.5,
    creato_il    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_insight_documento ON document_insight(documento_id);
CREATE INDEX IF NOT EXISTS idx_insight_tipo      ON document_insight(tipo_insight);

-- ============================================================
-- MIGRAZIONE: migration_v17.sql
-- ============================================================
-- VEMORA V3.6 — Migration V17 — Search & Knowledge Engine
CREATE TABLE IF NOT EXISTS search_index (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    target_tipo TEXT NOT NULL,
    target_id   UUID NOT NULL,
    contenuto   TEXT NOT NULL,
    creato_il   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (target_tipo, target_id)
);
CREATE INDEX IF NOT EXISTS idx_search_tipo     ON search_index(target_tipo);
CREATE INDEX IF NOT EXISTS idx_search_contenuto ON search_index USING gin(to_tsvector('italian', contenuto));

-- ============================================================
-- MIGRAZIONE: migration_v18.sql
-- ============================================================
-- VEMORA V3.7 — Migration V18 — Metadata Engine
CREATE TABLE IF NOT EXISTS document_metadata (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id UUID NOT NULL,
    chiave       TEXT NOT NULL,
    valore       TEXT NOT NULL,
    origine      TEXT NOT NULL DEFAULT 'sistema',
    creato_il    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (documento_id, chiave)
);
CREATE INDEX IF NOT EXISTS idx_metadata_documento ON document_metadata(documento_id);
CREATE INDEX IF NOT EXISTS idx_metadata_chiave    ON document_metadata(chiave);
CREATE INDEX IF NOT EXISTS idx_metadata_valore    ON document_metadata(valore);

-- ============================================================
-- MIGRAZIONE: migration_v19.sql
-- ============================================================
-- VEMORA V3.8 — Migration V19 — Performance Layer
-- Indici composti e ottimizzazioni query

-- document_metadata: chiave+valore per lookup rapido
CREATE INDEX IF NOT EXISTS idx_metadata_chiave_valore
    ON document_metadata(chiave, valore);

-- search_index: ricerca testuale già coperta da GIN V17
-- Aggiunta indice su creato_il per ordinamento
CREATE INDEX IF NOT EXISTS idx_search_creato
    ON search_index(creato_il DESC);

-- document_insight: tipo+confidenza per filtri per qualità
CREATE INDEX IF NOT EXISTS idx_insight_tipo_conf
    ON document_insight(tipo_insight, confidenza DESC);

-- timeline_event: indice composto per query principale
CREATE INDEX IF NOT EXISTS idx_timeline_compound
    ON timeline_event(target_tipo, target_id, creato_il DESC);

-- document_lifecycle: indice su documento+creato per timeline sintetica
CREATE INDEX IF NOT EXISTS idx_lifecycle_doc_data
    ON document_lifecycle(documento_id, creato_il DESC);

-- ============================================================
-- MIGRAZIONE: migration_v20.sql
-- ============================================================
-- VEMORA V3.9 — Migration V20 — Security System
CREATE TABLE IF NOT EXISTS security_log (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tipo_evento TEXT NOT NULL,
    target_tipo TEXT,
    target_id   UUID,
    descrizione TEXT,
    creato_il   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_seclog_tipo    ON security_log(tipo_evento);
CREATE INDEX IF NOT EXISTS idx_seclog_target  ON security_log(target_tipo, target_id);
CREATE INDEX IF NOT EXISTS idx_seclog_data    ON security_log(creato_il DESC);

-- ============================================================
-- MIGRAZIONE: migration_v21.sql
-- ============================================================
-- VEMORA V4.0 — Migration V21 — Storage Architecture
ALTER TABLE documenti
    ADD COLUMN IF NOT EXISTS storage_tier   TEXT NOT NULL DEFAULT 'HOT',
    ADD COLUMN IF NOT EXISTS last_accessed  TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS access_count   INTEGER NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_doc_tier         ON documenti(storage_tier);
CREATE INDEX IF NOT EXISTS idx_doc_last_accessed ON documenti(last_accessed DESC);
CREATE INDEX IF NOT EXISTS idx_doc_access_count  ON documenti(access_count DESC);

-- ============================================================
-- MIGRAZIONE: migration_v22.sql
-- ============================================================
-- VEMORA V4.3 — Migration V22 — Document + Search + Memory Final

-- Document duplicates + versions
ALTER TABLE documenti
    ADD COLUMN IF NOT EXISTS is_duplicate    BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS originale_id    UUID REFERENCES documenti(id),
    ADD COLUMN IF NOT EXISTS versione_doc    INTEGER NOT NULL DEFAULT 1,
    ADD COLUMN IF NOT EXISTS parent_version_id UUID REFERENCES documenti(id),
    ADD COLUMN IF NOT EXISTS location_tag   TEXT;

-- Memory enhancements
ALTER TABLE memorie
    ADD COLUMN IF NOT EXISTS location_tag   TEXT,
    ADD COLUMN IF NOT EXISTS is_deleted     BOOLEAN NOT NULL DEFAULT FALSE;

CREATE INDEX IF NOT EXISTS idx_doc_duplicate    ON documenti(is_duplicate);
CREATE INDEX IF NOT EXISTS idx_doc_originale    ON documenti(originale_id);
CREATE INDEX IF NOT EXISTS idx_doc_parent_ver   ON documenti(parent_version_id);
CREATE INDEX IF NOT EXISTS idx_doc_location     ON documenti(location_tag);
CREATE INDEX IF NOT EXISTS idx_mem_location     ON memorie(location_tag);
CREATE INDEX IF NOT EXISTS idx_mem_deleted      ON memorie(is_deleted);

-- ============================================================
-- MIGRAZIONE: migration_v23.sql
-- ============================================================
-- VEMORA V4.5 Performance Patch — Migration V23
-- Indici mancanti identificati in test di carico (3000 doc, 6000 timeline, 4500 search_index)

-- 1. Archivio: indice composito per query proprietario_id + stato + creata_il
CREATE INDEX IF NOT EXISTS idx_memorie_owner_stato_data
    ON memorie(proprietario_id, stato, creata_il DESC)
    WHERE stato = 'attiva';

-- 2. Duplicate detection: indice funzionale su prefisso testo OCR
CREATE INDEX IF NOT EXISTS idx_doc_testo_prefix
    ON documenti(LEFT(testo_grezzo, 200))
    WHERE testo_grezzo IS NOT NULL;

-- 3. Search FTS: aggiunge indice pg_trgm per ILIKE efficiente
-- (fallback se GIN tsvector non usato dalla query ILIKE)
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE INDEX IF NOT EXISTS idx_search_trgm
    ON search_index USING gin(contenuto gin_trgm_ops);

-- 4. Performance stats: indici parziali per COUNT veloci
CREATE INDEX IF NOT EXISTS idx_timeline_count
    ON timeline_event(target_tipo) INCLUDE (id);

CREATE INDEX IF NOT EXISTS idx_insight_count
    ON document_insight(documento_id) INCLUDE (id);

-- 5. Document event: indice su documento_id per hook lookup rapido
CREATE INDEX IF NOT EXISTS idx_doc_event_documento
    ON document_event(documento_id, creato_il DESC);

-- 6. Metadata per utente: lookup preferenze localization
CREATE INDEX IF NOT EXISTS idx_metadata_origine
    ON document_metadata(origine);

-- ============================================================
-- MIGRAZIONE: migration_v24.sql
-- ============================================================
-- VEMORA V4.5 PATCH — Migration V24
-- Fix FK originale_id ON DELETE SET NULL
-- Fix parent_version_id ON DELETE SET NULL  
-- Exclude is_deleted memorie from search

-- Drop old FK if exists and re-add with ON DELETE SET NULL
ALTER TABLE documenti
    DROP CONSTRAINT IF EXISTS documenti_originale_id_fkey,
    DROP CONSTRAINT IF EXISTS documenti_parent_version_id_fkey;

ALTER TABLE documenti
    ADD CONSTRAINT documenti_originale_id_fkey
        FOREIGN KEY (originale_id) REFERENCES documenti(id) ON DELETE SET NULL,
    ADD CONSTRAINT documenti_parent_version_id_fkey
        FOREIGN KEY (parent_version_id) REFERENCES documenti(id) ON DELETE SET NULL;

-- Index to exclude deleted memorie efficiently
CREATE INDEX IF NOT EXISTS idx_memorie_active
    ON memorie(proprietario_id, creata_il DESC)
    WHERE is_deleted = FALSE;

-- Exclude in_attesa_utente from default archivio if stato filter not applied
CREATE INDEX IF NOT EXISTS idx_doc_stato_owner
    ON documenti(proprietario_id, stato_elaborazione);

-- ============================================================
-- MIGRAZIONE: migration_v25.sql
-- ============================================================
-- VEMORA V4.5.1 — Migration V25
-- Estende tipi_documento con sottocategoria, parole_chiave, has_scadenza
-- Idempotente

ALTER TABLE tipi_documento
    ADD COLUMN IF NOT EXISTS sottocategoria  TEXT,
    ADD COLUMN IF NOT EXISTS parole_chiave   TEXT[],
    ADD COLUMN IF NOT EXISTS has_scadenza    BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS macro_categoria TEXT;

CREATE INDEX IF NOT EXISTS idx_tipo_doc_macro ON tipi_documento(macro_categoria);
CREATE INDEX IF NOT EXISTS idx_tipo_doc_cat   ON tipi_documento(categoria);

-- ============================================================
-- FALLBACK VIEW: macro_categoria per documenti non riconosciuti
-- Se codice non trovato in tipi_documento, assegna macro dal testo
-- ============================================================
CREATE OR REPLACE VIEW v_fallback_macro AS
SELECT
    codice,
    etichetta,
    macro_categoria,
    sottocategoria,
    parole_chiave,
    has_scadenza
FROM tipi_documento
WHERE attivo = TRUE;

-- Index per ricerca rapida per parole_chiave (GIN su array)
CREATE INDEX IF NOT EXISTS idx_tipo_doc_keywords ON tipi_documento USING gin(parole_chiave);

-- Funzione helper: dato un testo OCR, trova macro_categoria probabile

-- ============================================================
-- FALLBACK: guess_macro_categoria
-- Dato testo OCR, restituisce macro_categoria piu probabile.
-- Fallback finale garantito: 'generico'
-- ============================================================
CREATE OR REPLACE FUNCTION guess_macro_categoria(testo_ocr TEXT)
RETURNS TEXT AS $$
DECLARE
    result      TEXT;
    testo_lower TEXT;
BEGIN
    IF testo_ocr IS NULL OR length(trim(testo_ocr)) < 3 THEN
        RETURN 'generico';
    END IF;

    testo_lower := lower(testo_ocr);

    -- 1. Cerca corrispondenza parole_chiave tramite GIN index
    SELECT macro_categoria INTO result
    FROM tipi_documento
    WHERE attivo = TRUE
      AND parole_chiave IS NOT NULL
      AND parole_chiave && string_to_array(
            regexp_replace(testo_lower, '[^a-z0-9 ]', ' ', 'g'), ' ')
    ORDER BY array_length(
        ARRAY(
            SELECT unnest(parole_chiave)
            INTERSECT
            SELECT unnest(string_to_array(
                regexp_replace(testo_lower, '[^a-z0-9 ]', ' ', 'g'), ' '))
        ), 1
    ) DESC NULLS LAST
    LIMIT 1;

    IF result IS NOT NULL THEN
        RETURN result;
    END IF;

    -- 2. Fallback per pattern comuni italiani nel testo OCR
    -- Ordine: più specifico prima
    RETURN CASE
        WHEN testo_lower ~ '(cantiere|psc |pos |dvr|duvri|rspp|durc|collaudo statico|computo metrico|capitolato|vvf |cpi |superbonus|ecobonus|sismabonus|scia edilizia|cila|permesso di costruire|agibilita)' THEN 'cantiere_edilizia'
        WHEN testo_lower ~ '(universita degli studi|universita di|universita statale|corso di laurea|laurea magistrale|laurea triennale|diploma di laurea|facolta|ateneo|ecdl|icdl|patente europea computer|pagella scolastica|iscrizione scolastica|crediti formativi|attestato di frequenza)' THEN 'scuola'
        WHEN testo_lower ~ '(visura camerale|registro delle imprese|registro imprese|partita iva|s\.r\.l\.|s\.p\.a\.|statuto|rea |attivita commerciale|bilancio|sede legale)' THEN 'impresa'
        WHEN testo_lower ~ '(decreto ingiuntivo|atto notarile|sentenza|tribunale|avvocato|ricorso|diffida|pignoramento|successione|lodo arbitrale|mediazione|citazione)' THEN 'legale'
        WHEN testo_lower ~ '(busta paga|cedolino|contratto di lavoro|ccnl|assunzione|licenziamento|dimissioni|inps|tfr|liquidazione)' THEN 'lavoro'
        WHEN testo_lower ~ '(irpef|f24|dichiarazione dei redditi|agenzia delle entrate|730 |modello unico|imu |tari |cartella esattoriale|avviso di accertamento)' THEN 'fisco'
        WHEN testo_lower ~ '(fattura|bonifico|conto corrente|mutuo|prestito|leasing|estratto conto|tasso|spread bancario|taeg|tan)' THEN 'banca'
        WHEN testo_lower ~ '(carta d identita|passaporto|patente di guida|codice fiscale|tessera sanitaria|stato di famiglia|atto di nascita|matrimonio|residenza)' THEN 'identita'
        WHEN testo_lower ~ '(referto|diagnosi|ricetta medica|ospedale|asl |paziente|terapia|farmac|analisi cliniche|ecografia|risonanza|biopsia)' THEN 'salute'
        WHEN testo_lower ~ '(contratto di affitto|contratto di locazione|rogito|catasto|visura catastale|condominio|agibilita|planimetria)' THEN 'casa'
        WHEN testo_lower ~ '(polizza|sinistro|premio assicurativo|constatazione amichevole|attestato di rischio|bonus malus|denuncia sinistro)' THEN 'assicurazioni'
        WHEN testo_lower ~ '(libretto di circolazione|immatricolazione|revisione auto|bollo auto|moto|veicolo|targa|perizia auto|stima veicolo|collaudo motorizzazione)' THEN 'veicoli'
        WHEN testo_lower ~ '(bolletta|energia elettrica|gas naturale|acqua potabile|fibra ottica|internet|kwh|consumo energetico)' THEN 'utenze'
        ELSE 'generico'
    END;
END;
$$ LANGUAGE plpgsql STABLE;

-- ============================================================
-- MIGRAZIONE: migration_v26.sql
-- ============================================================
-- VEMORA V4.6 — Migration V26
-- Copyright Engine + Accettazione Preventivo Engine

-- ── Funzione 1: Copyright ─────────────────────────────────────
ALTER TABLE documenti
    ADD COLUMN IF NOT EXISTS copyright_protected   BOOLEAN   NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS copyright_author      TEXT,
    ADD COLUMN IF NOT EXISTS copyright_timestamp   TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS copyright_hash        TEXT;

CREATE INDEX IF NOT EXISTS idx_doc_copyright ON documenti(copyright_protected)
    WHERE copyright_protected = TRUE;

-- ── Funzione 2: Accettazione Preventivo ───────────────────────
ALTER TABLE eventi_invio
    ADD COLUMN IF NOT EXISTS richiesta_accettazione    BOOLEAN   NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS accettazione_stato        TEXT      NOT NULL DEFAULT 'pending'
        CHECK (accettazione_stato IN ('pending','accettato','rifiutato')),
    ADD COLUMN IF NOT EXISTS accettazione_timestamp    TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS accettazione_destinatario TEXT,
    ADD COLUMN IF NOT EXISTS accettazione_hash_doc     TEXT,
    ADD COLUMN IF NOT EXISTS accettazione_token        TEXT UNIQUE; -- token sicuro per UI

CREATE INDEX IF NOT EXISTS idx_invio_accettazione
    ON eventi_invio(richiesta_accettazione, accettazione_stato)
    WHERE richiesta_accettazione = TRUE;

CREATE INDEX IF NOT EXISTS idx_invio_token
    ON eventi_invio(accettazione_token)
    WHERE accettazione_token IS NOT NULL;


-- ============================================================
-- TRANSFER TABLE — V4.6 P2P File Transfer
-- Aggiunta come estensione, non modifica tabelle esistenti
-- ============================================================
CREATE TABLE IF NOT EXISTS transfer (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sender_id       UUID NOT NULL,
    receiver_id     UUID,
    file_path       TEXT NOT NULL,
    original_name   TEXT NOT NULL,
    file_size       BIGINT NOT NULL DEFAULT 0,
    file_hash       TEXT,                          -- SHA-256 calcolato server-side al momento dell'upload
    evento_invio_id UUID REFERENCES eventi_invio(id) ON DELETE SET NULL,  -- collegamento proof
    oggetto         TEXT,                          -- oggetto del trasferimento (per il proof)
    corpo           TEXT,                          -- messaggio accompagnatorio
    status          TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending', 'downloaded', 'received', 'expired')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at      TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '24 hours')
);

CREATE INDEX IF NOT EXISTS idx_transfer_sender    ON transfer(sender_id);
CREATE INDEX IF NOT EXISTS idx_transfer_status    ON transfer(status);
CREATE INDEX IF NOT EXISTS idx_transfer_expires   ON transfer(expires_at);

-- ── Unknown Document Candidates — V4.6 ─────────────────────────
-- Apprendimento controllato: documenti non riconosciuti con confidenza < 0.30
CREATE TABLE IF NOT EXISTS unknown_document_candidates (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id    UUID REFERENCES documenti(id) ON DELETE CASCADE,
    memoria_id      UUID REFERENCES memorie(id)   ON DELETE SET NULL,
    testo_ocr       TEXT,
    keyword_estratte TEXT[],
    tipo_probabile  TEXT,
    confidenza      FLOAT NOT NULL DEFAULT 0.0,
    categoria_guess TEXT,
    fingerprint     TEXT,
    nome_file       TEXT,
    occorrenze      INTEGER NOT NULL DEFAULT 1,
    prima_vista_il  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ultima_vista_il TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    stato           TEXT NOT NULL DEFAULT 'candidato'
                    CHECK (stato IN ('candidato', 'ricorrente', 'validato', 'scartato')),
    note            TEXT,
    creato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_udc_fingerprint ON unknown_document_candidates(fingerprint) WHERE stato IN ('candidato','ricorrente');
CREATE INDEX IF NOT EXISTS idx_udc_stato       ON unknown_document_candidates(stato);
CREATE INDEX IF NOT EXISTS idx_udc_categoria   ON unknown_document_candidates(categoria_guess);

-- ── Migration V26b — tipo_invio su eventi_invio (rinominato: era duplicato con V26) ──
ALTER TABLE eventi_invio
    ADD COLUMN IF NOT EXISTS tipo_invio TEXT NOT NULL DEFAULT 'standard'
        CHECK (tipo_invio IN ('standard', 'copyright', 'convalida'));
CREATE INDEX IF NOT EXISTS idx_eventi_tipo_invio ON eventi_invio(tipo_invio);

-- ── Migration V27 — firma + timestamp su eventi_invio ─────────
ALTER TABLE eventi_invio
    ADD COLUMN IF NOT EXISTS firma_tipo   TEXT NOT NULL DEFAULT 'none'
        CHECK (firma_tipo IN ('none', 'operativa', 'fea', 'digitale')),
    ADD COLUMN IF NOT EXISTS firma_stato  TEXT NOT NULL DEFAULT 'none'
        CHECK (firma_stato IN ('none', 'richiesta', 'completata', 'rifiutata', 'errore')),
    ADD COLUMN IF NOT EXISTS firmato_il          TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS file_firmato_path   TEXT,
    ADD COLUMN IF NOT EXISTS certificate_info    JSONB,
    ADD COLUMN IF NOT EXISTS provider            TEXT,
    ADD COLUMN IF NOT EXISTS provider_request_id TEXT,
    ADD COLUMN IF NOT EXISTS provider_status     TEXT,
    ADD COLUMN IF NOT EXISTS timestamp_tipo   TEXT NOT NULL DEFAULT 'none'
        CHECK (timestamp_tipo IN ('none', 'interno', 'certificato')),
    ADD COLUMN IF NOT EXISTS timestamp_valore TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS timestamp_token  TEXT;
CREATE INDEX IF NOT EXISTS idx_eventi_firma_tipo  ON eventi_invio(firma_tipo);
CREATE INDEX IF NOT EXISTS idx_eventi_firma_stato ON eventi_invio(firma_stato);
CREATE INDEX IF NOT EXISTS idx_eventi_ts_tipo     ON eventi_invio(timestamp_tipo);

-- ── Migration V28 — inviti_pendenti ──────────────────────────
CREATE TABLE IF NOT EXISTS inviti_pendenti (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    token           TEXT NOT NULL UNIQUE,
    mittente_id     UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    destinatario    TEXT NOT NULL,
    canale          TEXT NOT NULL DEFAULT 'link'
                        CHECK (canale IN ('email','sms','whatsapp','link')),
    stato           TEXT NOT NULL DEFAULT 'pendente'
                        CHECK (stato IN ('pendente','accettato','scaduto','revocato')),
    documento_id    UUID REFERENCES documenti(id) ON DELETE SET NULL,
    messaggio       TEXT,
    creato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    scade_il        TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '7 days',
    accettato_il    TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_inviti_token        ON inviti_pendenti(token);
CREATE INDEX IF NOT EXISTS idx_inviti_destinatario ON inviti_pendenti(destinatario);
CREATE INDEX IF NOT EXISTS idx_inviti_mittente     ON inviti_pendenti(mittente_id);
CREATE INDEX IF NOT EXISTS idx_inviti_stato        ON inviti_pendenti(stato);

-- ── Migration V29 — contatti_rubrica ─────────────────────────
-- Contatti importati dalla rubrica del dispositivo.
-- Separati dalla tabella entity (entity = soggetti documentali,
-- contatti_rubrica = rubrica telefono importata con consenso).
CREATE TABLE IF NOT EXISTS contatti_rubrica (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    display_name    TEXT NOT NULL,
    email           TEXT,          -- prima email disponibile
    phone           TEXT,          -- primo numero disponibile
    source          TEXT NOT NULL DEFAULT 'device' CHECK (source IN ('device','manuale')),
    registrato      BOOLEAN,       -- null=non verificato, true=su Vemora, false=no
    registrato_utente_id UUID REFERENCES utenti(id) ON DELETE SET NULL,
    creato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, email, phone)   -- evita duplicati per stesso utente
);
CREATE INDEX IF NOT EXISTS idx_contatti_utente ON contatti_rubrica(utente_id);
CREATE INDEX IF NOT EXISTS idx_contatti_email  ON contatti_rubrica(email);
CREATE INDEX IF NOT EXISTS idx_contatti_phone  ON contatti_rubrica(phone);
CREATE INDEX IF NOT EXISTS idx_contatti_registrato ON contatti_rubrica(registrato);

-- ── Migration V30 — campi profilo su utenti ───────────────────
ALTER TABLE utenti
    ADD COLUMN IF NOT EXISTS avatar_path  TEXT,        -- percorso file avatar sul server
    ADD COLUMN IF NOT EXISTS stato        TEXT,         -- stato/bio breve (max 140 char)
    ADD COLUMN IF NOT EXISTS telefono     TEXT;         -- telefono opzionale

COMMENT ON COLUMN utenti.avatar_path IS 'Percorso relativo al file avatar in /data/vemora/avatars/';
COMMENT ON COLUMN utenti.stato IS 'Stato/bio breve mostrato nel profilo. Max 140 caratteri.';

-- ── Migration V31 — Email → Memoria ─────────────────────────
ALTER TABLE utenti
    ADD COLUMN IF NOT EXISTS email_token  TEXT UNIQUE,
    ADD COLUMN IF NOT EXISTS email_attivo BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS email_memora (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id    UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    message_id   TEXT UNIQUE,
    mittente     TEXT NOT NULL,
    mittente_nome TEXT,
    destinatario TEXT NOT NULL,
    oggetto      TEXT,
    corpo_testo  TEXT,
    data_email   TIMESTAMPTZ,
    creato_il    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    memoria_id   UUID REFERENCES memorie(id) ON DELETE SET NULL,
    contatto_id  UUID REFERENCES contatti_rubrica(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS email_allegati (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email_id     UUID NOT NULL REFERENCES email_memora(id) ON DELETE CASCADE,
    nome_file    TEXT NOT NULL,
    mime_type    TEXT,
    dimensione   INT,
    percorso     TEXT,
    documento_id UUID REFERENCES documenti(id) ON DELETE SET NULL,
    creato_il    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_email_utente   ON email_memora(utente_id);
CREATE INDEX IF NOT EXISTS idx_email_mittente ON email_memora(mittente);
CREATE INDEX IF NOT EXISTS idx_email_data     ON email_memora(data_email DESC);
CREATE INDEX IF NOT EXISTS idx_allegati_email ON email_allegati(email_id);

-- ============================================================
-- MIGRAZIONE: migration_v51_eco_premium.sql
-- ============================================================
-- VEMORA Migration V51
-- ECO Premium foundation
--
-- Obiettivo:
-- creare il layer persistente minimo di ECO come linea autonoma del vocale,
-- separata da Radar/Prisma/Sentinella ma leggibile da Control Room in futuro.

CREATE TABLE IF NOT EXISTS eco_sessions (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NULL REFERENCES utenti(id) ON DELETE CASCADE,
    current_screen      TEXT,
    target_tipo         TEXT,
    target_id           TEXT,
    session_lock_key    TEXT,
    session_state       TEXT NOT NULL DEFAULT 'active' CHECK (session_state IN ('active', 'paused', 'closed')),
    runtime_locale      TEXT,
    runtime_country     TEXT,
    source              TEXT NOT NULL DEFAULT 'voice_router',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at           TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_eco_sessions_user ON eco_sessions(utente_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_sessions_lock ON eco_sessions(session_lock_key);

CREATE TABLE IF NOT EXISTS eco_utterances (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id              UUID NOT NULL REFERENCES eco_sessions(id) ON DELETE CASCADE,
    seq_no                  INTEGER NOT NULL,
    raw_text                TEXT NOT NULL,
    normalized_text         TEXT,
    corrected_text          TEXT,
    recognized_command      TEXT,
    recognized_parameter    TEXT,
    recognized_confidence   REAL NOT NULL DEFAULT 0.0,
    protected_matches       JSONB NOT NULL DEFAULT '[]'::jsonb,
    context_snapshot        JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (session_id, seq_no)
);
CREATE INDEX IF NOT EXISTS idx_eco_utterances_session ON eco_utterances(session_id, seq_no DESC);

CREATE TABLE IF NOT EXISTS eco_phonetic_variants (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    canonical_term      TEXT NOT NULL,
    heard_variant       TEXT NOT NULL,
    phonetic_key        TEXT,
    context_scope       TEXT NOT NULL DEFAULT '',
    evidence_count      INTEGER NOT NULL DEFAULT 1,
    trust_level         TEXT NOT NULL DEFAULT 'candidate' CHECK (trust_level IN ('candidate', 'reinforced', 'stable', 'protected')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_eco_phonetic_variant
    ON eco_phonetic_variants (utente_id, canonical_term, heard_variant, context_scope);
CREATE INDEX IF NOT EXISTS idx_eco_phonetic_user ON eco_phonetic_variants(utente_id, evidence_count DESC);

CREATE TABLE IF NOT EXISTS eco_disambiguation_cases (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    selected_value          TEXT,
    selected_type           TEXT,
    candidates_json         JSONB NOT NULL DEFAULT '[]'::jsonb,
    risk_level              TEXT NOT NULL DEFAULT 'low' CHECK (risk_level IN ('low', 'medium', 'high')),
    requires_confirmation   BOOLEAN NOT NULL DEFAULT FALSE,
    reason_codes            JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_disambiguation_utterance ON eco_disambiguation_cases(utterance_id);

CREATE TABLE IF NOT EXISTS eco_intent_packets (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    intent_name             TEXT NOT NULL,
    action_code             TEXT NOT NULL,
    target_entities_json    JSONB NOT NULL DEFAULT '[]'::jsonb,
    temporal_scope_json     JSONB NOT NULL DEFAULT '{}'::jsonb,
    confidence_global       REAL NOT NULL DEFAULT 0.0,
    risk_level              TEXT NOT NULL DEFAULT 'low' CHECK (risk_level IN ('low', 'medium', 'high')),
    requires_confirmation   BOOLEAN NOT NULL DEFAULT FALSE,
    explanation_short       TEXT,
    luiss_bridge_status     TEXT NOT NULL DEFAULT 'pending',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_intent_utterance ON eco_intent_packets(utterance_id);
CREATE INDEX IF NOT EXISTS idx_eco_intent_action ON eco_intent_packets(action_code, created_at DESC);

-- ============================================================
-- MIGRAZIONE: migration_v52_eco_runtime_dialog.sql
-- ============================================================
-- VEMORA V52 — ECO Premium Runtime/Dialog/Policy

CREATE TABLE IF NOT EXISTS eco_dialog_turns (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id              UUID NOT NULL REFERENCES eco_sessions(id) ON DELETE CASCADE,
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    turn_index              INTEGER NOT NULL,
    turn_type               TEXT NOT NULL,
    dialog_phase            TEXT NOT NULL DEFAULT 'active',
    repair_mode             TEXT NOT NULL DEFAULT 'none',
    interruption_detected   BOOLEAN NOT NULL DEFAULT FALSE,
    active_focus_json       JSONB NOT NULL DEFAULT '[]'::jsonb,
    grounding_json          JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_dialog_session ON eco_dialog_turns(session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_dialog_utterance ON eco_dialog_turns(utterance_id);

CREATE TABLE IF NOT EXISTS eco_policy_events (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    policy_action           TEXT NOT NULL,
    confirmation_mode       TEXT NOT NULL DEFAULT 'none',
    silence_mode            TEXT NOT NULL DEFAULT 'none',
    reason_codes            JSONB NOT NULL DEFAULT '[]'::jsonb,
    grounding_strength      REAL NOT NULL DEFAULT 0.0,
    policy_summary          TEXT,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_policy_utterance ON eco_policy_events(utterance_id);
CREATE INDEX IF NOT EXISTS idx_eco_policy_action ON eco_policy_events(policy_action, created_at DESC);


-- ============================================================
-- MIGRAZIONE: migration_v53_eco_anchor_time.sql
-- ============================================================
-- VEMORA V53 — ECO Camere Ancora / Tempo Umano / Common Ground

CREATE TABLE IF NOT EXISTS eco_anchor_candidates (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id        UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    anchor_label        TEXT NOT NULL,
    anchor_type         TEXT NOT NULL DEFAULT 'generic',
    anchor_strength     TEXT NOT NULL DEFAULT 'probable',
    anchor_score        REAL NOT NULL DEFAULT 0.0,
    linked_entity_type  TEXT,
    linked_entity_id    UUID,
    source              TEXT NOT NULL DEFAULT 'eco',
    reason_codes        JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_anchor_utterance ON eco_anchor_candidates(utterance_id);
CREATE INDEX IF NOT EXISTS idx_eco_anchor_label ON eco_anchor_candidates(anchor_label, created_at DESC);

CREATE TABLE IF NOT EXISTS eco_temporal_resolutions (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id        UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    resolution_mode     TEXT NOT NULL,
    expression          TEXT,
    from_date           DATE,
    to_date             DATE,
    resolution_json     JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_temporal_utterance ON eco_temporal_resolutions(utterance_id);
CREATE INDEX IF NOT EXISTS idx_eco_temporal_mode ON eco_temporal_resolutions(resolution_mode, created_at DESC);

CREATE TABLE IF NOT EXISTS eco_common_ground_states (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id              UUID NOT NULL REFERENCES eco_sessions(id) ON DELETE CASCADE,
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    active_focus_json       JSONB NOT NULL DEFAULT '[]'::jsonb,
    shared_entities_json    JSONB NOT NULL DEFAULT '[]'::jsonb,
    shared_action           TEXT,
    shared_time_scope_json  JSONB NOT NULL DEFAULT '{}'::jsonb,
    shared_anchor_json      JSONB NOT NULL DEFAULT '{}'::jsonb,
    open_uncertainties_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    ground_strength         REAL NOT NULL DEFAULT 0.0,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_ground_session ON eco_common_ground_states(session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_ground_utterance ON eco_common_ground_states(utterance_id);

-- VEMORA V54 — ECO Camere Ancora / Maturazione storica

CREATE TABLE IF NOT EXISTS eco_anchor_memories (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    anchor_identity     TEXT NOT NULL,
    anchor_label        TEXT NOT NULL,
    anchor_type         TEXT NOT NULL DEFAULT 'generic',
    maturity_level      TEXT NOT NULL DEFAULT 'debole',
    maturity_score      REAL NOT NULL DEFAULT 0.0,
    evidence_count      INTEGER NOT NULL DEFAULT 1,
    recurrence_sessions INTEGER NOT NULL DEFAULT 1,
    linked_entity_type  TEXT,
    linked_entity_id    UUID,
    last_session_id     UUID REFERENCES eco_sessions(id) ON DELETE SET NULL,
    first_seen_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    reason_codes        JSONB NOT NULL DEFAULT '[]'::jsonb,
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, anchor_identity)
);

CREATE INDEX IF NOT EXISTS idx_eco_anchor_memories_user_score
    ON eco_anchor_memories(utente_id, maturity_score DESC, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_anchor_memories_label
    ON eco_anchor_memories(anchor_label, updated_at DESC);


-- ============================================================
-- MIGRAZIONE: migration_v55_eco_life_events.sql
-- ============================================================

-- VEMORA V55 — ECO Eventi di vita semantici / common ground esteso

ALTER TABLE IF EXISTS eco_common_ground_states
    ADD COLUMN IF NOT EXISTS shared_semantic_period_json JSONB NOT NULL DEFAULT '{}'::jsonb;

CREATE TABLE IF NOT EXISTS eco_life_anchor_events (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    event_identity      TEXT NOT NULL,
    event_label         TEXT NOT NULL,
    anchor_domain       TEXT NOT NULL DEFAULT 'generic',
    event_type          TEXT NOT NULL DEFAULT 'event',
    relationship_scope  TEXT,
    salience_level      TEXT NOT NULL DEFAULT 'media',
    temporal_force      INTEGER NOT NULL DEFAULT 0,
    maturity_level      TEXT NOT NULL DEFAULT 'debole',
    maturity_score      REAL NOT NULL DEFAULT 0.0,
    evidence_count      INTEGER NOT NULL DEFAULT 1,
    recurrence_sessions INTEGER NOT NULL DEFAULT 1,
    last_session_id     UUID REFERENCES eco_sessions(id) ON DELETE SET NULL,
    first_seen_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    reason_codes        JSONB NOT NULL DEFAULT '[]'::jsonb,
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, event_identity)
);

CREATE INDEX IF NOT EXISTS idx_eco_life_anchor_events_user_score
    ON eco_life_anchor_events(utente_id, maturity_score DESC, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_life_anchor_events_label
    ON eco_life_anchor_events(event_label, updated_at DESC);


-- ============================================================
-- MIGRAZIONE: migration_v56_semantic_anchor_memory.sql
-- ============================================================

-- VEMORA V56 — Memoria semantica generale per ancore/periodi usati dal vocale
-- Correzione architetturale: ECO consuma refs vocali, non possiede la memoria primaria della vita.

CREATE TABLE IF NOT EXISTS semantic_anchor_events (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    anchor_identity     TEXT NOT NULL,
    short_label         TEXT NOT NULL,
    anchor_domain       TEXT NOT NULL DEFAULT 'generic',
    anchor_kind         TEXT NOT NULL DEFAULT 'semantic_period',
    event_type          TEXT NOT NULL DEFAULT 'event',
    relationship_scope  TEXT,
    salience_level      TEXT NOT NULL DEFAULT 'media',
    temporal_force      INTEGER NOT NULL DEFAULT 0,
    human_priority      INTEGER NOT NULL DEFAULT 0,
    maturity_level      TEXT NOT NULL DEFAULT 'debole',
    maturity_score      REAL NOT NULL DEFAULT 0.0,
    evidence_count      INTEGER NOT NULL DEFAULT 1,
    recurrence_sessions INTEGER NOT NULL DEFAULT 1,
    last_source_session_id UUID,
    owner_scope         TEXT NOT NULL DEFAULT 'vemora_semantic_memory',
    visibility_scope    TEXT NOT NULL DEFAULT 'voice_reference',
    payload_json        JSONB NOT NULL DEFAULT '{}'::jsonb,
    reason_codes        JSONB NOT NULL DEFAULT '[]'::jsonb,
    first_seen_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, anchor_identity)
);

CREATE INDEX IF NOT EXISTS idx_semantic_anchor_events_user_score
    ON semantic_anchor_events(utente_id, maturity_score DESC, human_priority DESC, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_semantic_anchor_events_label
    ON semantic_anchor_events(short_label, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_semantic_anchor_events_visibility
    ON semantic_anchor_events(visibility_scope, anchor_domain, event_type);



-- ============================================================
-- MIGRAZIONE: migration_v57_eco_user_adaptation.sql
-- ============================================================

-- VEMORA V57 — ECO User Adaptation Core V1

CREATE TABLE IF NOT EXISTS eco_user_voice_profiles (
    utente_id                    UUID PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    learning_enabled             BOOLEAN NOT NULL DEFAULT TRUE,
    phonetic_learning_enabled    BOOLEAN NOT NULL DEFAULT TRUE,
    semantic_ref_learning_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    screen_habit_learning_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    correction_learning_enabled  BOOLEAN NOT NULL DEFAULT TRUE,
    phonetic_learning_count      INTEGER NOT NULL DEFAULT 0,
    correction_count             INTEGER NOT NULL DEFAULT 0,
    semantic_ref_learning_count  INTEGER NOT NULL DEFAULT 0,
    screen_habit_learning_count  INTEGER NOT NULL DEFAULT 0,
    last_seen_at                 TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at                   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS eco_adaptation_feedback (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id        UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    session_id       UUID REFERENCES eco_sessions(id) ON DELETE SET NULL,
    utterance_id     UUID REFERENCES eco_utterances(id) ON DELETE SET NULL,
    signal_type      TEXT NOT NULL,
    category         TEXT NOT NULL,
    learned_key      TEXT NOT NULL,
    learned_value    TEXT,
    context_scope    TEXT,
    source_event     TEXT NOT NULL DEFAULT 'voice_turn',
    evidence_weight  REAL NOT NULL DEFAULT 1.0,
    confidence_delta REAL NOT NULL DEFAULT 0.0,
    payload_json     JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_eco_adaptation_feedback_user_time
    ON eco_adaptation_feedback(utente_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_adaptation_feedback_category
    ON eco_adaptation_feedback(utente_id, category, signal_type, created_at DESC);

CREATE TABLE IF NOT EXISTS eco_screen_action_habits (
    utente_id        UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    screen_id        TEXT NOT NULL,
    action_code      TEXT NOT NULL,
    usage_count      INTEGER NOT NULL DEFAULT 0,
    success_count    INTEGER NOT NULL DEFAULT 0,
    correction_count INTEGER NOT NULL DEFAULT 0,
    strength_score   REAL NOT NULL DEFAULT 0.0,
    last_used_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (utente_id, screen_id, action_code)
);

CREATE INDEX IF NOT EXISTS idx_eco_screen_action_habits_strength
    ON eco_screen_action_habits(utente_id, screen_id, strength_score DESC, last_used_at DESC);

CREATE TABLE IF NOT EXISTS eco_semantic_ref_learning (
    utente_id          UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    semantic_period_ref TEXT NOT NULL,
    short_label        TEXT NOT NULL,
    context_scope      TEXT NOT NULL DEFAULT '',
    usage_count        INTEGER NOT NULL DEFAULT 0,
    correction_count   INTEGER NOT NULL DEFAULT 0,
    strength_score     REAL NOT NULL DEFAULT 0.0,
    last_seen_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (utente_id, semantic_period_ref, context_scope)
);

CREATE INDEX IF NOT EXISTS idx_eco_semantic_ref_learning_strength
    ON eco_semantic_ref_learning(utente_id, strength_score DESC, last_seen_at DESC);



-- ============================================================
-- LUISSRuntimeContext — contesto breve persistente LPE
-- ============================================================
CREATE TABLE IF NOT EXISTS luiss_runtime_context (
    utente_id                UUID PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    documento_corrente       UUID NULL REFERENCES documenti(id) ON DELETE SET NULL,
    ultimo_risultato_json    JSONB NULL,
    storico_json             JSONB NOT NULL DEFAULT '[]'::jsonb,
    avviato_il               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_luiss_runtime_context_updated
    ON luiss_runtime_context(aggiornato_il DESC);


-- ============================================================
-- SchemaMigrationState — stato migration additive gestite
-- ============================================================
CREATE TABLE IF NOT EXISTS schema_migration_state (
    migration_name       TEXT PRIMARY KEY,
    migration_sha256     TEXT NOT NULL,
    source_path          TEXT NOT NULL,
    applied_by           TEXT NULL,
    applied_notes        TEXT NULL,
    applied_il           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_schema_migration_state_applied_il
    ON schema_migration_state(applied_il DESC);
