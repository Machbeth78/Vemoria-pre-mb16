-- Vemoria — Canonical relationship chat media metadata (R4)
-- Only metadata/opaque local references. No media bytes are stored server-side.

ALTER TABLE chat_messaggi DROP CONSTRAINT IF EXISTS chat_messaggi_tipo_check;
ALTER TABLE chat_messaggi
    ADD CONSTRAINT chat_messaggi_tipo_check CHECK (
        tipo IN ('text','document','image','audio','voice_note','video','file',
                 'signature_request','acceptance_request','proof','delivery','system')
    );

ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS attachment_local_ref TEXT;
ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS attachment_mime TEXT;
ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS attachment_size_bytes BIGINT;
ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS attachment_sha256 TEXT;
ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS attachment_duration_ms INTEGER;
ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS transfer_state TEXT NOT NULL DEFAULT 'not_required';
ALTER TABLE chat_messaggi ADD COLUMN IF NOT EXISTS transfer_job_ref TEXT;

ALTER TABLE chat_messaggi DROP CONSTRAINT IF EXISTS chat_messaggi_transfer_state_check;
ALTER TABLE chat_messaggi ADD CONSTRAINT chat_messaggi_transfer_state_check CHECK (
    transfer_state IN ('not_required','draft','queued','waiting_peer','connecting','transferring',
                       'paused','delivered','read','failed','cancelled','expired')
);

CREATE INDEX IF NOT EXISTS idx_chat_messaggi_transfer_state
    ON chat_messaggi(thread_id, transfer_state, creato_il DESC)
    WHERE transfer_state NOT IN ('not_required','delivered','read','cancelled','expired');
CREATE INDEX IF NOT EXISTS idx_chat_messaggi_attachment_hash
    ON chat_messaggi(attachment_sha256)
    WHERE attachment_sha256 IS NOT NULL;

COMMENT ON COLUMN chat_messaggi.attachment_local_ref IS
    'Opaque owner-controlled local reference. Never a Vemoria server blob path.';
COMMENT ON COLUMN chat_messaggi.transfer_job_ref IS
    'Reference to the local P2P/owner-node queue; no server-side media custody.';
