-- Vemoria V79.2K — Abuse, wrong recipient and recipient rights
CREATE TABLE IF NOT EXISTS abuse_recipient_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reporter_user_id UUID NULL,
    reporter_contact TEXT NULL,
    report_type TEXT NOT NULL,
    content_ref TEXT NULL,
    event_ref TEXT NULL,
    recipient_ref TEXT NULL,
    public_token_hash TEXT NULL,
    reason_code TEXT NULL,
    description TEXT NULL,
    status TEXT NOT NULL DEFAULT 'received',
    legal_registry_hash TEXT NULL,
    evidence_hash TEXT NOT NULL,
    metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_abuse_recipient_reports_status ON abuse_recipient_reports(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_abuse_recipient_reports_content ON abuse_recipient_reports(content_ref);
CREATE UNIQUE INDEX IF NOT EXISTS ux_abuse_recipient_reports_hash ON abuse_recipient_reports(evidence_hash);
