-- VEMORA
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
-- Tutti i diritti riservati.
--
-- Desktop Companion / Secure Line Delivery V1

ALTER TABLE desktop_secure_line_requests
    ADD COLUMN IF NOT EXISTS pickup_ready_at TIMESTAMPTZ NULL,
    ADD COLUMN IF NOT EXISTS pickup_completed_at TIMESTAMPTZ NULL,
    ADD COLUMN IF NOT EXISTS pickup_channel TEXT NULL,
    ADD COLUMN IF NOT EXISTS delivery_mode TEXT NULL;

CREATE INDEX IF NOT EXISTS idx_secure_line_requests_pickup_ready
    ON desktop_secure_line_requests (utente_id, pickup_channel, pickup_completed_at, updated_at DESC);
