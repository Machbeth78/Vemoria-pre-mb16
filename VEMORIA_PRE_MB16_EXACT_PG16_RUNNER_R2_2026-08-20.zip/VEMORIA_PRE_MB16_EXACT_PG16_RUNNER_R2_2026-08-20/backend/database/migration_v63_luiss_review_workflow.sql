-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA
-- migration_v63_luiss_review_workflow.sql
-- Workflow persistente review/admin per decisioni LUISS.

CREATE TABLE IF NOT EXISTS luiss_review_state (
    decision_log_id      UUID PRIMARY KEY REFERENCES luiss_decision_log(id) ON DELETE CASCADE,
    review_status        TEXT NOT NULL DEFAULT 'open',
    assigned_to          TEXT NULL,
    resolution_code      TEXT NULL,
    review_note          TEXT NULL,
    review_payload_json  JSONB NULL,
    first_opened_il      TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    assigned_il          TIMESTAMP WITH TIME ZONE NULL,
    last_reviewed_il     TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    resolved_il          TIMESTAMP WITH TIME ZONE NULL,
    updated_il           TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    last_transition_il   TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    version              INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT ck_luiss_review_status
        CHECK (review_status IN ('open', 'in_progress', 'resolved', 'ignored', 'reopened'))
);

CREATE INDEX IF NOT EXISTS idx_luiss_review_state_status
    ON luiss_review_state(review_status, updated_il DESC);

CREATE INDEX IF NOT EXISTS idx_luiss_review_state_assigned
    ON luiss_review_state(assigned_to, updated_il DESC);

CREATE TABLE IF NOT EXISTS luiss_review_event (
    id              UUID PRIMARY KEY,
    decision_log_id UUID NOT NULL REFERENCES luiss_decision_log(id) ON DELETE CASCADE,
    event_type      TEXT NOT NULL,
    from_status     TEXT NULL,
    to_status       TEXT NULL,
    actor_ref       TEXT NULL,
    note            TEXT NULL,
    payload_json    JSONB NULL,
    created_il      TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_luiss_review_event_decision
    ON luiss_review_event(decision_log_id, created_il DESC);

CREATE INDEX IF NOT EXISTS idx_luiss_review_event_type
    ON luiss_review_event(event_type, created_il DESC);
