-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA Migration V47
-- Profilo runtime utente per lingua/paese/pack modulari

CREATE TABLE IF NOT EXISTS user_runtime_profiles (
    utente_id            UUID PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    locale               TEXT NOT NULL DEFAULT 'it-IT',
    paese_iso            TEXT NOT NULL DEFAULT 'IT',
    voice_lang           TEXT,
    ocr_lang             TEXT,
    document_locale      TEXT,
    semantic_locale      TEXT,
    preferred_domain     TEXT,
    extra                JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_user_runtime_profiles_locale
    ON user_runtime_profiles (locale);

CREATE INDEX IF NOT EXISTS idx_user_runtime_profiles_country
    ON user_runtime_profiles (paese_iso);
