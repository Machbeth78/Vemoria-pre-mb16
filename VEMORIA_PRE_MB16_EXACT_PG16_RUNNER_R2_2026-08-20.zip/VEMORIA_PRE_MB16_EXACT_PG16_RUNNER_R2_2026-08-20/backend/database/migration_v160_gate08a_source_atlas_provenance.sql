-- Gate08A — Source Atlas / Official Site Resolver / Provenance
-- Structural registry only. No live source fetch, no concrete source lists seeded.
-- Runtime remains NON_ESEGUITO.

CREATE TABLE IF NOT EXISTS gate08a_source_atlas_provenance_registry (
    id BIGSERIAL PRIMARY KEY,
    registry_version TEXT NOT NULL,
    invariant_code TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'BLOCKER',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (registry_version, invariant_code)
);

CREATE TABLE IF NOT EXISTS gate08a_source_provenance_event_contracts (
    id BIGSERIAL PRIMARY KEY,
    owner_id UUID NULL,
    assertion_id TEXT NOT NULL,
    origin_type TEXT NOT NULL CHECK (origin_type IN ('MIA_MEMORIA','RELAZIONE_GRUPPO','FONTE_PUBBLICA_UFFICIALE','DOCUMENTO_UTENTE','FONTE_QUARANTENATA')),
    source_chain_required BOOLEAN NOT NULL DEFAULT TRUE,
    can_claim_verified BOOLEAN NOT NULL DEFAULT FALSE,
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE CHECK (runtime_pass_claimed = FALSE),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS gate08a_group_source_cards_contracts (
    id BIGSERIAL PRIMARY KEY,
    group_id UUID NULL,
    source_key TEXT NOT NULL,
    domain TEXT NOT NULL,
    source_state TEXT NOT NULL CHECK (source_state IN ('FONTE_PUBBLICA_UFFICIALE','FONTE_QUARANTENATA')),
    contains_private_content BOOLEAN NOT NULL DEFAULT FALSE CHECK (contains_private_content = FALSE),
    contains_chat_content BOOLEAN NOT NULL DEFAULT FALSE CHECK (contains_chat_content = FALSE),
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE CHECK (runtime_pass_claimed = FALSE),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (group_id, source_key)
);

CREATE INDEX IF NOT EXISTS idx_gate08a_source_provenance_assertion
    ON gate08a_source_provenance_event_contracts(assertion_id);
CREATE INDEX IF NOT EXISTS idx_gate08a_group_source_cards_domain
    ON gate08a_group_source_cards_contracts(domain);
