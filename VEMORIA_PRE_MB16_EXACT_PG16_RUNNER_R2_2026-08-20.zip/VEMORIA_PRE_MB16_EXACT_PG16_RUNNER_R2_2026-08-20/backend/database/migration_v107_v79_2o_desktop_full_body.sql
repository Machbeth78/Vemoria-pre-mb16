
-- Vemoria — migration_v107_v79_2o_desktop_full_body.sql
-- Creatore e proprietario: Devoti Massimo
-- V79.2O — Vemoria PC/Desktop Full Body: stesso Cerebro del telefono,
-- chat desktop, sync eventi 360°, dossier/cartelle inviabili con storia.

CREATE TABLE IF NOT EXISTS desktop_vemoria_contacts_cache (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    contact_ref     TEXT NOT NULL,
    display_name    TEXT NOT NULL,
    contact_kind    TEXT NOT NULL DEFAULT 'person',
    source_payload  JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, contact_ref)
);
CREATE INDEX IF NOT EXISTS idx_desktop_vemoria_contacts_user
    ON desktop_vemoria_contacts_cache(utente_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_desktop_vemoria_contacts_display_lower
    ON desktop_vemoria_contacts_cache(LOWER(display_name));

CREATE TABLE IF NOT EXISTS desktop_vemoria_chat_threads (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    contact_ref     TEXT NOT NULL,
    contact_label   TEXT NOT NULL,
    thread_kind     TEXT NOT NULL DEFAULT 'person',
    status          TEXT NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active','archived','muted')),
    last_message_at TIMESTAMP,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_desktop_vemoria_threads_user
    ON desktop_vemoria_chat_threads(utente_id, COALESCE(last_message_at, updated_at) DESC);
CREATE INDEX IF NOT EXISTS idx_desktop_vemoria_threads_contact
    ON desktop_vemoria_chat_threads(utente_id, contact_ref);

CREATE TABLE IF NOT EXISTS desktop_vemoria_chat_messages (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    thread_id           UUID NOT NULL REFERENCES desktop_vemoria_chat_threads(id) ON DELETE CASCADE,
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    desktop_device_id   UUID REFERENCES desktop_devices(id) ON DELETE SET NULL,
    sender_side         TEXT NOT NULL DEFAULT 'desktop'
                        CHECK (sender_side IN ('desktop','mobile','owner','contact','system')),
    body                TEXT,
    attachments_json    JSONB NOT NULL DEFAULT '[]'::jsonb,
    dossier_id          UUID REFERENCES desktop_studio_dossiers(id) ON DELETE SET NULL,
    document_id         UUID REFERENCES documenti(id) ON DELETE SET NULL,
    delivery_status     TEXT NOT NULL DEFAULT 'queued'
                        CHECK (delivery_status IN ('queued','sent','delivered','opened','failed','draft')),
    proof_payload_json  JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_desktop_vemoria_messages_thread
    ON desktop_vemoria_chat_messages(thread_id, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_desktop_vemoria_messages_user
    ON desktop_vemoria_chat_messages(utente_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_desktop_vemoria_messages_dossier
    ON desktop_vemoria_chat_messages(dossier_id, created_at DESC) WHERE dossier_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS desktop_vemoria_sync_events (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    origin_device_id    UUID REFERENCES desktop_devices(id) ON DELETE SET NULL,
    target_device_id    UUID REFERENCES desktop_devices(id) ON DELETE SET NULL,
    origin_surface      TEXT NOT NULL DEFAULT 'desktop'
                        CHECK (origin_surface IN ('desktop','mobile','backend','system')),
    event_type          TEXT NOT NULL,
    event_title         TEXT NOT NULL,
    contact_ref         TEXT,
    dossier_id          UUID REFERENCES desktop_studio_dossiers(id) ON DELETE SET NULL,
    document_id         UUID REFERENCES documenti(id) ON DELETE SET NULL,
    payload_json        JSONB NOT NULL DEFAULT '{}'::jsonb,
    sync_status         TEXT NOT NULL DEFAULT 'pending'
                        CHECK (sync_status IN ('pending','seen','applied','failed')),
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    acknowledged_at     TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_desktop_vemoria_sync_user
    ON desktop_vemoria_sync_events(utente_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_desktop_vemoria_sync_status
    ON desktop_vemoria_sync_events(utente_id, sync_status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_desktop_vemoria_sync_dossier
    ON desktop_vemoria_sync_events(dossier_id, created_at DESC) WHERE dossier_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS desktop_studio_dossier_sends (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    dossier_id              UUID NOT NULL REFERENCES desktop_studio_dossiers(id) ON DELETE CASCADE,
    utente_id               UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    desktop_device_id       UUID REFERENCES desktop_devices(id) ON DELETE SET NULL,
    recipient_ref           TEXT NOT NULL,
    recipient_label         TEXT NOT NULL,
    send_channel            TEXT NOT NULL DEFAULT 'vemoria_chat',
    manifest_hash           TEXT NOT NULL,
    content_snapshot_json   JSONB NOT NULL DEFAULT '{}'::jsonb,
    message                 TEXT,
    send_status             TEXT NOT NULL DEFAULT 'queued'
                            CHECK (send_status IN ('queued','sent','delivered','opened','failed','cancelled')),
    proof_payload_json      JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_desktop_studio_dossier_sends_dossier
    ON desktop_studio_dossier_sends(dossier_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_desktop_studio_dossier_sends_user
    ON desktop_studio_dossier_sends(utente_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_desktop_studio_dossier_sends_recipient
    ON desktop_studio_dossier_sends(utente_id, recipient_ref, created_at DESC);

CREATE TABLE IF NOT EXISTS desktop_vemoria_remote_requests (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    requester_surface   TEXT NOT NULL DEFAULT 'mobile'
                        CHECK (requester_surface IN ('mobile','desktop','backend','system')),
    target_device_id    UUID REFERENCES desktop_devices(id) ON DELETE SET NULL,
    request_type        TEXT NOT NULL DEFAULT 'search_pc_vault',
    query               TEXT NOT NULL,
    payload_json        JSONB NOT NULL DEFAULT '{}'::jsonb,
    status              TEXT NOT NULL DEFAULT 'queued'
                        CHECK (status IN ('queued','processing','completed','failed','cancelled')),
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_desktop_vemoria_remote_user
    ON desktop_vemoria_remote_requests(utente_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_desktop_vemoria_remote_status
    ON desktop_vemoria_remote_requests(utente_id, status, created_at DESC);
