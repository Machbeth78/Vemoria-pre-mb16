-- Vemoria migration v117 - Gentilapp Base Behavior Pack
-- Purpose: register base behavior/vocabulary pack and optional per-user behavior preferences.

CREATE TABLE IF NOT EXISTS gentilapp_behavior_packs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    pack_id TEXT NOT NULL UNIQUE,
    version TEXT NOT NULL,
    language TEXT NOT NULL DEFAULT 'it-IT',
    scope TEXT NOT NULL DEFAULT 'vemoria_base',
    active BOOLEAN NOT NULL DEFAULT TRUE,
    sha256 TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_dialogue_behavior_preferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    preferred_default_tone TEXT NOT NULL DEFAULT 'neutro_professionale',
    avoid_phrases JSONB NOT NULL DEFAULT '[]'::jsonb,
    preferred_phrases JSONB NOT NULL DEFAULT '[]'::jsonb,
    context_overrides JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(user_id)
);

CREATE INDEX IF NOT EXISTS idx_user_dialogue_behavior_preferences_user_id
    ON user_dialogue_behavior_preferences(user_id);

INSERT INTO gentilapp_behavior_packs (pack_id, version, language, scope, active)
VALUES ('vemoria.gentilapp.base_behavior.v1', '1.0.0', 'it-IT', 'vemoria_base', TRUE)
ON CONFLICT (pack_id) DO UPDATE SET
    version = EXCLUDED.version,
    active = EXCLUDED.active,
    updated_at = now();
