-- MB15-P1 — Capability & Permission Broker
-- Tables: permission request audit, goal resolution audit, user capability preferences.
-- Owner-scoped RLS enforced; fail-closed.

CREATE TABLE IF NOT EXISTS mb15_p1_permission_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    device_ref_hash TEXT NOT NULL DEFAULT '',
    capability_id TEXT NOT NULL,
    goal_type TEXT NOT NULL DEFAULT '',
    state TEXT NOT NULL DEFAULT 'NOT_REQUESTED',
    state_source TEXT DEFAULT 'UNKNOWN',
    trusted BOOLEAN DEFAULT FALSE,
    reason TEXT,
    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    workflow_expires_at TIMESTAMPTZ,
    observed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_mb15_p1_perm_owner ON mb15_p1_permission_requests(owner_id);
CREATE INDEX IF NOT EXISTS idx_mb15_p1_perm_active ON mb15_p1_permission_requests(owner_id, device_ref_hash, capability_id, updated_at DESC);

CREATE TABLE IF NOT EXISTS mb15_p1_goal_resolutions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    device_ref_hash TEXT NOT NULL DEFAULT '',
    goal_type TEXT NOT NULL,
    resolution_data JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mb15_p1_res_owner ON mb15_p1_goal_resolutions(owner_id, created_at DESC);

CREATE TABLE IF NOT EXISTS mb15_p1_user_preferences (
    owner_id UUID PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    preference_key TEXT NOT NULL,
    preference_value JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE mb15_p1_permission_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb15_p1_goal_resolutions ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb15_p1_user_preferences ENABLE ROW LEVEL SECURITY;

ALTER TABLE mb15_p1_permission_requests FORCE ROW LEVEL SECURITY;
ALTER TABLE mb15_p1_goal_resolutions FORCE ROW LEVEL SECURITY;
ALTER TABLE mb15_p1_user_preferences FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb15_p1_permission_requests_owner_isolation ON mb15_p1_permission_requests;
CREATE POLICY mb15_p1_permission_requests_owner_isolation ON mb15_p1_permission_requests
    USING (owner_id = _rls_owner_uuid())
    WITH CHECK (owner_id = _rls_owner_uuid());

DROP POLICY IF EXISTS mb15_p1_goal_resolutions_owner_isolation ON mb15_p1_goal_resolutions;
CREATE POLICY mb15_p1_goal_resolutions_owner_isolation ON mb15_p1_goal_resolutions
    USING (owner_id = _rls_owner_uuid())
    WITH CHECK (owner_id = _rls_owner_uuid());

DROP POLICY IF EXISTS mb15_p1_user_preferences_owner_isolation ON mb15_p1_user_preferences;
CREATE POLICY mb15_p1_user_preferences_owner_isolation ON mb15_p1_user_preferences
    USING (owner_id = _rls_owner_uuid())
    WITH CHECK (owner_id = _rls_owner_uuid());
