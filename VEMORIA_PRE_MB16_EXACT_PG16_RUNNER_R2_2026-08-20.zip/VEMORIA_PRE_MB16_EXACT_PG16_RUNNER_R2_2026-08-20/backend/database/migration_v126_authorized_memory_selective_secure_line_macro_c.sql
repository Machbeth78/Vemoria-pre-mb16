-- Vemoria Authorized Memory Macro C
-- Linea Protetta selettiva: indice, derivati e contenuti autorizzati.
-- Static contract only. No plaintext paths, filenames, byte payloads or automatic copies.

CREATE TABLE IF NOT EXISTS authorized_memory_selective_sync_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    sync_id TEXT NOT NULL,
    grant_id TEXT NOT NULL,
    source_id TEXT NOT NULL,
    source_device_id TEXT NOT NULL,
    target_device_id TEXT NOT NULL,
    device_set_epoch INTEGER NOT NULL CHECK (device_set_epoch >= 1),
    payload_kind TEXT NOT NULL CHECK (payload_kind IN (
        'index_delta','identity_delta','derivative_manifest','derivative_object','content_object'
    )),
    plan_state TEXT NOT NULL CHECK (plan_state IN (
        'ready','queued_offline','deferred_by_capability','blocked_by_consent','blocked_by_policy'
    )),
    encrypted_transport_required BOOLEAN NOT NULL DEFAULT TRUE,
    content_transfer BOOLEAN NOT NULL DEFAULT FALSE,
    index_only BOOLEAN NOT NULL DEFAULT FALSE,
    owner_visible_summary TEXT NOT NULL,
    payload_digest_sha256 CHAR(64) NOT NULL CHECK (payload_digest_sha256 ~ '^[0-9a-f]{64}$'),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_user_id, sync_id),
    CHECK (NOT (content_transfer AND index_only)),
    CHECK (payload_kind <> 'index_delta' OR (index_only = TRUE AND content_transfer = FALSE)),
    CHECK (payload_kind <> 'content_object' OR (content_transfer = TRUE AND encrypted_transport_required = TRUE))
);
CREATE INDEX IF NOT EXISTS idx_authmem_sync_owner_state
    ON authorized_memory_selective_sync_jobs(owner_user_id, plan_state, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_authmem_sync_owner_grant
    ON authorized_memory_selective_sync_jobs(owner_user_id, grant_id);

CREATE TABLE IF NOT EXISTS authorized_memory_index_delta_cursors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    source_id TEXT NOT NULL,
    device_id TEXT NOT NULL,
    cursor_ref TEXT NOT NULL CHECK (cursor_ref ~ '^(idxref:|sourceref:|devref:|vaultref:|localref:)'),
    source_epoch INTEGER NOT NULL CHECK (source_epoch >= 0),
    last_item_version BIGINT NOT NULL CHECK (last_item_version >= 0),
    index_digest_sha256 CHAR(64) NOT NULL CHECK (index_digest_sha256 ~ '^[0-9a-f]{64}$'),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_user_id, source_id, device_id, source_epoch, last_item_version)
);
CREATE INDEX IF NOT EXISTS idx_authmem_cursor_owner_source
    ON authorized_memory_index_delta_cursors(owner_user_id, source_id, device_id, source_epoch DESC, last_item_version DESC);

CREATE TABLE IF NOT EXISTS authorized_memory_selective_sync_routes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    sync_job_id UUID NOT NULL REFERENCES authorized_memory_selective_sync_jobs(id) ON DELETE CASCADE,
    route TEXT NOT NULL CHECK (route IN ('direct_lan','owner_node','direct_quic','blind_relay','blind_deposit')),
    route_order INTEGER NOT NULL CHECK (route_order >= 0),
    assisted_route BOOLEAN NOT NULL DEFAULT FALSE,
    UNIQUE(sync_job_id, route)
);

COMMENT ON TABLE authorized_memory_selective_sync_jobs IS
    'Selective sync intent over Linea Protetta. Contains metadata and opaque refs only, never plaintext paths or content bytes.';
COMMENT ON COLUMN authorized_memory_selective_sync_jobs.payload_kind IS
    'index_delta means no content copy. content_object requires explicit TRANSFER_CONTENT grant and secure line.';
COMMENT ON TABLE authorized_memory_index_delta_cursors IS
    'Monotonic per-source index cursors used for delta sync and recovery. No raw paths.';
