-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification,
-- distribution or use is prohibited.
--
-- migration_v113_v_pt_core_02_owner_identity_backup_emergency.sql
-- Laboratorio: Vemoria Privacy & Trust — Blocco V-PT-CORE-02
-- Owner Identity foundation + Backup base + Emergency lock
--
-- Filosofia (V-PT-CORE-02):
-- - Owner identity = layer di verifica server-side. Server vede SOLO:
--     * chiave pubblica (PEM), mai privata
--     * fingerprint della chiave (SHA-256 hex)
--     * hash della passphrase di recovery (PBKDF2-SHA256, mai passphrase)
-- - Backup base = manifest opaco al server. Il blob arriva cifrato dal
--   client, server lo persiste e ne calcola hash di integrità.
-- - Emergency lock = stato per-utente (locked/locked_reason/auto_unlock_at)
--   + token_epoch (bump per revocare JWT senza migrare a stateful sessions).
--
-- Niente ALTER su utenti, dispositivi_utente, runtime_sessions, memorie,
-- chat_thread, contatti_rubrica, dossier, eventi_invio, timeline_eventi,
-- user_operational_profile.
-- Tutte le tabelle FK ON DELETE CASCADE su utenti(id): privacy by design.
-- Additiva e idempotente: CREATE TABLE IF NOT EXISTS, CREATE INDEX IF NOT EXISTS.

BEGIN;

-- ===========================================================================
-- 1. owner_identity_state
-- ===========================================================================
-- Una riga per utente. Tiene la chiave pubblica owner (Ed25519 default),
-- il token_epoch per revoke globale dei JWT, e il recovery handle hashed.
--
-- Niente private key, niente passphrase in chiaro: la migration NON espone
-- nessun campo che possa contenere segreti dell'utente in forma riusabile.

CREATE TABLE IF NOT EXISTS owner_identity_state (
    utente_id            UUID         PRIMARY KEY
                                      REFERENCES utenti(id) ON DELETE CASCADE,

    -- chiave pubblica (PEM ASCII). Server vede solo questa.
    public_key_pem       TEXT         NULL,
    key_algorithm        TEXT         NOT NULL DEFAULT 'ed25519'
                                      CHECK (key_algorithm IN (
                                          'ed25519',
                                          'rsa-2048',
                                          'rsa-3072',
                                          'rsa-4096',
                                          'unset'
                                      )),
    key_fingerprint      TEXT         NULL,    -- SHA-256(public_key_pem) hex

    -- contatore per revocare tutti i JWT precedenti (epoch bump)
    token_epoch          INTEGER      NOT NULL DEFAULT 0
                                      CHECK (token_epoch >= 0),

    -- recovery handle: PBKDF2-SHA256(passphrase, salt, iterations)
    -- la passphrase NON viene mai salvata in chiaro né loggata.
    recovery_handle_hash TEXT         NULL,
    recovery_salt        TEXT         NULL,
    recovery_iterations  INTEGER      NOT NULL DEFAULT 200000
                                      CHECK (recovery_iterations >= 100000
                                             AND recovery_iterations <= 2000000),

    created_at           TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_owner_identity_state_updated
    ON owner_identity_state(updated_at DESC);


-- ===========================================================================
-- 2. owner_lock_state
-- ===========================================================================
-- Stato di emergency lock per utente. Una riga per utente.
-- Quando locked=TRUE, le dependency `require_unlocked_owner` rifiutano
-- le operazioni sensibili (i router CORE-02 lo usano; altri router possono
-- adottarlo nei blocchi futuri).

CREATE TABLE IF NOT EXISTS owner_lock_state (
    utente_id          UUID         PRIMARY KEY
                                    REFERENCES utenti(id) ON DELETE CASCADE,
    locked             BOOLEAN      NOT NULL DEFAULT FALSE,
    locked_reason      TEXT         NULL
                                    CHECK (locked_reason IS NULL
                                           OR locked_reason IN (
                                               'owner_request',
                                               'lost_device',
                                               'suspicious_activity',
                                               'recovery_in_progress'
                                           )),
    locked_at          TIMESTAMPTZ  NULL,
    unlocked_at        TIMESTAMPTZ  NULL,
    auto_unlock_at     TIMESTAMPTZ  NULL,

    -- diagnostica per rate-limit unlock (PRIVATA all'owner)
    unlock_attempts    INTEGER      NOT NULL DEFAULT 0
                                    CHECK (unlock_attempts >= 0),
    last_unlock_attempt_at TIMESTAMPTZ NULL,

    created_at         TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_owner_lock_state_locked
    ON owner_lock_state(locked) WHERE locked = TRUE;


-- ===========================================================================
-- 3. owner_device_registration
-- ===========================================================================
-- Device autorizzati dall'owner. Distinto da dispositivi_utente che è
-- 1-1 (info hardware): qui è 1-N e gestisce autorizzazione/revoke.

CREATE TABLE IF NOT EXISTS owner_device_registration (
    id                   UUID         PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id            UUID         NOT NULL
                                      REFERENCES utenti(id) ON DELETE CASCADE,

    device_label         TEXT         NOT NULL,    -- "iPhone 15 Massimo"
    device_fingerprint   TEXT         NOT NULL,    -- hash univoco device

    platform             TEXT         NULL
                                      CHECK (platform IS NULL OR platform IN (
                                          'android', 'ios', 'desktop',
                                          'web', 'other'
                                      )),

    registered_at        TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_seen_at         TIMESTAMPTZ  NOT NULL DEFAULT NOW(),

    revoked              BOOLEAN      NOT NULL DEFAULT FALSE,
    revoked_at           TIMESTAMPTZ  NULL,
    revoke_reason        TEXT         NULL,

    UNIQUE (utente_id, device_fingerprint)
);

CREATE INDEX IF NOT EXISTS idx_owner_device_owner_active
    ON owner_device_registration(utente_id)
    WHERE revoked = FALSE;

CREATE INDEX IF NOT EXISTS idx_owner_device_last_seen
    ON owner_device_registration(utente_id, last_seen_at DESC);


-- ===========================================================================
-- 4. backup_session
-- ===========================================================================
-- Sessione di backup. Server ne registra solo i metadati operativi
-- (chi, dove, quando, quanto), MAI il contenuto.

CREATE TABLE IF NOT EXISTS backup_session (
    id                   UUID         PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id            UUID         NOT NULL
                                      REFERENCES utenti(id) ON DELETE CASCADE,

    target_kind          TEXT         NOT NULL
                                      CHECK (target_kind IN (
                                          'second_device',
                                          'usb_vault',
                                          'pc_agent_planned'
                                      )),
    -- fingerprint del target (hash opaco). Permette all'owner di riconoscere
    -- "lo stesso vault" senza esporre identificatori al server.
    target_fingerprint   TEXT         NULL,

    status               TEXT         NOT NULL DEFAULT 'preparata'
                                      CHECK (status IN (
                                          'preparata',
                                          'in_corso',
                                          'completata',
                                          'fallita',
                                          'annullata'
                                      )),

    started_at           TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    completed_at         TIMESTAMPTZ  NULL,

    total_chunks         INTEGER      NOT NULL DEFAULT 0
                                      CHECK (total_chunks >= 0),
    total_size_bytes     BIGINT       NOT NULL DEFAULT 0
                                      CHECK (total_size_bytes >= 0),

    -- nota operativa, mai PII: "annullata da utente" e simili
    notes                TEXT         NULL
);

CREATE INDEX IF NOT EXISTS idx_backup_session_owner_status
    ON backup_session(utente_id, status, started_at DESC);


-- ===========================================================================
-- 5. backup_manifest
-- ===========================================================================
-- Manifest cifrato lato client. Server persiste blob opaco + hash di
-- integrità. NESSUN parsing del contenuto server-side.
--
-- Una riga per session (PK=session_id): se l'utente vuole aggiornare il
-- manifest in corso, fa UPDATE. Niente storico server-side.

CREATE TABLE IF NOT EXISTS backup_manifest (
    session_id           UUID         PRIMARY KEY
                                      REFERENCES backup_session(id) ON DELETE CASCADE,

    -- blob opaco prodotto e cifrato dal client
    manifest_blob        BYTEA        NOT NULL,
    -- SHA-256 hex del blob (client può ricomputare per verificare integrità)
    manifest_hash        TEXT         NOT NULL,
    -- scheme dichiarato dal client; server NON verifica veridicità,
    -- è solo etichetta documentale per il client stesso
    encryption_scheme    TEXT         NOT NULL DEFAULT 'client_aes_256_gcm'
                                      CHECK (encryption_scheme IN (
                                          'client_aes_256_gcm',
                                          'client_chacha20_poly1305',
                                          'client_custom_declared'
                                      )),

    created_at           TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);


-- ===========================================================================
-- Commenti documentativi
-- ===========================================================================
COMMENT ON TABLE  owner_identity_state IS
    'V-PT-CORE-02: pubkey + token_epoch + recovery handle hashed. Server vede solo dati non-segreti.';
COMMENT ON COLUMN owner_identity_state.public_key_pem IS
    'V-PT-CORE-02: chiave pubblica PEM. Mai privata. Opzionale.';
COMMENT ON COLUMN owner_identity_state.recovery_handle_hash IS
    'V-PT-CORE-02: PBKDF2-SHA256(passphrase, salt). MAI loggato, MAI esportato.';
COMMENT ON COLUMN owner_identity_state.token_epoch IS
    'V-PT-CORE-02: bump → JWT con epoch precedente diventano invalidi (per chi usa la dependency).';

COMMENT ON TABLE  owner_lock_state IS
    'V-PT-CORE-02: stato di emergency lock per utente.';
COMMENT ON TABLE  owner_device_registration IS
    'V-PT-CORE-02: device autorizzati. Distinta da dispositivi_utente.';
COMMENT ON TABLE  backup_session IS
    'V-PT-CORE-02: sessione backup. Server vede solo metadati operativi.';
COMMENT ON COLUMN backup_manifest.manifest_blob IS
    'V-PT-CORE-02: blob cifrato dal client. Server NON ne conosce il contenuto.';

COMMIT;
