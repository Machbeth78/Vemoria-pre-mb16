-- Vemoria Gate08G-R1 - Cerebro Engine Policy / Local-First Runtime Contract
-- Static/runtime-policy schema contract only. No LLM runtime execution is performed here.
-- Defines traceable engine choice policy: local-first, no hidden remote escalation,
-- Sapere packages are knowledge bundles, not duplicated LLM weights.

CREATE TABLE IF NOT EXISTS gate08g_r1_cerebro_engine_policy_snapshots (
    id TEXT PRIMARY KEY,
    policy_version TEXT NOT NULL,
    local_first_default BOOLEAN NOT NULL DEFAULT TRUE CHECK (local_first_default = TRUE),
    remote_enabled_by_default BOOLEAN NOT NULL DEFAULT FALSE CHECK (remote_enabled_by_default = FALSE),
    hidden_remote_escalation_allowed BOOLEAN NOT NULL DEFAULT FALSE CHECK (hidden_remote_escalation_allowed = FALSE),
    model_license_registry_required BOOLEAN NOT NULL DEFAULT TRUE CHECK (model_license_registry_required = TRUE),
    no_llm_per_vertical_package BOOLEAN NOT NULL DEFAULT TRUE CHECK (no_llm_per_vertical_package = TRUE),
    sapere_packs_are_knowledge_not_model_bundles BOOLEAN NOT NULL DEFAULT TRUE CHECK (sapere_packs_are_knowledge_not_model_bundles = TRUE),
    can_claim_llm_runtime_pass BOOLEAN NOT NULL DEFAULT FALSE CHECK (can_claim_llm_runtime_pass = FALSE),
    policy_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    contains_secret BOOLEAN NOT NULL DEFAULT FALSE CHECK (contains_secret = FALSE),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_gate08g_r1_engine_policy_version
    ON gate08g_r1_cerebro_engine_policy_snapshots(policy_version);

CREATE TABLE IF NOT EXISTS gate08g_r1_engine_choice_trace_contracts (
    trace_contract_id TEXT PRIMARY KEY,
    policy_version TEXT NOT NULL,
    required_fields_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    remote_payload_must_be_minimized BOOLEAN NOT NULL DEFAULT TRUE CHECK (remote_payload_must_be_minimized = TRUE),
    remote_payload_must_be_redacted BOOLEAN NOT NULL DEFAULT TRUE CHECK (remote_payload_must_be_redacted = TRUE),
    owner_consent_required_for_remote BOOLEAN NOT NULL DEFAULT TRUE CHECK (owner_consent_required_for_remote = TRUE),
    runtime_executed BOOLEAN NOT NULL DEFAULT FALSE CHECK (runtime_executed = FALSE),
    contains_secret BOOLEAN NOT NULL DEFAULT FALSE CHECK (contains_secret = FALSE),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
