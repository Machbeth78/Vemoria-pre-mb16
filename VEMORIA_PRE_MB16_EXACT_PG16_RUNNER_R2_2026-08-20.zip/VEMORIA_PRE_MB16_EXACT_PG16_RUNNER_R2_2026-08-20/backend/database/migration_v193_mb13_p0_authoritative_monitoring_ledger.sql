-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- MB13-P0 R2 — Authoritative Monitoring Ledger Closure.
-- Forward-only, idempotent. Strengthens v192 writer/event/revoke functions
-- with owner-scoped validation, exact target binding, consent locking,
-- atomic lifecycle events, and complete canonical payload hashing.

BEGIN;

-- Deterministic ordering for events recorded inside the same transaction.
CREATE SEQUENCE IF NOT EXISTS public.mb13_p0_event_sequence_seq;
ALTER TABLE public.mb13_p0_monitor_event_ledger
    ADD COLUMN IF NOT EXISTS event_sequence BIGINT DEFAULT nextval('public.mb13_p0_event_sequence_seq');
UPDATE public.mb13_p0_monitor_event_ledger
   SET event_sequence = nextval('public.mb13_p0_event_sequence_seq')
 WHERE event_sequence IS NULL;
ALTER TABLE public.mb13_p0_monitor_event_ledger
    ALTER COLUMN event_sequence SET NOT NULL;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p0_app') THEN
        CREATE ROLE mb13_p0_app NOLOGIN;
    END IF;
END
$$;

-- Drop old v192 application-facing functions so we can replace signatures
-- and grants cleanly.
REVOKE ALL ON FUNCTION public.mb13_p0_write_monitor(UUID,TEXT,TEXT,TEXT,JSONB,INTEGER,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB) FROM PUBLIC, mb13_p0_app;
REVOKE ALL ON FUNCTION public.mb13_p0_revoke_monitor(UUID,TEXT) FROM PUBLIC, mb13_p0_app;
REVOKE ALL ON FUNCTION public.mb13_p0_record_monitor_event(UUID,UUID,INTEGER,TEXT,TEXT,TIMESTAMPTZ,JSONB,JSONB,JSONB,JSONB,TEXT,JSONB) FROM PUBLIC, mb13_p0_app;

DROP FUNCTION IF EXISTS public.mb13_p0_write_monitor(UUID,TEXT,TEXT,TEXT,JSONB,INTEGER,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB);
DROP FUNCTION IF EXISTS public.mb13_p0_revoke_monitor(UUID,TEXT);
DROP FUNCTION IF EXISTS public.mb13_p0_record_monitor_event(UUID,UUID,INTEGER,TEXT,TEXT,TIMESTAMPTZ,JSONB,JSONB,JSONB,JSONB,TEXT,JSONB);

-- Canonical deterministic SHA-256 digest of a JSONB value.
CREATE OR REPLACE FUNCTION public.mb13_p0_hash_jsonb(p_jsonb JSONB)
RETURNS TEXT AS $$
    SELECT encode(digest(convert_to($1::text, 'UTF8'), 'sha256'), 'hex');
$$ LANGUAGE SQL IMMUTABLE
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_hash_jsonb(JSONB) FROM PUBLIC;

-- Normalize a JSONB array of objects into a stable order so hashes are
-- deterministic across equivalent inputs.
CREATE OR REPLACE FUNCTION public.mb13_p0_normalize_jsonb_array(p_arr JSONB)
RETURNS JSONB AS $$
DECLARE
    v_normalized JSONB;
BEGIN
    IF p_arr IS NULL OR jsonb_typeof(p_arr) = 'null' THEN
        RETURN '[]'::jsonb;
    END IF;
    IF jsonb_typeof(p_arr) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p0_array_expected';
    END IF;
    IF jsonb_array_length(p_arr) = 0 THEN
        RETURN '[]'::jsonb;
    END IF;
    SELECT jsonb_agg(value ORDER BY value::text)
      INTO v_normalized
      FROM jsonb_array_elements(p_arr) AS value
     WHERE jsonb_typeof(value) <> 'null';
    RETURN COALESCE(v_normalized, '[]'::jsonb);
END;
$$ LANGUAGE plpgsql IMMUTABLE
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_normalize_jsonb_array(JSONB) FROM PUBLIC;

-- Temporal policy validation: real IANA timezone, parseable RFC 3339
-- timestamps, coherent ordering, and governed cadence vocabulary.
CREATE OR REPLACE FUNCTION public.mb13_p0_validate_temporal_policy(p_policy JSONB)
RETURNS void AS $$
DECLARE
    v_tz TEXT;
    v_field TEXT;
    v_val TEXT;
    v_ts TIMESTAMPTZ;
    v_valid_from TIMESTAMPTZ;
    v_valid_until TIMESTAMPTZ;
    v_next_check_at TIMESTAMPTZ;
    v_due_at TIMESTAMPTZ;
    v_grace_until TIMESTAMPTZ;
    v_cadence_kind TEXT;
    v_cadence_value TEXT;
    v_fields TEXT[] := ARRAY['valid_from','valid_until','next_check_at','due_at','grace_until'];
BEGIN
    IF jsonb_typeof(p_policy) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p0_policy_invalid';
    END IF;
    v_tz := p_policy->>'timezone';
    IF v_tz IS NULL OR length(trim(v_tz)) = 0 THEN
        RAISE EXCEPTION 'mb13_p0_policy_timezone_required';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_timezone_names WHERE name = v_tz) THEN
        RAISE EXCEPTION 'mb13_p0_policy_timezone_invalid';
    END IF;

    FOREACH v_field IN ARRAY v_fields LOOP
        v_val := p_policy->>v_field;
        IF v_val IS NOT NULL AND length(trim(v_val)) > 0 THEN
            BEGIN
                v_ts := v_val::TIMESTAMPTZ;
            EXCEPTION WHEN invalid_text_representation OR invalid_datetime_format OR datetime_field_overflow THEN
                RAISE EXCEPTION 'mb13_p0_temporal_policy_timestamp_invalid:%', v_field;
            END;
            CASE v_field
                WHEN 'valid_from' THEN v_valid_from := v_ts;
                WHEN 'valid_until' THEN v_valid_until := v_ts;
                WHEN 'next_check_at' THEN v_next_check_at := v_ts;
                WHEN 'due_at' THEN v_due_at := v_ts;
                WHEN 'grace_until' THEN v_grace_until := v_ts;
            END CASE;
        END IF;
    END LOOP;

    IF v_valid_from IS NOT NULL AND v_next_check_at IS NOT NULL AND v_valid_from > v_next_check_at THEN
        RAISE EXCEPTION 'mb13_p0_temporal_policy_invalid_order:valid_from_after_next_check_at';
    END IF;
    IF v_valid_from IS NOT NULL AND v_due_at IS NOT NULL AND v_valid_from > v_due_at THEN
        RAISE EXCEPTION 'mb13_p0_temporal_policy_invalid_order:valid_from_after_due_at';
    END IF;
    IF v_due_at IS NOT NULL AND v_grace_until IS NOT NULL AND v_due_at > v_grace_until THEN
        RAISE EXCEPTION 'mb13_p0_temporal_policy_invalid_order:due_at_after_grace_until';
    END IF;
    IF v_valid_from IS NOT NULL AND v_valid_until IS NOT NULL AND v_valid_from > v_valid_until THEN
        RAISE EXCEPTION 'mb13_p0_temporal_policy_invalid_order:valid_from_after_valid_until';
    END IF;
    IF v_next_check_at IS NOT NULL AND v_valid_until IS NOT NULL AND v_next_check_at > v_valid_until THEN
        RAISE EXCEPTION 'mb13_p0_temporal_policy_invalid_order:next_check_at_after_valid_until';
    END IF;

    v_cadence_kind := p_policy->>'cadence_kind';
    IF v_cadence_kind IS NOT NULL AND length(trim(v_cadence_kind)) > 0 THEN
        IF v_cadence_kind NOT IN ('daily','weekly','monthly','quarterly','yearly','one-shot','manual') THEN
            RAISE EXCEPTION 'mb13_p0_policy_cadence_kind_invalid';
        END IF;
        IF v_cadence_kind NOT IN ('one-shot','manual') THEN
            v_cadence_value := p_policy->>'cadence_value';
            IF v_cadence_value IS NULL OR length(trim(v_cadence_value)) = 0 THEN
                RAISE EXCEPTION 'mb13_p0_policy_cadence_value_required';
            END IF;
            IF v_cadence_value !~ '^[1-9][0-9]*$' THEN
                RAISE EXCEPTION 'mb13_p0_policy_cadence_value_invalid';
            END IF;
        END IF;
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_validate_temporal_policy(JSONB) FROM PUBLIC;

-- Validate target reference shape and exact currentness against canonical
-- registries.  p_for_active=true enforces that the target can be activated
-- (generic_entity and unsupported canonical types are not activatable).
CREATE OR REPLACE FUNCTION public.mb13_p0_validate_target(
    p_owner UUID,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_for_active BOOLEAN
)
RETURNS void AS $$
DECLARE
    v_id TEXT;
    v_revision INTEGER;
    v_hash TEXT;
    v_state TEXT;
    v_doc RECORD;
    v_dossier RECORD;
    v_source RECORD;
    v_decision RECORD;
    v_rev_hash TEXT;
BEGIN
    IF jsonb_typeof(p_target_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p0_target_ref_invalid';
    END IF;
    IF p_target_ref->>'id' IS NULL OR p_target_ref->>'revision' IS NULL OR p_target_ref->>'payload_hash' IS NULL OR p_target_ref->>'owner_user_id' IS NULL OR p_target_ref->>'state' IS NULL THEN
        RAISE EXCEPTION 'mb13_p0_target_ref_missing';
    END IF;
    v_id := p_target_ref->>'id';
    BEGIN
        v_revision := (p_target_ref->>'revision')::INTEGER;
    EXCEPTION WHEN invalid_text_representation THEN
        RAISE EXCEPTION 'mb13_p0_target_ref_invalid';
    END;
    v_hash := p_target_ref->>'payload_hash';
    v_state := p_target_ref->>'state';

    IF p_target_ref->>'owner_user_id' IS DISTINCT FROM p_owner::text THEN
        RAISE EXCEPTION 'mb13_p0_target_owner_mismatch';
    END IF;

    IF p_target_type = 'generic_entity' THEN
        IF p_for_active THEN
            RAISE EXCEPTION 'mb13_p0_target_type_not_activatable';
        END IF;
        RETURN;
    END IF;

    IF p_target_type IN ('rule','identity','object') THEN
        IF p_for_active THEN
            RAISE EXCEPTION 'mb13_p0_target_type_not_activatable';
        END IF;
        RETURN;
    END IF;

    IF p_target_type = 'document' THEN
        IF v_revision <> 1 THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        SELECT stato_elaborazione, hash_file, proprietario_id::text INTO v_doc
          FROM public.documenti
         WHERE id = v_id::UUID
           AND proprietario_id = p_owner
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_target_not_found';
        END IF;
        IF v_doc.stato_elaborazione = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_target_revoked';
        END IF;
        IF v_doc.stato_elaborazione <> 'memorizzato' THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_doc.hash_file IS NULL OR length(trim(v_doc.hash_file)) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_target_authoritative_hash_missing';
        END IF;
        IF v_doc.hash_file <> v_hash OR v_state <> 'memorizzato' THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        RETURN;
    END IF;

    IF p_target_type IN ('dossier','contract','offer') THEN
        SELECT current_revision, payload_hash, state INTO v_dossier
          FROM public.mb12_p1_offer_contract
         WHERE owner_user_id = p_owner
           AND dossier_id = v_id::UUID
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_target_not_found';
        END IF;
        IF v_dossier.state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_target_revoked';
        END IF;
        IF v_dossier.state <> 'normalized' THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_dossier.current_revision <> v_revision
           OR v_dossier.payload_hash IS NULL OR length(trim(v_dossier.payload_hash)) = 0
           OR v_dossier.payload_hash <> v_hash
           OR v_state <> 'normalized' THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        -- confirm exact revision row hash
        SELECT payload_hash INTO v_rev_hash
          FROM public.mb12_p1_offer_contract_revision
         WHERE owner_user_id = p_owner
           AND dossier_id = v_id::UUID
           AND revision = v_revision
         FOR SHARE;
        IF NOT FOUND OR v_rev_hash <> v_hash THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        RETURN;
    END IF;

    IF p_target_type = 'source' THEN
        IF v_revision <> 1 THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        SELECT
            b.content_hash,
            b.status,
            b.revoked_at,
            b.source_id::text AS binding_source_id,
            a.status AS authority_status,
            a.source_state,
            a.revocation_state,
            s.status AS source_status,
            s.revoked_at AS source_revoked,
            i.memory_state,
            i.deleted_at,
            i.content_hash AS item_hash,
            l.id AS evidence_id
          INTO v_source
          FROM public.mb12_p0_source_card_binding b
          JOIN public.canonical_source_card_authority a
            ON a.owner_user_id = b.owner_user_id
           AND a.source_card_id = b.source_card_id
          JOIN public.authorized_memory_sources s
            ON s.id = b.source_id
           AND s.user_id = b.owner_user_id
          JOIN public.authorized_memory_inventory_items i
            ON i.id = b.source_revision_id
           AND i.user_id = b.owner_user_id
           AND i.source_id = b.source_id
          JOIN public.authorized_memory_activity_log l
            ON l.id = b.evidence_id
           AND l.user_id = b.owner_user_id
         WHERE b.owner_user_id = p_owner
           AND b.source_card_id = v_id
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_target_not_found';
        END IF;
        IF v_source.status <> 'active' OR v_source.revoked_at IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p0_target_revoked';
        END IF;
        IF v_source.authority_status <> 'active'
           OR v_source.source_state <> 'active'
           OR v_source.revocation_state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_source.source_status <> 'active' OR v_source.source_revoked IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_source.memory_state = 'revoked' OR v_source.deleted_at IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_source.content_hash IS NULL OR length(trim(v_source.content_hash)) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_target_authoritative_hash_missing';
        END IF;
        IF v_source.content_hash <> v_hash OR v_state <> 'active' THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        RETURN;
    END IF;

    IF p_target_type = 'decision' THEN
        SELECT current_revision, payload_hash, state INTO v_decision
          FROM public.mb12_p4_governed_explainable_ranking
         WHERE owner_user_id = p_owner
           AND ranking_id = v_id::UUID
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_target_not_found';
        END IF;
        IF v_decision.state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_target_revoked';
        END IF;
        IF v_decision.current_revision <> v_revision
           OR v_decision.payload_hash IS NULL OR length(trim(v_decision.payload_hash)) = 0
           OR v_decision.payload_hash <> v_hash
           OR v_state <> v_decision.state THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        RETURN;
    END IF;

    RAISE EXCEPTION 'mb13_p0_target_type_not_supported';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_validate_target(UUID, TEXT, JSONB, BOOLEAN) FROM PUBLIC;

-- Lock and verify every consent reference.  Returns a normalized array to be
-- used for hashing and provenance.  For source targets the grant source_id
-- must match the binding source_id; for dossier targets each grant source_id
-- must appear in the dossier revision's source_refs.
CREATE OR REPLACE FUNCTION public.mb13_p0_lock_and_verify_consents(
    p_owner UUID,
    p_consent_refs JSONB,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_required BOOLEAN
)
RETURNS JSONB AS $$
DECLARE
    v_ref JSONB;
    v_source_id TEXT;
    v_grant_id TEXT;
    v_grant RECORD;
    v_normalized JSONB;
    v_count INTEGER := 0;
    v_target_source_id TEXT;
    v_dossier_source_ids TEXT[];
BEGIN
    IF p_consent_refs IS NULL OR jsonb_typeof(p_consent_refs) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p0_consent_refs_invalid';
    END IF;
    IF p_required AND jsonb_array_length(p_consent_refs) = 0 THEN
        RAISE EXCEPTION 'mb13_p0_consent_required';
    END IF;

    SELECT public.mb13_p0_normalize_jsonb_array(p_consent_refs) INTO v_normalized;

    -- Gather target-related source ids for compatibility checks.
    IF p_target_type IN ('dossier','contract','offer') THEN
        SELECT array_agg(DISTINCT (s->>'source_id')) INTO v_dossier_source_ids
          FROM public.mb12_p1_offer_contract_revision r,
               jsonb_array_elements(r.source_refs) AS s
         WHERE r.owner_user_id = p_owner
           AND r.dossier_id = (p_target_ref->>'id')::UUID
           AND r.revision = (p_target_ref->>'revision')::INTEGER
           AND s->>'source_id' IS NOT NULL;
    ELSIF p_target_type = 'source' THEN
        SELECT source_id::text INTO v_target_source_id
          FROM public.mb12_p0_source_card_binding
         WHERE owner_user_id = p_owner
           AND source_card_id = p_target_ref->>'id';
    END IF;

    FOR v_ref IN SELECT value FROM jsonb_array_elements(v_normalized) LOOP
        v_source_id := v_ref->>'source_id';
        v_grant_id := v_ref->>'grant_id';
        IF v_source_id IS NULL OR v_grant_id IS NULL THEN
            RAISE EXCEPTION 'mb13_p0_consent_ref_invalid';
        END IF;
        -- Acquire a shared lock on the grant; a concurrent revoke will block.
        SELECT * INTO v_grant
          FROM public.authorized_memory_consent_grants
         WHERE user_id = p_owner
           AND source_id = v_source_id::UUID
           AND id = v_grant_id::UUID
           AND status = 'active'
           AND revoked_at IS NULL
           AND (expires_at IS NULL OR expires_at > NOW())
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_consent_revoked_or_invalid';
        END IF;
        -- The grant must be a read/capability plane suitable for monitoring.
        IF v_grant.action NOT IN ('read_metadata','inventory_existence')
           OR v_grant.plane <> 'EXISTENCE' THEN
            RAISE EXCEPTION 'mb13_p0_consent_action_incompatible';
        END IF;

        IF p_target_type IN ('dossier','contract','offer') THEN
            IF v_dossier_source_ids IS NOT NULL AND NOT (v_source_id = ANY(v_dossier_source_ids)) THEN
                RAISE EXCEPTION 'mb13_p0_consent_source_not_related_to_target';
            END IF;
        ELSIF p_target_type = 'source' THEN
            IF v_source_id IS DISTINCT FROM v_target_source_id THEN
                RAISE EXCEPTION 'mb13_p0_consent_source_not_related_to_target';
            END IF;
        END IF;

        v_count := v_count + 1;
    END LOOP;

    IF p_required AND v_count = 0 THEN
        RAISE EXCEPTION 'mb13_p0_consent_required';
    END IF;

    RETURN v_normalized;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN) FROM PUBLIC;

-- Authoritative writer for monitor creation and state transitions.
-- Creates a revision, updates the current row, and appends a lifecycle event
-- atomically.  All governance checks happen inside the database.
CREATE OR REPLACE FUNCTION public.mb13_p0_write_monitor(
    p_monitor_id UUID,
    p_stable_id TEXT,
    p_title TEXT,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_target_revision INTEGER,
    p_target_payload_hash TEXT,
    p_monitor_reason TEXT,
    p_monitor_state TEXT,
    p_monitor_policy JSONB,
    p_consent_refs JSONB,
    p_source_refs JSONB,
    p_evidence_refs JSONB,
    p_baseline_ref JSONB,
    p_request_payload JSONB,
    p_result_payload JSONB
) RETURNS TABLE(monitor_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_revision INTEGER;
    v_payload_hash TEXT;
    v_result_payload JSONB;
    v_event_type TEXT;
    v_event_id UUID;
    v_event_payload_hash TEXT;
    v_event_time TIMESTAMPTZ := NOW();
    v_canonical_consent_refs JSONB;
    v_canonical_source_refs JSONB;
    v_canonical_evidence_refs JSONB;
    v_required_target_keys TEXT[] := ARRAY['id','revision','payload_hash','owner_user_id','state'];
    k TEXT;
    v_old_state TEXT;
    v_current_found BOOLEAN;
    v_is_new BOOLEAN;
    v_canonical JSONB;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p0_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p0_monitor_identity_invalid';
    END IF;
    IF length(trim(COALESCE(p_stable_id, ''))) = 0 OR length(p_stable_id) > 200 THEN
        RAISE EXCEPTION 'mb13_p0_stable_id_invalid';
    END IF;
    IF length(trim(COALESCE(p_title, ''))) = 0 OR length(p_title) > 300 THEN
        RAISE EXCEPTION 'mb13_p0_title_invalid';
    END IF;
    IF length(trim(COALESCE(p_monitor_reason, ''))) = 0 OR length(p_monitor_reason) > 500 THEN
        RAISE EXCEPTION 'mb13_p0_monitor_reason_invalid';
    END IF;
    IF p_target_type NOT IN ('document','contract','offer','rule','source','dossier','identity','object','decision','generic_entity') THEN
        RAISE EXCEPTION 'mb13_p0_target_type_invalid';
    END IF;
    IF p_monitor_state NOT IN ('draft','active','paused','blocked','revoked','completed') THEN
        RAISE EXCEPTION 'mb13_p0_monitor_state_invalid';
    END IF;
    IF jsonb_typeof(p_target_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p0_target_ref_invalid';
    END IF;
    FOREACH k IN ARRAY v_required_target_keys LOOP
        IF p_target_ref->>k IS NULL OR length(trim(p_target_ref->>k)) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_target_ref_missing:%', k;
        END IF;
    END LOOP;
    IF p_target_ref->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
        RAISE EXCEPTION 'mb13_p0_target_owner_mismatch';
    END IF;
    IF jsonb_typeof(p_monitor_policy) <> 'object' OR jsonb_typeof(p_baseline_ref) <> 'object' OR jsonb_typeof(p_request_payload) <> 'object' OR jsonb_typeof(p_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p0_payload_shape_invalid';
    END IF;
    IF jsonb_typeof(p_consent_refs) <> 'array' OR jsonb_typeof(p_source_refs) <> 'array' OR jsonb_typeof(p_evidence_refs) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p0_refs_must_be_arrays';
    END IF;

    PERFORM public.mb13_p0_validate_temporal_policy(p_monitor_policy);

    -- Normalize arrays for deterministic hashing and provenance.
    v_canonical_consent_refs := public.mb13_p0_lock_and_verify_consents(v_owner, p_consent_refs, p_target_type, p_target_ref, p_required => FALSE);
    v_canonical_source_refs := public.mb13_p0_normalize_jsonb_array(p_source_refs);
    v_canonical_evidence_refs := public.mb13_p0_normalize_jsonb_array(p_evidence_refs);

    -- Validate target currentness only when moving to active.
    IF p_monitor_state = 'active' THEN
        PERFORM public.mb13_p0_validate_target(v_owner, p_target_type, p_target_ref, p_for_active => TRUE);
    END IF;

    -- Consent/capability is required for any operational state.
    IF p_monitor_state IN ('active','paused','blocked','completed') THEN
        v_canonical_consent_refs := public.mb13_p0_lock_and_verify_consents(v_owner, v_canonical_consent_refs, p_target_type, p_target_ref, p_required => TRUE);
    END IF;

    -- Serialize all operations on this owner+stable_id monitor.
    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_stable_id, 0));

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = v_owner
       AND t.stable_id = p_stable_id
     FOR UPDATE;

    v_current_found := FOUND;
    v_is_new := NOT FOUND;

    IF v_current_found THEN
        v_old_state := v_current.monitor_state;
        IF v_old_state = 'revoked' AND p_monitor_state <> 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_revoked_monitor_cannot_reactivate';
        END IF;
        -- Allowed state machine.  Same-state writes are idempotent.
        IF NOT (
            (v_old_state = p_monitor_state)
         OR (v_old_state = 'draft' AND p_monitor_state IN ('active','revoked'))
         OR (v_old_state = 'active' AND p_monitor_state IN ('paused','blocked','revoked','completed'))
         OR (v_old_state = 'paused' AND p_monitor_state IN ('active','blocked','revoked'))
         OR (v_old_state = 'blocked' AND p_monitor_state IN ('active','revoked'))
         OR (v_old_state = 'completed' AND p_monitor_state IN ('revoked'))
        ) THEN
            RAISE EXCEPTION 'mb13_p0_transition_invalid:%->%', v_old_state, p_monitor_state;
        END IF;

        p_monitor_id := v_current.monitor_id;
        v_revision := v_current.current_revision;
    END IF;

    IF v_is_new THEN
        -- New monitors must be created in draft.
        IF p_monitor_state <> 'draft' THEN
            RAISE EXCEPTION 'mb13_p0_monitor_must_be_created_in_draft';
        END IF;
        -- Guard against a provided monitor_id already used with a different stable_id.
        IF EXISTS (SELECT 1 FROM public.mb13_p0_monitor_target AS t WHERE t.owner_user_id = v_owner AND t.monitor_id = p_monitor_id) THEN
            RAISE EXCEPTION 'mb13_p0_monitor_id_already_exists';
        END IF;
        v_old_state := NULL;
        v_revision := 1;
    END IF;

    v_result_payload := p_result_payload || jsonb_build_object(
        'monitor_state', p_monitor_state,
        'no_auto_action', true,
        'no_auto_notification', true
    );

    v_canonical := jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'stable_id', p_stable_id,
        'title', p_title,
        'target_type', p_target_type,
        'target_ref', p_target_ref,
        'target_revision', p_target_revision,
        'target_payload_hash', p_target_payload_hash,
        'monitor_reason', p_monitor_reason,
        'monitor_state', p_monitor_state,
        'monitor_policy', p_monitor_policy,
        'consent_refs', v_canonical_consent_refs,
        'source_refs', v_canonical_source_refs,
        'evidence_refs', v_canonical_evidence_refs,
        'baseline_ref', p_baseline_ref,
        'request_payload', p_request_payload,
        'result_payload', v_result_payload,
        'revision', v_revision
    );
    v_payload_hash := public.mb13_p0_hash_jsonb(v_canonical);

    IF v_current_found AND v_current.payload_hash = v_payload_hash AND v_current.monitor_state = p_monitor_state THEN
        RETURN QUERY SELECT v_current.monitor_id, v_current.current_revision, v_current.payload_hash::TEXT;
        RETURN;
    END IF;

    -- Non-idempotent update: advance to the next revision and recompute the hash.
    IF v_current_found THEN
        v_revision := v_current.current_revision + 1;
        v_canonical := jsonb_build_object(
            'owner_user_id', v_owner,
            'monitor_id', p_monitor_id,
            'stable_id', p_stable_id,
            'title', p_title,
            'target_type', p_target_type,
            'target_ref', p_target_ref,
            'target_revision', p_target_revision,
            'target_payload_hash', p_target_payload_hash,
            'monitor_reason', p_monitor_reason,
            'monitor_state', p_monitor_state,
            'monitor_policy', p_monitor_policy,
            'consent_refs', v_canonical_consent_refs,
            'source_refs', v_canonical_source_refs,
            'evidence_refs', v_canonical_evidence_refs,
            'baseline_ref', p_baseline_ref,
            'request_payload', p_request_payload,
            'result_payload', v_result_payload,
            'revision', v_revision
        );
        v_payload_hash := public.mb13_p0_hash_jsonb(v_canonical);
    END IF;

    -- Determine lifecycle event to be appended.
    IF NOT v_current_found THEN
        v_event_type := 'MONITOR_CREATED';
    ELSIF v_old_state = 'draft' AND p_monitor_state = 'active' THEN
        v_event_type := 'MONITOR_ACTIVATED';
    ELSIF v_old_state = 'active' AND p_monitor_state = 'paused' THEN
        v_event_type := 'MONITOR_PAUSED';
    ELSIF v_old_state = 'paused' AND p_monitor_state = 'active' THEN
        v_event_type := 'MONITOR_RESUMED';
    ELSIF p_monitor_state = 'blocked' THEN
        v_event_type := 'MONITOR_BLOCKED';
    ELSIF p_monitor_state = 'revoked' THEN
        v_event_type := 'MONITOR_REVOKED';
    ELSE
        v_event_type := NULL;
    END IF;

    -- Current-row promotion must precede revision append so the FK is satisfied.
    IF v_is_new THEN
        INSERT INTO public.mb13_p0_monitor_target (
            owner_user_id, monitor_id, stable_id, title, target_type,
            target_ref, target_revision, target_payload_hash,
            monitor_reason, monitor_state, monitor_policy,
            consent_refs, source_refs, evidence_refs, baseline_ref,
            current_revision, payload_hash
        ) VALUES (
            v_owner, p_monitor_id, p_stable_id, p_title, p_target_type,
            p_target_ref, p_target_revision, p_target_payload_hash,
            p_monitor_reason, p_monitor_state, p_monitor_policy,
            v_canonical_consent_refs, v_canonical_source_refs, v_canonical_evidence_refs, p_baseline_ref,
            v_revision, v_payload_hash
        );
    ELSE
        UPDATE public.mb13_p0_monitor_target AS t
           SET title = p_title,
               target_ref = p_target_ref,
               target_revision = p_target_revision,
               target_payload_hash = p_target_payload_hash,
               monitor_reason = p_monitor_reason,
               monitor_state = p_monitor_state,
               monitor_policy = p_monitor_policy,
               consent_refs = v_canonical_consent_refs,
               source_refs = v_canonical_source_refs,
               evidence_refs = v_canonical_evidence_refs,
               baseline_ref = p_baseline_ref,
               current_revision = v_revision,
               payload_hash = v_payload_hash,
               updated_at = NOW()
         WHERE t.owner_user_id = v_owner
           AND t.monitor_id = p_monitor_id;
    END IF;

    INSERT INTO public.mb13_p0_monitor_target_revision (
        owner_user_id, monitor_id, revision, monitor_state, payload_hash,
        target_ref, target_revision, target_payload_hash,
        monitor_reason, monitor_policy, consent_refs, source_refs, evidence_refs, baseline_ref,
        request_payload, result_payload
    ) VALUES (
        v_owner, p_monitor_id, v_revision, p_monitor_state, v_payload_hash,
        p_target_ref, p_target_revision, p_target_payload_hash,
        p_monitor_reason, p_monitor_policy, v_canonical_consent_refs, v_canonical_source_refs, v_canonical_evidence_refs, p_baseline_ref,
        p_request_payload, v_result_payload
    );

    IF v_event_type IS NOT NULL THEN
        v_event_id := gen_random_uuid();
        v_event_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'event_id', v_event_id,
            'owner_user_id', v_owner,
            'monitor_id', p_monitor_id,
            'monitor_revision', v_revision,
            'event_type', v_event_type,
            'event_status', 'recorded',
            'event_time', to_jsonb(v_event_time),
            'observed_ref', '{}'::jsonb,
            'source_refs', v_canonical_source_refs,
            'evidence_refs', v_canonical_evidence_refs,
            'consent_refs', v_canonical_consent_refs,
            'reason', NULL,
            'result_payload', v_result_payload
        ));
        INSERT INTO public.mb13_p0_monitor_event_ledger (
            event_id, owner_user_id, monitor_id, monitor_revision, event_type, event_status, event_time,
            observed_ref, source_refs, evidence_refs, consent_refs, reason, result_payload, payload_hash
        ) VALUES (
            v_event_id, v_owner, p_monitor_id, v_revision, v_event_type, 'recorded', v_event_time,
            '{}'::jsonb, v_canonical_source_refs, v_canonical_evidence_refs, v_canonical_consent_refs, NULL, v_result_payload, v_event_payload_hash
        );
    END IF;

    RETURN QUERY SELECT p_monitor_id, v_revision, v_payload_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_write_monitor(UUID,TEXT,TEXT,TEXT,JSONB,INTEGER,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB) FROM PUBLIC;

-- Authoritative revoke: locks the current row, appends a 'revoked' revision,
-- updates the current row, and appends a MONITOR_REVOKED event atomically.
CREATE OR REPLACE FUNCTION public.mb13_p0_revoke_monitor(
    p_monitor_id UUID,
    p_reason TEXT
) RETURNS TABLE(monitor_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_revision INTEGER;
    v_payload_hash TEXT;
    v_result_payload JSONB;
    v_event_id UUID;
    v_event_payload_hash TEXT;
    v_event_time TIMESTAMPTZ := NOW();
    v_canonical_consent_refs JSONB;
    v_canonical_source_refs JSONB;
    v_canonical_evidence_refs JSONB;
    v_canonical JSONB;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p0_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p0_monitor_identity_invalid';
    END IF;
    IF length(trim(COALESCE(p_reason, ''))) = 0 OR length(p_reason) > 500 THEN
        RAISE EXCEPTION 'mb13_p0_revocation_reason_invalid';
    END IF;

    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_monitor_id::text, 0));

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = v_owner
       AND t.monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p0_monitor_not_found';
    END IF;
    IF v_current.monitor_state = 'revoked' THEN
        RETURN QUERY SELECT v_current.monitor_id, v_current.current_revision, v_current.payload_hash::TEXT;
        RETURN;
    END IF;

    v_revision := v_current.current_revision + 1;
    v_canonical_consent_refs := public.mb13_p0_normalize_jsonb_array(v_current.consent_refs);
    v_canonical_source_refs := public.mb13_p0_normalize_jsonb_array(v_current.source_refs);
    v_canonical_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_current.evidence_refs);

    v_result_payload := jsonb_build_object(
        'monitor_state', 'revoked',
        'reason', p_reason,
        'no_auto_action', true,
        'no_auto_notification', true
    );

    v_canonical := jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'stable_id', v_current.stable_id,
        'title', v_current.title,
        'target_type', v_current.target_type,
        'target_ref', v_current.target_ref,
        'target_revision', v_current.target_revision,
        'target_payload_hash', v_current.target_payload_hash,
        'monitor_reason', v_current.monitor_reason,
        'monitor_state', 'revoked',
        'monitor_policy', v_current.monitor_policy,
        'consent_refs', v_canonical_consent_refs,
        'source_refs', v_canonical_source_refs,
        'evidence_refs', v_canonical_evidence_refs,
        'baseline_ref', v_current.baseline_ref,
        'request_payload', jsonb_build_object('action','revoke','reason',p_reason),
        'result_payload', v_result_payload,
        'revision', v_revision
    );
    v_payload_hash := public.mb13_p0_hash_jsonb(v_canonical);

    INSERT INTO public.mb13_p0_monitor_target_revision (
        owner_user_id, monitor_id, revision, monitor_state, payload_hash,
        target_ref, target_revision, target_payload_hash,
        monitor_reason, monitor_policy, consent_refs, source_refs, evidence_refs, baseline_ref,
        request_payload, result_payload
    ) VALUES (
        v_owner, p_monitor_id, v_revision, 'revoked', v_payload_hash,
        v_current.target_ref, v_current.target_revision, v_current.target_payload_hash,
        v_current.monitor_reason, v_current.monitor_policy,
        v_canonical_consent_refs, v_canonical_source_refs, v_canonical_evidence_refs, v_current.baseline_ref,
        jsonb_build_object('action','revoke','reason',p_reason), v_result_payload
    );

    UPDATE public.mb13_p0_monitor_target AS t
       SET monitor_state = 'revoked',
           current_revision = v_revision,
           payload_hash = v_payload_hash,
           updated_at = NOW()
     WHERE t.owner_user_id = v_owner
       AND t.monitor_id = p_monitor_id;

    v_event_id := gen_random_uuid();
    v_event_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'event_id', v_event_id,
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_revision,
        'event_type', 'MONITOR_REVOKED',
        'event_status', 'recorded',
        'event_time', to_jsonb(v_event_time),
        'observed_ref', '{}'::jsonb,
        'source_refs', v_canonical_source_refs,
        'evidence_refs', v_canonical_evidence_refs,
        'consent_refs', v_canonical_consent_refs,
        'reason', p_reason,
        'result_payload', v_result_payload
    ));
    INSERT INTO public.mb13_p0_monitor_event_ledger (
        event_id, owner_user_id, monitor_id, monitor_revision, event_type, event_status, event_time,
        observed_ref, source_refs, evidence_refs, consent_refs, reason, result_payload, payload_hash
    ) VALUES (
        v_event_id, v_owner, p_monitor_id, v_revision, 'MONITOR_REVOKED', 'recorded', v_event_time,
        '{}'::jsonb, v_canonical_source_refs, v_canonical_evidence_refs, v_canonical_consent_refs, p_reason, v_result_payload, v_event_payload_hash
    );

    RETURN QUERY SELECT p_monitor_id, v_revision, v_payload_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_revoke_monitor(UUID,TEXT) FROM PUBLIC;

-- Authoritative event recorder for operational events.  Provenance is taken
-- from the monitor, not from the caller, and the caller cannot store lifecycle
-- events that are reserved for the writer/revoke functions.
CREATE OR REPLACE FUNCTION public.mb13_p0_record_monitor_event(
    p_event_id UUID,
    p_monitor_id UUID,
    p_monitor_revision INTEGER,
    p_event_type TEXT,
    p_event_status TEXT,
    p_event_time TIMESTAMPTZ,
    p_observed_ref JSONB,
    p_source_refs JSONB,
    p_evidence_refs JSONB,
    p_consent_refs JSONB,
    p_reason TEXT,
    p_result_payload JSONB
) RETURNS TABLE(event_id UUID, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_payload_hash TEXT;
    v_result_payload JSONB;
    v_observed JSONB;
    v_event_time TIMESTAMPTZ := COALESCE(p_event_time, NOW());
    v_canonical_consent_refs JSONB;
    v_canonical_source_refs JSONB;
    v_canonical_evidence_refs JSONB;
    v_event_uuid UUID;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p0_owner_missing';
    END IF;
    IF p_monitor_id IS NULL OR p_monitor_revision IS NULL THEN
        RAISE EXCEPTION 'mb13_p0_event_identity_invalid';
    END IF;
    IF p_event_type IS NULL OR p_event_type IN ('MONITOR_CREATED','MONITOR_ACTIVATED','MONITOR_PAUSED','MONITOR_RESUMED','MONITOR_BLOCKED','MONITOR_REVOKED') THEN
        RAISE EXCEPTION 'mb13_p0_event_type_not_allowed';
    END IF;
    IF p_event_type NOT IN ('CHECK_DUE','CHECK_STARTED','CHECK_COMPLETED','CHECK_FAILED','NO_CHANGE_RECORDED','CHANGE_CANDIDATE_RECORDED') THEN
        RAISE EXCEPTION 'mb13_p0_event_type_invalid';
    END IF;
    IF p_event_status IS NULL OR p_event_status NOT IN ('pending','recorded','superseded','failed') THEN
        RAISE EXCEPTION 'mb13_p0_event_status_invalid';
    END IF;
    IF p_reason IS NOT NULL AND length(p_reason) > 500 THEN
        RAISE EXCEPTION 'mb13_p0_event_reason_invalid';
    END IF;
    IF jsonb_typeof(COALESCE(p_observed_ref, '{}'::jsonb)) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p0_observed_ref_invalid';
    END IF;

    -- Serialize event recording for this monitor.
    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_monitor_id::text, 0));

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = v_owner
       AND t.monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p0_monitor_not_found';
    END IF;
    IF v_current.monitor_state <> 'active' THEN
        RAISE EXCEPTION 'mb13_p0_monitor_not_active';
    END IF;
    IF v_current.current_revision <> p_monitor_revision THEN
        RAISE EXCEPTION 'mb13_p0_monitor_revision_not_current';
    END IF;

    -- Operational events require target currentness and active consent/lock.
    IF p_event_type = 'CHANGE_CANDIDATE_RECORDED' THEN
        v_observed := COALESCE(NULLIF(p_observed_ref, '{}'::jsonb), v_current.target_ref);
        IF v_observed->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
            RAISE EXCEPTION 'mb13_p0_target_owner_mismatch';
        END IF;
        PERFORM public.mb13_p0_validate_target(v_owner, v_current.target_type, v_observed, p_for_active => FALSE);
    ELSE
        v_observed := v_current.target_ref;
        PERFORM public.mb13_p0_validate_target(v_owner, v_current.target_type, v_current.target_ref, p_for_active => FALSE);
    END IF;

    v_canonical_consent_refs := public.mb13_p0_lock_and_verify_consents(
        v_owner, v_current.consent_refs, v_current.target_type, v_current.target_ref, p_required => TRUE
    );

    v_canonical_source_refs := public.mb13_p0_normalize_jsonb_array(v_current.source_refs);
    v_canonical_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_current.evidence_refs);

    v_result_payload := COALESCE(p_result_payload, '{}'::jsonb) || jsonb_build_object(
        'event_type', p_event_type,
        'event_status', p_event_status,
        'no_auto_action', true,
        'no_auto_notification', true
    );

    v_event_uuid := COALESCE(p_event_id, gen_random_uuid());
    v_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'event_id', v_event_uuid,
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', p_monitor_revision,
        'event_type', p_event_type,
        'event_status', p_event_status,
        'event_time', to_jsonb(v_event_time),
        'observed_ref', v_observed,
        'source_refs', v_canonical_source_refs,
        'evidence_refs', v_canonical_evidence_refs,
        'consent_refs', v_canonical_consent_refs,
        'reason', p_reason,
        'result_payload', v_result_payload
    ));

    INSERT INTO public.mb13_p0_monitor_event_ledger (
        event_id, owner_user_id, monitor_id, monitor_revision, event_type, event_status, event_time,
        observed_ref, source_refs, evidence_refs, consent_refs, reason, result_payload, payload_hash
    ) VALUES (
        v_event_uuid, v_owner, p_monitor_id, p_monitor_revision, p_event_type, p_event_status, v_event_time,
        v_observed, v_canonical_source_refs, v_canonical_evidence_refs, v_canonical_consent_refs, p_reason, v_result_payload, v_payload_hash
    );

    RETURN QUERY SELECT v_event_uuid, v_payload_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_record_monitor_event(UUID,UUID,INTEGER,TEXT,TEXT,TIMESTAMPTZ,JSONB,JSONB,JSONB,JSONB,TEXT,JSONB) FROM PUBLIC;

-- Allow the application role to invoke only these authoritative functions.
GRANT EXECUTE ON FUNCTION public.mb13_p0_write_monitor(UUID,TEXT,TEXT,TEXT,JSONB,INTEGER,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB) TO mb13_p0_app;
GRANT EXECUTE ON FUNCTION public.mb13_p0_revoke_monitor(UUID,TEXT) TO mb13_p0_app;
GRANT EXECUTE ON FUNCTION public.mb13_p0_record_monitor_event(UUID,UUID,INTEGER,TEXT,TEXT,TIMESTAMPTZ,JSONB,JSONB,JSONB,JSONB,TEXT,JSONB) TO mb13_p0_app;

-- Internal helpers are not directly invocable by the application role.
REVOKE EXECUTE ON FUNCTION public.mb13_p0_hash_jsonb(JSONB) FROM PUBLIC, mb13_p0_app;
REVOKE EXECUTE ON FUNCTION public.mb13_p0_normalize_jsonb_array(JSONB) FROM PUBLIC, mb13_p0_app;
REVOKE EXECUTE ON FUNCTION public.mb13_p0_validate_temporal_policy(JSONB) FROM PUBLIC, mb13_p0_app;
REVOKE EXECUTE ON FUNCTION public.mb13_p0_validate_target(UUID,TEXT,JSONB,BOOLEAN) FROM PUBLIC, mb13_p0_app;
REVOKE EXECUTE ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID,JSONB,TEXT,JSONB,BOOLEAN) FROM PUBLIC, mb13_p0_app;

-- Ensure no direct DML on the ledger tables from PUBLIC or the app role.
REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER
    ON public.mb13_p0_monitor_target,
       public.mb13_p0_monitor_target_revision,
       public.mb13_p0_monitor_event_ledger
    FROM PUBLIC, mb13_p0_app;
GRANT SELECT
    ON public.mb13_p0_monitor_target,
       public.mb13_p0_monitor_target_revision,
       public.mb13_p0_monitor_event_ledger
    TO mb13_p0_app;

COMMIT;
