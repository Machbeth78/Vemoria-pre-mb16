-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V4.6 — Migration V26
-- Aggiunge tipo_invio come campo strutturato a eventi_invio.
-- Idempotente.

ALTER TABLE eventi_invio
    ADD COLUMN IF NOT EXISTS tipo_invio TEXT NOT NULL DEFAULT 'standard'
        CHECK (tipo_invio IN ('standard', 'copyright', 'convalida'));

CREATE INDEX IF NOT EXISTS idx_eventi_tipo_invio ON eventi_invio(tipo_invio);

COMMENT ON COLUMN eventi_invio.tipo_invio IS
    'Modalità invio: standard | copyright | convalida. '
    'Determina il flusso applicativo lato backend.';
