-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB12-P0 R1B — Governance repair migration for existing R1A deployments.
-- Additive and idempotent: adds missing columns/constraints and migrates any
-- leftover v175 revision history rows.

BEGIN;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'mb12_p0_foundation_entity' AND column_name = 'source_authority_state'
    ) THEN
        ALTER TABLE mb12_p0_foundation_entity ADD COLUMN source_authority_state TEXT NOT NULL DEFAULT 'unknown';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'mb12_p0_foundation_entity' AND column_name = 'jurisdiction_applicability_state'
    ) THEN
        ALTER TABLE mb12_p0_foundation_entity ADD COLUMN jurisdiction_applicability_state TEXT NOT NULL DEFAULT 'unknown';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'mb12_p0_foundation_entity' AND column_name = 'payload_hash'
    ) THEN
        ALTER TABLE mb12_p0_foundation_entity ADD COLUMN payload_hash TEXT NOT NULL DEFAULT '';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'mb12_p0_eligibility_evaluation' AND column_name = 'request_id'
    ) THEN
        ALTER TABLE mb12_p0_eligibility_evaluation ADD COLUMN request_id TEXT NOT NULL DEFAULT '';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'mb12_p0_eligibility_evaluation' AND column_name = 'dossier_id'
    ) THEN
        ALTER TABLE mb12_p0_eligibility_evaluation ADD COLUMN dossier_id TEXT NOT NULL DEFAULT '';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'mb12_p0_eligibility_evaluation' AND column_name = 'rule_set_id'
    ) THEN
        ALTER TABLE mb12_p0_eligibility_evaluation ADD COLUMN rule_set_id TEXT NOT NULL DEFAULT '';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'mb12_p0_revision_history' AND column_name = 'payload_hash'
    ) THEN
        ALTER TABLE mb12_p0_revision_history ADD COLUMN payload_hash TEXT NOT NULL DEFAULT '';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'mb12_p0_revision_history' AND column_name = 'previous_revision'
    ) THEN
        ALTER TABLE mb12_p0_revision_history ADD COLUMN previous_revision INT;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'mb12_p0_revision_history' AND column_name = 'payload_version'
    ) THEN
        ALTER TABLE mb12_p0_revision_history ADD COLUMN payload_version TEXT NOT NULL DEFAULT 'r1b';
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints
        WHERE table_name = 'mb12_p0_foundation_entity' AND constraint_name = 'chk_mb12_p0_retroactivity_state'
    ) THEN
        ALTER TABLE mb12_p0_foundation_entity
        ADD CONSTRAINT chk_mb12_p0_retroactivity_state
        CHECK (retroactivity_state IN ('none', 'proactive', 'retroactive', 'transitional'));
    END IF;
END $$;

-- Rename any leftover v175 revision history table and migrate rows.
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relname = 'mb12_p0_revision_history' AND c.relkind = 'r'
    ) AND NOT EXISTS (
        SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relname = 'mb12_p0_revision_history_r1_deprecated' AND c.relkind = 'r'
    ) THEN
        ALTER TABLE mb12_p0_revision_history RENAME TO mb12_p0_revision_history_r1_deprecated;
    END IF;
END $$;

DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relname = 'mb12_p0_revision_history_r1_deprecated' AND c.relkind = 'r'
    ) THEN
        INSERT INTO mb12_p0_revision_history (
            owner_user_id, record_id, entity_type, revision, operation,
            payload, payload_hash, previous_revision, payload_version, source_refs, provenance, created_at
        )
        SELECT
            d.owner_user_id,
            d.record_id,
            d.entity_type,
            d.revision::int,
            d.operation,
            jsonb_build_object(
                'entity_id', d.record_id,
                'entity_type', d.entity_type,
                'stable_id', d.record_id,
                'revision', d.revision::int,
                'canonical_name', '',
                'state', 'promoted',
                'status', 'promoted',
                'data', d.payload,
                'source_refs', d.source_refs,
                'owner_id', d.owner_user_id::text,
                'source_authority_state', 'unknown',
                'jurisdiction_applicability_state', 'unknown',
                'jurisdiction_state', 'unknown',
                'territory_state', '',
                'confidence', 0.0,
                'uncertainty', '{}'::jsonb,
                'provenance', '{}'::jsonb,
                'retroactivity_state', 'none',
                'unknown_validity', false,
                'conflicting_validity', false
            ),
            '',
            NULL,
            'v175',
            d.source_refs,
            jsonb_build_object('migrated_from', 'mb12_p0_revision_history_r1_deprecated'),
            d.created_at
        FROM mb12_p0_revision_history_r1_deprecated d
        WHERE NOT EXISTS (
            SELECT 1 FROM mb12_p0_revision_history h
            WHERE h.owner_user_id = d.owner_user_id
              AND h.record_id = d.record_id
              AND h.revision = d.revision::int
              AND h.operation = d.operation
              AND h.payload_version = 'v175'
        );
    END IF;
END $$;

COMMIT;
