-- ===========================================================================
-- VEMORA V245 — MB14-P2 Rich Communication
-- ===========================================================================
-- Scope:
--   1. Extend conversation_message/draft with rich message types.
--   2. Attachment reference metadata + integrity + access state.
--   3. Canonical card envelope (conversation_card).
--   4. Explicit governed sharing grants + revocation.
--   5. Rich timeline events and diagnostic traceability.
--   6. RLS owner isolation + least-privilege grants.
--
-- NON modifica MB0→MB13 / MB14-P0 / MB14-P1; solo additive.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- 1. Extend message_type enum on conversation_message and conversation_draft
-- ---------------------------------------------------------------------------
ALTER TABLE conversation_message
    DROP CONSTRAINT IF EXISTS conversation_message_message_type_check;
ALTER TABLE conversation_message
    ADD CONSTRAINT conversation_message_message_type_check
    CHECK (message_type IN (
        'TEXT','ATTACHMENT','CARD','SYSTEM_EVENT',
        'DOCUMENT_CARD','CONTACT_CARD','EVIDENCE_CARD','ACTION_CARD',
        'PROCEDURE_CARD','SAFETY_CARD','THREAT_CARD','INCIDENT_CARD',
        'EXPERIENCE_CAPSULE'
    ));

ALTER TABLE conversation_draft
    DROP CONSTRAINT IF EXISTS conversation_draft_message_type_check;
ALTER TABLE conversation_draft
    ADD CONSTRAINT conversation_draft_message_type_check
    CHECK (message_type IN (
        'TEXT','ATTACHMENT','CARD','SYSTEM_EVENT',
        'DOCUMENT_CARD','CONTACT_CARD','EVIDENCE_CARD','ACTION_CARD',
        'PROCEDURE_CARD','SAFETY_CARD','THREAT_CARD','INCIDENT_CARD',
        'EXPERIENCE_CAPSULE'
    ));

-- ---------------------------------------------------------------------------
-- 2. Extend message_attachment_reference with canonical metadata
-- ---------------------------------------------------------------------------
ALTER TABLE message_attachment_reference
    ADD COLUMN IF NOT EXISTS resource_type TEXT DEFAULT 'generic',
    ADD COLUMN IF NOT EXISTS resource_id TEXT,
    ADD COLUMN IF NOT EXISTS display_name TEXT,
    ADD COLUMN IF NOT EXISTS mime_type TEXT,
    ADD COLUMN IF NOT EXISTS size_bytes BIGINT,
    ADD COLUMN IF NOT EXISTS sha256 TEXT,
    ADD COLUMN IF NOT EXISTS access_state TEXT NOT NULL DEFAULT 'private',
    ADD COLUMN IF NOT EXISTS integrity_state TEXT NOT NULL DEFAULT 'UNSIGNED',
    ADD COLUMN IF NOT EXISTS sharing_state TEXT NOT NULL DEFAULT 'PRIVATE',
    ADD COLUMN IF NOT EXISTS schema_version TEXT NOT NULL DEFAULT '1.0.0',
    ADD COLUMN IF NOT EXISTS provenance JSONB NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE message_attachment_reference
    DROP CONSTRAINT IF EXISTS message_attachment_reference_access_state_check;
ALTER TABLE message_attachment_reference
    ADD CONSTRAINT message_attachment_reference_access_state_check
    CHECK (access_state IN ('private','shared','revoked'));

ALTER TABLE message_attachment_reference
    DROP CONSTRAINT IF EXISTS message_attachment_reference_integrity_state_check;
ALTER TABLE message_attachment_reference
    ADD CONSTRAINT message_attachment_reference_integrity_state_check
    CHECK (integrity_state IN ('UNSIGNED','INTEGRITY_HASHED','SIGNED','VERIFIED_SIGNATURE'));

ALTER TABLE message_attachment_reference
    DROP CONSTRAINT IF EXISTS message_attachment_reference_sharing_state_check;
ALTER TABLE message_attachment_reference
    ADD CONSTRAINT message_attachment_reference_sharing_state_check
    CHECK (sharing_state IN ('PRIVATE','SHARED','REVOKED'));

-- ---------------------------------------------------------------------------
-- 3. Card envelope
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS conversation_card (
    card_id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    conversation_id     UUID NOT NULL REFERENCES conversation(conversation_id) ON DELETE CASCADE,
    relationship_id     UUID REFERENCES relationship(relationship_id) ON DELETE SET NULL,
    message_id          UUID REFERENCES conversation_message(message_id) ON DELETE SET NULL,
    card_type           TEXT NOT NULL
        CHECK (card_type IN (
            'DOCUMENT_CARD','CONTACT_CARD','EVIDENCE_CARD','ACTION_CARD',
            'PROCEDURE_CARD','SAFETY_CARD','THREAT_CARD','INCIDENT_CARD',
            'EXPERIENCE_CAPSULE','OTHER'
        )),
    schema_version      TEXT NOT NULL DEFAULT '1.0.0',
    issuer_reference    TEXT NOT NULL DEFAULT 'owner',
    payload             JSONB NOT NULL DEFAULT '{}'::jsonb,
    payload_reference   TEXT,
    integrity_hash      TEXT,
    signature_state     TEXT NOT NULL DEFAULT 'UNSIGNED'
        CHECK (signature_state IN ('UNSIGNED','INTEGRITY_HASHED','SIGNED','VERIFIED_SIGNATURE')),
    privacy_classification TEXT NOT NULL DEFAULT 'NORMAL'
        CHECK (privacy_classification IN ('NORMAL','SENSITIVE','HIGH_PRIVACY')),
    provenance          JSONB NOT NULL DEFAULT '{}'::jsonb,
    sharing_state       TEXT NOT NULL DEFAULT 'PRIVATE'
        CHECK (sharing_state IN ('PRIVATE','SHARED','REVOKED')),
    reshare_policy      TEXT NOT NULL DEFAULT 'NO_RESHARE'
        CHECK (reshare_policy IN ('NO_RESHARE','RESHARE_ALLOWED','RESHARE_WITH_CONFIRMATION')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_conversation_card_owner_conv
    ON conversation_card(owner_user_id, conversation_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_conversation_card_message
    ON conversation_card(owner_user_id, message_id);
CREATE INDEX IF NOT EXISTS idx_conversation_card_payload_ref
    ON conversation_card(owner_user_id, payload_reference);

-- ---------------------------------------------------------------------------
-- 4. Sharing grants
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS conversation_sharing_grant (
    grant_id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    resource_type           TEXT NOT NULL
        CHECK (resource_type IN ('ATTACHMENT','CARD','DOCUMENT')),
    resource_id             TEXT NOT NULL,
    sender_relationship_id  UUID REFERENCES relationship(relationship_id) ON DELETE SET NULL,
    recipient_relationship_id UUID REFERENCES relationship(relationship_id) ON DELETE SET NULL,
    action_scope            TEXT NOT NULL DEFAULT 'view',
    purpose                 TEXT,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at              TIMESTAMPTZ,
    revoked_at              TIMESTAMPTZ,
    provenance              JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_conversation_sharing_grant_owner_resource
    ON conversation_sharing_grant(owner_user_id, resource_type, resource_id);
CREATE INDEX IF NOT EXISTS idx_conversation_sharing_grant_recipient
    ON conversation_sharing_grant(owner_user_id, recipient_relationship_id, revoked_at);

-- ---------------------------------------------------------------------------
-- 5. Extend timeline events
-- ---------------------------------------------------------------------------
ALTER TABLE conversation_timeline_event
    DROP CONSTRAINT IF EXISTS conversation_timeline_event_event_type_check;
ALTER TABLE conversation_timeline_event
    ADD CONSTRAINT conversation_timeline_event_event_type_check
    CHECK (event_type IN (
        'conversation_created','message_drafted','message_authorized','message_queued',
        'message_sent','message_failed','message_received','message_read','conversation_archived',
        'attachment_added','document_card_sent','document_card_received','sharing_grant_created',
        'sharing_revoked','card_validation_failed'
    ));

-- ---------------------------------------------------------------------------
-- 6. Diagnostic traceability (MB14.*)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mb14_rich_communication_diagnostic (
    diagnostic_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    conversation_id     UUID REFERENCES conversation(conversation_id) ON DELETE SET NULL,
    message_id          UUID REFERENCES conversation_message(message_id) ON DELETE SET NULL,
    card_id             UUID REFERENCES conversation_card(card_id) ON DELETE SET NULL,
    grant_id            UUID REFERENCES conversation_sharing_grant(grant_id) ON DELETE SET NULL,
    event_code          TEXT NOT NULL,
    status              TEXT NOT NULL,
    severity            TEXT NOT NULL DEFAULT 'info',
    payload_json        JSONB NOT NULL DEFAULT '{}'::jsonb,
    timestamp_utc       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mb14_diag_owner_code
    ON mb14_rich_communication_diagnostic(owner_user_id, event_code, timestamp_utc DESC);
CREATE INDEX IF NOT EXISTS idx_mb14_diag_conv
    ON mb14_rich_communication_diagnostic(owner_user_id, conversation_id, timestamp_utc DESC);

-- ---------------------------------------------------------------------------
-- 7. RLS owner isolation
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    ALTER TABLE message_attachment_reference ENABLE ROW LEVEL SECURITY;
    ALTER TABLE message_attachment_reference FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS message_attachment_reference_owner_isolation ON message_attachment_reference;
    CREATE POLICY message_attachment_reference_owner_isolation ON message_attachment_reference
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND (
                message_id IS NULL
                OR message_id IN (SELECT message_id FROM conversation_message)
            )
            AND (
                draft_id IS NULL
                OR draft_id IN (SELECT draft_id FROM conversation_draft)
            )
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND (
                message_id IS NULL
                OR message_id IN (SELECT message_id FROM conversation_message)
            )
            AND (
                draft_id IS NULL
                OR draft_id IN (SELECT draft_id FROM conversation_draft)
            )
        );

    ALTER TABLE conversation_card ENABLE ROW LEVEL SECURITY;
    ALTER TABLE conversation_card FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS conversation_card_owner_isolation ON conversation_card;
    CREATE POLICY conversation_card_owner_isolation ON conversation_card
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND conversation_id IN (SELECT conversation_id FROM conversation)
            AND (message_id IS NULL OR message_id IN (SELECT message_id FROM conversation_message))
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND conversation_id IN (SELECT conversation_id FROM conversation)
            AND (message_id IS NULL OR message_id IN (SELECT message_id FROM conversation_message))
        );

    ALTER TABLE conversation_sharing_grant ENABLE ROW LEVEL SECURITY;
    ALTER TABLE conversation_sharing_grant FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS conversation_sharing_grant_owner_isolation ON conversation_sharing_grant;
    CREATE POLICY conversation_sharing_grant_owner_isolation ON conversation_sharing_grant
        FOR ALL
        USING (owner_user_id = _rls_owner_uuid())
        WITH CHECK (owner_user_id = _rls_owner_uuid());

    ALTER TABLE mb14_rich_communication_diagnostic ENABLE ROW LEVEL SECURITY;
    ALTER TABLE mb14_rich_communication_diagnostic FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS mb14_diag_owner_isolation ON mb14_rich_communication_diagnostic;
    CREATE POLICY mb14_diag_owner_isolation ON mb14_rich_communication_diagnostic
        FOR ALL
        USING (owner_user_id = _rls_owner_uuid())
        WITH CHECK (owner_user_id = _rls_owner_uuid());
END $$;

-- ---------------------------------------------------------------------------
-- 8. Least-privilege grants
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p2_api') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE conversation_card TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE conversation_sharing_grant TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE mb14_rich_communication_diagnostic TO mb13_p2_api;
    END IF;
END $$;
