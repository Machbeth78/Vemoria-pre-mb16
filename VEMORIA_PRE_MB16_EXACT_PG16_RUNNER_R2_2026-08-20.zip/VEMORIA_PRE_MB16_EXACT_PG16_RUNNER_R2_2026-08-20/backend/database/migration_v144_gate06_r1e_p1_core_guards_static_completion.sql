-- Gate06 R1E — P1 Core Guards static completion
-- Static bookkeeping only. Does not claim real runtime, Cerebro activation, PostgreSQL execution, or Android execution.

CREATE TABLE IF NOT EXISTS gate06_p1_core_guards_static_completion (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vc_id TEXT NOT NULL,
    completion_gate TEXT NOT NULL DEFAULT 'GATE06_R1E_P1_CORE_GUARDS_STATIC_COMPLETION',
    static_completion_state TEXT NOT NULL DEFAULT 'STATIC_COMPLETED_RUNTIME_DEFERRED',
    runtime_state TEXT NOT NULL,
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE,
    cerebro_real_activated BOOLEAN NOT NULL DEFAULT FALSE,
    source_atlas_version TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(vc_id, completion_gate),
    CHECK (vc_id IN ('VC-014','VC-019','VC-020','VC-015','VC-016','VC-017','VC-021')),
    CHECK (runtime_pass_claimed = FALSE),
    CHECK (cerebro_real_activated = FALSE)
);

CREATE INDEX IF NOT EXISTS idx_gate06_p1_core_guards_completion_vc
    ON gate06_p1_core_guards_static_completion(vc_id, created_at DESC);

CREATE TABLE IF NOT EXISTS gate06_p1_core_guards_runtime_probe_requirements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vc_id TEXT NOT NULL,
    required_probe TEXT NOT NULL,
    required_before_runtime_pass BOOLEAN NOT NULL DEFAULT TRUE,
    risk_and_confirmation_required BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (vc_id IN ('VC-014','VC-019','VC-020','VC-015','VC-016','VC-017','VC-021')),
    CHECK (required_before_runtime_pass = TRUE),
    CHECK (risk_and_confirmation_required = TRUE)
);

CREATE INDEX IF NOT EXISTS idx_gate06_p1_probe_requirements_vc
    ON gate06_p1_core_guards_runtime_probe_requirements(vc_id);
