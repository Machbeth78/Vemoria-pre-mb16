-- Vemoria Gate07C — prima proiezione reale contenuto/occorrenza dal log canonico.
-- Additiva, owner-scoped, ricostruibile. Il log Gate07B resta l'unica verità.
-- Nessuna timeline, ricerca o Cerebro viene migrata in questo gate.
BEGIN;

CREATE TABLE IF NOT EXISTS canonical_content_projection (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    canonical_content_id TEXT NOT NULL,
    content_sha256 CHAR(64) NOT NULL CHECK (content_sha256 ~ '^[0-9a-f]{64}$'),
    content_kind TEXT NOT NULL,
    state TEXT NOT NULL,
    is_private BOOLEAN NOT NULL DEFAULT FALSE,
    version INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),
    description TEXT,
    first_event_id TEXT NOT NULL,
    last_event_id TEXT NOT NULL,
    last_lamport_clock BIGINT NOT NULL CHECK (last_lamport_clock >= 1),
    updated_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY(owner_user_id, canonical_content_id),
    UNIQUE(owner_user_id, content_sha256),
    FOREIGN KEY(owner_user_id, first_event_id)
        REFERENCES canonical_event_log(owner_user_id, event_id),
    FOREIGN KEY(owner_user_id, last_event_id)
        REFERENCES canonical_event_log(owner_user_id, event_id),
    CHECK (canonical_content_id = 'cnt_' || content_sha256)
);

CREATE TABLE IF NOT EXISTS canonical_content_alias_projection (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    source_content_id TEXT NOT NULL,
    canonical_content_id TEXT NOT NULL,
    first_event_id TEXT NOT NULL,
    last_event_id TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY(owner_user_id, source_content_id),
    FOREIGN KEY(owner_user_id, canonical_content_id)
        REFERENCES canonical_content_projection(owner_user_id, canonical_content_id)
        ON DELETE CASCADE,
    FOREIGN KEY(owner_user_id, first_event_id)
        REFERENCES canonical_event_log(owner_user_id, event_id),
    FOREIGN KEY(owner_user_id, last_event_id)
        REFERENCES canonical_event_log(owner_user_id, event_id)
);

CREATE TABLE IF NOT EXISTS canonical_content_occurrence_projection (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    occurrence_id TEXT NOT NULL,
    canonical_content_id TEXT NOT NULL,
    device_id TEXT NOT NULL,
    source_ref TEXT NOT NULL,
    opaque_local_ref TEXT,
    path_fingerprint TEXT,
    origin TEXT NOT NULL,
    availability TEXT NOT NULL CHECK (availability IN ('AVAILABLE','UNAVAILABLE','DELETED')),
    first_event_id TEXT NOT NULL,
    last_event_id TEXT NOT NULL,
    last_lamport_clock BIGINT NOT NULL CHECK (last_lamport_clock >= 1),
    updated_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY(owner_user_id, occurrence_id),
    FOREIGN KEY(owner_user_id, canonical_content_id)
        REFERENCES canonical_content_projection(owner_user_id, canonical_content_id)
        ON DELETE CASCADE,
    FOREIGN KEY(owner_user_id, first_event_id)
        REFERENCES canonical_event_log(owner_user_id, event_id),
    FOREIGN KEY(owner_user_id, last_event_id)
        REFERENCES canonical_event_log(owner_user_id, event_id),
    CHECK (opaque_local_ref IS NULL OR opaque_local_ref ~ '^localref:[0-9a-f]{32,64}$'),
    CHECK (path_fingerprint IS NULL OR path_fingerprint ~ '^[0-9a-f]{64}$')
);

CREATE TABLE IF NOT EXISTS canonical_projection_applied_events (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    projection_name TEXT NOT NULL,
    event_id TEXT NOT NULL,
    lamport_clock BIGINT NOT NULL CHECK (lamport_clock >= 1),
    device_id TEXT NOT NULL,
    device_sequence BIGINT NOT NULL CHECK (device_sequence >= 1),
    applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY(owner_user_id, projection_name, event_id),
    FOREIGN KEY(owner_user_id, event_id)
        REFERENCES canonical_event_log(owner_user_id, event_id)
);

CREATE TABLE IF NOT EXISTS canonical_projection_watermarks (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    projection_name TEXT NOT NULL,
    schema_version INTEGER NOT NULL CHECK (schema_version >= 1),
    last_lamport_clock BIGINT NOT NULL DEFAULT 0 CHECK (last_lamport_clock >= 0),
    last_order_device_id TEXT,
    last_order_device_sequence BIGINT NOT NULL DEFAULT 0 CHECK (last_order_device_sequence >= 0),
    last_event_id TEXT,
    device_sequences JSONB NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(device_sequences)='object'),
    consistency TEXT NOT NULL DEFAULT 'COMPLETE' CHECK (consistency IN ('COMPLETE','STALE','INCONSISTENT')),
    rebuilt_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY(owner_user_id, projection_name),
    FOREIGN KEY(owner_user_id, last_event_id)
        REFERENCES canonical_event_log(owner_user_id, event_id)
);

CREATE INDEX IF NOT EXISTS idx_canonical_content_projection_owner_kind
    ON canonical_content_projection(owner_user_id, content_kind, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_canonical_occurrence_owner_content
    ON canonical_content_occurrence_projection(owner_user_id, canonical_content_id, availability);
CREATE INDEX IF NOT EXISTS idx_canonical_occurrence_owner_device
    ON canonical_content_occurrence_projection(owner_user_id, device_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_canonical_projection_applied_order
    ON canonical_projection_applied_events(owner_user_id, projection_name, lamport_clock, device_id, device_sequence);

ALTER TABLE canonical_content_projection ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_content_alias_projection ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_content_occurrence_projection ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_projection_applied_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_projection_watermarks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS canonical_content_projection_owner_policy ON canonical_content_projection;
CREATE POLICY canonical_content_projection_owner_policy ON canonical_content_projection
    USING (owner_user_id::text = current_setting('app.owner_id', true))
    WITH CHECK (owner_user_id::text = current_setting('app.owner_id', true));

DROP POLICY IF EXISTS canonical_content_alias_owner_policy ON canonical_content_alias_projection;
CREATE POLICY canonical_content_alias_owner_policy ON canonical_content_alias_projection
    USING (owner_user_id::text = current_setting('app.owner_id', true))
    WITH CHECK (owner_user_id::text = current_setting('app.owner_id', true));

DROP POLICY IF EXISTS canonical_content_occurrence_owner_policy ON canonical_content_occurrence_projection;
CREATE POLICY canonical_content_occurrence_owner_policy ON canonical_content_occurrence_projection
    USING (owner_user_id::text = current_setting('app.owner_id', true))
    WITH CHECK (owner_user_id::text = current_setting('app.owner_id', true));

DROP POLICY IF EXISTS canonical_projection_applied_owner_policy ON canonical_projection_applied_events;
CREATE POLICY canonical_projection_applied_owner_policy ON canonical_projection_applied_events
    USING (owner_user_id::text = current_setting('app.owner_id', true))
    WITH CHECK (owner_user_id::text = current_setting('app.owner_id', true));

DROP POLICY IF EXISTS canonical_projection_watermark_owner_policy ON canonical_projection_watermarks;
CREATE POLICY canonical_projection_watermark_owner_policy ON canonical_projection_watermarks
    USING (owner_user_id::text = current_setting('app.owner_id', true))
    WITH CHECK (owner_user_id::text = current_setting('app.owner_id', true));

COMMENT ON TABLE canonical_content_projection IS
    'Gate07C rebuildable logical content identity projection; never canonical truth.';
COMMENT ON TABLE canonical_content_alias_projection IS
    'Maps legacy/source content IDs to deterministic cnt_<sha256> identities.';
COMMENT ON TABLE canonical_content_occurrence_projection IS
    'Rebuildable physical/source occurrences; no raw filesystem path is stored.';
COMMENT ON TABLE canonical_projection_applied_events IS
    'Idempotency ledger for materialized projections; rebuildable from canonical log.';
COMMENT ON TABLE canonical_projection_watermarks IS
    'Projection freshness and per-device watermarks. STALE views must not serve as current.';

COMMIT;
