-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.
--
-- MB8→MB9 correction R1 — Real source connector adapters and canonical consent binding.
-- Additive migration. Extends v233 to support:
--   - pending/aborted source item states for two-phase consent verification;
--   - linked_memory_id to wire source items to real memory rows;
--   - grants for the existing source_connections / source_consent_log tables
--     so MB9 can validate consent_fingerprint without creating a second consent system.

BEGIN;

-- ------------------------------------------------------------------
-- Extend mb9_personal_source_item state machine for run/commit split.
-- A run can be prepared (pending) and later committed. A commit with a
-- revoked grant aborts instead of activating.
-- ------------------------------------------------------------------
DO $$
DECLARE
    v_constraint text;
BEGIN
    SELECT conname INTO v_constraint
    FROM pg_constraint
    WHERE conrelid = 'public.mb9_personal_source_item'::regclass
      AND contype = 'c'
      AND pg_get_expr(conbin, conrelid) LIKE '%state%';
    IF v_constraint IS NOT NULL THEN
        EXECUTE format('ALTER TABLE public.mb9_personal_source_item DROP CONSTRAINT %I', v_constraint);
    END IF;
END $$;

ALTER TABLE public.mb9_personal_source_item
    ADD CONSTRAINT mb9_personal_source_item_state_check
    CHECK (state IN ('active','revoked','superseded','pending','aborted'));

-- Canonical display name for the source item (non-identifying, safe for UI).
ALTER TABLE public.mb9_personal_source_item
    ADD COLUMN IF NOT EXISTS canonical_name TEXT;

-- Link to the real memory row produced by the source connector (e.g. memorie.id, contatti_rubrica.id, email_memora.memoria_id).
ALTER TABLE public.mb9_personal_source_item
    ADD COLUMN IF NOT EXISTS linked_memory_id TEXT;

-- Extra non-identifying metadata emitted by the connector adapter (e.g. device status).
ALTER TABLE public.mb9_personal_source_item
    ADD COLUMN IF NOT EXISTS extra_metadata JSONB NOT NULL DEFAULT '{}'::jsonb;

-- ------------------------------------------------------------------
-- Grants for the canonical consent / source tables already in v109.
-- MB9 adapters need SELECT on these tables to validate consent_fingerprint
-- and to read existing connector results without duplicating data.
-- ------------------------------------------------------------------
DO $$
DECLARE
    v_role text := 'test_app';
BEGIN
    IF EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = v_role) THEN
        IF EXISTS (
            SELECT 1 FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE c.relname = 'source_connections' AND n.nspname = 'public' AND c.relkind = 'r'
        ) THEN
            EXECUTE format('GRANT SELECT ON TABLE public.source_connections, public.source_consent_log, public.source_indexed_items, public.contatti_rubrica, public.email_memora, public.memorie TO %I', v_role);
        END IF;
    END IF;
END $$;

COMMIT;
