-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.
--
-- MB8→MB9 — Canonical personal source intake bridge.
-- Additive, owner-scoped, fail-closed. Materializes source intake results into
-- canonical memory and the evidence graph without persisting raw local paths,
-- provider URIs or raw provider identifiers.

BEGIN;

-- ------------------------------------------------------------------
-- Canonical personal source item registry.
-- Each row is a materialization of a source intake event. It carries the
-- provenance chain (source, revision, intake event, run, consent fingerprint,
-- content hash) and the resolved canonical identity id.
-- ------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mb9_personal_source_item (
    owner_user_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    source_item_pk          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    canonical_identity_id   TEXT NOT NULL,
    source_family           TEXT NOT NULL CHECK (source_family IN ('storage','contacts','calendar','email','pec')),
    source_id               TEXT NOT NULL,            -- connector/source instance fingerprint
    source_item_id          TEXT NOT NULL,            -- stable source-side item fingerprint
    revision_id             TEXT NOT NULL,
    intake_event_id         TEXT NOT NULL,
    run_id                  TEXT NOT NULL,
    consent_fingerprint     TEXT NOT NULL,
    content_sha256          TEXT NOT NULL CHECK (content_sha256 ~ '^[0-9a-f]{64}$'),
    verified_content_sha256 TEXT,                     -- hash recomputed by the backend canonical payload
    verified                BOOLEAN NOT NULL DEFAULT FALSE,
    canonical_payload       TEXT,                     -- owner-scoped canonical JSON snippet used for verification
    state                   TEXT NOT NULL DEFAULT 'active' CHECK (state IN ('active','revoked','superseded')),
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_mb9_personal_source_natural_key
    ON mb9_personal_source_item(owner_user_id, source_family, source_id, source_item_id, revision_id, intake_event_id);

CREATE INDEX IF NOT EXISTS idx_mb9_personal_source_identity
    ON mb9_personal_source_item(owner_user_id, canonical_identity_id);

CREATE INDEX IF NOT EXISTS idx_mb9_personal_source_state
    ON mb9_personal_source_item(owner_user_id, source_id, state);

-- Row-level ownership isolation.
ALTER TABLE mb9_personal_source_item ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb9_personal_source_item FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb9_personal_source_item_owner_policy ON mb9_personal_source_item;
CREATE POLICY mb9_personal_source_item_owner_policy ON mb9_personal_source_item
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

-- ------------------------------------------------------------------
-- Extend the evidence model to support superseded events and hide them
-- from active evidence so that new decisions cannot consume them.
-- ------------------------------------------------------------------
ALTER TABLE mb8_evidence_node DROP CONSTRAINT IF EXISTS mb8_evidence_node_event_type_check;
ALTER TABLE mb8_evidence_node ADD CONSTRAINT mb8_evidence_node_event_type_check
    CHECK (event_type IN ('created','revoked','superseded','used_in_decision','used_in_action'));

ALTER TABLE mb8_evidence_audit DROP CONSTRAINT IF EXISTS mb8_evidence_audit_event_type_check;
ALTER TABLE mb8_evidence_audit ADD CONSTRAINT mb8_evidence_audit_event_type_check
    CHECK (event_type IN ('created','revoked','superseded','used_in_decision','used_in_action'));

CREATE OR REPLACE VIEW mb8_active_evidence AS
WITH latest AS (
    SELECT DISTINCT ON (owner_user_id, evidence_id) *
    FROM mb8_evidence_node
    ORDER BY owner_user_id, evidence_id, event_sequence DESC, created_at DESC
)
SELECT *
FROM latest
WHERE event_type NOT IN ('revoked', 'superseded');

-- ------------------------------------------------------------------
-- Minimal grants for the canonical non-superuser application role.
-- ------------------------------------------------------------------
DO $$
DECLARE
    v_role text;
BEGIN
    v_role := 'test_app';
    IF EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = v_role) THEN
        IF EXISTS (
            SELECT 1 FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE c.relname = 'mb9_personal_source_item' AND n.nspname = 'public' AND c.relkind = 'r'
        ) THEN
            EXECUTE format('GRANT SELECT, INSERT, UPDATE ON TABLE public.%I TO %I', 'mb9_personal_source_item', v_role);
        END IF;
    END IF;
END $$;

COMMIT;
