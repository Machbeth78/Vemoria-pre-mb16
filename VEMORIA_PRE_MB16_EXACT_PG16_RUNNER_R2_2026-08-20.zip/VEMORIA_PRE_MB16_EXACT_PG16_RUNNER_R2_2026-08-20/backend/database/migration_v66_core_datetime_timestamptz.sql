-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V66 — Core datetime alignment to TIMESTAMPTZ
-- Obiettivo: allineare il core ORM storico al contratto UTC-aware già usato da LUISS.
-- Regola di conversione: i valori legacy TIMESTAMP vengono interpretati come UTC.

ALTER TABLE IF EXISTS utenti
    ALTER COLUMN creato_il TYPE TIMESTAMPTZ USING creato_il AT TIME ZONE 'UTC',
    ALTER COLUMN creato_il SET DEFAULT NOW(),
    ALTER COLUMN aggiornato_il TYPE TIMESTAMPTZ USING aggiornato_il AT TIME ZONE 'UTC',
    ALTER COLUMN aggiornato_il SET DEFAULT NOW();

ALTER TABLE IF EXISTS tipi_documento
    ALTER COLUMN creato_il TYPE TIMESTAMPTZ USING creato_il AT TIME ZONE 'UTC',
    ALTER COLUMN creato_il SET DEFAULT NOW();

ALTER TABLE IF EXISTS documenti
    ALTER COLUMN creato_il TYPE TIMESTAMPTZ USING creato_il AT TIME ZONE 'UTC',
    ALTER COLUMN creato_il SET DEFAULT NOW(),
    ALTER COLUMN aggiornato_il TYPE TIMESTAMPTZ USING aggiornato_il AT TIME ZONE 'UTC',
    ALTER COLUMN aggiornato_il SET DEFAULT NOW();

ALTER TABLE IF EXISTS memorie
    ALTER COLUMN creata_il TYPE TIMESTAMPTZ USING creata_il AT TIME ZONE 'UTC',
    ALTER COLUMN creata_il SET DEFAULT NOW(),
    ALTER COLUMN aggiornato_il TYPE TIMESTAMPTZ USING aggiornato_il AT TIME ZONE 'UTC',
    ALTER COLUMN aggiornato_il SET DEFAULT NOW(),
    ALTER COLUMN confermata_il TYPE TIMESTAMPTZ USING confermata_il AT TIME ZONE 'UTC',
    ALTER COLUMN data_documento TYPE TIMESTAMPTZ USING data_documento AT TIME ZONE 'UTC';

ALTER TABLE IF EXISTS cronologia_eventi
    ALTER COLUMN timestamp TYPE TIMESTAMPTZ USING timestamp AT TIME ZONE 'UTC',
    ALTER COLUMN timestamp SET DEFAULT NOW();

ALTER TABLE IF EXISTS problemi
    ALTER COLUMN creato_il TYPE TIMESTAMPTZ USING creato_il AT TIME ZONE 'UTC',
    ALTER COLUMN creato_il SET DEFAULT NOW(),
    ALTER COLUMN risolto_il TYPE TIMESTAMPTZ USING risolto_il AT TIME ZONE 'UTC';

ALTER TABLE IF EXISTS identita_digitale
    ALTER COLUMN creata_il TYPE TIMESTAMPTZ USING creata_il AT TIME ZONE 'UTC',
    ALTER COLUMN creata_il SET DEFAULT NOW();

ALTER TABLE IF EXISTS dossier
    ALTER COLUMN creato_il TYPE TIMESTAMPTZ USING creato_il AT TIME ZONE 'UTC',
    ALTER COLUMN creato_il SET DEFAULT NOW(),
    ALTER COLUMN aggiornato_il TYPE TIMESTAMPTZ USING aggiornato_il AT TIME ZONE 'UTC',
    ALTER COLUMN aggiornato_il SET DEFAULT NOW();

ALTER TABLE IF EXISTS documento_dossier
    ALTER COLUMN aggiunto_il TYPE TIMESTAMPTZ USING aggiunto_il AT TIME ZONE 'UTC',
    ALTER COLUMN aggiunto_il SET DEFAULT NOW();

ALTER TABLE IF EXISTS schema_migration_state
    ALTER COLUMN applied_il TYPE TIMESTAMPTZ USING applied_il AT TIME ZONE 'UTC',
    ALTER COLUMN applied_il SET DEFAULT NOW();
