-- Vemoria MB0→MB15 audit convergence — targeted owner RLS cohort.
-- Only tables with simple one-owner semantics are included here.
-- Complex/member/public-token/auth-bootstrap tables are intentionally excluded.
BEGIN;

-- Push tokens are private owner data. Provider dispatch and token management
-- bind app.owner_id before every read/write.
ALTER TABLE user_push_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_push_tokens FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS user_push_tokens_owner_isolation ON user_push_tokens;
CREATE POLICY user_push_tokens_owner_isolation ON user_push_tokens
    USING (user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

-- Source Indexer V1 is strictly owner-scoped.  The canonical source services
-- now establish app.owner_id for direct/background calls as well as HTTP calls.
ALTER TABLE source_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE source_connections FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS source_connections_owner_isolation ON source_connections;
CREATE POLICY source_connections_owner_isolation ON source_connections
    USING (user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

ALTER TABLE source_indexed_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE source_indexed_items FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS source_indexed_items_owner_isolation ON source_indexed_items;
CREATE POLICY source_indexed_items_owner_isolation ON source_indexed_items
    USING (user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

ALTER TABLE source_consent_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE source_consent_log FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS source_consent_log_owner_isolation ON source_consent_log;
CREATE POLICY source_consent_log_owner_isolation ON source_consent_log
    USING (user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

COMMIT;
