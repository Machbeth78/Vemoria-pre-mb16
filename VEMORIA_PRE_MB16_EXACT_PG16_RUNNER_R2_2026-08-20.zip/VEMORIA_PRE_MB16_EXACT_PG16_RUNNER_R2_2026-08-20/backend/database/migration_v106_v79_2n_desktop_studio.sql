-- Vemoria — migration_v106_v79_2n_desktop_studio.sql
-- Creatore e proprietario: Devoti Massimo
-- V79.2N — Vemoria PC/Desktop Studio: cartelle/dossier con identità digitale,
-- manifest contenuti, timeline e ricerca non-cartelle.

CREATE TABLE IF NOT EXISTS desktop_studio_dossiers (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    desktop_device_id   UUID REFERENCES desktop_devices(id) ON DELETE SET NULL,
    owner_label         TEXT NOT NULL DEFAULT 'Studio/Proprietario',
    title               TEXT NOT NULL,
    description         TEXT,
    original_path       TEXT NOT NULL,
    source_os           TEXT,
    manifest_hash       TEXT NOT NULL,
    manifest_payload    JSONB NOT NULL DEFAULT '{}'::jsonb,
    confidence_level    TEXT NOT NULL DEFAULT 'media'
                        CHECK (confidence_level IN ('alta','media','bassa')),
    confidence_score    NUMERIC(5,2) NOT NULL DEFAULT 50,
    evidence_json       JSONB NOT NULL DEFAULT '{}'::jsonb,
    status              TEXT NOT NULL DEFAULT 'active'
                        CHECK (status IN ('active','archived','needs_review','rejected')),
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, desktop_device_id, manifest_hash)
);

CREATE INDEX IF NOT EXISTS idx_desktop_studio_dossiers_user
    ON desktop_studio_dossiers(utente_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_desktop_studio_dossiers_device
    ON desktop_studio_dossiers(desktop_device_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_desktop_studio_dossiers_hash
    ON desktop_studio_dossiers(manifest_hash);
CREATE INDEX IF NOT EXISTS idx_desktop_studio_dossiers_title_lower
    ON desktop_studio_dossiers(LOWER(title));
CREATE INDEX IF NOT EXISTS idx_desktop_studio_dossiers_path_lower
    ON desktop_studio_dossiers(LOWER(original_path));

CREATE TABLE IF NOT EXISTS desktop_studio_dossier_files (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    dossier_id              UUID NOT NULL REFERENCES desktop_studio_dossiers(id) ON DELETE CASCADE,
    utente_id               UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    desktop_device_id       UUID REFERENCES desktop_devices(id) ON DELETE SET NULL,
    file_hash               TEXT,
    file_name               TEXT NOT NULL,
    original_path           TEXT,
    relative_path           TEXT,
    mime_type               TEXT,
    size_bytes              BIGINT,
    modified_at             TIMESTAMP,
    detected_kind           TEXT,
    extracted_text_preview  TEXT,
    metadata_json           JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_desktop_studio_files_dossier
    ON desktop_studio_dossier_files(dossier_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_desktop_studio_files_user
    ON desktop_studio_dossier_files(utente_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_desktop_studio_files_hash
    ON desktop_studio_dossier_files(file_hash) WHERE file_hash IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_desktop_studio_files_name_lower
    ON desktop_studio_dossier_files(LOWER(file_name));
CREATE INDEX IF NOT EXISTS idx_desktop_studio_files_path_lower
    ON desktop_studio_dossier_files(LOWER(COALESCE(relative_path, original_path, '')));

CREATE TABLE IF NOT EXISTS desktop_studio_timeline_events (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    dossier_id          UUID NOT NULL REFERENCES desktop_studio_dossiers(id) ON DELETE CASCADE,
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    desktop_device_id   UUID REFERENCES desktop_devices(id) ON DELETE SET NULL,
    event_type          TEXT NOT NULL,
    event_title         TEXT NOT NULL,
    occurred_at         TIMESTAMP NOT NULL DEFAULT NOW(),
    payload_json        JSONB NOT NULL DEFAULT '{}'::jsonb,
    confidence_level    TEXT NOT NULL DEFAULT 'media'
                        CHECK (confidence_level IN ('alta','media','bassa')),
    confidence_score    NUMERIC(5,2) NOT NULL DEFAULT 50,
    created_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_desktop_studio_timeline_dossier
    ON desktop_studio_timeline_events(dossier_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_desktop_studio_timeline_user
    ON desktop_studio_timeline_events(utente_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_desktop_studio_timeline_type
    ON desktop_studio_timeline_events(event_type, occurred_at DESC);

-- Nota: registrazione migration demandata al migration runner/registry service.
