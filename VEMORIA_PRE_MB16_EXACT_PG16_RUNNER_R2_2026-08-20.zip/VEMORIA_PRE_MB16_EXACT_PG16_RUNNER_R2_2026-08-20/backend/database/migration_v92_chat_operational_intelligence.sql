-- VEMORA — Migration V92: Operational Chat Intelligence
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
--
-- Introduce:
--   1. messaggi "azione operativa" pinnable in testa al thread finché non risolti
--   2. read-receipts per ogni azione (chi ha visto/aperto/scaricato cosa)
--   3. stato operativo denormalizzato sul thread (next-action hint)
--   4. suggerimenti composer (smart composer log per futuro tuning)
--
-- Design choice: azione "pinnata" = messaggio di tipo signature_request, acceptance_request,
--   delivery o proof che è ancora "pending" (non completato/rifiutato/scaduto).
--   Il backend pinna automaticamente quando viene creato e spinna quando lo stato sottostante
--   passa a final (completed/rejected/cancelled/expired).

-- ── 1. Pinned actions su chat_messaggi ────────────────────────────────────────

ALTER TABLE chat_messaggi
    ADD COLUMN IF NOT EXISTS pinned_as_action BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE chat_messaggi
    ADD COLUMN IF NOT EXISTS action_status TEXT;
    -- valori: pending | completed | rejected | cancelled | expired | observed
    -- NULL per messaggi non-azione (text, system, document-solo-allegato senza richiesta)

ALTER TABLE chat_messaggi
    ADD COLUMN IF NOT EXISTS action_resolved_at TIMESTAMPTZ;

ALTER TABLE chat_messaggi
    ADD COLUMN IF NOT EXISTS action_resolution_payload JSONB;

CREATE INDEX IF NOT EXISTS idx_chat_messaggi_pinned
    ON chat_messaggi(thread_id, creato_il DESC)
    WHERE pinned_as_action = TRUE AND deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_chat_messaggi_action_pending
    ON chat_messaggi(thread_id, action_status)
    WHERE action_status = 'pending' AND deleted_at IS NULL;

COMMENT ON COLUMN chat_messaggi.pinned_as_action IS
    'Messaggio-azione ancora da risolvere: appare in hero band del thread finché non chiuso';
COMMENT ON COLUMN chat_messaggi.action_status IS
    'pending | completed | rejected | cancelled | expired | observed — NULL per messaggi non-azione';

-- ── 2. Action receipts — chi ha visto/aperto/scaricato/firmato ───────────────

CREATE TABLE IF NOT EXISTS chat_action_receipts (
    id              UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    message_id      UUID        NOT NULL REFERENCES chat_messaggi(id) ON DELETE CASCADE,
    thread_id       UUID        NOT NULL REFERENCES chat_thread(id) ON DELETE CASCADE,
    actor_user_id   UUID        REFERENCES utenti(id) ON DELETE SET NULL,
    actor_kind      TEXT        NOT NULL DEFAULT 'user'
                                CHECK (actor_kind IN ('user', 'counterparty', 'system')),
    actor_label     TEXT,                           -- nome controparte non-registrata
    action          TEXT        NOT NULL
                                CHECK (action IN ('seen', 'opened', 'downloaded', 'signed', 'accepted', 'rejected', 'replied', 'forwarded')),
    details_json    JSONB       NOT NULL DEFAULT '{}'::jsonb,
    occurred_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chat_action_receipts_message
    ON chat_action_receipts(message_id, occurred_at DESC);

CREATE INDEX IF NOT EXISTS idx_chat_action_receipts_thread_actor
    ON chat_action_receipts(thread_id, actor_user_id, action);

COMMENT ON TABLE chat_action_receipts IS
    'Ricevute operative per azioni di chat: chi ha visto, aperto, scaricato, firmato, accettato, risposto. Dà retina operativa al thread.';

-- ── 3. Stato operativo denormalizzato sul thread ─────────────────────────────
-- Permette di calcolare in una query il "thread_status" senza scorrere tutti i messaggi:
--   active_pending      — c'è almeno una azione aperta
--   active_waiting_me   — io sono il destinatario di un'azione aperta
--   active_waiting_them — loro sono i destinatari di un'azione aperta mia
--   resolved            — tutte le azioni chiuse
--   dormant             — nessuna azione, solo testo

ALTER TABLE chat_thread
    ADD COLUMN IF NOT EXISTS open_actions_count INTEGER NOT NULL DEFAULT 0;

ALTER TABLE chat_thread
    ADD COLUMN IF NOT EXISTS last_action_at TIMESTAMPTZ;

ALTER TABLE chat_thread
    ADD COLUMN IF NOT EXISTS last_resolution_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_chat_thread_open_actions
    ON chat_thread(workspace_type, workspace_id, open_actions_count)
    WHERE open_actions_count > 0 AND archived_at IS NULL;

-- ── 4. Composer suggestions log (per tuning futuro) ──────────────────────────

CREATE TABLE IF NOT EXISTS chat_composer_suggestions_log (
    id              UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    thread_id       UUID        NOT NULL REFERENCES chat_thread(id) ON DELETE CASCADE,
    user_id         UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    suggestion_kind TEXT        NOT NULL,          -- ex. 'remind_counterparty', 'send_proof', 'request_acceptance'
    context_snapshot JSONB      NOT NULL DEFAULT '{}'::jsonb,
    user_action     TEXT,                           -- 'accepted' | 'dismissed' | 'ignored'
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    acted_at        TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_composer_suggestions_user_recent
    ON chat_composer_suggestions_log(user_id, created_at DESC);

COMMENT ON TABLE chat_composer_suggestions_log IS
    'Log suggerimenti del composer intelligente: utile per capire quali suggerimenti funzionano davvero.';

-- ── 5. Mark-read atomico (last_read_message_id) ──────────────────────────────
-- chat_read_state ha già last_read_message_id dalla V83, ma non veniva valorizzato.
-- Questa migration non cambia schema: solo commento per consistency.

COMMENT ON COLUMN chat_read_state.last_read_message_id IS
    'Ultimo messaggio letto. Unread count = messaggi creati dopo questo id (non after last_read_at, che è race-prone).';
