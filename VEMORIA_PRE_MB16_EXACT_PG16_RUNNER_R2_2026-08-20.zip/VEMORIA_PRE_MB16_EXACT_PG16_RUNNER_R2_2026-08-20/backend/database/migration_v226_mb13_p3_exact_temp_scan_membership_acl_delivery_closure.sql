-- migration_v226_mb13_p3_exact_temp_scan_membership_acl_delivery_closure.sql
-- MB13-P3 v226: exact temp-function scan (regex not pseudo-wildcard), per-table ACL,
-- ownership inventory across all schemas/object kinds, membership/SET ROLE matrix.
-- v225 is rejected; this migration closes the residual gaps.
BEGIN;

-- ============================================================================
-- 1. Role inertization and canonical owner creation
-- ============================================================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p3_pack_data_owner') THEN
        CREATE ROLE mb13_p3_pack_data_owner NOLOGIN NOINHERIT NOBYPASSRLS;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p3_pack_lifecycle_executor') THEN
        CREATE ROLE mb13_p3_pack_lifecycle_executor NOLOGIN NOINHERIT NOBYPASSRLS;
    END IF;
END $$;

ALTER ROLE mb13_p3_pack_data_owner NOLOGIN NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p3_pack_lifecycle_executor NOLOGIN NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p3_pack_mutator NOLOGIN NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p3_pack_lifecycle_owner NOLOGIN NOINHERIT NOBYPASSRLS;

-- ============================================================================
-- 2. Exact temp-function scan across all non-system schemas
-- ============================================================================
DROP FUNCTION IF EXISTS public.migration_v224_reason_specific_recovery();
DO $$
DECLARE r RECORD;
BEGIN
    FOR r IN
        SELECT n.nspname AS schema_name, p.oid::regprocedure::text AS sig
          FROM pg_proc p
          JOIN pg_namespace n ON p.pronamespace = n.oid
         WHERE n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
           AND p.proname ~ '^migration_v22[0-9x]_'
    LOOP
        RAISE EXCEPTION 'migration_v226 residual temporary function: %.%', r.schema_name, r.sig;
    END LOOP;
END $$;

-- ============================================================================
-- 3. Exact canonical object allowlist and structural trigger verification
-- ============================================================================
DO $$
DECLARE
    v_allowed_tables TEXT[] := ARRAY['mb13_p3_action_pack', 'mb13_p3_action_pack_attempt', 'mb13_p3_action_pack_authorization', 'mb13_p3_action_pack_evidence', 'mb13_p3_action_pack_result', 'mb13_p3_action_pack_revision', 'mb13_p3_action_pack_timeline', 'mb13_p3_recovery_audit'];
    v_allowed_sequences TEXT[] := ARRAY['mb13_p3_recovery_audit_audit_id_seq'];
    v_allowed_functions TEXT[] := ARRAY['mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)', 'mb13_p3_action_pack_authorization_append_only()', 'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)', 'mb13_p3_action_pack_evidence_immutable()', 'mb13_p3_action_pack_governed_mutation()', 'mb13_p3_action_pack_monitor_policy_hash()', 'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)', 'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)', 'mb13_p3_action_pack_result_evidence_guard()', 'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)', 'mb13_p3_action_pack_result_immutable()', 'mb13_p3_action_pack_revision_immutable()', 'mb13_p3_action_pack_terminal_attempt_sync()', 'mb13_p3_action_pack_timeline_immutable()', 'mb13_p3_action_pack_transition_guard()', 'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)', 'mb13_p3_cancel_action_pack(uuid,uuid)', 'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)', 'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)', 'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)', 'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)', 'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)', 'mb13_p3_expire_action_pack(uuid,uuid)', 'mb13_p3_get_action_pack(uuid,uuid)', 'mb13_p3_get_action_pack_attempts(uuid,uuid)', 'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)', 'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)', 'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)', 'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)', 'mb13_p3_list_action_packs(uuid,text,integer,integer)', 'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)', 'mb13_p3_recovery_audit_immutable()', 'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)', 'mb13_p3_revoke_action_pack(uuid,uuid)', 'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)', 'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)', 'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)', 'mb13_p3_validate_result_evidence(jsonb)', 'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)', 'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)', 'mb13_p3_validate_steps(uuid,jsonb)', 'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'];
    v_allowed_roles TEXT[] := ARRAY['mb13_p3_api', 'mb13_p3_executor', 'mb13_p3_pack_data_owner', 'mb13_p3_pack_lifecycle_executor', 'mb13_p3_pack_lifecycle_owner', 'mb13_p3_pack_mutator', 'mb13_p3_validator', 'mb13_p3_writer', 'test_app'];
    v_allowed_policies TEXT[] := ARRAY['mb13_p3_pack_owner_isolation', 'mb13_p3_attempt_owner_isolation', 'mb13_p3_auth_owner_isolation', 'mb13_p3_evidence_owner_policy', 'mb13_p3_result_owner_isolation', 'mb13_p3_rev_owner_isolation', 'mb13_p3_timeline_owner_isolation', 'mb13_p3_recovery_audit_lifecycle'];
    r RECORD;
BEGIN
    FOR r IN
        SELECT rolname FROM pg_roles
         WHERE (rolname LIKE 'mb13_p3_%' OR rolname = 'test_app')
           AND NOT (rolname = ANY(v_allowed_roles))
    LOOP
        RAISE EXCEPTION 'migration_v226 unexpected role: %', r.rolname;
    END LOOP;

    FOR r IN
        SELECT c.relname, c.relkind
          FROM pg_class c
          JOIN pg_namespace n ON c.relnamespace = n.oid
         WHERE n.nspname = 'public'
           AND c.relname LIKE 'mb13_p3_%'
           AND c.relkind IN ('r','p','S')
    LOOP
        IF NOT (r.relname = ANY(v_allowed_tables) OR r.relname = ANY(v_allowed_sequences)) THEN
            RAISE EXCEPTION 'migration_v226 unexpected table/sequence: % (kind %)', r.relname, r.relkind;
        END IF;
    END LOOP;

    FOR r IN
        SELECT p.proname, n.nspname,
               p.oid::regprocedure::text AS sig
          FROM pg_proc p
          JOIN pg_namespace n ON p.pronamespace = n.oid
         WHERE n.nspname = 'public'
           AND p.proname LIKE 'mb13_p3_%'
    LOOP
        IF NOT (r.sig = ANY(v_allowed_functions)) THEN
            RAISE EXCEPTION 'migration_v226 unexpected function: %', r.sig;
        END IF;
    END LOOP;

    FOR r IN
        SELECT p.polname, c.relname
          FROM pg_policy p
          JOIN pg_class c ON p.polrelid = c.oid
          JOIN pg_namespace n ON c.relnamespace = n.oid
         WHERE n.nspname = 'public'
           AND c.relname LIKE 'mb13_p3_%'
    LOOP
        IF NOT (r.polname = ANY(v_allowed_policies)) THEN
            RAISE EXCEPTION 'migration_v226 unexpected policy % on table %', r.polname, r.relname;
        END IF;
    END LOOP;

    FOR r IN
        SELECT c.relname, t.tgname, p.proname
          FROM pg_trigger t
          JOIN pg_class c ON t.tgrelid = c.oid
          JOIN pg_namespace n ON c.relnamespace = n.oid
          JOIN pg_proc p ON t.tgfoid = p.oid
         WHERE n.nspname = 'public'
           AND c.relname LIKE 'mb13_p3_%'
           AND NOT t.tgisinternal
    LOOP
        PERFORM 1 FROM (VALUES ('mb13_p3_action_pack','trg_mb13_p3_action_pack_governed_mutation'), ('mb13_p3_action_pack','trg_mb13_p3_action_pack_monitor_policy_hash'), ('mb13_p3_action_pack','trg_mb13_p3_action_pack_terminal_attempt_sync'), ('mb13_p3_action_pack','trg_mb13_p3_action_pack_transition_guard'), ('mb13_p3_action_pack_authorization','trg_mb13_p3_authorization_append_only'), ('mb13_p3_action_pack_evidence','trg_mb13_p3_evidence_immutable'), ('mb13_p3_action_pack_result','trg_mb13_p3_action_pack_result_evidence_guard'), ('mb13_p3_action_pack_result','trg_mb13_p3_result_immutable'), ('mb13_p3_action_pack_revision','trg_mb13_p3_revision_immutable'), ('mb13_p3_action_pack_timeline','trg_mb13_p3_timeline_immutable'), ('mb13_p3_recovery_audit','trg_mb13_p3_recovery_audit_immutable')) AS v(relname, tgname)
         WHERE v.relname = r.relname AND v.tgname = r.tgname;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'migration_v226 unexpected trigger % on table % (function %)', r.tgname, r.relname, r.proname;
        END IF;
    END LOOP;
END $$;

-- ============================================================================
-- 4. Full ownership inventory across all schemas and object kinds
-- ============================================================================
DO $$
DECLARE
    v_legacy_roles TEXT[] := ARRAY['mb13_p3_pack_mutator', 'mb13_p3_pack_lifecycle_owner'];
    v_allowed_tables TEXT[] := ARRAY['mb13_p3_action_pack', 'mb13_p3_action_pack_attempt', 'mb13_p3_action_pack_authorization', 'mb13_p3_action_pack_evidence', 'mb13_p3_action_pack_result', 'mb13_p3_action_pack_revision', 'mb13_p3_action_pack_timeline', 'mb13_p3_recovery_audit'];
    v_allowed_sequences TEXT[] := ARRAY['mb13_p3_recovery_audit_audit_id_seq'];
    v_allowed_functions TEXT[] := ARRAY['mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)', 'mb13_p3_action_pack_authorization_append_only()', 'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)', 'mb13_p3_action_pack_evidence_immutable()', 'mb13_p3_action_pack_governed_mutation()', 'mb13_p3_action_pack_monitor_policy_hash()', 'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)', 'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)', 'mb13_p3_action_pack_result_evidence_guard()', 'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)', 'mb13_p3_action_pack_result_immutable()', 'mb13_p3_action_pack_revision_immutable()', 'mb13_p3_action_pack_terminal_attempt_sync()', 'mb13_p3_action_pack_timeline_immutable()', 'mb13_p3_action_pack_transition_guard()', 'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)', 'mb13_p3_cancel_action_pack(uuid,uuid)', 'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)', 'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)', 'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)', 'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)', 'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)', 'mb13_p3_expire_action_pack(uuid,uuid)', 'mb13_p3_get_action_pack(uuid,uuid)', 'mb13_p3_get_action_pack_attempts(uuid,uuid)', 'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)', 'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)', 'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)', 'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)', 'mb13_p3_list_action_packs(uuid,text,integer,integer)', 'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)', 'mb13_p3_recovery_audit_immutable()', 'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)', 'mb13_p3_revoke_action_pack(uuid,uuid)', 'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)', 'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)', 'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)', 'mb13_p3_validate_result_evidence(jsonb)', 'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)', 'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)', 'mb13_p3_validate_steps(uuid,jsonb)', 'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'];
    r RECORD;
    v_fn_sig TEXT;
    v_target_owner TEXT;
BEGIN
    FOREACH v_target_owner IN ARRAY v_legacy_roles LOOP
        -- pg_class: tables, indexes, sequences, views, matviews, foreign tables, partitioned tables, TOAST tables
        FOR r IN
            SELECT c.relname, c.relkind, c.oid, n.nspname AS schema_name
              FROM pg_class c
              JOIN pg_namespace n ON c.relnamespace = n.oid
              JOIN pg_roles rl ON c.relowner = rl.oid
             WHERE rl.rolname = v_target_owner
               AND n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
        LOOP
            IF r.schema_name <> 'public' THEN
                RAISE EXCEPTION 'migration_v226 legacy role % owns % object % in non-public schema %', v_target_owner, r.relkind, r.relname, r.schema_name;
            END IF;
            -- Transfer table ownership first; owned sequences/toast/indexes follow automatically.
            IF r.relkind = 'r' AND r.relname = ANY(v_allowed_tables) THEN
                EXECUTE format('ALTER TABLE public.%I OWNER TO mb13_p3_pack_data_owner', r.relname);
            ELSIF r.relkind = 'S' AND r.relname = ANY(v_allowed_sequences) THEN
                -- Linked column sequences change owner with their table; only alter independent sequences.
                IF NOT EXISTS (
                    SELECT 1 FROM pg_depend d
                     WHERE d.classid = 'pg_class'::regclass
                       AND d.objid = r.oid
                       AND d.deptype = 'a'
                       AND d.refclassid = 'pg_class'::regclass
                ) THEN
                    EXECUTE format('ALTER SEQUENCE public.%I OWNER TO mb13_p3_pack_data_owner', r.relname);
                END IF;
            ELSIF r.relkind IN ('i','I') THEN
                IF EXISTS (
                    SELECT 1 FROM pg_index pi
                      JOIN pg_class c2 ON pi.indrelid = c2.oid
                     WHERE pi.indexrelid = r.oid
                       AND c2.relname = ANY(v_allowed_tables)
                ) THEN
                    EXECUTE format('ALTER INDEX public.%I OWNER TO mb13_p3_pack_data_owner', r.relname);
                ELSE
                    RAISE EXCEPTION 'migration_v226 legacy role % owns unexpected index % (kind %)', v_target_owner, r.relname, r.relkind;
                END IF;
            ELSIF r.relkind = 't' THEN
                IF NOT EXISTS (
                    SELECT 1 FROM pg_class c2
                     WHERE c2.reltoastrelid = r.oid
                       AND c2.relname = ANY(v_allowed_tables)
                ) THEN
                    RAISE EXCEPTION 'migration_v226 legacy role % owns unexpected TOAST table %', v_target_owner, r.relname;
                END IF;
            ELSE
                RAISE EXCEPTION 'migration_v226 legacy role % owns unexpected object % (kind %) in schema %', v_target_owner, r.relname, r.relkind, r.schema_name;
            END IF;
        END LOOP;

        -- pg_proc: functions, procedures, aggregates, window functions in all schemas
        FOR r IN
            SELECT n.nspname AS schema_name, p.proname,
                   p.oid::regprocedure::text AS sig,
                   p.prokind
              FROM pg_proc p
              JOIN pg_namespace n ON p.pronamespace = n.oid
              JOIN pg_roles rl ON p.proowner = rl.oid
             WHERE rl.rolname = v_target_owner
               AND n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
        LOOP
            IF r.schema_name <> 'public' THEN
                RAISE EXCEPTION 'migration_v226 legacy role % owns % %.% in non-public schema', v_target_owner, r.prokind, r.proname, r.schema_name;
            END IF;
            IF r.sig = ANY(v_allowed_functions) THEN
                IF r.proname IN ('mb13_p3_action_pack_refs_revoked','mb13_p3_validate_source_grant_chain','mb13_p3_validate_trigger_diff') THEN
                    EXECUTE format('ALTER FUNCTION %s OWNER TO mb13_p3_validator', r.sig);
                ELSE
                    EXECUTE format('ALTER FUNCTION %s OWNER TO mb13_p3_pack_lifecycle_executor', r.sig);
                END IF;
            ELSE
                RAISE EXCEPTION 'migration_v226 legacy role % owns unexpected function/procedure/aggregate: %', v_target_owner, r.sig;
            END IF;
        END LOOP;

        -- pg_type: types and domains in all schemas
        FOR r IN
            SELECT n.nspname AS schema_name, t.typname, t.typtype
              FROM pg_type t
              JOIN pg_namespace n ON t.typnamespace = n.oid
              JOIN pg_roles rl ON t.typowner = rl.oid
             WHERE rl.rolname = v_target_owner
               AND n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
        LOOP
            IF r.schema_name <> 'public' THEN
                RAISE EXCEPTION 'migration_v226 legacy role % owns type/domain % in non-public schema %', v_target_owner, r.typname, r.schema_name;
            END IF;
            IF r.typname = ANY(v_allowed_tables) OR r.typname = ANY(v_allowed_sequences) THEN
                EXECUTE format('ALTER TYPE public.%I OWNER TO mb13_p3_pack_data_owner', r.typname);
            ELSE
                RAISE EXCEPTION 'migration_v226 legacy role % owns unexpected type/domain % (type %)', v_target_owner, r.typname, r.typtype;
            END IF;
        END LOOP;

        -- pg_namespace: schemas
        FOR r IN
            SELECT n.nspname AS schema_name
              FROM pg_namespace n
              JOIN pg_roles rl ON n.nspowner = rl.oid
             WHERE rl.rolname = v_target_owner
               AND n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
        LOOP
            RAISE EXCEPTION 'migration_v226 legacy role % owns unexpected schema %', v_target_owner, r.schema_name;
        END LOOP;

        -- pg_operator, pg_opclass, pg_opfamily, pg_collation, pg_conversion, pg_ts_config, pg_ts_dict
        FOR r IN
            SELECT 'operator' AS kind, n.nspname AS schema_name, o.oprname AS obj_name
              FROM pg_operator o
              JOIN pg_namespace n ON o.oprnamespace = n.oid
              JOIN pg_roles rl ON o.oprowner = rl.oid
             WHERE rl.rolname = v_target_owner
               AND n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
            UNION ALL
            SELECT 'opclass', n.nspname, oc.opcname
              FROM pg_opclass oc
              JOIN pg_namespace n ON oc.opcnamespace = n.oid
              JOIN pg_roles rl ON oc.opcowner = rl.oid
             WHERE rl.rolname = v_target_owner
               AND n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
            UNION ALL
            SELECT 'opfamily', n.nspname, of.opfname
              FROM pg_opfamily of
              JOIN pg_namespace n ON of.opfnamespace = n.oid
              JOIN pg_roles rl ON of.opfowner = rl.oid
             WHERE rl.rolname = v_target_owner
               AND n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
            UNION ALL
            SELECT 'collation', n.nspname, co.collname
              FROM pg_collation co
              JOIN pg_namespace n ON co.collnamespace = n.oid
              JOIN pg_roles rl ON co.collowner = rl.oid
             WHERE rl.rolname = v_target_owner
               AND n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
            UNION ALL
            SELECT 'conversion', n.nspname, cv.conname
              FROM pg_conversion cv
              JOIN pg_namespace n ON cv.connamespace = n.oid
              JOIN pg_roles rl ON cv.conowner = rl.oid
             WHERE rl.rolname = v_target_owner
               AND n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
            UNION ALL
            SELECT 'ts_config', n.nspname, cfg.cfgname
              FROM pg_ts_config cfg
              JOIN pg_namespace n ON cfg.cfgnamespace = n.oid
              JOIN pg_roles rl ON cfg.cfgowner = rl.oid
             WHERE rl.rolname = v_target_owner
               AND n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
            UNION ALL
            SELECT 'ts_dict', n.nspname, dict.dictname
              FROM pg_ts_dict dict
              JOIN pg_namespace n ON dict.dictnamespace = n.oid
              JOIN pg_roles rl ON dict.dictowner = rl.oid
             WHERE rl.rolname = v_target_owner
               AND n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
        LOOP
            RAISE EXCEPTION 'migration_v226 legacy role % owns unexpected % %.% in schema %', v_target_owner, r.kind, r.schema_name, r.obj_name, r.schema_name;
        END LOOP;

        -- pg_language, pg_tablespace, pg_event_trigger, pg_publication, pg_subscription, pg_extension
        FOR r IN
            SELECT 'language' AS kind, lanname AS obj_name FROM pg_language l JOIN pg_roles rl ON l.lanowner = rl.oid WHERE rl.rolname = v_target_owner
            UNION ALL
            SELECT 'tablespace', spcname FROM pg_tablespace s JOIN pg_roles rl ON s.spcowner = rl.oid WHERE rl.rolname = v_target_owner
            UNION ALL
            SELECT 'event_trigger', evtname FROM pg_event_trigger e JOIN pg_roles rl ON e.evtowner = rl.oid WHERE rl.rolname = v_target_owner
            UNION ALL
            SELECT 'publication', pubname FROM pg_publication p JOIN pg_roles rl ON p.pubowner = rl.oid WHERE rl.rolname = v_target_owner
            UNION ALL
            SELECT 'subscription', subname FROM pg_subscription s JOIN pg_roles rl ON s.subowner = rl.oid WHERE rl.rolname = v_target_owner
            UNION ALL
            SELECT 'extension', e.extname FROM pg_extension e JOIN pg_roles rl ON e.extowner = rl.oid WHERE rl.rolname = v_target_owner AND e.extnamespace NOT IN (SELECT oid FROM pg_namespace WHERE nspname IN ('pg_catalog','information_schema','pg_toast'))
        LOOP
            RAISE EXCEPTION 'migration_v226 legacy role % owns unexpected % %', v_target_owner, r.kind, r.obj_name;
        END LOOP;
    END LOOP;

    -- Verify canonical owners do not own unexpected objects in any non-system schema.
    FOR r IN
        SELECT n.nspname AS schema_name, c.relname AS obj_name, c.relkind, c.oid, rl.rolname AS owner
          FROM pg_class c
          JOIN pg_namespace n ON c.relnamespace = n.oid
          JOIN pg_roles rl ON c.relowner = rl.oid
         WHERE rl.rolname IN ('mb13_p3_pack_data_owner','mb13_p3_pack_lifecycle_executor')
           AND n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
    LOOP
        IF r.owner = 'mb13_p3_pack_data_owner' AND r.relkind = 'r' AND r.obj_name = ANY(v_allowed_tables) THEN CONTINUE; END IF;
        IF r.owner = 'mb13_p3_pack_data_owner' AND r.relkind = 'S' AND r.obj_name = ANY(v_allowed_sequences) THEN CONTINUE; END IF;
        IF r.owner = 'mb13_p3_pack_data_owner' AND r.relkind IN ('i','I') AND EXISTS (
            SELECT 1 FROM pg_index pi JOIN pg_class c2 ON pi.indrelid = c2.oid
             WHERE pi.indexrelid = r.oid AND c2.relname = ANY(v_allowed_tables)
        ) THEN CONTINUE; END IF;
        IF r.owner = 'mb13_p3_pack_data_owner' AND r.relkind = 't' AND EXISTS (
            SELECT 1 FROM pg_class c2 WHERE c2.reltoastrelid = r.oid AND c2.relname = ANY(v_allowed_tables)
        ) THEN CONTINUE; END IF;
        RAISE EXCEPTION 'migration_v226 owner % owns unexpected object %.% (kind %) in schema %', r.owner, r.schema_name, r.obj_name, r.relkind, r.schema_name;
    END LOOP;

    FOR r IN
        SELECT n.nspname AS schema_name, p.oid::regprocedure::text AS sig, rl.rolname AS owner
          FROM pg_proc p
          JOIN pg_namespace n ON p.pronamespace = n.oid
          JOIN pg_roles rl ON p.proowner = rl.oid
         WHERE rl.rolname IN ('mb13_p3_pack_lifecycle_executor','mb13_p3_validator')
           AND n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
    LOOP
        IF r.owner = 'mb13_p3_validator' AND r.sig = ANY(v_allowed_functions) AND r.sig IN ('mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)','mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)','mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)') THEN CONTINUE; END IF;
        IF r.owner = 'mb13_p3_pack_lifecycle_executor' AND r.sig = ANY(v_allowed_functions) THEN CONTINUE; END IF;
        RAISE EXCEPTION 'migration_v226 owner % owns unexpected function % in schema %', r.owner, r.sig, r.schema_name;
    END LOOP;
END $$;

-- ============================================================================
-- 5. Exact per-table ACL matrix (no uniform ALL TABLES grant)
-- ============================================================================
DO $$
DECLARE
    v_revoke_roles TEXT[] := ARRAY['PUBLIC','test_app','mb13_p3_api','mb13_p3_executor','mb13_p3_writer','mb13_p3_validator','mb13_p3_pack_mutator','mb13_p3_pack_lifecycle_owner','mb13_p3_pack_lifecycle_executor','mb13_p3_pack_data_owner'];
    t TEXT; r TEXT; v_role_sql TEXT;
BEGIN
    -- mb13_p3_action_pack
    FOREACH r IN ARRAY v_revoke_roles LOOP
        v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
        EXECUTE format('REVOKE ALL PRIVILEGES ON TABLE public.%I FROM %s', 'mb13_p3_action_pack', v_role_sql);
    END LOOP;
    EXECUTE format('GRANT ALL PRIVILEGES ON TABLE public.%I TO mb13_p3_pack_data_owner', 'mb13_p3_action_pack');
    EXECUTE format('GRANT SELECT, INSERT, UPDATE ON TABLE public.%I TO mb13_p3_pack_lifecycle_executor', 'mb13_p3_action_pack');
    -- mb13_p3_action_pack_attempt
    FOREACH r IN ARRAY v_revoke_roles LOOP
        v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
        EXECUTE format('REVOKE ALL PRIVILEGES ON TABLE public.%I FROM %s', 'mb13_p3_action_pack_attempt', v_role_sql);
    END LOOP;
    EXECUTE format('GRANT ALL PRIVILEGES ON TABLE public.%I TO mb13_p3_pack_data_owner', 'mb13_p3_action_pack_attempt');
    EXECUTE format('GRANT SELECT, INSERT, UPDATE ON TABLE public.%I TO mb13_p3_pack_lifecycle_executor', 'mb13_p3_action_pack_attempt');
    -- mb13_p3_action_pack_authorization
    FOREACH r IN ARRAY v_revoke_roles LOOP
        v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
        EXECUTE format('REVOKE ALL PRIVILEGES ON TABLE public.%I FROM %s', 'mb13_p3_action_pack_authorization', v_role_sql);
    END LOOP;
    EXECUTE format('GRANT ALL PRIVILEGES ON TABLE public.%I TO mb13_p3_pack_data_owner', 'mb13_p3_action_pack_authorization');
    EXECUTE format('GRANT SELECT, INSERT, UPDATE ON TABLE public.%I TO mb13_p3_pack_lifecycle_executor', 'mb13_p3_action_pack_authorization');
    -- mb13_p3_action_pack_evidence
    FOREACH r IN ARRAY v_revoke_roles LOOP
        v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
        EXECUTE format('REVOKE ALL PRIVILEGES ON TABLE public.%I FROM %s', 'mb13_p3_action_pack_evidence', v_role_sql);
    END LOOP;
    EXECUTE format('GRANT ALL PRIVILEGES ON TABLE public.%I TO mb13_p3_pack_data_owner', 'mb13_p3_action_pack_evidence');
    EXECUTE format('GRANT SELECT, INSERT ON TABLE public.%I TO mb13_p3_pack_lifecycle_executor', 'mb13_p3_action_pack_evidence');
    -- mb13_p3_action_pack_result
    FOREACH r IN ARRAY v_revoke_roles LOOP
        v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
        EXECUTE format('REVOKE ALL PRIVILEGES ON TABLE public.%I FROM %s', 'mb13_p3_action_pack_result', v_role_sql);
    END LOOP;
    EXECUTE format('GRANT ALL PRIVILEGES ON TABLE public.%I TO mb13_p3_pack_data_owner', 'mb13_p3_action_pack_result');
    EXECUTE format('GRANT SELECT, INSERT ON TABLE public.%I TO mb13_p3_pack_lifecycle_executor', 'mb13_p3_action_pack_result');
    -- mb13_p3_action_pack_revision
    FOREACH r IN ARRAY v_revoke_roles LOOP
        v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
        EXECUTE format('REVOKE ALL PRIVILEGES ON TABLE public.%I FROM %s', 'mb13_p3_action_pack_revision', v_role_sql);
    END LOOP;
    EXECUTE format('GRANT ALL PRIVILEGES ON TABLE public.%I TO mb13_p3_pack_data_owner', 'mb13_p3_action_pack_revision');
    EXECUTE format('GRANT SELECT, INSERT ON TABLE public.%I TO mb13_p3_pack_lifecycle_executor', 'mb13_p3_action_pack_revision');
    -- mb13_p3_action_pack_timeline
    FOREACH r IN ARRAY v_revoke_roles LOOP
        v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
        EXECUTE format('REVOKE ALL PRIVILEGES ON TABLE public.%I FROM %s', 'mb13_p3_action_pack_timeline', v_role_sql);
    END LOOP;
    EXECUTE format('GRANT ALL PRIVILEGES ON TABLE public.%I TO mb13_p3_pack_data_owner', 'mb13_p3_action_pack_timeline');
    EXECUTE format('GRANT SELECT, INSERT ON TABLE public.%I TO mb13_p3_pack_lifecycle_executor', 'mb13_p3_action_pack_timeline');
    -- mb13_p3_recovery_audit
    FOREACH r IN ARRAY v_revoke_roles LOOP
        v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
        EXECUTE format('REVOKE ALL PRIVILEGES ON TABLE public.%I FROM %s', 'mb13_p3_recovery_audit', v_role_sql);
    END LOOP;
    EXECUTE format('GRANT ALL PRIVILEGES ON TABLE public.%I TO mb13_p3_pack_data_owner', 'mb13_p3_recovery_audit');
    EXECUTE format('GRANT SELECT, INSERT ON TABLE public.%I TO mb13_p3_pack_lifecycle_executor', 'mb13_p3_recovery_audit');
    FOREACH r IN ARRAY v_revoke_roles LOOP
        v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
        EXECUTE format('REVOKE ALL PRIVILEGES ON SEQUENCE public.%I FROM %s', 'mb13_p3_recovery_audit_audit_id_seq', v_role_sql);
    END LOOP;
    EXECUTE format('GRANT ALL PRIVILEGES ON SEQUENCE public.%I TO mb13_p3_pack_data_owner', 'mb13_p3_recovery_audit_audit_id_seq');
    EXECUTE format('GRANT USAGE, SELECT ON SEQUENCE public.%I TO mb13_p3_pack_lifecycle_executor', 'mb13_p3_recovery_audit_audit_id_seq');
END $$;

-- ============================================================================
-- 6. Normalize function ACLs: revoke-first, grant-exact
-- ============================================================================
DO $$
DECLARE
    v_entrypoint_sigs TEXT[] := ARRAY['mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)', 'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)', 'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)', 'mb13_p3_cancel_action_pack(uuid,uuid)', 'mb13_p3_revoke_action_pack(uuid,uuid)', 'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)', 'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)', 'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)', 'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)', 'mb13_p3_expire_action_pack(uuid,uuid)', 'mb13_p3_get_action_pack(uuid,uuid)', 'mb13_p3_get_action_pack_attempts(uuid,uuid)', 'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)', 'mb13_p3_list_action_packs(uuid,text,integer,integer)'];
    v_api_sigs TEXT[] := ARRAY['mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)', 'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)', 'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)', 'mb13_p3_cancel_action_pack(uuid,uuid)', 'mb13_p3_revoke_action_pack(uuid,uuid)'];
    v_executor_sigs TEXT[] := ARRAY['mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)', 'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)', 'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)', 'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)', 'mb13_p3_expire_action_pack(uuid,uuid)'];
    v_reader_sigs TEXT[] := ARRAY['mb13_p3_get_action_pack(uuid,uuid)', 'mb13_p3_get_action_pack_attempts(uuid,uuid)', 'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)', 'mb13_p3_list_action_packs(uuid,text,integer,integer)'];
    v_all_sigs TEXT[] := ARRAY['mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)', 'mb13_p3_action_pack_authorization_append_only()', 'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)', 'mb13_p3_action_pack_evidence_immutable()', 'mb13_p3_action_pack_governed_mutation()', 'mb13_p3_action_pack_monitor_policy_hash()', 'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)', 'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)', 'mb13_p3_action_pack_result_evidence_guard()', 'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)', 'mb13_p3_action_pack_result_immutable()', 'mb13_p3_action_pack_revision_immutable()', 'mb13_p3_action_pack_terminal_attempt_sync()', 'mb13_p3_action_pack_timeline_immutable()', 'mb13_p3_action_pack_transition_guard()', 'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)', 'mb13_p3_cancel_action_pack(uuid,uuid)', 'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)', 'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)', 'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)', 'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)', 'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)', 'mb13_p3_expire_action_pack(uuid,uuid)', 'mb13_p3_get_action_pack(uuid,uuid)', 'mb13_p3_get_action_pack_attempts(uuid,uuid)', 'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)', 'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)', 'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)', 'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)', 'mb13_p3_list_action_packs(uuid,text,integer,integer)', 'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)', 'mb13_p3_recovery_audit_immutable()', 'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)', 'mb13_p3_revoke_action_pack(uuid,uuid)', 'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)', 'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)', 'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)', 'mb13_p3_validate_result_evidence(jsonb)', 'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)', 'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)', 'mb13_p3_validate_steps(uuid,jsonb)', 'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'];
    v_revoke_roles TEXT[] := ARRAY['PUBLIC','test_app','mb13_p3_api','mb13_p3_executor','mb13_p3_writer','mb13_p3_validator','mb13_p3_pack_mutator','mb13_p3_pack_lifecycle_owner','mb13_p3_pack_lifecycle_executor','mb13_p3_pack_data_owner'];
    sig TEXT; r TEXT; v_role_sql TEXT; proname TEXT;
    v_validator_internal TEXT[] := ARRAY['mb13_p3_action_pack_refs_revoked','mb13_p3_validate_source_grant_chain','mb13_p3_validate_trigger_diff'];
BEGIN
    FOREACH sig IN ARRAY v_all_sigs LOOP
        FOREACH r IN ARRAY v_revoke_roles LOOP
            v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
            EXECUTE format('REVOKE ALL ON FUNCTION %s FROM %s', sig, v_role_sql);
        END LOOP;
    END LOOP;

    FOREACH sig IN ARRAY v_api_sigs LOOP
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_api', sig);
    END LOOP;
    FOREACH sig IN ARRAY v_executor_sigs LOOP
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_executor', sig);
    END LOOP;
    FOREACH sig IN ARRAY v_reader_sigs LOOP
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_api, mb13_p3_executor', sig);
    END LOOP;

    FOREACH sig IN ARRAY v_all_sigs LOOP
        proname := split_part(sig, '(', 1);
        IF proname = ANY(v_validator_internal) THEN
            EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_validator, mb13_p3_pack_lifecycle_executor', sig);
        ELSIF NOT (sig = ANY(v_entrypoint_sigs)) THEN
            EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_pack_lifecycle_executor', sig);
        END IF;
    END LOOP;
END $$;

GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_governed_mutation()
    TO mb13_p3_pack_data_owner, mb13_p3_writer, mb13_p3_api, mb13_p3_executor,
       mb13_p3_validator, test_app;

-- ============================================================================
-- 7. Force RLS on MB13-P3 tables
-- ============================================================================
DO $$
DECLARE
    v_tables TEXT[] := ARRAY['mb13_p3_action_pack', 'mb13_p3_action_pack_attempt', 'mb13_p3_action_pack_authorization', 'mb13_p3_action_pack_evidence', 'mb13_p3_action_pack_result', 'mb13_p3_action_pack_revision', 'mb13_p3_action_pack_timeline', 'mb13_p3_recovery_audit'];
    t TEXT;
BEGIN
    FOREACH t IN ARRAY v_tables LOOP
        EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
        EXECUTE format('ALTER TABLE public.%I FORCE ROW LEVEL SECURITY', t);
    END LOOP;
END $$;

DROP POLICY IF EXISTS mb13_p3_recovery_audit_lifecycle ON public.mb13_p3_recovery_audit;
CREATE POLICY mb13_p3_recovery_audit_lifecycle
    ON public.mb13_p3_recovery_audit
    FOR ALL
    TO mb13_p3_pack_lifecycle_executor
    USING (true)
    WITH CHECK (true);

-- ============================================================================
-- 8. Membership/SET ROLE graph isolation
-- ============================================================================
DO $$
DECLARE
    v_app_roles TEXT[] := ARRAY['test_app', 'mb13_p3_api', 'mb13_p3_executor', 'mb13_p3_writer', 'mb13_p3_validator', 'mb13_p3_pack_mutator', 'mb13_p3_pack_lifecycle_owner'];
    v_owners TEXT[] := ARRAY['mb13_p3_pack_data_owner', 'mb13_p3_pack_lifecycle_executor', 'mb13_p3_validator'];
    r TEXT; o TEXT;
BEGIN
    FOREACH r IN ARRAY v_app_roles LOOP
        FOREACH o IN ARRAY v_owners LOOP
            EXECUTE format('REVOKE %I FROM %I', o, r);
        END LOOP;
    END LOOP;
END $$;

DO $$
DECLARE
    v_source_roles TEXT[] := ARRAY['test_app', 'mb13_p3_api', 'mb13_p3_executor', 'mb13_p3_writer', 'mb13_p3_validator', 'mb13_p3_pack_mutator', 'mb13_p3_pack_lifecycle_owner'];
    v_target_roles TEXT[] := ARRAY['mb13_p3_pack_data_owner', 'mb13_p3_pack_lifecycle_executor', 'mb13_p3_validator'];
    r RECORD;
BEGIN
    WITH RECURSIVE membership AS (
        SELECT m.member::regrole AS member_role,
               m.roleid::regrole AS granted_role,
               1 AS depth,
               m.admin_option,
               ARRAY[m.member::regrole::text, m.roleid::regrole::text]::text[] AS path
          FROM pg_auth_members m
         WHERE m.member IN (SELECT oid FROM pg_roles WHERE rolname = ANY(v_source_roles))
        UNION
        SELECT p.member_role,
               m.roleid::regrole,
               p.depth + 1,
               p.admin_option OR m.admin_option AS admin_option,
               p.path || m.roleid::regrole::text
          FROM membership p
          JOIN pg_auth_members m ON p.granted_role::oid = m.member
         WHERE p.depth < 10
           AND NOT m.roleid::regrole::text = ANY(p.path)
    )
    SELECT member_role::text, granted_role::text, depth, admin_option, path
      INTO r
      FROM membership
     WHERE granted_role::text = ANY(v_target_roles)
     LIMIT 1;
    IF FOUND THEN
        RAISE EXCEPTION 'migration_v226 membership path from app/legacy role to owner/validator: % -> % (depth %, admin %, path %)', r.member_role, r.granted_role, r.depth, r.admin_option, r.path;
    END IF;
END $$;

-- ============================================================================
-- 9. Effective privilege verification on final state
-- ============================================================================
DO $$
DECLARE
    v_tables TEXT[] := ARRAY['mb13_p3_action_pack', 'mb13_p3_action_pack_attempt', 'mb13_p3_action_pack_authorization', 'mb13_p3_action_pack_evidence', 'mb13_p3_action_pack_result', 'mb13_p3_action_pack_revision', 'mb13_p3_action_pack_timeline', 'mb13_p3_recovery_audit'];
    v_app_roles TEXT[] := ARRAY['test_app', 'mb13_p3_api', 'mb13_p3_executor', 'mb13_p3_writer', 'mb13_p3_validator', 'mb13_p3_pack_mutator', 'mb13_p3_pack_lifecycle_owner'];
    v_append_only_tables TEXT[] := ARRAY['mb13_p3_action_pack_evidence','mb13_p3_action_pack_result','mb13_p3_action_pack_revision','mb13_p3_action_pack_timeline','mb13_p3_recovery_audit'];
    v_privs TEXT[] := ARRAY['INSERT','UPDATE','DELETE','TRUNCATE','REFERENCES','TRIGGER'];
    r TEXT; t TEXT; p TEXT;
BEGIN
    FOREACH t IN ARRAY v_tables LOOP
        FOREACH r IN ARRAY v_app_roles LOOP
            FOREACH p IN ARRAY v_privs LOOP
                IF has_table_privilege(r, 'public.' || t, p) THEN
                    RAISE EXCEPTION 'migration_v226 effective privilege violation: role % has % on %', r, p, t;
                END IF;
            END LOOP;
        END LOOP;
    END LOOP;

    -- lifecycle executor must not UPDATE/DELETE append-only tables.
    FOREACH t IN ARRAY v_append_only_tables LOOP
        FOREACH p IN ARRAY ARRAY['UPDATE','DELETE','TRUNCATE','REFERENCES','TRIGGER']::text[] LOOP
            IF has_table_privilege('mb13_p3_pack_lifecycle_executor', 'public.' || t, p) THEN
                RAISE EXCEPTION 'migration_v226 lifecycle executor has % on append-only table %', p, t;
            END IF;
        END LOOP;
    END LOOP;

    -- lifecycle executor must not have SELECT/INSERT on non-allowlisted tables; verify exact table ACL matrix
    FOREACH t IN ARRAY v_tables LOOP
        IF NOT has_table_privilege('mb13_p3_pack_lifecycle_executor', 'public.' || t, 'SELECT') THEN
            RAISE EXCEPTION 'migration_v226 lifecycle executor missing SELECT on %', t;
        END IF;
        IF NOT has_table_privilege('mb13_p3_pack_lifecycle_executor', 'public.' || t, 'INSERT') THEN
            RAISE EXCEPTION 'migration_v226 lifecycle executor missing INSERT on %', t;
        END IF;
        IF t IN ('mb13_p3_action_pack','mb13_p3_action_pack_attempt','mb13_p3_action_pack_authorization') THEN
            IF NOT has_table_privilege('mb13_p3_pack_lifecycle_executor', 'public.' || t, 'UPDATE') THEN
                RAISE EXCEPTION 'migration_v226 lifecycle executor missing UPDATE on %', t;
            END IF;
        ELSE
            IF has_table_privilege('mb13_p3_pack_lifecycle_executor', 'public.' || t, 'UPDATE') THEN
                RAISE EXCEPTION 'migration_v226 lifecycle executor has unexpected UPDATE on %', t;
            END IF;
        END IF;
        IF has_table_privilege('mb13_p3_pack_lifecycle_executor', 'public.' || t, 'DELETE') THEN
            RAISE EXCEPTION 'migration_v226 lifecycle executor has unexpected DELETE on %', t;
        END IF;
    END LOOP;

    -- writer must not have direct SELECT on MB13-P3 tables (it is BYPASSRLS)
    FOREACH t IN ARRAY v_tables LOOP
        IF has_table_privilege('mb13_p3_writer', 'public.' || t, 'SELECT') THEN
            RAISE EXCEPTION 'migration_v226 writer has direct SELECT on %', t;
        END IF;
    END LOOP;

    -- no residual migration_v22[0-9x]_ function in any non-system schema
    FOR r IN
        SELECT n.nspname, p.oid::regprocedure::text AS sig
          FROM pg_proc p
          JOIN pg_namespace n ON p.pronamespace = n.oid
         WHERE n.nspname NOT IN ('pg_catalog','information_schema','pg_toast')
           AND p.proname ~ '^migration_v22[0-9x]_'
    LOOP
        RAISE EXCEPTION 'migration_v226 residual temporary function at final check: %.%', r.nspname, r.sig;
    END LOOP;
END $$;

-- ============================================================================
-- 10. Remove the row lock on append-only evidence; the attempt lock already
--     serializes calls for a given attempt_id, and the unique index on
--     (owner_user_id, attempt_id, idempotency_key) prevents duplicates.
-- ============================================================================
CREATE OR REPLACE FUNCTION public.mb13_p3_record_execution_evidence(p_owner_user_id uuid, p_pack_id uuid, p_attempt_id uuid, p_attempt_number integer, p_evidence_type text, p_evidence_payload jsonb, p_idempotency_key text)
 RETURNS TABLE(evidence_id uuid, receipt_id uuid, evidence_hash text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_executor_identity TEXT := session_user;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_canonical_payload JSONB;
    v_evidence_hash TEXT;
    v_request_hash TEXT;
    v_receipt_id UUID;
    v_new_id UUID;
    v_existing public.mb13_p3_action_pack_evidence%ROWTYPE;
    v_step_consents JSONB := '[]'::jsonb;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    IF p_idempotency_key IS NULL OR p_idempotency_key = '' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_idempotency_key_required';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.attempt_number IS DISTINCT FROM p_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;
    IF v_attempt.executor_identity IS DISTINCT FROM v_executor_identity THEN
        RAISE EXCEPTION 'mb13_p3_executor_identity_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.provenance_state IS DISTINCT FROM 'verified' THEN
        RAISE EXCEPTION 'mb13_p3_pack_provenance_unverified';
    END IF;

    v_canonical_payload := public.mb13_p3_canonicalize_evidence_payload(v_pack, p_evidence_type, p_evidence_payload);

    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'pack_id', p_pack_id,
        'pack_revision', v_pack.pack_revision,
        'attempt_id', p_attempt_id,
        'attempt_number', p_attempt_number,
        'monitor_revision', v_monitor.current_revision,
        'executor_identity', v_executor_identity,
        'evidence_type', p_evidence_type,
        'schema_version', v_canonical_payload->>'schema_version',
        'evidence_payload', v_canonical_payload
    ));

    SELECT * INTO v_existing
      FROM public.mb13_p3_action_pack_evidence
     WHERE owner_user_id = p_owner_user_id
       AND attempt_id = p_attempt_id
       AND idempotency_key = p_idempotency_key;
    IF FOUND THEN
        IF v_existing.pack_id IS DISTINCT FROM p_pack_id
           OR v_existing.evidence_type IS DISTINCT FROM p_evidence_type
           OR v_existing.attempt_number IS DISTINCT FROM p_attempt_number
           OR v_existing.executor_identity IS DISTINCT FROM v_executor_identity
           OR v_existing.evidence_payload IS DISTINCT FROM v_canonical_payload
           OR v_existing.evidence_state IS DISTINCT FROM 'active' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_idempotency_conflict';
        END IF;

        IF v_pack.status IS DISTINCT FROM 'executing' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
        END IF;
        IF v_attempt.status IS DISTINCT FROM 'executing' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
        END IF;
        IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
            RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
        END IF;
        IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
            RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
        END IF;

        PERFORM public.mb13_p3_validate_trigger_diff(
            p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
            v_pack.trigger_event_id, v_pack.diff_result_id
        );

        v_auth := public.mb13_p3_get_active_authorization(
            p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
            v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
            public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
            public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
            v_monitor.current_revision
        );

        v_step_consents := public.mb13_p3_get_covered_step_consents(v_pack, v_canonical_payload);

        PERFORM public.mb13_p3_validate_source_grant_chain(
            p_owner_user_id, v_monitor, v_pack.consent_refs, v_pack.provenance_refs, v_step_consents
        );

        RETURN QUERY SELECT v_existing.evidence_id, v_existing.receipt_id, v_existing.evidence_hash;
        RETURN;
    END IF;

    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;
    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;
    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    v_step_consents := public.mb13_p3_get_covered_step_consents(v_pack, v_canonical_payload);

    PERFORM public.mb13_p3_validate_source_grant_chain(
        p_owner_user_id, v_monitor, v_pack.consent_refs, v_pack.provenance_refs, v_step_consents
    );

    v_evidence_hash := public.mb13_p0_hash_jsonb(v_canonical_payload);
    v_receipt_id := gen_random_uuid();

    INSERT INTO public.mb13_p3_action_pack_evidence (
        owner_user_id, pack_id, attempt_id, attempt_number, pack_revision, monitor_revision,
        executor_identity, evidence_type, evidence_hash, receipt_id, evidence_payload,
        evidence_schema_version, idempotency_key, evidence_request_hash, evidence_state, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, p_attempt_number, v_pack.pack_revision,
        v_monitor.current_revision, v_executor_identity, p_evidence_type, v_evidence_hash,
        v_receipt_id, v_canonical_payload, 'mb13-p3-evidence/v1', p_idempotency_key,
        v_request_hash, 'active', v_now
    )
    ON CONFLICT ON CONSTRAINT uq_mb13_p3_evidence_owner_attempt_idempotency DO NOTHING
    RETURNING public.mb13_p3_action_pack_evidence.evidence_id INTO v_new_id;

    IF v_new_id IS NULL THEN
        SELECT * INTO v_existing
          FROM public.mb13_p3_action_pack_evidence
         WHERE owner_user_id = p_owner_user_id
           AND attempt_id = p_attempt_id
           AND idempotency_key = p_idempotency_key;
        IF FOUND THEN
            IF v_existing.pack_id IS DISTINCT FROM p_pack_id
               OR v_existing.evidence_type IS DISTINCT FROM p_evidence_type
               OR v_existing.attempt_number IS DISTINCT FROM p_attempt_number
               OR v_existing.executor_identity IS DISTINCT FROM v_executor_identity
               OR v_existing.evidence_payload IS DISTINCT FROM v_canonical_payload
               OR v_existing.evidence_state IS DISTINCT FROM 'active' THEN
                RAISE EXCEPTION 'mb13_p3_evidence_idempotency_conflict';
            END IF;
            IF v_pack.status IS DISTINCT FROM 'executing' OR v_attempt.status IS DISTINCT FROM 'executing' THEN
                RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
            END IF;
            RETURN QUERY SELECT v_existing.evidence_id, v_existing.receipt_id, v_existing.evidence_hash;
            RETURN;
        END IF;
        RAISE EXCEPTION 'mb13_p3_evidence_insert_failed';
    END IF;

    RETURN QUERY SELECT v_new_id, v_receipt_id, v_evidence_hash;
END;
$function$;

ALTER FUNCTION public.mb13_p3_record_execution_evidence(uuid, uuid, uuid, integer, text, jsonb, text) OWNER TO mb13_p3_pack_lifecycle_executor;


-- ============================================================================
-- 11. Final legacy role inertization
-- ============================================================================
ALTER ROLE mb13_p3_pack_mutator NOLOGIN NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p3_pack_lifecycle_owner NOLOGIN NOINHERIT NOBYPASSRLS;

COMMIT;