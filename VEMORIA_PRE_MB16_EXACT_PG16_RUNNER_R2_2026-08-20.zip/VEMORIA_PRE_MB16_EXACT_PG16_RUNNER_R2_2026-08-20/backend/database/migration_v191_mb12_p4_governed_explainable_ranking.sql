-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- MB12-P4 R1 — governed explainable ranking and recommendation.
-- No sponsored ranking, paid priority, hidden criteria, auto-decision or auto-action.

BEGIN;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb12_p4_app') THEN
        CREATE ROLE mb12_p4_app NOLOGIN;
    END IF;
END
$$;

CREATE TABLE IF NOT EXISTS public.mb12_p4_governed_explainable_ranking (
    owner_user_id      UUID NOT NULL,
    ranking_id         UUID NOT NULL,
    stable_id          TEXT NOT NULL,
    title              TEXT NOT NULL,
    current_revision   INTEGER NOT NULL DEFAULT 1,
    state              TEXT NOT NULL,
    payload_hash       TEXT NOT NULL,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, ranking_id),
    UNIQUE (owner_user_id, stable_id),
    CONSTRAINT ck_mb12_p4_stable_id_nonempty CHECK (length(trim(stable_id)) > 0),
    CONSTRAINT ck_mb12_p4_title_nonempty CHECK (length(trim(title)) > 0),
    CONSTRAINT ck_mb12_p4_state CHECK (state IN ('ready','incomplete','incompatible','revoked')),
    CONSTRAINT ck_mb12_p4_revision_positive CHECK (current_revision >= 1)
);

CREATE TABLE IF NOT EXISTS public.mb12_p4_governed_explainable_ranking_revision (
    owner_user_id      UUID NOT NULL,
    ranking_id         UUID NOT NULL,
    revision           INTEGER NOT NULL,
    state              TEXT NOT NULL,
    payload_hash       TEXT NOT NULL,
    profile_ref        JSONB NOT NULL,
    request_payload    JSONB NOT NULL,
    result_payload     JSONB NOT NULL,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, ranking_id, revision),
    CONSTRAINT fk_mb12_p4_revision_ranking
        FOREIGN KEY (owner_user_id, ranking_id)
        REFERENCES public.mb12_p4_governed_explainable_ranking(owner_user_id, ranking_id)
        ON DELETE RESTRICT,
    CONSTRAINT ck_mb12_p4_revision_state CHECK (state IN ('ready','incomplete','incompatible','revoked')),
    CONSTRAINT ck_mb12_p4_revision_positive_2 CHECK (revision >= 1),
    CONSTRAINT ck_mb12_p4_profile_ref_object CHECK (jsonb_typeof(profile_ref) = 'object'),
    CONSTRAINT ck_mb12_p4_request_object CHECK (jsonb_typeof(request_payload) = 'object'),
    CONSTRAINT ck_mb12_p4_result_object CHECK (jsonb_typeof(result_payload) = 'object')
);

CREATE INDEX IF NOT EXISTS ix_mb12_p4_ranking_owner_state
    ON public.mb12_p4_governed_explainable_ranking(owner_user_id, state, updated_at DESC);
CREATE INDEX IF NOT EXISTS ix_mb12_p4_revision_owner_ranking
    ON public.mb12_p4_governed_explainable_ranking_revision(owner_user_id, ranking_id, revision DESC);

ALTER TABLE public.mb12_p4_governed_explainable_ranking ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p4_governed_explainable_ranking FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p4_governed_explainable_ranking_revision ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p4_governed_explainable_ranking_revision FORCE ROW LEVEL SECURITY;

DO $$
DECLARE
    table_name TEXT;
BEGIN
    FOREACH table_name IN ARRAY ARRAY[
        'mb12_p4_governed_explainable_ranking',
        'mb12_p4_governed_explainable_ranking_revision'
    ] LOOP
        EXECUTE format('DROP POLICY IF EXISTS mb12_p4_owner_isolation ON public.%I', table_name);
        EXECUTE format(
            'CREATE POLICY mb12_p4_owner_isolation ON public.%I '
            'USING (owner_user_id = NULLIF(current_setting(''app.owner_id'', true), '''')::uuid) '
            'WITH CHECK (owner_user_id = NULLIF(current_setting(''app.owner_id'', true), '''')::uuid)',
            table_name
        );
    END LOOP;
END
$$;

CREATE OR REPLACE FUNCTION public.mb12_p4_history_immutable()
RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb12_p4_history_is_append_only';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb12_p4_history_immutable() FROM PUBLIC;

DROP TRIGGER IF EXISTS trg_mb12_p4_revision_immutable ON public.mb12_p4_governed_explainable_ranking_revision;
CREATE TRIGGER trg_mb12_p4_revision_immutable
BEFORE UPDATE OR DELETE ON public.mb12_p4_governed_explainable_ranking_revision
FOR EACH ROW EXECUTE FUNCTION public.mb12_p4_history_immutable();

CREATE OR REPLACE FUNCTION public.mb12_p4_write_explainable_ranking(
    p_ranking_id UUID,
    p_stable_id TEXT,
    p_title TEXT,
    p_state TEXT,
    p_profile_ref JSONB,
    p_request_payload JSONB,
    p_result_payload JSONB
) RETURNS TABLE(ranking_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_profile public.mb12_p3_owner_decision_profile%ROWTYPE;
    v_profile_revision public.mb12_p3_owner_decision_profile_revision%ROWTYPE;
    v_current public.mb12_p4_governed_explainable_ranking%ROWTYPE;
    v_revision INTEGER;
    v_payload_hash TEXT;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p4_authenticated_owner_missing';
    END IF;
    IF p_ranking_id IS NULL
       OR length(trim(COALESCE(p_stable_id, ''))) = 0 OR length(p_stable_id) > 200
       OR length(trim(COALESCE(p_title, ''))) = 0 OR length(p_title) > 300 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p4_identity_invalid';
    END IF;
    IF p_state NOT IN ('ready','incomplete','incompatible','revoked') THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p4_state_invalid';
    END IF;
    IF jsonb_typeof(p_profile_ref) <> 'object'
       OR jsonb_typeof(p_request_payload) <> 'object'
       OR jsonb_typeof(p_result_payload) <> 'object'
       OR p_result_payload->'items' IS NULL
       OR jsonb_typeof(p_result_payload->'items') <> 'array' THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p4_payload_shape_invalid';
    END IF;

    IF p_result_payload->'winner' IS DISTINCT FROM 'null'::jsonb
       OR COALESCE((p_result_payload->>'no_auto_decision')::boolean, FALSE) IS NOT TRUE
       OR COALESCE((p_result_payload->>'no_auto_action')::boolean, FALSE) IS NOT TRUE
       OR COALESCE((p_result_payload->>'sponsored_ranking')::boolean, TRUE) IS NOT FALSE
       OR p_result_payload->>'engine_version' IS DISTINCT FROM 'mb12-p4-r1' THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p4_neutrality_invariant_invalid';
    END IF;

    IF p_request_payload ?| ARRAY[
        'score','ranking','recommendation','winner','sponsor','paid_placement',
        'commercial_priority','inferred_profile','confidence','source_refs'
       ]
       OR p_result_payload ?| ARRAY['utility_score','normalized_score','paid_placement'] THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p4_forbidden_decision_field';
    END IF;

    -- Decision episode fields must be present in the result contract for future learning.
    IF p_result_payload->'decision_episode_id' IS NULL
       OR p_result_payload->'user_choice_status' IS NULL
       OR p_result_payload->'user_choice_dossier_id' IS NULL
       OR p_result_payload->'choice_reason' IS NULL
       OR p_result_payload->'outcome_status' IS NULL
       OR p_result_payload->'outcome_evidence' IS NULL
       OR p_result_payload->'correction_status' IS NULL
       OR p_result_payload->'learning_candidate_status' IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p4_decision_episode_contract_missing';
    END IF;

    -- The referenced P3 profile must be ready, current and belong to the owner.
    SELECT p.* INTO v_profile
      FROM public.mb12_p3_owner_decision_profile p
     WHERE p.owner_user_id = v_owner
       AND p.profile_id = NULLIF(p_profile_ref->>'profile_id', '')::uuid
       AND p.current_revision = NULLIF(p_profile_ref->>'revision', '')::integer
       AND p.payload_hash = p_profile_ref->>'payload_hash'
       AND p.state = 'ready';
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p4_ready_p3_profile_required';
    END IF;

    SELECT r.* INTO v_profile_revision
      FROM public.mb12_p3_owner_decision_profile_revision r
     WHERE r.owner_user_id = v_owner
       AND r.profile_id = v_profile.profile_id
       AND r.revision = v_profile.current_revision
       AND r.state = 'ready';
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p4_ready_p3_revision_required';
    END IF;

    -- Result must bind to the referenced P3 profile.
    IF p_result_payload->'profile_ref' IS DISTINCT FROM p_profile_ref
       OR p_result_payload->'assessment_ref' IS DISTINCT FROM v_profile_revision.assessment_ref THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p4_result_binding_invalid';
    END IF;

    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_stable_id, 0));
    v_payload_hash := encode(
        digest(convert_to((p_request_payload || jsonb_build_object('result', p_result_payload))::text, 'UTF8'), 'sha256'),
        'hex'
    );

    SELECT * INTO v_current
      FROM public.mb12_p4_governed_explainable_ranking r
     WHERE r.owner_user_id = v_owner
       AND r.stable_id = p_stable_id
     FOR UPDATE;

    IF FOUND THEN
        IF v_current.payload_hash = v_payload_hash AND v_current.state = p_state THEN
            RETURN QUERY SELECT v_current.ranking_id, v_current.current_revision, v_current.payload_hash;
            RETURN;
        END IF;
        IF v_current.state = 'revoked' AND p_state <> 'revoked' THEN
            RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb12_p4_revoked_ranking_cannot_reactivate';
        END IF;
        p_ranking_id := v_current.ranking_id;
        v_revision := v_current.current_revision + 1;
    ELSE
        v_revision := 1;
        INSERT INTO public.mb12_p4_governed_explainable_ranking (
            owner_user_id, ranking_id, stable_id, title, current_revision, state, payload_hash
        ) VALUES (
            v_owner, p_ranking_id, p_stable_id, p_title, v_revision, p_state, v_payload_hash
        );
    END IF;

    INSERT INTO public.mb12_p4_governed_explainable_ranking_revision (
        owner_user_id, ranking_id, revision, state, payload_hash,
        profile_ref, request_payload, result_payload
    ) VALUES (
        v_owner, p_ranking_id, v_revision, p_state, v_payload_hash,
        p_profile_ref, p_request_payload, p_result_payload
    );

    UPDATE public.mb12_p4_governed_explainable_ranking AS r
       SET title = p_title,
           current_revision = v_revision,
           state = p_state,
           payload_hash = v_payload_hash,
           updated_at = NOW()
     WHERE r.owner_user_id = v_owner
       AND r.ranking_id = p_ranking_id;

    RETURN QUERY SELECT p_ranking_id, v_revision, v_payload_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION public.mb12_p4_revoke_explainable_ranking(
    p_ranking_id UUID,
    p_reason TEXT
) RETURNS TABLE(ranking_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb12_p4_governed_explainable_ranking%ROWTYPE;
    v_previous public.mb12_p4_governed_explainable_ranking_revision%ROWTYPE;
    v_revision INTEGER;
    v_result JSONB;
    v_hash TEXT;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p4_authenticated_owner_missing';
    END IF;
    IF p_ranking_id IS NULL OR length(trim(COALESCE(p_reason, ''))) = 0 OR length(p_reason) > 500 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p4_revocation_invalid';
    END IF;

    SELECT * INTO v_current
      FROM public.mb12_p4_governed_explainable_ranking r
     WHERE r.owner_user_id = v_owner
       AND r.ranking_id = p_ranking_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = 'P0002', MESSAGE = 'mb12_p4_ranking_not_found';
    END IF;
    IF v_current.state = 'revoked' THEN
        RETURN QUERY SELECT v_current.ranking_id, v_current.current_revision, v_current.payload_hash;
        RETURN;
    END IF;

    SELECT * INTO v_previous
      FROM public.mb12_p4_governed_explainable_ranking_revision r
     WHERE r.owner_user_id = v_owner
       AND r.ranking_id = p_ranking_id
       AND r.revision = v_current.current_revision;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb12_p4_current_revision_missing';
    END IF;

    v_revision := v_current.current_revision + 1;
    v_result := v_previous.result_payload || jsonb_build_object(
        'state', 'revoked',
        'revocation_reason', trim(p_reason),
        'revoked_from_revision', v_current.current_revision
    );
    v_hash := encode(
        digest(convert_to((v_previous.request_payload || jsonb_build_object('result', v_result))::text, 'UTF8'), 'sha256'),
        'hex'
    );

    INSERT INTO public.mb12_p4_governed_explainable_ranking_revision (
        owner_user_id, ranking_id, revision, state, payload_hash,
        profile_ref, request_payload, result_payload
    ) VALUES (
        v_owner, p_ranking_id, v_revision, 'revoked', v_hash,
        v_previous.profile_ref, v_previous.request_payload, v_result
    );

    UPDATE public.mb12_p4_governed_explainable_ranking AS r
       SET current_revision = v_revision,
           state = 'revoked',
           payload_hash = v_hash,
           updated_at = NOW()
     WHERE r.owner_user_id = v_owner
       AND r.ranking_id = p_ranking_id;

    RETURN QUERY SELECT p_ranking_id, v_revision, v_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb12_p4_write_explainable_ranking(UUID,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb12_p4_revoke_explainable_ranking(UUID,TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p4_write_explainable_ranking(UUID,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB) TO mb12_p4_app;
GRANT EXECUTE ON FUNCTION public.mb12_p4_revoke_explainable_ranking(UUID,TEXT) TO mb12_p4_app;

REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER
    ON public.mb12_p4_governed_explainable_ranking,
       public.mb12_p4_governed_explainable_ranking_revision
    FROM PUBLIC, mb12_p4_app;
GRANT SELECT
    ON public.mb12_p4_governed_explainable_ranking,
       public.mb12_p4_governed_explainable_ranking_revision
    TO mb12_p4_app;

COMMIT;
