-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- database/migration_v65_luiss_decision_utente_index.sql

CREATE INDEX IF NOT EXISTS idx_luiss_decision_utente
    ON luiss_decision_log(utente_id, creato_il DESC)
    WHERE utente_id IS NOT NULL;
