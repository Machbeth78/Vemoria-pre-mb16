-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
--
-- MB13-P1 R2 — v198b Worker queue and API/executor role separation.
-- Forward-only, idempotent migration. Does not modify v196, v197 or v198a.

BEGIN;

-- ----------------------------------------------------------------------------
-- Ensure the API role exists and is not a member of the executor role.
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p1_api') THEN
        CREATE ROLE mb13_p1_api LOGIN;
    ELSE
        ALTER ROLE mb13_p1_api LOGIN;
    END IF;
END
$$;

-- NOTE: mb13_p1_api is intentionally not granted membership in mb13_p1_executor.
-- The API role can only request jobs; it cannot SET ROLE mb13_p1_executor.

-- ----------------------------------------------------------------------------
-- Job queue: the only table the API role may write.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.mb13_p1_diff_job_queue (
    job_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id       UUID NOT NULL,
    monitor_id          UUID NOT NULL,
    observation_ref     JSONB NOT NULL,
    diff_kind           TEXT NOT NULL CHECK (diff_kind IN ('structured','text')),
    status              TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','claimed','completed','failed')),
    result_payload      JSONB,
    error_message       TEXT,
    diff_id             UUID,
    preflight_id        UUID,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_job_queue_monitor FOREIGN KEY (owner_user_id, monitor_id)
        REFERENCES public.mb13_p0_monitor_target(owner_user_id, monitor_id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS ix_mb13_p1_diff_job_queue_pending
    ON public.mb13_p1_diff_job_queue(owner_user_id, status, created_at)
    WHERE status = 'pending';

ALTER TABLE public.mb13_p1_diff_job_queue OWNER TO mb13_p1_executor;

-- ----------------------------------------------------------------------------
-- API role privileges: read monitors, read/write job queue, call request function.
-- No direct access to diff tables or preflight/writer functions.
-- ----------------------------------------------------------------------------
GRANT SELECT, INSERT, UPDATE ON public.mb13_p1_diff_job_queue TO mb13_p1_api;
GRANT SELECT ON public.mb13_p0_monitor_target TO mb13_p1_api;
GRANT SELECT ON public.mb13_p1_universal_diff TO mb13_p1_api;
GRANT SELECT ON public.mb13_p1_universal_diff_revision TO mb13_p1_api;
GRANT SELECT ON public.mb13_p1_document_revision TO mb13_p1_api;
GRANT SELECT ON public.documenti TO mb13_p1_api;
GRANT SELECT ON public.mb12_p1_offer_contract TO mb13_p1_api;
GRANT SELECT ON public.mb12_p1_offer_contract_revision TO mb13_p1_api;
GRANT SELECT ON public.mb12_p4_governed_explainable_ranking TO mb13_p1_api;
GRANT SELECT ON public.mb12_p4_governed_explainable_ranking_revision TO mb13_p1_api;

-- ----------------------------------------------------------------------------
-- Executor privileges: full control over diff tables and job queue.
-- ----------------------------------------------------------------------------
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p1_diff_job_queue TO mb13_p1_executor;

-- ----------------------------------------------------------------------------
-- API request function: creates a pending job and returns its identity.
-- SECURITY DEFINER runs as executor so the API role cannot write the diff tables.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_request_diff_job(UUID, JSONB, TEXT);
CREATE OR REPLACE FUNCTION public.mb13_p1_request_diff_job(
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT
) RETURNS UUID AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_job_id UUID := gen_random_uuid();
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object'
       OR p_observation_ref->>'id' IS NULL
       OR p_observation_ref->>'revision' IS NULL
       OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
        RAISE EXCEPTION 'mb13_p1_target_owner_mismatch';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM public.mb13_p0_monitor_target
         WHERE owner_user_id = v_owner
           AND monitor_id = p_monitor_id
           AND monitor_state = 'active'
    ) THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;

    INSERT INTO public.mb13_p1_diff_job_queue (
        job_id, owner_user_id, monitor_id, observation_ref, diff_kind, status, created_at, updated_at
    ) VALUES (
        v_job_id, v_owner, p_monitor_id, p_observation_ref, p_diff_kind, 'pending', NOW(), NOW()
    );

    RETURN v_job_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_request_diff_job(UUID, JSONB, TEXT) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_request_diff_job(UUID, JSONB, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_request_diff_job(UUID, JSONB, TEXT) TO mb13_p1_api;

-- ----------------------------------------------------------------------------
-- Executor-only job lifecycle functions.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_claim_job(UUID);
CREATE OR REPLACE FUNCTION public.mb13_p1_claim_job(p_owner UUID)
RETURNS TABLE(
    job_id UUID,
    monitor_id UUID,
    observation_ref JSONB,
    diff_kind TEXT
) AS $$
DECLARE
    v_job public.mb13_p1_diff_job_queue%ROWTYPE;
BEGIN
    SELECT * INTO v_job
      FROM public.mb13_p1_diff_job_queue
     WHERE owner_user_id = p_owner
       AND status = 'pending'
     ORDER BY created_at ASC
     FOR UPDATE SKIP LOCKED
     LIMIT 1;

    IF NOT FOUND THEN
        RETURN;
    END IF;

    UPDATE public.mb13_p1_diff_job_queue
       SET status = 'claimed', updated_at = NOW()
     WHERE public.mb13_p1_diff_job_queue.job_id = v_job.job_id;

    RETURN QUERY SELECT v_job.job_id, v_job.monitor_id, v_job.observation_ref, v_job.diff_kind;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_claim_job(UUID) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_claim_job(UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_claim_job(UUID) TO mb13_p1_executor;

DROP FUNCTION IF EXISTS public.mb13_p1_complete_job(UUID, TEXT, JSONB, TEXT, UUID);
CREATE OR REPLACE FUNCTION public.mb13_p1_complete_job(
    p_job_id UUID,
    p_status TEXT,
    p_result_payload JSONB,
    p_error_message TEXT,
    p_diff_id UUID
) RETURNS VOID AS $$
BEGIN
    UPDATE public.mb13_p1_diff_job_queue
       SET status = p_status,
           result_payload = p_result_payload,
           error_message = p_error_message,
           diff_id = p_diff_id,
           updated_at = NOW()
     WHERE job_id = p_job_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_complete_job(UUID, TEXT, JSONB, TEXT, UUID) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_complete_job(UUID, TEXT, JSONB, TEXT, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_complete_job(UUID, TEXT, JSONB, TEXT, UUID) TO mb13_p1_executor;

-- ----------------------------------------------------------------------------
-- Revoke public/executor-private functions from the API role.
-- The API must request a job; it cannot preflight or write diff tables.
-- ----------------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) FROM mb13_p1_api;
REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB) FROM mb13_p1_api;

REVOKE ALL ON TABLE public.mb13_p1_universal_diff FROM mb13_p1_api;
REVOKE ALL ON TABLE public.mb13_p1_universal_diff_revision FROM mb13_p1_api;
REVOKE ALL ON TABLE public.mb13_p1_preflight_state FROM mb13_p1_api;

COMMIT;
