-- VEMORA -- Migration V78 -- LUISS Personal Memory (alias + role_map)
-- Data: 2026-04-11
-- Autore: Devoti Massimo
--
-- Obiettivo:
--   Primo strato dell'apprendimento locale per utente.
--   Permette a LUISS di imparare nel tempo come il proprietario
--   si riferisce a persone e ruoli specifici.
--
-- Scope V78 (stretto):
--   luiss_personal_aliases -- token generico -> entita' (contatto, tipo doc, soggetto)
--   luiss_personal_roles   -- etichetta ruolo -> contatto specifico
--
-- Fuori scope V78 (prossimi layer):
--   doc_patterns, correction_log, implicit_refs, op_preferences
--
-- Principio di apprendimento:
--   confirmed_count parte da 1 al primo segnale confermato.
--   Cresce a ogni conferma successiva. Non viene mai scritto
--   su inferenze non confermate -- solo su risoluzione accettata.
--   Le correzioni (F4) decrementano: se arriva a 0 la voce
--   non viene piu' usata dal resolver.
--
-- Idempotente: IF NOT EXISTS su tutto.

-- ── Alias personali ───────────────────────────────────────────────────────
-- Mappa un token (nome, soprannome, etichetta) a un'entita' per questo utente.
-- Esempio: "luca" -> contact_id di Luca Rossi (confirmed_count=5)
-- Esempio: "il cliente di via roma" -> contact_id di Mario Bianchi

CREATE TABLE IF NOT EXISTS luiss_personal_aliases (
    id                  UUID        NOT NULL DEFAULT uuid_generate_v4() PRIMARY KEY,
    utente_id           UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,

    -- Token come arriva dall'utente, normalizzato in minuscolo (max 120 char)
    token               TEXT        NOT NULL CHECK (char_length(token) BETWEEN 1 AND 120),

    -- Tipo di entita' a cui il token si riferisce
    entity_type         TEXT        NOT NULL DEFAULT 'subject'
                                    CHECK (entity_type IN ('contact', 'document_type', 'subject')),

    -- Identificatore dell'entita' (UUID contatto come stringa, o etichetta tipo documento)
    entity_id           TEXT,

    -- Nome leggibile dell'entita' (es. "Luca Rossi", "fattura", "Bianchi Mario")
    entity_label        TEXT        NOT NULL,

    -- Segnali confermati: parte da 1 alla prima conferma, cresce a ogni riuso.
    -- Non puo' scendere sotto 0 (gestito dal service con GREATEST).
    -- Voci con confirmed_count = 0 non vengono usate dal resolver.
    confirmed_count     INT         NOT NULL DEFAULT 1 CHECK (confirmed_count >= 0),

    last_confirmed_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    -- Un solo alias attivo per token per utente
    UNIQUE (utente_id, token)
);

CREATE INDEX IF NOT EXISTS idx_personal_aliases_utente
    ON luiss_personal_aliases (utente_id, confirmed_count DESC);

-- ── Role map personale ────────────────────────────────────────────────────
-- Mappa un'etichetta di ruolo a un contatto specifico per questo utente.
-- Esempio: "geometra" -> contact_id di Bianchi Mario (confirmed_count=8)
-- Esempio: "commercialista" -> contact_id di Studio Rossi

CREATE TABLE IF NOT EXISTS luiss_personal_roles (
    id                  UUID        NOT NULL DEFAULT uuid_generate_v4() PRIMARY KEY,
    utente_id           UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,

    -- Etichetta ruolo normalizzata in minuscolo (senza articolo: "geometra" non "il geometra")
    role_label          TEXT        NOT NULL CHECK (char_length(role_label) BETWEEN 1 AND 80),

    -- Contatto associato a questo ruolo per questo utente
    contact_id          TEXT        NOT NULL,   -- UUID del contatto come stringa
    contact_name        TEXT        NOT NULL,   -- nome cached per display rapido

    confirmed_count     INT         NOT NULL DEFAULT 1 CHECK (confirmed_count >= 0),
    last_confirmed_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    -- Un solo contatto attivo per ruolo per utente
    UNIQUE (utente_id, role_label)
);

CREATE INDEX IF NOT EXISTS idx_personal_roles_utente
    ON luiss_personal_roles (utente_id, confirmed_count DESC);
