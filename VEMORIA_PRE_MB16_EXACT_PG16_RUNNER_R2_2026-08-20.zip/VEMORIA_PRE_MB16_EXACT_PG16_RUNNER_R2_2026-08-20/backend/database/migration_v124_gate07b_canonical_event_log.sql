-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- Gate07B — Canonical Event Log foundation.
-- Additive, owner-scoped, append-only. No existing timeline/index is migrated here.
-- Runtime PostgreSQL remains NON_ESEGUITO until the dedicated probe runs on a real DSN.

BEGIN;

CREATE TABLE IF NOT EXISTS canonical_event_payload_registry (
    payload_type TEXT NOT NULL,
    schema_version INTEGER NOT NULL CHECK (schema_version >= 1),
    description TEXT NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    registered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (payload_type, schema_version)
);

INSERT INTO canonical_event_payload_registry(payload_type, schema_version, description)
VALUES
    ('document.v1',1,'Documento o scansione'),
    ('photo.v1',1,'Fotografia'),
    ('video.v1',1,'Video'),
    ('audio.v1',1,'Audio o voce'),
    ('email.v1',1,'Email'),
    ('pec.v1',1,'PEC'),
    ('chat.v1',1,'Chat o messaggio'),
    ('web.v1',1,'Fonte Internet o portale'),
    ('file.v1',1,'File generico'),
    ('entity_link.v1',1,'Collegamento entità-contenuto'),
    ('user_decision.v1',1,'Conferma, correzione, rifiuto o revoca utente'),
    ('revision.v1',1,'Nuova revisione di contenuto'),
    ('deletion.v1',1,'Decisione o esito di eliminazione byte'),
    ('technical.v1',1,'Evento tecnico verificabile'),
    ('projection.v1',1,'Evento tecnico di ricostruzione proiezione')
ON CONFLICT (payload_type, schema_version) DO NOTHING;

CREATE TABLE IF NOT EXISTS canonical_device_set_documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    device_set_epoch BIGINT NOT NULL CHECK (device_set_epoch >= 1),
    previous_digest CHAR(64),
    device_set_digest CHAR(64) NOT NULL CHECK (device_set_digest ~ '^[0-9a-f]{64}$'),
    document_id TEXT NOT NULL,
    issued_at TIMESTAMPTZ NOT NULL,
    signature_b64 TEXT NOT NULL CHECK (length(signature_b64)=86),
    document_json JSONB NOT NULL CHECK (jsonb_typeof(document_json)='object'),
    registered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_user_id, device_set_epoch),
    UNIQUE(owner_user_id, device_set_digest),
    UNIQUE(owner_user_id, device_set_epoch, device_set_digest),
    CHECK (
        (device_set_epoch=1 AND previous_digest IS NULL)
        OR
        (device_set_epoch>1 AND previous_digest ~ '^[0-9a-f]{64}$')
    ),
    CHECK (length(btrim(document_id)) > 0),
    CHECK (document_json ?& ARRAY['owner_pseudonym','epoch','devices','issued_at','document_id','digest','signature_b64']),
    CHECK (document_json->>'digest' = device_set_digest),
    CHECK ((document_json->>'epoch')::BIGINT = device_set_epoch),
    CHECK (document_json->>'owner_pseudonym' = owner_user_id::text),
    CHECK (document_json->>'document_id' = document_id),
    CHECK ((document_json->>'previous_digest') IS NOT DISTINCT FROM previous_digest),
    CHECK ((document_json->>'issued_at')::TIMESTAMPTZ = issued_at),
    CHECK (document_json->>'signature_b64' = signature_b64),
    CHECK (jsonb_typeof(document_json->'devices')='array')
);
CREATE INDEX IF NOT EXISTS idx_canonical_device_set_owner_epoch
    ON canonical_device_set_documents(owner_user_id, device_set_epoch DESC);

-- Proiezione append-only della storia firmata del device-set. Gate05 resta il
-- proprietario della cerimonia di revoca; Gate07B consuma solo chiavi pubbliche,
-- digest, epoch e confine causale/di sequenza. Nessuna private key è ammessa.
CREATE TABLE IF NOT EXISTS canonical_device_authority_epochs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    device_id TEXT NOT NULL,
    device_set_epoch BIGINT NOT NULL CHECK (device_set_epoch >= 1),
    device_set_digest CHAR(64) NOT NULL CHECK (device_set_digest ~ '^[0-9a-f]{64}$'),
    signing_public_key TEXT NOT NULL CHECK (length(signing_public_key)=43),
    device_status TEXT NOT NULL CHECK (device_status IN ('active','revoked')),
    last_authorized_device_sequence BIGINT,
    last_authorized_event_hash CHAR(64),
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_user_id, device_id, device_set_epoch),
    FOREIGN KEY (owner_user_id, device_set_epoch, device_set_digest)
        REFERENCES canonical_device_set_documents(owner_user_id, device_set_epoch, device_set_digest),
    CHECK (
        (device_status='active' AND last_authorized_device_sequence IS NULL
                                AND last_authorized_event_hash IS NULL)
        OR
        (device_status='revoked' AND last_authorized_device_sequence IS NOT NULL
                                 AND last_authorized_device_sequence >= 0
                                 AND last_authorized_event_hash ~ '^[0-9a-f]{64}$')
    )
);
CREATE INDEX IF NOT EXISTS idx_canonical_device_authority_owner_epoch
    ON canonical_device_authority_epochs(owner_user_id, device_set_epoch DESC, device_id);

CREATE TABLE IF NOT EXISTS canonical_event_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    event_id TEXT NOT NULL,
    event_hash CHAR(64) NOT NULL CHECK (event_hash ~ '^[0-9a-f]{64}$'),
    event_type TEXT NOT NULL,
    event_category TEXT NOT NULL CHECK (event_category IN (
        'FATTO_DALLA_FONTE','PROPOSTA_CEREBRO','DECISIONE_UTENTE','EVENTO_TECNICO'
    )),
    schema_version INTEGER NOT NULL CHECK (schema_version = 1),
    payload_type TEXT NOT NULL,
    payload_schema_version INTEGER NOT NULL,
    actor_type TEXT NOT NULL CHECK (actor_type IN (
        'UTENTE','FONTE','CEREBRO','DISPOSITIVO','SERVIZIO_TECNICO'
    )),
    actor_id TEXT NOT NULL,
    device_id TEXT NOT NULL,
    device_set_epoch BIGINT NOT NULL CHECK (device_set_epoch >= 1),
    device_sequence BIGINT NOT NULL CHECK (device_sequence >= 1),
    occurred_at TIMESTAMPTZ,
    recorded_at TIMESTAMPTZ NOT NULL,
    lamport_clock BIGINT NOT NULL CHECK (lamport_clock >= 1),
    operation_id TEXT,
    subject_type TEXT NOT NULL CHECK (subject_type IN (
        'CONTENUTO','OCCORRENZA','REVISIONE','DERIVATO','ENTITA',
        'COLLEGAMENTO','PRATICA','OPERAZIONE'
    )),
    subject_id TEXT NOT NULL,
    source_ref TEXT,
    content_fingerprint TEXT,
    certainty_class TEXT NOT NULL CHECK (certainty_class IN (
        'CERTA_DALLA_FONTE','PROBABILE','PROPOSTA','CONFERMATA_UTENTE',
        'CORRETTA_UTENTE','REVOCATA'
    )),
    confidence_score DOUBLE PRECISION CHECK (
        confidence_score IS NULL OR (confidence_score >= 0 AND confidence_score <= 1)
    ),
    decision_authority TEXT NOT NULL,
    reversibility_class TEXT NOT NULL CHECK (reversibility_class IN (
        'REVERSIBILE','COMPENSABILE','IRREVERSIBILE','ESTERNO_NON_REVOCABILE'
    )),
    causal_refs JSONB NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(causal_refs)='array'),
    related_refs JSONB NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(related_refs)='array'),
    evidence_refs JSONB NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(evidence_refs)='array'),
    previous_device_event_hash CHAR(64),
    signature_algorithm TEXT NOT NULL CHECK (signature_algorithm='Ed25519'),
    device_signature TEXT NOT NULL CHECK (length(device_signature)=86),
    payload JSONB NOT NULL CHECK (jsonb_typeof(payload)='object'),
    event_document JSONB NOT NULL CHECK (jsonb_typeof(event_document)='object'),
    received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_user_id, event_id),
    UNIQUE(owner_user_id, event_hash),
    UNIQUE(owner_user_id, device_id, device_sequence),
    FOREIGN KEY (payload_type, payload_schema_version)
        REFERENCES canonical_event_payload_registry(payload_type, schema_version),
    FOREIGN KEY (owner_user_id, device_id, device_set_epoch)
        REFERENCES canonical_device_authority_epochs(owner_user_id, device_id, device_set_epoch),
    CHECK (
        (device_sequence=1 AND previous_device_event_hash IS NULL)
        OR
        (device_sequence>1 AND previous_device_event_hash ~ '^[0-9a-f]{64}$')
    ),
    CHECK (event_id ~ '^evt_[0-9a-f]{64}$'),
    CHECK (event_category <> 'FATTO_DALLA_FONTE' OR source_ref IS NOT NULL),
    CHECK (
        (event_category='FATTO_DALLA_FONTE' AND actor_type='FONTE')
        OR (event_category='PROPOSTA_CEREBRO' AND actor_type='CEREBRO')
        OR (event_category='DECISIONE_UTENTE' AND actor_type='UTENTE')
        OR (event_category='EVENTO_TECNICO' AND actor_type IN ('DISPOSITIVO','SERVIZIO_TECNICO'))
    ),
    CHECK (
        event_category <> 'PROPOSTA_CEREBRO'
        OR confidence_score IS NULL
        OR jsonb_array_length(evidence_refs) > 0
    ),
    CHECK (
        payload_type <> 'revision.v1'
        OR causal_refs @? '$[*] ? (@.relation == "previous_revision")'
        OR related_refs @? '$[*] ? (@.relation == "previous_revision")'
    ),
    CHECK (event_document ?& ARRAY['event_id','event_hash','owner_id','event_type','event_category',
                                    'schema_version','payload_type','payload_schema_version','actor_type',
                                    'actor_id','device_id','device_set_epoch','device_sequence','recorded_at',
                                    'lamport_clock','subject_type','subject_id','certainty_class',
                                    'decision_authority','reversibility_class','causal_refs','related_refs',
                                    'evidence_refs','signature_algorithm','device_signature','payload']),
    CHECK (event_document->>'event_id' = event_id),
    CHECK (event_document->>'event_hash' = event_hash),
    CHECK (event_document->>'owner_id' = owner_user_id::text),
    CHECK (event_document->>'event_type' = event_type),
    CHECK (event_document->>'event_category' = event_category),
    CHECK ((event_document->>'schema_version')::INTEGER = schema_version),
    CHECK (event_document->>'payload_type' = payload_type),
    CHECK ((event_document->>'payload_schema_version')::INTEGER = payload_schema_version),
    CHECK (event_document->>'actor_type' = actor_type),
    CHECK (event_document->>'actor_id' = actor_id),
    CHECK (event_document->>'device_id' = device_id),
    CHECK ((event_document->>'device_set_epoch')::BIGINT = device_set_epoch),
    CHECK ((event_document->>'device_sequence')::BIGINT = device_sequence),
    CHECK ((event_document->>'lamport_clock')::BIGINT = lamport_clock),
    CHECK (event_document->>'subject_type' = subject_type),
    CHECK (event_document->>'subject_id' = subject_id),
    CHECK (event_document->>'certainty_class' = certainty_class),
    CHECK (event_document->>'decision_authority' = decision_authority),
    CHECK (event_document->>'reversibility_class' = reversibility_class),
    CHECK (event_document->>'signature_algorithm' = signature_algorithm),
    CHECK (event_document->>'device_signature' = device_signature),
    CHECK ((event_document->>'operation_id') IS NOT DISTINCT FROM operation_id),
    CHECK ((event_document->>'source_ref') IS NOT DISTINCT FROM source_ref),
    CHECK ((event_document->>'content_fingerprint') IS NOT DISTINCT FROM content_fingerprint),
    CHECK ((event_document->>'previous_device_event_hash') IS NOT DISTINCT FROM previous_device_event_hash),
    CHECK (((event_document->>'confidence_score')::DOUBLE PRECISION) IS NOT DISTINCT FROM confidence_score),
    CHECK (((event_document->>'occurred_at')::TIMESTAMPTZ) IS NOT DISTINCT FROM occurred_at),
    CHECK ((event_document->>'recorded_at')::TIMESTAMPTZ = recorded_at),
    CHECK (event_document->'payload' = payload),
    CHECK (event_document->'causal_refs' = causal_refs),
    CHECK (event_document->'related_refs' = related_refs),
    CHECK (event_document->'evidence_refs' = evidence_refs)
);

CREATE INDEX IF NOT EXISTS idx_canonical_event_owner_lamport
    ON canonical_event_log(owner_user_id, lamport_clock, device_id, device_sequence);
CREATE INDEX IF NOT EXISTS idx_canonical_event_owner_subject
    ON canonical_event_log(owner_user_id, subject_type, subject_id, lamport_clock DESC);
CREATE INDEX IF NOT EXISTS idx_canonical_event_owner_operation
    ON canonical_event_log(owner_user_id, operation_id)
    WHERE operation_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_canonical_event_owner_category
    ON canonical_event_log(owner_user_id, event_category, recorded_at DESC);
CREATE INDEX IF NOT EXISTS idx_canonical_event_causal_gin
    ON canonical_event_log USING GIN(causal_refs);
CREATE INDEX IF NOT EXISTS idx_canonical_event_related_gin
    ON canonical_event_log USING GIN(related_refs);
CREATE INDEX IF NOT EXISTS idx_canonical_event_evidence_gin
    ON canonical_event_log USING GIN(evidence_refs);

CREATE TABLE IF NOT EXISTS canonical_event_device_heads (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    device_id TEXT NOT NULL,
    last_device_sequence BIGINT NOT NULL CHECK (last_device_sequence >= 1),
    last_event_hash CHAR(64) NOT NULL CHECK (last_event_hash ~ '^[0-9a-f]{64}$'),
    last_lamport_clock BIGINT NOT NULL CHECK (last_lamport_clock >= 1),
    last_device_set_epoch BIGINT NOT NULL CHECK (last_device_set_epoch >= 1),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY(owner_user_id, device_id)
);

CREATE TABLE IF NOT EXISTS canonical_event_owner_clock (
    owner_user_id UUID PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    max_lamport_clock BIGINT NOT NULL DEFAULT 0 CHECK (max_lamport_clock >= 0),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE OR REPLACE FUNCTION vemoria_reject_canonical_event_mutation()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'VEMORIA_CANONICAL_EVENT_IMMUTABLE';
END;
$$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname='trg_canonical_event_log_immutable'
    ) THEN
        CREATE TRIGGER trg_canonical_event_log_immutable
        BEFORE UPDATE OR DELETE ON canonical_event_log
        FOR EACH ROW EXECUTE FUNCTION vemoria_reject_canonical_event_mutation();
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname='trg_canonical_device_set_documents_immutable'
    ) THEN
        CREATE TRIGGER trg_canonical_device_set_documents_immutable
        BEFORE UPDATE OR DELETE ON canonical_device_set_documents
        FOR EACH ROW EXECUTE FUNCTION vemoria_reject_canonical_event_mutation();
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname='trg_canonical_device_authority_immutable'
    ) THEN
        CREATE TRIGGER trg_canonical_device_authority_immutable
        BEFORE UPDATE OR DELETE ON canonical_device_authority_epochs
        FOR EACH ROW EXECUTE FUNCTION vemoria_reject_canonical_event_mutation();
    END IF;
END;
$$;

ALTER TABLE canonical_event_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_event_device_heads ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_event_owner_clock ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_device_authority_epochs ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_device_set_documents ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS canonical_event_log_owner_policy ON canonical_event_log;
CREATE POLICY canonical_event_log_owner_policy ON canonical_event_log
    USING (owner_user_id::text = current_setting('app.owner_id', true))
    WITH CHECK (owner_user_id::text = current_setting('app.owner_id', true));

DROP POLICY IF EXISTS canonical_event_heads_owner_policy ON canonical_event_device_heads;
CREATE POLICY canonical_event_heads_owner_policy ON canonical_event_device_heads
    USING (owner_user_id::text = current_setting('app.owner_id', true))
    WITH CHECK (owner_user_id::text = current_setting('app.owner_id', true));

DROP POLICY IF EXISTS canonical_event_clock_owner_policy ON canonical_event_owner_clock;
CREATE POLICY canonical_event_clock_owner_policy ON canonical_event_owner_clock
    USING (owner_user_id::text = current_setting('app.owner_id', true))
    WITH CHECK (owner_user_id::text = current_setting('app.owner_id', true));

DROP POLICY IF EXISTS canonical_device_set_documents_owner_policy ON canonical_device_set_documents;
CREATE POLICY canonical_device_set_documents_owner_policy ON canonical_device_set_documents
    USING (owner_user_id::text = current_setting('app.owner_id', true))
    WITH CHECK (owner_user_id::text = current_setting('app.owner_id', true));

DROP POLICY IF EXISTS canonical_device_authority_owner_policy ON canonical_device_authority_epochs;
CREATE POLICY canonical_device_authority_owner_policy ON canonical_device_authority_epochs
    USING (owner_user_id::text = current_setting('app.owner_id', true))
    WITH CHECK (owner_user_id::text = current_setting('app.owner_id', true));

COMMENT ON TABLE canonical_event_log IS
    'Gate07B append-only owner-scoped canonical event log. No projection is canonical.';
COMMENT ON TABLE canonical_event_device_heads IS
    'Rebuildable guard state for contiguous per-device sequence and hash chain.';
COMMENT ON TABLE canonical_event_owner_clock IS
    'Rebuildable owner Lamport watermark; not a global canonical sequence.';
COMMENT ON TABLE canonical_device_set_documents IS
    'Append-only signed device-set documents; public metadata only.';
COMMENT ON TABLE canonical_device_authority_epochs IS
    'Public device authority snapshots and revocation cutoffs derived from signed device-set history.';

COMMIT;
