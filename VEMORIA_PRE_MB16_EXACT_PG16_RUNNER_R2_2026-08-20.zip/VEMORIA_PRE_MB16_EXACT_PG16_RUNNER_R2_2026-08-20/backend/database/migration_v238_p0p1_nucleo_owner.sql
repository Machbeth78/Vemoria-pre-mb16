-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA P0/P1 Adversarial Closure — v238
-- Owner isolation for Nucleo Memoria tables.

DO $$
DECLARE
    v_role name;
    v_tbl regclass;
BEGIN
    -- Add owner column to private Nucleo tables
    ALTER TABLE nm_timeline_events ADD COLUMN IF NOT EXISTS owner_user_id UUID;
    ALTER TABLE nm_relations ADD COLUMN IF NOT EXISTS owner_user_id UUID;
    ALTER TABLE nm_session_context ADD COLUMN IF NOT EXISTS owner_user_id UUID;
    ALTER TABLE nm_anchors ADD COLUMN IF NOT EXISTS owner_user_id UUID;
    ALTER TABLE nm_action_decisions ADD COLUMN IF NOT EXISTS owner_user_id UUID;
    ALTER TABLE nm_static_nodes ADD COLUMN IF NOT EXISTS owner_user_id UUID;
    ALTER TABLE nm_read_path_log ADD COLUMN IF NOT EXISTS owner_user_id UUID;

    -- Deterministic backfill for timeline events (best-effort from known owner paths)
    UPDATE nm_timeline_events te
    SET owner_user_id = COALESCE(
        (SELECT d.proprietario_id FROM documenti d WHERE d.id = te.primary_document_id LIMIT 1),
        (SELECT dos.proprietario_id FROM dossier dos WHERE dos.id = te.primary_dossier_id LIMIT 1),
        (SELECT ei.mittente_id FROM eventi_invio ei WHERE ei.id = NULLIF(te.primary_entity_ref, '')::uuid LIMIT 1),
        NULLIF(te.payload_json->>'_shadow_user_ref', '')::uuid
    )
    WHERE te.owner_user_id IS NULL;

    -- Backfill session context from user_ref (text UUID when valid)
    UPDATE nm_session_context sc
    SET owner_user_id = NULLIF(sc.user_ref, '')::uuid
    WHERE sc.owner_user_id IS NULL
      AND sc.user_ref ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$';

    -- Relations, anchors and action decisions: no deterministic owner path available;
    -- assign the system sentinel. Existing rows will be visible only to a system context.
    UPDATE nm_relations SET owner_user_id = '00000000-0000-0000-0000-000000000000'::uuid WHERE owner_user_id IS NULL;
    UPDATE nm_anchors SET owner_user_id = '00000000-0000-0000-0000-000000000000'::uuid WHERE owner_user_id IS NULL;
    UPDATE nm_action_decisions SET owner_user_id = '00000000-0000-0000-0000-000000000000'::uuid WHERE owner_user_id IS NULL;

    -- Timeline and session context leftovers also get the sentinel.
    UPDATE nm_timeline_events SET owner_user_id = '00000000-0000-0000-0000-000000000000'::uuid WHERE owner_user_id IS NULL;
    UPDATE nm_session_context SET owner_user_id = '00000000-0000-0000-0000-000000000000'::uuid WHERE owner_user_id IS NULL;
    UPDATE nm_static_nodes SET owner_user_id = '00000000-0000-0000-0000-000000000000'::uuid WHERE owner_user_id IS NULL;
    UPDATE nm_read_path_log SET owner_user_id = COALESCE(utente_id, '00000000-0000-0000-0000-000000000000'::uuid) WHERE owner_user_id IS NULL;

    -- Function to set owner_user_id from the canonical GUC if not provided explicitly.
    CREATE OR REPLACE FUNCTION trg_set_nucleo_owner()
    RETURNS TRIGGER AS $func$
    BEGIN
        IF NEW.owner_user_id IS NULL THEN
            NEW.owner_user_id := NULLIF(current_setting('app.owner_id', true), '')::uuid;
        END IF;
        RETURN NEW;
    END;
    $func$ LANGUAGE plpgsql;

    -- Attach trigger to each private Nucleo table
    FOR v_tbl IN SELECT unnest(ARRAY['nm_timeline_events', 'nm_relations', 'nm_session_context', 'nm_anchors', 'nm_action_decisions', 'nm_static_nodes', 'nm_read_path_log']::regclass[])
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS %I ON %s', v_tbl::text || '_owner_set', v_tbl::text);
        EXECUTE format('CREATE TRIGGER %I BEFORE INSERT OR UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION trg_set_nucleo_owner()', v_tbl::text || '_owner_set', v_tbl::text);
    END LOOP;

    -- RLS owner policy
    FOR v_tbl IN SELECT unnest(ARRAY['nm_timeline_events', 'nm_relations', 'nm_session_context', 'nm_anchors', 'nm_action_decisions', 'nm_static_nodes', 'nm_read_path_log']::regclass[])
    LOOP
        EXECUTE format('ALTER TABLE %s ENABLE ROW LEVEL SECURITY', v_tbl::text);
        EXECUTE format('ALTER TABLE %s FORCE ROW LEVEL SECURITY', v_tbl::text);
        EXECUTE format('DROP POLICY IF EXISTS %I ON %s', v_tbl::text || '_owner_policy', v_tbl::text);
        EXECUTE format(
            'CREATE POLICY %I ON %s FOR ALL TO PUBLIC USING (owner_user_id = NULLIF(current_setting(''app.owner_id'', true), '''')::uuid) WITH CHECK (owner_user_id = NULLIF(current_setting(''app.owner_id'', true), '''')::uuid)',
            v_tbl::text || '_owner_policy',
            v_tbl::text
        );
    END LOOP;

    -- Minimal grants
    FOR v_role IN SELECT unnest(ARRAY['test_app', 'vemora_user', 'app']::name[])
    LOOP
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = v_role) THEN
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE nm_timeline_events TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE nm_relations TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE nm_session_context TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE nm_anchors TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE nm_action_decisions TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE nm_static_nodes TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE nm_read_path_log TO %I', v_role);
        END IF;
    END LOOP;
END $$;
