-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
--
-- MB13-P1 R2 — v199a Real worker boundary, roles and queue authority.
-- Forward-only, idempotent. Does not modify v196, v197, v198a or v198b.

BEGIN;

-- ----------------------------------------------------------------------------
-- Role cleanup: legacy app is a bypass, executor is internal only.
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p1_app') THEN
        -- Disable login and strip legacy privileges.
        EXECUTE 'ALTER ROLE mb13_p1_app NOLOGIN';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p1_executor') THEN
        CREATE ROLE mb13_p1_executor NOLOGIN;
    ELSE
        ALTER ROLE mb13_p1_executor NOLOGIN;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p1_api') THEN
        CREATE ROLE mb13_p1_api LOGIN;
    ELSE
        ALTER ROLE mb13_p1_api LOGIN;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p1_worker') THEN
        CREATE ROLE mb13_p1_worker LOGIN;
    END IF;

    -- Worker must be a member of executor to run the diff pipeline.
    IF NOT pg_has_role('mb13_p1_worker', 'mb13_p1_executor', 'MEMBER') THEN
        EXECUTE 'GRANT mb13_p1_executor TO mb13_p1_worker';
    END IF;

    -- API must never be a member of executor or worker.
    IF pg_has_role('mb13_p1_api', 'mb13_p1_executor', 'MEMBER') THEN
        EXECUTE 'REVOKE mb13_p1_executor FROM mb13_p1_api';
    END IF;
    IF pg_has_role('mb13_p1_api', 'mb13_p1_worker', 'MEMBER') THEN
        EXECUTE 'REVOKE mb13_p1_worker FROM mb13_p1_api';
    END IF;
END
$$;

-- Executor and worker must be able to bypass RLS for authoritative operations.
ALTER ROLE mb13_p1_executor BYPASSRLS;
ALTER ROLE mb13_p1_worker BYPASSRLS;

-- ----------------------------------------------------------------------------
-- Queue: RLS, owner-isolated, immutable core fields.
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p1_diff_job_queue
    ADD COLUMN IF NOT EXISTS request_hash TEXT,
    ADD COLUMN IF NOT EXISTS worker_name TEXT,
    ADD COLUMN IF NOT EXISTS claimed_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS completed_at TIMESTAMPTZ;

ALTER TABLE public.mb13_p1_diff_job_queue OWNER TO mb13_p1_executor;

ALTER TABLE public.mb13_p1_diff_job_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p1_diff_job_queue FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS queue_owner_select ON public.mb13_p1_diff_job_queue;
CREATE POLICY queue_owner_select ON public.mb13_p1_diff_job_queue
    FOR SELECT TO mb13_p1_api
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID);

-- Worker and executor bypass RLS.

-- Queue fields become immutable after creation.
CREATE OR REPLACE FUNCTION public.mb13_p1_diff_job_queue_immutable_guard()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'mb13_p1_job_delete_blocked';
    END IF;
    IF TG_OP = 'UPDATE' THEN
        IF OLD.owner_user_id IS DISTINCT FROM NEW.owner_user_id
           OR OLD.monitor_id IS DISTINCT FROM NEW.monitor_id
           OR OLD.observation_ref IS DISTINCT FROM NEW.observation_ref
           OR OLD.diff_kind IS DISTINCT FROM NEW.diff_kind
           OR OLD.request_hash IS DISTINCT FROM NEW.request_hash THEN
            RAISE EXCEPTION 'mb13_p1_job_immutable_fields_blocked';
        END IF;
        IF NOT (
            (OLD.status = 'pending' AND NEW.status IN ('pending','claimed','failed'))
            OR (OLD.status = 'claimed' AND NEW.status IN ('claimed','completed','failed'))
        ) THEN
            RAISE EXCEPTION 'mb13_p1_job_invalid_status_transition';
        END IF;
    END IF;
    IF TG_OP = 'INSERT' THEN
        IF NEW.status <> 'pending' THEN
            RAISE EXCEPTION 'mb13_p1_job_must_start_pending';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_mb13_p1_diff_job_queue_immutable_guard ON public.mb13_p1_diff_job_queue;
CREATE TRIGGER trg_mb13_p1_diff_job_queue_immutable_guard
    BEFORE INSERT OR UPDATE OR DELETE ON public.mb13_p1_diff_job_queue
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p1_diff_job_queue_immutable_guard();

-- ----------------------------------------------------------------------------
-- Preflight state RLS.
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p1_preflight_state OWNER TO mb13_p1_executor;
ALTER TABLE public.mb13_p1_preflight_state ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p1_preflight_state FORCE ROW LEVEL SECURITY;

-- ----------------------------------------------------------------------------
-- API privileges: minimal and strictly through functions.
-- ----------------------------------------------------------------------------
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM mb13_p1_api;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM mb13_p1_api;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM mb13_p1_api;

REVOKE ALL ON public.mb13_p1_universal_diff FROM mb13_p1_api;
REVOKE ALL ON public.mb13_p1_universal_diff_revision FROM mb13_p1_api;
REVOKE ALL ON public.mb13_p1_preflight_state FROM mb13_p1_api;
REVOKE ALL ON public.mb13_p1_document_revision FROM mb13_p1_api;
REVOKE ALL ON public.mb13_p1_diff_job_queue FROM mb13_p1_api;

GRANT USAGE ON SCHEMA public TO mb13_p1_api;

-- Read only completed diffs and own job status.
GRANT SELECT ON public.mb13_p1_universal_diff TO mb13_p1_api;
GRANT SELECT ON public.mb13_p1_universal_diff_revision TO mb13_p1_api;
GRANT SELECT ON public.mb13_p1_diff_job_queue TO mb13_p1_api;

-- Monitor read for validation inside request function.
GRANT SELECT ON public.mb13_p0_monitor_target TO mb13_p1_api;

-- ----------------------------------------------------------------------------
-- Legacy app: no privileges.
-- ----------------------------------------------------------------------------
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM mb13_p1_app;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM mb13_p1_app;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM mb13_p1_app;

-- ----------------------------------------------------------------------------
-- Worker privileges: executor grant + ability to read queue and write diff.
-- ----------------------------------------------------------------------------
GRANT mb13_p1_executor TO mb13_p1_worker;

-- ----------------------------------------------------------------------------
-- Request diff job: the only way the API can create a job.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_request_diff_job(UUID, JSONB, TEXT);
CREATE OR REPLACE FUNCTION public.mb13_p1_request_diff_job(
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT
) RETURNS UUID AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_job_id UUID := gen_random_uuid();
    v_request_hash TEXT;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_api', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_api_role_required';
    END IF;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object'
       OR p_observation_ref->>'id' IS NULL
       OR p_observation_ref->>'revision' IS NULL
       OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
        RAISE EXCEPTION 'mb13_p1_target_owner_mismatch';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM public.mb13_p0_monitor_target
         WHERE owner_user_id = v_owner
           AND monitor_id = p_monitor_id
           AND monitor_state = 'active'
    ) THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;

    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'observation_ref', p_observation_ref,
        'diff_kind', p_diff_kind,
        'requested_at', to_jsonb(NOW())
    ));

    INSERT INTO public.mb13_p1_diff_job_queue (
        job_id, owner_user_id, monitor_id, observation_ref, diff_kind, status,
        request_hash, created_at, updated_at
    ) VALUES (
        v_job_id, v_owner, p_monitor_id, p_observation_ref, p_diff_kind, 'pending',
        v_request_hash, NOW(), NOW()
    );

    RETURN v_job_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_request_diff_job(UUID, JSONB, TEXT) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_request_diff_job(UUID, JSONB, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_request_diff_job(UUID, JSONB, TEXT) TO mb13_p1_api;

-- ----------------------------------------------------------------------------
-- API status helpers.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_get_job_status(UUID);
CREATE OR REPLACE FUNCTION public.mb13_p1_get_job_status(p_job_id UUID)
RETURNS public.mb13_p1_diff_job_queue AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_job public.mb13_p1_diff_job_queue%ROWTYPE;
BEGIN
    SELECT * INTO v_job
      FROM public.mb13_p1_diff_job_queue
     WHERE owner_user_id = v_owner
       AND job_id = p_job_id;
    RETURN v_job;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_get_job_status(UUID) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_get_job_status(UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_get_job_status(UUID) TO mb13_p1_api;

DROP FUNCTION IF EXISTS public.mb13_p1_list_jobs(UUID, INTEGER, INTEGER);
CREATE OR REPLACE FUNCTION public.mb13_p1_list_jobs(
    p_monitor_id UUID DEFAULT NULL,
    p_limit INTEGER DEFAULT 100,
    p_offset INTEGER DEFAULT 0
) RETURNS SETOF public.mb13_p1_diff_job_queue AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    RETURN QUERY
    SELECT *
      FROM public.mb13_p1_diff_job_queue
     WHERE owner_user_id = v_owner
       AND (p_monitor_id IS NULL OR monitor_id = p_monitor_id)
     ORDER BY created_at DESC
     LIMIT p_limit OFFSET p_offset;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_list_jobs(UUID, INTEGER, INTEGER) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_list_jobs(UUID, INTEGER, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_list_jobs(UUID, INTEGER, INTEGER) TO mb13_p1_api;

-- ----------------------------------------------------------------------------
-- Worker claim/complete functions (executor-owned, bypass RLS).
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_claim_job_for_worker();
CREATE OR REPLACE FUNCTION public.mb13_p1_claim_job_for_worker()
RETURNS TABLE(
    job_id UUID,
    owner_user_id UUID,
    monitor_id UUID,
    observation_ref JSONB,
    diff_kind TEXT,
    request_hash TEXT
) AS $$
DECLARE
    v_job public.mb13_p1_diff_job_queue%ROWTYPE;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    SELECT * INTO v_job
      FROM public.mb13_p1_diff_job_queue
     WHERE status = 'pending'
     ORDER BY created_at ASC
     FOR UPDATE SKIP LOCKED
     LIMIT 1;

    IF NOT FOUND THEN
        RETURN;
    END IF;

    UPDATE public.mb13_p1_diff_job_queue
       SET status = 'claimed',
           worker_name = v_session_user,
           claimed_at = NOW(),
           updated_at = NOW()
     WHERE public.mb13_p1_diff_job_queue.job_id = v_job.job_id;

    RETURN QUERY SELECT v_job.job_id, v_job.owner_user_id, v_job.monitor_id, v_job.observation_ref, v_job.diff_kind, v_job.request_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_claim_job_for_worker() OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_claim_job_for_worker() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_claim_job_for_worker() TO mb13_p1_worker;

DROP FUNCTION IF EXISTS public.mb13_p1_complete_job(UUID, TEXT, JSONB, TEXT, UUID);
CREATE OR REPLACE FUNCTION public.mb13_p1_complete_job(
    p_job_id UUID,
    p_status TEXT,
    p_result_payload JSONB,
    p_error_message TEXT,
    p_diff_id UUID
) RETURNS VOID AS $$
DECLARE
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    UPDATE public.mb13_p1_diff_job_queue
       SET status = p_status,
           result_payload = p_result_payload,
           error_message = p_error_message,
           diff_id = p_diff_id,
           completed_at = NOW(),
           updated_at = NOW()
     WHERE job_id = p_job_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_complete_job(UUID, TEXT, JSONB, TEXT, UUID) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_complete_job(UUID, TEXT, JSONB, TEXT, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_complete_job(UUID, TEXT, JSONB, TEXT, UUID) TO mb13_p1_worker;

-- ----------------------------------------------------------------------------
-- Revoke old preflight/writer from legacy app and API.
-- ----------------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) FROM mb13_p1_app;
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) FROM mb13_p1_api;
REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB) FROM mb13_p1_app;
REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB) FROM mb13_p1_api;
REVOKE ALL ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) FROM mb13_p1_app;
REVOKE ALL ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) FROM mb13_p1_api;

COMMIT;
