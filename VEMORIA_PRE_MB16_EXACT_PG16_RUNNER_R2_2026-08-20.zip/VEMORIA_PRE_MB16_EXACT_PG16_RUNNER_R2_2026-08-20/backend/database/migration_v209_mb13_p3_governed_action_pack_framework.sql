-- VEMORA — Migration v209
-- MB13-P3 R1 — Governed Action Pack Framework
-- forward-only, idempotent, owner-scoped, append-only provenance
BEGIN;

-- ----------------------------------------------------------------------------
-- 1. Roles
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p3_writer') THEN
        CREATE ROLE mb13_p3_writer NOLOGIN BYPASSRLS;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p3_api') THEN
        CREATE ROLE mb13_p3_api NOLOGIN;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p3_executor') THEN
        CREATE ROLE mb13_p3_executor NOLOGIN;
    END IF;
END $$;

GRANT USAGE ON SCHEMA public TO mb13_p3_writer, mb13_p3_api, mb13_p3_executor;

-- ----------------------------------------------------------------------------
-- 2. Action Pack tables
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.mb13_p3_action_pack (
    pack_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL,
    monitor_id UUID NOT NULL,
    monitor_revision INTEGER NOT NULL,
    trigger_event_id UUID,
    diff_result_id UUID,
    pack_revision INTEGER NOT NULL DEFAULT 1,
    payload_hash TEXT NOT NULL,
    action_type TEXT NOT NULL,
    target_ref JSONB NOT NULL DEFAULT '{}'::jsonb,
    consent_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
    provenance_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
    steps JSONB NOT NULL DEFAULT '[]'::jsonb,
    expires_at TIMESTAMPTZ,
    idempotency_key TEXT,
    status TEXT NOT NULL DEFAULT 'proposed',
    claimed_attempt_id UUID,
    created_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    CONSTRAINT fk_mb13_p3_pack_monitor FOREIGN KEY (owner_user_id, monitor_id)
        REFERENCES public.mb13_p0_monitor_target(owner_user_id, monitor_id) ON DELETE CASCADE,
    CONSTRAINT ck_mb13_p3_pack_status CHECK (status IN (
        'draft','proposed','awaiting_confirmation','authorized','claimed','executing','completed','partial','failed','cancelled','revoked','expired'
    )),
    CONSTRAINT ck_mb13_p3_pack_action_type CHECK (action_type IN (
        'notify','update','remind','simulate','internal'
    )),
    CONSTRAINT ck_mb13_p3_pack_refs CHECK (
        jsonb_typeof(target_ref) = 'object'
        AND jsonb_typeof(consent_refs) = 'array'
        AND jsonb_typeof(provenance_refs) = 'array'
        AND jsonb_typeof(steps) = 'array'
    ),
    CONSTRAINT ck_mb13_p3_pack_revision_positive CHECK (pack_revision >= 1)
);

CREATE UNIQUE INDEX IF NOT EXISTS ix_mb13_p3_pack_idempotency
    ON public.mb13_p3_action_pack(owner_user_id, idempotency_key)
    WHERE idempotency_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_mb13_p3_pack_owner_status
    ON public.mb13_p3_action_pack(owner_user_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_mb13_p3_pack_monitor
    ON public.mb13_p3_action_pack(owner_user_id, monitor_id);

CREATE TABLE IF NOT EXISTS public.mb13_p3_action_pack_revision (
    revision_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL,
    pack_id UUID NOT NULL,
    revision INTEGER NOT NULL,
    monitor_revision INTEGER NOT NULL,
    trigger_event_id UUID,
    diff_result_id UUID,
    payload_hash TEXT NOT NULL,
    action_type TEXT NOT NULL,
    target_ref JSONB NOT NULL,
    consent_refs JSONB NOT NULL,
    provenance_refs JSONB NOT NULL,
    steps JSONB NOT NULL,
    expires_at TIMESTAMPTZ,
    idempotency_key TEXT,
    status TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    CONSTRAINT fk_mb13_p3_rev_pack FOREIGN KEY (pack_id)
        REFERENCES public.mb13_p3_action_pack(pack_id) ON DELETE CASCADE,
    CONSTRAINT uq_mb13_p3_rev_pack_revision UNIQUE (pack_id, revision),
    CONSTRAINT ck_mb13_p3_rev_status CHECK (status IN (
        'draft','proposed','awaiting_confirmation','authorized','claimed','executing','completed','partial','failed','cancelled','revoked','expired'
    ))
);

CREATE TABLE IF NOT EXISTS public.mb13_p3_action_pack_authorization (
    auth_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL,
    pack_id UUID NOT NULL UNIQUE,
    pack_revision INTEGER NOT NULL,
    authorized_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    expires_at TIMESTAMPTZ NOT NULL,
    auth_payload_hash TEXT NOT NULL,
    revoked BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    CONSTRAINT fk_mb13_p3_auth_pack FOREIGN KEY (pack_id)
        REFERENCES public.mb13_p3_action_pack(pack_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS public.mb13_p3_action_pack_attempt (
    attempt_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL,
    pack_id UUID NOT NULL,
    attempt_number INTEGER NOT NULL,
    idempotency_key TEXT NOT NULL,
    claim_nonce TEXT NOT NULL,
    executor_identity TEXT,
    status TEXT NOT NULL DEFAULT 'claimed',
    result_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    result_hash TEXT,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    CONSTRAINT fk_mb13_p3_attempt_pack FOREIGN KEY (pack_id)
        REFERENCES public.mb13_p3_action_pack(pack_id) ON DELETE CASCADE,
    CONSTRAINT uq_mb13_p3_attempt_idempotency UNIQUE (pack_id, idempotency_key),
    CONSTRAINT ck_mb13_p3_attempt_status CHECK (status IN ('claimed','executing','completed','partial','failed')),
    CONSTRAINT ck_mb13_p3_attempt_payload_object CHECK (jsonb_typeof(result_payload) = 'object')
);
CREATE INDEX IF NOT EXISTS ix_mb13_p3_attempt_pack
    ON public.mb13_p3_action_pack_attempt(pack_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.mb13_p3_action_pack_timeline (
    timeline_event_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL,
    pack_id UUID NOT NULL,
    monitor_id UUID NOT NULL,
    event_kind TEXT NOT NULL,
    from_state TEXT,
    to_state TEXT,
    event_time TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    event_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    payload_hash TEXT NOT NULL,
    monitor_revision INTEGER,
    policy_hash TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    CONSTRAINT fk_mb13_p3_timeline_pack FOREIGN KEY (pack_id)
        REFERENCES public.mb13_p3_action_pack(pack_id) ON DELETE CASCADE,
    CONSTRAINT ck_mb13_p3_timeline_event_kind CHECK (event_kind IN (
        'pack_created','pack_revised','authorized','authorization_revoked','claim_revoked','claimed','started','completed','partial','failed','cancelled','expired','rolled_back'
    )),
    CONSTRAINT ck_mb13_p3_timeline_payload_object CHECK (jsonb_typeof(event_payload) = 'object')
);
CREATE INDEX IF NOT EXISTS ix_mb13_p3_timeline_pack
    ON public.mb13_p3_action_pack_timeline(pack_id, event_time DESC);

ALTER TABLE public.mb13_p3_action_pack OWNER TO mb13_p3_writer;
ALTER TABLE public.mb13_p3_action_pack_revision OWNER TO mb13_p3_writer;
ALTER TABLE public.mb13_p3_action_pack_authorization OWNER TO mb13_p3_writer;
ALTER TABLE public.mb13_p3_action_pack_attempt OWNER TO mb13_p3_writer;
ALTER TABLE public.mb13_p3_action_pack_timeline OWNER TO mb13_p3_writer;

-- ----------------------------------------------------------------------------
-- 3. RLS and owner isolation
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p3_action_pack ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p3_action_pack FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p3_action_pack_revision ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p3_action_pack_revision FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p3_action_pack_authorization ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p3_action_pack_authorization FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p3_action_pack_attempt ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p3_action_pack_attempt FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p3_action_pack_timeline ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p3_action_pack_timeline FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb13_p3_pack_owner_isolation ON public.mb13_p3_action_pack;
CREATE POLICY mb13_p3_pack_owner_isolation ON public.mb13_p3_action_pack
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

DROP POLICY IF EXISTS mb13_p3_rev_owner_isolation ON public.mb13_p3_action_pack_revision;
CREATE POLICY mb13_p3_rev_owner_isolation ON public.mb13_p3_action_pack_revision
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

DROP POLICY IF EXISTS mb13_p3_auth_owner_isolation ON public.mb13_p3_action_pack_authorization;
CREATE POLICY mb13_p3_auth_owner_isolation ON public.mb13_p3_action_pack_authorization
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

DROP POLICY IF EXISTS mb13_p3_attempt_owner_isolation ON public.mb13_p3_action_pack_attempt;
CREATE POLICY mb13_p3_attempt_owner_isolation ON public.mb13_p3_action_pack_attempt
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

DROP POLICY IF EXISTS mb13_p3_timeline_owner_isolation ON public.mb13_p3_action_pack_timeline;
CREATE POLICY mb13_p3_timeline_owner_isolation ON public.mb13_p3_action_pack_timeline
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

-- ----------------------------------------------------------------------------
-- 4. Append-only triggers for revision and timeline
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_revision_immutable()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'mb13_p3_action_pack_revision is append-only'
        USING ERRCODE = 'P3IMM';
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_revision_immutable() OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_revision_immutable() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_revision_immutable() TO mb13_p3_writer;

DROP TRIGGER IF EXISTS trg_mb13_p3_revision_immutable ON public.mb13_p3_action_pack_revision;
CREATE TRIGGER trg_mb13_p3_revision_immutable
    BEFORE UPDATE OR DELETE ON public.mb13_p3_action_pack_revision
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p3_action_pack_revision_immutable();

CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_timeline_immutable()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        NEW.payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', NEW.owner_user_id,
            'pack_id', NEW.pack_id,
            'monitor_id', NEW.monitor_id,
            'event_kind', NEW.event_kind,
            'from_state', NEW.from_state,
            'to_state', NEW.to_state,
            'event_time', NEW.event_time,
            'event_payload', NEW.event_payload,
            'monitor_revision', NEW.monitor_revision,
            'policy_hash', NEW.policy_hash
        ));
        RETURN NEW;
    END IF;
    RAISE EXCEPTION 'mb13_p3_action_pack_timeline is append-only'
        USING ERRCODE = 'P3IMM';
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_timeline_immutable() OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_timeline_immutable() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_timeline_immutable() TO mb13_p3_writer;

DROP TRIGGER IF EXISTS trg_mb13_p3_timeline_immutable ON public.mb13_p3_action_pack_timeline;
CREATE TRIGGER trg_mb13_p3_timeline_immutable
    BEFORE INSERT OR UPDATE OR DELETE ON public.mb13_p3_action_pack_timeline
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p3_action_pack_timeline_immutable();

-- ----------------------------------------------------------------------------
-- 5. Helpers
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_payload_hash(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_monitor_revision INTEGER,
    p_trigger_event_id UUID,
    p_diff_result_id UUID,
    p_action_type TEXT,
    p_target_ref JSONB,
    p_consent_refs JSONB,
    p_provenance_refs JSONB,
    p_steps JSONB,
    p_expires_at TIMESTAMPTZ,
    p_idempotency_key TEXT,
    p_status TEXT
) RETURNS TEXT AS $$
BEGIN
    RETURN public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'monitor_id', p_monitor_id,
        'monitor_revision', p_monitor_revision,
        'trigger_event_id', p_trigger_event_id,
        'diff_result_id', p_diff_result_id,
        'action_type', p_action_type,
        'target_ref', COALESCE(p_target_ref, '{}'::jsonb),
        'consent_refs', COALESCE(p_consent_refs, '[]'::jsonb),
        'provenance_refs', COALESCE(p_provenance_refs, '[]'::jsonb),
        'steps', COALESCE(p_steps, '[]'::jsonb),
        'expires_at', p_expires_at,
        'idempotency_key', p_idempotency_key,
        'status', p_status
    ));
END;
$$ LANGUAGE plpgsql IMMUTABLE
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_payload_hash(UUID, UUID, INTEGER, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_payload_hash(UUID, UUID, INTEGER, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) FROM PUBLIC;

CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_auth_hash(
    p_pack_id UUID,
    p_owner_user_id UUID,
    p_pack_revision INTEGER,
    p_monitor_revision INTEGER,
    p_authorized_at TIMESTAMPTZ,
    p_expires_at TIMESTAMPTZ
) RETURNS TEXT AS $$
BEGIN
    RETURN public.mb13_p0_hash_jsonb(jsonb_build_object(
        'pack_id', p_pack_id,
        'owner_user_id', p_owner_user_id,
        'pack_revision', p_pack_revision,
        'monitor_revision', p_monitor_revision,
        'authorized_at', p_authorized_at,
        'expires_at', p_expires_at
    ));
END;
$$ LANGUAGE plpgsql IMMUTABLE
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_auth_hash(UUID, UUID, INTEGER, INTEGER, TIMESTAMPTZ, TIMESTAMPTZ) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_auth_hash(UUID, UUID, INTEGER, INTEGER, TIMESTAMPTZ, TIMESTAMPTZ) FROM PUBLIC;

CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_refs_revoked(
    p_monitor public.mb13_p0_monitor_target,
    p_consent_refs JSONB,
    p_provenance_refs JSONB
) RETURNS BOOLEAN AS $$
DECLARE
    v_elem JSONB;
    v_present BOOLEAN;
BEGIN
    FOR v_elem IN SELECT jsonb_array_elements(COALESCE(p_consent_refs, '[]'::jsonb)) LOOP
        v_present := (
            SELECT bool_or(v_elem = jsonb_array_elements(COALESCE(p_monitor.consent_refs, '[]'::jsonb)))
            FROM public.mb13_p0_monitor_target
            WHERE FALSE
        );
        IF NOT EXISTS (
            SELECT 1
            FROM jsonb_array_elements(COALESCE(p_monitor.consent_refs, '[]'::jsonb)) AS e
            WHERE e = v_elem
        ) THEN
            RETURN true;
        END IF;
    END LOOP;

    FOR v_elem IN SELECT jsonb_array_elements(COALESCE(p_provenance_refs, '[]'::jsonb)) LOOP
        IF NOT EXISTS (
            SELECT 1
            FROM jsonb_array_elements(COALESCE(p_monitor.source_refs, '[]'::jsonb) || COALESCE(p_monitor.evidence_refs, '[]'::jsonb)) AS e
            WHERE e = v_elem
        ) THEN
            RETURN true;
        END IF;
    END LOOP;

    RETURN false;
END;
$$ LANGUAGE plpgsql STABLE
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_refs_revoked(public.mb13_p0_monitor_target, JSONB, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_refs_revoked(public.mb13_p0_monitor_target, JSONB, JSONB) FROM PUBLIC;

-- ----------------------------------------------------------------------------
-- 6. Create action pack
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_create_action_pack(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_trigger_event_id UUID,
    p_diff_result_id UUID,
    p_action_type TEXT,
    p_target_ref JSONB,
    p_consent_refs JSONB,
    p_provenance_refs JSONB,
    p_steps JSONB,
    p_expires_at TIMESTAMPTZ,
    p_idempotency_key TEXT,
    p_initial_status TEXT DEFAULT 'proposed'
) RETURNS TABLE(
    pack_id UUID,
    owner_user_id UUID,
    monitor_id UUID,
    monitor_revision INTEGER,
    trigger_event_id UUID,
    diff_result_id UUID,
    pack_revision INTEGER,
    payload_hash TEXT,
    action_type TEXT,
    target_ref JSONB,
    consent_refs JSONB,
    provenance_refs JSONB,
    steps JSONB,
    expires_at TIMESTAMPTZ,
    idempotency_key TEXT,
    status TEXT,
    claimed_attempt_id UUID,
    created_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_existing public.mb13_p3_action_pack%ROWTYPE;
    v_pack_id UUID;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
    v_payload_hash TEXT;
    v_status TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);
    v_status := COALESCE(p_initial_status, 'proposed');

    IF p_trigger_event_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.mb13_p0_monitor_event_ledger
             WHERE owner_user_id = p_owner_user_id
               AND event_id = p_trigger_event_id
               AND monitor_id = p_monitor_id
               AND event_status NOT IN ('superseded','failed')
        ) THEN
            RAISE EXCEPTION 'mb13_p3_trigger_event_invalid';
        END IF;
    END IF;

    IF p_diff_result_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.mb13_p1_universal_diff
             WHERE owner_user_id = p_owner_user_id
               AND diff_id = p_diff_result_id
               AND monitor_id = p_monitor_id
               AND diff_state NOT IN ('blocked','invalid')
        ) THEN
            RAISE EXCEPTION 'mb13_p3_diff_result_invalid';
        END IF;
    END IF;

    IF p_trigger_event_id IS NULL AND p_diff_result_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_trigger_or_diff_required';
    END IF;

    IF p_expires_at IS NOT NULL AND p_expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF p_idempotency_key IS NOT NULL THEN
        SELECT * INTO v_existing
          FROM public.mb13_p3_action_pack
         WHERE owner_user_id = p_owner_user_id
           AND idempotency_key = p_idempotency_key;
        IF FOUND THEN
            RETURN QUERY SELECT * FROM public.mb13_p3_action_pack WHERE pack_id = v_existing.pack_id AND owner_user_id = p_owner_user_id;
            RETURN;
        END IF;
    END IF;

    v_payload_hash := public.mb13_p3_action_pack_payload_hash(
        p_owner_user_id, p_monitor_id, v_monitor_revision,
        p_trigger_event_id, p_diff_result_id, p_action_type,
        p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
        p_expires_at, p_idempotency_key, v_status
    );

    INSERT INTO public.mb13_p3_action_pack (
        owner_user_id, monitor_id, monitor_revision, trigger_event_id, diff_result_id,
        pack_revision, payload_hash, action_type, target_ref, consent_refs, provenance_refs,
        steps, expires_at, idempotency_key, status, created_at, updated_at
    ) VALUES (
        p_owner_user_id, p_monitor_id, v_monitor_revision, p_trigger_event_id, p_diff_result_id,
        1, v_payload_hash, p_action_type, COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, p_idempotency_key, v_status, v_now, v_now
    ) RETURNING public.mb13_p3_action_pack.pack_id INTO v_pack_id;

    INSERT INTO public.mb13_p3_action_pack_revision (
        owner_user_id, pack_id, revision, monitor_revision, trigger_event_id, diff_result_id,
        payload_hash, action_type, target_ref, consent_refs, provenance_refs, steps,
        expires_at, idempotency_key, status, created_at
    ) VALUES (
        p_owner_user_id, v_pack_id, 1, v_monitor_revision, p_trigger_event_id, p_diff_result_id,
        v_payload_hash, p_action_type, COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, p_idempotency_key, v_status, v_now
    );

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_pack_id, p_monitor_id, 'pack_created', NULL, v_status,
        v_now, jsonb_build_object('pack_revision', 1),
        v_monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT * FROM public.mb13_p3_action_pack WHERE pack_id = v_pack_id AND owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) TO mb13_p3_api;

-- ----------------------------------------------------------------------------
-- 7. Get / list action pack
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_get_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID
) RETURNS TABLE(
    pack_id UUID,
    owner_user_id UUID,
    monitor_id UUID,
    monitor_revision INTEGER,
    trigger_event_id UUID,
    diff_result_id UUID,
    pack_revision INTEGER,
    payload_hash TEXT,
    action_type TEXT,
    target_ref JSONB,
    consent_refs JSONB,
    provenance_refs JSONB,
    steps JSONB,
    expires_at TIMESTAMPTZ,
    idempotency_key TEXT,
    status TEXT,
    claimed_attempt_id UUID,
    created_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_get_action_pack(UUID, UUID) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_get_action_pack(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_action_pack(UUID, UUID) TO mb13_p3_api;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_action_pack(UUID, UUID) TO mb13_p3_executor;

CREATE OR REPLACE FUNCTION public.mb13_p3_list_action_packs(
    p_owner_user_id UUID,
    p_status TEXT DEFAULT NULL,
    p_limit INTEGER DEFAULT 100,
    p_offset INTEGER DEFAULT 0
) RETURNS TABLE(
    pack_id UUID,
    owner_user_id UUID,
    monitor_id UUID,
    monitor_revision INTEGER,
    trigger_event_id UUID,
    diff_result_id UUID,
    pack_revision INTEGER,
    payload_hash TEXT,
    action_type TEXT,
    target_ref JSONB,
    consent_refs JSONB,
    provenance_refs JSONB,
    steps JSONB,
    expires_at TIMESTAMPTZ,
    idempotency_key TEXT,
    status TEXT,
    claimed_attempt_id UUID,
    created_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    RETURN QUERY
        SELECT * FROM public.mb13_p3_action_pack ap
        WHERE ap.owner_user_id = p_owner_user_id
          AND (p_status IS NULL OR ap.status = p_status)
        ORDER BY ap.created_at DESC
        LIMIT p_limit OFFSET p_offset;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_list_action_packs(UUID, TEXT, INTEGER, INTEGER) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_list_action_packs(UUID, TEXT, INTEGER, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_list_action_packs(UUID, TEXT, INTEGER, INTEGER) TO mb13_p3_api;

-- ----------------------------------------------------------------------------
-- 8. Revise action pack (pre-authorization)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_revise_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_action_type TEXT,
    p_target_ref JSONB,
    p_consent_refs JSONB,
    p_provenance_refs JSONB,
    p_steps JSONB,
    p_expires_at TIMESTAMPTZ
) RETURNS TABLE(
    pack_id UUID,
    owner_user_id UUID,
    monitor_id UUID,
    monitor_revision INTEGER,
    pack_revision INTEGER,
    payload_hash TEXT,
    action_type TEXT,
    status TEXT
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_new_revision INTEGER;
    v_payload_hash TEXT;
    v_policy_hash TEXT;
    v_old_status TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status IN ('claimed','executing','completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_cannot_revise';
    END IF;

    IF p_expires_at IS NOT NULL AND p_expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    v_old_status := v_pack.status;
    v_new_revision := v_pack.pack_revision + 1;
    v_payload_hash := public.mb13_p3_action_pack_payload_hash(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id, p_action_type,
        p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
        p_expires_at, v_pack.idempotency_key, 'proposed'
    );
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    UPDATE public.mb13_p3_action_pack
       SET pack_revision = v_new_revision,
           payload_hash = v_payload_hash,
           action_type = p_action_type,
           target_ref = COALESCE(p_target_ref, '{}'::jsonb),
           consent_refs = COALESCE(p_consent_refs, '[]'::jsonb),
           provenance_refs = COALESCE(p_provenance_refs, '[]'::jsonb),
           steps = COALESCE(p_steps, '[]'::jsonb),
           expires_at = p_expires_at,
           status = 'proposed',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    UPDATE public.mb13_p3_action_pack_authorization
       SET revoked = true
     WHERE pack_id = p_pack_id
       AND revoked = false;

    INSERT INTO public.mb13_p3_action_pack_revision (
        owner_user_id, pack_id, revision, monitor_revision, trigger_event_id, diff_result_id,
        payload_hash, action_type, target_ref, consent_refs, provenance_refs, steps,
        expires_at, idempotency_key, status, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, v_new_revision, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id, v_payload_hash, p_action_type,
        COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, v_pack.idempotency_key, 'proposed', v_now
    );

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'pack_revised', v_old_status, 'proposed',
        v_now, jsonb_build_object('pack_revision', v_new_revision),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.owner_user_id, ap.monitor_id, ap.monitor_revision,
                        ap.pack_revision, ap.payload_hash, ap.action_type, ap.status
                   FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ) TO mb13_p3_api;

-- ----------------------------------------------------------------------------
-- 9. Authorize action pack
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_authorize_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_expires_at TIMESTAMPTZ DEFAULT NULL
) RETURNS TABLE(
    pack_id UUID,
    owner_user_id UUID,
    status TEXT,
    pack_revision INTEGER,
    authorized_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_auth_expires TIMESTAMPTZ;
    v_policy_hash TEXT;
    v_auth_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status NOT IN ('draft','proposed','awaiting_confirmation') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_cannot_authorize';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    v_auth_expires := COALESCE(p_expires_at, v_pack.expires_at, v_now + interval '1 hour');
    IF v_auth_expires <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_authorization_expired';
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);
    v_auth_hash := public.mb13_p3_action_pack_auth_hash(
        p_pack_id, p_owner_user_id, v_pack.pack_revision, v_pack.monitor_revision, v_now, v_auth_expires
    );

    INSERT INTO public.mb13_p3_action_pack_authorization (
        owner_user_id, pack_id, pack_revision, authorized_at, expires_at, auth_payload_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.pack_revision, v_now, v_auth_expires, v_auth_hash
    )
    ON CONFLICT (pack_id) DO UPDATE SET
        pack_revision = EXCLUDED.pack_revision,
        authorized_at = EXCLUDED.authorized_at,
        expires_at = EXCLUDED.expires_at,
        auth_payload_hash = EXCLUDED.auth_payload_hash,
        revoked = false;

    UPDATE public.mb13_p3_action_pack
       SET status = 'authorized',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorized', v_pack.status, 'authorized',
        v_now, jsonb_build_object('pack_revision', v_pack.pack_revision, 'expires_at', v_auth_expires),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.owner_user_id, ap.status, ap.pack_revision, v_now, v_auth_expires
                   FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_authorize_action_pack(UUID, UUID, TIMESTAMPTZ) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_authorize_action_pack(UUID, UUID, TIMESTAMPTZ) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_authorize_action_pack(UUID, UUID, TIMESTAMPTZ) TO mb13_p3_api;

-- ----------------------------------------------------------------------------
-- 10. Cancel / revoke action pack
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_cancel_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID
) RETURNS TABLE(pack_id UUID, status TEXT) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status IN ('completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_already_terminal';
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    UPDATE public.mb13_p3_action_pack_authorization
       SET revoked = true
     WHERE pack_id = p_pack_id
       AND revoked = false;

    UPDATE public.mb13_p3_action_pack
       SET status = 'cancelled',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'cancelled', v_pack.status, 'cancelled',
        v_now, '{}'::jsonb, v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.status FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_cancel_action_pack(UUID, UUID) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_cancel_action_pack(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_cancel_action_pack(UUID, UUID) TO mb13_p3_api;

-- ----------------------------------------------------------------------------
-- 11. Executor claim action pack
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_claim_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_expected_pack_revision INTEGER,
    p_claim_nonce TEXT,
    p_idempotency_key TEXT,
    p_executor_identity TEXT DEFAULT NULL
) RETURNS TABLE(
    attempt_id UUID,
    pack_id UUID,
    attempt_number INTEGER,
    claim_nonce TEXT,
    status TEXT,
    created_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_existing public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
    v_attempt_number INTEGER;
    v_attempt_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_idempotency_key IS NULL OR length(COALESCE(p_idempotency_key, '')) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_idempotency_key_required';
    END IF;
    IF p_claim_nonce IS NULL OR length(COALESCE(p_claim_nonce, '')) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_claim_nonce_required';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    SELECT * INTO v_existing
      FROM public.mb13_p3_action_pack_attempt
     WHERE pack_id = p_pack_id
       AND idempotency_key = p_idempotency_key;
    IF FOUND THEN
        RETURN QUERY SELECT v_existing.attempt_id, v_existing.pack_id, v_existing.attempt_number,
                            v_existing.claim_nonce, v_existing.status, v_existing.created_at;
        RETURN;
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;

    IF v_pack.status IS DISTINCT FROM 'authorized' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_authorized';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    SELECT * INTO v_auth
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id;
    IF NOT FOUND OR v_auth.revoked = true OR v_auth.expires_at <= v_now OR v_auth.pack_revision IS DISTINCT FROM v_pack.pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_authorization_invalid';
    END IF;

    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);
    v_attempt_number := COALESCE((SELECT MAX(attempt_number) FROM public.mb13_p3_action_pack_attempt WHERE pack_id = p_pack_id), 0) + 1;

    INSERT INTO public.mb13_p3_action_pack_attempt (
        owner_user_id, pack_id, attempt_number, idempotency_key, claim_nonce,
        executor_identity, status, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, v_attempt_number, p_idempotency_key, p_claim_nonce,
        p_executor_identity, 'claimed', v_now
    ) RETURNING public.mb13_p3_action_pack_attempt.attempt_id INTO v_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = 'claimed',
           claimed_attempt_id = v_attempt_id,
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'claimed', 'authorized', 'claimed',
        v_now, jsonb_build_object('attempt_id', v_attempt_id, 'attempt_number', v_attempt_number, 'claim_nonce', p_claim_nonce),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt_id, p_pack_id, v_attempt_number, p_claim_nonce, 'claimed'::TEXT, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_claim_action_pack(UUID, UUID, INTEGER, TEXT, TEXT, TEXT) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_claim_action_pack(UUID, UUID, INTEGER, TEXT, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_claim_action_pack(UUID, UUID, INTEGER, TEXT, TEXT, TEXT) TO mb13_p3_executor;

-- ----------------------------------------------------------------------------
-- 12. Executor start action pack
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_start_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_expected_pack_revision INTEGER
) RETURNS TABLE(
    attempt_id UUID,
    pack_id UUID,
    attempt_number INTEGER,
    status TEXT,
    started_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;

    IF v_pack.status NOT IN ('claimed','executing') OR v_attempt.status IS DISTINCT FROM 'claimed' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_claimed';
    END IF;

    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    UPDATE public.mb13_p3_action_pack_attempt
       SET status = 'executing',
           started_at = v_now
     WHERE attempt_id = p_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = 'executing',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'started', 'claimed', 'executing',
        v_now, jsonb_build_object('attempt_id', p_attempt_id, 'attempt_number', v_attempt.attempt_number),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number, 'executing'::TEXT, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_start_action_pack(UUID, UUID, UUID, INTEGER) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_start_action_pack(UUID, UUID, UUID, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_start_action_pack(UUID, UUID, UUID, INTEGER) TO mb13_p3_executor;

-- ----------------------------------------------------------------------------
-- 13. Executor complete / fail action pack
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_complete_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_expected_pack_revision INTEGER,
    p_expected_attempt_number INTEGER,
    p_outcome TEXT,
    p_result_payload JSONB
) RETURNS TABLE(
    attempt_id UUID,
    pack_id UUID,
    attempt_number INTEGER,
    status TEXT,
    result_hash TEXT,
    completed_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
    v_result_hash TEXT;
    v_event_kind TEXT;
    v_old_status TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_outcome NOT IN ('completed','partial','failed') THEN
        RAISE EXCEPTION 'mb13_p3_invalid_outcome';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;

    IF v_attempt.attempt_number IS DISTINCT FROM p_expected_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;

    IF v_attempt.status = p_outcome OR v_attempt.status IN ('completed','partial','failed') THEN
        RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                            v_attempt.status, v_attempt.result_hash, v_attempt.completed_at;
        RETURN;
    END IF;

    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    v_result_hash := public.mb13_p0_hash_jsonb(COALESCE(p_result_payload, '{}'::jsonb));
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);
    v_event_kind := p_outcome;
    v_old_status := v_pack.status;

    UPDATE public.mb13_p3_action_pack_attempt
       SET status = p_outcome,
           result_payload = COALESCE(p_result_payload, '{}'::jsonb),
           result_hash = v_result_hash,
           completed_at = v_now
     WHERE attempt_id = p_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = p_outcome,
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, v_event_kind, 'executing', p_outcome,
        v_now, jsonb_build_object('attempt_id', p_attempt_id, 'attempt_number', v_attempt.attempt_number, 'result_hash', v_result_hash),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                        p_outcome::TEXT, v_result_hash, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) TO mb13_p3_executor;

-- ----------------------------------------------------------------------------
-- 14. Timeline and attempts read
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_get_action_pack_timeline(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_limit INTEGER DEFAULT 100,
    p_offset INTEGER DEFAULT 0
) RETURNS TABLE(
    timeline_event_id UUID,
    event_kind TEXT,
    from_state TEXT,
    to_state TEXT,
    event_time TIMESTAMPTZ,
    event_payload JSONB,
    payload_hash TEXT,
    monitor_revision INTEGER,
    policy_hash TEXT
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    RETURN QUERY
        SELECT t.timeline_event_id, t.event_kind, t.from_state, t.to_state,
               t.event_time, t.event_payload, t.payload_hash, t.monitor_revision, t.policy_hash
          FROM public.mb13_p3_action_pack_timeline t
         WHERE t.pack_id = p_pack_id
           AND t.owner_user_id = p_owner_user_id
         ORDER BY t.event_time DESC, t.timeline_event_id DESC
         LIMIT p_limit OFFSET p_offset;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_get_action_pack_timeline(UUID, UUID, INTEGER, INTEGER) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_get_action_pack_timeline(UUID, UUID, INTEGER, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_action_pack_timeline(UUID, UUID, INTEGER, INTEGER) TO mb13_p3_api;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_action_pack_timeline(UUID, UUID, INTEGER, INTEGER) TO mb13_p3_executor;

CREATE OR REPLACE FUNCTION public.mb13_p3_get_action_pack_attempts(
    p_owner_user_id UUID,
    p_pack_id UUID
) RETURNS TABLE(
    attempt_id UUID,
    attempt_number INTEGER,
    idempotency_key TEXT,
    claim_nonce TEXT,
    executor_identity TEXT,
    status TEXT,
    result_payload JSONB,
    result_hash TEXT,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    RETURN QUERY
        SELECT a.attempt_id, a.attempt_number, a.idempotency_key, a.claim_nonce,
               a.executor_identity, a.status, a.result_payload, a.result_hash,
               a.started_at, a.completed_at, a.created_at
          FROM public.mb13_p3_action_pack_attempt a
         WHERE a.pack_id = p_pack_id
           AND a.owner_user_id = p_owner_user_id
         ORDER BY a.created_at DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_get_action_pack_attempts(UUID, UUID) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_get_action_pack_attempts(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_action_pack_attempts(UUID, UUID) TO mb13_p3_api;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_action_pack_attempts(UUID, UUID) TO mb13_p3_executor;

-- ----------------------------------------------------------------------------
-- 15. Grant direct table access to writer only; API/executor use functions
-- ----------------------------------------------------------------------------
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p3_action_pack TO mb13_p3_writer;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p3_action_pack_revision TO mb13_p3_writer;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p3_action_pack_authorization TO mb13_p3_writer;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p3_action_pack_attempt TO mb13_p3_writer;
GRANT SELECT, INSERT ON public.mb13_p3_action_pack_timeline TO mb13_p3_writer;
REVOKE UPDATE, DELETE ON public.mb13_p3_action_pack_timeline FROM mb13_p3_writer;

REVOKE ALL ON public.mb13_p3_action_pack FROM PUBLIC;
REVOKE ALL ON public.mb13_p3_action_pack_revision FROM PUBLIC;
REVOKE ALL ON public.mb13_p3_action_pack_authorization FROM PUBLIC;
REVOKE ALL ON public.mb13_p3_action_pack_attempt FROM PUBLIC;
REVOKE ALL ON public.mb13_p3_action_pack_timeline FROM PUBLIC;

GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO mb13_p3_writer;

-- P3 writer needs access to referenced monitor/diff tables and shared hash utility.
GRANT SELECT, UPDATE ON public.mb13_p0_monitor_target TO mb13_p3_writer;
GRANT SELECT ON public.mb13_p0_monitor_event_ledger TO mb13_p3_writer;
GRANT SELECT ON public.mb13_p1_universal_diff TO mb13_p3_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p0_hash_jsonb(JSONB) TO mb13_p3_writer;

COMMIT;
