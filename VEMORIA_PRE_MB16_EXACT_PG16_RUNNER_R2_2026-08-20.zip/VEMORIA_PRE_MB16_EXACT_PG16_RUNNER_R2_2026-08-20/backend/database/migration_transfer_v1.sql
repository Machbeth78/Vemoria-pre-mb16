-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V4.6 — Transfer security migration
-- Aggiunge status 'downloaded' al vincolo della tabella transfer
-- Eseguire se la tabella transfer esiste già senza questo stato

DO $$
BEGIN
    -- Drop existing check constraint (PostgreSQL non supporta ALTER CONSTRAINT direttamente)
    ALTER TABLE transfer DROP CONSTRAINT IF EXISTS transfer_status_check;
    ALTER TABLE transfer DROP CONSTRAINT IF EXISTS transfer_status_chk;
    ALTER TABLE transfer ADD CONSTRAINT transfer_status_check
        CHECK (status IN ('pending', 'downloaded', 'received', 'expired'));
END $$;
