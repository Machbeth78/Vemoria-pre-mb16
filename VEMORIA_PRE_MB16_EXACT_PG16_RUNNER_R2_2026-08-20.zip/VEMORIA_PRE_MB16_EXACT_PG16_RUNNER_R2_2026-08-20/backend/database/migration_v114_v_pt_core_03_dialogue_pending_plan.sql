-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification,
-- distribution or use is prohibited.
--
-- migration_v114_v_pt_core_03_dialogue_pending_plan.sql
-- Laboratorio: Scrivania Conversazionale Ragionante Locale — V-PT-CORE-03
--
-- Una tabella additiva per persistere i piani conversazionali in attesa di
-- conferma utente. TTL morbido: il service ignora piani > 24h.
--
-- Privacy by design:
--   - summary_human può contenere LABEL (es. "Invio preventivo a Bianchi").
--     Sono dati dell'owner, mai esportati, mai loggati dal logger.
--   - actions/entities JSONB contengono SOLO id risorse (uuid) e tipi
--     azione; nessun testo grezzo dell'utente, nessuna trascrizione voce.
--   - FK CASCADE su utenti(id): cancellando l'utente sparisce ogni piano.
--
-- Idempotente: CREATE TABLE IF NOT EXISTS, CREATE INDEX IF NOT EXISTS.

BEGIN;

CREATE TABLE IF NOT EXISTS dialogue_pending_plan (
    id                      UUID         PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id               UUID         NOT NULL
                                         REFERENCES utenti(id) ON DELETE CASCADE,

    -- intent canonico unified_contracts (es. 'prepare_send', 'attach_to_dossier')
    canonical_intent        TEXT         NOT NULL,

    -- riassunto umano del piano, mostrato in UI (mai loggato)
    summary_human           TEXT         NOT NULL,

    -- sequenza di azioni operative da passare al LUISS action engine
    actions                 JSONB        NOT NULL DEFAULT '[]'::jsonb,

    -- entità risolte (documento_id, contatto_id, dossier_id, thread_id, ...)
    entities                JSONB        NOT NULL DEFAULT '{}'::jsonb,

    -- meta
    risk_level              TEXT         NOT NULL DEFAULT 'none'
                                         CHECK (risk_level IN (
                                             'none', 'low', 'medium', 'high'
                                         )),
    requires_confirmation   BOOLEAN      NOT NULL DEFAULT FALSE,

    -- ciclo di vita
    status                  TEXT         NOT NULL DEFAULT 'pending'
                                         CHECK (status IN (
                                             'pending', 'confirmed',
                                             'executed', 'cancelled'
                                         )),

    -- timestamps
    created_at              TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    consumed_at             TIMESTAMPTZ  NULL,
    expires_at              TIMESTAMPTZ  NOT NULL DEFAULT (NOW() + INTERVAL '24 hours')
);

-- Indice per lookup veloce dei pending per utente
CREATE INDEX IF NOT EXISTS idx_dialogue_pending_plan_owner_status
    ON dialogue_pending_plan(utente_id, status, created_at DESC);

-- Indice per cleanup dei pending scaduti
CREATE INDEX IF NOT EXISTS idx_dialogue_pending_plan_expires
    ON dialogue_pending_plan(expires_at)
    WHERE status = 'pending';

-- Commenti documentativi
COMMENT ON TABLE  dialogue_pending_plan IS
    'V-PT-CORE-03: piani conversazionali in attesa di conferma utente. TTL 24h.';
COMMENT ON COLUMN dialogue_pending_plan.summary_human IS
    'V-PT-CORE-03: testo italiano per UI, NON loggato (privacy).';
COMMENT ON COLUMN dialogue_pending_plan.actions IS
    'V-PT-CORE-03: sequenza azioni operative; passate al LUISS action engine.';
COMMENT ON COLUMN dialogue_pending_plan.entities IS
    'V-PT-CORE-03: id risorse risolte (UUID); nessun testo utente grezzo.';

COMMIT;
