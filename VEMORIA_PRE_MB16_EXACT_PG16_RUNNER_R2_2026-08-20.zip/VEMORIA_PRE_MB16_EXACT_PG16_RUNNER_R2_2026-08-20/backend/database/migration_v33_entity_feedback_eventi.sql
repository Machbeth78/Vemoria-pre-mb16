-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V33 — DEBORA: Entity evoluta + Feedback + Eventi
-- Sicura: ADD COLUMN IF NOT EXISTS, CREATE TABLE IF NOT EXISTS
-- Eseguire DOPO migration_v32_dati_forti.sql

-- ── 1. Estende tabella entity con dati scheda soggetto ───────────────────────
ALTER TABLE entity
    ADD COLUMN IF NOT EXISTS cognome        TEXT,
    ADD COLUMN IF NOT EXISTS denominazione  TEXT,
    ADD COLUMN IF NOT EXISTS email          TEXT,
    ADD COLUMN IF NOT EXISTS telefono       TEXT,
    ADD COLUMN IF NOT EXISTS indirizzo      TEXT,
    ADD COLUMN IF NOT EXISTS fonte_dato     TEXT DEFAULT 'documento',
    ADD COLUMN IF NOT EXISTS affidabilita   SMALLINT DEFAULT 50 CHECK (affidabilita BETWEEN 0 AND 100),
    ADD COLUMN IF NOT EXISTS updated_at     TIMESTAMP DEFAULT NOW();

-- Il campo "nome" esiste già nella tabella entity originale.
-- Rinominiamo semanticamente: per PERSONA = nome proprio, cognome separato.
-- Per AZIENDA = denominazione. Retrocompatibile.

CREATE INDEX IF NOT EXISTS idx_entity_email    ON entity (email)    WHERE email    IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_entity_telefono ON entity (telefono) WHERE telefono IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_entity_updated  ON entity (updated_at);

-- ── 2. Tabella entity_feedback (memoria scelte utente) ───────────────────────
CREATE TABLE IF NOT EXISTS entity_feedback (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id    UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    entity_id       UUID NOT NULL REFERENCES entity(id)   ON DELETE CASCADE,
    scelta_utente   BOOLEAN NOT NULL,   -- TRUE = confermato, FALSE = rifiutato
    tipo_match      TEXT,               -- 'forte' | 'medio' | 'debole'
    confidenza      FLOAT,
    creato_il       TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ef_documento ON entity_feedback (documento_id);
CREATE INDEX IF NOT EXISTS idx_ef_entity    ON entity_feedback (entity_id);
CREATE INDEX IF NOT EXISTS idx_ef_scelta    ON entity_feedback (scelta_utente);

-- ── 3. Tabella eventi_documento (scadenze, pagamenti, appuntamenti) ──────────
-- Separata da document_event (eventi UI) e da eventi_invio (dominio invio)
CREATE TABLE IF NOT EXISTS eventi_documento (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tipo_evento     TEXT NOT NULL,      -- 'SCADENZA' | 'PAGAMENTO' | 'APPUNTAMENTO'
    data_evento     DATE,
    importo         NUMERIC(15, 2),
    descrizione     TEXT,
    documento_id    UUID REFERENCES documenti(id)   ON DELETE SET NULL,
    entity_id       UUID REFERENCES entity(id)      ON DELETE SET NULL,
    utente_id       UUID REFERENCES utenti(id)      ON DELETE CASCADE,
    completato      BOOLEAN DEFAULT FALSE,
    fonte           TEXT DEFAULT 'auto',  -- 'auto' | 'manuale'
    creato_il       TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ev_documento  ON eventi_documento (documento_id) WHERE documento_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_ev_entity     ON eventi_documento (entity_id)    WHERE entity_id    IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_ev_utente     ON eventi_documento (utente_id);
CREATE INDEX IF NOT EXISTS idx_ev_data       ON eventi_documento (data_evento)  WHERE data_evento  IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_ev_tipo       ON eventi_documento (tipo_evento);
