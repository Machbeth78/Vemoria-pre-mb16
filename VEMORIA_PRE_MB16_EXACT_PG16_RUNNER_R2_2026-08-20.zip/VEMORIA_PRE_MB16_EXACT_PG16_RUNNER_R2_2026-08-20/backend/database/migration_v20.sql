-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V3.9 — Migration V20 — Security System
CREATE TABLE IF NOT EXISTS security_log (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tipo_evento TEXT NOT NULL,
    target_tipo TEXT,
    target_id   UUID,
    descrizione TEXT,
    creato_il   TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_seclog_tipo    ON security_log(tipo_evento);
CREATE INDEX IF NOT EXISTS idx_seclog_target  ON security_log(target_tipo, target_id);
CREATE INDEX IF NOT EXISTS idx_seclog_data    ON security_log(creato_il DESC);
