-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA Migration V51
-- ECO Premium foundation
--
-- Obiettivo:
-- creare il layer persistente minimo di ECO come linea autonoma del vocale,
-- separata da Radar/Prisma/Sentinella ma leggibile da Control Room in futuro.

CREATE TABLE IF NOT EXISTS eco_sessions (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NULL REFERENCES utenti(id) ON DELETE CASCADE,
    current_screen      TEXT,
    target_tipo         TEXT,
    target_id           TEXT,
    session_lock_key    TEXT,
    session_state       TEXT NOT NULL DEFAULT 'active' CHECK (session_state IN ('active', 'paused', 'closed')),
    runtime_locale      TEXT,
    runtime_country     TEXT,
    source              TEXT NOT NULL DEFAULT 'voice_router',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at           TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_eco_sessions_user ON eco_sessions(utente_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_sessions_lock ON eco_sessions(session_lock_key);

CREATE TABLE IF NOT EXISTS eco_utterances (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id              UUID NOT NULL REFERENCES eco_sessions(id) ON DELETE CASCADE,
    seq_no                  INTEGER NOT NULL,
    raw_text                TEXT NOT NULL,
    normalized_text         TEXT,
    corrected_text          TEXT,
    recognized_command      TEXT,
    recognized_parameter    TEXT,
    recognized_confidence   REAL NOT NULL DEFAULT 0.0,
    protected_matches       JSONB NOT NULL DEFAULT '[]'::jsonb,
    context_snapshot        JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (session_id, seq_no)
);
CREATE INDEX IF NOT EXISTS idx_eco_utterances_session ON eco_utterances(session_id, seq_no DESC);

CREATE TABLE IF NOT EXISTS eco_phonetic_variants (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    canonical_term      TEXT NOT NULL,
    heard_variant       TEXT NOT NULL,
    phonetic_key        TEXT,
    context_scope       TEXT NOT NULL DEFAULT '',
    evidence_count      INTEGER NOT NULL DEFAULT 1,
    trust_level         TEXT NOT NULL DEFAULT 'candidate' CHECK (trust_level IN ('candidate', 'reinforced', 'stable', 'protected')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_eco_phonetic_variant
    ON eco_phonetic_variants (utente_id, canonical_term, heard_variant, context_scope);
CREATE INDEX IF NOT EXISTS idx_eco_phonetic_user ON eco_phonetic_variants(utente_id, evidence_count DESC);

CREATE TABLE IF NOT EXISTS eco_disambiguation_cases (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    selected_value          TEXT,
    selected_type           TEXT,
    candidates_json         JSONB NOT NULL DEFAULT '[]'::jsonb,
    risk_level              TEXT NOT NULL DEFAULT 'low' CHECK (risk_level IN ('low', 'medium', 'high')),
    requires_confirmation   BOOLEAN NOT NULL DEFAULT FALSE,
    reason_codes            JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_disambiguation_utterance ON eco_disambiguation_cases(utterance_id);

CREATE TABLE IF NOT EXISTS eco_intent_packets (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    intent_name             TEXT NOT NULL,
    action_code             TEXT NOT NULL,
    target_entities_json    JSONB NOT NULL DEFAULT '[]'::jsonb,
    temporal_scope_json     JSONB NOT NULL DEFAULT '{}'::jsonb,
    confidence_global       REAL NOT NULL DEFAULT 0.0,
    risk_level              TEXT NOT NULL DEFAULT 'low' CHECK (risk_level IN ('low', 'medium', 'high')),
    requires_confirmation   BOOLEAN NOT NULL DEFAULT FALSE,
    explanation_short       TEXT,
    luiss_bridge_status     TEXT NOT NULL DEFAULT 'pending',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_intent_utterance ON eco_intent_packets(utterance_id);
CREATE INDEX IF NOT EXISTS idx_eco_intent_action ON eco_intent_packets(action_code, created_at DESC);
