-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V4.6 — Migration V30 — campi profilo utente
ALTER TABLE utenti
    ADD COLUMN IF NOT EXISTS avatar_path  TEXT,
    ADD COLUMN IF NOT EXISTS stato        TEXT,
    ADD COLUMN IF NOT EXISTS telefono     TEXT;
