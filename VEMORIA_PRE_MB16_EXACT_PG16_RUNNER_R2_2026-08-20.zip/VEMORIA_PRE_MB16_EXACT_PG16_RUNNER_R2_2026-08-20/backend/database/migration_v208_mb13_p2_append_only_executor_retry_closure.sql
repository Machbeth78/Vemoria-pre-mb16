-- VEMORA — Migration v208
-- MB13-P2 — Append-only timeline, dedicated executor retry closure,
-- mandatory expected_retry_count, monitor-first locking for cancel/fire/advance,
-- immutable timeline trigger with canonical provenance hash.
-- forward-only, idempotent
BEGIN;

-- ----------------------------------------------------------------------------
-- 1. Timeline append-only privileges
-- ----------------------------------------------------------------------------
REVOKE ALL ON public.mb13_p2_monitor_timeline FROM mb13_p2_writer;
GRANT SELECT, INSERT ON public.mb13_p2_monitor_timeline TO mb13_p2_writer;

-- ----------------------------------------------------------------------------
-- 2. Immutable timeline trigger with canonical provenance hash
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_monitor_timeline_immutable()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        NEW.payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', NEW.owner_user_id,
            'monitor_id', NEW.monitor_id,
            'event_kind', NEW.event_kind,
            'from_state', NEW.from_state,
            'to_state', NEW.to_state,
            'event_time', NEW.event_time,
            'event_payload', NEW.event_payload,
            'monitor_revision', NEW.monitor_revision,
            'policy_hash', NEW.policy_hash
        ));
        RETURN NEW;
    END IF;
    RAISE EXCEPTION 'mb13_p2_timeline_immutable: % on timeline is forbidden', TG_OP
        USING ERRCODE = 'P2IMM';
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_monitor_timeline_immutable() OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_monitor_timeline_immutable() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_monitor_timeline_immutable() TO mb13_p2_writer;

DROP TRIGGER IF EXISTS trg_mb13_p2_monitor_timeline_immutable ON public.mb13_p2_monitor_timeline;
CREATE TRIGGER trg_mb13_p2_monitor_timeline_immutable
    BEFORE INSERT OR UPDATE OR DELETE ON public.mb13_p2_monitor_timeline
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p2_monitor_timeline_immutable();

-- ----------------------------------------------------------------------------
-- 3. Advance retry: mandatory expected_retry_count, monitor-first lock
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN);
DROP FUNCTION IF EXISTS public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN, INTEGER);

CREATE OR REPLACE FUNCTION public.mb13_p2_advance_retry(
    p_owner_user_id UUID,
    p_retry_id UUID,
    p_success BOOLEAN,
    p_expected_retry_count INTEGER
) RETURNS TABLE(
    retry_id UUID,
    monitor_id UUID,
    status TEXT,
    retry_count INTEGER,
    next_retry_at TIMESTAMPTZ,
    executed_at TIMESTAMPTZ
) AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_retry public.mb13_p2_retry_schedule%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_next_at TIMESTAMPTZ;
    v_new_count INTEGER;
    v_interval INTERVAL;
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;
    IF p_expected_retry_count IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_retry_expected_count_required';
    END IF;

    -- Deterministic lock order: canonical monitor target first, then retry.
    SELECT t.* INTO v_monitor
      FROM public.mb13_p0_monitor_target t
      JOIN public.mb13_p2_retry_schedule rz ON t.monitor_id = rz.monitor_id
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id
       AND t.owner_user_id = p_owner_user_id
     FOR UPDATE OF t;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_retry_not_found';
    END IF;

    SELECT * INTO v_retry
      FROM public.mb13_p2_retry_schedule rz
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_retry_not_found';
    END IF;
    IF v_retry.status <> 'pending' THEN
        RAISE EXCEPTION 'mb13_p2_retry_not_pending';
    END IF;
    IF v_retry.next_retry_at > v_now THEN
        RAISE EXCEPTION 'mb13_p2_retry_too_early';
    END IF;
    IF v_retry.retry_count IS DISTINCT FROM p_expected_retry_count THEN
        RAISE EXCEPTION 'mb13_p2_retry_concurrent_or_stale';
    END IF;

    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    IF p_success THEN
        UPDATE public.mb13_p2_retry_schedule rz
           SET status = 'completed',
               last_fired_at = v_now
         WHERE rz.owner_user_id = p_owner_user_id
           AND rz.retry_id = p_retry_id;

        INSERT INTO public.mb13_p2_monitor_timeline (
            owner_user_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, payload_hash, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, v_retry.monitor_id, 'retry_completed', 'pending', 'completed',
            v_now, jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_retry.retry_count, 'success', true),
            public.mb13_p0_hash_jsonb(jsonb_build_object(
                'owner_user_id', p_owner_user_id,
                'monitor_id', v_retry.monitor_id,
                'event_kind', 'retry_completed',
                'from_state', 'pending',
                'to_state', 'completed',
                'event_time', v_now,
                'event_payload', jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_retry.retry_count, 'success', true)
            )),
            v_monitor_revision, v_policy_hash
        );

        RETURN QUERY SELECT p_retry_id, v_retry.monitor_id, 'completed'::TEXT, v_retry.retry_count, v_retry.next_retry_at, v_now;
        RETURN;
    END IF;

    v_new_count := v_retry.retry_count + 1;
    IF v_new_count >= v_retry.max_retries THEN
        UPDATE public.mb13_p2_retry_schedule rz
           SET status = 'expired',
               retry_count = v_new_count,
               last_fired_at = v_now
         WHERE rz.owner_user_id = p_owner_user_id
           AND rz.retry_id = p_retry_id;

        INSERT INTO public.mb13_p2_monitor_timeline (
            owner_user_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, payload_hash, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, v_retry.monitor_id, 'retry_expired', 'pending', 'expired',
            v_now, jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_new_count, 'success', false),
            public.mb13_p0_hash_jsonb(jsonb_build_object(
                'owner_user_id', p_owner_user_id,
                'monitor_id', v_retry.monitor_id,
                'event_kind', 'retry_expired',
                'from_state', 'pending',
                'to_state', 'expired',
                'event_time', v_now,
                'event_payload', jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_new_count, 'success', false)
            )),
            v_monitor_revision, v_policy_hash
        );

        RETURN QUERY SELECT p_retry_id, v_retry.monitor_id, 'expired'::TEXT, v_new_count, v_retry.next_retry_at, v_now;
        RETURN;
    END IF;

    IF v_retry.backoff_kind = 'fixed' THEN
        v_interval := '1 minute'::INTERVAL;
    ELSIF v_retry.backoff_kind = 'linear' THEN
        v_interval := (v_new_count * '1 minute'::INTERVAL);
    ELSIF v_retry.backoff_kind = 'exponential' THEN
        v_interval := (POWER(2, v_new_count)::INTEGER * '1 minute'::INTERVAL);
    ELSE
        v_interval := '0 minutes'::INTERVAL;
    END IF;

    v_next_at := v_now + v_interval;

    UPDATE public.mb13_p2_retry_schedule rz
       SET retry_count = v_new_count,
           next_retry_at = v_next_at,
           last_fired_at = v_now
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id;

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_retry.monitor_id, 'retry_fired', 'pending', 'pending',
        v_now, jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_new_count, 'success', false, 'next_retry_at', v_next_at),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', v_retry.monitor_id,
            'event_kind', 'retry_fired',
            'from_state', 'pending',
            'to_state', 'pending',
            'event_time', v_now,
            'event_payload', jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_new_count, 'success', false, 'next_retry_at', v_next_at)
        )),
        v_monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT p_retry_id, v_retry.monitor_id, 'pending'::TEXT, v_new_count, v_next_at, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN, INTEGER) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN, INTEGER) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- 4. Schedule retry: no UPDATE lock on timeline, rely on partial unique index
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_schedule_retry(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_original_event_id UUID,
    p_next_retry_at TIMESTAMPTZ,
    p_max_retries INTEGER DEFAULT 3,
    p_backoff_kind TEXT DEFAULT 'exponential',
    p_last_error_payload JSONB DEFAULT '{}'::jsonb,
    p_immediate BOOLEAN DEFAULT FALSE
) RETURNS UUID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_retry_id UUID := gen_random_uuid();
    v_now TIMESTAMPTZ := clock_timestamp();
    v_effective_next_at TIMESTAMPTZ;
    v_original public.mb13_p2_monitor_timeline%ROWTYPE;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
    v_entity_kind TEXT;
    v_reminder_id UUID;
    v_retry_ref_id UUID;
    v_reminder_status TEXT;
    v_retry_status TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;
    IF p_next_retry_at IS NULL AND NOT p_immediate THEN
        RAISE EXCEPTION 'mb13_p2_retry_time_invalid';
    END IF;
    IF p_immediate THEN
        v_effective_next_at := v_now;
    ELSE
        IF p_next_retry_at < v_now THEN
            RAISE EXCEPTION 'mb13_p2_retry_time_obsolete';
        END IF;
        v_effective_next_at := p_next_retry_at;
    END IF;
    IF p_max_retries < 1 OR p_max_retries > 20 THEN
        RAISE EXCEPTION 'mb13_p2_retry_max_invalid';
    END IF;
    IF p_backoff_kind NOT IN ('fixed','exponential','linear','none') THEN
        RAISE EXCEPTION 'mb13_p2_retry_backoff_invalid';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = p_owner_user_id
       AND t.monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_monitor_not_found';
    END IF;

    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    IF p_original_event_id IS NOT NULL THEN
        SELECT * INTO v_original
          FROM public.mb13_p2_monitor_timeline t
         WHERE t.timeline_event_id = p_original_event_id
           AND t.owner_user_id = p_owner_user_id
           AND t.monitor_id = p_monitor_id;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p2_original_event_not_found';
        END IF;

        v_entity_kind := v_original.event_kind;
        IF v_entity_kind IN ('completed','expired','retry_completed','retry_expired','retry_cancelled','reminder_cancelled') THEN
            RAISE EXCEPTION 'mb13_p2_original_event_not_retryable';
        END IF;

        IF v_entity_kind LIKE 'reminder_%' THEN
            v_reminder_id := (v_original.event_payload->>'reminder_id')::UUID;
            SELECT status INTO v_reminder_status
              FROM public.mb13_p2_reminder_schedule r
             WHERE r.reminder_id = v_reminder_id
               AND r.owner_user_id = p_owner_user_id
               AND r.monitor_id = p_monitor_id
             FOR UPDATE;
            IF NOT FOUND OR v_reminder_status IN ('cancelled','dispatched') THEN
                RAISE EXCEPTION 'mb13_p2_original_event_not_retryable';
            END IF;
        ELSIF v_entity_kind LIKE 'retry_%' THEN
            v_retry_ref_id := (v_original.event_payload->>'retry_id')::UUID;
            SELECT status INTO v_retry_status
              FROM public.mb13_p2_retry_schedule rz
             WHERE rz.retry_id = v_retry_ref_id
               AND rz.owner_user_id = p_owner_user_id
               AND rz.monitor_id = p_monitor_id
             FOR UPDATE;
            IF NOT FOUND OR v_retry_status IN ('cancelled','completed','expired') THEN
                RAISE EXCEPTION 'mb13_p2_original_event_not_retryable';
            END IF;
        END IF;
    END IF;

    INSERT INTO public.mb13_p2_retry_schedule (
        retry_id, owner_user_id, monitor_id, original_event_id, retry_count,
        max_retries, next_retry_at, backoff_kind, status, last_error_payload
    ) VALUES (
        v_retry_id, p_owner_user_id, p_monitor_id, p_original_event_id, 0,
        p_max_retries, v_effective_next_at, p_backoff_kind, 'pending', COALESCE(p_last_error_payload, '{}'::jsonb)
    );

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_monitor_id, 'retry_scheduled', NULL, NULL,
        v_now, jsonb_build_object('retry_id', v_retry_id, 'max_retries', p_max_retries, 'backoff_kind', p_backoff_kind, 'original_event_id', p_original_event_id, 'next_retry_at', v_effective_next_at, 'immediate', p_immediate),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', p_monitor_id,
            'event_kind', 'retry_scheduled',
            'from_state', NULL,
            'to_state', NULL,
            'event_time', v_now,
            'event_payload', jsonb_build_object('retry_id', v_retry_id, 'max_retries', p_max_retries, 'backoff_kind', p_backoff_kind, 'original_event_id', p_original_event_id, 'next_retry_at', v_effective_next_at, 'immediate', p_immediate)
        )),
        v_monitor_revision, v_policy_hash
    );

    RETURN v_retry_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB, BOOLEAN) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB, BOOLEAN) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB, BOOLEAN) TO mb13_p2_api;

-- ----------------------------------------------------------------------------
-- 5. Fire reminder: monitor-first lock
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_fire_reminder(
    p_owner_user_id UUID,
    p_reminder_id UUID,
    p_success BOOLEAN DEFAULT TRUE
) RETURNS TABLE(
    reminder_id UUID,
    monitor_id UUID,
    status TEXT,
    dispatched_at TIMESTAMPTZ
) AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_reminder public.mb13_p2_reminder_schedule%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_new_status TEXT;
    v_event_kind TEXT;
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    -- Deterministic lock order: canonical monitor target first, then reminder.
    SELECT t.* INTO v_monitor
      FROM public.mb13_p0_monitor_target t
      JOIN public.mb13_p2_reminder_schedule r ON t.monitor_id = r.monitor_id
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id
       AND t.owner_user_id = p_owner_user_id
     FOR UPDATE OF t;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_reminder_not_found';
    END IF;

    SELECT * INTO v_reminder
      FROM public.mb13_p2_reminder_schedule r
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_reminder_not_found';
    END IF;
    IF v_reminder.status <> 'pending' THEN
        RAISE EXCEPTION 'mb13_p2_reminder_already_handled';
    END IF;
    IF v_reminder.remind_at > v_now THEN
        RAISE EXCEPTION 'mb13_p2_reminder_too_early';
    END IF;

    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    IF p_success THEN
        v_new_status := 'dispatched';
        v_event_kind := 'reminder_dispatched';
    ELSE
        v_new_status := 'failed';
        v_event_kind := 'reminder_failed';
    END IF;

    UPDATE public.mb13_p2_reminder_schedule r
       SET status = v_new_status,
           dispatched_at = v_now
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id;

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_reminder.monitor_id, v_event_kind, 'pending', v_new_status,
        v_now,
        jsonb_build_object('reminder_id', p_reminder_id, 'reminder_kind', v_reminder.reminder_kind, 'channel', v_reminder.channel, 'success', p_success),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', v_reminder.monitor_id,
            'event_kind', v_event_kind,
            'from_state', 'pending',
            'to_state', v_new_status,
            'event_time', v_now,
            'event_payload', jsonb_build_object('reminder_id', p_reminder_id, 'reminder_kind', v_reminder.reminder_kind, 'channel', v_reminder.channel, 'success', p_success)
        )),
        v_monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT p_reminder_id, v_reminder.monitor_id, v_new_status, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_fire_reminder(UUID, UUID, BOOLEAN) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_fire_reminder(UUID, UUID, BOOLEAN) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_fire_reminder(UUID, UUID, BOOLEAN) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- 5. Cancel reminder: monitor-first lock and provenance
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_cancel_reminder(
    p_owner_user_id UUID,
    p_reminder_id UUID
) RETURNS VOID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_reminder public.mb13_p2_reminder_schedule%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    -- Deterministic lock order: canonical monitor target first, then reminder.
    SELECT t.* INTO v_monitor
      FROM public.mb13_p0_monitor_target t
      JOIN public.mb13_p2_reminder_schedule r ON t.monitor_id = r.monitor_id
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id
       AND t.owner_user_id = p_owner_user_id
     FOR UPDATE OF t;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_reminder_not_found';
    END IF;

    SELECT * INTO v_reminder
      FROM public.mb13_p2_reminder_schedule r
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_reminder_not_found';
    END IF;
    IF v_reminder.status NOT IN ('pending','dispatched') THEN
        RAISE EXCEPTION 'mb13_p2_reminder_cannot_cancel';
    END IF;

    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    UPDATE public.mb13_p2_reminder_schedule r
       SET status = 'cancelled'
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id;

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_reminder.monitor_id, 'reminder_cancelled', v_reminder.status, 'cancelled',
        v_now, jsonb_build_object('reminder_id', p_reminder_id),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', v_reminder.monitor_id,
            'event_kind', 'reminder_cancelled',
            'from_state', v_reminder.status,
            'to_state', 'cancelled',
            'event_time', v_now,
            'event_payload', jsonb_build_object('reminder_id', p_reminder_id)
        )),
        v_monitor_revision, v_policy_hash
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- 6. Cancel retry: monitor-first lock and provenance
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_cancel_retry(
    p_owner_user_id UUID,
    p_retry_id UUID
) RETURNS VOID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_retry public.mb13_p2_retry_schedule%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    -- Deterministic lock order: canonical monitor target first, then retry.
    SELECT t.* INTO v_monitor
      FROM public.mb13_p0_monitor_target t
      JOIN public.mb13_p2_retry_schedule rz ON t.monitor_id = rz.monitor_id
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id
       AND t.owner_user_id = p_owner_user_id
     FOR UPDATE OF t;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_retry_not_found';
    END IF;

    SELECT * INTO v_retry
      FROM public.mb13_p2_retry_schedule rz
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_retry_not_found';
    END IF;
    IF v_retry.status NOT IN ('pending') THEN
        RAISE EXCEPTION 'mb13_p2_retry_cannot_cancel';
    END IF;

    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    UPDATE public.mb13_p2_retry_schedule rz
       SET status = 'cancelled'
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id;

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_retry.monitor_id, 'retry_cancelled', 'pending', 'cancelled',
        v_now, jsonb_build_object('retry_id', p_retry_id),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', v_retry.monitor_id,
            'event_kind', 'retry_cancelled',
            'from_state', 'pending',
            'to_state', 'cancelled',
            'event_time', v_now,
            'event_payload', jsonb_build_object('retry_id', p_retry_id)
        )),
        v_monitor_revision, v_policy_hash
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) TO mb13_p2_executor;

COMMIT;
