-- ============================================================
-- VEMORA — Schema PostgreSQL Completo
-- Ideatore: Devoti Massimo
-- Generato da: architettura FROZEN V1
-- ============================================================

-- Estensione UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- TABELLA: utenti
-- ============================================================
CREATE TABLE utenti (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome            TEXT NOT NULL,
    email           TEXT NOT NULL UNIQUE,
    password_hash   TEXT NOT NULL,
    creato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    attivo          BOOLEAN NOT NULL DEFAULT TRUE
);

-- ============================================================
-- TABELLA: tipi_documento
-- Libreria modelli — popolata al bootstrap
-- ============================================================
CREATE TABLE tipi_documento (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    codice      TEXT NOT NULL UNIQUE,   -- es: "fattura", "contratto", "generico"
    etichetta   TEXT NOT NULL,          -- es: "Fattura", "Contratto"
    categoria   TEXT NOT NULL,          -- es: "finanziario", "legale", "sanitario"
    attivo      BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABELLA: documenti
-- Documento fisico ricevuto dal sistema
-- ============================================================
CREATE TABLE documenti (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    proprietario_id         UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    nome_file_originale     TEXT NOT NULL,
    stato_elaborazione      TEXT NOT NULL DEFAULT 'ricevuto',
                            -- ricevuto | in_acquisizione | in_comprensione
                            -- in_costruzione | in_qualita | memorizzato
                            -- in_errore | in_attesa_utente
    tipo_documento_id       UUID REFERENCES tipi_documento(id),
    percorso_storage        TEXT,           -- path relativo in originali/
    hash_file               TEXT,           -- SHA-256 del file originale
    testo_grezzo            TEXT,           -- testo estratto dall'OCR
    lingua_rilevata         TEXT,           -- codice ISO 639-1 es: "it"
    tentativi_correnti      INTEGER NOT NULL DEFAULT 0,
    dati_strutturati        JSONB,          -- PacchettoDocumento serializzato
    creato_il               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_documenti_proprietario    ON documenti(proprietario_id);
CREATE INDEX idx_documenti_stato           ON documenti(stato_elaborazione);
CREATE INDEX idx_documenti_tipo            ON documenti(tipo_documento_id);
CREATE INDEX idx_documenti_aggiornato      ON documenti(aggiornato_il DESC);

-- ============================================================
-- TABELLA: memorie
-- Memoria strutturata e approvata dalla pipeline
-- ============================================================
CREATE TABLE memorie (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    proprietario_id         UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    documento_sorgente_id   UUID REFERENCES documenti(id) ON DELETE SET NULL,

    -- Contenuto principale
    titolo                  TEXT NOT NULL,
    riassunto               TEXT,
    testo_completo          TEXT,

    -- Classificazione
    tipo_documento          TEXT NOT NULL DEFAULT 'generico',
    categoria_documento     TEXT NOT NULL DEFAULT 'generico',
    sottocategoria          TEXT,
    codice_lingua           TEXT NOT NULL DEFAULT 'it',

    -- Qualità
    score_qualita           REAL NOT NULL DEFAULT 0.0,
    livello_affidabilita    REAL NOT NULL DEFAULT 0.0,
    approvata_con_riserva   BOOLEAN NOT NULL DEFAULT FALSE,

    -- Dati strutturati (entità, metadati, qualità)
    dati_strutturati        JSONB,
    metadati_ricerca        JSONB,

    -- Stato
    stato                   TEXT NOT NULL DEFAULT 'attiva',
                            -- attiva | archiviata | eliminata
    versione                INTEGER NOT NULL DEFAULT 1,

    creata_il               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    confermata_il           TIMESTAMPTZ
);

CREATE INDEX idx_memorie_proprietario      ON memorie(proprietario_id);
CREATE INDEX idx_memorie_tipo              ON memorie(tipo_documento);
CREATE INDEX idx_memorie_categoria         ON memorie(categoria_documento);
CREATE INDEX idx_memorie_stato             ON memorie(stato);
CREATE INDEX idx_memorie_creata            ON memorie(creata_il DESC);
CREATE INDEX idx_memorie_documento_src     ON memorie(documento_sorgente_id);

-- Ricerca full-text sul titolo e riassunto
CREATE INDEX idx_memorie_fts ON memorie
    USING GIN (to_tsvector('italian', coalesce(titolo,'') || ' ' || coalesce(riassunto,'')));

-- ============================================================
-- TABELLA: cronologia_eventi
-- Log immutabile di ogni step della pipeline
-- ============================================================
CREATE TABLE cronologia_eventi (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id        UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    nome_camera         TEXT NOT NULL,
    tipo_evento         TEXT NOT NULL,
    numero_tentativo    INTEGER NOT NULL DEFAULT 1,
    dati_evento         JSONB,
    messaggio_errore    TEXT,
    timestamp           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_cronologia_documento  ON cronologia_eventi(documento_id);
CREATE INDEX idx_cronologia_timestamp  ON cronologia_eventi(timestamp DESC);
CREATE INDEX idx_cronologia_camera     ON cronologia_eventi(nome_camera);

-- ============================================================
-- TABELLA: problemi
-- Documenti che la pipeline non è riuscita a gestire
-- ============================================================
CREATE TABLE problemi (
    id                          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id                UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    camera_origine              TEXT NOT NULL,
    tipo_problema               TEXT NOT NULL,
    motivazione_principale      TEXT,
    dettaglio_tecnico           TEXT,
    tentativi_effettuati        INTEGER NOT NULL DEFAULT 0,
    richiede_intervento_utente  BOOLEAN NOT NULL DEFAULT FALSE,
    risolto                     BOOLEAN NOT NULL DEFAULT FALSE,
    creato_il                   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    risolto_il                  TIMESTAMPTZ
);

CREATE INDEX idx_problemi_documento    ON problemi(documento_id);
CREATE INDEX idx_problemi_risolto      ON problemi(risolto);

-- ============================================================
-- TABELLA: identita_digitale
-- Impronta SHA-256 verificabile di ogni documento
-- ============================================================
CREATE TABLE identita_digitale (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id        UUID NOT NULL UNIQUE REFERENCES documenti(id) ON DELETE CASCADE,
    hash_documento      TEXT NOT NULL,
    percorso_file       TEXT NOT NULL,
    stato_identita      TEXT NOT NULL DEFAULT 'attiva',
                        -- attiva | revocata | aggiornata
    versione_identita   TEXT NOT NULL DEFAULT '1.0',
    firma_identita      TEXT,           -- placeholder per V2
    metadati            JSONB,
    creata_il           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_identita_documento ON identita_digitale(documento_id);
CREATE INDEX idx_identita_stato     ON identita_digitale(stato_identita);

-- ============================================================
-- DATI INIZIALI: tipi_documento (Libreria Modelli)
-- ============================================================
INSERT INTO tipi_documento (codice, etichetta, categoria) VALUES
    ('fattura',         'Fattura',              'finanziario'),
    ('ricevuta',        'Ricevuta',             'finanziario'),
    ('contratto',       'Contratto',            'legale'),
    ('lettera',         'Lettera',              'corrispondenza'),
    ('referto_medico',  'Referto Medico',       'sanitario'),
    ('preventivo',      'Preventivo',           'finanziario'),
    ('verbale',         'Verbale',              'legale'),
    ('certificato',     'Certificato',          'ufficiale'),
    ('generico',        'Documento Generico',   'generico');

-- ============================================================
-- FUNZIONE: aggiorna aggiornato_il automaticamente
-- ============================================================
CREATE OR REPLACE FUNCTION aggiorna_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.aggiornato_il = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_documenti_aggiornato
    BEFORE UPDATE ON documenti
    FOR EACH ROW EXECUTE FUNCTION aggiorna_timestamp();

CREATE TRIGGER trigger_memorie_aggiornato
    BEFORE UPDATE ON memorie
    FOR EACH ROW EXECUTE FUNCTION aggiorna_timestamp();

-- ============================================================
-- MIGRAZIONE: migration_v51_eco_premium.sql
-- ============================================================
-- VEMORA Migration V51
-- ECO Premium foundation
--
-- Obiettivo:
-- creare il layer persistente minimo di ECO come linea autonoma del vocale,
-- separata da Radar/Prisma/Sentinella ma leggibile da Control Room in futuro.

CREATE TABLE IF NOT EXISTS eco_sessions (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NULL REFERENCES utenti(id) ON DELETE CASCADE,
    current_screen      TEXT,
    target_tipo         TEXT,
    target_id           TEXT,
    session_lock_key    TEXT,
    session_state       TEXT NOT NULL DEFAULT 'active' CHECK (session_state IN ('active', 'paused', 'closed')),
    runtime_locale      TEXT,
    runtime_country     TEXT,
    source              TEXT NOT NULL DEFAULT 'voice_router',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at           TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_eco_sessions_user ON eco_sessions(utente_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_sessions_lock ON eco_sessions(session_lock_key);

CREATE TABLE IF NOT EXISTS eco_utterances (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id              UUID NOT NULL REFERENCES eco_sessions(id) ON DELETE CASCADE,
    seq_no                  INTEGER NOT NULL,
    raw_text                TEXT NOT NULL,
    normalized_text         TEXT,
    corrected_text          TEXT,
    recognized_command      TEXT,
    recognized_parameter    TEXT,
    recognized_confidence   REAL NOT NULL DEFAULT 0.0,
    protected_matches       JSONB NOT NULL DEFAULT '[]'::jsonb,
    context_snapshot        JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (session_id, seq_no)
);
CREATE INDEX IF NOT EXISTS idx_eco_utterances_session ON eco_utterances(session_id, seq_no DESC);

CREATE TABLE IF NOT EXISTS eco_phonetic_variants (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    canonical_term      TEXT NOT NULL,
    heard_variant       TEXT NOT NULL,
    phonetic_key        TEXT,
    context_scope       TEXT NOT NULL DEFAULT '',
    evidence_count      INTEGER NOT NULL DEFAULT 1,
    trust_level         TEXT NOT NULL DEFAULT 'candidate' CHECK (trust_level IN ('candidate', 'reinforced', 'stable', 'protected')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_eco_phonetic_variant
    ON eco_phonetic_variants (utente_id, canonical_term, heard_variant, context_scope);
CREATE INDEX IF NOT EXISTS idx_eco_phonetic_user ON eco_phonetic_variants(utente_id, evidence_count DESC);

CREATE TABLE IF NOT EXISTS eco_disambiguation_cases (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    selected_value          TEXT,
    selected_type           TEXT,
    candidates_json         JSONB NOT NULL DEFAULT '[]'::jsonb,
    risk_level              TEXT NOT NULL DEFAULT 'low' CHECK (risk_level IN ('low', 'medium', 'high')),
    requires_confirmation   BOOLEAN NOT NULL DEFAULT FALSE,
    reason_codes            JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_disambiguation_utterance ON eco_disambiguation_cases(utterance_id);

CREATE TABLE IF NOT EXISTS eco_intent_packets (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    intent_name             TEXT NOT NULL,
    action_code             TEXT NOT NULL,
    target_entities_json    JSONB NOT NULL DEFAULT '[]'::jsonb,
    temporal_scope_json     JSONB NOT NULL DEFAULT '{}'::jsonb,
    confidence_global       REAL NOT NULL DEFAULT 0.0,
    risk_level              TEXT NOT NULL DEFAULT 'low' CHECK (risk_level IN ('low', 'medium', 'high')),
    requires_confirmation   BOOLEAN NOT NULL DEFAULT FALSE,
    explanation_short       TEXT,
    luiss_bridge_status     TEXT NOT NULL DEFAULT 'pending',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_intent_utterance ON eco_intent_packets(utterance_id);
CREATE INDEX IF NOT EXISTS idx_eco_intent_action ON eco_intent_packets(action_code, created_at DESC);

-- ============================================================
-- MIGRAZIONE: migration_v52_eco_runtime_dialog.sql
-- ============================================================
-- VEMORA V52 — ECO Premium Runtime/Dialog/Policy

CREATE TABLE IF NOT EXISTS eco_dialog_turns (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id              UUID NOT NULL REFERENCES eco_sessions(id) ON DELETE CASCADE,
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    turn_index              INTEGER NOT NULL,
    turn_type               TEXT NOT NULL,
    dialog_phase            TEXT NOT NULL DEFAULT 'active',
    repair_mode             TEXT NOT NULL DEFAULT 'none',
    interruption_detected   BOOLEAN NOT NULL DEFAULT FALSE,
    active_focus_json       JSONB NOT NULL DEFAULT '[]'::jsonb,
    grounding_json          JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_dialog_session ON eco_dialog_turns(session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_dialog_utterance ON eco_dialog_turns(utterance_id);

CREATE TABLE IF NOT EXISTS eco_policy_events (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    policy_action           TEXT NOT NULL,
    confirmation_mode       TEXT NOT NULL DEFAULT 'none',
    silence_mode            TEXT NOT NULL DEFAULT 'none',
    reason_codes            JSONB NOT NULL DEFAULT '[]'::jsonb,
    grounding_strength      REAL NOT NULL DEFAULT 0.0,
    policy_summary          TEXT,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_policy_utterance ON eco_policy_events(utterance_id);
CREATE INDEX IF NOT EXISTS idx_eco_policy_action ON eco_policy_events(policy_action, created_at DESC);


-- ============================================================
-- MIGRAZIONE: migration_v53_eco_anchor_time.sql
-- ============================================================
-- VEMORA V53 — ECO Camere Ancora / Tempo Umano / Common Ground

CREATE TABLE IF NOT EXISTS eco_anchor_candidates (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id        UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    anchor_label        TEXT NOT NULL,
    anchor_type         TEXT NOT NULL DEFAULT 'generic',
    anchor_strength     TEXT NOT NULL DEFAULT 'probable',
    anchor_score        REAL NOT NULL DEFAULT 0.0,
    linked_entity_type  TEXT,
    linked_entity_id    UUID,
    source              TEXT NOT NULL DEFAULT 'eco',
    reason_codes        JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_anchor_utterance ON eco_anchor_candidates(utterance_id);
CREATE INDEX IF NOT EXISTS idx_eco_anchor_label ON eco_anchor_candidates(anchor_label, created_at DESC);

CREATE TABLE IF NOT EXISTS eco_temporal_resolutions (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id        UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    resolution_mode     TEXT NOT NULL,
    expression          TEXT,
    from_date           DATE,
    to_date             DATE,
    resolution_json     JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_temporal_utterance ON eco_temporal_resolutions(utterance_id);
CREATE INDEX IF NOT EXISTS idx_eco_temporal_mode ON eco_temporal_resolutions(resolution_mode, created_at DESC);

CREATE TABLE IF NOT EXISTS eco_common_ground_states (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id              UUID NOT NULL REFERENCES eco_sessions(id) ON DELETE CASCADE,
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    active_focus_json       JSONB NOT NULL DEFAULT '[]'::jsonb,
    shared_entities_json    JSONB NOT NULL DEFAULT '[]'::jsonb,
    shared_action           TEXT,
    shared_time_scope_json  JSONB NOT NULL DEFAULT '{}'::jsonb,
    shared_anchor_json      JSONB NOT NULL DEFAULT '{}'::jsonb,
    open_uncertainties_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    ground_strength         REAL NOT NULL DEFAULT 0.0,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_ground_session ON eco_common_ground_states(session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_ground_utterance ON eco_common_ground_states(utterance_id);

-- VEMORA V54 — ECO Camere Ancora / Maturazione storica

CREATE TABLE IF NOT EXISTS eco_anchor_memories (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    anchor_identity     TEXT NOT NULL,
    anchor_label        TEXT NOT NULL,
    anchor_type         TEXT NOT NULL DEFAULT 'generic',
    maturity_level      TEXT NOT NULL DEFAULT 'debole',
    maturity_score      REAL NOT NULL DEFAULT 0.0,
    evidence_count      INTEGER NOT NULL DEFAULT 1,
    recurrence_sessions INTEGER NOT NULL DEFAULT 1,
    linked_entity_type  TEXT,
    linked_entity_id    UUID,
    last_session_id     UUID REFERENCES eco_sessions(id) ON DELETE SET NULL,
    first_seen_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    reason_codes        JSONB NOT NULL DEFAULT '[]'::jsonb,
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, anchor_identity)
);

CREATE INDEX IF NOT EXISTS idx_eco_anchor_memories_user_score
    ON eco_anchor_memories(utente_id, maturity_score DESC, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_anchor_memories_label
    ON eco_anchor_memories(anchor_label, updated_at DESC);


-- ============================================================
-- MIGRAZIONE: migration_v55_eco_life_events.sql
-- ============================================================

-- VEMORA V55 — ECO Eventi di vita semantici / common ground esteso

ALTER TABLE IF EXISTS eco_common_ground_states
    ADD COLUMN IF NOT EXISTS shared_semantic_period_json JSONB NOT NULL DEFAULT '{}'::jsonb;

CREATE TABLE IF NOT EXISTS eco_life_anchor_events (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    event_identity      TEXT NOT NULL,
    event_label         TEXT NOT NULL,
    anchor_domain       TEXT NOT NULL DEFAULT 'generic',
    event_type          TEXT NOT NULL DEFAULT 'event',
    relationship_scope  TEXT,
    salience_level      TEXT NOT NULL DEFAULT 'media',
    temporal_force      INTEGER NOT NULL DEFAULT 0,
    maturity_level      TEXT NOT NULL DEFAULT 'debole',
    maturity_score      REAL NOT NULL DEFAULT 0.0,
    evidence_count      INTEGER NOT NULL DEFAULT 1,
    recurrence_sessions INTEGER NOT NULL DEFAULT 1,
    last_session_id     UUID REFERENCES eco_sessions(id) ON DELETE SET NULL,
    first_seen_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    reason_codes        JSONB NOT NULL DEFAULT '[]'::jsonb,
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, event_identity)
);

CREATE INDEX IF NOT EXISTS idx_eco_life_anchor_events_user_score
    ON eco_life_anchor_events(utente_id, maturity_score DESC, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_life_anchor_events_label
    ON eco_life_anchor_events(event_label, updated_at DESC);


-- ============================================================
-- MIGRAZIONE: migration_v56_semantic_anchor_memory.sql
-- ============================================================

-- VEMORA V56 — Memoria semantica generale per ancore/periodi usati dal vocale
-- Correzione architetturale: ECO consuma refs vocali, non possiede la memoria primaria della vita.

CREATE TABLE IF NOT EXISTS semantic_anchor_events (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    anchor_identity     TEXT NOT NULL,
    short_label         TEXT NOT NULL,
    anchor_domain       TEXT NOT NULL DEFAULT 'generic',
    anchor_kind         TEXT NOT NULL DEFAULT 'semantic_period',
    event_type          TEXT NOT NULL DEFAULT 'event',
    relationship_scope  TEXT,
    salience_level      TEXT NOT NULL DEFAULT 'media',
    temporal_force      INTEGER NOT NULL DEFAULT 0,
    human_priority      INTEGER NOT NULL DEFAULT 0,
    maturity_level      TEXT NOT NULL DEFAULT 'debole',
    maturity_score      REAL NOT NULL DEFAULT 0.0,
    evidence_count      INTEGER NOT NULL DEFAULT 1,
    recurrence_sessions INTEGER NOT NULL DEFAULT 1,
    last_source_session_id UUID,
    owner_scope         TEXT NOT NULL DEFAULT 'vemora_semantic_memory',
    visibility_scope    TEXT NOT NULL DEFAULT 'voice_reference',
    payload_json        JSONB NOT NULL DEFAULT '{}'::jsonb,
    reason_codes        JSONB NOT NULL DEFAULT '[]'::jsonb,
    first_seen_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, anchor_identity)
);

CREATE INDEX IF NOT EXISTS idx_semantic_anchor_events_user_score
    ON semantic_anchor_events(utente_id, maturity_score DESC, human_priority DESC, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_semantic_anchor_events_label
    ON semantic_anchor_events(short_label, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_semantic_anchor_events_visibility
    ON semantic_anchor_events(visibility_scope, anchor_domain, event_type);



-- ============================================================
-- MIGRAZIONE: migration_v57_eco_user_adaptation.sql
-- ============================================================

-- VEMORA V57 — ECO User Adaptation Core V1

CREATE TABLE IF NOT EXISTS eco_user_voice_profiles (
    utente_id                    UUID PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    learning_enabled             BOOLEAN NOT NULL DEFAULT TRUE,
    phonetic_learning_enabled    BOOLEAN NOT NULL DEFAULT TRUE,
    semantic_ref_learning_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    screen_habit_learning_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    correction_learning_enabled  BOOLEAN NOT NULL DEFAULT TRUE,
    phonetic_learning_count      INTEGER NOT NULL DEFAULT 0,
    correction_count             INTEGER NOT NULL DEFAULT 0,
    semantic_ref_learning_count  INTEGER NOT NULL DEFAULT 0,
    screen_habit_learning_count  INTEGER NOT NULL DEFAULT 0,
    last_seen_at                 TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at                   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS eco_adaptation_feedback (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id        UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    session_id       UUID REFERENCES eco_sessions(id) ON DELETE SET NULL,
    utterance_id     UUID REFERENCES eco_utterances(id) ON DELETE SET NULL,
    signal_type      TEXT NOT NULL,
    category         TEXT NOT NULL,
    learned_key      TEXT NOT NULL,
    learned_value    TEXT,
    context_scope    TEXT,
    source_event     TEXT NOT NULL DEFAULT 'voice_turn',
    evidence_weight  REAL NOT NULL DEFAULT 1.0,
    confidence_delta REAL NOT NULL DEFAULT 0.0,
    payload_json     JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_eco_adaptation_feedback_user_time
    ON eco_adaptation_feedback(utente_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_adaptation_feedback_category
    ON eco_adaptation_feedback(utente_id, category, signal_type, created_at DESC);

CREATE TABLE IF NOT EXISTS eco_screen_action_habits (
    utente_id        UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    screen_id        TEXT NOT NULL,
    action_code      TEXT NOT NULL,
    usage_count      INTEGER NOT NULL DEFAULT 0,
    success_count    INTEGER NOT NULL DEFAULT 0,
    correction_count INTEGER NOT NULL DEFAULT 0,
    strength_score   REAL NOT NULL DEFAULT 0.0,
    last_used_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (utente_id, screen_id, action_code)
);

CREATE INDEX IF NOT EXISTS idx_eco_screen_action_habits_strength
    ON eco_screen_action_habits(utente_id, screen_id, strength_score DESC, last_used_at DESC);

CREATE TABLE IF NOT EXISTS eco_semantic_ref_learning (
    utente_id          UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    semantic_period_ref TEXT NOT NULL,
    short_label        TEXT NOT NULL,
    context_scope      TEXT NOT NULL DEFAULT '',
    usage_count        INTEGER NOT NULL DEFAULT 0,
    correction_count   INTEGER NOT NULL DEFAULT 0,
    strength_score     REAL NOT NULL DEFAULT 0.0,
    last_seen_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (utente_id, semantic_period_ref, context_scope)
);

CREATE INDEX IF NOT EXISTS idx_eco_semantic_ref_learning_strength
    ON eco_semantic_ref_learning(utente_id, strength_score DESC, last_seen_at DESC);

