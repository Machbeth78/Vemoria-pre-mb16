-- Gate08G — Cerebro orchestrator gated contracts (runtime deferred)
CREATE TABLE IF NOT EXISTS gate08g_cerebro_orchestration_contracts (
    id BIGSERIAL PRIMARY KEY,
    owner_id TEXT NOT NULL,
    workfile_id TEXT NULL,
    intent TEXT NOT NULL,
    domain TEXT NOT NULL,
    route_status TEXT NOT NULL,
    source_chain_hash TEXT NULL,
    probe_gate_hash TEXT NULL,
    three_maps_ready BOOLEAN NOT NULL DEFAULT FALSE,
    owner_confirmation_required BOOLEAN NOT NULL DEFAULT TRUE,
    runtime_executed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_gate08g_cerebro_orchestration_owner_created
    ON gate08g_cerebro_orchestration_contracts(owner_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_gate08g_cerebro_orchestration_domain_status
    ON gate08g_cerebro_orchestration_contracts(domain, route_status);
