-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V32 — Dati Forti su documenti + Entity estesa
-- Aggiunge colonne indicizzate per i dati forti estratti da OCR.
-- Sicura: tutte le colonne sono nullable e non toccano dati esistenti.

-- ── 1. Colonne dati forti su documenti ───────────────────────────────────
ALTER TABLE documenti
    ADD COLUMN IF NOT EXISTS codice_fiscale  TEXT,
    ADD COLUMN IF NOT EXISTS partita_iva     TEXT,
    ADD COLUMN IF NOT EXISTS numero_documento TEXT,
    ADD COLUMN IF NOT EXISTS importo         NUMERIC(15, 2),
    ADD COLUMN IF NOT EXISTS email_estratta  TEXT,
    ADD COLUMN IF NOT EXISTS telefono        TEXT,
    ADD COLUMN IF NOT EXISTS targa           TEXT;

-- data_documento esiste già in memorie ma NON su documenti — aggiunta qui
ALTER TABLE documenti
    ADD COLUMN IF NOT EXISTS data_documento  DATE;

-- ── 2. Indici su documenti ────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_doc_codice_fiscale
    ON documenti (codice_fiscale)
    WHERE codice_fiscale IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_doc_partita_iva
    ON documenti (partita_iva)
    WHERE partita_iva IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_doc_data_documento
    ON documenti (data_documento)
    WHERE data_documento IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_doc_numero_documento
    ON documenti (numero_documento)
    WHERE numero_documento IS NOT NULL;

-- ── 3. Estende entity: aggiunge codice_fiscale e partita_iva come colonne ─
-- La tabella entity ha già: tipo_entity, nome, identificativo (generico)
-- Aggiungiamo colonne dedicate per CF e PIVA, mantenendo identificativo
ALTER TABLE entity
    ADD COLUMN IF NOT EXISTS codice_fiscale TEXT,
    ADD COLUMN IF NOT EXISTS partita_iva    TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS idx_entity_codice_fiscale
    ON entity (codice_fiscale)
    WHERE codice_fiscale IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS idx_entity_partita_iva
    ON entity (partita_iva)
    WHERE partita_iva IS NOT NULL;

-- ── 4. Tabella documento_entity_link (link diretto doc → entity via CF/PIVA)
-- Separata da entity_link (generica) per distinguere i link automatici
-- da quelli manuali.
CREATE TABLE IF NOT EXISTS documento_entity_link (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id    UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    entity_id       UUID NOT NULL REFERENCES entity(id)   ON DELETE CASCADE,
    metodo          TEXT NOT NULL DEFAULT 'auto',  -- 'auto_cf' | 'auto_piva' | 'manuale'
    confidenza      FLOAT NOT NULL DEFAULT 1.0,
    creato_il       TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (documento_id, entity_id)
);

CREATE INDEX IF NOT EXISTS idx_del_documento ON documento_entity_link (documento_id);
CREATE INDEX IF NOT EXISTS idx_del_entity    ON documento_entity_link (entity_id);
