-- MB13-P3 v223 — recovery quarantine atomicity, exact object allowlist,
-- data/function owner separation, internal privilege closure.
-- Do not reopen MB13-P1/MB13-P2, do not open R3, do not produce APK/AAB.
BEGIN;

-- ============================================================================
-- 1. Role definitions: separate data owner and function/executor owner
-- ============================================================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p3_pack_data_owner') THEN
        CREATE ROLE mb13_p3_pack_data_owner NOLOGIN NOINHERIT NOBYPASSRLS;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p3_pack_lifecycle_executor') THEN
        CREATE ROLE mb13_p3_pack_lifecycle_executor NOLOGIN NOINHERIT NOBYPASSRLS;
    END IF;
END $$;

ALTER ROLE mb13_p3_pack_data_owner NOLOGIN NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p3_pack_lifecycle_executor NOLOGIN NOINHERIT NOBYPASSRLS;

-- ============================================================================
-- 2. Exact canonical object allowlist and fail-closed verification
-- ============================================================================
DO $$
DECLARE
    v_allowed_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    v_allowed_sequences TEXT[] := ARRAY[
        'mb13_p3_recovery_audit_audit_id_seq'
    ];
    v_allowed_triggers TEXT[] := ARRAY[
        'trg_mb13_p3_action_pack_governed_mutation',
        'trg_mb13_p3_action_pack_monitor_policy_hash',
        'trg_mb13_p3_action_pack_result_evidence_guard',
        'trg_mb13_p3_action_pack_terminal_attempt_sync',
        'trg_mb13_p3_action_pack_transition_guard',
        'trg_mb13_p3_authorization_append_only',
        'trg_mb13_p3_evidence_immutable',
        'trg_mb13_p3_recovery_audit_immutable',
        'trg_mb13_p3_result_immutable',
        'trg_mb13_p3_revision_immutable',
        'trg_mb13_p3_timeline_immutable'
    ];
    v_allowed_functions TEXT[] := ARRAY[
        'mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_authorization_append_only()',
        'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_evidence_immutable()',
        'mb13_p3_action_pack_governed_mutation()',
        'mb13_p3_action_pack_monitor_policy_hash()',
        'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)',
        'mb13_p3_action_pack_result_evidence_guard()',
        'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)',
        'mb13_p3_action_pack_result_immutable()',
        'mb13_p3_action_pack_revision_immutable()',
        'mb13_p3_action_pack_terminal_attempt_sync()',
        'mb13_p3_action_pack_timeline_immutable()',
        'mb13_p3_action_pack_transition_guard()',
        'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'mb13_p3_cancel_action_pack(uuid,uuid)',
        'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)',
        'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_expire_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack_attempts(uuid,uuid)',
        'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)',
        'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)',
        'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)',
        'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)',
        'mb13_p3_list_action_packs(uuid,text,integer,integer)',
        'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'mb13_p3_recovery_audit_immutable()',
        'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'mb13_p3_revoke_action_pack(uuid,uuid)',
        'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)',
        'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)',
        'mb13_p3_validate_result_evidence(jsonb)',
        'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)',
        'mb13_p3_validate_steps(uuid,jsonb)',
        'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'
    ];
    v_allowed_roles TEXT[] := ARRAY[
        'mb13_p3_api',
        'mb13_p3_executor',
        'mb13_p3_pack_data_owner',
        'mb13_p3_pack_lifecycle_executor',
        'mb13_p3_pack_lifecycle_owner',
        'mb13_p3_pack_mutator',
        'mb13_p3_validator',
        'mb13_p3_writer'
    ];
    v_found_triggers TEXT[];
    r RECORD;
    t TEXT;
    s TEXT;
    sig TEXT;
    tg TEXT;
    rol TEXT;
BEGIN
    -- Unexpected / missing tables
    FOR r IN
        SELECT relname FROM pg_class
         WHERE relnamespace = 'public'::regnamespace
           AND relkind = 'r'
           AND relname LIKE 'mb13_p3_%'
           AND NOT (relname = ANY(v_allowed_tables))
    LOOP
        RAISE EXCEPTION 'migration_v223 unexpected table: %', r.relname;
    END LOOP;

    FOREACH t IN ARRAY v_allowed_tables LOOP
        IF to_regclass('public.' || t) IS NULL THEN
            RAISE EXCEPTION 'migration_v223 missing table: %', t;
        END IF;
    END LOOP;

    -- Unexpected / missing sequences
    FOR r IN
        SELECT c.relname FROM pg_class c
          JOIN pg_namespace n ON c.relnamespace = n.oid
         WHERE n.nspname = 'public'
           AND c.relkind = 'S'
           AND c.relname LIKE 'mb13_p3_%'
           AND NOT (c.relname = ANY(v_allowed_sequences))
    LOOP
        RAISE EXCEPTION 'migration_v223 unexpected sequence: %', r.relname;
    END LOOP;

    FOREACH s IN ARRAY v_allowed_sequences LOOP
        IF to_regclass('public.' || s) IS NULL THEN
            RAISE EXCEPTION 'migration_v223 missing sequence: %', s;
        END IF;
    END LOOP;

    -- Unexpected / missing functions (exact regprocedure signatures)
    FOR r IN
        SELECT p.oid::regprocedure::text AS sig
          FROM pg_proc p
          JOIN pg_namespace n ON p.pronamespace = n.oid
         WHERE n.nspname = 'public'
           AND p.proname LIKE 'mb13_p3_%'
           AND NOT (p.oid::regprocedure::text = ANY(v_allowed_functions))
    LOOP
        RAISE EXCEPTION 'migration_v223 unexpected function: %', r.sig;
    END LOOP;

    FOREACH sig IN ARRAY v_allowed_functions LOOP
        IF to_regprocedure(sig) IS NULL THEN
            RAISE EXCEPTION 'migration_v223 missing function: %', sig;
        END IF;
    END LOOP;

    -- Unexpected / missing user-defined triggers on allowlisted tables
    SELECT array_agg(t.tgname) INTO v_found_triggers
      FROM pg_trigger t
      JOIN pg_class c ON t.tgrelid = c.oid
      JOIN pg_namespace n ON c.relnamespace = n.oid
     WHERE n.nspname = 'public'
       AND c.relname = ANY(v_allowed_tables)
       AND t.tgname LIKE 'trg_mb13_p3_%';

    IF v_found_triggers IS NOT NULL THEN
        FOREACH tg IN ARRAY v_found_triggers LOOP
            IF NOT (tg = ANY(v_allowed_triggers)) THEN
                RAISE EXCEPTION 'migration_v223 unexpected trigger: %', tg;
            END IF;
        END LOOP;
    END IF;

    FOREACH tg IN ARRAY v_allowed_triggers LOOP
        IF NOT EXISTS (
            SELECT 1 FROM pg_trigger t
              JOIN pg_class c ON t.tgrelid = c.oid
              JOIN pg_namespace n ON c.relnamespace = n.oid
             WHERE n.nspname = 'public'
               AND t.tgname = tg
        ) THEN
            RAISE EXCEPTION 'migration_v223 missing trigger: %', tg;
        END IF;
    END LOOP;

    -- Unexpected / missing roles
    FOR r IN
        SELECT rolname FROM pg_roles
         WHERE rolname LIKE 'mb13_p3_%'
           AND NOT (rolname = ANY(v_allowed_roles))
    LOOP
        RAISE EXCEPTION 'migration_v223 unexpected role: %', r.rolname;
    END LOOP;

    FOREACH rol IN ARRAY v_allowed_roles LOOP
        IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = rol) THEN
            RAISE EXCEPTION 'migration_v223 missing role: %', rol;
        END IF;
    END LOOP;
END $$;

-- ============================================================================
-- 3. Strip broad schema-level privileges from the separated owner roles
-- ============================================================================
REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM mb13_p3_pack_lifecycle_executor, mb13_p3_pack_lifecycle_owner;
REVOKE ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public FROM mb13_p3_pack_lifecycle_executor, mb13_p3_pack_lifecycle_owner;
REVOKE ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public FROM mb13_p3_pack_lifecycle_executor, mb13_p3_pack_lifecycle_owner;
REVOKE ALL PRIVILEGES ON SCHEMA public FROM mb13_p3_pack_lifecycle_executor, mb13_p3_pack_lifecycle_owner;
GRANT USAGE ON SCHEMA public TO mb13_p3_pack_data_owner, mb13_p3_pack_lifecycle_executor, mb13_p3_pack_lifecycle_owner;

-- ============================================================================
-- 4. Transfer all allowlisted tables and sequences to the data owner
-- ============================================================================
DO $$
DECLARE
    v_allowed_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    v_allowed_sequences TEXT[] := ARRAY[
        'mb13_p3_recovery_audit_audit_id_seq'
    ];
    t TEXT;
    s TEXT;
BEGIN
    FOREACH t IN ARRAY v_allowed_tables LOOP
        EXECUTE format('ALTER TABLE public.%I OWNER TO mb13_p3_pack_data_owner', t);
    END LOOP;
    FOREACH s IN ARRAY v_allowed_sequences LOOP
        EXECUTE format('ALTER SEQUENCE public.%I OWNER TO mb13_p3_pack_data_owner', s);
    END LOOP;
END $$;

-- ============================================================================
-- 4.5. Ensure the data owner holds the full privilege set on its own objects
--      (required so FK checks on child tables owned by the data owner can lock
--       the referenced parent rows via FOR KEY SHARE).
-- ============================================================================
GRANT ALL PRIVILEGES ON TABLE
    public.mb13_p3_action_pack,
    public.mb13_p3_action_pack_attempt,
    public.mb13_p3_action_pack_authorization,
    public.mb13_p3_action_pack_evidence,
    public.mb13_p3_action_pack_result,
    public.mb13_p3_action_pack_revision,
    public.mb13_p3_action_pack_timeline,
    public.mb13_p3_recovery_audit
    TO mb13_p3_pack_data_owner;

GRANT ALL PRIVILEGES ON SEQUENCE public.mb13_p3_recovery_audit_audit_id_seq
    TO mb13_p3_pack_data_owner;

-- The action_pack table references mb13_p0_monitor_target; the data owner must
-- be able to acquire a FOR KEY SHARE lock on the referenced row during inserts.
GRANT SELECT ON TABLE public.mb13_p0_monitor_target TO mb13_p3_pack_data_owner;

-- ============================================================================
-- 4.6. Recreate the pack mutation gate as a GUC-based fail-closed check
--      owned by the lifecycle executor.  Earlier iterations made the gate
--      role-based; v223 separates the data owner from the function owner, so
--      the canonical lifecycle functions authorize their own mutations via
--      app.mb13_p3_authorized_pack_mutation = 'true'.
-- ============================================================================
DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_governed_mutation ON public.mb13_p3_action_pack;
DROP FUNCTION IF EXISTS public.mb13_p3_action_pack_governed_mutation();

CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_governed_mutation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF current_setting('app.mb13_p3_authorized_pack_mutation', true) = 'true' THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;
    RAISE EXCEPTION 'mb13_p3_action_pack_direct_mutation_denied'
        USING ERRCODE = '42501';
END;
$$;

ALTER FUNCTION public.mb13_p3_action_pack_governed_mutation() OWNER TO mb13_p3_pack_lifecycle_executor;

CREATE TRIGGER trg_mb13_p3_action_pack_governed_mutation
    BEFORE INSERT OR UPDATE OR DELETE ON public.mb13_p3_action_pack
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p3_action_pack_governed_mutation();

-- ============================================================================
-- 5. Transfer all allowlisted functions to the lifecycle executor or validator
-- ============================================================================
DO $$
DECLARE
    v_lifecycle TEXT[] := ARRAY[
        'mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_authorization_append_only()',
        'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_evidence_immutable()',
        'mb13_p3_action_pack_governed_mutation()',
        'mb13_p3_action_pack_monitor_policy_hash()',
        'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_action_pack_result_evidence_guard()',
        'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)',
        'mb13_p3_action_pack_result_immutable()',
        'mb13_p3_action_pack_revision_immutable()',
        'mb13_p3_action_pack_terminal_attempt_sync()',
        'mb13_p3_action_pack_timeline_immutable()',
        'mb13_p3_action_pack_transition_guard()',
        'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'mb13_p3_cancel_action_pack(uuid,uuid)',
        'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)',
        'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_expire_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack_attempts(uuid,uuid)',
        'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)',
        'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)',
        'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)',
        'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)',
        'mb13_p3_list_action_packs(uuid,text,integer,integer)',
        'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'mb13_p3_recovery_audit_immutable()',
        'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'mb13_p3_revoke_action_pack(uuid,uuid)',
        'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)',
        'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)',
        'mb13_p3_validate_result_evidence(jsonb)',
        'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_validate_steps(uuid,jsonb)'
    ];
    v_validator TEXT[] := ARRAY[
        'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)',
        'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)',
        'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'
    ];
    sig TEXT;
BEGIN
    FOREACH sig IN ARRAY v_lifecycle LOOP
        EXECUTE format('ALTER FUNCTION %s OWNER TO mb13_p3_pack_lifecycle_executor', sig);
    END LOOP;
    FOREACH sig IN ARRAY v_validator LOOP
        EXECUTE format('ALTER FUNCTION %s OWNER TO mb13_p3_validator', sig);
    END LOOP;
END $$;

-- ============================================================================
-- 6. Grant lifecycle executor the minimal table/sequence privileges it needs
-- ============================================================================
-- Append-only tables: SELECT/INSERT/UPDATE.  The append-only triggers deny any
-- actual UPDATE/DELETE, but lifecycle functions need UPDATE for SELECT ... FOR UPDATE
-- locking on these rows.
DO $$
DECLARE
    v_append_only TEXT[] := ARRAY[
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    t TEXT;
BEGIN
    FOREACH t IN ARRAY v_append_only LOOP
        EXECUTE format('GRANT SELECT, INSERT, UPDATE ON TABLE public.%I TO mb13_p3_pack_lifecycle_executor', t);
    END LOOP;
END $$;

-- Authorization is append-only for non-revocation columns (enforced by trigger),
-- but the lifecycle executor must lock rows with FOR UPDATE and may update revoked.
GRANT SELECT, INSERT, UPDATE ON TABLE public.mb13_p3_action_pack_authorization TO mb13_p3_pack_lifecycle_executor;

-- Non-append-only operational tables
GRANT SELECT, INSERT, UPDATE ON TABLE public.mb13_p3_action_pack TO mb13_p3_pack_lifecycle_executor;
GRANT SELECT, INSERT, UPDATE ON TABLE public.mb13_p3_action_pack_attempt TO mb13_p3_pack_lifecycle_executor;

-- Referenced tables outside MB13-P3
GRANT SELECT, UPDATE ON TABLE public.mb13_p0_monitor_target TO mb13_p3_pack_lifecycle_executor;
GRANT SELECT ON TABLE public.mb13_p0_monitor_target_revision TO mb13_p3_pack_lifecycle_executor;
GRANT SELECT ON TABLE public.mb13_p0_monitor_event_ledger TO mb13_p3_pack_lifecycle_executor;
GRANT SELECT ON TABLE public.authorized_memory_consent_grants TO mb13_p3_pack_lifecycle_executor;
GRANT SELECT ON TABLE public.authorized_memory_sources TO mb13_p3_pack_lifecycle_executor;
GRANT SELECT ON TABLE public.authorized_memory_activity_log TO mb13_p3_pack_lifecycle_executor;

-- Sequences
GRANT USAGE, SELECT ON SEQUENCE public.mb13_p3_recovery_audit_audit_id_seq TO mb13_p3_pack_lifecycle_executor;

-- Validator-owned helpers need referenced table read access
GRANT SELECT ON TABLE public.mb13_p3_action_pack TO mb13_p3_validator;
GRANT SELECT ON TABLE public.mb13_p3_action_pack_revision TO mb13_p3_validator;
GRANT SELECT ON TABLE public.mb13_p0_monitor_target TO mb13_p3_validator;
GRANT SELECT ON TABLE public.mb13_p0_monitor_target_revision TO mb13_p3_validator;
GRANT SELECT ON TABLE public.mb13_p0_monitor_event_ledger TO mb13_p3_validator;
GRANT SELECT ON TABLE public.authorized_memory_consent_grants TO mb13_p3_validator;
GRANT SELECT ON TABLE public.authorized_memory_sources TO mb13_p3_validator;
GRANT SELECT ON TABLE public.authorized_memory_activity_log TO mb13_p3_validator;

-- Helper privileges
GRANT EXECUTE ON FUNCTION public.mb13_p0_hash_jsonb(JSONB) TO mb13_p3_pack_lifecycle_executor, mb13_p3_validator;

-- ============================================================================
-- 7. Deny direct DML on all Action Pack tables to application/test roles
-- ============================================================================
DO $$
DECLARE
    v_allowed_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    t TEXT;
BEGIN
    FOREACH t IN ARRAY v_allowed_tables LOOP
        EXECUTE format('REVOKE ALL ON TABLE public.%I FROM PUBLIC, mb13_p3_writer, mb13_p3_api, mb13_p3_executor, test_app', t);
    END LOOP;
END $$;

-- Allow read-only SELECT to the canonical application roles (functions enforce DML)
DO $$
DECLARE
    v_allowed_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    t TEXT;
BEGIN
    FOREACH t IN ARRAY v_allowed_tables LOOP
        EXECUTE format('GRANT SELECT ON TABLE public.%I TO mb13_p3_writer, mb13_p3_api, mb13_p3_executor, mb13_p3_validator', t);
    END LOOP;
END $$;

-- Recovery audit is append-only: only the lifecycle executor may insert
REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON TABLE public.mb13_p3_recovery_audit FROM PUBLIC, mb13_p3_writer, mb13_p3_api, mb13_p3_executor, test_app;

-- ============================================================================
-- 8. Exact privilege matrix for all allowlisted functions
-- ============================================================================
DO $$
DECLARE
    v_api_sigs TEXT[] := ARRAY[
        'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'mb13_p3_cancel_action_pack(uuid,uuid)',
        'mb13_p3_revoke_action_pack(uuid,uuid)'
    ];
    v_executor_sigs TEXT[] := ARRAY[
        'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'mb13_p3_expire_action_pack(uuid,uuid)'
    ];
    v_reader_sigs TEXT[] := ARRAY[
        'mb13_p3_get_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack_attempts(uuid,uuid)',
        'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)',
        'mb13_p3_list_action_packs(uuid,text,integer,integer)'
    ];
    v_all_entrypoints TEXT[] := v_api_sigs || v_executor_sigs || v_reader_sigs;
    v_internal TEXT[] := ARRAY[
        'mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_authorization_append_only()',
        'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_evidence_immutable()',
        'mb13_p3_action_pack_governed_mutation()',
        'mb13_p3_action_pack_monitor_policy_hash()',
        'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)',
        'mb13_p3_action_pack_result_evidence_guard()',
        'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)',
        'mb13_p3_action_pack_result_immutable()',
        'mb13_p3_action_pack_revision_immutable()',
        'mb13_p3_action_pack_terminal_attempt_sync()',
        'mb13_p3_action_pack_timeline_immutable()',
        'mb13_p3_action_pack_transition_guard()',
        'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)',
        'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)',
        'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)',
        'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)',
        'mb13_p3_recovery_audit_immutable()',
        'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)',
        'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)',
        'mb13_p3_validate_result_evidence(jsonb)',
        'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)',
        'mb13_p3_validate_steps(uuid,jsonb)',
        'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'
    ];
    sig TEXT;
    proname TEXT;
BEGIN
    -- Public API / lifecycle entrypoints: revoke broadly, then grant narrowly.
    FOREACH sig IN ARRAY v_all_entrypoints LOOP
        EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC, test_app', sig);
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_writer', sig);
    END LOOP;
    FOREACH sig IN ARRAY (v_api_sigs || v_reader_sigs) LOOP
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_api', sig);
    END LOOP;
    FOREACH sig IN ARRAY (v_executor_sigs || v_reader_sigs) LOOP
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_executor', sig);
    END LOOP;

    -- Internal helpers/triggers: revoke from app/test/public, grant only to the lifecycle executor
    -- or the validator role where the helper is specifically validator-owned.
    FOREACH sig IN ARRAY v_internal LOOP
        proname := split_part(sig, '(', 1);
        EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC, mb13_p3_api, mb13_p3_executor, mb13_p3_writer, test_app', sig);
        IF proname = ANY(ARRAY['mb13_p3_action_pack_refs_revoked',
        'mb13_p3_validate_source_grant_chain',
        'mb13_p3_validate_trigger_diff']) THEN
            EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_validator, mb13_p3_pack_lifecycle_executor', sig);
        ELSE
            EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_pack_lifecycle_executor', sig);
        END IF;
    END LOOP;
END $$;

-- ============================================================================
-- 9. Force RLS on every data-owner table; owners must not bypass RLS
-- ============================================================================
DO $$
DECLARE
    v_allowed_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    t TEXT;
BEGIN
    FOREACH t IN ARRAY v_allowed_tables LOOP
        EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
        EXECUTE format('ALTER TABLE public.%I FORCE ROW LEVEL SECURITY', t);
    END LOOP;
END $$;

-- ============================================================================
-- 10. Ensure no application role can SET ROLE into the separated owners
-- ============================================================================
DO $$
DECLARE
    v_app_roles TEXT[] := ARRAY['mb13_p3_writer','mb13_p3_api','mb13_p3_executor','mb13_p3_validator','mb13_p3_pack_mutator','test_app'];
    r TEXT;
BEGIN
    FOREACH r IN ARRAY v_app_roles LOOP
        EXECUTE format('REVOKE mb13_p3_pack_data_owner FROM %I', r);
        EXECUTE format('REVOKE mb13_p3_pack_lifecycle_executor FROM %I', r);
        EXECUTE format('REVOKE mb13_p3_pack_lifecycle_owner FROM %I', r);
    END LOOP;
END $$;

-- ============================================================================
-- 11. Full chain re-classification with atomic exception quarantine and
--     reason-specific de-quarantine
-- ============================================================================
ALTER TABLE public.mb13_p3_recovery_audit
    DROP CONSTRAINT IF EXISTS ck_mb13_p3_recovery_audit_classification;
ALTER TABLE public.mb13_p3_recovery_audit
    ADD CONSTRAINT ck_mb13_p3_recovery_audit_classification
        CHECK (classification IN ('candidate','verified','ambiguous','skipped','quarantined','upgraded','quarantine_preserved'));

DO $$
DECLARE
    v_run_id UUID := gen_random_uuid();
    v_pack RECORD;
    v_rev RECORD;
    v_current_rev public.mb13_p3_action_pack_revision%ROWTYPE;
    v_pack_hash TEXT;
    v_expected TEXT;
    v_pack_expected TEXT;
    v_pack_quarantine BOOLEAN;
    v_pack_reason TEXT;
    v_is_candidate BOOLEAN;
    v_rev_count INTEGER;
    v_expected_rev INTEGER;
    v_chain_gap BOOLEAN;
    v_revision_ambiguous BOOLEAN;
    v_correctable_reasons TEXT[] := ARRAY[
        'legacy_recovery_revision_hash_mismatch',
        'legacy_recovery_pack_hash_mismatch',
        'legacy_recovery_current_revision_canonical_mismatch',
        'legacy_recovery_current_revision_missing',
        'legacy_recovery_chain_gap',
        'legacy_recovery_no_revisions',
        'legacy_recovery_exception'
    ];
    v_previous_reason TEXT;
BEGIN
    ALTER TABLE public.mb13_p3_action_pack DISABLE TRIGGER USER;
    ALTER TABLE public.mb13_p3_action_pack_revision DISABLE TRIGGER USER;

    FOR v_pack IN
        SELECT * FROM public.mb13_p3_action_pack
         ORDER BY pack_id
    LOOP
        BEGIN
            v_pack_hash := encode(digest(v_pack.pack_id::text, 'sha256'), 'hex');
            v_pack_quarantine := FALSE;
            v_pack_reason := NULL;
            v_is_candidate := FALSE;

            IF v_pack.legacy_idempotency_unverified IS TRUE
               OR v_pack.legacy_idempotency_quarantined IS TRUE
               OR v_pack.idempotency_key IS NULL THEN
                v_is_candidate := TRUE;
            END IF;

            SELECT * INTO v_current_rev
              FROM public.mb13_p3_action_pack_revision r
             WHERE r.pack_id = v_pack.pack_id
               AND r.revision = v_pack.pack_revision;

            IF NOT FOUND THEN
                v_pack_quarantine := TRUE;
                v_pack_reason := 'legacy_recovery_current_revision_missing';
            ELSE
                IF v_pack.owner_user_id IS DISTINCT FROM v_current_rev.owner_user_id
                   OR v_pack.pack_id IS DISTINCT FROM v_current_rev.pack_id
                   OR v_pack.pack_revision IS DISTINCT FROM v_current_rev.revision
                   OR v_pack.monitor_revision IS DISTINCT FROM v_current_rev.monitor_revision
                   OR v_pack.trigger_event_id IS DISTINCT FROM v_current_rev.trigger_event_id
                   OR v_pack.diff_result_id IS DISTINCT FROM v_current_rev.diff_result_id
                   OR v_pack.action_type IS DISTINCT FROM v_current_rev.action_type
                   OR v_pack.target_ref IS DISTINCT FROM v_current_rev.target_ref
                   OR v_pack.consent_refs IS DISTINCT FROM v_current_rev.consent_refs
                   OR v_pack.provenance_refs IS DISTINCT FROM v_current_rev.provenance_refs
                   OR v_pack.steps IS DISTINCT FROM v_current_rev.steps
                   OR v_pack.expires_at IS DISTINCT FROM v_current_rev.expires_at
                THEN
                    v_pack_quarantine := TRUE;
                    v_pack_reason := 'legacy_recovery_current_revision_canonical_mismatch';
                END IF;

                IF NOT v_pack_quarantine THEN
                    BEGIN
                        v_pack_expected := public.mb13_p3_action_pack_payload_hash(
                            v_pack.owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
                            v_pack.trigger_event_id, v_pack.diff_result_id, v_pack.action_type,
                            v_pack.target_ref, v_pack.consent_refs, v_pack.provenance_refs, v_pack.steps,
                            v_pack.expires_at, v_pack.idempotency_key, v_current_rev.status
                        );
                    EXCEPTION WHEN OTHERS THEN
                        v_pack_expected := NULL;
                    END;

                    IF v_pack_expected IS DISTINCT FROM v_pack.payload_hash THEN
                        v_pack_quarantine := TRUE;
                        v_pack_reason := 'legacy_recovery_pack_hash_mismatch';
                    END IF;
                END IF;
            END IF;

            v_rev_count := 0;
            v_revision_ambiguous := FALSE;

            FOR v_rev IN
                SELECT * FROM public.mb13_p3_action_pack_revision
                 WHERE pack_id = v_pack.pack_id
                 ORDER BY revision
            LOOP
                v_rev_count := v_rev_count + 1;

                IF v_rev.revision IS DISTINCT FROM v_rev_count THEN
                    v_chain_gap := TRUE;
                    v_pack_quarantine := TRUE;
                    IF v_pack_reason IS NULL THEN
                        v_pack_reason := 'legacy_recovery_chain_gap';
                    END IF;
                END IF;

                IF v_rev.legacy_idempotency_unverified IS TRUE
                   OR v_rev.legacy_idempotency_quarantined IS TRUE
                   OR v_rev.idempotency_key IS NULL THEN
                    v_is_candidate := TRUE;
                END IF;

                BEGIN
                    v_expected := public.mb13_p3_action_pack_payload_hash(
                        v_rev.owner_user_id, v_pack.monitor_id, v_rev.monitor_revision,
                        v_rev.trigger_event_id, v_rev.diff_result_id, v_rev.action_type,
                        v_rev.target_ref, v_rev.consent_refs, v_rev.provenance_refs, v_rev.steps,
                        v_rev.expires_at, v_rev.idempotency_key, v_rev.status
                    );
                EXCEPTION WHEN OTHERS THEN
                    v_expected := NULL;
                END;

                v_previous_reason := v_rev.legacy_idempotency_quarantine_reason;

                IF v_expected IS DISTINCT FROM v_rev.payload_hash THEN
                    v_revision_ambiguous := TRUE;
                    v_pack_quarantine := TRUE;
                    IF v_pack_reason IS NULL THEN
                        v_pack_reason := 'legacy_recovery_revision_hash_mismatch';
                    END IF;

                    UPDATE public.mb13_p3_action_pack_revision
                       SET legacy_idempotency_quarantined = TRUE,
                           legacy_idempotency_quarantine_reason = 'legacy_recovery_revision_hash_mismatch'
                     WHERE pack_id = v_rev.pack_id
                       AND revision = v_rev.revision;

                    INSERT INTO public.mb13_p3_recovery_audit (
                        migration_name, run_id, pack_id_hash, pack_revision, revision,
                        classification, reason_code, before_hash, after_hash
                    ) VALUES (
                        'migration_v223_mb13_p3_recovery_quarantine_exact_object_ownership_test_integrity_closure.sql',
                        v_run_id, v_pack_hash, v_pack.pack_revision, v_rev.revision,
                        'ambiguous', 'legacy_recovery_revision_hash_mismatch', v_rev.payload_hash, v_expected
                    );
                ELSE
                    -- Hash matches: clear quarantine only if previous reason is in the v223-correctable set
                    IF v_rev.legacy_idempotency_quarantined IS TRUE THEN
                        IF v_previous_reason = ANY(v_correctable_reasons) OR v_previous_reason IS NULL THEN
                            UPDATE public.mb13_p3_action_pack_revision
                               SET legacy_idempotency_quarantined = FALSE,
                                   legacy_idempotency_quarantine_reason = NULL
                             WHERE pack_id = v_rev.pack_id
                               AND revision = v_rev.revision;

                            INSERT INTO public.mb13_p3_recovery_audit (
                                migration_name, run_id, pack_id_hash, pack_revision, revision,
                                classification, reason_code, before_hash, after_hash
                            ) VALUES (
                                'migration_v223_mb13_p3_recovery_quarantine_exact_object_ownership_test_integrity_closure.sql',
                                v_run_id, v_pack_hash, v_pack.pack_revision, v_rev.revision,
                                'verified', 'legacy_recovery_revision_hash_verified', v_rev.payload_hash, v_expected
                            );
                        ELSE
                            INSERT INTO public.mb13_p3_recovery_audit (
                                migration_name, run_id, pack_id_hash, pack_revision, revision,
                                classification, reason_code, before_hash, after_hash
                            ) VALUES (
                                'migration_v223_mb13_p3_recovery_quarantine_exact_object_ownership_test_integrity_closure.sql',
                                v_run_id, v_pack_hash, v_pack.pack_revision, v_rev.revision,
                                'quarantine_preserved', v_previous_reason, v_rev.payload_hash, v_expected
                            );
                        END IF;
                    ELSE
                        INSERT INTO public.mb13_p3_recovery_audit (
                            migration_name, run_id, pack_id_hash, pack_revision, revision,
                            classification, reason_code, before_hash, after_hash
                        ) VALUES (
                            'migration_v223_mb13_p3_recovery_quarantine_exact_object_ownership_test_integrity_closure.sql',
                            v_run_id, v_pack_hash, v_pack.pack_revision, v_rev.revision,
                            'verified', 'legacy_recovery_revision_hash_verified', v_rev.payload_hash, v_expected
                        );
                    END IF;
                END IF;
            END LOOP;

            IF v_rev_count = 0 AND NOT v_pack_quarantine THEN
                v_pack_quarantine := TRUE;
                v_pack_reason := 'legacy_recovery_no_revisions';
            END IF;

            v_previous_reason := v_pack.legacy_idempotency_quarantine_reason;

            IF v_pack_quarantine THEN
                UPDATE public.mb13_p3_action_pack
                   SET legacy_idempotency_quarantined = TRUE,
                       legacy_idempotency_quarantine_reason = v_pack_reason
                 WHERE pack_id = v_pack.pack_id;

                INSERT INTO public.mb13_p3_recovery_audit (
                    migration_name, run_id, pack_id_hash, pack_revision, revision,
                    classification, reason_code, before_hash, after_hash
                ) VALUES (
                    'migration_v223_mb13_p3_recovery_quarantine_exact_object_ownership_test_integrity_closure.sql',
                    v_run_id, v_pack_hash, v_pack.pack_revision, NULL,
                    'quarantined', v_pack_reason, v_pack.payload_hash, NULL
                );
            ELSIF v_is_candidate THEN
                IF v_pack.legacy_idempotency_quarantined IS TRUE
                   AND (v_previous_reason IS NOT NULL AND NOT (v_previous_reason = ANY(v_correctable_reasons))) THEN
                    INSERT INTO public.mb13_p3_recovery_audit (
                        migration_name, run_id, pack_id_hash, pack_revision, revision,
                        classification, reason_code, before_hash, after_hash
                    ) VALUES (
                        'migration_v223_mb13_p3_recovery_quarantine_exact_object_ownership_test_integrity_closure.sql',
                        v_run_id, v_pack_hash, v_pack.pack_revision, NULL,
                        'quarantine_preserved', v_previous_reason, v_pack.payload_hash, NULL
                    );
                ELSE
                    UPDATE public.mb13_p3_action_pack
                       SET legacy_idempotency_quarantined = FALSE,
                           legacy_idempotency_quarantine_reason = NULL
                     WHERE pack_id = v_pack.pack_id;

                    INSERT INTO public.mb13_p3_recovery_audit (
                        migration_name, run_id, pack_id_hash, pack_revision, revision,
                        classification, reason_code, before_hash, after_hash
                    ) VALUES (
                        'migration_v223_mb13_p3_recovery_quarantine_exact_object_ownership_test_integrity_closure.sql',
                        v_run_id, v_pack_hash, v_pack.pack_revision, NULL,
                        'candidate', 'legacy_recovery_chain_verified', v_pack.payload_hash, NULL
                    );
                END IF;
            ELSE
                IF v_pack.legacy_idempotency_quarantined IS TRUE
                   AND (v_previous_reason IS NOT NULL AND NOT (v_previous_reason = ANY(v_correctable_reasons))) THEN
                    INSERT INTO public.mb13_p3_recovery_audit (
                        migration_name, run_id, pack_id_hash, pack_revision, revision,
                        classification, reason_code, before_hash, after_hash
                    ) VALUES (
                        'migration_v223_mb13_p3_recovery_quarantine_exact_object_ownership_test_integrity_closure.sql',
                        v_run_id, v_pack_hash, v_pack.pack_revision, NULL,
                        'quarantine_preserved', v_previous_reason, v_pack.payload_hash, NULL
                    );
                ELSE
                    IF v_pack.legacy_idempotency_quarantined IS TRUE THEN
                        UPDATE public.mb13_p3_action_pack
                           SET legacy_idempotency_quarantined = FALSE,
                               legacy_idempotency_quarantine_reason = NULL
                         WHERE pack_id = v_pack.pack_id;
                    END IF;

                    INSERT INTO public.mb13_p3_recovery_audit (
                        migration_name, run_id, pack_id_hash, pack_revision, revision,
                        classification, reason_code, before_hash, after_hash
                    ) VALUES (
                        'migration_v223_mb13_p3_recovery_quarantine_exact_object_ownership_test_integrity_closure.sql',
                        v_run_id, v_pack_hash, v_pack.pack_revision, NULL,
                        'skipped', 'legacy_recovery_skipped', v_pack.payload_hash, NULL
                    );
                END IF;
            END IF;

        EXCEPTION WHEN OTHERS THEN
            -- Atomic quarantine: update pack and current revision, insert audit, then continue.
            -- If quarantine itself fails, abort the migration.
            BEGIN
                UPDATE public.mb13_p3_action_pack
                   SET legacy_idempotency_quarantined = TRUE,
                       legacy_idempotency_quarantine_reason = 'legacy_recovery_exception'
                 WHERE pack_id = v_pack.pack_id;

                UPDATE public.mb13_p3_action_pack_revision
                   SET legacy_idempotency_quarantined = TRUE,
                       legacy_idempotency_quarantine_reason = 'legacy_recovery_exception'
                 WHERE pack_id = v_pack.pack_id
                   AND revision = v_pack.pack_revision;

                INSERT INTO public.mb13_p3_recovery_audit (
                    migration_name, run_id, pack_id_hash, pack_revision, revision,
                    classification, reason_code, before_hash, after_hash
                ) VALUES (
                    'migration_v223_mb13_p3_recovery_quarantine_exact_object_ownership_test_integrity_closure.sql',
                    v_run_id, v_pack_hash, v_pack.pack_revision, v_pack.pack_revision,
                    'quarantined', 'legacy_recovery_exception', v_pack.payload_hash, NULL
                );
            EXCEPTION WHEN OTHERS THEN
                RAISE EXCEPTION 'migration_v223 quarantine of pack % failed: %', v_pack.pack_id, SQLERRM;
            END;
        END;
    END LOOP;

    ALTER TABLE public.mb13_p3_action_pack ENABLE TRIGGER USER;
    ALTER TABLE public.mb13_p3_action_pack_revision ENABLE TRIGGER USER;
END $$;

-- ============================================================================
-- 12. Strip the superseded single lifecycle owner role of any residual
--     ownership/privileges in the current database; it is kept defunct.
-- ============================================================================
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p3_pack_lifecycle_owner') THEN
        REASSIGN OWNED BY mb13_p3_pack_lifecycle_owner TO mb13_p3_pack_data_owner;
        DROP OWNED BY mb13_p3_pack_lifecycle_owner;
    END IF;
END $$;

COMMIT;
