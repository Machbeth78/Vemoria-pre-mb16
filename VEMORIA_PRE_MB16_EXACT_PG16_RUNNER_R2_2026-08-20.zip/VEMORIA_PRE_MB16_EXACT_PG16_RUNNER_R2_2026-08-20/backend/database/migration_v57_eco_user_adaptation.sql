-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V57 — ECO User Adaptation Core V1

CREATE TABLE IF NOT EXISTS eco_user_voice_profiles (
    utente_id                    UUID PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    phonetic_learning_count      INTEGER NOT NULL DEFAULT 0,
    correction_count             INTEGER NOT NULL DEFAULT 0,
    semantic_ref_learning_count  INTEGER NOT NULL DEFAULT 0,
    screen_habit_learning_count  INTEGER NOT NULL DEFAULT 0,
    last_seen_at                 TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at                   TIMESTAMP NOT NULL DEFAULT NOW(),
    created_at                   TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS eco_adaptation_feedback (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id        UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    session_id       UUID REFERENCES eco_sessions(id) ON DELETE SET NULL,
    utterance_id     UUID REFERENCES eco_utterances(id) ON DELETE SET NULL,
    signal_type      TEXT NOT NULL,
    category         TEXT NOT NULL,
    learned_key      TEXT NOT NULL,
    learned_value    TEXT,
    context_scope    TEXT,
    source_event     TEXT NOT NULL DEFAULT 'voice_turn',
    evidence_weight  REAL NOT NULL DEFAULT 1.0,
    confidence_delta REAL NOT NULL DEFAULT 0.0,
    payload_json     JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at       TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_eco_adaptation_feedback_user_time
    ON eco_adaptation_feedback(utente_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_adaptation_feedback_category
    ON eco_adaptation_feedback(utente_id, category, signal_type, created_at DESC);

CREATE TABLE IF NOT EXISTS eco_screen_action_habits (
    utente_id        UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    screen_id        TEXT NOT NULL,
    action_code      TEXT NOT NULL,
    usage_count      INTEGER NOT NULL DEFAULT 0,
    success_count    INTEGER NOT NULL DEFAULT 0,
    correction_count INTEGER NOT NULL DEFAULT 0,
    strength_score   REAL NOT NULL DEFAULT 0.0,
    last_used_at     TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMP NOT NULL DEFAULT NOW(),
    created_at       TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (utente_id, screen_id, action_code)
);

CREATE INDEX IF NOT EXISTS idx_eco_screen_action_habits_strength
    ON eco_screen_action_habits(utente_id, screen_id, strength_score DESC, last_used_at DESC);

CREATE TABLE IF NOT EXISTS eco_semantic_ref_learning (
    utente_id          UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    semantic_period_ref TEXT NOT NULL,
    short_label        TEXT NOT NULL,
    context_scope      TEXT NOT NULL DEFAULT '',
    usage_count        INTEGER NOT NULL DEFAULT 0,
    correction_count   INTEGER NOT NULL DEFAULT 0,
    strength_score     REAL NOT NULL DEFAULT 0.0,
    last_seen_at       TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMP NOT NULL DEFAULT NOW(),
    created_at         TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (utente_id, semantic_period_ref, context_scope)
);

CREATE INDEX IF NOT EXISTS idx_eco_semantic_ref_learning_strength
    ON eco_semantic_ref_learning(utente_id, strength_score DESC, last_seen_at DESC);
