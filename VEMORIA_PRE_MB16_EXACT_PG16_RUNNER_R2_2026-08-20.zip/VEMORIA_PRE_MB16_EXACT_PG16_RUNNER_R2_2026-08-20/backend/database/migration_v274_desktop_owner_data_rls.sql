-- Vemoria MB0→MB15 audit convergence — Desktop owner-data RLS.
-- These tables are accessed only after a mobile JWT or verified Desktop session
-- has established app.owner_id. Pairing bootstrap/device identity tables are
-- intentionally excluded because they participate in pre-owner token lookup.
BEGIN;

ALTER TABLE desktop_import_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE desktop_import_queue FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS desktop_import_queue_owner_isolation ON desktop_import_queue;
CREATE POLICY desktop_import_queue_owner_isolation ON desktop_import_queue
    USING (utente_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (utente_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

ALTER TABLE desktop_transfer_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE desktop_transfer_log FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS desktop_transfer_log_owner_isolation ON desktop_transfer_log;
CREATE POLICY desktop_transfer_log_owner_isolation ON desktop_transfer_log
    USING (utente_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (utente_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

ALTER TABLE desktop_document_pins ENABLE ROW LEVEL SECURITY;
ALTER TABLE desktop_document_pins FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS desktop_document_pins_owner_isolation ON desktop_document_pins;
CREATE POLICY desktop_document_pins_owner_isolation ON desktop_document_pins
    USING (utente_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (utente_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

COMMIT;
