-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB11-P2 Phase A R1D — Trusted R1F source-card authority repository.
-- Additive, idempotent. Trusted resolver only; client self-certification is not stored.

BEGIN;

CREATE TABLE IF NOT EXISTS canonical_source_card_authority (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    source_card_id TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('active','inactive')),
    officiality TEXT NOT NULL CHECK (officiality IN ('official','delegated','authorized_network','candidate')),
    source_state TEXT NOT NULL CHECK (source_state IN ('active','revoked','suspended')),
    brand_manufacturer_binding TEXT NOT NULL CHECK (brand_manufacturer_binding IN ('verified','candidate','unknown')),
    consent_scope TEXT NOT NULL,
    revocation_state TEXT NOT NULL CHECK (revocation_state IN ('valid','revoked')),
    ambiguity_result TEXT NOT NULL CHECK (ambiguity_result IN ('unambiguous','ambiguous','conflicting')),
    brand_id TEXT,
    official_domain TEXT,
    authorized_identifier_value TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, source_card_id)
);

ALTER TABLE canonical_source_card_authority ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_source_card_authority FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS canonical_source_card_authority_owner_policy ON canonical_source_card_authority;
CREATE POLICY canonical_source_card_authority_owner_policy ON canonical_source_card_authority
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

COMMIT;
