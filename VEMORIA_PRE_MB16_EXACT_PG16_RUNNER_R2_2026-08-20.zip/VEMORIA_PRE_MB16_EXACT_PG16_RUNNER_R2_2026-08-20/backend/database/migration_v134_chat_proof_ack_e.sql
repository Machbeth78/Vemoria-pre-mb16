-- VEMORIA Chat Macro E - proof/acknowledgement separation
-- Runtime not executed.

CREATE TABLE IF NOT EXISTS chat_message_proof_ack_states (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL,
    thread_id UUID,
    message_id UUID,
    delivery_state TEXT NOT NULL CHECK (delivery_state IN ('SENT','DELIVERED','READ','ACKNOWLEDGED','PROOF_BUNDLE')),
    proof_origin TEXT NOT NULL DEFAULT 'NONE' CHECK (proof_origin IN ('NONE','PROTECTED_SEND','SIGNATURE_FLOW','ACCEPTANCE_FLOW','DELIVERY_PROOF_BUNDLE')),
    proof_bundle_hash TEXT,
    read_is_acknowledgement BOOLEAN NOT NULL DEFAULT FALSE,
    acknowledgement_is_proof BOOLEAN NOT NULL DEFAULT FALSE,
    translated_view_is_not_acknowledgement BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (read_is_acknowledgement = FALSE),
    CHECK (acknowledgement_is_proof = FALSE),
    CHECK (translated_view_is_not_acknowledgement = TRUE),
    CHECK (NOT (delivery_state = 'PROOF_BUNDLE' AND proof_origin = 'NONE'))
);
