-- MB0→MB15 convergence: Desktop pairing bootstrap/session authority hardening.
BEGIN;

ALTER TABLE desktop_pairing_requests
    ADD COLUMN IF NOT EXISTS poll_secret_hash TEXT,
    ADD COLUMN IF NOT EXISTS session_token_digest TEXT,
    ADD COLUMN IF NOT EXISTS session_delivered_at TIMESTAMP;

-- Convert any historical plaintext session credential to a digest, then erase it.
UPDATE desktop_pairing_requests
SET session_token_digest = COALESCE(session_token_digest, encode(digest(session_token, 'sha256'), 'hex'))
WHERE session_token IS NOT NULL AND session_token <> '';
UPDATE desktop_pairing_requests SET session_token = NULL WHERE session_token IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_desktop_pair_req_session_digest
    ON desktop_pairing_requests(session_token_digest)
    WHERE session_token_digest IS NOT NULL;

COMMIT;
