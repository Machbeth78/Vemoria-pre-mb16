-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V4.0 — Migration V21 — Storage Architecture
ALTER TABLE documenti
    ADD COLUMN IF NOT EXISTS storage_tier   TEXT NOT NULL DEFAULT 'HOT',
    ADD COLUMN IF NOT EXISTS last_accessed  TIMESTAMP,
    ADD COLUMN IF NOT EXISTS access_count   INTEGER NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_doc_tier         ON documenti(storage_tier);
CREATE INDEX IF NOT EXISTS idx_doc_last_accessed ON documenti(last_accessed DESC);
CREATE INDEX IF NOT EXISTS idx_doc_access_count  ON documenti(access_count DESC);
