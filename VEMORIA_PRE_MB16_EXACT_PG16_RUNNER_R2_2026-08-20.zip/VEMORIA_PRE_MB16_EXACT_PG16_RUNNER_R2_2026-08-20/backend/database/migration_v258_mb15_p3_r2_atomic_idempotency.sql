-- MB15-P3-R2 — Atomic idempotency reservation and key length bound

BEGIN;

-- Ensure the idempotency partial index can be used for ON CONFLICT.
-- Drop and recreate as a unique partial index with an explicit predicate.
DROP INDEX IF EXISTS idx_mb15_p3_goal_executions_idempotency;
CREATE UNIQUE INDEX idx_mb15_p3_goal_executions_idempotency
    ON mb15_p3_goal_executions (owner_id, idempotency_key)
    WHERE idempotency_key IS NOT NULL;

-- Bound idempotency key length at the database level.
ALTER TABLE mb15_p3_goal_executions
    ADD CONSTRAINT chk_mb15_p3_goal_executions_idempotency_key_length
    CHECK (idempotency_key IS NULL OR length(idempotency_key) <= 256);

COMMIT;
