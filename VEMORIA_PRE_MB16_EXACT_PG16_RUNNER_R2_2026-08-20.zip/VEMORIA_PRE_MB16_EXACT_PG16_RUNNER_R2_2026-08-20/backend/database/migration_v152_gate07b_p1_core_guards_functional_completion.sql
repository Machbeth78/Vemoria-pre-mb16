-- Vemoria Gate07B — P1 Core Guards functional completion
-- Static schema marker only. Does not claim Android/PostgreSQL/Cerebro runtime PASS.

CREATE TABLE IF NOT EXISTS gate07b_p1_core_guards_functional_completion (
    vc_id TEXT PRIMARY KEY,
    integration_state TEXT NOT NULL CHECK (integration_state = 'CODICE_INTEGRATO'),
    runtime_state TEXT NOT NULL CHECK (runtime_state <> 'PASS'),
    completion_state TEXT NOT NULL CHECK (completion_state = 'FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED'),
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE CHECK (runtime_pass_claimed = FALSE),
    completed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO gate07b_p1_core_guards_functional_completion (vc_id, integration_state, runtime_state, completion_state, runtime_pass_claimed) VALUES
('VC-014','CODICE_INTEGRATO','NON_ESEGUITO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED', FALSE),
('VC-019','CODICE_INTEGRATO','NON_ESEGUITO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED', FALSE),
('VC-020','CODICE_INTEGRATO','NON_ESEGUITO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED', FALSE),
('VC-015','CODICE_INTEGRATO','NON_ESEGUITO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED', FALSE),
('VC-016','CODICE_INTEGRATO','NON_ESEGUITO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED', FALSE),
('VC-017','CODICE_INTEGRATO','NON_ESEGUITO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED', FALSE),
('VC-021','CODICE_INTEGRATO','NON_ESEGUITO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED', FALSE)
ON CONFLICT (vc_id) DO UPDATE SET
    integration_state = EXCLUDED.integration_state,
    runtime_state = EXCLUDED.runtime_state,
    completion_state = EXCLUDED.completion_state,
    runtime_pass_claimed = FALSE;
