-- VEMORA — Nucleo Memoria Operativa hardening V4
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo

-- Index per deduplicazione logica timeline via fingerprint nel payload JSON.
CREATE INDEX IF NOT EXISTS idx_nm_timeline_shadow_fingerprint
    ON nm_timeline_events (source_module, event_type, COALESCE(event_subtype, ''), (payload_json->>'_shadow_fingerprint'));

-- Index per merge relazioni ricorrenti.
CREATE INDEX IF NOT EXISTS idx_nm_relations_compound_key
    ON nm_relations (left_type, left_id, relation_type, right_type, right_id);

-- Index per lookup/update contesto breve.
CREATE INDEX IF NOT EXISTS idx_nm_session_context_scope_key
    ON nm_session_context (context_key, session_id, user_ref, device_ref);
