-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V54 — ECO Camere Ancora / Maturazione storica

CREATE TABLE IF NOT EXISTS eco_anchor_memories (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    anchor_identity     TEXT NOT NULL,
    anchor_label        TEXT NOT NULL,
    anchor_type         TEXT NOT NULL DEFAULT 'generic',
    maturity_level      TEXT NOT NULL DEFAULT 'debole',
    maturity_score      REAL NOT NULL DEFAULT 0.0,
    evidence_count      INTEGER NOT NULL DEFAULT 1,
    recurrence_sessions INTEGER NOT NULL DEFAULT 1,
    linked_entity_type  TEXT,
    linked_entity_id    UUID,
    last_session_id     UUID REFERENCES eco_sessions(id) ON DELETE SET NULL,
    first_seen_at       TIMESTAMP NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMP NOT NULL DEFAULT NOW(),
    reason_codes        JSONB NOT NULL DEFAULT '[]'::jsonb,
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, anchor_identity)
);

CREATE INDEX IF NOT EXISTS idx_eco_anchor_memories_user_score
    ON eco_anchor_memories(utente_id, maturity_score DESC, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_anchor_memories_label
    ON eco_anchor_memories(anchor_label, updated_at DESC);
