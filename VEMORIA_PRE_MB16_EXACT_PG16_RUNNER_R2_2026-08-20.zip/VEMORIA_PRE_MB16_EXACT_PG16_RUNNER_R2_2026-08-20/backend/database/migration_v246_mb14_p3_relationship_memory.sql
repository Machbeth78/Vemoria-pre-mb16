-- ===========================================================================
-- VEMORA V246 — MB14-P3 Relationship Memory + Temporal Intelligence
-- ===========================================================================
-- Scope:
--   1. relationship memory item, commitment, decision, open-loop tables.
--   2. Document version / supersession tracking per relationship.
--   3. Status social layer with privacy-governed visibility and expiry.
--   4. Relationship meaningful-activity ordering and row-level signal support.
--   5. RLS owner isolation + diagnostic traceability.
--
-- NON modifica MB0→MB13 / MB14-P0/P1/P2; solo additive.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- 1. relationship: add meaningful activity timestamp
-- ---------------------------------------------------------------------------
ALTER TABLE relationship
    ADD COLUMN IF NOT EXISTS last_meaningful_activity_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS last_meaningful_activity_type TEXT,
    ADD COLUMN IF NOT EXISTS memory_summary JSONB NOT NULL DEFAULT '{}'::jsonb;

-- Backfill existing rows so ordering works.
UPDATE relationship
SET last_meaningful_activity_at = COALESCE(updated_at, created_at)
WHERE last_meaningful_activity_at IS NULL;

-- ---------------------------------------------------------------------------
-- 2. relationship_memory_item
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_memory_item (
    memory_item_id      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id     UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    memory_type         TEXT NOT NULL
        CHECK (memory_type IN (
            'MESSAGE_FACT','DOCUMENT_EVENT','DECISION','COMMITMENT','DEADLINE',
            'ACTION','ROLE_CHANGE','ORGANIZATION_CHANGE','CONTACT_CHANGE',
            'STATUS_EVENT','NOTE','USER_CONFIRMED_FACT'
        )),
    source_event_id     TEXT,
    source_reference    JSONB NOT NULL DEFAULT '{}'::jsonb,
    event_time          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    recorded_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    confidence          TEXT NOT NULL DEFAULT 'EXTRACTED'
        CHECK (confidence IN ('OBSERVED','USER_CONFIRMED','EXTRACTED','INFERRED','DISPUTED','SUPERSEDED','REVOKED')),
    provenance          JSONB NOT NULL DEFAULT '{}'::jsonb,
    supersedes_id       UUID REFERENCES relationship_memory_item(memory_item_id) ON DELETE SET NULL,
    valid_from          TIMESTAMPTZ,
    valid_to            TIMESTAMPTZ,
    status              TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active','superseded','revoked','disputed')),
    description         TEXT NOT NULL DEFAULT '',
    payload             JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_relationship_memory_owner_rel
    ON relationship_memory_item(owner_user_id, relationship_id, event_time DESC);
CREATE INDEX IF NOT EXISTS idx_relationship_memory_type
    ON relationship_memory_item(owner_user_id, memory_type, event_time DESC);
CREATE INDEX IF NOT EXISTS idx_relationship_memory_supersedes
    ON relationship_memory_item(owner_user_id, supersedes_id);
CREATE INDEX IF NOT EXISTS idx_relationship_memory_status
    ON relationship_memory_item(owner_user_id, status, event_time DESC);

-- ---------------------------------------------------------------------------
-- 3. relationship_commitment
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_commitment (
    commitment_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id     UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    memory_item_id      UUID REFERENCES relationship_memory_item(memory_item_id) ON DELETE SET NULL,
    actor_reference     TEXT NOT NULL DEFAULT 'relationship',
    description         TEXT NOT NULL,
    created_from        TEXT NOT NULL DEFAULT '',
    due_at              TIMESTAMPTZ,
    status              TEXT NOT NULL DEFAULT 'OPEN'
        CHECK (status IN ('OPEN','FULFILLED','CANCELLED','OVERDUE','DISPUTED','UNKNOWN')),
    fulfilled_at        TIMESTAMPTZ,
    resolved_at         TIMESTAMPTZ,
    evidence            JSONB NOT NULL DEFAULT '{}'::jsonb,
    provenance          JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_relationship_commitment_owner_rel
    ON relationship_commitment(owner_user_id, relationship_id, status, due_at);
CREATE INDEX IF NOT EXISTS idx_relationship_commitment_open
    ON relationship_commitment(owner_user_id, relationship_id, status)
    WHERE status = 'OPEN';
CREATE INDEX IF NOT EXISTS idx_relationship_commitment_due
    ON relationship_commitment(owner_user_id, relationship_id, due_at)
    WHERE status = 'OPEN';

-- ---------------------------------------------------------------------------
-- 4. relationship_decision
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_decision (
    decision_id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id     UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    memory_item_id      UUID REFERENCES relationship_memory_item(memory_item_id) ON DELETE SET NULL,
    description         TEXT NOT NULL,
    participants        JSONB NOT NULL DEFAULT '[]'::jsonb,
    source_evidence     JSONB NOT NULL DEFAULT '{}'::jsonb,
    confidence          TEXT NOT NULL DEFAULT 'USER_CONFIRMED'
        CHECK (confidence IN ('OBSERVED','USER_CONFIRMED','EXTRACTED','INFERRED','DISPUTED','SUPERSEDED')),
    provenance          JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_relationship_decision_owner_rel
    ON relationship_decision(owner_user_id, relationship_id, created_at DESC);

-- ---------------------------------------------------------------------------
-- 5. relationship_open_loop
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_open_loop (
    open_loop_id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id     UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    loop_type           TEXT NOT NULL
        CHECK (loop_type IN ('PROMISE','QUESTION','MISSING_DOCUMENT','DEADLINE','ACTION')),
    description         TEXT NOT NULL,
    evidence            JSONB NOT NULL DEFAULT '{}'::jsonb,
    status              TEXT NOT NULL DEFAULT 'OPEN'
        CHECK (status IN ('OPEN','CLOSED','CONVERTED')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at         TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_relationship_open_loop_owner_rel
    ON relationship_open_loop(owner_user_id, relationship_id, status, created_at DESC);

-- ---------------------------------------------------------------------------
-- 6. relationship_document_version
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_document_version (
    version_id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id     UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    document_id         TEXT NOT NULL,
    version_number      INTEGER NOT NULL DEFAULT 1,
    supersedes_version_id UUID REFERENCES relationship_document_version(version_id) ON DELETE SET NULL,
    source_event_id     TEXT,
    provenance          JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (owner_user_id, document_id, version_number)
);

CREATE INDEX IF NOT EXISTS idx_relationship_doc_version_owner_doc
    ON relationship_document_version(owner_user_id, relationship_id, document_id, version_number DESC);

-- ---------------------------------------------------------------------------
-- 7. relationship_status
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_status (
    status_id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    author_identity     TEXT NOT NULL DEFAULT 'owner',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at          TIMESTAMPTZ,
    visibility_scope    TEXT NOT NULL DEFAULT 'PRIVATE'
        CHECK (visibility_scope IN ('PRIVATE','SELECTED_RELATIONSHIPS','CONTACTS','CUSTOM_LIST','PRIVATE_TEST')),
    content_type        TEXT NOT NULL DEFAULT 'TEXT'
        CHECK (content_type IN ('TEXT','IMAGE','CARD')),
    content_reference   TEXT,
    payload             JSONB NOT NULL DEFAULT '{}'::jsonb,
    provenance          JSONB NOT NULL DEFAULT '{}'::jsonb,
    state               TEXT NOT NULL DEFAULT 'active'
        CHECK (state IN ('active','expired','revoked','viewed'))
);

CREATE INDEX IF NOT EXISTS idx_relationship_status_owner_active
    ON relationship_status(owner_user_id, state, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_relationship_status_expires
    ON relationship_status(owner_user_id, expires_at)
    WHERE state = 'active';

-- status audience mapping (only for non-PRIVATE scopes)
CREATE TABLE IF NOT EXISTS relationship_status_audience (
    audience_id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    status_id           UUID NOT NULL REFERENCES relationship_status(status_id) ON DELETE CASCADE,
    relationship_id     UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (owner_user_id, status_id, relationship_id)
);

CREATE INDEX IF NOT EXISTS idx_relationship_status_audience
    ON relationship_status_audience(owner_user_id, relationship_id, status_id);

-- ---------------------------------------------------------------------------
-- 8. relationship_status_reply
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_status_reply (
    reply_id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    status_id           UUID NOT NULL REFERENCES relationship_status(status_id) ON DELETE CASCADE,
    relationship_id     UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    conversation_id     UUID REFERENCES conversation(conversation_id) ON DELETE SET NULL,
    reply_body          TEXT NOT NULL DEFAULT '',
    reply_context       JSONB NOT NULL DEFAULT '{}'::jsonb,
    provenance          JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_relationship_status_reply
    ON relationship_status_reply(owner_user_id, status_id, created_at DESC);

-- ---------------------------------------------------------------------------
-- 9. Trigger: meaningful activity updates relationship.last_meaningful_activity_at
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION relationship_update_meaningful_activity()
RETURNS TRIGGER AS $$
DECLARE
    v_relationship_id UUID;
    v_activity_type TEXT;
BEGIN
    IF TG_TABLE_NAME = 'conversation_message' THEN
        -- Only meaningful send/queue/read states, not draft noise.
        IF NEW.delivery_state IN ('SENT','QUEUED','READ','RECEIVED') AND NEW.direction IN ('INBOUND','OUTBOUND') THEN
            SELECT relationship_id INTO v_relationship_id
            FROM conversation
            WHERE conversation_id = NEW.conversation_id AND owner_user_id = NEW.owner_user_id;
            v_activity_type := 'message_' || lower(NEW.delivery_state);
        END IF;
    ELSIF TG_TABLE_NAME = 'relationship_memory_item' THEN
        v_relationship_id := NEW.relationship_id;
        v_activity_type := lower(NEW.memory_type);
    ELSIF TG_TABLE_NAME = 'relationship_status' THEN
        -- status creation is meaningful; views/replies are handled by their own inserts.
        IF NEW.state = 'active' THEN
            -- author_identity may be a relationship_id (status from that person)
            v_relationship_id := NULLIF(NEW.author_identity, 'owner')::uuid;
        END IF;
    ELSIF TG_TABLE_NAME = 'relationship_status_reply' THEN
        v_relationship_id := NEW.relationship_id;
        v_activity_type := 'status_reply';
    ELSIF TG_TABLE_NAME = 'relationship_commitment' THEN
        v_relationship_id := NEW.relationship_id;
        v_activity_type := 'commitment_' || lower(NEW.status);
    END IF;

    IF v_relationship_id IS NOT NULL THEN
        UPDATE relationship
        SET last_meaningful_activity_at = GREATEST(clock_timestamp(), COALESCE(last_meaningful_activity_at, '1970-01-01')),
            last_meaningful_activity_type = v_activity_type
        WHERE relationship_id = v_relationship_id
          AND owner_user_id = NEW.owner_user_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_relationship_meaningful_message ON conversation_message;
CREATE TRIGGER trg_relationship_meaningful_message
    AFTER UPDATE OF delivery_state ON conversation_message
    FOR EACH ROW
    WHEN (NEW.delivery_state IN ('SENT','QUEUED','READ','RECEIVED'))
    EXECUTE FUNCTION relationship_update_meaningful_activity();

DROP TRIGGER IF EXISTS trg_relationship_meaningful_memory ON relationship_memory_item;
CREATE TRIGGER trg_relationship_meaningful_memory
    AFTER INSERT ON relationship_memory_item
    FOR EACH ROW
    EXECUTE FUNCTION relationship_update_meaningful_activity();

DROP TRIGGER IF EXISTS trg_relationship_meaningful_commitment ON relationship_commitment;
CREATE TRIGGER trg_relationship_meaningful_commitment
    AFTER INSERT OR UPDATE OF status ON relationship_commitment
    FOR EACH ROW
    EXECUTE FUNCTION relationship_update_meaningful_activity();

DROP TRIGGER IF EXISTS trg_relationship_meaningful_status ON relationship_status;
CREATE TRIGGER trg_relationship_meaningful_status
    AFTER INSERT ON relationship_status
    FOR EACH ROW
    EXECUTE FUNCTION relationship_update_meaningful_activity();

DROP TRIGGER IF EXISTS trg_relationship_meaningful_status_reply ON relationship_status_reply;
CREATE TRIGGER trg_relationship_meaningful_status_reply
    AFTER INSERT ON relationship_status_reply
    FOR EACH ROW
    EXECUTE FUNCTION relationship_update_meaningful_activity();

-- ---------------------------------------------------------------------------
-- 10. Extend relationship_timeline_event types
-- ---------------------------------------------------------------------------
ALTER TABLE relationship_timeline_event
    DROP CONSTRAINT IF EXISTS relationship_timeline_event_event_type_check;
ALTER TABLE relationship_timeline_event
    ADD CONSTRAINT relationship_timeline_event_event_type_check
    CHECK (event_type IN (
        'contact_added','role_changed','message_received','document_shared',
        'commitment_created','deadline_created','action_completed','relationship_created',
        'archive','sharing_revoked','consent_changed','import_candidate',
        'memory_created','commitment_fulfilled','commitment_overdue','decision_created',
        'status_created','status_viewed','status_replied','memory_superseded','memory_corrected'
    ));

-- ---------------------------------------------------------------------------
-- 11. Extend conversation_timeline_event types
-- ---------------------------------------------------------------------------
ALTER TABLE conversation_timeline_event
    DROP CONSTRAINT IF EXISTS conversation_timeline_event_event_type_check;
ALTER TABLE conversation_timeline_event
    ADD CONSTRAINT conversation_timeline_event_event_type_check
    CHECK (event_type IN (
        'conversation_created','message_drafted','message_authorized','message_queued',
        'message_sent','message_failed','message_received','message_read','conversation_archived',
        'attachment_added','document_card_sent','document_card_received','sharing_grant_created',
        'sharing_revoked','card_validation_failed','memory_extracted','commitment_extracted',
        'decision_extracted','document_versioned'
    ));

-- ---------------------------------------------------------------------------
-- 12. Diagnostic traceability (MB14.MEMORY.*, MB14.COMMITMENT.*, MB14.TIMELINE.*, MB14.STATUS.*)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mb14_relationship_memory_diagnostic (
    diagnostic_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id     UUID REFERENCES relationship(relationship_id) ON DELETE SET NULL,
    memory_item_id      UUID REFERENCES relationship_memory_item(memory_item_id) ON DELETE SET NULL,
    commitment_id       UUID REFERENCES relationship_commitment(commitment_id) ON DELETE SET NULL,
    status_id           UUID REFERENCES relationship_status(status_id) ON DELETE SET NULL,
    event_code          TEXT NOT NULL,
    status              TEXT NOT NULL,
    severity            TEXT NOT NULL DEFAULT 'info',
    payload_json        JSONB NOT NULL DEFAULT '{}'::jsonb,
    timestamp_utc       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mb14_rel_memory_diag_owner_code
    ON mb14_relationship_memory_diagnostic(owner_user_id, event_code, timestamp_utc DESC);
CREATE INDEX IF NOT EXISTS idx_mb14_rel_memory_diag_rel
    ON mb14_relationship_memory_diagnostic(owner_user_id, relationship_id, timestamp_utc DESC);

-- ---------------------------------------------------------------------------
-- 13. RLS owner isolation
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    -- relationship_memory_item
    ALTER TABLE relationship_memory_item ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship_memory_item FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_memory_item_owner_isolation ON relationship_memory_item;
    CREATE POLICY relationship_memory_item_owner_isolation ON relationship_memory_item
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND relationship_id IN (SELECT relationship_id FROM relationship)
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND relationship_id IN (SELECT relationship_id FROM relationship)
        );

    -- relationship_commitment
    ALTER TABLE relationship_commitment ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship_commitment FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_commitment_owner_isolation ON relationship_commitment;
    CREATE POLICY relationship_commitment_owner_isolation ON relationship_commitment
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND relationship_id IN (SELECT relationship_id FROM relationship)
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND relationship_id IN (SELECT relationship_id FROM relationship)
        );

    -- relationship_decision
    ALTER TABLE relationship_decision ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship_decision FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_decision_owner_isolation ON relationship_decision;
    CREATE POLICY relationship_decision_owner_isolation ON relationship_decision
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND relationship_id IN (SELECT relationship_id FROM relationship)
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND relationship_id IN (SELECT relationship_id FROM relationship)
        );

    -- relationship_open_loop
    ALTER TABLE relationship_open_loop ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship_open_loop FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_open_loop_owner_isolation ON relationship_open_loop;
    CREATE POLICY relationship_open_loop_owner_isolation ON relationship_open_loop
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND relationship_id IN (SELECT relationship_id FROM relationship)
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND relationship_id IN (SELECT relationship_id FROM relationship)
        );

    -- relationship_document_version
    ALTER TABLE relationship_document_version ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship_document_version FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_document_version_owner_isolation ON relationship_document_version;
    CREATE POLICY relationship_document_version_owner_isolation ON relationship_document_version
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND relationship_id IN (SELECT relationship_id FROM relationship)
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND relationship_id IN (SELECT relationship_id FROM relationship)
        );

    -- relationship_status
    ALTER TABLE relationship_status ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship_status FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_status_owner_isolation ON relationship_status;
    CREATE POLICY relationship_status_owner_isolation ON relationship_status
        FOR ALL
        USING (owner_user_id = _rls_owner_uuid())
        WITH CHECK (owner_user_id = _rls_owner_uuid());

    -- relationship_status_audience
    ALTER TABLE relationship_status_audience ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship_status_audience FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_status_audience_owner_isolation ON relationship_status_audience;
    CREATE POLICY relationship_status_audience_owner_isolation ON relationship_status_audience
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND status_id IN (SELECT status_id FROM relationship_status)
            AND relationship_id IN (SELECT relationship_id FROM relationship)
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND status_id IN (SELECT status_id FROM relationship_status)
            AND relationship_id IN (SELECT relationship_id FROM relationship)
        );

    -- relationship_status_reply
    ALTER TABLE relationship_status_reply ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship_status_reply FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_status_reply_owner_isolation ON relationship_status_reply;
    CREATE POLICY relationship_status_reply_owner_isolation ON relationship_status_reply
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND status_id IN (SELECT status_id FROM relationship_status)
            AND relationship_id IN (SELECT relationship_id FROM relationship)
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND status_id IN (SELECT status_id FROM relationship_status)
            AND relationship_id IN (SELECT relationship_id FROM relationship)
        );

    -- mb14_relationship_memory_diagnostic
    ALTER TABLE mb14_relationship_memory_diagnostic ENABLE ROW LEVEL SECURITY;
    ALTER TABLE mb14_relationship_memory_diagnostic FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS mb14_rel_memory_diag_owner_isolation ON mb14_relationship_memory_diagnostic;
    CREATE POLICY mb14_rel_memory_diag_owner_isolation ON mb14_relationship_memory_diagnostic
        FOR ALL
        USING (owner_user_id = _rls_owner_uuid())
        WITH CHECK (owner_user_id = _rls_owner_uuid());
END $$;

-- ---------------------------------------------------------------------------
-- 14. Least-privilege grants
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p2_api') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship_memory_item TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship_commitment TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship_decision TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship_open_loop TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship_document_version TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship_status TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship_status_audience TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship_status_reply TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE mb14_relationship_memory_diagnostic TO mb13_p2_api;
    END IF;
END $$;
