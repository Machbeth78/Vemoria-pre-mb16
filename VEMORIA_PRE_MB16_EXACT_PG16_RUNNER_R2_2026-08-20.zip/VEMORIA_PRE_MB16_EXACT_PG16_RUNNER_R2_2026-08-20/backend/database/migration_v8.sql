-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V2.6 — Migration V8 — Capacità dispositivo
ALTER TABLE dispositivi_utente
    ADD COLUMN IF NOT EXISTS camera_ok  BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS mic_ok     BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS file_ok    BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS pdf_ok     BOOLEAN NOT NULL DEFAULT TRUE;
