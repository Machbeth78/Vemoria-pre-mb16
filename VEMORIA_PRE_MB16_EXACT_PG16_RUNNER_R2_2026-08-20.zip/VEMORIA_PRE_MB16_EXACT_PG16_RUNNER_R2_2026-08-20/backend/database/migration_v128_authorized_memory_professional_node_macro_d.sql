-- Vemoria Authorized Memory Macro D
-- PC/Vault/workstation come nodo pesante autorizzato e centro operativo professionale contestuale.
-- Additive static contract. Runtime PostgreSQL non eseguito in ChatGPT.

CREATE TABLE IF NOT EXISTS authorized_memory_professional_nodes (
    owner_id TEXT NOT NULL,
    node_id TEXT NOT NULL,
    device_id TEXT NOT NULL,
    owner_visible_name TEXT NOT NULL,
    roles JSONB NOT NULL DEFAULT '[]'::jsonb,
    user_surface TEXT NOT NULL CHECK (user_surface IN ('desktop','vault','server','mobile','tablet')),
    can_be_primary_professional_surface BOOLEAN NOT NULL DEFAULT FALSE,
    can_index BOOLEAN NOT NULL DEFAULT FALSE,
    can_compute_identity BOOLEAN NOT NULL DEFAULT FALSE,
    can_heavy_analyze BOOLEAN NOT NULL DEFAULT FALSE,
    can_store_vault_copy BOOLEAN NOT NULL DEFAULT FALSE,
    can_relay_secure_line BOOLEAN NOT NULL DEFAULT FALSE,
    has_large_storage BOOLEAN NOT NULL DEFAULT FALSE,
    is_often_online BOOLEAN NOT NULL DEFAULT FALSE,
    owner_managed BOOLEAN NOT NULL DEFAULT TRUE,
    cloud_mandatory BOOLEAN NOT NULL DEFAULT FALSE,
    max_parallel_jobs INTEGER NOT NULL DEFAULT 1 CHECK (max_parallel_jobs BETWEEN 1 AND 16),
    working_state_ref TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (owner_id, node_id),
    CHECK (owner_managed = TRUE),
    CHECK (cloud_mandatory = FALSE),
    CHECK (working_state_ref LIKE 'devref:%' OR working_state_ref LIKE 'vaultref:%' OR working_state_ref LIKE 'localref:%'),
    CHECK (
        can_be_primary_professional_surface = FALSE OR (
            user_surface IN ('desktop','vault','server') AND can_index = TRUE AND has_large_storage = TRUE
        )
    )
);

CREATE TABLE IF NOT EXISTS authorized_memory_heavy_work_orders (
    owner_id TEXT NOT NULL,
    work_id TEXT NOT NULL,
    target_node_id TEXT NOT NULL,
    source_device_id TEXT NOT NULL,
    source_id TEXT NOT NULL,
    grant_id TEXT NOT NULL,
    transport_grant_id TEXT,
    workload_kind TEXT NOT NULL CHECK (workload_kind IN (
        'mass_ocr',
        'mass_stt',
        'video_derivative_analysis',
        'cross_device_dedup',
        'index_compaction',
        'vault_encrypted_copy',
        'encrypted_backup',
        'evidence_graph_linking'
    )),
    execution_policy TEXT NOT NULL CHECK (execution_policy IN ('owner_local_only','owner_secure_line_only')),
    input_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
    content_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
    output_manifest_ref TEXT,
    owner_visible_reason TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'planned' CHECK (status IN ('planned','ready','deferred','queued_offline','blocked','completed_static','runtime_required')),
    revocation_trace_required BOOLEAN NOT NULL DEFAULT TRUE,
    owner_review_required_before_memory BOOLEAN NOT NULL DEFAULT TRUE,
    canonical_promotion_forbidden BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (owner_id, work_id),
    FOREIGN KEY (owner_id, target_node_id) REFERENCES authorized_memory_professional_nodes(owner_id, node_id),
    CHECK (work_id LIKE 'work_%'),
    CHECK (revocation_trace_required = TRUE),
    CHECK (owner_review_required_before_memory = TRUE),
    CHECK (canonical_promotion_forbidden = TRUE),
    CHECK (execution_policy <> 'owner_secure_line_only' OR transport_grant_id IS NOT NULL),
    CHECK (output_manifest_ref IS NULL OR output_manifest_ref LIKE 'fabricref:%' OR output_manifest_ref LIKE 'derivref:%' OR output_manifest_ref LIKE 'idxref:%')
);

CREATE TABLE IF NOT EXISTS authorized_memory_heavy_work_outputs (
    owner_id TEXT NOT NULL,
    output_id TEXT NOT NULL,
    work_id TEXT NOT NULL,
    produced_by_grant_id TEXT NOT NULL,
    output_kind TEXT NOT NULL CHECK (output_kind IN ('ocr_result','stt_result','keyframe','thumbnail','scene_index','dedup_group','evidence_graph_edge','vault_copy_manifest','backup_manifest','search_cache')),
    output_ref TEXT NOT NULL,
    content_id TEXT,
    parent_ref TEXT,
    search_visible BOOLEAN NOT NULL DEFAULT FALSE,
    revocation_target_registered BOOLEAN NOT NULL DEFAULT TRUE,
    canonical_item BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (owner_id, output_id),
    FOREIGN KEY (owner_id, work_id) REFERENCES authorized_memory_heavy_work_orders(owner_id, work_id),
    CHECK (output_ref LIKE 'idxref:%' OR output_ref LIKE 'derivref:%' OR output_ref LIKE 'fabricref:%' OR output_ref LIKE 'egraphref:%' OR output_ref LIKE 'vaultref:%'),
    CHECK (content_id IS NULL OR content_id ~ '^cnt_[0-9a-f]{64}$'),
    CHECK (parent_ref IS NULL OR parent_ref LIKE 'sourceref:%' OR parent_ref LIKE 'contentref:%' OR parent_ref LIKE 'derivref:%'),
    CHECK (revocation_target_registered = TRUE),
    CHECK (canonical_item = FALSE)
);

CREATE INDEX IF NOT EXISTS idx_auth_mem_prof_nodes_owner_surface
    ON authorized_memory_professional_nodes(owner_id, user_surface, can_be_primary_professional_surface);

CREATE INDEX IF NOT EXISTS idx_auth_mem_heavy_work_owner_node
    ON authorized_memory_heavy_work_orders(owner_id, target_node_id, status);

CREATE INDEX IF NOT EXISTS idx_auth_mem_heavy_outputs_grant
    ON authorized_memory_heavy_work_outputs(owner_id, produced_by_grant_id, work_id);
