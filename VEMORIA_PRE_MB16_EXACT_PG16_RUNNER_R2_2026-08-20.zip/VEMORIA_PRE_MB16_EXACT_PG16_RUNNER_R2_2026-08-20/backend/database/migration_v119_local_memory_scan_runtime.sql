-- Vemoria — Canonical local-memory scan runtime (R4)
-- Metadata/control-plane only. Raw device content never transits or persists here.

CREATE TABLE IF NOT EXISTS memory_scan_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    device_id TEXT,
    source_kind TEXT NOT NULL DEFAULT 'device_local'
        CHECK (source_kind IN ('device_local','desktop_local','owner_node','manual_import')),
    state TEXT NOT NULL DEFAULT 'planned'
        CHECK (state IN ('planned','waiting_consent','queued','running','paused','completed','cancelled','error')),
    current_level TEXT NOT NULL DEFAULT 'L0'
        CHECK (current_level IN ('L0','L1','L2','L3')),
    consent_version TEXT NOT NULL,
    roots_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    constraints_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    stats_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    error_code TEXT,
    error_message TEXT,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_memory_scan_sessions_owner_state
    ON memory_scan_sessions(owner_user_id, state, updated_at DESC);

CREATE TABLE IF NOT EXISTS memory_scan_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES memory_scan_sessions(id) ON DELETE CASCADE,
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    opaque_local_ref TEXT NOT NULL,
    source_root TEXT,
    filename TEXT NOT NULL,
    mime_type TEXT,
    size_bytes BIGINT NOT NULL DEFAULT 0,
    modified_at TIMESTAMPTZ,
    content_sha256 TEXT,
    content_signature TEXT,
    scan_level TEXT NOT NULL DEFAULT 'L0'
        CHECK (scan_level IN ('L0','L1','L2','L3')),
    scan_state TEXT NOT NULL DEFAULT 'indexed_metadata'
        CHECK (scan_state IN ('indexed_metadata','quick_read','deep_read_queued','deep_read','linked','needs_confirmation','skipped','error')),
    native_text_available BOOLEAN NOT NULL DEFAULT FALSE,
    ocr_text_preview TEXT,
    ocr_confidence NUMERIC(5,4),
    ocr_engine TEXT,
    ocr_candidates JSONB NOT NULL DEFAULT '[]'::jsonb,
    classification JSONB NOT NULL DEFAULT '{}'::jsonb,
    entities JSONB NOT NULL DEFAULT '[]'::jsonb,
    relation_candidates JSONB NOT NULL DEFAULT '[]'::jsonb,
    explanation TEXT,
    tier TEXT NOT NULL DEFAULT 'WARM'
        CHECK (tier IN ('HOT','WARM','COLD')),
    importance_score NUMERIC(5,4) NOT NULL DEFAULT 0.0000,
    sensitivity TEXT NOT NULL DEFAULT 'normal'
        CHECK (sensitivity IN ('normal','personal','sensitive','restricted')),
    private_index_policy TEXT NOT NULL DEFAULT 'NO_GENERAL_INDEX'
        CHECK (private_index_policy IN ('NO_GENERAL_INDEX','LOCAL_ENCRYPTED_INDEX','OWNER_AUTHORIZED_INDEX')),
    needs_deep_scan BOOLEAN NOT NULL DEFAULT FALSE,
    first_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_accessed_at TIMESTAMPTZ,
    access_count INTEGER NOT NULL DEFAULT 0,
    UNIQUE(owner_user_id, opaque_local_ref),
    UNIQUE(owner_user_id, content_sha256)
);
CREATE INDEX IF NOT EXISTS idx_memory_scan_items_owner_level
    ON memory_scan_items(owner_user_id, scan_level, scan_state);
CREATE INDEX IF NOT EXISTS idx_memory_scan_items_owner_tier
    ON memory_scan_items(owner_user_id, tier, last_accessed_at DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_memory_scan_items_owner_hash
    ON memory_scan_items(owner_user_id, content_sha256)
    WHERE content_sha256 IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_memory_scan_items_deep_queue
    ON memory_scan_items(owner_user_id, needs_deep_scan, importance_score DESC)
    WHERE needs_deep_scan = TRUE;

CREATE TABLE IF NOT EXISTS memory_scan_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    session_id UUID REFERENCES memory_scan_sessions(id) ON DELETE SET NULL,
    item_id UUID REFERENCES memory_scan_items(id) ON DELETE SET NULL,
    action TEXT NOT NULL,
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_memory_scan_audit_owner_created
    ON memory_scan_audit_log(owner_user_id, created_at DESC);
