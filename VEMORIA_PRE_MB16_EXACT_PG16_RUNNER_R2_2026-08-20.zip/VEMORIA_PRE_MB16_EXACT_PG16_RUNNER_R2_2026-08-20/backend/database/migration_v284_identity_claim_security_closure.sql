-- Vemoria PRE-MB16 security closure: canonical account email identity,
-- verified-mailbox gate foundation, and one public bearer token -> one account.
BEGIN;

-- Account email is a canonical identity key in Vemoria. Refuse to silently
-- merge historical rows if normalization exposes a collision.
DO $$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM utenti
        GROUP BY lower(btrim(email))
        HAVING COUNT(*) > 1
    ) THEN
        RAISE EXCEPTION 'canonical email collision in utenti; manual resolution required';
    END IF;
END $$;

UPDATE utenti
SET email = lower(btrim(email))
WHERE email IS DISTINCT FROM lower(btrim(email));

CREATE UNIQUE INDEX IF NOT EXISTS ux_utenti_email_canonical
    ON utenti ((lower(btrim(email))));

ALTER TABLE utenti
    ADD COLUMN IF NOT EXISTS email_verified_at TIMESTAMPTZ NULL;

COMMENT ON COLUMN utenti.email_verified_at IS
    'Mailbox ownership verification time. NULL is fail-closed for public bearer claims/invite redemption; email_memoria activation is not mailbox verification.';

-- The old token+user unique key still allowed one bearer fingerprint to be
-- consumed by several different accounts. Fail migration rather than choosing
-- a winner if historical data already violates single-claim authority.
DO $$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM public_funnel_conversions
        GROUP BY public_token
        HAVING COUNT(DISTINCT resolved_user_id) > 1
    ) THEN
        RAISE EXCEPTION 'public token claimed by multiple users; manual containment required';
    END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS ux_public_funnel_conversions_token_once
    ON public_funnel_conversions(public_token);

COMMIT;
