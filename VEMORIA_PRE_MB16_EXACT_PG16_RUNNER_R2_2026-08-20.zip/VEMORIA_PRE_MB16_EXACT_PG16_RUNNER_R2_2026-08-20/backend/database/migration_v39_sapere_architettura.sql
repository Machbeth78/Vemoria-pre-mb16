-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V39 — Architettura Sapere V1
-- Definisce il contenitore tecnico per il prodotto Sapere.
-- Non carica ancora i dataset finali: prepara camere, sessioni e code.

CREATE TABLE IF NOT EXISTS sapere_documenti (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id    TEXT NOT NULL UNIQUE,
    settore         TEXT NOT NULL,
    nome            TEXT NOT NULL,
    alias           JSONB,
    keywords        JSONB,
    pattern         JSONB,
    sapere_id       TEXT,
    versione        TEXT NOT NULL DEFAULT '1.0',
    fonte           TEXT NOT NULL DEFAULT 'manuale',
    attivo          BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il       TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sapere_documenti_settore
    ON sapere_documenti (settore)
    WHERE attivo = TRUE;

CREATE TABLE IF NOT EXISTS sapere_contenuti (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sapere_id           TEXT NOT NULL UNIQUE,
    documento_id        TEXT NOT NULL,
    settore             TEXT,
    titolo              TEXT NOT NULL,
    cos_e               TEXT,
    a_cosa_serve        TEXT,
    come_si_riconosce   TEXT,
    quando_serve        TEXT,
    attenzioni          TEXT,
    versione            TEXT NOT NULL DEFAULT '1.0',
    attivo              BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il           TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sapere_contenuti_documento_id
    ON sapere_contenuti (documento_id)
    WHERE attivo = TRUE;

CREATE TABLE IF NOT EXISTS sapere_sessioni (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    trace_id            TEXT NOT NULL UNIQUE,
    documento_fisico_id UUID REFERENCES documenti(id) ON DELETE CASCADE,
    stato               TEXT NOT NULL DEFAULT 'in_ingresso',
    risk_level          TEXT,
    risk_score          FLOAT,
    match_documento_id  TEXT,
    match_sapere_id     TEXT,
    confidenza_match    FLOAT,
    payload_ingresso    JSONB,
    esito_antifrode     JSONB,
    risposta_json       JSONB,
    nome_camera         TEXT,
    camera_origine      TEXT,
    creato_il           TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sapere_sessioni_documento
    ON sapere_sessioni (documento_fisico_id, creato_il DESC);

CREATE TABLE IF NOT EXISTS sapere_sospesi (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    trace_id                TEXT NOT NULL,
    documento_fisico_id     UUID REFERENCES documenti(id) ON DELETE CASCADE,
    fingerprint             TEXT,
    settore_suggerito       TEXT,
    tipo_suggerito          TEXT,
    confidenza_suggerita    FLOAT,
    payload_sospeso         JSONB,
    stato                   TEXT NOT NULL DEFAULT 'nuovo',
    inviato_sentinella      BOOLEAN NOT NULL DEFAULT FALSE,
    sentinella_payload      JSONB,
    creato_il               TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sapere_sospesi_stato
    ON sapere_sospesi (stato, creato_il DESC);
