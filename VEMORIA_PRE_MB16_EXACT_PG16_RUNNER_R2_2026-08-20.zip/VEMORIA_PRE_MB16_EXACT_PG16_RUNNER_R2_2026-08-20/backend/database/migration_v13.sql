-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V3.2 — Migration V13 — Entity Engine
CREATE TABLE IF NOT EXISTS entity (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tipo_entity   TEXT NOT NULL,   -- persona|azienda|ente
    nome          TEXT NOT NULL,
    identificativo TEXT,           -- CF, P.IVA, codice ente
    note          TEXT,
    creato_il     TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (tipo_entity, nome, identificativo)
);
CREATE INDEX IF NOT EXISTS idx_entity_tipo ON entity(tipo_entity);
CREATE INDEX IF NOT EXISTS idx_entity_nome ON entity(nome);

CREATE TABLE IF NOT EXISTS entity_link (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_id   UUID NOT NULL REFERENCES entity(id) ON DELETE CASCADE,
    tipo_target TEXT NOT NULL,  -- documento|evento|dossier
    target_id   UUID NOT NULL,
    ruolo       TEXT,
    creato_il   TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_entity_link_entity ON entity_link(entity_id);
CREATE INDEX IF NOT EXISTS idx_entity_link_target ON entity_link(target_id);
