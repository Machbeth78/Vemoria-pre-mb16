-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V4.6 — Migration V27
-- Aggiunge layer firma + timestamp a eventi_invio.
-- Idempotente. Nessun provider esterno richiesto.
-- Predispone per: firma operativa, FEA futura, TSA futura.

-- ── Firma ─────────────────────────────────────────────────────
ALTER TABLE eventi_invio
    ADD COLUMN IF NOT EXISTS firma_tipo   TEXT NOT NULL DEFAULT 'none'
        CHECK (firma_tipo IN ('none', 'operativa', 'fea', 'digitale')),

    ADD COLUMN IF NOT EXISTS firma_stato  TEXT NOT NULL DEFAULT 'none'
        CHECK (firma_stato IN ('none', 'richiesta', 'completata', 'rifiutata', 'errore')),

    ADD COLUMN IF NOT EXISTS firmato_il          TIMESTAMP,
    ADD COLUMN IF NOT EXISTS file_firmato_path   TEXT,
    ADD COLUMN IF NOT EXISTS certificate_info    JSONB,

    -- Provider (popolato solo quando integrazione esterna sarà attiva)
    ADD COLUMN IF NOT EXISTS provider            TEXT,        -- es. 'yousign', 'docusign'
    ADD COLUMN IF NOT EXISTS provider_request_id TEXT,
    ADD COLUMN IF NOT EXISTS provider_status     TEXT;

-- ── Timestamp ─────────────────────────────────────────────────
ALTER TABLE eventi_invio
    ADD COLUMN IF NOT EXISTS timestamp_tipo   TEXT NOT NULL DEFAULT 'none'
        CHECK (timestamp_tipo IN ('none', 'interno', 'certificato')),

    ADD COLUMN IF NOT EXISTS timestamp_valore TIMESTAMP,
    ADD COLUMN IF NOT EXISTS timestamp_token  TEXT;         -- TSA token (futuro)

-- ── Indici ────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_eventi_firma_tipo   ON eventi_invio(firma_tipo);
CREATE INDEX IF NOT EXISTS idx_eventi_firma_stato  ON eventi_invio(firma_stato);
CREATE INDEX IF NOT EXISTS idx_eventi_ts_tipo      ON eventi_invio(timestamp_tipo);

-- ── Commenti ──────────────────────────────────────────────────
COMMENT ON COLUMN eventi_invio.firma_tipo IS
    'Tipo firma richiesta: none | operativa | fea | digitale. '
    'Oggi solo operativa è implementata internamente.';
COMMENT ON COLUMN eventi_invio.timestamp_tipo IS
    'Tipo timestamp: none | interno (clock Vemora) | certificato (TSA futura).';
COMMENT ON COLUMN eventi_invio.timestamp_token IS
    'Token TSA (RFC3161). Null finché TSA esterna non è integrata.';
