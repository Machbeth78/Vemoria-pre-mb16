-- MB15-P3-R1 — Governed Goal Executor final closure additions
-- Idempotency key support and unique partial index for duplicate-execution prevention.

BEGIN;

ALTER TABLE mb15_p3_goal_executions
    ADD COLUMN IF NOT EXISTS idempotency_key TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS idx_mb15_p3_goal_executions_idempotency
    ON mb15_p3_goal_executions (owner_id, idempotency_key)
    WHERE idempotency_key IS NOT NULL;

COMMIT;
