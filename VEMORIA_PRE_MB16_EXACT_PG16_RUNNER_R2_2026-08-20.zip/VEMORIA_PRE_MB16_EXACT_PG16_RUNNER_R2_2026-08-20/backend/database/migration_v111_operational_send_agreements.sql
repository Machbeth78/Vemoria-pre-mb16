-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification,
-- distribution or use is prohibited.
--
-- migration_v111_operational_send_agreements.sql
-- Product Probe V1.2 — FASE 6: Invii importanti con accordo allegato.
--
-- Filosofia:
-- - Un "invio importante" è un evento_invio arricchito da un ACCORDO strutturato:
--   preventivo, pre-accordo, accettazione incarico, tutela contenuto, condizioni
--   di accesso, presa visione.
-- - L'accordo NON sostituisce eventi_invio: lo accompagna. Il messaggio breve
--   resta in eventi_invio.corpo; l'accordo completo sta qui.
-- - Regola prodotto: "poche righe fuori, accordo completo dentro".
-- - L'accordo è parte della catena di prova (proof bundle + timeline), NON una
--   firma certificata isolata. La Firma Vemoria resta parte del pacchetto prova.
--
-- Sicurezza:
-- - FK owner_id → utenti(id) ON DELETE CASCADE.
-- - FK evento_id → eventi_invio(id) ON DELETE SET NULL (l'accordo può essere
--   preparato PRIMA che l'evento_invio esista; viene collegato dopo).
-- - agreement_type validato con CHECK constraint stretto.
-- - content_hash per integrità dell'accordo (parte della catena di prova).
-- - version_snapshot per congelare il testo al momento dell'invio.
--
-- Additiva e idempotente: CREATE TABLE IF NOT EXISTS, CREATE INDEX IF NOT EXISTS.
-- NON modifica eventi_invio, NON modifica timeline_eventi.

BEGIN;

-- ===========================================================================
-- operational_send_agreements
-- ===========================================================================
-- Un accordo strutturato collegato (opzionalmente) a un evento_invio.

CREATE TABLE IF NOT EXISTS operational_send_agreements (
    id                        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    -- proprietà: chi crea l'accordo
    owner_id                  UUID NOT NULL
                              REFERENCES utenti(id) ON DELETE CASCADE,

    -- collegamento all'evento di invio (può essere NULL: accordo preparato
    -- prima dell'invio, collegato al momento dell'invio effettivo)
    evento_id                 UUID
                              REFERENCES eventi_invio(id) ON DELETE SET NULL,

    -- tipo di accordo / invio importante
    agreement_type            TEXT NOT NULL DEFAULT 'normal'
                              CHECK (agreement_type IN (
                                  'normal',
                                  'proof',
                                  'presa_visione',
                                  'tutela_contenuto',
                                  'preventivo',
                                  'pre_accordo',
                                  'accettazione_incarico',
                                  'condizioni_accesso'
                              )),

    -- contenuto leggibile
    title                     TEXT NOT NULL,
    short_message             TEXT,           -- "poche righe fuori"
    agreement_body            TEXT,           -- testo completo "dentro"
    agreement_payload         JSONB DEFAULT '{}'::jsonb,  -- dati strutturati

    -- collegamenti opzionali
    linked_document_id        UUID
                              REFERENCES documenti(id) ON DELETE SET NULL,
    linked_source_item_id     UUID,           -- source_indexed_items.id (no FK
                                              -- hard: tabella in modulo separato)
    linked_contact_id         UUID,           -- contatti_rubrica.id

    -- dati economici (preventivo / pre-accordo)
    amount                    NUMERIC(14, 2),
    currency                  TEXT DEFAULT 'EUR',
    validity_until            DATE,

    -- requisiti operativi
    requires_acceptance       BOOLEAN NOT NULL DEFAULT FALSE,
    requires_signature        BOOLEAN NOT NULL DEFAULT FALSE,
    requires_view_ack         BOOLEAN NOT NULL DEFAULT FALSE,

    -- preview protetta (FASE 7)
    protected_preview_required BOOLEAN NOT NULL DEFAULT FALSE,
    preview_asset_id          UUID,           -- riferimento all'asset preview
    preview_watermark_text    TEXT,
    full_access_unlocked_at   TIMESTAMPTZ,
    full_access_unlock_event_id UUID,

    -- integrità e versioning (catena di prova)
    version_snapshot          INTEGER NOT NULL DEFAULT 1,
    content_hash              TEXT,           -- SHA256 di agreement_body

    -- stato del ciclo di vita
    status                    TEXT NOT NULL DEFAULT 'draft'
                              CHECK (status IN (
                                  'draft',
                                  'prepared',
                                  'sent',
                                  'viewed',
                                  'accepted',
                                  'signed',
                                  'declined',
                                  'expired',
                                  'cancelled'
                              )),

    -- timestamp del ciclo di vita
    accepted_at               TIMESTAMPTZ,
    signed_at                 TIMESTAMPTZ,
    viewed_at                 TIMESTAMPTZ,
    declined_at               TIMESTAMPTZ,

    created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_osa_owner
    ON operational_send_agreements(owner_id);
CREATE INDEX IF NOT EXISTS idx_osa_evento
    ON operational_send_agreements(evento_id);
CREATE INDEX IF NOT EXISTS idx_osa_type
    ON operational_send_agreements(agreement_type);
CREATE INDEX IF NOT EXISTS idx_osa_status
    ON operational_send_agreements(status);
CREATE INDEX IF NOT EXISTS idx_osa_contact
    ON operational_send_agreements(linked_contact_id);
CREATE INDEX IF NOT EXISTS idx_osa_created
    ON operational_send_agreements(created_at DESC);

-- ===========================================================================
-- operational_send_agreement_events
-- ===========================================================================
-- Log append-only degli eventi dell'accordo (preview vista, condizioni viste,
-- accettazione, firma, apertura completa). Separato per la catena di prova.
-- Coerente con il principio Vemoria: ogni write importante = segnale leggibile.

CREATE TABLE IF NOT EXISTS operational_send_agreement_events (
    id                        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agreement_id              UUID NOT NULL
                              REFERENCES operational_send_agreements(id)
                              ON DELETE CASCADE,
    event_type                TEXT NOT NULL
                              CHECK (event_type IN (
                                  'prepared',
                                  'sent',
                                  'preview_viewed',
                                  'conditions_viewed',
                                  'accepted',
                                  'signed',
                                  'declined',
                                  'full_access_unlocked',
                                  'expired',
                                  'cancelled'
                              )),
    detail                    TEXT,
    actor_kind                TEXT DEFAULT 'owner'
                              CHECK (actor_kind IN ('owner', 'counterparty', 'system')),
    metadata                  JSONB DEFAULT '{}'::jsonb,
    registered_at             TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_osae_agreement
    ON operational_send_agreement_events(agreement_id);
CREATE INDEX IF NOT EXISTS idx_osae_type
    ON operational_send_agreement_events(event_type);
CREATE INDEX IF NOT EXISTS idx_osae_registered
    ON operational_send_agreement_events(registered_at);

-- ===========================================================================
-- Trigger updated_at automatico su operational_send_agreements
-- ===========================================================================

CREATE OR REPLACE FUNCTION trg_operational_send_agreements_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS operational_send_agreements_set_updated_at
    ON operational_send_agreements;
CREATE TRIGGER operational_send_agreements_set_updated_at
    BEFORE UPDATE ON operational_send_agreements
    FOR EACH ROW
    EXECUTE FUNCTION trg_operational_send_agreements_set_updated_at();

COMMIT;

-- Note per Devin / runtime:
-- 1. operational_send_agreement_events è APPEND-ONLY. Mai UPDATE/DELETE.
--    Coerente con timeline_eventi (invariante legale Vemoria).
-- 2. content_hash va calcolato lato service al momento di status='prepared'
--    (SHA256 di agreement_body). Congela il testo dell'accordo.
-- 3. version_snapshot incrementa se l'accordo viene rieditato prima dell'invio.
--    Dopo 'sent' l'accordo NON va più modificato (solo nuovo accordo).
-- 4. La preview protetta (preview_asset_id, watermark) richiede rendering
--    immagini/PDF: RUNTIME_REQUIRED. In V1.2 i campi esistono ma il rendering
--    NON è implementato. Vedi PROTECTED_PREVIEW_CONTRACT.md.
-- 5. accept/sign end-to-end richiedono integrazione con firma_service e con
--    eventi_invio: in V1.2 gli endpoint sono IMPLEMENTED parziale (stato +
--    event log), la firma certificata effettiva resta parte del proof bundle.
