-- Vemoria MB0→MB15 audit convergence — do not retain reusable public bearer
-- tokens in funnel analytics after the claim. The column is kept for schema
-- compatibility but contains only a SHA-256 fingerprint from v275 onward.
BEGIN;

UPDATE public_funnel_conversions
SET public_token = 'sha256:' || encode(digest(convert_to(public_token, 'UTF8'), 'sha256'), 'hex')
WHERE public_token IS NOT NULL
  AND public_token NOT LIKE 'sha256:%';

COMMENT ON COLUMN public_funnel_conversions.public_token IS
    'Non-reversible sha256 fingerprint of the claimed public bearer token. Never stores the reusable raw token.';

COMMIT;
