-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA / SAPERE — Normalizzazione stage labels workflow nel DB

CREATE TABLE IF NOT EXISTS sapere_workflow_stage_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id TEXT NOT NULL,
    sapere_id TEXT NULL,
    locale TEXT NOT NULL,
    domain TEXT NOT NULL DEFAULT 'core',
    stage_key TEXT NOT NULL,
    stage_label TEXT NOT NULL,
    stage_rank INTEGER NOT NULL DEFAULT 0,
    phase_code TEXT NULL,
    phase_label TEXT NULL,
    phase_rank INTEGER NOT NULL DEFAULT 0,
    metadata_stage JSONB NOT NULL DEFAULT '{}'::jsonb,
    source_pack_id TEXT NULL,
    source_pack_version TEXT NULL,
    source_manifest_version TEXT NULL,
    source_entry_index INTEGER NULL,
    source_checksum TEXT NULL,
    attivo BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (documento_id, locale, domain, stage_key)
);

CREATE INDEX IF NOT EXISTS idx_sapere_workflow_stage_items_doc_locale_domain
    ON sapere_workflow_stage_items(documento_id, locale, domain)
    WHERE attivo = TRUE;

CREATE INDEX IF NOT EXISTS idx_sapere_workflow_stage_items_phase
    ON sapere_workflow_stage_items(phase_code, locale, domain)
    WHERE attivo = TRUE;
