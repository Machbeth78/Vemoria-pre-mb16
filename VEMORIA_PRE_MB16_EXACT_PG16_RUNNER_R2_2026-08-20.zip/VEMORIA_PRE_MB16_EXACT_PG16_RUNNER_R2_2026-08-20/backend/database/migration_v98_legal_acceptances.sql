-- VEMORIA V79.2H — Legal/IP protection integration
-- Additive migration: documenti legali/versioning/accettazioni consensi.

CREATE TABLE IF NOT EXISTS legal_document_versions (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id         TEXT NOT NULL,
    document_version    TEXT NOT NULL,
    locale              TEXT NOT NULL DEFAULT 'it-IT',
    title               TEXT NOT NULL,
    path                TEXT NULL,
    sha256              TEXT NOT NULL,
    status              TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('draft', 'active', 'archived')),
    published_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(document_id, document_version, locale)
);

CREATE INDEX IF NOT EXISTS idx_legal_document_versions_active
    ON legal_document_versions(document_id, document_version, locale)
    WHERE status = 'active';

CREATE TABLE IF NOT EXISTS legal_acceptances (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id             UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    document_id         TEXT NOT NULL,
    document_version    TEXT NOT NULL,
    document_sha256     TEXT NOT NULL,
    checkbox_id         TEXT NOT NULL,
    area                TEXT NOT NULL DEFAULT 'general',
    accepted            BOOLEAN NOT NULL,
    accepted_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    locale              TEXT NULL,
    device_id           TEXT NULL,
    app_version         TEXT NULL,
    ip_hash             TEXT NULL,
    user_agent_hash     TEXT NULL,
    metadata_json       JSONB NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(user_id, checkbox_id, document_id, document_version)
);

CREATE INDEX IF NOT EXISTS idx_legal_acceptances_user_area
    ON legal_acceptances(user_id, area, accepted_at DESC);

CREATE INDEX IF NOT EXISTS idx_legal_acceptances_doc
    ON legal_acceptances(document_id, document_version, checkbox_id);

-- Seed minimale dei documenti V2. Gli SHA operativi completi sono nel registry JSON.
INSERT INTO legal_document_versions (document_id, document_version, locale, title, path, sha256, status)
VALUES
('terms_general', 'V2_2026-05-02', 'it-IT', 'Termini generali Vemoria', 'LEGAL/PRODUCT_USER_FIRMA_PROOF_GDPR_V2_2026-05-02/01_documenti_legali/TERMINI_GENERALI_VEMORIA.md', 'see_LEGAL_DOCUMENT_REGISTRY_V79_2H', 'active'),
('privacy_policy', 'V2_2026-05-02', 'it-IT', 'Privacy Policy GDPR schema', 'LEGAL/PRODUCT_USER_FIRMA_PROOF_GDPR_V2_2026-05-02/01_documenti_legali/PRIVACY_POLICY_GDPR_SCHEMA.md', 'see_LEGAL_DOCUMENT_REGISTRY_V79_2H', 'active'),
('ip_limits', 'V2_2026-05-02', 'it-IT', 'Proprietà intellettuale e limiti uso Vemoria', 'LEGAL/PRODUCT_USER_FIRMA_PROOF_GDPR_V2_2026-05-02/01_documenti_legali/PROPRIETA_INTELLETTUALE_E_LIMITI_USO_VEMORIA.md', 'see_LEGAL_DOCUMENT_REGISTRY_V79_2H', 'active'),
('metering_policy', 'V2_2026-05-02', 'it-IT', 'Policy metering crediti soglie antiabuso', 'LEGAL/PRODUCT_USER_FIRMA_PROOF_GDPR_V2_2026-05-02/01_documenti_legali/POLICY_METERING_CREDITI_SOGLIE_ANTIABUSO.md', 'see_LEGAL_DOCUMENT_REGISTRY_V79_2H', 'active'),
('firma_proof_terms', 'V2_2026-05-02', 'it-IT', 'Condizioni Firma Proof Vemoria', 'LEGAL/PRODUCT_USER_FIRMA_PROOF_GDPR_V2_2026-05-02/01_documenti_legali/CONDIZIONI_FIRMA_PROOF_VEMORIA.md', 'see_LEGAL_DOCUMENT_REGISTRY_V79_2H', 'active'),
('firma_sensitive_warning', 'V2_2026-05-02', 'it-IT', 'Warning atti sensibili Firma Vemoria', 'LEGAL/PRODUCT_USER_FIRMA_PROOF_GDPR_V2_2026-05-02/01_documenti_legali/FIRMA_VEMORIA_WARNING_ATTI_SENSIBILI.md', 'see_LEGAL_DOCUMENT_REGISTRY_V79_2H', 'active')
ON CONFLICT (document_id, document_version, locale) DO UPDATE
SET title = EXCLUDED.title, path = EXCLUDED.path, status = EXCLUDED.status;
