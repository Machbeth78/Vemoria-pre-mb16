-- VEMORA -- Migration V80 -- Conversation State: action slots per clarification loop
-- Data: 2026-04-11
-- Autore: Devoti Massimo
--
-- Obiettivo:
--   Aggiunge slot strutturati a luiss_conversation_state per il loop
--   turno-N-ambiguo → clarification → turno-N+1-riprende-azione.
--
--   Senza questi slot, il sistema non ha memoria di cosa stava cercando
--   di fare quando ha chiesto chiarimento — il turno N+1 ricomincia da zero.
--
-- Nuovi campi:
--   pending_intent    TEXT         -- es. "prepare_send", "open_item", "create_deadline"
--   pending_action    JSONB        -- payload parziale dell'azione da completare
--   pending_entities  JSONB        -- entita' gia' risolte nell'azione pending
--   last_candidates   JSONB        -- candidati proposti all'utente per disambiguare
--
-- Idempotente: ADD COLUMN IF NOT EXISTS.

ALTER TABLE luiss_conversation_state
    ADD COLUMN IF NOT EXISTS pending_intent   TEXT,
    ADD COLUMN IF NOT EXISTS pending_action   JSONB,
    ADD COLUMN IF NOT EXISTS pending_entities JSONB,
    ADD COLUMN IF NOT EXISTS last_candidates  JSONB;
