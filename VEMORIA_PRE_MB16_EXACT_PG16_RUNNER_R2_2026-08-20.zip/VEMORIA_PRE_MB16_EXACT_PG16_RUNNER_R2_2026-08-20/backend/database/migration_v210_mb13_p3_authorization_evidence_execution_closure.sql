-- MB13-P3 v210 — Authorization, evidence and execution closure
-- Applied on top of v209. Additive, idempotent, no history rewrite.
BEGIN;

-- ----------------------------------------------------------------------------
-- 1. Additional grants for consent/provenance validation
-- ----------------------------------------------------------------------------
GRANT SELECT ON public.authorized_memory_sources TO mb13_p3_writer;
GRANT SELECT ON public.authorized_memory_consent_grants TO mb13_p3_writer;
GRANT SELECT ON public.authorized_memory_activity_log TO mb13_p3_writer;
GRANT SELECT ON public.authorized_memory_inventory_items TO mb13_p3_writer;
GRANT SELECT ON public.mb12_p0_source_card_binding TO mb13_p3_writer;

-- ----------------------------------------------------------------------------
-- 2. Owner-scoped composite isolation on pack and children
-- ----------------------------------------------------------------------------
CREATE UNIQUE INDEX IF NOT EXISTS uq_mb13_p3_action_pack_pack_owner
    ON public.mb13_p3_action_pack(pack_id, owner_user_id);

ALTER TABLE public.mb13_p3_action_pack_revision
    DROP CONSTRAINT IF EXISTS fk_mb13_p3_rev_pack;
ALTER TABLE public.mb13_p3_action_pack_revision
    DROP CONSTRAINT IF EXISTS fk_mb13_p3_rev_pack_owner;
ALTER TABLE public.mb13_p3_action_pack_revision
    ADD CONSTRAINT fk_mb13_p3_rev_pack_owner
        FOREIGN KEY (pack_id, owner_user_id)
        REFERENCES public.mb13_p3_action_pack(pack_id, owner_user_id)
        ON DELETE CASCADE;

-- Authorization table needs to become append-only (multiple rows per pack).
ALTER TABLE public.mb13_p3_action_pack_authorization
    DROP CONSTRAINT IF EXISTS mb13_p3_action_pack_authorization_pack_id_key;
ALTER TABLE public.mb13_p3_action_pack_authorization
    DROP CONSTRAINT IF EXISTS uq_mb13_p3_action_pack_authorization_pack_id;

ALTER TABLE public.mb13_p3_action_pack_authorization
    ADD COLUMN IF NOT EXISTS pack_payload_hash TEXT,
    ADD COLUMN IF NOT EXISTS monitor_revision INTEGER,
    ADD COLUMN IF NOT EXISTS action_type TEXT,
    ADD COLUMN IF NOT EXISTS target_ref_hash TEXT,
    ADD COLUMN IF NOT EXISTS consent_hash TEXT,
    ADD COLUMN IF NOT EXISTS provenance_hash TEXT,
    ADD COLUMN IF NOT EXISTS revoked_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS revocation_event_id UUID,
    ADD COLUMN IF NOT EXISTS authorization_hash TEXT;

-- Only one active (non-revoked) authorization per pack.
DROP INDEX IF EXISTS uq_mb13_p3_action_pack_authorization_active_pack;
CREATE UNIQUE INDEX uq_mb13_p3_action_pack_authorization_active_pack
    ON public.mb13_p3_action_pack_authorization(pack_id)
    WHERE revoked = false;

ALTER TABLE public.mb13_p3_action_pack_authorization
    DROP CONSTRAINT IF EXISTS fk_mb13_p3_auth_pack;
ALTER TABLE public.mb13_p3_action_pack_authorization
    DROP CONSTRAINT IF EXISTS fk_mb13_p3_auth_pack_owner;
ALTER TABLE public.mb13_p3_action_pack_authorization
    ADD CONSTRAINT fk_mb13_p3_auth_pack_owner
        FOREIGN KEY (pack_id, owner_user_id)
        REFERENCES public.mb13_p3_action_pack(pack_id, owner_user_id)
        ON DELETE CASCADE;

ALTER TABLE public.mb13_p3_action_pack_attempt
    DROP CONSTRAINT IF EXISTS fk_mb13_p3_attempt_pack;
ALTER TABLE public.mb13_p3_action_pack_attempt
    DROP CONSTRAINT IF EXISTS fk_mb13_p3_attempt_pack_owner;
ALTER TABLE public.mb13_p3_action_pack_attempt
    ADD CONSTRAINT fk_mb13_p3_attempt_pack_owner
        FOREIGN KEY (pack_id, owner_user_id)
        REFERENCES public.mb13_p3_action_pack(pack_id, owner_user_id)
        ON DELETE CASCADE;

ALTER TABLE public.mb13_p3_action_pack_timeline
    DROP CONSTRAINT IF EXISTS fk_mb13_p3_timeline_pack;
ALTER TABLE public.mb13_p3_action_pack_timeline
    DROP CONSTRAINT IF EXISTS fk_mb13_p3_timeline_pack_owner;
ALTER TABLE public.mb13_p3_action_pack_timeline
    ADD CONSTRAINT fk_mb13_p3_timeline_pack_owner
        FOREIGN KEY (pack_id, owner_user_id)
        REFERENCES public.mb13_p3_action_pack(pack_id, owner_user_id)
        ON DELETE CASCADE;

-- ----------------------------------------------------------------------------
-- 3. Append-only result table for terminal execution evidence
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.mb13_p3_action_pack_result (
    result_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL,
    pack_id UUID NOT NULL,
    attempt_id UUID NOT NULL,
    attempt_number INTEGER NOT NULL,
    outcome TEXT NOT NULL,
    executor_identity TEXT,
    result_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    result_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    CONSTRAINT uq_mb13_p3_result_attempt UNIQUE (attempt_id),
    CONSTRAINT fk_mb13_p3_result_pack_owner
        FOREIGN KEY (pack_id, owner_user_id)
        REFERENCES public.mb13_p3_action_pack(pack_id, owner_user_id)
        ON DELETE CASCADE,
    CONSTRAINT ck_mb13_p3_result_outcome CHECK (outcome IN ('completed','partial','failed')),
    CONSTRAINT ck_mb13_p3_result_payload_object CHECK (jsonb_typeof(result_payload) = 'object')
);

ALTER TABLE public.mb13_p3_action_pack_result OWNER TO mb13_p3_writer;
ALTER TABLE public.mb13_p3_action_pack_result ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p3_action_pack_result FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb13_p3_result_owner_isolation ON public.mb13_p3_action_pack_result;
CREATE POLICY mb13_p3_result_owner_isolation ON public.mb13_p3_action_pack_result
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

-- Result log is append-only: no UPDATE/DELETE ever.
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_result_immutable()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'mb13_p3_action_pack_result is append-only'
        USING ERRCODE = 'P3IMM';
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_result_immutable() OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_result_immutable() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_result_immutable() TO mb13_p3_writer;

DROP TRIGGER IF EXISTS trg_mb13_p3_result_immutable ON public.mb13_p3_action_pack_result;
CREATE TRIGGER trg_mb13_p3_result_immutable
    BEFORE UPDATE OR DELETE ON public.mb13_p3_action_pack_result
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p3_action_pack_result_immutable();

-- Authorization table is append-only: only revocation flags may be updated.
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_authorization_append_only()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_authorization is append-only'
            USING ERRCODE = 'P3IMM';
    END IF;
    IF TG_OP = 'UPDATE' THEN
        IF NEW.auth_id IS DISTINCT FROM OLD.auth_id
           OR NEW.owner_user_id IS DISTINCT FROM OLD.owner_user_id
           OR NEW.pack_id IS DISTINCT FROM OLD.pack_id
           OR NEW.pack_revision IS DISTINCT FROM OLD.pack_revision
           OR NEW.pack_payload_hash IS DISTINCT FROM OLD.pack_payload_hash
           OR NEW.monitor_revision IS DISTINCT FROM OLD.monitor_revision
           OR NEW.action_type IS DISTINCT FROM OLD.action_type
           OR NEW.target_ref_hash IS DISTINCT FROM OLD.target_ref_hash
           OR NEW.consent_hash IS DISTINCT FROM OLD.consent_hash
           OR NEW.provenance_hash IS DISTINCT FROM OLD.provenance_hash
           OR NEW.authorized_at IS DISTINCT FROM OLD.authorized_at
           OR NEW.expires_at IS DISTINCT FROM OLD.expires_at
           OR NEW.auth_payload_hash IS DISTINCT FROM OLD.auth_payload_hash
           OR NEW.authorization_hash IS DISTINCT FROM OLD.authorization_hash
           OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
            RAISE EXCEPTION 'mb13_p3_action_pack_authorization is append-only'
                USING ERRCODE = 'P3IMM';
        END IF;
        IF NEW.revoked IS DISTINCT FROM OLD.revoked
           OR NEW.revoked_at IS DISTINCT FROM OLD.revoked_at
           OR NEW.revocation_event_id IS DISTINCT FROM OLD.revocation_event_id THEN
            RETURN NEW;
        END IF;
        RAISE EXCEPTION 'mb13_p3_action_pack_authorization is append-only'
            USING ERRCODE = 'P3IMM';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_authorization_append_only() OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_authorization_append_only() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_authorization_append_only() TO mb13_p3_writer;

DROP TRIGGER IF EXISTS trg_mb13_p3_authorization_append_only ON public.mb13_p3_action_pack_authorization;
CREATE TRIGGER trg_mb13_p3_authorization_append_only
    BEFORE UPDATE OR DELETE ON public.mb13_p3_action_pack_authorization
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p3_action_pack_authorization_append_only();

-- ----------------------------------------------------------------------------
-- 4. Helper functions
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_authorization_hash(
    p_pack_id UUID,
    p_owner_user_id UUID,
    p_pack_revision INTEGER,
    p_pack_payload_hash TEXT,
    p_monitor_revision INTEGER,
    p_action_type TEXT,
    p_target_ref_hash TEXT,
    p_consent_hash TEXT,
    p_provenance_hash TEXT,
    p_authorized_at TIMESTAMPTZ,
    p_expires_at TIMESTAMPTZ
) RETURNS TEXT AS $$
BEGIN
    RETURN public.mb13_p0_hash_jsonb(jsonb_build_object(
        'pack_id', p_pack_id,
        'owner_user_id', p_owner_user_id,
        'pack_revision', p_pack_revision,
        'pack_payload_hash', p_pack_payload_hash,
        'monitor_revision', p_monitor_revision,
        'action_type', p_action_type,
        'target_ref_hash', p_target_ref_hash,
        'consent_hash', p_consent_hash,
        'provenance_hash', p_provenance_hash,
        'authorized_at', p_authorized_at,
        'expires_at', p_expires_at
    ));
END;
$$ LANGUAGE plpgsql IMMUTABLE
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_authorization_hash(UUID, UUID, INTEGER, TEXT, INTEGER, TEXT, TEXT, TEXT, TEXT, TIMESTAMPTZ, TIMESTAMPTZ) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_authorization_hash(UUID, UUID, INTEGER, TEXT, INTEGER, TEXT, TEXT, TEXT, TEXT, TIMESTAMPTZ, TIMESTAMPTZ) FROM PUBLIC;

CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_result_hash(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_pack_revision INTEGER,
    p_attempt_id UUID,
    p_attempt_number INTEGER,
    p_outcome TEXT,
    p_executor_identity TEXT,
    p_evidence JSONB,
    p_completed_at TIMESTAMPTZ
) RETURNS TEXT AS $$
BEGIN
    RETURN public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'pack_id', p_pack_id,
        'pack_revision', p_pack_revision,
        'attempt_id', p_attempt_id,
        'attempt_number', p_attempt_number,
        'outcome', p_outcome,
        'executor_identity', p_executor_identity,
        'evidence', COALESCE(p_evidence, '{}'::jsonb),
        'completed_at', p_completed_at
    ));
END;
$$ LANGUAGE plpgsql IMMUTABLE
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_result_hash(UUID, UUID, INTEGER, UUID, INTEGER, TEXT, TEXT, JSONB, TIMESTAMPTZ) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_result_hash(UUID, UUID, INTEGER, UUID, INTEGER, TEXT, TEXT, JSONB, TIMESTAMPTZ) FROM PUBLIC;

-- Robust consent/provenance resolver. Replaces the runtime-failing bool_or variant.
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_refs_revoked(
    p_monitor public.mb13_p0_monitor_target,
    p_consent_refs JSONB,
    p_provenance_refs JSONB
) RETURNS BOOLEAN AS $$
DECLARE
    v_owner UUID := p_monitor.owner_user_id;
    v_elem JSONB;
    v_source_id UUID;
    v_grant_id UUID;
    v_evidence_id UUID;
BEGIN
    IF p_consent_refs IS NULL OR jsonb_typeof(p_consent_refs) <> 'array' THEN
        RETURN true;
    END IF;
    IF jsonb_array_length(p_consent_refs) = 0 THEN
        RETURN false;
    END IF;

    FOR v_elem IN SELECT jsonb_array_elements(p_consent_refs) LOOP
        IF jsonb_typeof(v_elem) <> 'object' THEN
            RETURN true;
        END IF;
        v_source_id := NULLIF(v_elem->>'source_id', '')::UUID;
        v_grant_id := NULLIF(v_elem->>'grant_id', '')::UUID;
        IF v_source_id IS NULL OR v_grant_id IS NULL THEN
            RETURN true;
        END IF;

        IF NOT EXISTS (
            SELECT 1 FROM public.authorized_memory_sources s
            WHERE s.id = v_source_id
              AND s.user_id = v_owner
              AND s.status = 'active'
              AND s.revoked_at IS NULL
        ) THEN
            RETURN true;
        END IF;

        IF NOT EXISTS (
            SELECT 1 FROM public.authorized_memory_consent_grants g
            WHERE g.id = v_grant_id
              AND g.user_id = v_owner
              AND g.source_id = v_source_id
              AND g.status = 'active'
              AND (g.expires_at IS NULL OR g.expires_at > clock_timestamp())
              AND g.revoked_at IS NULL
        ) THEN
            RETURN true;
        END IF;
    END LOOP;

    IF p_provenance_refs IS NOT NULL AND jsonb_typeof(p_provenance_refs) = 'array' THEN
        IF jsonb_array_length(p_provenance_refs) = 0 THEN
            RETURN false;
        END IF;
        FOR v_elem IN SELECT jsonb_array_elements(p_provenance_refs) LOOP
            IF jsonb_typeof(v_elem) <> 'object' THEN
                RETURN true;
            END IF;
            v_source_id := NULLIF(v_elem->>'source_id', '')::UUID;
            v_grant_id := NULLIF(v_elem->>'grant_id', '')::UUID;
            v_evidence_id := NULLIF(v_elem->>'evidence_id', '')::UUID;
            IF v_source_id IS NULL OR v_evidence_id IS NULL THEN
                RETURN true;
            END IF;

            IF NOT EXISTS (
                SELECT 1 FROM public.authorized_memory_sources s
                WHERE s.id = v_source_id
                  AND s.user_id = v_owner
                  AND s.status = 'active'
                  AND s.revoked_at IS NULL
            ) THEN
                RETURN true;
            END IF;

            IF v_grant_id IS NOT NULL AND NOT EXISTS (
                SELECT 1 FROM public.authorized_memory_consent_grants g
                WHERE g.id = v_grant_id
                  AND g.user_id = v_owner
                  AND g.source_id = v_source_id
                  AND g.status = 'active'
                  AND (g.expires_at IS NULL OR g.expires_at > clock_timestamp())
                  AND g.revoked_at IS NULL
            ) THEN
                RETURN true;
            END IF;

            IF NOT EXISTS (
                SELECT 1 FROM public.authorized_memory_activity_log e
                WHERE e.id = v_evidence_id
                  AND e.user_id = v_owner
                  AND (e.source_id = v_source_id OR (v_grant_id IS NOT NULL AND e.grant_id = v_grant_id))
            ) THEN
                RETURN true;
            END IF;
        END LOOP;
    END IF;

    RETURN false;
END;
$$ LANGUAGE plpgsql STABLE
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_refs_revoked(public.mb13_p0_monitor_target, JSONB, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_refs_revoked(public.mb13_p0_monitor_target, JSONB, JSONB) FROM PUBLIC;

CREATE OR REPLACE FUNCTION public.mb13_p3_validate_steps(
    p_owner_user_id UUID,
    p_steps JSONB
) RETURNS VOID AS $$
DECLARE
    v_elem JSONB;
    v_step_number INTEGER;
    v_prev INTEGER := 0;
    v_action TEXT;
    v_step_consent JSONB;
    v_c JSONB;
    v_source_id UUID;
    v_grant_id UUID;
BEGIN
    IF p_steps IS NULL OR jsonb_typeof(p_steps) <> 'array' OR jsonb_array_length(p_steps) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_steps_required';
    END IF;

    FOR v_elem IN SELECT jsonb_array_elements(p_steps) LOOP
        IF jsonb_typeof(v_elem) <> 'object' THEN
            RAISE EXCEPTION 'mb13_p3_step_invalid';
        END IF;

        v_step_number := NULLIF(v_elem->>'step_number', '')::INTEGER;
        IF v_step_number IS NULL OR v_step_number <= 0 THEN
            RAISE EXCEPTION 'mb13_p3_step_number_invalid';
        END IF;

        v_action := v_elem->>'action_type';
        IF v_action NOT IN ('simulate','internal') THEN
            RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
        END IF;

        IF jsonb_typeof(COALESCE(v_elem->'target_ref','{}'::jsonb)) IS DISTINCT FROM 'object' THEN
            RAISE EXCEPTION 'mb13_p3_step_target_invalid';
        END IF;

        IF jsonb_typeof(COALESCE(v_elem->'parameters','{}'::jsonb)) IS DISTINCT FROM 'object' THEN
            RAISE EXCEPTION 'mb13_p3_step_parameters_invalid';
        END IF;

        v_step_consent := COALESCE(v_elem->'consent_refs','[]'::jsonb);
        IF jsonb_typeof(v_step_consent) IS DISTINCT FROM 'array' THEN
            RAISE EXCEPTION 'mb13_p3_step_consent_refs_invalid';
        END IF;

        -- validate per-step consent refs when present
        IF jsonb_array_length(v_step_consent) > 0 THEN
            FOR v_c IN SELECT jsonb_array_elements(v_step_consent) LOOP
                v_source_id := NULLIF(v_c->>'source_id', '')::UUID;
                v_grant_id := NULLIF(v_c->>'grant_id', '')::UUID;
                IF v_source_id IS NULL OR v_grant_id IS NULL THEN
                    RAISE EXCEPTION 'mb13_p3_step_consent_ref_invalid';
                END IF;
                IF NOT EXISTS (
                    SELECT 1 FROM public.authorized_memory_sources s
                    WHERE s.id = v_source_id
                      AND s.user_id = p_owner_user_id
                      AND s.status = 'active'
                      AND s.revoked_at IS NULL
                ) THEN
                    RAISE EXCEPTION 'mb13_p3_step_consent_source_invalid';
                END IF;
                IF NOT EXISTS (
                    SELECT 1 FROM public.authorized_memory_consent_grants g
                    WHERE g.id = v_grant_id
                      AND g.user_id = p_owner_user_id
                      AND g.source_id = v_source_id
                      AND g.status = 'active'
                      AND (g.expires_at IS NULL OR g.expires_at > clock_timestamp())
                      AND g.revoked_at IS NULL
                ) THEN
                    RAISE EXCEPTION 'mb13_p3_step_consent_grant_invalid';
                END IF;
            END LOOP;
        END IF;

        IF v_step_number <= v_prev THEN
            RAISE EXCEPTION 'mb13_p3_steps_unordered';
        END IF;
        v_prev := v_step_number;
    END LOOP;

    -- Require contiguous numbering 1..N to guarantee uniqueness and order.
    IF v_prev <> jsonb_array_length(p_steps) THEN
        RAISE EXCEPTION 'mb13_p3_steps_not_contiguous';
    END IF;
END;
$$ LANGUAGE plpgsql STABLE
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_validate_steps(UUID, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_validate_steps(UUID, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_steps(UUID, JSONB) TO mb13_p3_writer;

CREATE OR REPLACE FUNCTION public.mb13_p3_validate_result_evidence(p_result_payload JSONB)
RETURNS VOID AS $$
DECLARE
    v_evidence JSONB;
    v_evidence_type TEXT;
    v_evidence_id TEXT;
    v_receipt_id TEXT;
    v_evidence_hash TEXT;
BEGIN
    IF p_result_payload IS NULL OR jsonb_typeof(p_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_payload_invalid';
    END IF;

    v_evidence := p_result_payload->'evidence';
    IF v_evidence IS NULL OR jsonb_typeof(v_evidence) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_required';
    END IF;

    v_evidence_type := NULLIF(v_evidence->>'evidence_type', '');
    v_evidence_id := NULLIF(v_evidence->>'evidence_id', '');
    v_receipt_id := NULLIF(v_evidence->>'receipt_id', '');
    v_evidence_hash := NULLIF(v_evidence->>'evidence_hash', '');

    IF v_evidence_type IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_type_required';
    END IF;
    IF v_evidence_id IS NULL AND v_receipt_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_id_required';
    END IF;
    IF v_evidence_hash IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_hash_required';
    END IF;
END;
$$ LANGUAGE plpgsql IMMUTABLE
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_validate_result_evidence(JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_validate_result_evidence(JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_result_evidence(JSONB) TO mb13_p3_writer;

-- Returns the active (non-revoked, non-expired) authorization for a pack if it
-- exactly matches the expected payload and current monitor revision.
CREATE OR REPLACE FUNCTION public.mb13_p3_get_active_authorization(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_pack_payload_hash TEXT,
    p_pack_revision INTEGER,
    p_action_type TEXT,
    p_target_ref_hash TEXT,
    p_consent_hash TEXT,
    p_provenance_hash TEXT,
    p_monitor_revision INTEGER
) RETURNS public.mb13_p3_action_pack_authorization AS $$
DECLARE
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
BEGIN
    SELECT * INTO v_auth
      FROM public.mb13_p3_action_pack_authorization
     WHERE owner_user_id = p_owner_user_id
       AND pack_id = p_pack_id
       AND revoked = false
       AND expires_at > v_now
     ORDER BY authorized_at DESC, auth_id DESC
     LIMIT 1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_authorization_invalid';
    END IF;

    IF v_auth.pack_revision IS DISTINCT FROM p_pack_revision
       OR v_auth.pack_payload_hash IS DISTINCT FROM p_pack_payload_hash
       OR v_auth.monitor_revision IS DISTINCT FROM p_monitor_revision
       OR v_auth.action_type IS DISTINCT FROM p_action_type
       OR v_auth.target_ref_hash IS DISTINCT FROM p_target_ref_hash
       OR v_auth.consent_hash IS DISTINCT FROM p_consent_hash
       OR v_auth.provenance_hash IS DISTINCT FROM p_provenance_hash THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_authorization_invalid';
    END IF;

    RETURN v_auth;
END;
$$ LANGUAGE plpgsql STABLE
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_get_active_authorization(UUID, UUID, TEXT, INTEGER, TEXT, TEXT, TEXT, TEXT, INTEGER) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_get_active_authorization(UUID, UUID, TEXT, INTEGER, TEXT, TEXT, TEXT, TEXT, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_active_authorization(UUID, UUID, TEXT, INTEGER, TEXT, TEXT, TEXT, TEXT, INTEGER) TO mb13_p3_writer;

-- ----------------------------------------------------------------------------
-- 5. Core function replacements
-- ----------------------------------------------------------------------------

-- Create action pack
CREATE OR REPLACE FUNCTION public.mb13_p3_create_action_pack(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_trigger_event_id UUID,
    p_diff_result_id UUID,
    p_action_type TEXT,
    p_target_ref JSONB,
    p_consent_refs JSONB,
    p_provenance_refs JSONB,
    p_steps JSONB,
    p_expires_at TIMESTAMPTZ,
    p_idempotency_key TEXT,
    p_initial_status TEXT DEFAULT 'proposed'
) RETURNS TABLE(
    pack_id UUID,
    owner_user_id UUID,
    monitor_id UUID,
    monitor_revision INTEGER,
    trigger_event_id UUID,
    diff_result_id UUID,
    pack_revision INTEGER,
    payload_hash TEXT,
    action_type TEXT,
    target_ref JSONB,
    consent_refs JSONB,
    provenance_refs JSONB,
    steps JSONB,
    expires_at TIMESTAMPTZ,
    idempotency_key TEXT,
    status TEXT,
    claimed_attempt_id UUID,
    created_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_existing public.mb13_p3_action_pack%ROWTYPE;
    v_pack_id UUID;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
    v_payload_hash TEXT;
    v_status TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);
    v_status := COALESCE(p_initial_status, 'proposed');

    IF v_status NOT IN ('draft','proposed','awaiting_confirmation') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_invalid_initial_status';
    END IF;

    IF p_action_type NOT IN ('simulate','internal') THEN
        RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
    END IF;

    PERFORM public.mb13_p3_validate_steps(p_owner_user_id, COALESCE(p_steps, '[]'::jsonb));

    IF p_trigger_event_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.mb13_p0_monitor_event_ledger
             WHERE owner_user_id = p_owner_user_id
               AND event_id = p_trigger_event_id
               AND monitor_id = p_monitor_id
               AND event_status NOT IN ('superseded','failed')
        ) THEN
            RAISE EXCEPTION 'mb13_p3_trigger_event_invalid';
        END IF;
    END IF;

    IF p_diff_result_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.mb13_p1_universal_diff
             WHERE owner_user_id = p_owner_user_id
               AND diff_id = p_diff_result_id
               AND monitor_id = p_monitor_id
               AND diff_state NOT IN ('blocked','invalid')
        ) THEN
            RAISE EXCEPTION 'mb13_p3_diff_result_invalid';
        END IF;
    END IF;

    IF p_trigger_event_id IS NULL AND p_diff_result_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_trigger_or_diff_required';
    END IF;

    IF p_expires_at IS NOT NULL AND p_expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF p_idempotency_key IS NOT NULL THEN
        SELECT * INTO v_existing
          FROM public.mb13_p3_action_pack
         WHERE owner_user_id = p_owner_user_id
           AND idempotency_key = p_idempotency_key;
        IF FOUND THEN
            RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = v_existing.pack_id AND ap.owner_user_id = p_owner_user_id;
            RETURN;
        END IF;
    END IF;

    v_payload_hash := public.mb13_p3_action_pack_payload_hash(
        p_owner_user_id, p_monitor_id, v_monitor_revision,
        p_trigger_event_id, p_diff_result_id, p_action_type,
        p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
        p_expires_at, p_idempotency_key, v_status
    );

    INSERT INTO public.mb13_p3_action_pack (
        owner_user_id, monitor_id, monitor_revision, trigger_event_id, diff_result_id,
        pack_revision, payload_hash, action_type, target_ref, consent_refs, provenance_refs,
        steps, expires_at, idempotency_key, status, created_at, updated_at
    ) VALUES (
        p_owner_user_id, p_monitor_id, v_monitor_revision, p_trigger_event_id, p_diff_result_id,
        1, v_payload_hash, p_action_type, COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, p_idempotency_key, v_status, v_now, v_now
    ) RETURNING public.mb13_p3_action_pack.pack_id INTO v_pack_id;

    INSERT INTO public.mb13_p3_action_pack_revision (
        owner_user_id, pack_id, revision, monitor_revision, trigger_event_id, diff_result_id,
        payload_hash, action_type, target_ref, consent_refs, provenance_refs, steps,
        expires_at, idempotency_key, status, created_at
    ) VALUES (
        p_owner_user_id, v_pack_id, 1, v_monitor_revision, p_trigger_event_id, p_diff_result_id,
        v_payload_hash, p_action_type, COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, p_idempotency_key, v_status, v_now
    );

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_pack_id, p_monitor_id, 'pack_created', NULL, v_status,
        v_now, jsonb_build_object('pack_revision', 1),
        v_monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = v_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) TO mb13_p3_api;

-- Revise action pack
CREATE OR REPLACE FUNCTION public.mb13_p3_revise_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_action_type TEXT,
    p_target_ref JSONB,
    p_consent_refs JSONB,
    p_provenance_refs JSONB,
    p_steps JSONB,
    p_expires_at TIMESTAMPTZ
) RETURNS TABLE(
    pack_id UUID,
    owner_user_id UUID,
    monitor_id UUID,
    monitor_revision INTEGER,
    pack_revision INTEGER,
    payload_hash TEXT,
    action_type TEXT,
    status TEXT
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_new_revision INTEGER;
    v_payload_hash TEXT;
    v_policy_hash TEXT;
    v_old_status TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status IN ('claimed','executing','completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_cannot_revise';
    END IF;

    IF p_expires_at IS NOT NULL AND p_expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF p_action_type NOT IN ('simulate','internal') THEN
        RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
    END IF;

    PERFORM public.mb13_p3_validate_steps(p_owner_user_id, COALESCE(p_steps, '[]'::jsonb));

    v_old_status := v_pack.status;
    v_new_revision := v_pack.pack_revision + 1;
    v_payload_hash := public.mb13_p3_action_pack_payload_hash(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id, p_action_type,
        p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
        p_expires_at, v_pack.idempotency_key, 'proposed'
    );
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    UPDATE public.mb13_p3_action_pack
       SET pack_revision = v_new_revision,
           payload_hash = v_payload_hash,
           action_type = p_action_type,
           target_ref = COALESCE(p_target_ref, '{}'::jsonb),
           consent_refs = COALESCE(p_consent_refs, '[]'::jsonb),
           provenance_refs = COALESCE(p_provenance_refs, '[]'::jsonb),
           steps = COALESCE(p_steps, '[]'::jsonb),
           expires_at = p_expires_at,
           status = 'proposed',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    -- Any previous authorization is now tied to a superseded revision.
    UPDATE public.mb13_p3_action_pack_authorization
       SET revoked = true, revoked_at = v_now
     WHERE pack_id = p_pack_id
       AND revoked = false;

    INSERT INTO public.mb13_p3_action_pack_revision (
        owner_user_id, pack_id, revision, monitor_revision, trigger_event_id, diff_result_id,
        payload_hash, action_type, target_ref, consent_refs, provenance_refs, steps,
        expires_at, idempotency_key, status, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, v_new_revision, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id, v_payload_hash, p_action_type,
        COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, v_pack.idempotency_key, 'proposed', v_now
    );

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'pack_revised', v_old_status, 'proposed',
        v_now, jsonb_build_object('pack_revision', v_new_revision),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.owner_user_id, ap.monitor_id, ap.monitor_revision,
                        ap.pack_revision, ap.payload_hash, ap.action_type, ap.status
                   FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ) TO mb13_p3_api;

-- Authorize action pack
CREATE OR REPLACE FUNCTION public.mb13_p3_authorize_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_expires_at TIMESTAMPTZ DEFAULT NULL
) RETURNS TABLE(
    pack_id UUID,
    owner_user_id UUID,
    status TEXT,
    pack_revision INTEGER,
    authorized_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_auth_expires TIMESTAMPTZ;
    v_policy_hash TEXT;
    v_auth_hash TEXT;
    v_pack_payload_hash TEXT;
    v_target_ref_hash TEXT;
    v_consent_hash TEXT;
    v_provenance_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status NOT IN ('draft','proposed','awaiting_confirmation','authorized') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_cannot_authorize';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    -- Revalidate trigger/diff origin still valid for authorization.
    IF v_pack.trigger_event_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.mb13_p0_monitor_event_ledger
             WHERE owner_user_id = p_owner_user_id
               AND event_id = v_pack.trigger_event_id
               AND monitor_id = v_pack.monitor_id
               AND event_status NOT IN ('superseded','failed')
        ) THEN
            RAISE EXCEPTION 'mb13_p3_trigger_event_invalid';
        END IF;
    END IF;

    IF v_pack.diff_result_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.mb13_p1_universal_diff
             WHERE owner_user_id = p_owner_user_id
               AND diff_id = v_pack.diff_result_id
               AND monitor_id = v_pack.monitor_id
               AND diff_state NOT IN ('blocked','invalid')
        ) THEN
            RAISE EXCEPTION 'mb13_p3_diff_result_invalid';
        END IF;
    END IF;

    v_auth_expires := COALESCE(p_expires_at, v_pack.expires_at, v_now + interval '1 hour');
    IF v_auth_expires <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_authorization_expired';
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);
    v_pack_payload_hash := v_pack.payload_hash;
    v_target_ref_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb));
    v_consent_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb));
    v_provenance_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb));

    v_auth_hash := public.mb13_p3_action_pack_authorization_hash(
        p_pack_id, p_owner_user_id, v_pack.pack_revision, v_pack_payload_hash,
        v_monitor.current_revision, v_pack.action_type, v_target_ref_hash,
        v_consent_hash, v_provenance_hash, v_now, v_auth_expires
    );

    -- Mark any previous active authorization historic and unusable.
    UPDATE public.mb13_p3_action_pack_authorization
       SET revoked = true, revoked_at = v_now
     WHERE pack_id = p_pack_id
       AND revoked = false;

    INSERT INTO public.mb13_p3_action_pack_authorization (
        owner_user_id, pack_id, pack_revision, authorized_at, expires_at,
        auth_payload_hash, pack_payload_hash, monitor_revision, action_type,
        target_ref_hash, consent_hash, provenance_hash, authorization_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.pack_revision, v_now, v_auth_expires,
        v_auth_hash, v_pack_payload_hash, v_monitor.current_revision, v_pack.action_type,
        v_target_ref_hash, v_consent_hash, v_provenance_hash, v_auth_hash
    );

    UPDATE public.mb13_p3_action_pack
       SET status = 'authorized',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorized', v_pack.status, 'authorized',
        v_now, jsonb_build_object('pack_revision', v_pack.pack_revision, 'expires_at', v_auth_expires),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.owner_user_id, ap.status, ap.pack_revision, v_now, v_auth_expires
                   FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_authorize_action_pack(UUID, UUID, TIMESTAMPTZ) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_authorize_action_pack(UUID, UUID, TIMESTAMPTZ) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_authorize_action_pack(UUID, UUID, TIMESTAMPTZ) TO mb13_p3_api;

-- Cancel / revoke action pack
CREATE OR REPLACE FUNCTION public.mb13_p3_cancel_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID
) RETURNS TABLE(pack_id UUID, status TEXT) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status IN ('completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_already_terminal';
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    UPDATE public.mb13_p3_action_pack_authorization
       SET revoked = true, revoked_at = v_now
     WHERE pack_id = p_pack_id
       AND revoked = false;

    UPDATE public.mb13_p3_action_pack
       SET status = 'cancelled',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'cancelled', v_pack.status, 'cancelled',
        v_now, '{}'::jsonb, v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.status FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_cancel_action_pack(UUID, UUID) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_cancel_action_pack(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_cancel_action_pack(UUID, UUID) TO mb13_p3_api;

-- Executor claim action pack
CREATE OR REPLACE FUNCTION public.mb13_p3_claim_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_expected_pack_revision INTEGER,
    p_claim_nonce TEXT,
    p_idempotency_key TEXT,
    p_executor_identity TEXT DEFAULT NULL
) RETURNS TABLE(
    attempt_id UUID,
    pack_id UUID,
    attempt_number INTEGER,
    claim_nonce TEXT,
    status TEXT,
    created_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_existing public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
    v_attempt_number INTEGER;
    v_attempt_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_idempotency_key IS NULL OR length(COALESCE(p_idempotency_key, '')) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_idempotency_key_required';
    END IF;
    IF p_claim_nonce IS NULL OR length(COALESCE(p_claim_nonce, '')) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_claim_nonce_required';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_existing
      FROM public.mb13_p3_action_pack_attempt
     WHERE pack_id = p_pack_id
       AND idempotency_key = p_idempotency_key;
    IF FOUND THEN
        RETURN QUERY SELECT v_existing.attempt_id, v_existing.pack_id, v_existing.attempt_number,
                            v_existing.claim_nonce, v_existing.status, v_existing.created_at;
        RETURN;
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;

    IF v_pack.status IS DISTINCT FROM 'authorized' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_authorized';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    -- Revalidate trigger/diff origin still valid.
    IF v_pack.trigger_event_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.mb13_p0_monitor_event_ledger
             WHERE owner_user_id = p_owner_user_id
               AND event_id = v_pack.trigger_event_id
               AND monitor_id = v_pack.monitor_id
               AND event_status NOT IN ('superseded','failed')
        ) THEN
            RAISE EXCEPTION 'mb13_p3_trigger_event_invalid';
        END IF;
    END IF;

    IF v_pack.diff_result_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.mb13_p1_universal_diff
             WHERE owner_user_id = p_owner_user_id
               AND diff_id = v_pack.diff_result_id
               AND monitor_id = v_pack.monitor_id
               AND diff_state NOT IN ('blocked','invalid')
        ) THEN
            RAISE EXCEPTION 'mb13_p3_diff_result_invalid';
        END IF;
    END IF;

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);
    v_attempt_number := COALESCE((SELECT MAX(attempt_number) FROM public.mb13_p3_action_pack_attempt WHERE pack_id = p_pack_id), 0) + 1;

    INSERT INTO public.mb13_p3_action_pack_attempt (
        owner_user_id, pack_id, attempt_number, idempotency_key, claim_nonce,
        executor_identity, status, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, v_attempt_number, p_idempotency_key, p_claim_nonce,
        p_executor_identity, 'claimed', v_now
    ) RETURNING public.mb13_p3_action_pack_attempt.attempt_id INTO v_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = 'claimed',
           claimed_attempt_id = v_attempt_id,
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'claimed', 'authorized', 'claimed',
        v_now, jsonb_build_object('attempt_id', v_attempt_id, 'attempt_number', v_attempt_number, 'claim_nonce', p_claim_nonce),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt_id, p_pack_id, v_attempt_number, p_claim_nonce, 'claimed'::TEXT, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_claim_action_pack(UUID, UUID, INTEGER, TEXT, TEXT, TEXT) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_claim_action_pack(UUID, UUID, INTEGER, TEXT, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_claim_action_pack(UUID, UUID, INTEGER, TEXT, TEXT, TEXT) TO mb13_p3_executor;

-- Executor start action pack
CREATE OR REPLACE FUNCTION public.mb13_p3_start_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_expected_pack_revision INTEGER
) RETURNS TABLE(
    attempt_id UUID,
    pack_id UUID,
    attempt_number INTEGER,
    status TEXT,
    started_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;

    IF v_pack.status NOT IN ('claimed','executing') OR v_attempt.status IS DISTINCT FROM 'claimed' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_claimed';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    -- Revalidate trigger/diff origin still valid.
    IF v_pack.trigger_event_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.mb13_p0_monitor_event_ledger
             WHERE owner_user_id = p_owner_user_id
               AND event_id = v_pack.trigger_event_id
               AND monitor_id = v_pack.monitor_id
               AND event_status NOT IN ('superseded','failed')
        ) THEN
            RAISE EXCEPTION 'mb13_p3_trigger_event_invalid';
        END IF;
    END IF;

    IF v_pack.diff_result_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.mb13_p1_universal_diff
             WHERE owner_user_id = p_owner_user_id
               AND diff_id = v_pack.diff_result_id
               AND monitor_id = v_pack.monitor_id
               AND diff_state NOT IN ('blocked','invalid')
        ) THEN
            RAISE EXCEPTION 'mb13_p3_diff_result_invalid';
        END IF;
    END IF;

    -- Revalidate active authorization.
    PERFORM public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    UPDATE public.mb13_p3_action_pack_attempt
       SET status = 'executing',
           started_at = v_now
     WHERE attempt_id = p_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = 'executing',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'started', 'claimed', 'executing',
        v_now, jsonb_build_object('attempt_id', p_attempt_id, 'attempt_number', v_attempt.attempt_number),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number, 'executing'::TEXT, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_start_action_pack(UUID, UUID, UUID, INTEGER) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_start_action_pack(UUID, UUID, UUID, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_start_action_pack(UUID, UUID, UUID, INTEGER) TO mb13_p3_executor;

-- Executor complete / fail action pack
CREATE OR REPLACE FUNCTION public.mb13_p3_complete_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_expected_pack_revision INTEGER,
    p_expected_attempt_number INTEGER,
    p_outcome TEXT,
    p_result_payload JSONB
) RETURNS TABLE(
    attempt_id UUID,
    pack_id UUID,
    attempt_number INTEGER,
    status TEXT,
    result_hash TEXT,
    completed_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_result public.mb13_p3_action_pack_result%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
    v_result_hash TEXT;
    v_event_kind TEXT;
    v_old_status TEXT;
    v_evidence JSONB;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_outcome NOT IN ('completed','partial','failed') THEN
        RAISE EXCEPTION 'mb13_p3_invalid_outcome';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;

    IF v_attempt.attempt_number IS DISTINCT FROM p_expected_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;

    IF v_attempt.status = p_outcome OR v_attempt.status IN ('completed','partial','failed') THEN
        RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                            v_attempt.status, v_attempt.result_hash, v_attempt.completed_at;
        RETURN;
    END IF;

    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    -- Revalidate trigger/diff origin still valid.
    IF v_pack.trigger_event_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.mb13_p0_monitor_event_ledger
             WHERE owner_user_id = p_owner_user_id
               AND event_id = v_pack.trigger_event_id
               AND monitor_id = v_pack.monitor_id
               AND event_status NOT IN ('superseded','failed')
        ) THEN
            RAISE EXCEPTION 'mb13_p3_trigger_event_invalid';
        END IF;
    END IF;

    IF v_pack.diff_result_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.mb13_p1_universal_diff
             WHERE owner_user_id = p_owner_user_id
               AND diff_id = v_pack.diff_result_id
               AND monitor_id = v_pack.monitor_id
               AND diff_state NOT IN ('blocked','invalid')
        ) THEN
            RAISE EXCEPTION 'mb13_p3_diff_result_invalid';
        END IF;
    END IF;

    -- Revalidate active authorization.
    PERFORM public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    IF p_outcome IN ('completed','partial') THEN
        PERFORM public.mb13_p3_validate_result_evidence(p_result_payload);
        v_evidence := p_result_payload->'evidence';
    END IF;

    v_result_hash := public.mb13_p3_action_pack_result_hash(
        p_owner_user_id, p_pack_id, v_pack.pack_revision, p_attempt_id,
        v_attempt.attempt_number, p_outcome, v_attempt.executor_identity,
        v_evidence, v_now
    );
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);
    v_event_kind := p_outcome;
    v_old_status := v_pack.status;

    INSERT INTO public.mb13_p3_action_pack_result (
        owner_user_id, pack_id, attempt_id, attempt_number, outcome, executor_identity,
        result_payload, result_hash, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, v_attempt.attempt_number, p_outcome,
        v_attempt.executor_identity, COALESCE(p_result_payload, '{}'::jsonb), v_result_hash, v_now
    );

    UPDATE public.mb13_p3_action_pack_attempt
       SET status = p_outcome,
           result_payload = COALESCE(p_result_payload, '{}'::jsonb),
           result_hash = v_result_hash,
           completed_at = v_now
     WHERE attempt_id = p_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = p_outcome,
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, v_event_kind, 'executing', p_outcome,
        v_now, jsonb_build_object('attempt_id', p_attempt_id, 'attempt_number', v_attempt.attempt_number, 'result_hash', v_result_hash),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                        p_outcome::TEXT, v_result_hash, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) TO mb13_p3_executor;

-- Read attempts (prefer immutable result log)
CREATE OR REPLACE FUNCTION public.mb13_p3_get_action_pack_attempts(
    p_owner_user_id UUID,
    p_pack_id UUID
) RETURNS TABLE(
    attempt_id UUID,
    attempt_number INTEGER,
    idempotency_key TEXT,
    claim_nonce TEXT,
    executor_identity TEXT,
    status TEXT,
    result_payload JSONB,
    result_hash TEXT,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    RETURN QUERY
        SELECT a.attempt_id, a.attempt_number, a.idempotency_key, a.claim_nonce,
               a.executor_identity, a.status,
               COALESCE(r.result_payload, a.result_payload),
               COALESCE(r.result_hash, a.result_hash),
               a.started_at, a.completed_at, a.created_at
          FROM public.mb13_p3_action_pack_attempt a
          LEFT JOIN public.mb13_p3_action_pack_result r
                 ON r.attempt_id = a.attempt_id AND r.owner_user_id = a.owner_user_id
         WHERE a.pack_id = p_pack_id
           AND a.owner_user_id = p_owner_user_id
         ORDER BY a.created_at DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_get_action_pack_attempts(UUID, UUID) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_get_action_pack_attempts(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_action_pack_attempts(UUID, UUID) TO mb13_p3_api;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_action_pack_attempts(UUID, UUID) TO mb13_p3_executor;

-- ----------------------------------------------------------------------------
-- 6. Final grants and immutability enforcement
-- ----------------------------------------------------------------------------
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p3_action_pack TO mb13_p3_writer;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p3_action_pack_revision TO mb13_p3_writer;
GRANT SELECT, INSERT, UPDATE ON public.mb13_p3_action_pack_authorization TO mb13_p3_writer;
REVOKE DELETE ON public.mb13_p3_action_pack_authorization FROM mb13_p3_writer;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p3_action_pack_attempt TO mb13_p3_writer;
GRANT SELECT, INSERT ON public.mb13_p3_action_pack_timeline TO mb13_p3_writer;
REVOKE UPDATE, DELETE ON public.mb13_p3_action_pack_timeline FROM mb13_p3_writer;
GRANT SELECT, INSERT ON public.mb13_p3_action_pack_result TO mb13_p3_writer;
REVOKE UPDATE, DELETE ON public.mb13_p3_action_pack_result FROM mb13_p3_writer;

REVOKE ALL ON public.mb13_p3_action_pack FROM PUBLIC;
REVOKE ALL ON public.mb13_p3_action_pack_revision FROM PUBLIC;
REVOKE ALL ON public.mb13_p3_action_pack_authorization FROM PUBLIC;
REVOKE ALL ON public.mb13_p3_action_pack_attempt FROM PUBLIC;
REVOKE ALL ON public.mb13_p3_action_pack_timeline FROM PUBLIC;
REVOKE ALL ON public.mb13_p3_action_pack_result FROM PUBLIC;

GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO mb13_p3_writer;

COMMIT;
