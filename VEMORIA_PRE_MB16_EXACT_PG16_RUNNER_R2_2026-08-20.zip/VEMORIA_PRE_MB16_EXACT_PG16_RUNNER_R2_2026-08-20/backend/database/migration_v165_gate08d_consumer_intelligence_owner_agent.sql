-- Gate08D — Consumer Intelligence / Owner Agent (runtime deferred)
-- This migration registers contracts only. It does not execute live source fetch, pricing crawl, regulated financial advice, billing, or Cerebro runtime.

CREATE TABLE IF NOT EXISTS consumer_intelligence_registry_gate08d (
    id TEXT PRIMARY KEY,
    version TEXT NOT NULL,
    owner_agent BOOLEAN NOT NULL DEFAULT TRUE,
    ad_channel BOOLEAN NOT NULL DEFAULT FALSE,
    paid_ranking_allowed BOOLEAN NOT NULL DEFAULT FALSE,
    runtime_status TEXT NOT NULL DEFAULT 'CODE_INTEGRATED_RUNTIME_DEFERRED_CANDIDATE',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS consumer_intelligence_decision_trace_gate08d (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NOT NULL,
    workfile_id UUID NULL,
    domain TEXT NOT NULL,
    decision_status TEXT NOT NULL,
    source_chain JSONB NOT NULL DEFAULT '[]'::jsonb,
    comparability_report JSONB NOT NULL DEFAULT '{}'::jsonb,
    redacted_summary JSONB NOT NULL DEFAULT '{}'::jsonb,
    previous_hash TEXT NULL,
    event_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS consumer_intelligence_source_reverify_gate08d (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NOT NULL,
    domain TEXT NOT NULL,
    source_candidate_hash TEXT NOT NULL,
    source_status TEXT NOT NULL,
    official_public_reverify_required BOOLEAN NOT NULL DEFAULT TRUE,
    live_fetch_executed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO consumer_intelligence_registry_gate08d (id, version, owner_agent, ad_channel, paid_ranking_allowed)
VALUES ('gate08d', 'GATE08D_CONSUMER_INTELLIGENCE_OWNER_AGENT_V165_2026-06-20', TRUE, FALSE, FALSE)
ON CONFLICT (id) DO UPDATE SET
    version = EXCLUDED.version,
    owner_agent = TRUE,
    ad_channel = FALSE,
    paid_ranking_allowed = FALSE;
