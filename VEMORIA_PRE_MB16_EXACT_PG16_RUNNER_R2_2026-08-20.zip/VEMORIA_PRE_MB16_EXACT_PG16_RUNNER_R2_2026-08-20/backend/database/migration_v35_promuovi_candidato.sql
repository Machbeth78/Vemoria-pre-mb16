-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V35 — Promozione Candidati
-- Aggiunge le colonne necessarie per la promozione a tipi_documento.
-- Rimuove il CHECK constraint su stato e lo ricrea includendo 'promosso'.
-- Idempotente.

-- ── 1. Colonne di promozione ──────────────────────────────────────────────────
ALTER TABLE unknown_document_candidates
    ADD COLUMN IF NOT EXISTS tipo_promosso_codice TEXT,
    ADD COLUMN IF NOT EXISTS updated_at           TIMESTAMPTZ DEFAULT NOW();

-- ── 2. Aggiorna il CHECK constraint su stato ──────────────────────────────────
-- Il CHECK originale non includeva 'promosso'.
-- Usiamo DO $$ per ignorare l'errore se il constraint non esiste.
DO $$
BEGIN
    ALTER TABLE unknown_document_candidates
        DROP CONSTRAINT IF EXISTS unknown_document_candidates_stato_check;
EXCEPTION WHEN OTHERS THEN
    NULL;
END;
$$;

ALTER TABLE unknown_document_candidates
    ADD CONSTRAINT unknown_document_candidates_stato_check
    CHECK (stato IN ('candidato', 'ricorrente', 'validato', 'promosso', 'scartato'));

-- ── 3. Indice per promozioni ──────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_udc_promosso
    ON unknown_document_candidates (tipo_promosso_codice)
    WHERE tipo_promosso_codice IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_udc_occorrenze
    ON unknown_document_candidates (occorrenze DESC)
    WHERE stato IN ('candidato', 'ricorrente');
