-- Vemoria migration v118
-- Responsibility & Validation Layer
-- Stato: schema additivo. Non certifica. Non sostituisce legal review.

CREATE TABLE IF NOT EXISTS responsibility_notice_audit (
    id TEXT PRIMARY KEY,
    user_id TEXT,
    dialogue_id TEXT,
    sector TEXT,
    intent TEXT,
    notice_mode TEXT NOT NULL,
    confidence_level TEXT,
    used_official_source BOOLEAN DEFAULT FALSE,
    used_case_atlas BOOLEAN DEFAULT FALSE,
    action_sensitive BOOLEAN DEFAULT FALSE,
    required_validator TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS responsibility_policy_ack (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    policy_version TEXT NOT NULL,
    acknowledged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    scope TEXT DEFAULT 'global'
);
