-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB12-P0 R1I — Governed context append-only history, hardened trusted-data writer,
-- SECURITY DEFINER privilege lock-down and multi-field scope corrections.
-- Additive, idempotent migration. Does not modify v176-v183.

BEGIN;

-- 1. Extend trusted-data value with governance lineage. -------------------------
ALTER TABLE public.mb12_p0_trusted_data_value
    ADD COLUMN IF NOT EXISTS source_card_id TEXT NOT NULL DEFAULT '';

ALTER TABLE public.mb12_p0_trusted_data_value
    ADD COLUMN IF NOT EXISTS actor_id TEXT NOT NULL DEFAULT '';

ALTER TABLE public.mb12_p0_trusted_data_value
    ADD COLUMN IF NOT EXISTS device_id TEXT NOT NULL DEFAULT '';

ALTER TABLE public.mb12_p0_trusted_data_value
    ADD COLUMN IF NOT EXISTS audit_id TEXT NOT NULL DEFAULT '';

-- 2. Extend governed context with governance lineage. -------------------------
ALTER TABLE public.mb12_p0_governed_context
    ADD COLUMN IF NOT EXISTS actor_id TEXT NOT NULL DEFAULT '';

ALTER TABLE public.mb12_p0_governed_context
    ADD COLUMN IF NOT EXISTS device_id TEXT NOT NULL DEFAULT '';

ALTER TABLE public.mb12_p0_governed_context
    ADD COLUMN IF NOT EXISTS audit_id TEXT NOT NULL DEFAULT '';

ALTER TABLE public.mb12_p0_governed_context
    ADD COLUMN IF NOT EXISTS operation TEXT NOT NULL DEFAULT '';

ALTER TABLE public.mb12_p0_governed_context
    ADD COLUMN IF NOT EXISTS payload_hash TEXT NOT NULL DEFAULT '';

-- 3. Append-only governed context history. -----------------------------------
CREATE TABLE IF NOT EXISTS public.mb12_p0_governed_context_history (
    history_id UUID NOT NULL PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES public.utenti(id) ON DELETE CASCADE,
    context_id TEXT NOT NULL,
    dossier_id TEXT NOT NULL,
    rule_set_id TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    territory TEXT NOT NULL,
    state TEXT NOT NULL DEFAULT 'active',
    revoked_at TIMESTAMPTZ NULL,
    revision INTEGER NOT NULL DEFAULT 1,
    previous_revision INTEGER NULL,
    payload_hash TEXT NOT NULL DEFAULT '',
    actor_id TEXT NOT NULL DEFAULT '',
    device_id TEXT NOT NULL DEFAULT '',
    audit_id TEXT NOT NULL DEFAULT '',
    operation TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mb12_governed_context_history_owner_context
    ON public.mb12_p0_governed_context_history(owner_user_id, context_id, revision DESC);

CREATE INDEX IF NOT EXISTS idx_mb12_governed_context_history_created
    ON public.mb12_p0_governed_context_history(owner_user_id, context_id, created_at DESC);

ALTER TABLE public.mb12_p0_governed_context_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p0_governed_context_history FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb12_p0_governed_context_history_owner_policy
    ON public.mb12_p0_governed_context_history;
CREATE POLICY mb12_p0_governed_context_history_owner_policy
    ON public.mb12_p0_governed_context_history
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

-- Application role must only append.
REVOKE UPDATE, DELETE ON public.mb12_p0_governed_context_history FROM PUBLIC;
REVOKE UPDATE, DELETE ON public.mb12_p0_governed_context_history FROM mb12_p0_app;
GRANT SELECT, INSERT ON public.mb12_p0_governed_context_history TO mb12_p0_app;

-- 4. Hardened trusted-data writer. ---------------------------------------------
-- Replaces the v183 definition. Keeps the public signature (8 arguments) so
-- existing callers and the binding trigger continue to work, but reads the
-- binding source_card_id and governance GUCs. It now also verifies the
-- canonical binding, the evidence source, and the personal/public classification.
DROP FUNCTION IF EXISTS public.mb12_p0_upsert_trusted_data_value(
    UUID, UUID, UUID, TEXT, TEXT, TEXT, UUID, TEXT
);

CREATE OR REPLACE FUNCTION public.mb12_p0_upsert_trusted_data_value(
    p_source_id UUID,
    p_source_revision_id UUID,
    p_evidence_id UUID,
    p_field_name TEXT,
    p_normalized_value TEXT,
    p_content_hash TEXT,
    p_grant_id UUID DEFAULT NULL,
    p_scope TEXT DEFAULT 'source'
) RETURNS VOID AS $$
DECLARE
    v_owner UUID := current_setting('app.owner_id', true)::UUID;
    v_source_card_id TEXT := COALESCE(current_setting('app.source_card_id', true), '');
    v_actor_id TEXT := COALESCE(current_setting('app.actor_id', true), '');
    v_device_id TEXT := COALESCE(current_setting('app.device_id', true), '');
    v_audit_id TEXT := COALESCE(current_setting('app.audit_id', true), '');
    v_source RECORD;
    v_item RECORD;
    v_evidence RECORD;
    v_binding RECORD;
    v_payload JSONB;
    v_value TEXT;
    v_expected_hash TEXT;
    v_is_public BOOLEAN := FALSE;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'authenticated owner missing';
    END IF;

    -- Source must be active and owned.
    SELECT id, status, revoked_at, source_kind INTO v_source
      FROM public.authorized_memory_sources
     WHERE id = p_source_id
       AND user_id = v_owner;
    IF NOT FOUND OR v_source.status <> 'active' OR v_source.revoked_at IS NOT NULL THEN
        RAISE EXCEPTION 'source not found, cross-owner, revoked or inactive';
    END IF;

    -- Source revision must be active, owned and bound to the source.
    SELECT id, content_hash, memory_state, deleted_at INTO v_item
      FROM public.authorized_memory_inventory_items
     WHERE id = p_source_revision_id
       AND user_id = v_owner
       AND source_id = p_source_id;
    IF NOT FOUND OR v_item.deleted_at IS NOT NULL OR v_item.memory_state = 'revoked' OR v_item.content_hash IS NULL THEN
        RAISE EXCEPTION 'source revision not found, cross-owner, revoked or invalid';
    END IF;
    v_expected_hash := v_item.content_hash;

    IF p_content_hash IS DISTINCT FROM v_expected_hash THEN
        RAISE EXCEPTION 'content_hash mismatch for field %', p_field_name;
    END IF;

    -- Evidence must belong to the same owner and source and must be a trusted action/plane.
    SELECT action, plane, technical_payload, user_id, source_id INTO v_evidence
      FROM public.authorized_memory_activity_log
     WHERE id = p_evidence_id
       AND user_id = v_owner
       AND source_id = p_source_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'evidence not found or cross-owner';
    END IF;
    IF v_evidence.action NOT IN ('read_metadata', 'eligibility_read', 'promote_to_canonical') THEN
        RAISE EXCEPTION 'evidence action not allowed: %', v_evidence.action;
    END IF;
    IF v_evidence.plane NOT IN ('EXISTENCE', 'MEMORY') THEN
        RAISE EXCEPTION 'evidence plane not allowed: %', v_evidence.plane;
    END IF;

    v_payload := COALESCE(v_evidence.technical_payload, '{}'::jsonb);
    IF jsonb_typeof(v_payload) <> 'object' THEN
        RAISE EXCEPTION 'evidence payload is not an object';
    END IF;

    -- For data fields the value must be present in the evidence payload.
    IF v_payload ? 'fields' AND jsonb_typeof(v_payload->'fields') = 'object' THEN
        IF NOT (v_payload->'fields' ? p_field_name) THEN
            RAISE EXCEPTION 'field % not found in trusted evidence fields', p_field_name;
        END IF;
        v_value := v_payload->'fields'->>p_field_name;
    ELSIF p_scope LIKE 'document:%' THEN
        -- For documents the trusted normalized value is the revision hash.
        v_value := v_expected_hash;
    ELSE
        RAISE EXCEPTION 'evidence payload missing fields object for field %', p_field_name;
    END IF;

    IF p_normalized_value IS DISTINCT FROM v_value THEN
        RAISE EXCEPTION 'normalized value mismatch for field %: expected % got %', p_field_name, v_value, p_normalized_value;
    END IF;

    -- The canonical binding must exist and match the evidence and hash.
    IF v_source_card_id <> '' THEN
        SELECT source_card_id, source_id, source_revision_id, evidence_id, content_hash, grant_id, scope, owner_user_id
          INTO v_binding
          FROM public.mb12_p0_source_card_binding
         WHERE source_card_id = v_source_card_id
           AND owner_user_id = v_owner;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'canonical source-card binding not found';
        END IF;
        IF v_binding.source_id IS DISTINCT FROM p_source_id
           OR v_binding.source_revision_id IS DISTINCT FROM p_source_revision_id
           OR v_binding.evidence_id IS DISTINCT FROM p_evidence_id
           OR v_binding.content_hash IS DISTINCT FROM p_content_hash
           OR v_binding.scope IS DISTINCT FROM p_scope THEN
            RAISE EXCEPTION 'trusted data does not match canonical binding';
        END IF;

        -- Public source classification: if no grant is supplied the source card must be explicitly public.
        SELECT COALESCE(is_public_evidence, FALSE) INTO v_is_public
          FROM public.canonical_source_card_authority
         WHERE owner_user_id = v_owner
           AND source_card_id = v_source_card_id;
    END IF;

    -- Personal source requires an active grant matching the source.
    IF p_grant_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.authorized_memory_consent_grants
             WHERE id = p_grant_id
               AND user_id = v_owner
               AND source_id = p_source_id
               AND status = 'active'
               AND revoked_at IS NULL
               AND (expires_at IS NULL OR expires_at > NOW())
        ) THEN
            RAISE EXCEPTION 'grant not found, cross-owner, revoked or expired';
        END IF;
    ELSIF NOT v_is_public THEN
        RAISE EXCEPTION 'personal source requires a grant';
    END IF;

    INSERT INTO public.mb12_p0_trusted_data_value (
        owner_user_id, source_id, source_revision_id, evidence_id, field_name,
        normalized_value, content_hash, grant_id, scope, source_card_id,
        actor_id, device_id, audit_id
    ) VALUES (
        v_owner, p_source_id, p_source_revision_id, p_evidence_id, p_field_name,
        p_normalized_value, p_content_hash, p_grant_id, p_scope, v_source_card_id,
        v_actor_id, v_device_id, v_audit_id
    )
    ON CONFLICT (owner_user_id, source_id, source_revision_id, field_name) DO UPDATE SET
        evidence_id = EXCLUDED.evidence_id,
        normalized_value = EXCLUDED.normalized_value,
        content_hash = EXCLUDED.content_hash,
        grant_id = EXCLUDED.grant_id,
        scope = EXCLUDED.scope,
        source_card_id = EXCLUDED.source_card_id,
        actor_id = EXCLUDED.actor_id,
        device_id = EXCLUDED.device_id,
        audit_id = EXCLUDED.audit_id,
        created_at = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

-- The trusted-data table is only writable through the SECURITY DEFINER function.
REVOKE INSERT, UPDATE, DELETE ON public.mb12_p0_trusted_data_value FROM mb12_p0_app;
REVOKE INSERT, UPDATE, DELETE ON public.mb12_p0_trusted_data_value FROM PUBLIC;
GRANT SELECT ON public.mb12_p0_trusted_data_value TO mb12_p0_app;

-- 5. Binding trigger forwards governance and binding identifiers. -------------
DROP TRIGGER IF EXISTS trg_mb12_p0_trusted_data_from_binding
    ON public.mb12_p0_source_card_binding;
DROP FUNCTION IF EXISTS public.mb12_p0_trusted_data_from_binding();

CREATE OR REPLACE FUNCTION public.mb12_p0_trusted_data_from_binding()
RETURNS trigger AS $$
DECLARE
    v_payload JSONB;
    v_field TEXT;
    v_fields JSONB;
    v_actor_id TEXT := COALESCE(current_setting('app.actor_id', true), '');
    v_device_id TEXT := COALESCE(current_setting('app.device_id', true), '');
    v_audit_id TEXT := COALESCE(current_setting('app.audit_id', true), '');
BEGIN
    -- Provide the binding identifier to the trusted writer so it can verify
    -- the canonical binding and public/personal classification.
    PERFORM set_config('app.source_card_id', NEW.source_card_id, true);
    PERFORM set_config('app.actor_id', v_actor_id, true);
    PERFORM set_config('app.device_id', v_device_id, true);
    PERFORM set_config('app.audit_id', v_audit_id, true);

    SELECT technical_payload INTO v_payload
      FROM public.authorized_memory_activity_log
     WHERE id = NEW.evidence_id
       AND user_id = NEW.owner_user_id
       AND source_id = NEW.source_id;
    IF NOT FOUND THEN
        RETURN NEW;
    END IF;
    IF jsonb_typeof(v_payload) <> 'object' THEN
        RETURN NEW;
    END IF;

    v_fields := v_payload->'fields';
    IF jsonb_typeof(v_fields) = 'object' THEN
        FOR v_field IN SELECT jsonb_object_keys(v_fields) LOOP
            PERFORM public.mb12_p0_upsert_trusted_data_value(
                NEW.source_id,
                NEW.source_revision_id,
                NEW.evidence_id,
                v_field,
                v_fields->>v_field,
                NEW.content_hash,
                NEW.grant_id,
                COALESCE(NEW.scope, 'source')
            );
        END LOOP;
    END IF;

    -- For document scopes, persist a single trusted row keyed by the document type.
    IF NEW.scope LIKE 'document:%' THEN
        PERFORM public.mb12_p0_upsert_trusted_data_value(
            NEW.source_id,
            NEW.source_revision_id,
            NEW.evidence_id,
            substring(NEW.scope from 10),
            NEW.content_hash,
            NEW.content_hash,
            NEW.grant_id,
            NEW.scope
        );
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

CREATE TRIGGER trg_mb12_p0_trusted_data_from_binding
    AFTER INSERT OR UPDATE ON public.mb12_p0_source_card_binding
    FOR EACH ROW EXECUTE FUNCTION public.mb12_p0_trusted_data_from_binding();

-- 6. Governed context productive writer with append-only history. -------------
DROP FUNCTION IF EXISTS public.mb12_p0_upsert_governed_context(
    TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TIMESTAMPTZ
);

CREATE OR REPLACE FUNCTION public.mb12_p0_upsert_governed_context(
    p_context_id TEXT,
    p_dossier_id TEXT,
    p_rule_set_id TEXT,
    p_subject_id TEXT,
    p_territory TEXT,
    p_state TEXT DEFAULT 'active',
    p_revoked_at TIMESTAMPTZ DEFAULT NULL
) RETURNS VOID AS $$
DECLARE
    v_owner UUID := current_setting('app.owner_id', true)::UUID;
    v_actor_id TEXT := COALESCE(current_setting('app.actor_id', true), '');
    v_device_id TEXT := COALESCE(current_setting('app.device_id', true), '');
    v_audit_id TEXT := COALESCE(current_setting('app.audit_id', true), '');
    v_operation TEXT := COALESCE(current_setting('app.operation', true), '');
    v_payload_hash TEXT := COALESCE(current_setting('app.payload_hash', true), '');
    v_previous_revision INTEGER;
    v_new_revision INTEGER;
    v_payload JSONB;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'authenticated owner missing';
    END IF;
    IF p_state NOT IN ('active', 'revoked', 'superseded') THEN
        RAISE EXCEPTION 'invalid governed context state: %', p_state;
    END IF;
    IF p_state = 'active' AND p_revoked_at IS NOT NULL THEN
        RAISE EXCEPTION 'active context cannot have revoked_at set';
    END IF;

    SELECT COALESCE(MAX(revision), 0) INTO v_previous_revision
      FROM public.mb12_p0_governed_context
     WHERE owner_user_id = v_owner
       AND context_id = p_context_id;
    v_new_revision := v_previous_revision + 1;
    IF v_new_revision < 1 THEN
        v_new_revision := 1;
    END IF;

    v_payload := jsonb_build_object(
        'context_id', p_context_id,
        'dossier_id', p_dossier_id,
        'rule_set_id', p_rule_set_id,
        'subject_id', p_subject_id,
        'territory', p_territory,
        'state', p_state,
        'revoked_at', p_revoked_at,
        'revision', v_new_revision,
        'previous_revision', v_previous_revision,
        'actor_id', v_actor_id,
        'device_id', v_device_id,
        'audit_id', v_audit_id,
        'operation', v_operation
    );
    IF v_payload_hash IS NULL OR v_payload_hash = '' THEN
        v_payload_hash := encode(digest(v_payload::text, 'sha256'), 'hex');
    END IF;

    -- Append-only history entry.
    INSERT INTO public.mb12_p0_governed_context_history (
        owner_user_id, context_id, dossier_id, rule_set_id, subject_id, territory,
        state, revoked_at, revision, previous_revision, payload_hash,
        actor_id, device_id, audit_id, operation, created_at
    ) VALUES (
        v_owner, p_context_id, p_dossier_id, p_rule_set_id, p_subject_id, p_territory,
        p_state, p_revoked_at, v_new_revision, v_previous_revision, v_payload_hash,
        v_actor_id, v_device_id, v_audit_id, v_operation, NOW()
    );

    -- Current-state projection.
    INSERT INTO public.mb12_p0_governed_context (
        owner_user_id, context_id, dossier_id, rule_set_id, subject_id, territory,
        state, revoked_at, revision, actor_id, device_id, audit_id, operation,
        payload_hash, created_at, updated_at
    ) VALUES (
        v_owner, p_context_id, p_dossier_id, p_rule_set_id, p_subject_id, p_territory,
        p_state, p_revoked_at, v_new_revision, v_actor_id, v_device_id, v_audit_id,
        v_operation, v_payload_hash, NOW(), NOW()
    )
    ON CONFLICT (owner_user_id, context_id) DO UPDATE SET
        dossier_id = EXCLUDED.dossier_id,
        rule_set_id = EXCLUDED.rule_set_id,
        subject_id = EXCLUDED.subject_id,
        territory = EXCLUDED.territory,
        state = EXCLUDED.state,
        revoked_at = EXCLUDED.revoked_at,
        revision = EXCLUDED.revision,
        actor_id = EXCLUDED.actor_id,
        device_id = EXCLUDED.device_id,
        audit_id = EXCLUDED.audit_id,
        operation = EXCLUDED.operation,
        payload_hash = EXCLUDED.payload_hash,
        updated_at = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

-- Prevent the application role from mutating history.
CREATE OR REPLACE FUNCTION public.mb12_p0_governed_context_history_immutable()
RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION 'mb12_p0_governed_context_history is append-only';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_mb12_p0_governed_context_history_immutable
    ON public.mb12_p0_governed_context_history;
CREATE TRIGGER trg_mb12_p0_governed_context_history_immutable
    BEFORE UPDATE OR DELETE ON public.mb12_p0_governed_context_history
    FOR EACH ROW EXECUTE FUNCTION public.mb12_p0_governed_context_history_immutable();

-- 7. Privilege lock-down: revoke PUBLIC on all SECURITY DEFINER functions. ----
REVOKE ALL ON FUNCTION public.mb12_p0_trusted_data_from_binding() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb12_p0_trusted_data_from_binding() FROM mb12_p0_app;

REVOKE ALL ON FUNCTION public.mb12_p0_upsert_trusted_data_value(UUID, UUID, UUID, TEXT, TEXT, TEXT, UUID, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p0_upsert_trusted_data_value(UUID, UUID, UUID, TEXT, TEXT, TEXT, UUID, TEXT) TO mb12_p0_app;

REVOKE ALL ON FUNCTION public.mb12_p0_upsert_governed_context(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TIMESTAMPTZ) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p0_upsert_governed_context(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TIMESTAMPTZ) TO mb12_p0_app;

REVOKE ALL ON FUNCTION public.mb12_p0_create_source_card_binding(TEXT, UUID, UUID, UUID, TEXT, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p0_create_source_card_binding(TEXT, UUID, UUID, UUID, TEXT, UUID) TO mb12_p0_app;

REVOKE ALL ON FUNCTION public.mb12_p0_validate_source_card_binding() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p0_validate_source_card_binding() TO mb12_p0_app;

-- 8. Ensure FORCE RLS stays active on the R1H/R1I tables. ----------------------
ALTER TABLE public.mb12_p0_governed_context FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p0_trusted_data_value FORCE ROW LEVEL SECURITY;

COMMIT;
