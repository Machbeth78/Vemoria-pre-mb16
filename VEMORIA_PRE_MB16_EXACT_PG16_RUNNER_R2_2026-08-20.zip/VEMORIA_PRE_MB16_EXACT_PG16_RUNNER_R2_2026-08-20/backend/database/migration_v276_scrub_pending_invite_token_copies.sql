-- Vemoria MB0→MB15 audit convergence — remove redundant copies of reusable
-- invitation bearer tokens from chat/thread diagnostic state. The canonical
-- bearer remains only in inviti_pendenti where it is required for resolution.
BEGIN;

UPDATE chat_thread
SET pending_invite_token = NULL
WHERE pending_invite_token IS NOT NULL;

UPDATE chat_messaggi
SET payload_json = payload_json - 'invite_token'
WHERE payload_json IS NOT NULL
  AND payload_json ? 'invite_token';

COMMENT ON COLUMN chat_thread.pending_invite_token IS
    'Legacy compatibility column. Must remain NULL; invitation bearer tokens are not duplicated into chat state.';

COMMIT;
