-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V3.4 — Migration V15 — Document Timeline Engine
CREATE TABLE IF NOT EXISTS timeline_event (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    target_tipo TEXT NOT NULL,
    target_id   UUID NOT NULL,
    tipo_evento TEXT NOT NULL,
    origine     TEXT NOT NULL,
    descrizione TEXT,
    metadata    JSONB,
    creato_il   TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_timeline_target ON timeline_event(target_tipo, target_id);
CREATE INDEX IF NOT EXISTS idx_timeline_tipo   ON timeline_event(tipo_evento);
CREATE INDEX IF NOT EXISTS idx_timeline_data   ON timeline_event(creato_il DESC);
