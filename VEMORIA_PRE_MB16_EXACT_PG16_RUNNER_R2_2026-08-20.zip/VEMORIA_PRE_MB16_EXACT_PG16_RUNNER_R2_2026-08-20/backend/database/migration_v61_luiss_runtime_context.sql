-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- database/migration_v61_luiss_runtime_context.sql
-- Persistenza del contesto breve LUISS/LPE tra processi e riavvii.

CREATE TABLE IF NOT EXISTS luiss_runtime_context (
    utente_id                UUID PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    documento_corrente       UUID NULL REFERENCES documenti(id) ON DELETE SET NULL,
    ultimo_risultato_json    JSONB NULL,
    storico_json             JSONB NOT NULL DEFAULT '[]'::jsonb,
    avviato_il               TIMESTAMP NOT NULL DEFAULT NOW(),
    aggiornato_il            TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_luiss_runtime_context_updated
    ON luiss_runtime_context(aggiornato_il DESC);
