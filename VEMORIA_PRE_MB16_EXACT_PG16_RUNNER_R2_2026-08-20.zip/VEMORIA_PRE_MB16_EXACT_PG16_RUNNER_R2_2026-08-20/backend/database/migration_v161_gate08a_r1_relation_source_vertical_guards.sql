-- Gate08A-R1 — Relation Source Atlas / One-to-One + Group + Vertical Source Guards
-- Runtime deferred: registra invarianti e audit leggero, senza fetch live e senza dati privati.

CREATE TABLE IF NOT EXISTS gate08a_r1_relation_source_policy (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NULL,
    policy_code TEXT NOT NULL,
    policy_version TEXT NOT NULL DEFAULT 'GATE08A_R1_V161',
    policy_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_gate08a_r1_relation_source_policy_code
    ON gate08a_r1_relation_source_policy(policy_code);

CREATE TABLE IF NOT EXISTS gate08a_r1_vertical_source_exchange_audit (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sharer_owner_hash TEXT NOT NULL,
    receiver_owner_hash TEXT NOT NULL,
    relation_type TEXT NOT NULL CHECK (relation_type IN ('ONE_TO_ONE','GROUP')),
    card_class TEXT NOT NULL CHECK (card_class IN ('PUBLIC_SOURCE_MAP','VERTICAL_INTELLIGENCE_CARD','AUTHENTICATED_CONTEXT_CARD')),
    vertical_scope TEXT NULL,
    entitlement_checked_on_share BOOLEAN NOT NULL DEFAULT false,
    entitlement_checked_on_use_required BOOLEAN NOT NULL DEFAULT true,
    private_or_auth_material_detected BOOLEAN NOT NULL DEFAULT false,
    decision TEXT NOT NULL CHECK (decision IN ('ALLOW_PUBLIC_MAP','ALLOW_VERTICAL_SHARED_ENTITLEMENT','REJECT_PRIVATE_OR_AUTH','REJECT_MISSING_ENTITLEMENT','REJECT_UNKNOWN')),
    decision_reason TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_gate08a_r1_vertical_source_exchange_audit_relation
    ON gate08a_r1_vertical_source_exchange_audit(relation_type, card_class, vertical_scope);
