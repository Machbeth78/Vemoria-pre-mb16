-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- ============================================================================
-- VEMORA V77 — Adattamento Visibile / Delfino che Risponde
-- migration_v97_v77_indexes.sql
-- ----------------------------------------------------------------------------
-- V77 NON crea tabelle nuove. Le tabelle V76 (`user_operational_profile`,
-- `user_corrections`) sono sufficienti per i nuovi intent voce e gli
-- endpoint owner-only.
--
-- Questa migration aggiunge SOLO indici utili al pattern di accesso V77:
--   - lettura corrente delle correzioni per scope (filtro UI)
--   - lettura più recente per origine voce/chat/composer
--
-- Idempotente. Sicura su DB con dati V76.
-- ============================================================================

-- Indice composito per query "tutte le correzioni di tipo X recenti"
-- (usato dall'endpoint owner-only e dagli handler LUISS V77).
CREATE INDEX IF NOT EXISTS ix_user_corrections_kind_created
    ON user_corrections(utente_id, kind, created_at DESC);

-- Indice per lookup veloce "esiste già correzione per questo target?"
-- Utile per evitare duplicati quando il composer salva correzioni multiple
-- nello stesso turno (la dedup applicativa è in correction_memory_service,
-- ma l'indice riduce la latenza della verifica).
CREATE INDEX IF NOT EXISTS ix_user_corrections_kind_target
    ON user_corrections(utente_id, kind, target_key)
    WHERE target_key IS NOT NULL;

-- Indice per ordinamento profilo aggiornato (UI "stato" V77).
CREATE INDEX IF NOT EXISTS ix_user_operational_profile_utente_updated
    ON user_operational_profile(utente_id, updated_at DESC);

COMMENT ON INDEX ix_user_corrections_kind_created IS
    'V77 — accesso UI/voce per tipo correzione, ordinato per recency.';
COMMENT ON INDEX ix_user_corrections_kind_target IS
    'V77 — dedup applicativa per (utente, kind, target_key).';
COMMENT ON INDEX ix_user_operational_profile_utente_updated IS
    'V77 — endpoint /me/state per leggere lo stato adattivo aggiornato.';
