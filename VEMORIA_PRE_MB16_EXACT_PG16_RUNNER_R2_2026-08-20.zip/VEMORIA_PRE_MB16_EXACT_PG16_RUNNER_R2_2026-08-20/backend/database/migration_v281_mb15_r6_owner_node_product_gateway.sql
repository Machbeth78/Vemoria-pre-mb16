-- Vemoria MB15 R6 — Owner Node product authority boundary.
-- Historical v277-v280 belong to the closed R5H5/R6 checkpoints and are not
-- present in this recovery snapshot. v281 follows that canonical numbering.
--
-- Client-visible APIs never receive/store raw paths or client-authored grants.
-- The binding freezes an already server-authorized inventory item + exact
-- heavy_analysis grant + current Owner Node for a short execution window.

CREATE TABLE IF NOT EXISTS mb15_r6_owner_node_product_bindings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    requested_by_device_id UUID NOT NULL,
    owner_node_id TEXT NOT NULL,
    inventory_item_id UUID NOT NULL REFERENCES authorized_memory_inventory_items(id) ON DELETE CASCADE,
    source_id UUID NOT NULL REFERENCES authorized_memory_sources(id) ON DELETE CASCADE,
    grant_id UUID NOT NULL REFERENCES authorized_memory_consent_grants(id) ON DELETE CASCADE,
    workload_id TEXT NOT NULL CHECK (workload_id IN ('MASS_OCR','MASS_DOCUMENT_ANALYSIS','MASS_VIDEO_ANALYSIS')),
    opaque_local_ref TEXT NOT NULL CHECK (opaque_local_ref ~ '^localref:[0-9a-f]{32,64}$'),
    source_sha256 TEXT NOT NULL CHECK (source_sha256 ~ '^[0-9a-f]{64}$'),
    filename TEXT NOT NULL,
    media_kind TEXT NOT NULL CHECK (media_kind IN ('IMAGE','PHOTO','DOCUMENT','VIDEO')),
    consent_revision INTEGER NOT NULL CHECK (consent_revision >= 1),
    grant_issued_at TIMESTAMPTZ NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    revoked_at TIMESTAMPTZ NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (expires_at > created_at)
);

CREATE INDEX IF NOT EXISTS idx_mb15_r6_owner_node_binding_owner_active
    ON mb15_r6_owner_node_product_bindings(owner_id, expires_at)
    WHERE revoked_at IS NULL;

ALTER TABLE mb15_r6_owner_node_product_bindings ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb15_r6_owner_node_product_bindings FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS mb15_r6_owner_node_binding_owner_policy ON mb15_r6_owner_node_product_bindings;
CREATE POLICY mb15_r6_owner_node_binding_owner_policy
    ON mb15_r6_owner_node_product_bindings
    USING (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

CREATE TABLE IF NOT EXISTS mb15_r6_owner_node_product_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    binding_id UUID NOT NULL REFERENCES mb15_r6_owner_node_product_bindings(id) ON DELETE CASCADE,
    idempotency_key_hash TEXT NOT NULL CHECK (idempotency_key_hash ~ '^[0-9a-f]{64}$'),
    payload_hash TEXT NOT NULL CHECK (payload_hash ~ '^[0-9a-f]{64}$'),
    state TEXT NOT NULL CHECK (state IN ('RUNNING','SUCCEEDED','FAILED')),
    error_code TEXT NULL,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ NULL,
    UNIQUE(owner_id, idempotency_key_hash)
);

CREATE INDEX IF NOT EXISTS idx_mb15_r6_owner_node_request_owner_state
    ON mb15_r6_owner_node_product_requests(owner_id, state, started_at DESC);

ALTER TABLE mb15_r6_owner_node_product_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb15_r6_owner_node_product_requests FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS mb15_r6_owner_node_request_owner_policy ON mb15_r6_owner_node_product_requests;
CREATE POLICY mb15_r6_owner_node_request_owner_policy
    ON mb15_r6_owner_node_product_requests
    USING (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);
