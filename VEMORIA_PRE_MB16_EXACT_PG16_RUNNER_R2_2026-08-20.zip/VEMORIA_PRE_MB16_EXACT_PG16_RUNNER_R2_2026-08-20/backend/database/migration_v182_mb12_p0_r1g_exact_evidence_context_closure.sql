-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB12-P0 R1G — Exact evidence/revision binding, server-derived scope and governed eligibility context.
-- Additive, idempotent migration. Does not modify v176-v181.

BEGIN;

-- Governed owner-scoped request/dossier/rule-set/subject/territory context.
CREATE TABLE IF NOT EXISTS mb12_p0_governed_context (
    owner_user_id       UUID NOT NULL,
    context_id          TEXT NOT NULL,
    dossier_id          TEXT NOT NULL,
    rule_set_id         TEXT NOT NULL,
    subject_id          TEXT NOT NULL,
    territory           TEXT NOT NULL,
    state               TEXT NOT NULL DEFAULT 'active',
    revoked_at          TIMESTAMPTZ NULL,
    revision            INTEGER NOT NULL DEFAULT 1,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, context_id)
);

CREATE INDEX IF NOT EXISTS ix_mb12_governed_context_owner
    ON mb12_p0_governed_context(owner_user_id);

CREATE INDEX IF NOT EXISTS ix_mb12_governed_context_dossier
    ON mb12_p0_governed_context(owner_user_id, dossier_id);

DO $$ BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'ck_mb12_governed_context_state'
    ) THEN
        ALTER TABLE mb12_p0_governed_context
            ADD CONSTRAINT ck_mb12_governed_context_state
            CHECK (state IN ('active','revoked','superseded'));
    END IF;
END $$;

-- Table for trusted normalized scalar data values bound to a source revision/evidence.
CREATE TABLE IF NOT EXISTS mb12_p0_trusted_data_value (
    owner_user_id       UUID NOT NULL,
    source_id           UUID NOT NULL,
    source_revision_id  UUID NOT NULL,
    evidence_id         UUID NOT NULL,
    field_name          TEXT NOT NULL,
    normalized_value    TEXT NOT NULL,
    content_hash        TEXT NOT NULL,
    grant_id            UUID NULL,
    scope               TEXT NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, source_id, source_revision_id, field_name)
);

CREATE INDEX IF NOT EXISTS ix_mb12_trusted_data_value_owner_evidence
    ON mb12_p0_trusted_data_value(owner_user_id, evidence_id);

CREATE INDEX IF NOT EXISTS ix_mb12_trusted_data_value_scope
    ON mb12_p0_trusted_data_value(owner_user_id, scope);

-- RLS/FORCE RLS for new tables.
ALTER TABLE mb12_p0_governed_context ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb12_p0_trusted_data_value ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
    t text;
BEGIN
    FOR t IN SELECT unnest(ARRAY['mb12_p0_governed_context','mb12_p0_trusted_data_value']) LOOP
        EXECUTE format('DROP POLICY IF EXISTS owner_isolation ON %I', t);
        EXECUTE format(
            'CREATE POLICY owner_isolation ON %I '
            'USING (owner_user_id = CAST(current_setting(''app.owner_id'', true) AS uuid)) '
            'WITH CHECK (owner_user_id = CAST(current_setting(''app.owner_id'', true) AS uuid))',
            t
        );
    END LOOP;
END
$$;

-- R1G stricter source-card binding validation.
-- Replaces the v181 function/trigger in-place with mandatory evidence payload checks.
CREATE OR REPLACE FUNCTION public.mb12_p0_validate_source_card_binding()
RETURNS trigger AS $$
DECLARE
    v_session_owner UUID := current_setting('app.owner_id', true)::UUID;
    v_inventory_hash TEXT;
    v_item_type TEXT;
    v_inventory_grant_id TEXT;
    v_evidence RECORD;
    v_payload JSONB;
    v_payload_source_id TEXT;
    v_payload_revision_id TEXT;
    v_payload_hash TEXT;
    v_payload_action TEXT;
    v_payload_plane TEXT;
    v_payload_grant_id TEXT;
    v_payload_scope TEXT;
    v_payload_fields JSONB;
    v_derived_scope TEXT;
    v_effective_grant_id TEXT;
    v_keys TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'binding owner missing from session';
    END IF;
    IF NEW.owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'binding owner does not match authenticated owner';
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM public.authorized_memory_sources s
         WHERE s.id = NEW.source_id
           AND s.user_id = NEW.owner_user_id
           AND s.status = 'active'
           AND s.revoked_at IS NULL
    ) THEN
        RAISE EXCEPTION 'binding source not found, cross-owner, revoked or inactive';
    END IF;
    SELECT i.content_hash, i.item_type, i.grant_id::text
      INTO v_inventory_hash, v_item_type, v_inventory_grant_id
      FROM public.authorized_memory_inventory_items i
     WHERE i.id = NEW.source_revision_id
       AND i.user_id = NEW.owner_user_id
       AND i.source_id = NEW.source_id
       AND i.deleted_at IS NULL
       AND i.memory_state <> 'revoked';
    IF NOT FOUND THEN
        RAISE EXCEPTION 'binding revision not found, cross-owner, wrong source or revoked';
    END IF;
    NEW.content_hash := COALESCE(v_inventory_hash, '');

    SELECT l.action, l.plane, l.technical_payload, l.grant_id::text
      INTO v_evidence
      FROM public.authorized_memory_activity_log l
     WHERE l.id = NEW.evidence_id
       AND l.user_id = NEW.owner_user_id
       AND l.source_id = NEW.source_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'binding evidence not found, cross-owner or wrong source';
    END IF;
    IF v_evidence.action NOT IN ('promote_to_canonical','read_metadata','eligibility_read') THEN
        RAISE EXCEPTION 'binding evidence action not allowed:%', v_evidence.action;
    END IF;
    IF v_evidence.action = 'promote_to_canonical' AND v_evidence.plane <> 'MEMORY' THEN
        RAISE EXCEPTION 'promotion evidence must be on MEMORY plane';
    END IF;
    IF v_evidence.action IN ('read_metadata','eligibility_read') AND v_evidence.plane <> 'EXISTENCE' THEN
        RAISE EXCEPTION 'read evidence must be on EXISTENCE plane';
    END IF;

    BEGIN
        v_payload := COALESCE(v_evidence.technical_payload, '{}'::jsonb);
    EXCEPTION WHEN OTHERS THEN
        v_payload := '{}'::jsonb;
    END;

    -- Mandatory exact evidence payload fields.
    v_payload_source_id := v_payload ->> 'source_id';
    v_payload_revision_id := v_payload ->> 'source_revision_id';
    v_payload_hash := v_payload ->> 'content_hash';
    v_payload_action := COALESCE(v_payload ->> 'action', v_payload ->> 'operation');
    v_payload_plane := v_payload ->> 'plane';
    v_payload_grant_id := v_payload ->> 'grant_id';

    IF v_payload_source_id IS NULL THEN
        RAISE EXCEPTION 'evidence payload missing source_id';
    END IF;
    IF v_payload_source_id <> NEW.source_id::text THEN
        RAISE EXCEPTION 'evidence payload source_id mismatch: expected % got %', NEW.source_id::text, v_payload_source_id;
    END IF;
    IF v_payload_revision_id IS NULL THEN
        RAISE EXCEPTION 'evidence payload missing source_revision_id';
    END IF;
    IF v_payload_revision_id <> NEW.source_revision_id::text THEN
        RAISE EXCEPTION 'evidence payload source_revision_id mismatch';
    END IF;
    IF v_payload_hash IS NULL THEN
        RAISE EXCEPTION 'evidence payload missing content_hash';
    END IF;
    IF v_payload_hash <> COALESCE(v_inventory_hash, '') THEN
        RAISE EXCEPTION 'evidence payload content_hash mismatch';
    END IF;
    IF v_payload_action IS NULL THEN
        RAISE EXCEPTION 'evidence payload missing action/operation';
    END IF;
    IF v_payload_action <> v_evidence.action THEN
        RAISE EXCEPTION 'evidence payload action mismatch: expected % got %', v_evidence.action, v_payload_action;
    END IF;
    IF v_payload_plane IS NULL THEN
        RAISE EXCEPTION 'evidence payload missing plane';
    END IF;
    IF v_payload_plane <> v_evidence.plane THEN
        RAISE EXCEPTION 'evidence payload plane mismatch: expected % got %', v_evidence.plane, v_payload_plane;
    END IF;

    -- Grant identity: required in payload when binding or inventory references a grant.
    v_effective_grant_id := COALESCE(NEW.grant_id::text, v_inventory_grant_id, v_payload_grant_id);
    IF v_effective_grant_id IS NOT NULL THEN
        IF v_payload_grant_id IS NULL THEN
            RAISE EXCEPTION 'evidence payload missing grant_id';
        END IF;
        IF v_payload_grant_id <> v_effective_grant_id THEN
            RAISE EXCEPTION 'evidence payload grant_id mismatch';
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM public.authorized_memory_consent_grants g
             WHERE g.id = v_effective_grant_id::uuid
               AND g.user_id = NEW.owner_user_id
               AND g.source_id = NEW.source_id
               AND g.status = 'active'
               AND g.revoked_at IS NULL
               AND (g.expires_at IS NULL OR g.expires_at > NOW())
        ) THEN
            RAISE EXCEPTION 'binding grant not found, cross-owner, revoked or expired';
        END IF;
    END IF;

    -- Server-derived scope: do not accept client-provided scope as authority.
    v_payload_scope := v_payload ->> 'scope';
    v_payload_fields := v_payload -> 'fields';
    IF v_payload_scope IS NOT NULL THEN
        v_derived_scope := v_payload_scope;
    ELSIF jsonb_typeof(v_payload_fields) = 'object' AND v_payload_fields <> '{}'::jsonb THEN
        SELECT string_agg(k, ',' ORDER BY k)
          INTO v_keys
          FROM jsonb_object_keys(v_payload_fields) k;
        v_derived_scope := 'data:' || COALESCE(v_keys, 'unknown');
    ELSIF v_item_type IS NOT NULL AND v_item_type <> '' AND v_item_type NOT IN ('source','source_revision') THEN
        v_derived_scope := 'document:' || v_item_type;
    ELSE
        v_derived_scope := 'source';
    END IF;
    NEW.scope := v_derived_scope;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_mb12_p0_validate_source_card_binding ON public.mb12_p0_source_card_binding;
CREATE TRIGGER trg_mb12_p0_validate_source_card_binding
    BEFORE INSERT OR UPDATE ON public.mb12_p0_source_card_binding
    FOR EACH ROW EXECUTE FUNCTION public.mb12_p0_validate_source_card_binding();

-- R1G writer: accepts a caller-supplied scope only for compatibility and rejects mismatches.
CREATE OR REPLACE FUNCTION public.mb12_p0_create_source_card_binding(
    p_source_card_id TEXT,
    p_source_id UUID,
    p_source_revision_id UUID,
    p_evidence_id UUID,
    p_scope TEXT DEFAULT 'source',
    p_grant_id UUID DEFAULT NULL
) RETURNS VOID AS $$
DECLARE
    v_owner UUID := current_setting('app.owner_id', true)::UUID;
    v_hash TEXT;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'authenticated owner missing';
    END IF;
    SELECT i.content_hash INTO v_hash
      FROM public.authorized_memory_inventory_items i
     WHERE i.id = p_source_revision_id
       AND i.user_id = v_owner
       AND i.source_id = p_source_id
       AND i.deleted_at IS NULL
       AND i.memory_state <> 'revoked';
    IF NOT FOUND THEN
        RAISE EXCEPTION 'source revision not found or not owned';
    END IF;
    INSERT INTO public.mb12_p0_source_card_binding (
        source_card_id, owner_user_id, source_id, source_revision_id, evidence_id,
        content_hash, scope, status, grant_id
    ) VALUES (
        p_source_card_id, v_owner, p_source_id, p_source_revision_id, p_evidence_id,
        COALESCE(v_hash, ''), p_scope, 'active', p_grant_id
    )
    ON CONFLICT (owner_user_id, source_card_id) DO UPDATE SET
        source_id = EXCLUDED.source_id,
        source_revision_id = EXCLUDED.source_revision_id,
        evidence_id = EXCLUDED.evidence_id,
        content_hash = EXCLUDED.content_hash,
        scope = EXCLUDED.scope,
        grant_id = EXCLUDED.grant_id,
        status = 'active',
        revoked_at = NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE INSERT ON public.mb12_p0_source_card_binding FROM mb12_p0_app;
REVOKE ALL ON FUNCTION public.mb12_p0_create_source_card_binding(TEXT, UUID, UUID, UUID, TEXT, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p0_create_source_card_binding(TEXT, UUID, UUID, UUID, TEXT, UUID) TO mb12_p0_app;

-- Helper to upsert trusted data values for scalar fields from evidence payloads.
CREATE OR REPLACE FUNCTION public.mb12_p0_upsert_trusted_data_value(
    p_source_id UUID,
    p_source_revision_id UUID,
    p_evidence_id UUID,
    p_field_name TEXT,
    p_normalized_value TEXT,
    p_content_hash TEXT,
    p_grant_id UUID DEFAULT NULL,
    p_scope TEXT DEFAULT 'source'
) RETURNS VOID AS $$
DECLARE
    v_owner UUID := current_setting('app.owner_id', true)::UUID;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'authenticated owner missing';
    END IF;
    INSERT INTO public.mb12_p0_trusted_data_value (
        owner_user_id, source_id, source_revision_id, evidence_id,
        field_name, normalized_value, content_hash, grant_id, scope
    ) VALUES (
        v_owner, p_source_id, p_source_revision_id, p_evidence_id,
        p_field_name, p_normalized_value, p_content_hash, p_grant_id, p_scope
    )
    ON CONFLICT (owner_user_id, source_id, source_revision_id, field_name) DO UPDATE SET
        evidence_id = EXCLUDED.evidence_id,
        normalized_value = EXCLUDED.normalized_value,
        content_hash = EXCLUDED.content_hash,
        grant_id = EXCLUDED.grant_id,
        scope = EXCLUDED.scope,
        created_at = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

COMMIT;
