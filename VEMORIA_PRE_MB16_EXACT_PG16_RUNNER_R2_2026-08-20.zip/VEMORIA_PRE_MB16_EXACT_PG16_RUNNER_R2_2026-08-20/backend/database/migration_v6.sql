-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- ============================================================
-- VEMORA V2.5 — Migration V6
-- Aggiunge stato_evento e data_scadenza a eventi_invio.
-- Append-only: nessun UPDATE sui record esistenti.
-- ============================================================

ALTER TABLE eventi_invio
    ADD COLUMN IF NOT EXISTS stato_evento  TEXT NOT NULL DEFAULT 'in_attesa',
    ADD COLUMN IF NOT EXISTS data_scadenza TIMESTAMP;

-- Aggiorna i record esistenti con scadenza 72h da creato_il
UPDATE eventi_invio
   SET stato_evento  = 'in_attesa',
       data_scadenza = creato_il + INTERVAL '72 hours'
 WHERE data_scadenza IS NULL;

CREATE INDEX IF NOT EXISTS idx_eventi_stato_evento  ON eventi_invio(stato_evento);
CREATE INDEX IF NOT EXISTS idx_eventi_data_scadenza ON eventi_invio(data_scadenza);

COMMENT ON COLUMN eventi_invio.stato_evento IS
    'Ciclo di vita VERO: in_attesa | archiviato | scaduto | distrutto';
COMMENT ON COLUMN eventi_invio.data_scadenza IS
    'Scadenza accesso: creato_il + 72h (calcolata automaticamente)';
