-- VEMORA — Migration V76 — LUISS Conversation State
-- Data: 2026-04-11
-- Autore: Devoti Massimo
--
-- Obiettivo:
--   Memoria breve operativa del dialogo LUISS.
--   Una riga per utente — sovrascritta a ogni turno.
--   Non è un log storico (quello è luiss_decisions).
--   È lo stato corrente del dialogo: cosa si stava facendo,
--   di cosa si stava parlando, cosa aspetta risposta.
--
-- Separazione intenzionale:
--   luiss_conversation_state  → memoria breve (questo file)
--   nucleo_memoria / eco      → memoria lunga (già esistente)
--
-- recent_turns: lista JSONB degli ultimi 8 turni max.
--   Struttura per turno: {role: "user"|"luiss", text: "...", ts: "ISO8601"}
--   Mantenuta dal service — la tabella non applica limiti.
--
-- Idempotente: IF NOT EXISTS su tutto.

CREATE TABLE IF NOT EXISTS luiss_conversation_state (
    utente_id               UUID        PRIMARY KEY
                                        REFERENCES utenti(id) ON DELETE CASCADE,

    -- ── Stato operativo top-level ─────────────────────────────────────────
    last_intent             TEXT,       -- es. "recupera_documento", "invia", "cerca"
    last_document_id        UUID,       -- documento discusso nell'ultimo turno risolto
    last_subject            TEXT,       -- soggetto/entità nominato ("Rossi", "geometra")
    last_time_reference     TEXT,       -- riferimento temporale ("marzo", "settimana scorsa")
    pending_clarification   TEXT,       -- domanda aperta in attesa di risposta utente
    current_task            TEXT,       -- task in corso non ancora completato

    -- ── Traccia conversazionale ───────────────────────────────────────────
    -- Lista ordinata degli ultimi N turni (max 8, gestito dal service).
    -- Struttura elemento: {"role": "user"|"luiss", "text": "...", "ts": "..."}
    recent_turns            JSONB       NOT NULL DEFAULT '[]'::jsonb,

    -- ── Metadati ──────────────────────────────────────────────────────────
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indice per pulizia/monitoraggio ordinato per aggiornamento
CREATE INDEX IF NOT EXISTS idx_luiss_conversation_state_updated_at
    ON luiss_conversation_state (updated_at DESC);
