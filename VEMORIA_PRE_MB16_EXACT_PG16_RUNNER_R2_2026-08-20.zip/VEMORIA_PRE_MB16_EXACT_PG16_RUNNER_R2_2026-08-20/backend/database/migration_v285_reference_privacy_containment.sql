-- Vemoria PRE-MB16 security closure: contain legacy contact registration
-- inference. Old registrato_utente_id values were populated by a global email
-- membership oracle and therefore are not identity authority.
BEGIN;

UPDATE contatti_rubrica
SET registrato = NULL,
    registrato_utente_id = NULL,
    aggiornato_il = NOW()
WHERE registrato IS NOT NULL
   OR registrato_utente_id IS NOT NULL;

COMMENT ON COLUMN contatti_rubrica.registrato_utente_id IS
    'Server-bound Vemoria identity only. Must be populated by a governed verified relationship/handoff flow; never by global email membership lookup.';

COMMIT;
