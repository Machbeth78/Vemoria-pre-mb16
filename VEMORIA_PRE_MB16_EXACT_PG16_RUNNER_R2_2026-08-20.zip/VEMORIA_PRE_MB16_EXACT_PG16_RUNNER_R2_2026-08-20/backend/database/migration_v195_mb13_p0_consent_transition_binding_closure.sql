-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
--
-- MB13-P0 R2 consent transition binding closure.
-- Forward-only, idempotent migration. Supersedes v194 function definitions without
-- touching v194 data or earlier migrations.

BEGIN;

-- ----------------------------------------------------------------------------
-- State-aware temporal validation with explicit retry_policy_ref.max_retries guard.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p0_validate_temporal_policy_for_state(p_policy JSONB, p_state TEXT)
RETURNS void AS $$
DECLARE
    v_max_retries_text TEXT;
BEGIN
    PERFORM public.mb13_p0_validate_temporal_policy(p_policy);

    IF p_state = 'active' THEN
        IF p_policy->>'timezone' IS NULL OR length(trim(p_policy->>'timezone')) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_active_requires_temporal_policy:timezone';
        END IF;
        IF p_policy->>'valid_from' IS NULL OR length(trim(p_policy->>'valid_from')) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_active_requires_temporal_policy:valid_from';
        END IF;
        IF p_policy->>'next_check_at' IS NULL OR length(trim(p_policy->>'next_check_at')) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_active_requires_temporal_policy:next_check_at';
        END IF;
    END IF;

    IF p_policy ? 'retry_policy_ref'
       AND p_policy->'retry_policy_ref' IS NOT NULL
       AND jsonb_typeof(p_policy->'retry_policy_ref') <> 'null'
       AND (p_policy->>'retry_policy_ref' <> '')
    THEN
        IF jsonb_typeof(p_policy->'retry_policy_ref') <> 'object' THEN
            RAISE EXCEPTION 'mb13_p0_retry_policy_ref_invalid:not_object';
        END IF;

        v_max_retries_text := p_policy->'retry_policy_ref'->>'max_retries';
        IF v_max_retries_text IS NULL
           OR v_max_retries_text !~ '^-?[0-9]+$'
           OR v_max_retries_text::INTEGER < 0 THEN
            RAISE EXCEPTION 'mb13_p0_retry_policy_ref_invalid:max_retries';
        END IF;

        IF p_policy->'retry_policy_ref'->>'backoff_kind' IS NULL
           OR p_policy->'retry_policy_ref'->>'backoff_kind' NOT IN ('fixed','exponential','linear','none') THEN
            RAISE EXCEPTION 'mb13_p0_retry_policy_ref_invalid:backoff_kind';
        END IF;
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_validate_temporal_policy_for_state(JSONB, TEXT) FROM PUBLIC;

-- ----------------------------------------------------------------------------
-- Authoritative monitor writer with stored-consent transition binding closure.
--
-- For an existing monitor the caller cannot silently rebind consents during a
-- normal transition. Stored consents are re-validated and locked, then used
-- verbatim in the new revision and lifecycle event.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p0_write_monitor(
    p_monitor_id UUID,
    p_stable_id TEXT,
    p_title TEXT,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_target_revision INTEGER,
    p_target_payload_hash TEXT,
    p_monitor_reason TEXT,
    p_monitor_state TEXT,
    p_monitor_policy JSONB,
    p_consent_refs JSONB,
    p_source_refs JSONB,
    p_evidence_refs JSONB,
    p_baseline_ref JSONB,
    p_request_payload JSONB,
    p_result_payload JSONB
) RETURNS TABLE(monitor_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_revision INTEGER;
    v_payload_hash TEXT;
    v_result_payload JSONB;
    v_event_type TEXT;
    v_event_id UUID;
    v_event_payload_hash TEXT;
    v_event_time TIMESTAMPTZ := NOW();
    v_event_reason TEXT;
    v_canonical_consent_refs JSONB;
    v_canonical_source_refs JSONB;
    v_canonical_evidence_refs JSONB;
    v_required_target_keys TEXT[] := ARRAY['id','revision','payload_hash','owner_user_id','state'];
    k TEXT;
    v_old_state TEXT;
    v_current_found BOOLEAN;
    v_is_new BOOLEAN;
    v_canonical JSONB;
    v_input_source_refs JSONB;
    v_input_evidence_refs JSONB;
    v_ref_revision INTEGER;
    v_input_consent_refs JSONB;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p0_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p0_monitor_identity_invalid';
    END IF;
    IF length(trim(COALESCE(p_stable_id, ''))) = 0 OR length(p_stable_id) > 200 THEN
        RAISE EXCEPTION 'mb13_p0_stable_id_invalid';
    END IF;
    IF length(trim(COALESCE(p_title, ''))) = 0 OR length(p_title) > 300 THEN
        RAISE EXCEPTION 'mb13_p0_title_invalid';
    END IF;
    IF length(trim(COALESCE(p_monitor_reason, ''))) = 0 OR length(p_monitor_reason) > 500 THEN
        RAISE EXCEPTION 'mb13_p0_monitor_reason_invalid';
    END IF;
    IF p_target_type NOT IN ('document','contract','offer','rule','source','dossier','identity','object','decision','generic_entity') THEN
        RAISE EXCEPTION 'mb13_p0_target_type_invalid';
    END IF;
    IF p_monitor_state NOT IN ('draft','active','paused','blocked','revoked','completed') THEN
        RAISE EXCEPTION 'mb13_p0_monitor_state_invalid';
    END IF;

    -- Revocation is only allowed through the dedicated revoke function.
    IF p_monitor_state = 'revoked' THEN
        RAISE EXCEPTION 'mb13_p0_revoke_must_use_revoke_function';
    END IF;

    IF jsonb_typeof(p_target_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p0_target_ref_invalid';
    END IF;
    FOREACH k IN ARRAY v_required_target_keys LOOP
        IF p_target_ref->>k IS NULL OR length(trim(p_target_ref->>k)) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_target_ref_missing:%', k;
        END IF;
    END LOOP;
    IF p_target_ref->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
        RAISE EXCEPTION 'mb13_p0_target_owner_mismatch';
    END IF;

    BEGIN
        v_ref_revision := (p_target_ref->>'revision')::INTEGER;
    EXCEPTION WHEN invalid_text_representation THEN
        RAISE EXCEPTION 'mb13_p0_target_ref_invalid:revision';
    END;
    IF v_ref_revision IS DISTINCT FROM p_target_revision OR p_target_ref->>'payload_hash' IS DISTINCT FROM p_target_payload_hash THEN
        RAISE EXCEPTION 'mb13_p0_target_binding_mismatch';
    END IF;

    IF jsonb_typeof(p_monitor_policy) <> 'object'
       OR jsonb_typeof(p_baseline_ref) <> 'object'
       OR jsonb_typeof(p_request_payload) <> 'object'
       OR jsonb_typeof(p_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p0_payload_shape_invalid';
    END IF;
    IF jsonb_typeof(p_consent_refs) <> 'array' OR jsonb_typeof(p_source_refs) <> 'array' OR jsonb_typeof(p_evidence_refs) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p0_refs_must_be_arrays';
    END IF;

    -- Normalize all caller-supplied ref arrays once.
    v_input_consent_refs := public.mb13_p0_normalize_jsonb_array(p_consent_refs);
    v_input_source_refs := public.mb13_p0_normalize_jsonb_array(p_source_refs);
    v_input_evidence_refs := public.mb13_p0_normalize_jsonb_array(p_evidence_refs);

    PERFORM public.mb13_p0_validate_temporal_policy_for_state(p_monitor_policy, p_monitor_state);

    -- Serialize all operations on this owner+stable_id monitor, then load current row.
    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_stable_id, 0));

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = v_owner
       AND t.stable_id = p_stable_id
     FOR UPDATE;

    v_current_found := FOUND;
    v_is_new := NOT FOUND;

    IF v_current_found THEN
        -- Identity is immutable; normalize caller-provided ids to the stored row.
        p_monitor_id := v_current.monitor_id;
        p_stable_id := v_current.stable_id;
        IF p_target_type IS DISTINCT FROM v_current.target_type THEN
            RAISE EXCEPTION 'mb13_p0_target_type_immutable';
        END IF;

        -- Transition payloads must reproduce the current canonical target/baseline.
        IF p_target_ref IS DISTINCT FROM v_current.target_ref THEN
            RAISE EXCEPTION 'mb13_p0_transition_payload_mismatch';
        END IF;
        IF p_target_revision IS DISTINCT FROM v_current.target_revision THEN
            RAISE EXCEPTION 'mb13_p0_transition_payload_mismatch';
        END IF;
        IF p_target_payload_hash IS DISTINCT FROM v_current.target_payload_hash THEN
            RAISE EXCEPTION 'mb13_p0_transition_payload_mismatch';
        END IF;
        IF p_baseline_ref IS DISTINCT FROM v_current.baseline_ref THEN
            RAISE EXCEPTION 'mb13_p0_transition_payload_mismatch';
        END IF;

        -- Caller cannot silently rebind consents during a normal transition.
        v_canonical_consent_refs := public.mb13_p0_normalize_jsonb_array(v_current.consent_refs);
        IF v_input_consent_refs IS DISTINCT FROM v_canonical_consent_refs THEN
            RAISE EXCEPTION 'mb13_p0_transition_consent_mismatch';
        END IF;

        -- Caller-supplied source/evidence refs must be empty or exactly the canonical set.
        IF jsonb_array_length(v_input_source_refs) > 0 AND v_input_source_refs IS DISTINCT FROM v_current.source_refs THEN
            RAISE EXCEPTION 'mb13_p0_source_ref_invalid';
        END IF;
        IF jsonb_array_length(v_input_evidence_refs) > 0 AND v_input_evidence_refs IS DISTINCT FROM v_current.evidence_refs THEN
            RAISE EXCEPTION 'mb13_p0_evidence_ref_invalid';
        END IF;

        -- Reload canonical fields from the database.
        v_canonical_source_refs := public.mb13_p0_normalize_jsonb_array(v_current.source_refs);
        v_canonical_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_current.evidence_refs);

        v_old_state := v_current.monitor_state;
        IF v_old_state = 'revoked' AND p_monitor_state <> 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_revoked_monitor_cannot_reactivate';
        END IF;
        IF NOT (
            (v_old_state = p_monitor_state)
         OR (v_old_state = 'draft' AND p_monitor_state IN ('active','revoked'))
         OR (v_old_state = 'active' AND p_monitor_state IN ('paused','blocked','revoked','completed'))
         OR (v_old_state = 'paused' AND p_monitor_state IN ('active','blocked','revoked'))
         OR (v_old_state = 'blocked' AND p_monitor_state IN ('active','revoked'))
         OR (v_old_state = 'completed' AND p_monitor_state IN ('revoked'))
        ) THEN
            RAISE EXCEPTION 'mb13_p0_transition_invalid:%->%', v_old_state, p_monitor_state;
        END IF;

        v_revision := v_current.current_revision;
    END IF;

    IF v_is_new THEN
        -- New monitors must be created in draft.
        IF p_monitor_state <> 'draft' THEN
            RAISE EXCEPTION 'mb13_p0_monitor_must_be_created_in_draft';
        END IF;
        IF EXISTS (SELECT 1 FROM public.mb13_p0_monitor_target AS t WHERE t.owner_user_id = v_owner AND t.monitor_id = p_monitor_id) THEN
            RAISE EXCEPTION 'mb13_p0_monitor_id_already_exists';
        END IF;

        v_canonical_consent_refs := v_input_consent_refs;
        v_old_state := NULL;
        v_revision := 1;
    END IF;

    -- Derive canonical source/evidence provenance from the authoritative target.
    SELECT source_refs, evidence_refs INTO v_canonical_source_refs, v_canonical_evidence_refs
      FROM public.mb13_p0_get_target_provenance(v_owner, p_target_type, p_target_ref);
    v_canonical_source_refs := public.mb13_p0_normalize_jsonb_array(v_canonical_source_refs);
    v_canonical_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_canonical_evidence_refs);

    -- For new monitors: caller cannot smuggle unverified provenance.
    IF v_is_new THEN
        IF jsonb_array_length(v_input_source_refs) > 0 AND v_input_source_refs IS DISTINCT FROM v_canonical_source_refs THEN
            RAISE EXCEPTION 'mb13_p0_source_ref_invalid';
        END IF;
        IF jsonb_array_length(v_input_evidence_refs) > 0 AND v_input_evidence_refs IS DISTINCT FROM v_canonical_evidence_refs THEN
            RAISE EXCEPTION 'mb13_p0_evidence_ref_invalid';
        END IF;
    END IF;

    -- Validate target currentness before acquiring consent locks for active transitions.
    IF p_monitor_state = 'active' THEN
        PERFORM public.mb13_p0_validate_target(v_owner, p_target_type, p_target_ref, p_for_active => TRUE);
    END IF;

    -- Re-validate and lock the consents that will actually be persisted.
    -- For operational states this also enforces complete coverage.
    v_canonical_consent_refs := public.mb13_p0_lock_and_verify_consents(
        v_owner,
        v_canonical_consent_refs,
        p_target_type,
        p_target_ref,
        p_required => (p_monitor_state IN ('active','paused','blocked','completed'))
    );

    v_result_payload := p_result_payload || jsonb_build_object(
        'monitor_state', p_monitor_state,
        'no_auto_action', true,
        'no_auto_notification', true
    );

    v_canonical := jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'stable_id', p_stable_id,
        'title', p_title,
        'target_type', p_target_type,
        'target_ref', p_target_ref,
        'target_revision', p_target_revision,
        'target_payload_hash', p_target_payload_hash,
        'monitor_reason', p_monitor_reason,
        'monitor_state', p_monitor_state,
        'monitor_policy', p_monitor_policy,
        'consent_refs', v_canonical_consent_refs,
        'source_refs', v_canonical_source_refs,
        'evidence_refs', v_canonical_evidence_refs,
        'baseline_ref', p_baseline_ref,
        'request_payload', p_request_payload,
        'result_payload', v_result_payload,
        'revision', v_revision
    );
    v_payload_hash := public.mb13_p0_hash_jsonb(v_canonical);

    IF v_current_found AND v_current.payload_hash = v_payload_hash AND v_current.monitor_state = p_monitor_state THEN
        RETURN QUERY SELECT v_current.monitor_id, v_current.current_revision, v_current.payload_hash::TEXT;
        RETURN;
    END IF;

    IF v_current_found THEN
        v_revision := v_current.current_revision + 1;
        v_canonical := jsonb_build_object(
            'owner_user_id', v_owner,
            'monitor_id', p_monitor_id,
            'stable_id', p_stable_id,
            'title', p_title,
            'target_type', p_target_type,
            'target_ref', p_target_ref,
            'target_revision', p_target_revision,
            'target_payload_hash', p_target_payload_hash,
            'monitor_reason', p_monitor_reason,
            'monitor_state', p_monitor_state,
            'monitor_policy', p_monitor_policy,
            'consent_refs', v_canonical_consent_refs,
            'source_refs', v_canonical_source_refs,
            'evidence_refs', v_canonical_evidence_refs,
            'baseline_ref', p_baseline_ref,
            'request_payload', p_request_payload,
            'result_payload', v_result_payload,
            'revision', v_revision
        );
        v_payload_hash := public.mb13_p0_hash_jsonb(v_canonical);
    END IF;

    IF NOT v_current_found THEN
        v_event_type := 'MONITOR_CREATED';
    ELSIF v_old_state = 'draft' AND p_monitor_state = 'active' THEN
        v_event_type := 'MONITOR_ACTIVATED';
    ELSIF v_old_state = 'active' AND p_monitor_state = 'paused' THEN
        v_event_type := 'MONITOR_PAUSED';
    ELSIF v_old_state = 'paused' AND p_monitor_state = 'active' THEN
        v_event_type := 'MONITOR_RESUMED';
    ELSIF p_monitor_state = 'blocked' THEN
        v_event_type := 'MONITOR_BLOCKED';
    ELSIF p_monitor_state = 'revoked' THEN
        v_event_type := 'MONITOR_REVOKED';
    ELSE
        v_event_type := NULL;
    END IF;

    v_event_reason := p_result_payload->>'block_reason';

    IF v_is_new THEN
        INSERT INTO public.mb13_p0_monitor_target (
            owner_user_id, monitor_id, stable_id, title, target_type,
            target_ref, target_revision, target_payload_hash,
            monitor_reason, monitor_state, monitor_policy,
            consent_refs, source_refs, evidence_refs, baseline_ref,
            current_revision, payload_hash
        ) VALUES (
            v_owner, p_monitor_id, p_stable_id, p_title, p_target_type,
            p_target_ref, p_target_revision, p_target_payload_hash,
            p_monitor_reason, p_monitor_state, p_monitor_policy,
            v_canonical_consent_refs, v_canonical_source_refs, v_canonical_evidence_refs, p_baseline_ref,
            v_revision, v_payload_hash
        );
    ELSE
        UPDATE public.mb13_p0_monitor_target AS t
           SET title = p_title,
               target_ref = p_target_ref,
               target_revision = p_target_revision,
               target_payload_hash = p_target_payload_hash,
               monitor_reason = p_monitor_reason,
               monitor_state = p_monitor_state,
               monitor_policy = p_monitor_policy,
               consent_refs = v_canonical_consent_refs,
               source_refs = v_canonical_source_refs,
               evidence_refs = v_canonical_evidence_refs,
               baseline_ref = p_baseline_ref,
               current_revision = v_revision,
               payload_hash = v_payload_hash,
               updated_at = NOW()
         WHERE t.owner_user_id = v_owner
           AND t.monitor_id = p_monitor_id;
    END IF;

    INSERT INTO public.mb13_p0_monitor_target_revision (
        owner_user_id, monitor_id, revision, monitor_state, payload_hash,
        target_ref, target_revision, target_payload_hash,
        monitor_reason, monitor_policy, consent_refs, source_refs, evidence_refs, baseline_ref,
        request_payload, result_payload
    ) VALUES (
        v_owner, p_monitor_id, v_revision, p_monitor_state, v_payload_hash,
        p_target_ref, p_target_revision, p_target_payload_hash,
        p_monitor_reason, p_monitor_policy, v_canonical_consent_refs, v_canonical_source_refs, v_canonical_evidence_refs, p_baseline_ref,
        p_request_payload, v_result_payload
    );

    IF v_event_type IS NOT NULL THEN
        v_event_id := gen_random_uuid();
        v_event_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'event_id', v_event_id,
            'owner_user_id', v_owner,
            'monitor_id', p_monitor_id,
            'monitor_revision', v_revision,
            'event_type', v_event_type,
            'event_status', 'recorded',
            'event_time', to_jsonb(v_event_time),
            'observed_ref', '{}'::jsonb,
            'source_refs', v_canonical_source_refs,
            'evidence_refs', v_canonical_evidence_refs,
            'consent_refs', v_canonical_consent_refs,
            'reason', v_event_reason,
            'result_payload', v_result_payload
        ));
        INSERT INTO public.mb13_p0_monitor_event_ledger (
            event_id, owner_user_id, monitor_id, monitor_revision, event_type, event_status, event_time,
            observed_ref, source_refs, evidence_refs, consent_refs, reason, result_payload, payload_hash
        ) VALUES (
            v_event_id, v_owner, p_monitor_id, v_revision, v_event_type, 'recorded', v_event_time,
            '{}'::jsonb, v_canonical_source_refs, v_canonical_evidence_refs, v_canonical_consent_refs, v_event_reason, v_result_payload, v_event_payload_hash
        );
    END IF;

    RETURN QUERY SELECT p_monitor_id, v_revision, v_payload_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_write_monitor(UUID,TEXT,TEXT,TEXT,JSONB,INTEGER,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB) FROM PUBLIC, mb13_p0_app;
GRANT EXECUTE ON FUNCTION public.mb13_p0_write_monitor(UUID,TEXT,TEXT,TEXT,JSONB,INTEGER,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB) TO mb13_p0_app;

COMMIT;
