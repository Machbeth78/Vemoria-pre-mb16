-- VEMORA — Migration V87: Firma graphic asset + proof PDF + public messages
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
--
-- Estende il blocco firma con:
--   1. asset grafico firma (mime, dimensioni, dati base64 inline opzionali)
--   2. path PDF proof scaricabile
--   3. tabella messaggi pubblici controparte (chat guest su sessione firma)

-- ── Firma grafica sul profilo ────────────────────────────────────────────────

ALTER TABLE firma_profili
    ADD COLUMN IF NOT EXISTS signature_mime          TEXT,
    ADD COLUMN IF NOT EXISTS signature_width_px      INTEGER,
    ADD COLUMN IF NOT EXISTS signature_height_px     INTEGER,
    ADD COLUMN IF NOT EXISTS signature_uploaded_at   TIMESTAMPTZ;

COMMENT ON COLUMN firma_profili.signature_asset_path IS
    'Path filesystem alla firma grafica PNG del profilo. Scritto solo al salvataggio esplicito.';
COMMENT ON COLUMN firma_profili.signature_mime IS
    'MIME type dell''asset firma (es. image/png).';

-- ── PDF proof path sulla sessione ────────────────────────────────────────────

ALTER TABLE firma_sessioni
    ADD COLUMN IF NOT EXISTS proof_pdf_path          TEXT,
    ADD COLUMN IF NOT EXISTS proof_pdf_generated_at  TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS proof_pdf_hash          TEXT;

COMMENT ON COLUMN firma_sessioni.proof_pdf_path IS
    'Path al PDF proof scaricabile (generato post-conferma). Contiene QR di verifica.';
COMMENT ON COLUMN firma_sessioni.proof_pdf_hash IS
    'SHA-256 del PDF proof generato, per verifica integrità.';

-- ── Messaggi pubblici su sessione firma (chat guest ↔ owner) ─────────────────
-- Permette alla controparte non registrata di scambiare brevi messaggi con
-- l''owner direttamente sulla landing pubblica (senza richiedere registrazione).
-- Non è una chat completa: max 20 messaggi per sessione, testo breve.

CREATE TABLE IF NOT EXISTS public_session_messages (
    id                  UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    firma_sessione_id   UUID        NOT NULL REFERENCES firma_sessioni(id) ON DELETE CASCADE,
    sender_kind         TEXT        NOT NULL
                                    CHECK (sender_kind IN ('owner', 'counterparty')),
    sender_label        TEXT,                          -- nome dichiarato (non verificato per counterparty)
    sender_email        TEXT,                          -- opzionale, solo counterparty
    testo               TEXT        NOT NULL,
    creato_il           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    read_by_owner_at    TIMESTAMPTZ,
    read_by_counterparty_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_public_session_messages_sess
    ON public_session_messages(firma_sessione_id, creato_il);

COMMENT ON TABLE public_session_messages IS
    'Scambio messaggi leggero tra owner e controparte (non registrata) su sessione firma. Max 20 messaggi.';

-- Nota: registrazione migration demandata al migration runner/registry service.
-- Se la migration viene applicata manualmente via SQL puro, usare poi adopt-existing o status nel runner.
