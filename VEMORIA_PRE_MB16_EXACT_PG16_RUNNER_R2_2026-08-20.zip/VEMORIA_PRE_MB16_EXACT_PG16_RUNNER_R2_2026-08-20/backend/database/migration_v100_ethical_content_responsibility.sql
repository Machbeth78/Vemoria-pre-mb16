-- VEMORIA V79.2J — Ethical use + content responsibility hardening
-- Crea registro eventi legali collegati a invii/contenuti.

CREATE TABLE IF NOT EXISTS content_send_legal_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    content_ref TEXT,
    event_ref TEXT,
    recipient_ref TEXT,
    action_type TEXT NOT NULL DEFAULT 'send',
    legal_registry_version TEXT NOT NULL,
    legal_registry_hash TEXT NOT NULL,
    responsibility_context JSONB NOT NULL DEFAULT '{}'::jsonb,
    evidence_hash TEXT NOT NULL,
    evidence_version TEXT NOT NULL DEFAULT 'V79.2J',
    metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_content_send_legal_user_created
    ON content_send_legal_events(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_content_send_legal_event_ref
    ON content_send_legal_events(event_ref)
    WHERE event_ref IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_content_send_legal_content_ref
    ON content_send_legal_events(content_ref)
    WHERE content_ref IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_content_send_legal_evidence_hash
    ON content_send_legal_events(evidence_hash);
