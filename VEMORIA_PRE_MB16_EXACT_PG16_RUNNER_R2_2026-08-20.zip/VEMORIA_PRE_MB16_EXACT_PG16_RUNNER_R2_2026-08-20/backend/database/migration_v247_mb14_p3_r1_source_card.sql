-- ===========================================================================
-- VEMORA V247 — MB14-P3-R1 SOURCE_CARD envelope compatibility
-- ===========================================================================
-- Scope:
--   1. Add SOURCE_CARD to the generic conversation_card envelope.
--   2. No full Internet verification yet — only envelope foundation.
--
-- NON modifica MB0→MB13 / MB14-P0/P1/P2/P3; solo additive.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- 1. Allow SOURCE_CARD in the generic card envelope.
-- ---------------------------------------------------------------------------
ALTER TABLE conversation_card
    DROP CONSTRAINT IF EXISTS conversation_card_card_type_check;

ALTER TABLE conversation_card
    ADD CONSTRAINT conversation_card_card_type_check
        CHECK (card_type IN (
            'DOCUMENT_CARD','CONTACT_CARD','EVIDENCE_CARD','ACTION_CARD',
            'PROCEDURE_CARD','SAFETY_CARD','THREAT_CARD','INCIDENT_CARD',
            'EXPERIENCE_CAPSULE','SOURCE_CARD','OTHER'
        ));

-- ---------------------------------------------------------------------------
-- 2. Optional future source-card verification provenance table (foundation).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS source_card_verification_state (
    verification_id     UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    card_id             UUID NOT NULL REFERENCES conversation_card(card_id) ON DELETE CASCADE,
    canonical_url       TEXT NOT NULL,
    domain              TEXT NOT NULL,
    source_classification TEXT NOT NULL DEFAULT 'UNVERIFIED'
        CHECK (source_classification IN (
            'VERIFIED_OFFICIAL','VERIFIED_AUTHORITATIVE','UNVERIFIED',
            'STALE','CHANGED','UNAVAILABLE'
        )),
    verified_at         TIMESTAMPTZ,
    verification_method TEXT,
    content_hash        TEXT,
    staleness_policy    TEXT,
    provenance          JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_source_card_verification_owner
    ON source_card_verification_state(owner_user_id, card_id);

-- RLS owner isolation.
ALTER TABLE source_card_verification_state ENABLE ROW LEVEL SECURITY;
ALTER TABLE source_card_verification_state FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS source_card_verification_owner_isolation ON source_card_verification_state;
CREATE POLICY source_card_verification_owner_isolation
    ON source_card_verification_state
    USING (owner_user_id = current_setting('app.owner_id')::UUID);

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'vemoria_app_user') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON source_card_verification_state TO vemoria_app_user;
    END IF;
END $$;
