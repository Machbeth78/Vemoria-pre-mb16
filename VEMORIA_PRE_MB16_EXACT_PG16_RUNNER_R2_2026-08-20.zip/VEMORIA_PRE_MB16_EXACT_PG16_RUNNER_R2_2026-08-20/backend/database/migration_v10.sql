-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V2.9 — Migration V10
-- Alert documenti + indici ottimizzazione archivio

CREATE TABLE IF NOT EXISTS document_alert (
    alert_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id   UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    tipo_alert     TEXT NOT NULL,   -- 'scadenza_vicina'|'scaduto'|'azione_richiesta'
    messaggio      TEXT NOT NULL,
    data_creazione TIMESTAMP NOT NULL DEFAULT NOW(),
    letto          BOOLEAN NOT NULL DEFAULT FALSE
);
CREATE INDEX IF NOT EXISTS idx_alert_documento ON document_alert(documento_id);
CREATE INDEX IF NOT EXISTS idx_alert_letto     ON document_alert(letto);

-- Indici ottimizzazione archivio
CREATE INDEX IF NOT EXISTS idx_memorie_tipo_documento ON memorie(tipo_documento);
CREATE INDEX IF NOT EXISTS idx_memorie_creata_il      ON memorie(creata_il DESC);
CREATE INDEX IF NOT EXISTS idx_documenti_tipo_id      ON documenti(tipo_documento_id);
