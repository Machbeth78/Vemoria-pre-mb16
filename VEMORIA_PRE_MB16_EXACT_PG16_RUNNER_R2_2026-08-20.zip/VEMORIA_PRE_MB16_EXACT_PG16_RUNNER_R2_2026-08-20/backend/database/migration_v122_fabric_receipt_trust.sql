-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.

-- Gate02: persistent owner-scoped trust material for externally issued Fabric
-- receipts. This migration stores public verification material and revocation
-- metadata only. It stores no content keys, plaintext documents or binaries.

ALTER TABLE fabric_endpoint_receipts
    ADD COLUMN IF NOT EXISTS issuer_role TEXT;
ALTER TABLE fabric_endpoint_receipts
    ADD COLUMN IF NOT EXISTS issuer_key_fingerprint CHAR(64);

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'fabric_endpoint_receipts_issuer_role_check'
    ) THEN
        ALTER TABLE fabric_endpoint_receipts
            ADD CONSTRAINT fabric_endpoint_receipts_issuer_role_check
            CHECK (issuer_role IS NULL OR issuer_role IN
                   ('recipient_endpoint','blind_deposit_service'));
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_fabric_receipt_owner_issuer
    ON fabric_endpoint_receipts(owner_user_id, issuer_role,
                                endpoint_device_pseudonym,
                                issuer_key_fingerprint)
    WHERE issuer_role IS NOT NULL;

CREATE TABLE IF NOT EXISTS fabric_receipt_trusted_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    issuer_role TEXT NOT NULL
        CHECK (issuer_role IN ('recipient_endpoint','blind_deposit_service')),
    issuer_pseudonym TEXT NOT NULL,
    issuer_key_fingerprint CHAR(64) NOT NULL,
    public_key_ed25519 BYTEA NOT NULL,
    device_set_epoch BIGINT,
    hardware_attestation_digest CHAR(64),
    trust_status TEXT NOT NULL DEFAULT 'active'
        CHECK (trust_status IN ('pending','active','revoked','expired')),
    trusted_at TIMESTAMPTZ,
    revoked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_user_id, issuer_role, issuer_pseudonym,
           issuer_key_fingerprint),
    CHECK (octet_length(public_key_ed25519) = 32),
    CHECK ((trust_status = 'revoked' AND revoked_at IS NOT NULL)
           OR trust_status <> 'revoked')
);

CREATE INDEX IF NOT EXISTS idx_fabric_trusted_key_owner_status
    ON fabric_receipt_trusted_keys(owner_user_id, trust_status,
                                   issuer_role, issuer_pseudonym);

COMMENT ON TABLE fabric_receipt_trusted_keys IS
    'Owner-scoped public verification keys for externally issued Fabric receipts. No private/content keys.';
COMMENT ON COLUMN fabric_receipt_trusted_keys.public_key_ed25519 IS
    'Public Ed25519 key only; private signing keys remain on the endpoint or isolated blind service.';
