-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V36 — Fraud Patterns Registry
-- Portata dal consolidato V4.6 nel pack Prisma 2026-04-03.
-- Tabella per il registro pattern antifrode.
-- Idempotente (CREATE TABLE IF NOT EXISTS, ADD COLUMN IF NOT EXISTS).

CREATE TABLE IF NOT EXISTS fraud_patterns (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    -- Fingerprint del documento (SHA-256 dei segnali strutturali)
    fingerprint         TEXT,

    -- Tipo documento associato al pattern
    tipo_documento      TEXT,

    -- Dominio email normalizzato (es: "dominio.com") — no indirizzi completi
    dominio_email       TEXT,

    -- Hash SHA-256 dell'IBAN — non reversibile
    iban_hash           TEXT,

    -- Keyword sospette rilevate
    keyword_sospette    TEXT[],

    -- Segnali completi (JSON) da RisultatiSicurezza.segnali_dettaglio
    segnali             JSONB,

    -- Livello rischio: "giallo" | "rosso"
    livello_rischio     TEXT NOT NULL,

    -- Stato del pattern
    stato               TEXT NOT NULL DEFAULT 'osservato'
                        CHECK (stato IN ('osservato', 'confermato_falso', 'confermato_regolare')),

    -- Quante volte questo pattern è stato osservato
    conteggio_occorrenze INTEGER NOT NULL DEFAULT 1,

    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_fp_fingerprint     ON fraud_patterns (fingerprint)   WHERE fingerprint IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_fp_iban_hash        ON fraud_patterns (iban_hash)     WHERE iban_hash IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_fp_dominio_email    ON fraud_patterns (dominio_email) WHERE dominio_email IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_fp_stato            ON fraud_patterns (stato);

-- Tabella feedback utente sui risultati antifrode
CREATE TABLE IF NOT EXISTS fraud_feedback (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id    UUID REFERENCES documenti(id) ON DELETE CASCADE,
    pattern_id      UUID REFERENCES fraud_patterns(id) ON DELETE SET NULL,
    livello_rischio TEXT NOT NULL,          -- livello al momento del feedback
    risposta_utente TEXT NOT NULL           -- "falso" | "regolare" | "non_so"
                    CHECK (risposta_utente IN ('falso', 'regolare', 'non_so')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ff_documento ON fraud_feedback (documento_id);
CREATE INDEX IF NOT EXISTS idx_ff_pattern   ON fraud_feedback (pattern_id) WHERE pattern_id IS NOT NULL;
