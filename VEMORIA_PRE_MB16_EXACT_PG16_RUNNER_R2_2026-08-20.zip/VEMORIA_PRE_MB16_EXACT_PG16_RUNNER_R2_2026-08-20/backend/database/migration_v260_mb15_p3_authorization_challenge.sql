-- MB15 R3A/R3B reconstruction — server-authoritative, single-use execution authorization.
-- Also closes the legacy empty-grant consent amplification fail-closed.

BEGIN;

CREATE TABLE IF NOT EXISTS mb15_p3_authorization_challenges (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    execution_id UUID NOT NULL REFERENCES mb15_p3_goal_executions(id) ON DELETE CASCADE,
    plan_id UUID NOT NULL REFERENCES mb15_p2_goal_execution_plans(id) ON DELETE CASCADE,
    plan_version INTEGER NOT NULL,
    step_id TEXT NOT NULL,
    action TEXT NOT NULL DEFAULT '',
    payload_hash TEXT NOT NULL,
    challenge_secret_hash TEXT NOT NULL,
    challenge_nonce TEXT NOT NULL,
    authenticated_device_id UUID NOT NULL,
    token_epoch BIGINT NOT NULL DEFAULT 0,
    device_set_epoch BIGINT NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING', 'CONFIRMED', 'CONSUMED', 'REVOKED', 'EXPIRED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    confirmed_at TIMESTAMPTZ,
    consumed_at TIMESTAMPTZ,
    revoked_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_mb15_p3_auth_challenge_owner_execution
    ON mb15_p3_authorization_challenges(owner_id, execution_id, step_id);
CREATE INDEX IF NOT EXISTS idx_mb15_p3_auth_challenge_expiry
    ON mb15_p3_authorization_challenges(expires_at);
CREATE UNIQUE INDEX IF NOT EXISTS idx_mb15_p3_auth_challenge_nonce
    ON mb15_p3_authorization_challenges(owner_id, challenge_nonce);

ALTER TABLE mb15_p3_authorization_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb15_p3_authorization_challenges FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS mb15_p3_authorization_challenges_owner_isolation
    ON mb15_p3_authorization_challenges;
CREATE POLICY mb15_p3_authorization_challenges_owner_isolation
    ON mb15_p3_authorization_challenges
    USING (owner_id = _rls_owner_uuid())
    WITH CHECK (owner_id = _rls_owner_uuid());

-- Legacy v230 rows with allowed=TRUE and an empty action map must not silently
-- expand to credentials/sensitive-id/portal/transport authority. Preserve only
-- the narrow historical web-search meaning and require new explicit grants for
-- every other action.
UPDATE internet_consent
SET granted_actions = jsonb_build_object('internet_search', TRUE),
    consent_version = CASE
        WHEN consent_version = 'v1' THEN 'v260-legacy-narrowed'
        ELSE consent_version
    END,
    updated_at = NOW()
WHERE allowed = TRUE
  AND COALESCE(granted_actions, '{}'::jsonb) = '{}'::jsonb;

COMMENT ON COLUMN internet_consent.granted_actions IS
    'Explicit action -> boolean grants. Empty or missing granular grants are fail-closed; legacy allowed-only rows are conservatively narrowed by v260.';

COMMIT;
