-- Vemoria Authorized Memory Macro F
-- Propagazione revoca: grant -> derivati, indici, cache, grafo, code offline.
-- Static contract migration; runtime deletion/neutralization probes remain Devin.

CREATE TABLE IF NOT EXISTS authorized_memory_revocation_jobs (
    revocation_id TEXT PRIMARY KEY CHECK (revocation_id LIKE 'rev_%'),
    owner_id TEXT NOT NULL,
    grant_id TEXT NOT NULL,
    source_id TEXT NOT NULL,
    requested_by_device_id TEXT NOT NULL,
    plan_state TEXT NOT NULL CHECK (plan_state IN ('ready','partial_offline','requires_owner_review','blocked_by_policy')),
    owner_visible_summary TEXT NOT NULL CHECK (length(owner_visible_summary) >= 40),
    append_only_event_required BOOLEAN NOT NULL DEFAULT TRUE CHECK (append_only_event_required = TRUE),
    evidence_graph_neutralization_required BOOLEAN NOT NULL DEFAULT TRUE CHECK (evidence_graph_neutralization_required = TRUE),
    runtime_verification_required BOOLEAN NOT NULL DEFAULT TRUE CHECK (runtime_verification_required = TRUE),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS authorized_memory_revocation_targets (
    revocation_id TEXT NOT NULL REFERENCES authorized_memory_revocation_jobs(revocation_id) ON DELETE CASCADE,
    artifact_ref TEXT NOT NULL,
    artifact_kind TEXT NOT NULL,
    action TEXT NOT NULL CHECK (action IN (
        'mark_grant_revoked','stop_future_work','delete','neutralize','detach_from_graph',
        'tombstone_search','queue_remote_revocation','require_owner_review',
        'mark_external_out_of_scope','cancel_sync_job'
    )),
    target_state TEXT NOT NULL CHECK (target_state IN (
        'planned','applied_statically','queued_offline','requires_owner_review','external_out_of_scope','blocked_policy'
    )),
    device_id TEXT NOT NULL,
    content_id TEXT NULL CHECK (content_id IS NULL OR content_id ~ '^cnt_[0-9a-f]{64}$'),
    requires_search_tombstone BOOLEAN NOT NULL DEFAULT FALSE,
    blocks_future_query_results BOOLEAN NOT NULL DEFAULT FALSE,
    owner_visible_effect TEXT NOT NULL CHECK (length(owner_visible_effect) >= 18),
    PRIMARY KEY (revocation_id, artifact_ref),
    CHECK (artifact_ref !~ '(^/|^[A-Za-z]:\\|/Users/|/home/|/storage/|/sdcard/|content://|file://|smb://|\\\\)'),
    CHECK (requires_search_tombstone = FALSE OR blocks_future_query_results = TRUE),
    CHECK (artifact_kind <> 'canonical_memory_item' OR action = 'require_owner_review'),
    CHECK (artifact_kind <> 'external_export' OR action = 'mark_external_out_of_scope'),
    CHECK (target_state <> 'queued_offline' OR action = 'queue_remote_revocation')
);

CREATE TABLE IF NOT EXISTS authorized_memory_revocation_dependency_edges (
    revocation_id TEXT NOT NULL REFERENCES authorized_memory_revocation_jobs(revocation_id) ON DELETE CASCADE,
    parent_artifact_ref TEXT NOT NULL,
    child_artifact_ref TEXT NOT NULL,
    relation TEXT NOT NULL CHECK (relation IN (
        'produced_derivative','indexed_by','cached_by','linked_in_evidence_graph',
        'similarity_candidate','owner_equivalence','queued_on_device'
    )),
    PRIMARY KEY (revocation_id, parent_artifact_ref, child_artifact_ref),
    CHECK (parent_artifact_ref <> child_artifact_ref),
    CHECK (parent_artifact_ref !~ '(^/|^[A-Za-z]:\\|/Users/|/home/|/storage/|/sdcard/|content://|file://|smb://|\\\\)'),
    CHECK (child_artifact_ref !~ '(^/|^[A-Za-z]:\\|/Users/|/home/|/storage/|/sdcard/|content://|file://|smb://|\\\\)')
);

CREATE TABLE IF NOT EXISTS authorized_memory_revocation_search_tombstones (
    revocation_id TEXT NOT NULL REFERENCES authorized_memory_revocation_jobs(revocation_id) ON DELETE CASCADE,
    owner_id TEXT NOT NULL,
    artifact_ref TEXT NOT NULL,
    content_id TEXT NULL CHECK (content_id IS NULL OR content_id ~ '^cnt_[0-9a-f]{64}$'),
    blocks_future_query_results BOOLEAN NOT NULL DEFAULT TRUE CHECK (blocks_future_query_results = TRUE),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (revocation_id, artifact_ref),
    CHECK (artifact_ref !~ '(^/|^[A-Za-z]:\\|/Users/|/home/|/storage/|/sdcard/|content://|file://|smb://|\\\\)')
);
