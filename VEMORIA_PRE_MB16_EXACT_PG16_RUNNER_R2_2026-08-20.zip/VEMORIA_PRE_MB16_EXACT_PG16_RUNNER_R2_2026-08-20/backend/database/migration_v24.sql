-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V4.5 PATCH — Migration V24
-- Fix FK originale_id ON DELETE SET NULL
-- Fix parent_version_id ON DELETE SET NULL  
-- Exclude is_deleted memorie from search

-- Drop old FK if exists and re-add with ON DELETE SET NULL
ALTER TABLE documenti
    DROP CONSTRAINT IF EXISTS documenti_originale_id_fkey,
    DROP CONSTRAINT IF EXISTS documenti_parent_version_id_fkey;

ALTER TABLE documenti
    ADD CONSTRAINT documenti_originale_id_fkey
        FOREIGN KEY (originale_id) REFERENCES documenti(id) ON DELETE SET NULL,
    ADD CONSTRAINT documenti_parent_version_id_fkey
        FOREIGN KEY (parent_version_id) REFERENCES documenti(id) ON DELETE SET NULL;

-- Index to exclude deleted memorie efficiently
CREATE INDEX IF NOT EXISTS idx_memorie_active
    ON memorie(proprietario_id, creata_il DESC)
    WHERE is_deleted = FALSE;

-- Exclude in_attesa_utente from default archivio if stato filter not applied
CREATE INDEX IF NOT EXISTS idx_doc_stato_owner
    ON documenti(proprietario_id, stato_elaborazione);
