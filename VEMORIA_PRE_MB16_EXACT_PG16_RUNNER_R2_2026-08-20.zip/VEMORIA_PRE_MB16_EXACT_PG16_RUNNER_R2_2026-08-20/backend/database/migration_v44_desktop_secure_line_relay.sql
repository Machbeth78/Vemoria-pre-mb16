-- VEMORA
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
-- Tutti i diritti riservati.
--
-- Desktop Companion / Secure Line Relay & Presence V1

CREATE TABLE IF NOT EXISTS desktop_secure_line_presence (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id     UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    channel       TEXT NOT NULL,
    presence_key  TEXT NOT NULL,
    device_id     UUID NULL REFERENCES desktop_devices(id) ON DELETE CASCADE,
    display_name  TEXT,
    status        TEXT NOT NULL DEFAULT 'online',
    session_hint  TEXT,
    details       JSONB,
    last_seen_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_secure_line_presence
    ON desktop_secure_line_presence (utente_id, channel, presence_key);

CREATE INDEX IF NOT EXISTS idx_secure_line_presence_seen
    ON desktop_secure_line_presence (utente_id, last_seen_at DESC);


CREATE TABLE IF NOT EXISTS desktop_secure_line_relay_tickets (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    request_id          UUID NOT NULL REFERENCES desktop_secure_line_requests(id) ON DELETE CASCADE,
    issued_for_channel  TEXT NOT NULL,
    issued_for_device_id UUID NULL REFERENCES desktop_devices(id) ON DELETE SET NULL,
    relay_ticket        TEXT NOT NULL,
    purpose             TEXT NOT NULL,
    status              TEXT NOT NULL DEFAULT 'active',
    payload             JSONB,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at          TIMESTAMPTZ NOT NULL,
    consumed_at         TIMESTAMPTZ NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_secure_line_relay_ticket_token
    ON desktop_secure_line_relay_tickets (relay_ticket);

CREATE INDEX IF NOT EXISTS idx_secure_line_relay_ticket_lookup
    ON desktop_secure_line_relay_tickets (utente_id, purpose, status, expires_at DESC);
