-- VEMORA MB13-P3 v215 — Evidence failure, expiry and terminal provenance closure
-- Non modificare MB13-P1/MB13-P2. Non aprire R3. Non produrre APK/AAB.

BEGIN;

-- ----------------------------------------------------------------------------
-- 1. Pack provenance snapshot: record monitor policy hash at pack creation/revision
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p3_action_pack
    ADD COLUMN IF NOT EXISTS monitor_policy_hash TEXT;

UPDATE public.mb13_p3_action_pack p
SET monitor_policy_hash = COALESCE(
    p.monitor_policy_hash,
    public.mb13_p0_hash_jsonb(COALESCE((SELECT m.monitor_policy FROM public.mb13_p0_monitor_target m WHERE m.owner_user_id = p.owner_user_id AND m.monitor_id = p.monitor_id), '{}'::jsonb))
)
WHERE p.monitor_policy_hash IS NULL;

ALTER TABLE public.mb13_p3_action_pack
    ALTER COLUMN monitor_policy_hash SET NOT NULL;

-- Ensure new/updated rows capture the policy hash of the monitor revision they bind to.
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_monitor_policy_hash()
RETURNS TRIGGER AS $$
DECLARE
    v_policy_hash TEXT;
BEGIN
    IF TG_OP = 'INSERT' OR NEW.monitor_revision IS DISTINCT FROM OLD.monitor_revision THEN
        SELECT public.mb13_p0_hash_jsonb(COALESCE(m.monitor_policy, '{}'::jsonb))
          INTO v_policy_hash
          FROM public.mb13_p0_monitor_target m
         WHERE m.owner_user_id = NEW.owner_user_id
           AND m.monitor_id = NEW.monitor_id;
        IF v_policy_hash IS NOT NULL THEN
            NEW.monitor_policy_hash := v_policy_hash;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_monitor_policy_hash ON public.mb13_p3_action_pack;
CREATE TRIGGER trg_mb13_p3_action_pack_monitor_policy_hash
    BEFORE INSERT OR UPDATE ON public.mb13_p3_action_pack
    FOR EACH ROW
    EXECUTE FUNCTION public.mb13_p3_action_pack_monitor_policy_hash();

-- ----------------------------------------------------------------------------
-- 2. Allow failure_receipt evidence type
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p3_action_pack_evidence
    DROP CONSTRAINT IF EXISTS ck_mb13_p3_evidence_type_values;
ALTER TABLE public.mb13_p3_action_pack_evidence
    ADD CONSTRAINT ck_mb13_p3_evidence_type_values
    CHECK (evidence_state <> 'active' OR evidence_type IN ('simulation_receipt','internal_action_receipt','step_result','failure_receipt'));

-- ----------------------------------------------------------------------------
-- 3. Canonical evidence payload builder and semantic validator
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_canonicalize_evidence_payload(
    p_pack public.mb13_p3_action_pack,
    p_evidence_type TEXT,
    p_evidence_payload JSONB
) RETURNS JSONB AS $$
DECLARE
    v_schema_version TEXT;
    v_status TEXT;
    v_details JSONB;
    v_action_result JSONB;
    v_required_action_type TEXT;
    v_pack_target_hash TEXT;
    v_target_ref_hash TEXT;
    v_step JSONB;
    v_step_number INTEGER;
    v_covered_steps JSONB;
    v_step_target_hash TEXT;
    v_failure_code TEXT;
    v_failed_step INTEGER;
    v_n INTEGER;
    v_allowed_statuses TEXT[];
BEGIN
    IF p_evidence_payload IS NULL OR jsonb_typeof(p_evidence_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_payload_invalid';
    END IF;
    IF p_evidence_payload = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_payload_empty';
    END IF;

    v_schema_version := NULLIF(p_evidence_payload->>'schema_version', '');
    IF v_schema_version IS DISTINCT FROM 'mb13-p3-evidence/v1' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_schema_version_not_allowed';
    END IF;

    v_status := NULLIF(p_evidence_payload->>'status', '');
    IF v_status IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_evidence_status_required';
    END IF;

    v_details := p_evidence_payload->'details';
    IF v_details IS NULL OR jsonb_typeof(v_details) <> 'object' OR v_details = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_details_required';
    END IF;

    v_action_result := p_evidence_payload->'action_result';
    IF v_action_result IS NULL OR jsonb_typeof(v_action_result) <> 'object' OR v_action_result = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_action_result_required';
    END IF;
    IF v_action_result ? 'status' AND v_action_result->>'status' IS DISTINCT FROM v_status THEN
        RAISE EXCEPTION 'mb13_p3_evidence_action_result_status_mismatch';
    END IF;
    IF NOT (v_action_result ? 'status') THEN
        v_action_result := v_action_result || jsonb_build_object('status', v_status);
    END IF;

    v_pack_target_hash := public.mb13_p0_hash_jsonb(COALESCE(p_pack.target_ref, '{}'::jsonb));

    IF p_evidence_type = 'simulation_receipt' AND p_pack.action_type IS DISTINCT FROM 'simulate' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_type_action_mismatch';
    END IF;
    IF p_evidence_type = 'internal_action_receipt' AND p_pack.action_type IS DISTINCT FROM 'internal' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_type_action_mismatch';
    END IF;

    v_required_action_type := COALESCE(NULLIF(p_evidence_payload->>'action_type', ''), p_pack.action_type);

    IF p_evidence_type = 'step_result' THEN
        IF NOT (p_evidence_payload ? 'step_number') THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_required_for_step_result';
        END IF;
        BEGIN
            v_step_number := NULLIF(p_evidence_payload->>'step_number', '')::INTEGER;
        EXCEPTION WHEN OTHERS THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_invalid';
        END;
        IF v_step_number IS NULL OR v_step_number <= 0 THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_invalid';
        END IF;

        SELECT s INTO v_step
          FROM jsonb_array_elements(COALESCE(p_pack.steps, '[]'::jsonb)) s
         WHERE NULLIF(s->>'step_number', '')::INTEGER = v_step_number
         LIMIT 1;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_not_found';
        END IF;
        IF v_step ? 'action_type' AND v_step->>'action_type' IS DISTINCT FROM p_pack.action_type THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_action_type_mismatch';
        END IF;
        IF v_required_action_type IS DISTINCT FROM COALESCE(v_step->>'action_type', p_pack.action_type) THEN
            RAISE EXCEPTION 'mb13_p3_evidence_payload_action_type_mismatch';
        END IF;

        v_step_target_hash := public.mb13_p0_hash_jsonb(COALESCE(v_step->'target_ref', '{}'::jsonb));
        IF p_evidence_payload ? 'target_ref_hash' AND p_evidence_payload->>'target_ref_hash' IS DISTINCT FROM v_step_target_hash THEN
            RAISE EXCEPTION 'mb13_p3_evidence_target_ref_hash_mismatch';
        END IF;
        v_target_ref_hash := v_step_target_hash;

        v_allowed_statuses := ARRAY['ok','completed','failed','skipped'];
        v_covered_steps := COALESCE(p_evidence_payload->'covered_steps', '[]'::jsonb);
        IF jsonb_typeof(v_covered_steps) <> 'array' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_steps_invalid';
        END IF;
        -- canonical covered steps for a step_result is the step number itself
        v_covered_steps := jsonb_build_array(v_step_number);
    ELSIF p_evidence_type IN ('simulation_receipt','internal_action_receipt') THEN
        v_allowed_statuses := ARRAY['ok','completed','partial','failed'];
        IF v_required_action_type IS DISTINCT FROM p_pack.action_type THEN
            RAISE EXCEPTION 'mb13_p3_evidence_payload_action_type_mismatch';
        END IF;
        IF p_evidence_payload ? 'target_ref_hash' AND p_evidence_payload->>'target_ref_hash' IS DISTINCT FROM v_pack_target_hash THEN
            RAISE EXCEPTION 'mb13_p3_evidence_target_ref_hash_mismatch';
        END IF;
        v_target_ref_hash := v_pack_target_hash;

        v_covered_steps := COALESCE(p_evidence_payload->'covered_steps', '[]'::jsonb);
        IF jsonb_typeof(v_covered_steps) <> 'array' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_steps_invalid';
        END IF;
        FOR v_n IN SELECT NULLIF(jt.value, '')::INTEGER FROM jsonb_array_elements_text(v_covered_steps) AS jt(value) LOOP
            IF v_n IS NULL OR v_n <= 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM jsonb_array_elements(COALESCE(p_pack.steps, '[]'::jsonb)) s
                WHERE NULLIF(s->>'step_number', '')::INTEGER = v_n
            ) THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_not_found';
            END IF;
        END LOOP;
    ELSIF p_evidence_type = 'failure_receipt' THEN
        v_allowed_statuses := ARRAY['failed'];
        IF v_status IS DISTINCT FROM 'failed' THEN
            RAISE EXCEPTION 'mb13_p3_failure_receipt_status_must_be_failed';
        END IF;

        v_failure_code := NULLIF(p_evidence_payload->>'failure_code', '');
        IF v_failure_code IS NULL THEN
            RAISE EXCEPTION 'mb13_p3_failure_receipt_code_required';
        END IF;
        IF v_details IS NULL OR v_details = '{}'::jsonb THEN
            RAISE EXCEPTION 'mb13_p3_failure_receipt_details_required';
        END IF;
        IF v_required_action_type IS DISTINCT FROM p_pack.action_type THEN
            RAISE EXCEPTION 'mb13_p3_evidence_payload_action_type_mismatch';
        END IF;
        IF p_evidence_payload ? 'target_ref_hash' AND p_evidence_payload->>'target_ref_hash' IS DISTINCT FROM v_pack_target_hash THEN
            RAISE EXCEPTION 'mb13_p3_evidence_target_ref_hash_mismatch';
        END IF;
        v_target_ref_hash := v_pack_target_hash;

        v_failed_step := NULLIF(p_evidence_payload->>'failed_step', '')::INTEGER;
        IF v_failed_step IS NOT NULL THEN
            IF NOT EXISTS (
                SELECT 1 FROM jsonb_array_elements(COALESCE(p_pack.steps, '[]'::jsonb)) s
                WHERE NULLIF(s->>'step_number', '')::INTEGER = v_failed_step
            ) THEN
                RAISE EXCEPTION 'mb13_p3_failure_receipt_step_not_found';
            END IF;
        END IF;
        IF v_failed_step IS NULL AND (NOT (v_action_result ? 'status') OR v_action_result->>'status' IS DISTINCT FROM 'failed') THEN
            RAISE EXCEPTION 'mb13_p3_failure_receipt_step_or_action_required';
        END IF;

        v_covered_steps := COALESCE(p_evidence_payload->'covered_steps', '[]'::jsonb);
        IF jsonb_typeof(v_covered_steps) <> 'array' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_steps_invalid';
        END IF;
        FOR v_n IN SELECT NULLIF(jt.value, '')::INTEGER FROM jsonb_array_elements_text(v_covered_steps) AS jt(value) LOOP
            IF v_n IS NULL OR v_n <= 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM jsonb_array_elements(COALESCE(p_pack.steps, '[]'::jsonb)) s
                WHERE NULLIF(s->>'step_number', '')::INTEGER = v_n
            ) THEN
                RAISE EXCEPTION 'mb13_p3_evidence_covered_step_not_found';
            END IF;
        END LOOP;
    ELSE
        RAISE EXCEPTION 'mb13_p3_evidence_type_not_allowed';
    END IF;

    IF NOT (v_status = ANY (v_allowed_statuses)) THEN
        RAISE EXCEPTION 'mb13_p3_evidence_status_not_allowed_for_type';
    END IF;

    RETURN p_evidence_payload
        || jsonb_build_object(
            'action_type', v_required_action_type,
            'target_ref_hash', v_target_ref_hash,
            'covered_steps', v_covered_steps,
            'action_result', v_action_result
        );
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_canonicalize_evidence_payload(public.mb13_p3_action_pack, TEXT, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_canonicalize_evidence_payload(public.mb13_p3_action_pack, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_canonicalize_evidence_payload(public.mb13_p3_action_pack, TEXT, JSONB) TO mb13_p3_writer;

-- ----------------------------------------------------------------------------
-- 4. Evidence registration with canonical payload, idempotency-first and step-consent validation
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_record_execution_evidence(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_attempt_number INTEGER,
    p_evidence_type TEXT,
    p_evidence_payload JSONB,
    p_idempotency_key TEXT
) RETURNS TABLE(
    evidence_id UUID,
    receipt_id UUID,
    evidence_hash TEXT
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_executor_identity TEXT := session_user;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_canonical_payload JSONB;
    v_evidence_hash TEXT;
    v_request_hash TEXT;
    v_receipt_id UUID;
    v_new_id UUID;
    v_existing public.mb13_p3_action_pack_evidence%ROWTYPE;
    v_step_number INTEGER;
    v_step_consents JSONB := '[]'::jsonb;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    IF p_idempotency_key IS NULL OR p_idempotency_key = '' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_idempotency_key_required';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.attempt_number IS DISTINCT FROM p_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;
    IF v_attempt.executor_identity IS DISTINCT FROM v_executor_identity THEN
        RAISE EXCEPTION 'mb13_p3_executor_identity_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;
    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    v_canonical_payload := public.mb13_p3_canonicalize_evidence_payload(v_pack, p_evidence_type, p_evidence_payload);

    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'pack_id', p_pack_id,
        'pack_revision', v_pack.pack_revision,
        'attempt_id', p_attempt_id,
        'attempt_number', p_attempt_number,
        'monitor_revision', v_monitor.current_revision,
        'executor_identity', v_executor_identity,
        'evidence_type', p_evidence_type,
        'schema_version', v_canonical_payload->>'schema_version',
        'evidence_payload', v_canonical_payload
    ));

    -- Idempotent lookup first: if the evidence is already persisted, return it.
    SELECT * INTO v_existing
      FROM public.mb13_p3_action_pack_evidence
     WHERE owner_user_id = p_owner_user_id
       AND attempt_id = p_attempt_id
       AND idempotency_key = p_idempotency_key
     FOR UPDATE;
    IF FOUND THEN
        IF v_existing.evidence_request_hash IS DISTINCT FROM v_request_hash
           OR v_existing.evidence_type IS DISTINCT FROM p_evidence_type
           OR v_existing.evidence_payload IS DISTINCT FROM v_canonical_payload
           OR v_existing.evidence_state IS DISTINCT FROM 'active' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_idempotency_conflict';
        END IF;
        RETURN QUERY SELECT v_existing.evidence_id, v_existing.receipt_id, v_existing.evidence_hash;
        RETURN;
    END IF;

    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    -- Determine step consent context for this evidence and validate the full chain.
    IF p_evidence_type = 'step_result' OR (p_evidence_type = 'failure_receipt' AND (v_canonical_payload ? 'failed_step')) THEN
        BEGIN
            v_step_number := NULLIF(v_canonical_payload->>'step_number', '')::INTEGER;
            IF v_step_number IS NULL AND v_canonical_payload ? 'failed_step' THEN
                v_step_number := NULLIF(v_canonical_payload->>'failed_step', '')::INTEGER;
            END IF;
        EXCEPTION WHEN OTHERS THEN
            v_step_number := NULL;
        END;
        IF v_step_number IS NOT NULL THEN
            SELECT COALESCE(s->'consent_refs', '[]'::jsonb) INTO v_step_consents
              FROM jsonb_array_elements(COALESCE(v_pack.steps, '[]'::jsonb)) s
             WHERE NULLIF(s->>'step_number', '')::INTEGER = v_step_number
             LIMIT 1;
        END IF;
    END IF;

    PERFORM public.mb13_p3_validate_source_grant_chain(
        p_owner_user_id, v_monitor, v_pack.consent_refs, v_pack.provenance_refs, v_step_consents
    );

    v_evidence_hash := public.mb13_p0_hash_jsonb(v_canonical_payload);
    v_receipt_id := gen_random_uuid();

    INSERT INTO public.mb13_p3_action_pack_evidence (
        owner_user_id, pack_id, attempt_id, attempt_number, pack_revision, monitor_revision,
        executor_identity, evidence_type, evidence_hash, receipt_id, evidence_payload,
        evidence_schema_version, idempotency_key, evidence_request_hash, evidence_state, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, p_attempt_number, v_pack.pack_revision,
        v_monitor.current_revision, v_executor_identity, p_evidence_type, v_evidence_hash,
        v_receipt_id, v_canonical_payload, 'mb13-p3-evidence/v1', p_idempotency_key,
        v_request_hash, 'active', v_now
    )
    ON CONFLICT ON CONSTRAINT uq_mb13_p3_evidence_owner_attempt_idempotency DO NOTHING
    RETURNING public.mb13_p3_action_pack_evidence.evidence_id INTO v_new_id;

    IF v_new_id IS NULL THEN
        SELECT * INTO v_existing
          FROM public.mb13_p3_action_pack_evidence
         WHERE owner_user_id = p_owner_user_id
           AND attempt_id = p_attempt_id
           AND idempotency_key = p_idempotency_key
         FOR UPDATE;
        IF FOUND THEN
            IF v_existing.evidence_request_hash IS DISTINCT FROM v_request_hash
               OR v_existing.evidence_type IS DISTINCT FROM p_evidence_type
               OR v_existing.evidence_payload IS DISTINCT FROM v_canonical_payload
               OR v_existing.evidence_state IS DISTINCT FROM 'active' THEN
                RAISE EXCEPTION 'mb13_p3_evidence_idempotency_conflict';
            END IF;
            RETURN QUERY SELECT v_existing.evidence_id, v_existing.receipt_id, v_existing.evidence_hash;
            RETURN;
        END IF;
        RAISE EXCEPTION 'mb13_p3_evidence_insert_failed';
    END IF;

    RETURN QUERY SELECT v_new_id, v_receipt_id, v_evidence_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_record_execution_evidence(UUID, UUID, UUID, INTEGER, TEXT, JSONB, TEXT) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_record_execution_evidence(UUID, UUID, UUID, INTEGER, TEXT, JSONB, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_record_execution_evidence(UUID, UUID, UUID, INTEGER, TEXT, JSONB, TEXT) TO mb13_p3_executor, mb13_p3_writer;

-- ----------------------------------------------------------------------------
-- 5. Result evidence canonicalizer (supports completed/partial/failure_receipt)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_canonicalize_result_evidence(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_result_payload JSONB
) RETURNS JSONB AS $$
DECLARE
    v_evidence JSONB;
    v_evidence_type TEXT;
    v_evidence_id UUID;
    v_receipt_id UUID;
    v_row public.mb13_p3_action_pack_evidence%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_expected_hash TEXT;
    v_canonical JSONB;
BEGIN
    IF p_result_payload IS NULL OR jsonb_typeof(p_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_payload_invalid';
    END IF;

    v_evidence := p_result_payload->'evidence';
    IF v_evidence IS NULL OR jsonb_typeof(v_evidence) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_required';
    END IF;
    IF v_evidence ? 'evidence_hash' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_hash_from_body_forbidden';
    END IF;

    v_evidence_type := NULLIF(v_evidence->>'evidence_type', '');
    v_evidence_id := NULLIF(v_evidence->>'evidence_id', '')::UUID;
    v_receipt_id := NULLIF(v_evidence->>'receipt_id', '')::UUID;

    IF v_evidence_type IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_type_required';
    END IF;
    IF v_evidence_id IS NULL AND v_receipt_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_not_pre_registered';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_evidence_id IS NOT NULL THEN
        SELECT * INTO v_row
          FROM public.mb13_p3_action_pack_evidence
         WHERE evidence_id = v_evidence_id
           AND owner_user_id = p_owner_user_id;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_found';
        END IF;
        IF v_row.pack_id IS DISTINCT FROM p_pack_id OR v_row.attempt_id IS DISTINCT FROM p_attempt_id THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_bound';
        END IF;
        IF v_receipt_id IS NOT NULL AND v_row.receipt_id IS DISTINCT FROM v_receipt_id THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_receipt_mismatch';
        END IF;
    ELSE
        SELECT * INTO v_row
          FROM public.mb13_p3_action_pack_evidence
         WHERE receipt_id = v_receipt_id
           AND owner_user_id = p_owner_user_id;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_found';
        END IF;
        IF v_row.pack_id IS DISTINCT FROM p_pack_id OR v_row.attempt_id IS DISTINCT FROM p_attempt_id THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_bound';
        END IF;
    END IF;

    IF v_row.evidence_state IS DISTINCT FROM 'active' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_quarantined';
    END IF;

    PERFORM public.mb13_p3_canonicalize_evidence_payload(v_pack, v_row.evidence_type, v_row.evidence_payload);

    IF v_row.evidence_type IS DISTINCT FROM v_evidence_type THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_type_mismatch';
    END IF;
    IF v_row.attempt_number IS DISTINCT FROM v_attempt.attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_attempt_number_mismatch';
    END IF;
    IF v_row.pack_revision IS DISTINCT FROM v_pack.pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_pack_revision_mismatch';
    END IF;
    IF v_row.monitor_revision IS DISTINCT FROM v_pack.monitor_revision THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_monitor_revision_mismatch';
    END IF;
    IF v_row.executor_identity IS DISTINCT FROM v_attempt.executor_identity THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_executor_identity_mismatch';
    END IF;
    IF v_row.evidence_schema_version IS DISTINCT FROM 'mb13-p3-evidence/v1' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_schema_version_mismatch';
    END IF;

    v_expected_hash := public.mb13_p0_hash_jsonb(v_row.evidence_payload);
    IF v_row.evidence_hash IS DISTINCT FROM v_expected_hash THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_integrity_failure';
    END IF;

    v_canonical := jsonb_build_object(
        'evidence', jsonb_build_object(
            'evidence_id', v_row.evidence_id,
            'receipt_id', v_row.receipt_id,
            'evidence_type', v_row.evidence_type
        ),
        'evidence_hash', v_row.evidence_hash,
        'evidence_payload', v_row.evidence_payload
    );
    RETURN v_canonical;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_canonicalize_result_evidence(UUID, UUID, UUID, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_canonicalize_result_evidence(UUID, UUID, UUID, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_canonicalize_result_evidence(UUID, UUID, UUID, JSONB) TO mb13_p3_writer;

-- ----------------------------------------------------------------------------
-- 6. Complete action pack: failure proof, step coverage, idempotent replay, terminal provenance
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_complete_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_expected_pack_revision INTEGER,
    p_expected_attempt_number INTEGER,
    p_outcome TEXT,
    p_result_payload JSONB
) RETURNS TABLE(
    attempt_id UUID,
    pack_id UUID,
    attempt_number INTEGER,
    status TEXT,
    result_hash TEXT,
    completed_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_existing_result public.mb13_p3_action_pack_result%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_transition_monitor_revision INTEGER;
    v_transition_policy_hash TEXT;
    v_pack_policy_hash TEXT;
    v_result_hash TEXT;
    v_event_kind TEXT;
    v_old_status TEXT;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_canonical_evidence JSONB;
    v_evidence_payload JSONB;
    v_evidence_status TEXT;
    v_covered_steps JSONB;
    v_result_payload JSONB;
    v_status_allowed BOOLEAN;
    v_pack_step_numbers INTEGER[];
    v_covered INTEGER[];
    v_missing INTEGER;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_outcome NOT IN ('completed','partial','failed') THEN
        RAISE EXCEPTION 'mb13_p3_invalid_outcome';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;
    IF v_attempt.attempt_number IS DISTINCT FROM p_expected_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    IF p_result_payload IS NULL THEN
        v_result_payload := '{}'::jsonb;
    ELSE
        v_result_payload := p_result_payload;
    END IF;
    IF jsonb_typeof(v_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_payload_invalid';
    END IF;

    IF NOT (v_result_payload ? 'evidence') THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_required';
    END IF;

    IF v_result_payload ? 'outcome' THEN
        IF v_result_payload->>'outcome' IS DISTINCT FROM p_outcome THEN
            RAISE EXCEPTION 'mb13_p3_result_payload_outcome_mismatch';
        END IF;
    END IF;

    v_canonical_evidence := public.mb13_p3_canonicalize_result_evidence(p_owner_user_id, p_pack_id, p_attempt_id, v_result_payload);
    v_evidence_payload := v_canonical_evidence->'evidence_payload';
    v_evidence_status := v_evidence_payload->>'status';

    IF p_outcome = 'failed' THEN
        IF v_canonical_evidence->'evidence'->>'evidence_type' IS DISTINCT FROM 'failure_receipt' THEN
            RAISE EXCEPTION 'mb13_p3_result_failure_receipt_required';
        END IF;
    ELSE
        IF v_canonical_evidence->'evidence'->>'evidence_type' IS DISTINCT FROM 'failure_receipt' THEN
            v_status_allowed := false;
            IF p_outcome = 'completed' AND v_evidence_status IN ('ok','completed') THEN
                v_status_allowed := true;
            END IF;
            IF p_outcome = 'partial' AND v_evidence_status IN ('ok','completed','partial') THEN
                v_status_allowed := true;
            END IF;
            IF NOT v_status_allowed THEN
                RAISE EXCEPTION 'mb13_p3_evidence_status_incompatible_with_outcome';
            END IF;
        ELSE
            RAISE EXCEPTION 'mb13_p3_evidence_status_incompatible_with_outcome';
        END IF;
    END IF;

    -- Completed outcome requires all mandatory steps to be covered.
    IF p_outcome = 'completed' THEN
        SELECT array_agg(NULLIF(s->>'step_number', '')::INTEGER ORDER BY NULLIF(s->>'step_number', '')::INTEGER)
          INTO v_pack_step_numbers
          FROM jsonb_array_elements(COALESCE(v_pack.steps, '[]'::jsonb)) s;
        SELECT array_agg(NULLIF(jt.value, '')::INTEGER)
          INTO v_covered
          FROM jsonb_array_elements_text(v_evidence_payload->'covered_steps') AS jt(value);
        IF v_pack_step_numbers IS NOT NULL THEN
            FOREACH v_missing IN ARRAY v_pack_step_numbers LOOP
                IF NOT (v_missing = ANY (v_covered)) THEN
                    RAISE EXCEPTION 'mb13_p3_evidence_step_coverage_incomplete';
                END IF;
            END LOOP;
        END IF;
    END IF;

    v_transition_monitor_revision := v_monitor.current_revision;
    v_transition_policy_hash := public.mb13_p0_hash_jsonb(COALESCE(v_monitor.monitor_policy, '{}'::jsonb));
    v_pack_policy_hash := v_pack.monitor_policy_hash;

    v_result_payload := v_result_payload - 'evidence_hash' - 'evidence' - 'outcome' - 'evidence_payload';
    v_result_payload := v_result_payload || jsonb_build_object(
        'outcome', p_outcome,
        'evidence', v_canonical_evidence->'evidence',
        'evidence_hash', v_canonical_evidence->'evidence_hash',
        'evidence_payload', v_canonical_evidence->'evidence_payload'
    );

    SELECT * INTO v_existing_result
      FROM public.mb13_p3_action_pack_result
     WHERE attempt_id = p_attempt_id
       AND owner_user_id = p_owner_user_id;
    IF FOUND THEN
        IF v_existing_result.outcome IS DISTINCT FROM p_outcome THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
        IF v_existing_result.result_payload IS DISTINCT FROM v_result_payload THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
        RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                            p_outcome::TEXT, v_existing_result.result_hash, v_existing_result.created_at;
        RETURN;
    END IF;

    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    v_event_kind := p_outcome;
    v_old_status := v_pack.status;

    v_result_hash := public.mb13_p3_action_pack_result_hash(
        p_owner_user_id, p_pack_id, v_pack.pack_revision, p_attempt_id,
        v_attempt.attempt_number, p_outcome, v_attempt.executor_identity,
        v_result_payload, v_now
    );

    INSERT INTO public.mb13_p3_action_pack_result (
        owner_user_id, pack_id, attempt_id, attempt_number, outcome, executor_identity,
        result_payload, result_hash, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, v_attempt.attempt_number, p_outcome,
        v_attempt.executor_identity, v_result_payload, v_result_hash, v_now
    );

    UPDATE public.mb13_p3_action_pack_attempt
       SET result_payload = v_result_payload,
           result_hash = v_result_hash,
           completed_at = v_now
     WHERE attempt_id = p_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = p_outcome,
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, v_event_kind, v_old_status, p_outcome,
        v_now, jsonb_build_object(
            'attempt_id', p_attempt_id,
            'attempt_number', v_attempt.attempt_number,
            'result_hash', v_result_hash,
            'pack_monitor_revision', v_pack.monitor_revision,
            'pack_policy_hash', v_pack_policy_hash,
            'transition_monitor_revision', v_transition_monitor_revision,
            'transition_policy_hash', v_transition_policy_hash
        ),
        v_transition_monitor_revision, v_transition_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                        p_outcome::TEXT, v_result_hash, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) TO mb13_p3_executor;

-- ----------------------------------------------------------------------------
-- 7. Terminal sync: transition provenance for every closed attempt
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync()
RETURNS TRIGGER AS $$
DECLARE
    v_now TIMESTAMPTZ := clock_timestamp();
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_transition_policy_hash TEXT;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_event_kind TEXT;
    v_old_status TEXT;
BEGIN
    IF NEW.status IN ('completed','partial','failed','cancelled','revoked','expired')
       AND NEW.status IS DISTINCT FROM OLD.status THEN

        SELECT * INTO v_monitor
          FROM public.mb13_p0_monitor_target
         WHERE owner_user_id = NEW.owner_user_id
           AND monitor_id = NEW.monitor_id
         FOR SHARE;
        IF FOUND THEN
            v_transition_policy_hash := public.mb13_p0_hash_jsonb(COALESCE(v_monitor.monitor_policy, '{}'::jsonb));
        ELSE
            v_transition_policy_hash := NEW.monitor_policy_hash;
        END IF;

        IF NEW.status = 'completed' THEN
            v_event_kind := 'attempt_completed';
        ELSIF NEW.status = 'partial' THEN
            v_event_kind := 'attempt_partial';
        ELSIF NEW.status = 'failed' THEN
            v_event_kind := 'attempt_failed';
        ELSIF NEW.status = 'cancelled' THEN
            v_event_kind := 'attempt_cancelled';
        ELSIF NEW.status = 'revoked' THEN
            v_event_kind := 'attempt_revoked';
        ELSE
            v_event_kind := 'attempt_expired';
        END IF;

        FOR v_attempt IN
            SELECT *
              FROM public.mb13_p3_action_pack_attempt
             WHERE pack_id = NEW.pack_id
               AND owner_user_id = NEW.owner_user_id
               AND status IN ('claimed','executing')
               FOR UPDATE
        LOOP
            v_old_status := v_attempt.status;
            UPDATE public.mb13_p3_action_pack_attempt
               SET status = NEW.status,
                   completed_at = COALESCE(completed_at, v_now)
             WHERE attempt_id = v_attempt.attempt_id
               AND owner_user_id = NEW.owner_user_id;

            INSERT INTO public.mb13_p3_action_pack_timeline (
                owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
                event_time, event_payload, monitor_revision, policy_hash
            ) VALUES (
                NEW.owner_user_id, NEW.pack_id, NEW.monitor_id, v_event_kind, v_old_status, NEW.status,
                v_now, jsonb_build_object(
                    'attempt_id', v_attempt.attempt_id,
                    'attempt_number', v_attempt.attempt_number,
                    'executor_identity', v_attempt.executor_identity,
                    'pack_revision', NEW.pack_revision,
                    'pack_monitor_revision', NEW.monitor_revision,
                    'pack_policy_hash', NEW.monitor_policy_hash,
                    'transition_monitor_revision', v_monitor.current_revision,
                    'transition_policy_hash', v_transition_policy_hash
                ),
                v_monitor.current_revision, v_transition_policy_hash
            );
        END LOOP;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync() OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync() TO mb13_p3_writer;

-- ----------------------------------------------------------------------------
-- 8. Cancel/revoke/expire with terminal provenance and expiry checks
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_cancel_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID
) RETURNS TABLE(pack_id UUID, status TEXT) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_transition_policy_hash TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status IN ('completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_already_terminal';
    END IF;

    v_transition_policy_hash := public.mb13_p0_hash_jsonb(COALESCE(v_monitor.monitor_policy, '{}'::jsonb));

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_pack.status, 'cancelled',
            v_now, jsonb_build_object(
                'pack_revision', v_pack.pack_revision,
                'pack_monitor_revision', v_pack.monitor_revision,
                'pack_policy_hash', v_pack.monitor_policy_hash,
                'transition_monitor_revision', v_monitor.current_revision,
                'transition_policy_hash', v_transition_policy_hash,
                'reason', 'cancel'
            ),
            v_monitor.current_revision, v_transition_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    UPDATE public.mb13_p3_action_pack
       SET status = 'cancelled',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'cancelled', v_pack.status, 'cancelled',
        v_now, jsonb_build_object(
            'pack_monitor_revision', v_pack.monitor_revision,
            'pack_policy_hash', v_pack.monitor_policy_hash,
            'transition_monitor_revision', v_monitor.current_revision,
            'transition_policy_hash', v_transition_policy_hash
        ),
        v_monitor.current_revision, v_transition_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.status FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_cancel_action_pack(UUID, UUID) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_cancel_action_pack(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_cancel_action_pack(UUID, UUID) TO mb13_p3_api;

CREATE OR REPLACE FUNCTION public.mb13_p3_revoke_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID
) RETURNS TABLE(pack_id UUID, status TEXT) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_transition_policy_hash TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status IN ('completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_already_terminal';
    END IF;

    v_transition_policy_hash := public.mb13_p0_hash_jsonb(COALESCE(v_monitor.monitor_policy, '{}'::jsonb));

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_pack.status, 'revoked',
            v_now, jsonb_build_object(
                'pack_revision', v_pack.pack_revision,
                'pack_monitor_revision', v_pack.monitor_revision,
                'pack_policy_hash', v_pack.monitor_policy_hash,
                'transition_monitor_revision', v_monitor.current_revision,
                'transition_policy_hash', v_transition_policy_hash,
                'reason', 'revoke'
            ),
            v_monitor.current_revision, v_transition_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    UPDATE public.mb13_p3_action_pack
       SET status = 'revoked',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    RETURN QUERY SELECT ap.pack_id, ap.status FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_revoke_action_pack(UUID, UUID) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_revoke_action_pack(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_revoke_action_pack(UUID, UUID) TO mb13_p3_api;

CREATE OR REPLACE FUNCTION public.mb13_p3_expire_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID
) RETURNS TABLE(pack_id UUID, status TEXT) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_transition_policy_hash TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status IN ('completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_already_terminal';
    END IF;

    IF v_pack.expires_at IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_no_expiry';
    END IF;
    IF v_pack.expires_at > v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_yet_expired';
    END IF;

    v_transition_policy_hash := public.mb13_p0_hash_jsonb(COALESCE(v_monitor.monitor_policy, '{}'::jsonb));

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_pack.status, 'expired',
            v_now, jsonb_build_object(
                'pack_revision', v_pack.pack_revision,
                'pack_monitor_revision', v_pack.monitor_revision,
                'pack_policy_hash', v_pack.monitor_policy_hash,
                'transition_monitor_revision', v_monitor.current_revision,
                'transition_policy_hash', v_transition_policy_hash,
                'reason', 'expire'
            ),
            v_monitor.current_revision, v_transition_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    UPDATE public.mb13_p3_action_pack
       SET status = 'expired',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'expired', v_pack.status, 'expired',
        v_now, jsonb_build_object(
            'pack_monitor_revision', v_pack.monitor_revision,
            'pack_policy_hash', v_pack.monitor_policy_hash,
            'transition_monitor_revision', v_monitor.current_revision,
            'transition_policy_hash', v_transition_policy_hash
        ),
        v_monitor.current_revision, v_transition_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.status FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_expire_action_pack(UUID, UUID) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_expire_action_pack(UUID, UUID) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p3_expire_action_pack(UUID, UUID) FROM mb13_p3_api;
-- Expiry is reserved for executor/housekeeping, not the API role.
GRANT EXECUTE ON FUNCTION public.mb13_p3_expire_action_pack(UUID, UUID) TO mb13_p3_executor, mb13_p3_writer;

-- ----------------------------------------------------------------------------
-- 12. Refresh pack accessors for the new monitor_policy_hash column
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) CASCADE;
DROP FUNCTION IF EXISTS public.mb13_p3_get_action_pack(UUID, UUID) CASCADE;
DROP FUNCTION IF EXISTS public.mb13_p3_list_action_packs(UUID, TEXT, INTEGER, INTEGER) CASCADE;
DROP FUNCTION IF EXISTS public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ) CASCADE;

CREATE OR REPLACE FUNCTION public.mb13_p3_create_action_pack(p_owner_user_id uuid, p_monitor_id uuid, p_trigger_event_id uuid, p_diff_result_id uuid, p_action_type text, p_target_ref jsonb, p_consent_refs jsonb, p_provenance_refs jsonb, p_steps jsonb, p_expires_at timestamp with time zone, p_idempotency_key text, p_initial_status text DEFAULT 'proposed'::text)
 RETURNS TABLE(pack_id uuid, owner_user_id uuid, monitor_id uuid, monitor_revision integer, trigger_event_id uuid, diff_result_id uuid, pack_revision integer, payload_hash text, action_type text, target_ref jsonb, consent_refs jsonb, provenance_refs jsonb, steps jsonb, expires_at timestamp with time zone, idempotency_key text, status text, claimed_attempt_id uuid, created_at timestamp with time zone, updated_at timestamp with time zone, monitor_policy_hash text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO pg_catalog, public
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_existing public.mb13_p3_action_pack%ROWTYPE;
    v_pack_id UUID;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
    v_payload_hash TEXT;
    v_status TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);
    v_status := COALESCE(p_initial_status, 'proposed');

    IF v_status NOT IN ('draft','proposed','awaiting_confirmation') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_invalid_initial_status';
    END IF;

    IF p_action_type NOT IN ('simulate','internal') THEN
        RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
    END IF;

    PERFORM public.mb13_p3_validate_steps(p_owner_user_id, COALESCE(p_steps, '[]'::jsonb));

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, p_monitor_id, v_monitor_revision,
        p_trigger_event_id, p_diff_result_id
    );

    IF p_expires_at IS NOT NULL AND p_expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF p_idempotency_key IS NOT NULL THEN
        SELECT * INTO v_existing
          FROM public.mb13_p3_action_pack
         WHERE owner_user_id = p_owner_user_id
           AND idempotency_key = p_idempotency_key;
        IF FOUND THEN
            v_payload_hash := public.mb13_p3_action_pack_payload_hash(
                p_owner_user_id, p_monitor_id, v_monitor_revision,
                p_trigger_event_id, p_diff_result_id, p_action_type,
                p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
                p_expires_at, p_idempotency_key, v_status
            );
            IF v_existing.payload_hash IS DISTINCT FROM v_payload_hash THEN
                RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
            END IF;
            RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = v_existing.pack_id AND ap.owner_user_id = p_owner_user_id;
            RETURN;
        END IF;
    END IF;

    v_payload_hash := public.mb13_p3_action_pack_payload_hash(
        p_owner_user_id, p_monitor_id, v_monitor_revision,
        p_trigger_event_id, p_diff_result_id, p_action_type,
        p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
        p_expires_at, p_idempotency_key, v_status
    );

    INSERT INTO public.mb13_p3_action_pack (
        owner_user_id, monitor_id, monitor_revision, trigger_event_id, diff_result_id,
        pack_revision, payload_hash, action_type, target_ref, consent_refs, provenance_refs,
        steps, expires_at, idempotency_key, status, created_at, updated_at
    ) VALUES (
        p_owner_user_id, p_monitor_id, v_monitor_revision, p_trigger_event_id, p_diff_result_id,
        1, v_payload_hash, p_action_type, COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, p_idempotency_key, v_status, v_now, v_now
    ) RETURNING public.mb13_p3_action_pack.pack_id INTO v_pack_id;

    INSERT INTO public.mb13_p3_action_pack_revision (
        owner_user_id, pack_id, revision, monitor_revision, trigger_event_id, diff_result_id,
        payload_hash, action_type, target_ref, consent_refs, provenance_refs, steps,
        expires_at, idempotency_key, status, created_at
    ) VALUES (
        p_owner_user_id, v_pack_id, 1, v_monitor_revision, p_trigger_event_id, p_diff_result_id,
        v_payload_hash, p_action_type, COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, p_idempotency_key, v_status, v_now
    );

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_pack_id, p_monitor_id, 'pack_created', NULL, v_status,
        v_now, jsonb_build_object('pack_revision', 1),
        v_monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = v_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;

ALTER FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) TO mb13_p3_api;

CREATE OR REPLACE FUNCTION public.mb13_p3_get_action_pack(p_owner_user_id uuid, p_pack_id uuid)
 RETURNS TABLE(pack_id uuid, owner_user_id uuid, monitor_id uuid, monitor_revision integer, trigger_event_id uuid, diff_result_id uuid, pack_revision integer, payload_hash text, action_type text, target_ref jsonb, consent_refs jsonb, provenance_refs jsonb, steps jsonb, expires_at timestamp with time zone, idempotency_key text, status text, claimed_attempt_id uuid, created_at timestamp with time zone, updated_at timestamp with time zone, monitor_policy_hash text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO pg_catalog, public
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;

ALTER FUNCTION public.mb13_p3_get_action_pack(UUID, UUID) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_get_action_pack(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_action_pack(UUID, UUID) TO mb13_p3_api;

CREATE OR REPLACE FUNCTION public.mb13_p3_list_action_packs(p_owner_user_id uuid, p_status text DEFAULT NULL::text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0)
 RETURNS TABLE(pack_id uuid, owner_user_id uuid, monitor_id uuid, monitor_revision integer, trigger_event_id uuid, diff_result_id uuid, pack_revision integer, payload_hash text, action_type text, target_ref jsonb, consent_refs jsonb, provenance_refs jsonb, steps jsonb, expires_at timestamp with time zone, idempotency_key text, status text, claimed_attempt_id uuid, created_at timestamp with time zone, updated_at timestamp with time zone, monitor_policy_hash text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO pg_catalog, public
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    RETURN QUERY
        SELECT * FROM public.mb13_p3_action_pack ap
        WHERE ap.owner_user_id = p_owner_user_id
          AND (p_status IS NULL OR ap.status = p_status)
        ORDER BY ap.created_at DESC
        LIMIT p_limit OFFSET p_offset;
END;
$function$;

ALTER FUNCTION public.mb13_p3_list_action_packs(UUID, TEXT, INTEGER, INTEGER) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_list_action_packs(UUID, TEXT, INTEGER, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_list_action_packs(UUID, TEXT, INTEGER, INTEGER) TO mb13_p3_api;

CREATE OR REPLACE FUNCTION public.mb13_p3_revise_action_pack(p_owner_user_id uuid, p_pack_id uuid, p_action_type text, p_target_ref jsonb, p_consent_refs jsonb, p_provenance_refs jsonb, p_steps jsonb, p_expires_at timestamp with time zone)
 RETURNS TABLE(pack_id uuid, owner_user_id uuid, monitor_id uuid, monitor_revision integer, monitor_policy_hash text, pack_revision integer, payload_hash text, action_type text, status text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO pg_catalog, public
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_new_revision INTEGER;
    v_payload_hash TEXT;
    v_policy_hash TEXT;
    v_old_status TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status IN ('claimed','executing','completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_cannot_revise';
    END IF;

    IF p_expires_at IS NOT NULL AND p_expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF p_action_type NOT IN ('simulate','internal') THEN
        RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
    END IF;

    PERFORM public.mb13_p3_validate_steps(p_owner_user_id, COALESCE(p_steps, '[]'::jsonb));

    v_old_status := v_pack.status;
    v_new_revision := v_pack.pack_revision + 1;
    v_payload_hash := public.mb13_p3_action_pack_payload_hash(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id, p_action_type,
        p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
        p_expires_at, v_pack.idempotency_key, 'proposed'
    );
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    UPDATE public.mb13_p3_action_pack
       SET pack_revision = v_new_revision,
           payload_hash = v_payload_hash,
           action_type = p_action_type,
           target_ref = COALESCE(p_target_ref, '{}'::jsonb),
           consent_refs = COALESCE(p_consent_refs, '[]'::jsonb),
           provenance_refs = COALESCE(p_provenance_refs, '[]'::jsonb),
           steps = COALESCE(p_steps, '[]'::jsonb),
           expires_at = p_expires_at,
           status = 'proposed',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_old_status, 'proposed',
            v_now, jsonb_build_object('pack_revision', v_new_revision, 'reason', 'revise'),
            v_pack.monitor_revision, v_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    INSERT INTO public.mb13_p3_action_pack_revision (
        owner_user_id, pack_id, revision, monitor_revision, trigger_event_id, diff_result_id,
        payload_hash, action_type, target_ref, consent_refs, provenance_refs, steps,
        expires_at, idempotency_key, status, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, v_new_revision, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id, v_payload_hash, p_action_type,
        COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, v_pack.idempotency_key, 'proposed', v_now
    );

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'pack_revised', v_old_status, 'proposed',
        v_now, jsonb_build_object('pack_revision', v_new_revision),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.owner_user_id, ap.monitor_id, ap.monitor_revision, ap.monitor_policy_hash,
                        ap.pack_revision, ap.payload_hash, ap.action_type, ap.status
                   FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;

ALTER FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ) TO mb13_p3_api;

-- ----------------------------------------------------------------------------
-- 13. Terminal transition provenance: allow monitor advancement and bind row to current state
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_transition_guard()
RETURNS TRIGGER AS $$
DECLARE
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_step_consents JSONB;
BEGIN
    IF TG_OP = 'UPDATE' THEN
        IF NEW.consent_refs IS NOT DISTINCT FROM OLD.consent_refs
           AND NEW.provenance_refs IS NOT DISTINCT FROM OLD.provenance_refs
           AND NEW.steps IS NOT DISTINCT FROM OLD.steps
           AND NEW.monitor_id IS NOT DISTINCT FROM OLD.monitor_id
           AND NEW.monitor_revision IS NOT DISTINCT FROM OLD.monitor_revision
           AND NEW.trigger_event_id IS NOT DISTINCT FROM OLD.trigger_event_id
           AND NEW.diff_result_id IS NOT DISTINCT FROM OLD.diff_result_id
           AND NEW.action_type IS NOT DISTINCT FROM OLD.action_type
           AND NEW.target_ref IS NOT DISTINCT FROM OLD.target_ref
           AND NEW.status IS NOT DISTINCT FROM OLD.status THEN
            RETURN NEW;
        END IF;
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = NEW.owner_user_id
       AND monitor_id = NEW.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF NEW.status IN ('proposed','authorized','claimed','executing') THEN
        IF NEW.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
            RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
        END IF;
    END IF;

    -- Terminal transitions may follow a monitor advancement; the pack keeps its
    -- origin revision while the terminal event separately records the transition.
    PERFORM public.mb13_p3_validate_trigger_diff(
        NEW.owner_user_id, NEW.monitor_id, NEW.monitor_revision,
        NEW.trigger_event_id, NEW.diff_result_id
    );

    IF NEW.action_type NOT IN ('simulate','internal') THEN
        RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
    END IF;

    PERFORM public.mb13_p3_validate_steps(NEW.owner_user_id, COALESCE(NEW.steps, '[]'::jsonb));

    SELECT COALESCE(jsonb_agg(elem), '[]'::jsonb) INTO v_step_consents
    FROM (
        SELECT jsonb_array_elements(s->'consent_refs') AS elem
        FROM jsonb_array_elements(COALESCE(NEW.steps, '[]'::jsonb)) AS s
    ) sub;

    PERFORM public.mb13_p3_validate_source_grant_chain(
        NEW.owner_user_id, v_monitor, NEW.consent_refs, NEW.provenance_refs, v_step_consents
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

-- The trigger definition already exists; the function replacement is enough.

COMMIT;
