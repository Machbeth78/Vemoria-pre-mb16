-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V52 — ECO Premium Runtime/Dialog/Policy

CREATE TABLE IF NOT EXISTS eco_dialog_turns (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id              UUID NOT NULL REFERENCES eco_sessions(id) ON DELETE CASCADE,
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    turn_index              INTEGER NOT NULL,
    turn_type               TEXT NOT NULL,
    dialog_phase            TEXT NOT NULL DEFAULT 'active',
    repair_mode             TEXT NOT NULL DEFAULT 'none',
    interruption_detected   BOOLEAN NOT NULL DEFAULT FALSE,
    active_focus_json       JSONB NOT NULL DEFAULT '[]'::jsonb,
    grounding_json          JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_dialog_session ON eco_dialog_turns(session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_dialog_utterance ON eco_dialog_turns(utterance_id);

CREATE TABLE IF NOT EXISTS eco_policy_events (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    policy_action           TEXT NOT NULL,
    confirmation_mode       TEXT NOT NULL DEFAULT 'none',
    silence_mode            TEXT NOT NULL DEFAULT 'none',
    reason_codes            JSONB NOT NULL DEFAULT '[]'::jsonb,
    grounding_strength      REAL NOT NULL DEFAULT 0.0,
    policy_summary          TEXT,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_policy_utterance ON eco_policy_events(utterance_id);
CREATE INDEX IF NOT EXISTS idx_eco_policy_action ON eco_policy_events(policy_action, created_at DESC);
