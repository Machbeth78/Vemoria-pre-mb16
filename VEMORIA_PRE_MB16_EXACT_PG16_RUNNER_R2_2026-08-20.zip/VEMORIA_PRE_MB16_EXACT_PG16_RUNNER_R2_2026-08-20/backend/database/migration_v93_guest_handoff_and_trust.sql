-- VEMORA — Migration V93: Handoff guest + trust contatti + invite-to-thread
-- Creatore e proprietario: Devoti Massimo
--
-- Tre estensioni:
--   1. Pending thread — thread aperto con destinatario via email (non ancora su Vemora)
--   2. Contact trust level — per evitare thread aperti da sconosciuti in personal
--   3. Funnel tracking — sapere quale public_token ha generato quale utente registrato

-- ── 1. Thread con destinatario pending (non ancora utente Vemora) ────────────

ALTER TABLE chat_thread
    ADD COLUMN IF NOT EXISTS pending_recipient_email TEXT;

ALTER TABLE chat_thread
    ADD COLUMN IF NOT EXISTS pending_recipient_name TEXT;

ALTER TABLE chat_thread
    ADD COLUMN IF NOT EXISTS pending_recipient_resolved_user_id UUID
        REFERENCES utenti(id) ON DELETE SET NULL;

ALTER TABLE chat_thread
    ADD COLUMN IF NOT EXISTS pending_invite_token TEXT;

CREATE INDEX IF NOT EXISTS idx_chat_thread_pending_email
    ON chat_thread(LOWER(pending_recipient_email))
    WHERE pending_recipient_email IS NOT NULL
      AND pending_recipient_resolved_user_id IS NULL;

COMMENT ON COLUMN chat_thread.pending_recipient_email IS
    'Se il destinatario non è (ancora) utente Vemora, il thread rimane in stato pending con questa email. Alla registrazione con quella email il thread si collega automaticamente.';

-- ── 2. Contact trust su contatti_rubrica ─────────────────────────────────────
-- Permette di distinguere: contatti trusted (rubrica confermata), invite_sent,
-- incoming_unconfirmed (hanno aperto un thread verso di me ma non sono in rubrica).

ALTER TABLE contatti_rubrica
    ADD COLUMN IF NOT EXISTS trust_level TEXT NOT NULL DEFAULT 'unknown';

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'chk_contatti_rubrica_trust_level'
    ) THEN
        ALTER TABLE contatti_rubrica
            ADD CONSTRAINT chk_contatti_rubrica_trust_level
            CHECK (trust_level IN ('unknown', 'invited', 'incoming_unconfirmed', 'confirmed', 'blocked'));
    END IF;
END $$;

ALTER TABLE contatti_rubrica
    ADD COLUMN IF NOT EXISTS last_interaction_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_contatti_rubrica_trust
    ON contatti_rubrica(utente_id, trust_level)
    WHERE trust_level <> 'blocked';

COMMENT ON COLUMN contatti_rubrica.trust_level IS
    'unknown=default, invited=ho mandato invito, incoming_unconfirmed=mi ha scritto ma non in rubrica, confirmed=accettato/accettato da me, blocked.';

-- ── 3. Funnel tracking guest -> registered ───────────────────────────────────
-- Link tra utente registrato e il public_token (firma o invito) tramite cui è entrato.

CREATE TABLE IF NOT EXISTS public_funnel_conversions (
    id                      UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    public_token            TEXT        NOT NULL,
    token_kind              TEXT        NOT NULL
                                        CHECK (token_kind IN ('firma', 'invito')),
    resolved_user_id        UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    resolved_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    source_session_id       UUID,                   -- firma_sessioni.id se token_kind='firma'
    source_invite_id        UUID,                   -- inviti_pendenti.id se token_kind='invito'
    handoff_thread_ids      UUID[],                 -- thread creati/migrati nel processo
    migrated_messages_count INTEGER     NOT NULL DEFAULT 0,
    metadata_json           JSONB       NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_public_funnel_conversions_user
    ON public_funnel_conversions(resolved_user_id, resolved_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS ux_public_funnel_conversions_token_user
    ON public_funnel_conversions(public_token, resolved_user_id);

COMMENT ON TABLE public_funnel_conversions IS
    'Tracciamento conversione guest -> utente Vemora registrato: quale token pubblico, quanti messaggi migrati, quali thread.';
