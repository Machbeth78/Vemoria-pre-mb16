-- VEMORA — Migration V81: Nucleo Read Path Observability
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo — Tutti i diritti riservati.
--
-- Obiettivo:
--   Rende misurabile e verificabile il read path del Nucleo Memoria.
--   Registra per ogni turno LUISS:
--     - quali sorgenti erano disponibili
--     - quali sono state selezionate
--     - se il contesto è stato iniettato nella risposta
--     - se il layer semantic (LLM) è stato attivato
--
-- NON è un log storico di tutte le conversazioni.
-- È un campione osservabile per debug e miglioramento del read path.
-- TTL: 30 giorni (pulito da automation/cleanup esistente).
--
-- Separazione intenzionale:
--   nm_read_path_log  → questo file (read path observability)
--   diagnostic_events → Radar (trace/eventi diagnostici globali)
--   luiss_decisions   → decisioni LUISS storiche
--
-- Idempotente: IF NOT EXISTS su tutto.

CREATE TABLE IF NOT EXISTS nm_read_path_log (
    id                  UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    utente_id           UUID        REFERENCES utenti(id) ON DELETE CASCADE,
    trace_id            TEXT,
    intent              TEXT,                          -- intent del turno
    recorded_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    -- ── Contesto disponibile ──────────────────────────────────────────────
    -- Sorgenti disponibili prima della selezione
    sources_available   TEXT[]      NOT NULL DEFAULT '{}',

    -- ── Contesto selezionato ──────────────────────────────────────────────
    -- Sorgenti effettivamente scelte per questo turno
    sources_selected    TEXT[]      NOT NULL DEFAULT '{}',

    -- ── Contesto iniettato ────────────────────────────────────────────────
    injected            BOOLEAN     NOT NULL DEFAULT FALSE,
    context_keys        TEXT[]      NOT NULL DEFAULT '{}',  -- chiavi payload usate

    -- ── Semantic Understanding ────────────────────────────────────────────
    semantic_activated  BOOLEAN     NOT NULL DEFAULT FALSE,  -- LLM attivato
    semantic_pattern    TEXT,                                -- pattern che ha attivato
    semantic_llm_used   BOOLEAN     NOT NULL DEFAULT FALSE,  -- LLM ha risposto
    semantic_tokens     INTEGER,                             -- token usati
    semantic_fallback   TEXT                                 -- motivo fallback se LLM non usato
);

CREATE INDEX IF NOT EXISTS idx_nm_read_path_utente_at
    ON nm_read_path_log(utente_id, recorded_at DESC);

CREATE INDEX IF NOT EXISTS idx_nm_read_path_intent
    ON nm_read_path_log(intent);

CREATE INDEX IF NOT EXISTS idx_nm_read_path_semantic
    ON nm_read_path_log(semantic_activated) WHERE semantic_activated = TRUE;

COMMENT ON TABLE nm_read_path_log IS
    'Log osservabile del read path del Nucleo Memoria per ogni turno LUISS. TTL 30 giorni.';

COMMENT ON COLUMN nm_read_path_log.sources_available IS
    'Sorgenti disponibili prima della selezione: conversation_state, personal_memory, ecc.';

COMMENT ON COLUMN nm_read_path_log.sources_selected IS
    'Sorgenti effettivamente selezionate per questo turno (non tutto ciò che era disponibile).';

COMMENT ON COLUMN nm_read_path_log.injected IS
    'TRUE se il contesto assembato è stato effettivamente iniettato nella risposta.';

COMMENT ON COLUMN nm_read_path_log.semantic_activated IS
    'TRUE se il layer semantic understanding è stato considerato per questo turno.';

COMMENT ON COLUMN nm_read_path_log.semantic_llm_used IS
    'TRUE se LLM è stato effettivamente chiamato e ha risposto.';

-- Pulizia automatica (30 giorni)
-- Compatibile con il cleanup job automation esistente.
-- Nota: il cleanup job deve includere nm_read_path_log nella lista tabelle.

-- Registra migrazione
-- Nota: registrazione migration demandata al migration runner/registry service.
-- Se la migration viene applicata manualmente via SQL puro, usare poi adopt-existing o status nel runner.
