-- Gate08E — Language / Lexicon / Translation contracts
-- Runtime deferred. Adds owner-scoped contract tables only.

CREATE TABLE IF NOT EXISTS gate08e_language_pack_contracts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NULL,
    language_code TEXT NOT NULL,
    operational_country TEXT NULL,
    pack_components JSONB NOT NULL DEFAULT '{}'::jsonb,
    source_chain JSONB NOT NULL DEFAULT '[]'::jsonb,
    status TEXT NOT NULL DEFAULT 'CONTRACT_ONLY_RUNTIME_DEFERRED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (status IN ('CONTRACT_ONLY_RUNTIME_DEFERRED','READY_FOR_RUNTIME_PROBE','REVOKED'))
);

CREATE TABLE IF NOT EXISTS gate08e_translation_trace_contracts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NULL,
    workfile_id UUID NULL,
    source_language TEXT NULL,
    target_language TEXT NULL,
    operational_country TEXT NULL,
    original_reference_hash TEXT NOT NULL,
    translation_confidence NUMERIC(5,4) NULL,
    source_chain JSONB NOT NULL DEFAULT '[]'::jsonb,
    sensitive_domain TEXT NULL,
    is_authoritative BOOLEAN NOT NULL DEFAULT FALSE,
    runtime_translation_executed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (is_authoritative = FALSE),
    CHECK (runtime_translation_executed = FALSE)
);

CREATE INDEX IF NOT EXISTS idx_gate08e_language_pack_owner_language
    ON gate08e_language_pack_contracts(owner_id, language_code, operational_country);

CREATE INDEX IF NOT EXISTS idx_gate08e_translation_trace_owner_workfile
    ON gate08e_translation_trace_contracts(owner_id, workfile_id);
