-- =============================================================================
-- VEMORA V236 — P0/P1 Cross-Cutting Security Closure: owner isolation RLS
-- =============================================================================
-- Targets: search_index, documenti, memorie, relazioni_documenti
-- Scope:
--   1. Add deterministic owner columns where missing.
--   2. Backfill existing rows from canonical owner paths.
--   3. Enable RLS + FORCE RLS + owner policies for live owner-scoped tables.
--   4. No broad grants; no ALTER DEFAULT PRIVILEGES.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. search_index owner_user_id
-- ---------------------------------------------------------------------------
ALTER TABLE search_index
    ADD COLUMN IF NOT EXISTS owner_user_id UUID;

-- Backfill documento rows: search_index.target_id -> documenti.id -> documenti.proprietario_id
UPDATE search_index si
SET owner_user_id = d.proprietario_id
FROM documenti d
WHERE si.target_tipo = 'documento'
  AND si.target_id = d.id
  AND si.owner_user_id IS NULL;

-- Backfill entity rows: deterministic first linked document owner.
-- min(uuid) is not a built-in aggregate; cast to text and back.
UPDATE search_index si
SET owner_user_id = sub.owner_id
FROM (
    SELECT si2.id, (
        SELECT MIN(d.proprietario_id::text)::uuid
        FROM entity_link el
        JOIN documenti d ON d.id = el.target_id
        WHERE el.entity_id = si2.target_id
    ) AS owner_id
    FROM search_index si2
    WHERE si2.target_tipo = 'entity'
      AND si2.owner_user_id IS NULL
) sub
WHERE si.id = sub.id
  AND si.owner_user_id IS NULL;

-- Backfill evento rows: search_index.target_id -> eventi_documento.id -> eventi_documento.utente_id
UPDATE search_index si
SET owner_user_id = ed.utente_id
FROM eventi_documento ed
WHERE si.target_tipo = 'evento'
  AND si.target_id = ed.id
  AND si.owner_user_id IS NULL;

-- ---------------------------------------------------------------------------
-- 2. relazioni_documenti owner_user_id
-- ---------------------------------------------------------------------------
ALTER TABLE relazioni_documenti
    ADD COLUMN IF NOT EXISTS owner_user_id UUID;

-- Owner = proprietario del documento origine (canonical source of the relation)
UPDATE relazioni_documenti rd
SET owner_user_id = d.proprietario_id
FROM documenti d
WHERE rd.documento_origine = d.id
  AND rd.owner_user_id IS NULL;

-- ---------------------------------------------------------------------------
-- 3. RLS + FORCE RLS + owner policies
-- ---------------------------------------------------------------------------

-- search_index
ALTER TABLE search_index ENABLE ROW LEVEL SECURITY;
ALTER TABLE search_index FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS search_index_owner_isolation ON search_index;
CREATE POLICY search_index_owner_isolation ON search_index
    FOR ALL
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

-- documenti
ALTER TABLE documenti ENABLE ROW LEVEL SECURITY;
ALTER TABLE documenti FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS documenti_owner_isolation ON documenti;
CREATE POLICY documenti_owner_isolation ON documenti
    FOR ALL
    USING (proprietario_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (proprietario_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

-- memorie
ALTER TABLE memorie ENABLE ROW LEVEL SECURITY;
ALTER TABLE memorie FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS memorie_owner_isolation ON memorie;
CREATE POLICY memorie_owner_isolation ON memorie
    FOR ALL
    USING (proprietario_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (proprietario_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

-- relazioni_documenti
ALTER TABLE relazioni_documenti ENABLE ROW LEVEL SECURITY;
ALTER TABLE relazioni_documenti FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS relazioni_documenti_owner_isolation ON relazioni_documenti;
CREATE POLICY relazioni_documenti_owner_isolation ON relazioni_documenti
    FOR ALL
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);
