-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB7→MB8 R3 — Minimal per-table privileges for the canonical non-superuser
-- application role (test_app) on MB11/MB12 owner-scoped tables needed by the
-- RLS regression tests.  This migration does NOT grant broad schema privileges and
-- does NOT use ALTER DEFAULT PRIVILEGES.  Grants are issued only to test_app
-- and, where a product role already exists, to mb12_p0_app for the single
-- table that lacked it.  All grants are conditional on the role existing so
-- the migration applies cleanly before the test fixture creates test_app.

BEGIN;

DO $$
DECLARE
    v_role text;
    v_table text;
    v_privs text;
BEGIN
    -- Canonical test app role: minimal SELECT (and INSERT where the RLS test
    -- needs to verify WITH CHECK enforcement) on the tables exercised by MB11/MB12
    -- RLS tests.  The role may be created later by the canonical test fixture;
    -- if it does not exist the grant is skipped and re-applied idempotently.
    v_role := 'test_app';
    IF EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = v_role) THEN
        FOREACH v_table IN ARRAY ARRAY[
            'canonical_identity_projection',
            'canonical_source_card_authority',
            'mb12_p0_foundation_entity',
            'mb12_p0_trusted_data_value',
            'mb12_p0_governed_context'
        ]
        LOOP
            IF EXISTS (
                SELECT 1 FROM pg_class c
                JOIN pg_namespace n ON n.oid = c.relnamespace
                WHERE c.relname = v_table AND n.nspname = 'public' AND c.relkind = 'r'
            ) THEN
                v_privs := 'SELECT';
                IF v_table = 'canonical_identity_projection' THEN
                    v_privs := 'SELECT, INSERT';
                END IF;
                EXECUTE format('GRANT %s ON TABLE public.%I TO %I', v_privs, v_table, v_role);
            END IF;
        END LOOP;
    END IF;

    -- The MB12 product application role also lacked SELECT on the governed
    -- foundation entity table; grant it so runtime RLS checks work for the
    -- real mb12_p0_app role as well.
    v_role := 'mb12_p0_app';
    IF EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = v_role) THEN
        IF EXISTS (
            SELECT 1 FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE c.relname = 'mb12_p0_foundation_entity' AND n.nspname = 'public' AND c.relkind = 'r'
        ) THEN
            EXECUTE format('GRANT SELECT ON TABLE public.%I TO %I', 'mb12_p0_foundation_entity', v_role);
        END IF;
    END IF;
END $$;

COMMIT;
