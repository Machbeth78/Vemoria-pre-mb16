-- ===========================================================================
-- VEMORA V243 — MB14-P0 Relationship Foundation
-- ===========================================================================
-- Scope:
--   1. Owner-scoped relationship, role, contact point and consent tables.
--   2. Organization context via canonical identity projection (entity_type).
--   3. Relationship timeline, document links and action links.
--   4. Row Level Security with FORCE RLS on all relationship tables.
--   5. Search indexes for owner-scoped display label and contact points.
--
-- NON modifica le tabelle frozen MB0→MB13; soltanto tabelle additive.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- 1. relationship
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship (
    relationship_id     UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    canonical_identity_id TEXT,                    -- identificativo identity (owner authority)
    relationship_type   TEXT NOT NULL
        CHECK (relationship_type IN (
            'person','organization','public_body','professional','business','other'
        )),
    display_label       TEXT NOT NULL,
    status              TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active','archived','removed')),
    trust_state         TEXT NOT NULL DEFAULT 'unknown'
        CHECK (trust_state IN (
            'unknown','user_confirmed','identity_verified','official_contact_verified',
            'suspicious','revoked','stale'
        )),
    source              TEXT NOT NULL DEFAULT 'manual'
        CHECK (source IN ('manual','imported_unverified','capture_identity','canonical_identity')),
    metadata            JSONB NOT NULL DEFAULT '{}'::jsonb,
    archived_at         TIMESTAMPTZ,
    removed_at          TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_relationship_owner
    ON relationship(owner_user_id);
CREATE INDEX IF NOT EXISTS idx_relationship_identity
    ON relationship(owner_user_id, canonical_identity_id);
CREATE INDEX IF NOT EXISTS idx_relationship_status
    ON relationship(owner_user_id, status);

-- ---------------------------------------------------------------------------
-- 2. relationship_role
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_role (
    role_id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id     UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id   UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    role_type         TEXT NOT NULL,
    organization_id   TEXT,                    -- canonical identity id of org
    context_id        TEXT,
    valid_from        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    valid_to          TIMESTAMPTZ,
    status            TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active','archived','revoked')),
    source            TEXT NOT NULL DEFAULT 'manual',
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_relationship_role_owner_rel
    ON relationship_role(owner_user_id, relationship_id);

-- ---------------------------------------------------------------------------
-- 3. relationship_contact_point
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_contact_point (
    contact_point_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id    UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id  UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    type             TEXT NOT NULL
        CHECK (type IN ('phone','email','pec','messaging_address','postal_address','official_portal_identity','other')),
    value            TEXT NOT NULL,
    verification_state TEXT NOT NULL DEFAULT 'unverified'
        CHECK (verification_state IN (
            'user_entered','imported','verified','unverified','official','revoked','stale'
        )),
    source           TEXT NOT NULL DEFAULT 'manual',
    owner_visibility TEXT NOT NULL DEFAULT 'private'
        CHECK (owner_visibility IN ('private','shared','archive')),
    valid_from       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    valid_to         TIMESTAMPTZ,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_relationship_contact_owner_rel
    ON relationship_contact_point(owner_user_id, relationship_id);
CREATE INDEX IF NOT EXISTS idx_relationship_contact_value
    ON relationship_contact_point(owner_user_id, type, lower(value));

-- ---------------------------------------------------------------------------
-- 4. relationship_consent_grant
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_consent_grant (
    grant_id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id    UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id  UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    resource_scope   TEXT NOT NULL,
    action_scope     TEXT NOT NULL,
    purpose          TEXT NOT NULL,
    granted_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at       TIMESTAMPTZ,
    revoked_at       TIMESTAMPTZ,
    explicit_ack     BOOLEAN NOT NULL DEFAULT FALSE,
    provenance       JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_relationship_consent_owner_rel
    ON relationship_consent_grant(owner_user_id, relationship_id);

-- ---------------------------------------------------------------------------
-- 5. relationship_timeline_event
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_timeline_event (
    event_id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id   UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    event_type      TEXT NOT NULL
        CHECK (event_type IN (
            'contact_added','role_changed','message_received','document_shared',
            'commitment_created','deadline_created','action_completed','relationship_created',
            'archive','sharing_revoked','consent_changed','import_candidate'
        )),
    event_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    source          TEXT NOT NULL DEFAULT 'manual',
    evidence        JSONB NOT NULL DEFAULT '{}'::jsonb,
    provenance      JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_relationship_timeline_owner_rel
    ON relationship_timeline_event(owner_user_id, relationship_id, event_at DESC);

-- ---------------------------------------------------------------------------
-- 6. relationship_document_link
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_document_link (
    link_id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id   UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    document_id     UUID NOT NULL,
    link_type       TEXT NOT NULL
        CHECK (link_type IN (
            'document_received_from','document_sent_to','document_related_to',
            'document_signed_with','document_requested_from'
        )),
    provenance      JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_relationship_doc_owner_rel
    ON relationship_document_link(owner_user_id, relationship_id);

-- ---------------------------------------------------------------------------
-- 7. relationship_action_link
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_action_link (
    link_id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id   UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    target_id       TEXT NOT NULL,
    target_type     TEXT NOT NULL
        CHECK (target_type IN ('action_pack','reminder','receipt','monitor')),
    link_type       TEXT NOT NULL DEFAULT 'related',
    provenance      JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_relationship_action_owner_rel
    ON relationship_action_link(owner_user_id, relationship_id);

-- ---------------------------------------------------------------------------
-- 8. RLS owner isolation
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    -- relationship
    ALTER TABLE relationship ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_owner_isolation ON relationship;
    CREATE POLICY relationship_owner_isolation ON relationship
        FOR ALL
        USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
        WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

    -- relationship_role
    ALTER TABLE relationship_role ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship_role FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_role_owner_isolation ON relationship_role;
    CREATE POLICY relationship_role_owner_isolation ON relationship_role
        FOR ALL
        USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
        WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

    -- relationship_contact_point
    ALTER TABLE relationship_contact_point ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship_contact_point FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_contact_point_owner_isolation ON relationship_contact_point;
    CREATE POLICY relationship_contact_point_owner_isolation ON relationship_contact_point
        FOR ALL
        USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
        WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

    -- relationship_consent_grant
    ALTER TABLE relationship_consent_grant ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship_consent_grant FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_consent_grant_owner_isolation ON relationship_consent_grant;
    CREATE POLICY relationship_consent_grant_owner_isolation ON relationship_consent_grant
        FOR ALL
        USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
        WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

    -- relationship_timeline_event
    ALTER TABLE relationship_timeline_event ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship_timeline_event FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_timeline_event_owner_isolation ON relationship_timeline_event;
    CREATE POLICY relationship_timeline_event_owner_isolation ON relationship_timeline_event
        FOR ALL
        USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
        WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

    -- relationship_document_link
    ALTER TABLE relationship_document_link ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship_document_link FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_document_link_owner_isolation ON relationship_document_link;
    CREATE POLICY relationship_document_link_owner_isolation ON relationship_document_link
        FOR ALL
        USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
        WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

    -- relationship_action_link
    ALTER TABLE relationship_action_link ENABLE ROW LEVEL SECURITY;
    ALTER TABLE relationship_action_link FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS relationship_action_link_owner_isolation ON relationship_action_link;
    CREATE POLICY relationship_action_link_owner_isolation ON relationship_action_link
        FOR ALL
        USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
        WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);
END $$;

-- ---------------------------------------------------------------------------
-- 9. Least-privilege grants for dedicated API role if present
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p2_api') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship_role TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship_contact_point TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship_consent_grant TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship_timeline_event TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship_document_link TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE relationship_action_link TO mb13_p2_api;
    END IF;
END $$;
