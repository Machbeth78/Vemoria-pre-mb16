-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V55 — ECO Eventi di vita semantici / common ground esteso

ALTER TABLE IF EXISTS eco_common_ground_states
    ADD COLUMN IF NOT EXISTS shared_semantic_period_json JSONB NOT NULL DEFAULT '{}'::jsonb;

CREATE TABLE IF NOT EXISTS eco_life_anchor_events (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    event_identity      TEXT NOT NULL,
    event_label         TEXT NOT NULL,
    anchor_domain       TEXT NOT NULL DEFAULT 'generic',
    event_type          TEXT NOT NULL DEFAULT 'event',
    relationship_scope  TEXT,
    salience_level      TEXT NOT NULL DEFAULT 'media',
    temporal_force      INTEGER NOT NULL DEFAULT 0,
    maturity_level      TEXT NOT NULL DEFAULT 'debole',
    maturity_score      REAL NOT NULL DEFAULT 0.0,
    evidence_count      INTEGER NOT NULL DEFAULT 1,
    recurrence_sessions INTEGER NOT NULL DEFAULT 1,
    last_session_id     UUID REFERENCES eco_sessions(id) ON DELETE SET NULL,
    first_seen_at       TIMESTAMP NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMP NOT NULL DEFAULT NOW(),
    reason_codes        JSONB NOT NULL DEFAULT '[]'::jsonb,
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, event_identity)
);

CREATE INDEX IF NOT EXISTS idx_eco_life_anchor_events_user_score
    ON eco_life_anchor_events(utente_id, maturity_score DESC, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_life_anchor_events_label
    ON eco_life_anchor_events(event_label, updated_at DESC);
