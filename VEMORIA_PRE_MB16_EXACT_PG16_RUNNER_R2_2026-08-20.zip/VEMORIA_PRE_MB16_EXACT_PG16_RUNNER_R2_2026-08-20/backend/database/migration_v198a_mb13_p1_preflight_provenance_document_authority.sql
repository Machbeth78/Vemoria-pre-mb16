-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
--
-- MB13-P1 R2 — v198a Preflight, exact provenance and document authority.
-- Forward-only, idempotent migration. Does not modify v196 or v197.

BEGIN;

-- ----------------------------------------------------------------------------
-- Roles used by the diff API and the internal executor.
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p1_app') THEN
        CREATE ROLE mb13_p1_app LOGIN;
    ELSE
        ALTER ROLE mb13_p1_app LOGIN;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p1_executor') THEN
        CREATE ROLE mb13_p1_executor LOGIN;
    ELSE
        ALTER ROLE mb13_p1_executor LOGIN;
    END IF;
END
$$;

-- ----------------------------------------------------------------------------
-- Preflight state: authoritative authorization before any payload read.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.mb13_p1_preflight_state (
    preflight_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id       UUID NOT NULL,
    monitor_id          UUID NOT NULL,
    observation_ref     JSONB NOT NULL,
    diff_kind           TEXT NOT NULL CHECK (diff_kind IN ('structured','text')),
    baseline_source_refs    JSONB NOT NULL DEFAULT '[]'::jsonb,
    baseline_evidence_refs  JSONB NOT NULL DEFAULT '[]'::jsonb,
    observation_source_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
    observation_evidence_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
    consent_refs        JSONB NOT NULL DEFAULT '[]'::jsonb,
    used                BOOLEAN NOT NULL DEFAULT FALSE,
    expires_at          TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '5 minutes'),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_preflight_monitor FOREIGN KEY (owner_user_id, monitor_id)
        REFERENCES public.mb13_p0_monitor_target(owner_user_id, monitor_id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS ix_mb13_p1_preflight_state_monitor
    ON public.mb13_p1_preflight_state(owner_user_id, monitor_id, used, expires_at);

ALTER TABLE public.mb13_p1_preflight_state OWNER TO mb13_p1_executor;

-- ----------------------------------------------------------------------------
-- Document revision authority: append-only, owner-bound, monotonic.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_append_document_revision(
    p_owner_user_id UUID,
    p_document_id UUID,
    p_revision INTEGER,
    p_state TEXT,
    p_payload_hash TEXT,
    p_dati_strutturati JSONB,
    p_testo_grezzo TEXT,
    p_supersedes_revision INTEGER DEFAULT NULL
) RETURNS UUID AS $$
DECLARE
    v_last_revision INTEGER;
    v_last_hash TEXT;
    v_doc_owner UUID;
    v_revision_id UUID := gen_random_uuid();
BEGIN
    IF p_state NOT IN ('memorizzato','revoked','superseded') THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_state_invalid';
    END IF;

    SELECT proprietario_id INTO v_doc_owner
      FROM public.documenti
     WHERE id = p_document_id
       AND proprietario_id = p_owner_user_id
     FOR SHARE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_document_not_found_or_owner_mismatch';
    END IF;

    IF p_revision < 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_invalid';
    END IF;

    IF p_revision > 1 THEN
        SELECT revision, payload_hash INTO v_last_revision, v_last_hash
          FROM public.mb13_p1_document_revision
         WHERE owner_user_id = p_owner_user_id
           AND document_id = p_document_id
           AND revision < p_revision
         ORDER BY revision DESC
         LIMIT 1;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p1_document_revision_skipped';
        END IF;
        IF p_supersedes_revision IS DISTINCT FROM v_last_revision THEN
            RAISE EXCEPTION 'mb13_p1_document_revision_supersedes_mismatch';
        END IF;
        IF p_state = 'memorizzato' AND v_last_hash IS NULL THEN
            RAISE EXCEPTION 'mb13_p1_document_revision_baseline_hash_missing';
        END IF;
    END IF;

    IF EXISTS (
        SELECT 1 FROM public.mb13_p1_document_revision
         WHERE owner_user_id = p_owner_user_id
           AND document_id = p_document_id
           AND revision = p_revision
    ) THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_already_exists';
    END IF;

    INSERT INTO public.mb13_p1_document_revision (
        owner_user_id, document_id, revision, state, payload_hash,
        dati_strutturati, testo_grezzo, supersedes_revision, created_at
    ) VALUES (
        p_owner_user_id, p_document_id, p_revision, p_state, p_payload_hash,
        p_dati_strutturati, p_testo_grezzo, p_supersedes_revision, NOW()
    )
    RETURNING revision_id INTO v_revision_id;

    RETURN v_revision_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) TO mb13_p1_app;

-- Trigger guard: block direct INSERT/UPDATE/DELETE on document revisions
-- unless the session is running under the executor role (e.g. via the function).
CREATE OR REPLACE FUNCTION public.mb13_p1_document_revision_guard()
RETURNS TRIGGER AS $$
BEGIN
    IF pg_has_role(current_user, 'mb13_p1_executor', 'MEMBER') THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;
    RAISE EXCEPTION 'mb13_p1_document_revision_direct_dml_blocked';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_mb13_p1_document_revision_guard ON public.mb13_p1_document_revision;
CREATE TRIGGER trg_mb13_p1_document_revision_guard
    BEFORE INSERT OR UPDATE OR DELETE ON public.mb13_p1_document_revision
    FOR EACH STATEMENT
    EXECUTE FUNCTION public.mb13_p1_document_revision_guard();

-- ----------------------------------------------------------------------------
-- Exact provenance verifier.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_verify_exact_provenance(
    p_owner UUID,
    p_source_refs JSONB,
    p_evidence_refs JSONB
) RETURNS VOID AS $$
DECLARE
    v_ref JSONB;
    v_source_id UUID;
    v_source_card_id TEXT;
    v_source_revision_id UUID;
    v_evidence_id UUID;
    v_grant_id UUID;
    v_ok BOOLEAN;
BEGIN
    IF jsonb_typeof(COALESCE(p_source_refs, '[]'::jsonb)) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p1_provenance_source_refs_invalid';
    END IF;
    IF jsonb_typeof(COALESCE(p_evidence_refs, '[]'::jsonb)) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p1_provenance_evidence_refs_invalid';
    END IF;

    FOR v_ref IN SELECT jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb))
    LOOP
        v_source_id := NULLIF(v_ref->>'source_id', '')::UUID;
        v_source_card_id := NULLIF(v_ref->>'source_card_id', '');
        v_source_revision_id := NULLIF(v_ref->>'source_revision_id', '')::UUID;
        v_evidence_id := NULLIF(v_ref->>'evidence_id', '')::UUID;
        v_grant_id := NULLIF(v_ref->>'grant_id', '')::UUID;

        IF v_source_id IS NOT NULL THEN
            SELECT TRUE INTO v_ok
              FROM public.authorized_memory_sources
             WHERE id = v_source_id
               AND user_id = p_owner
               AND status = 'active'
               AND revoked_at IS NULL;
            IF NOT FOUND THEN
                RAISE EXCEPTION 'mb13_p1_observation_source_revoked';
            END IF;
        END IF;

        IF v_source_card_id IS NOT NULL THEN
            SELECT TRUE INTO v_ok
              FROM public.mb12_p0_source_card_binding
             WHERE source_card_id = v_source_card_id
               AND owner_user_id = p_owner
               AND status = 'active'
               AND revoked_at IS NULL;
            IF NOT FOUND THEN
                RAISE EXCEPTION 'mb13_p1_observation_source_revoked';
            END IF;
        END IF;

        IF v_source_revision_id IS NOT NULL THEN
            SELECT TRUE INTO v_ok
              FROM public.authorized_memory_inventory_items
             WHERE id = v_source_revision_id
               AND user_id = p_owner
               AND deleted_at IS NULL
               AND identity_state <> 'revoked'
               AND memory_state <> 'revoked';
            IF NOT FOUND THEN
                RAISE EXCEPTION 'mb13_p1_observation_evidence_invalid';
            END IF;
        END IF;

        IF v_evidence_id IS NOT NULL THEN
            SELECT TRUE INTO v_ok
              FROM public.authorized_memory_activity_log
             WHERE id = v_evidence_id
               AND user_id = p_owner;
            IF NOT FOUND THEN
                RAISE EXCEPTION 'mb13_p1_observation_evidence_invalid';
            END IF;
        END IF;

        IF v_grant_id IS NOT NULL THEN
            SELECT TRUE INTO v_ok
              FROM public.authorized_memory_consent_grants
             WHERE id = v_grant_id
               AND user_id = p_owner
               AND status = 'active'
               AND (expires_at IS NULL OR expires_at > NOW())
               AND revoked_at IS NULL;
            IF NOT FOUND THEN
                RAISE EXCEPTION 'mb13_p1_observation_consent_not_covered';
            END IF;
        END IF;
    END LOOP;

    FOR v_ref IN SELECT jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb))
    LOOP
        v_evidence_id := NULLIF(v_ref->>'evidence_id', '')::UUID;
        v_source_id := NULLIF(v_ref->>'source_id', '')::UUID;

        IF v_evidence_id IS NOT NULL THEN
            SELECT TRUE INTO v_ok
              FROM public.authorized_memory_activity_log
             WHERE id = v_evidence_id
               AND user_id = p_owner;
            IF NOT FOUND THEN
                RAISE EXCEPTION 'mb13_p1_observation_evidence_invalid';
            END IF;
        END IF;

        IF v_source_id IS NOT NULL THEN
            SELECT TRUE INTO v_ok
              FROM public.authorized_memory_sources
             WHERE id = v_source_id
               AND user_id = p_owner
               AND status = 'active'
               AND revoked_at IS NULL;
            IF NOT FOUND THEN
                RAISE EXCEPTION 'mb13_p1_observation_source_revoked';
            END IF;
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_verify_exact_provenance(UUID, JSONB, JSONB) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_verify_exact_provenance(UUID, JSONB, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_verify_exact_provenance(UUID, JSONB, JSONB) TO mb13_p1_executor;

-- ----------------------------------------------------------------------------
-- Preflight: authorize before any payload is read.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_preflight(
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT
) RETURNS UUID AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_baseline_source_refs JSONB;
    v_baseline_evidence_refs JSONB;
    v_observation_source_refs JSONB;
    v_observation_evidence_refs JSONB;
    v_baseline_rev INTEGER;
    v_observation_rev INTEGER;
    v_preflight_id UUID := gen_random_uuid();
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'id' IS NULL OR p_observation_ref->>'revision' IS NULL OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
        RAISE EXCEPTION 'mb13_p1_target_owner_mismatch';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;

    -- Serialize all operations on this monitor.
    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_monitor_id::text, 0));

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = v_owner
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_found';
    END IF;
    IF v_current.monitor_state <> 'active' THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;

    -- Resolve baseline and observation; this locks the target rows.
    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, v_current.target_ref);
    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, p_observation_ref);

    -- Same-identity and monotonic compatibility.
    IF (v_current.target_ref->>'id') IS DISTINCT FROM (p_observation_ref->>'id') THEN
        RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
    END IF;

    v_baseline_rev := (v_current.target_ref->>'revision')::INTEGER;
    v_observation_rev := (p_observation_ref->>'revision')::INTEGER;

    IF v_observation_rev < v_baseline_rev THEN
        RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
    END IF;

    IF v_observation_rev = v_baseline_rev THEN
        IF (v_current.target_ref->>'payload_hash') IS DISTINCT FROM (p_observation_ref->>'payload_hash')
           OR (v_current.target_ref->>'state') IS DISTINCT FROM (p_observation_ref->>'state') THEN
            RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
        END IF;
    END IF;

    -- Consents must cover both baseline and observation.
    PERFORM public.mb13_p0_lock_and_verify_consents(
        v_owner, v_current.consent_refs, v_current.target_type, v_current.target_ref,
        p_required => TRUE, p_strict_relation => FALSE
    );
    PERFORM public.mb13_p0_lock_and_verify_consents(
        v_owner, v_current.consent_refs, v_current.target_type, p_observation_ref,
        p_required => TRUE, p_strict_relation => FALSE
    );

    -- Provenance (exact).
    SELECT source_refs, evidence_refs INTO v_baseline_source_refs, v_baseline_evidence_refs
      FROM public.mb13_p0_get_target_provenance(v_owner, v_current.target_type, v_current.target_ref);
    SELECT source_refs, evidence_refs INTO v_observation_source_refs, v_observation_evidence_refs
      FROM public.mb13_p0_get_target_provenance(v_owner, v_current.target_type, p_observation_ref);

    PERFORM public.mb13_p1_verify_exact_provenance(v_owner, v_baseline_source_refs, v_baseline_evidence_refs);
    PERFORM public.mb13_p1_verify_exact_provenance(v_owner, v_observation_source_refs, v_observation_evidence_refs);

    -- Record the authorized preflight state; payload read is still ahead.
    INSERT INTO public.mb13_p1_preflight_state (
        preflight_id, owner_user_id, monitor_id, observation_ref, diff_kind,
        baseline_source_refs, baseline_evidence_refs,
        observation_source_refs, observation_evidence_refs,
        consent_refs
    ) VALUES (
        v_preflight_id, v_owner, p_monitor_id, p_observation_ref, p_diff_kind,
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_source_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_evidence_refs), '[]'::jsonb),
        public.mb13_p0_normalize_jsonb_array(v_current.consent_refs)
    );

    RETURN v_preflight_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) TO mb13_p1_app;

-- ----------------------------------------------------------------------------
-- Authoritative diff writer (private, requires a valid preflight token).
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_write_diff(UUID,JSONB,TEXT,JSONB,INTEGER,INTEGER,TEXT,TEXT,TEXT,TEXT,JSONB,JSONB);
DROP FUNCTION IF EXISTS public.mb13_p1_write_diff(UUID,JSONB,TEXT,JSONB,INTEGER,INTEGER,TEXT,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB,JSONB);

CREATE OR REPLACE FUNCTION public.mb13_p1_write_diff(
    p_preflight_id UUID,
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT,
    p_changes JSONB,
    p_change_count INTEGER,
    p_material_change_count INTEGER,
    p_diff_state TEXT,
    p_summary TEXT,
    p_algorithm_version TEXT,
    p_normalization_version TEXT,
    p_request_payload JSONB,
    p_result_payload JSONB
) RETURNS TABLE(diff_id UUID, revision INTEGER, content_hash TEXT, diff_state TEXT, change_count INTEGER, material_change_count INTEGER, summary TEXT, changes JSONB) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_preflight public.mb13_p1_preflight_state%ROWTYPE;
    v_baseline_source_refs JSONB;
    v_baseline_evidence_refs JSONB;
    v_observation_source_refs JSONB;
    v_observation_evidence_refs JSONB;
    v_effective_source_refs JSONB;
    v_effective_evidence_refs JSONB;
    v_canonical_consent_refs JSONB;
    v_canonical_changes JSONB;
    v_change_count INTEGER;
    v_material_change_count INTEGER;
    v_diff_state TEXT;
    v_summary TEXT;
    v_content_hash TEXT;
    v_existing_diff_id UUID;
    v_existing_revision INTEGER;
    v_diff_id UUID;
    v_revision INTEGER := 1;
    v_event_type TEXT;
    v_event_id UUID;
    v_event_time TIMESTAMPTZ := NOW();
    v_event_payload_hash TEXT;
    v_event_result_payload JSONB;
    v_expected_algorithm TEXT;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_preflight_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_preflight_required';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'id' IS NULL OR p_observation_ref->>'revision' IS NULL OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;

    v_expected_algorithm := CASE p_diff_kind
        WHEN 'structured' THEN 'mb13-p1-r2-structured'
        WHEN 'text' THEN 'mb13-p1-r2-text'
    END;

    IF p_algorithm_version IS NULL OR p_algorithm_version <> v_expected_algorithm THEN
        RAISE EXCEPTION 'mb13_p1_algorithm_version_invalid';
    END IF;
    IF p_normalization_version IS NULL OR p_normalization_version <> 'mb13-p1-r2' THEN
        RAISE EXCEPTION 'mb13_p1_normalization_version_invalid';
    END IF;

    -- Serialize on monitor and consume the preflight token atomically.
    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_monitor_id::text, 0));

    SELECT * INTO v_preflight
      FROM public.mb13_p1_preflight_state
     WHERE preflight_id = p_preflight_id
       AND owner_user_id = v_owner
       AND monitor_id = p_monitor_id
       AND used = FALSE
       AND expires_at > NOW()
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_preflight_invalid_or_expired';
    END IF;

    -- Idempotency: exact same observation + kind on the same monitor revision.
    IF v_preflight.observation_ref IS NOT DISTINCT FROM p_observation_ref
       AND v_preflight.diff_kind IS NOT DISTINCT FROM p_diff_kind THEN
        -- continue; writer will enforce idempotency via content_hash
        NULL;
    ELSE
        RAISE EXCEPTION 'mb13_p1_preflight_mismatch';
    END IF;

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = v_owner
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_found';
    END IF;
    IF v_current.monitor_state <> 'active' THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;

    -- Resolve target again to ensure the rows are still current and locked.
    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, v_current.target_ref);
    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, p_observation_ref);

    -- Mark preflight used so it cannot be replayed.
    UPDATE public.mb13_p1_preflight_state
       SET used = TRUE
     WHERE preflight_id = p_preflight_id;

    v_baseline_source_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.baseline_source_refs);
    v_baseline_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.baseline_evidence_refs);
    v_observation_source_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.observation_source_refs);
    v_observation_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.observation_evidence_refs);
    v_canonical_consent_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.consent_refs);

    v_effective_source_refs := public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs);
    v_effective_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs);

    -- Derive canonical result from the supplied changes.
    v_canonical_changes := public.mb13_p0_normalize_jsonb_array(p_changes);
    v_change_count := jsonb_array_length(v_canonical_changes);

    SELECT COUNT(*) INTO v_material_change_count
      FROM jsonb_array_elements(v_canonical_changes) AS c
     WHERE (c.value->>'materiality') = 'POTENTIALLY_MATERIAL';

    IF v_change_count = 0 THEN
        v_diff_state := 'no_change';
    ELSE
        SELECT CASE WHEN EXISTS (
            SELECT 1 FROM jsonb_array_elements(v_canonical_changes) c
             WHERE (c.value->>'change_type') = 'AMBIGUOUS'
        ) THEN 'ambiguous' ELSE 'computed' END INTO v_diff_state;
    END IF;

    v_summary := CASE WHEN v_change_count = 0
        THEN 'No changes detected'
        ELSE format('Detected %s change(s), %s material', v_change_count, v_material_change_count)
    END;

    IF p_change_count IS DISTINCT FROM v_change_count THEN
        RAISE EXCEPTION 'mb13_p1_change_count_mismatch';
    END IF;
    IF p_material_change_count IS DISTINCT FROM v_material_change_count THEN
        RAISE EXCEPTION 'mb13_p1_material_change_count_mismatch';
    END IF;
    IF p_diff_state IS DISTINCT FROM v_diff_state THEN
        RAISE EXCEPTION 'mb13_p1_diff_state_mismatch';
    END IF;
    IF p_summary IS DISTINCT FROM v_summary THEN
        RAISE EXCEPTION 'mb13_p1_summary_mismatch';
    END IF;

    v_content_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'baseline_ref', v_current.target_ref,
        'observation_ref', p_observation_ref,
        'diff_kind', p_diff_kind,
        'changes', v_canonical_changes,
        'algorithm_version', p_algorithm_version,
        'normalization_version', p_normalization_version,
        'source_refs', v_effective_source_refs,
        'evidence_refs', v_effective_evidence_refs,
        'consent_refs', v_canonical_consent_refs
    ));

    -- Idempotency: same canonical inputs yield the same identity.
    SELECT d.diff_id, d.current_revision
      INTO v_existing_diff_id, v_existing_revision
      FROM public.mb13_p1_universal_diff d
     WHERE d.owner_user_id = v_owner
       AND d.content_hash = v_content_hash
     LIMIT 1;

    IF FOUND THEN
        RETURN QUERY SELECT v_existing_diff_id, v_existing_revision, v_content_hash, v_diff_state, v_change_count, v_material_change_count, v_summary, v_canonical_changes;
        RETURN;
    END IF;

    v_diff_id := gen_random_uuid();

    v_event_result_payload := COALESCE(p_result_payload, '{}'::jsonb) || jsonb_build_object(
        'diff_id', v_diff_id,
        'diff_revision', v_revision,
        'diff_content_hash', v_content_hash,
        'diff_kind', p_diff_kind,
        'diff_state', v_diff_state,
        'change_count', v_change_count,
        'material_change_count', v_material_change_count,
        'no_auto_action', true,
        'no_auto_notification', true,
        'baseline_source_refs', v_baseline_source_refs,
        'baseline_evidence_refs', v_baseline_evidence_refs,
        'observation_source_refs', v_observation_source_refs,
        'observation_evidence_refs', v_observation_evidence_refs,
        'effective_consent_refs', v_canonical_consent_refs
    );

    INSERT INTO public.mb13_p1_universal_diff (
        owner_user_id, diff_id, monitor_id, monitor_revision, baseline_ref, observation_ref,
        diff_kind, diff_state, summary, change_count, material_change_count, changes,
        source_refs, evidence_refs, consent_refs, algorithm_version, normalization_version,
        payload_hash, content_hash, current_revision, request_payload, result_payload
    ) VALUES (
        v_owner, v_diff_id, p_monitor_id, v_current.current_revision, v_current.target_ref, p_observation_ref,
        p_diff_kind, v_diff_state, v_summary, v_change_count, v_material_change_count, v_canonical_changes,
        v_effective_source_refs, v_effective_evidence_refs, v_canonical_consent_refs,
        p_algorithm_version, p_normalization_version,
        v_content_hash, v_content_hash, v_revision, COALESCE(p_request_payload, '{}'::jsonb), v_event_result_payload
    );

    INSERT INTO public.mb13_p1_universal_diff_revision (
        owner_user_id, diff_id, revision, monitor_revision, baseline_ref, observation_ref,
        diff_kind, diff_state, summary, change_count, material_change_count, changes,
        source_refs, evidence_refs, consent_refs, algorithm_version, normalization_version,
        payload_hash, content_hash, request_payload, result_payload
    ) VALUES (
        v_owner, v_diff_id, v_revision, v_current.current_revision, v_current.target_ref, p_observation_ref,
        p_diff_kind, v_diff_state, v_summary, v_change_count, v_material_change_count, v_canonical_changes,
        v_effective_source_refs, v_effective_evidence_refs, v_canonical_consent_refs,
        p_algorithm_version, p_normalization_version,
        v_content_hash, v_content_hash, COALESCE(p_request_payload, '{}'::jsonb), v_event_result_payload
    );

    IF v_diff_state = 'no_change' THEN
        v_event_type := 'NO_CHANGE_RECORDED';
    ELSE
        v_event_type := 'CHANGE_CANDIDATE_RECORDED';
    END IF;

    v_event_id := gen_random_uuid();
    v_event_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'event_id', v_event_id,
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'event_type', v_event_type,
        'event_status', 'recorded',
        'event_time', to_jsonb(v_event_time),
        'observed_ref', p_observation_ref,
        'source_refs', v_effective_source_refs,
        'evidence_refs', v_effective_evidence_refs,
        'consent_refs', v_canonical_consent_refs,
        'reason', NULL,
        'result_payload', v_event_result_payload
    ));

    INSERT INTO public.mb13_p0_monitor_event_ledger (
        event_id, owner_user_id, monitor_id, monitor_revision, event_type, event_status, event_time,
        observed_ref, source_refs, evidence_refs, consent_refs, reason, result_payload, payload_hash
    ) VALUES (
        v_event_id, v_owner, p_monitor_id, v_current.current_revision, v_event_type, 'recorded', v_event_time,
        p_observation_ref, v_effective_source_refs, v_effective_evidence_refs, v_canonical_consent_refs, NULL, v_event_result_payload, v_event_payload_hash
    );

    RETURN QUERY SELECT v_diff_id, v_revision, v_content_hash, v_diff_state, v_change_count, v_material_change_count, v_summary, v_canonical_changes;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_write_diff(UUID,UUID,JSONB,TEXT,JSONB,INTEGER,INTEGER,TEXT,TEXT,TEXT,TEXT,JSONB,JSONB) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID,UUID,JSONB,TEXT,JSONB,INTEGER,INTEGER,TEXT,TEXT,TEXT,TEXT,JSONB,JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_write_diff(UUID,UUID,JSONB,TEXT,JSONB,INTEGER,INTEGER,TEXT,TEXT,TEXT,TEXT,JSONB,JSONB) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p1_write_diff(UUID,UUID,JSONB,TEXT,JSONB,INTEGER,INTEGER,TEXT,TEXT,TEXT,TEXT,JSONB,JSONB) TO mb13_p1_app;

-- ----------------------------------------------------------------------------
-- Grants
-- ----------------------------------------------------------------------------
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p1_preflight_state TO mb13_p1_executor;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p1_universal_diff TO mb13_p1_executor;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p1_universal_diff_revision TO mb13_p1_executor;
GRANT SELECT, INSERT, UPDATE ON public.mb13_p1_document_revision TO mb13_p1_executor;
GRANT SELECT ON public.documenti TO mb13_p1_executor;
GRANT SELECT, UPDATE ON public.mb12_p1_offer_contract TO mb13_p1_executor;
GRANT SELECT, UPDATE ON public.mb12_p1_offer_contract_revision TO mb13_p1_executor;
GRANT SELECT, UPDATE ON public.mb12_p4_governed_explainable_ranking TO mb13_p1_executor;
GRANT SELECT, UPDATE ON public.mb12_p4_governed_explainable_ranking_revision TO mb13_p1_executor;
GRANT SELECT ON public.mb12_p0_trusted_data_value TO mb13_p1_executor;
GRANT SELECT ON public.authorized_memory_sources TO mb13_p1_executor;
GRANT SELECT ON public.authorized_memory_consent_grants TO mb13_p1_executor;
GRANT SELECT ON public.mb12_p0_source_card_binding TO mb13_p1_executor;
GRANT SELECT ON public.authorized_memory_inventory_items TO mb13_p1_executor;
GRANT SELECT ON public.authorized_memory_activity_log TO mb13_p1_executor;

GRANT EXECUTE ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID,JSONB,TEXT,JSONB,BOOLEAN,BOOLEAN) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p0_get_target_provenance(UUID,TEXT,JSONB) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p0_hash_jsonb(JSONB) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p0_normalize_jsonb_array(JSONB) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p1_resolve_target(UUID, TEXT, JSONB) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p1_canonical_jsonb(JSONB) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p1_typed_hash(JSONB) TO mb13_p1_executor;

-- API role can read monitors and preflight/create requests but cannot write diff tables directly.
GRANT SELECT, UPDATE ON public.mb13_p0_monitor_target TO mb13_p1_app;
GRANT SELECT, INSERT, UPDATE ON public.mb13_p1_preflight_state TO mb13_p1_app;
GRANT SELECT ON public.mb13_p1_universal_diff TO mb13_p1_app;
GRANT SELECT ON public.mb13_p1_universal_diff_revision TO mb13_p1_app;
GRANT SELECT ON public.mb13_p1_document_revision TO mb13_p1_app;
GRANT SELECT ON public.documenti TO mb13_p1_app;
GRANT SELECT ON public.mb12_p1_offer_contract TO mb13_p1_app;
GRANT SELECT ON public.mb12_p1_offer_contract_revision TO mb13_p1_app;
GRANT SELECT ON public.mb12_p4_governed_explainable_ranking TO mb13_p1_app;
GRANT SELECT ON public.mb12_p4_governed_explainable_ranking_revision TO mb13_p1_app;

COMMIT;
