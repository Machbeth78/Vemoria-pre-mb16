-- ----------------------------------------------------------------------------
-- MB13-P3 v220 — real legacy chain, privilege and mutation closure
-- ----------------------------------------------------------------------------
-- Corrections from v219:
--   * Recovery is based on the real post-v218 state, not on synthetic keys.
--   * No automatic quarantine from legacy- prefixes.
--   * The legacy idempotency recovery function is closed after migration.
--   * Pack mutations are gated by an internal NOLOGIN role, not by a GUC.
-- ----------------------------------------------------------------------------

-- 1. Internal NOLOGIN role that owns the governed pack tables.
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p3_pack_mutator') THEN
        CREATE ROLE mb13_p3_pack_mutator NOLOGIN BYPASSRLS;
    END IF;
END $$;

ALTER ROLE mb13_p3_pack_mutator BYPASSRLS;
GRANT USAGE ON SCHEMA public TO mb13_p3_pack_mutator;

-- Allow the writer role to pass the mutator gate, but do not inherit privileges
-- that would let it execute the internal classifier or other mutator-owned surfaces.
GRANT mb13_p3_pack_mutator TO mb13_p3_writer;
ALTER ROLE mb13_p3_writer NOINHERIT;

-- The real legacy classifier recomputes payload hashes through the immutable helper.
GRANT EXECUTE ON FUNCTION public.mb13_p0_hash_jsonb(JSONB) TO mb13_p3_pack_mutator;

-- 2. Replace the GUC-based pack mutation gate with a role-based gate.
DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_governed_mutation ON public.mb13_p3_action_pack;
DROP FUNCTION IF EXISTS public.mb13_p3_action_pack_governed_mutation();

CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_governed_mutation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF current_user = 'mb13_p3_pack_mutator' OR current_user = 'mb13_p3_writer' THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;
    RAISE EXCEPTION 'mb13_p3_action_pack_direct_mutation_denied' USING ERRCODE = '42501';
END;
$$;

ALTER FUNCTION public.mb13_p3_action_pack_governed_mutation() OWNER TO mb13_p3_pack_mutator;

CREATE TRIGGER trg_mb13_p3_action_pack_governed_mutation
    BEFORE INSERT OR UPDATE OR DELETE ON public.mb13_p3_action_pack
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p3_action_pack_governed_mutation();

-- The lifecycle functions are SECURITY DEFINER as mb13_p3_writer, so the trigger
-- must be executable by the writer role without inheriting mutator privileges.
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_governed_mutation() TO mb13_p3_writer;

-- 3. Transfer pack table ownership to the internal mutator role and lock down DML.
ALTER TABLE public.mb13_p3_action_pack OWNER TO mb13_p3_pack_mutator;
ALTER TABLE public.mb13_p3_action_pack_revision OWNER TO mb13_p3_pack_mutator;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p3_action_pack TO mb13_p3_writer;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p3_action_pack_revision TO mb13_p3_writer;
GRANT SELECT ON public.mb13_p3_action_pack TO mb13_p3_validator;
GRANT SELECT ON public.mb13_p3_action_pack_revision TO mb13_p3_validator;

REVOKE ALL ON public.mb13_p3_action_pack FROM PUBLIC, mb13_p3_api, mb13_p3_executor;
REVOKE ALL ON public.mb13_p3_action_pack_revision FROM PUBLIC, mb13_p3_api, mb13_p3_executor;

-- v207 intentionally removes the historical test_app role. A clean bootstrap
-- must therefore not reference it unconditionally here. Keep compatibility
-- with upgraded installations where the role may still exist, but make the
-- migration replay-safe on a fresh cluster.
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'test_app') THEN
        REVOKE ALL ON public.mb13_p3_action_pack FROM test_app;
        REVOKE ALL ON public.mb13_p3_action_pack_revision FROM test_app;
    END IF;
END
$$;

-- 4. Make the legacy recovery surface fail-closed: it is no longer invocable.
CREATE OR REPLACE FUNCTION public.mb13_p3_legacy_idempotency_recover()
RETURNS TABLE(
    stage text,
    item_type text,
    candidate_count bigint,
    restored_count bigint,
    excluded_count bigint,
    quarantined_count bigint
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    RAISE EXCEPTION 'mb13_p3_legacy_recovery_disabled' USING ERRCODE = '42501';
END;
$$;

ALTER FUNCTION public.mb13_p3_legacy_idempotency_recover() OWNER TO mb13_p3_pack_mutator;
REVOKE ALL ON FUNCTION public.mb13_p3_legacy_idempotency_recover() FROM PUBLIC;

-- 5. Lifecycle mutation functions must execute under the internal writer role.
DO $$
DECLARE
    r RECORD;
BEGIN
    FOR r IN
        SELECT proname, pg_get_function_identity_arguments(oid) AS args
        FROM pg_proc
        WHERE proname IN ('mb13_p3_create_action_pack', 'mb13_p3_revise_action_pack')
    LOOP
        EXECUTE format('ALTER FUNCTION public.%I(%s) OWNER TO mb13_p3_writer', r.proname, r.args);
    END LOOP;
END $$;

-- 6. Real legacy classifier: no synthetic-key reconstruction, no prefix quarantine.
--    It re-evaluates rows that are legacy/unverified, quarantined or key-less and
--    marks them either as authentic (coherent with the stored idempotency key and
--    current revision) or as legacy_recovery_ambiguous.
CREATE OR REPLACE FUNCTION public.mb13_p3_real_legacy_classify()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
    v_count INTEGER := 0;
    v_pack RECORD;
    v_revision public.mb13_p3_action_pack_revision%ROWTYPE;
    v_expected_pack_hash TEXT;
    v_expected_revision_hash TEXT;
    v_quarantine BOOLEAN;
    v_reason TEXT;
BEGIN
    FOR v_pack IN
        SELECT * FROM public.mb13_p3_action_pack
         WHERE legacy_idempotency_unverified = TRUE
            OR legacy_idempotency_quarantined = TRUE
            OR idempotency_key IS NULL
    LOOP
        v_quarantine := FALSE;
        v_reason := NULL;

        -- Unaffected normal rows are skipped.
        CONTINUE WHEN v_pack.idempotency_key IS NOT NULL
                     AND NOT COALESCE(v_pack.legacy_idempotency_unverified, FALSE)
                     AND NOT COALESCE(v_pack.legacy_idempotency_quarantined, FALSE);

        SELECT * INTO v_revision
          FROM public.mb13_p3_action_pack_revision
         WHERE pack_id = v_pack.pack_id
           AND revision = v_pack.pack_revision;

        IF NOT FOUND THEN
            v_quarantine := TRUE;
            v_reason := 'legacy_recovery_ambiguous';
        ELSE
            -- Canonical projection (excluding idempotency/payload/quarantine/flags).
            IF v_pack.owner_user_id IS DISTINCT FROM v_revision.owner_user_id
               OR v_pack.pack_id IS DISTINCT FROM v_revision.pack_id
               OR v_pack.pack_revision IS DISTINCT FROM v_revision.revision
               OR v_pack.monitor_revision IS DISTINCT FROM v_revision.monitor_revision
               OR v_pack.trigger_event_id IS DISTINCT FROM v_revision.trigger_event_id
               OR v_pack.diff_result_id IS DISTINCT FROM v_revision.diff_result_id
               OR v_pack.action_type IS DISTINCT FROM v_revision.action_type
               OR v_pack.target_ref IS DISTINCT FROM v_revision.target_ref
               OR v_pack.consent_refs IS DISTINCT FROM v_revision.consent_refs
               OR v_pack.provenance_refs IS DISTINCT FROM v_revision.provenance_refs
               OR v_pack.steps IS DISTINCT FROM v_revision.steps
               OR v_pack.expires_at IS DISTINCT FROM v_revision.expires_at
            THEN
                v_quarantine := TRUE;
                v_reason := 'legacy_recovery_ambiguous';
            END IF;

            IF NOT v_quarantine THEN
                BEGIN
                    v_expected_pack_hash := public.mb13_p3_action_pack_payload_hash(
                        v_pack.owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
                        v_pack.trigger_event_id, v_pack.diff_result_id, v_pack.action_type,
                        v_pack.target_ref, v_pack.consent_refs, v_pack.provenance_refs, v_pack.steps,
                        v_pack.expires_at, v_pack.idempotency_key, v_revision.status
                    );
                    IF v_expected_pack_hash IS DISTINCT FROM v_pack.payload_hash THEN
                        v_quarantine := TRUE;
                        v_reason := 'legacy_recovery_ambiguous';
                    END IF;
                EXCEPTION WHEN OTHERS THEN
                    v_quarantine := TRUE;
                    v_reason := 'legacy_recovery_ambiguous';
                END;
            END IF;

            IF NOT v_quarantine THEN
                BEGIN
                    v_expected_revision_hash := public.mb13_p3_action_pack_payload_hash(
                        v_revision.owner_user_id, v_pack.monitor_id, v_revision.monitor_revision,
                        v_revision.trigger_event_id, v_revision.diff_result_id, v_revision.action_type,
                        v_revision.target_ref, v_revision.consent_refs, v_revision.provenance_refs, v_revision.steps,
                        v_revision.expires_at, v_revision.idempotency_key, v_revision.status
                    );
                    IF v_expected_revision_hash IS DISTINCT FROM v_revision.payload_hash THEN
                        v_quarantine := TRUE;
                        v_reason := 'legacy_recovery_ambiguous';
                    END IF;
                EXCEPTION WHEN OTHERS THEN
                    v_quarantine := TRUE;
                    v_reason := 'legacy_recovery_ambiguous';
                END;
            END IF;

            IF NOT v_quarantine THEN
                BEGIN
                    PERFORM public.mb13_p3_validate_trigger_diff(
                        v_pack.owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
                        v_pack.trigger_event_id, v_pack.diff_result_id
                    );
                EXCEPTION WHEN OTHERS THEN
                    v_quarantine := TRUE;
                    v_reason := 'legacy_recovery_ambiguous';
                END;
            END IF;
        END IF;

        UPDATE public.mb13_p3_action_pack
           SET legacy_idempotency_unverified = TRUE,
               legacy_idempotency_quarantined = v_quarantine,
               legacy_idempotency_quarantine_reason = v_reason
         WHERE pack_id = v_pack.pack_id;

        UPDATE public.mb13_p3_action_pack_revision
           SET legacy_idempotency_unverified = TRUE,
               legacy_idempotency_quarantined = v_quarantine,
               legacy_idempotency_quarantine_reason = v_reason
         WHERE pack_id = v_pack.pack_id
           AND revision = v_pack.pack_revision;

        v_count := v_count + 1;
    END LOOP;

    RETURN v_count;
END;
$$;

ALTER FUNCTION public.mb13_p3_real_legacy_classify() OWNER TO mb13_p3_pack_mutator;

GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_payload_hash(
    uuid, uuid, integer, uuid, uuid, text, jsonb, jsonb, jsonb, jsonb, timestamp with time zone, text, text
) TO mb13_p3_pack_mutator;

GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_trigger_diff(
    uuid, uuid, integer, uuid, uuid
) TO mb13_p3_pack_mutator;

REVOKE ALL ON FUNCTION public.mb13_p3_real_legacy_classify() FROM PUBLIC, mb13_p3_api, mb13_p3_executor, mb13_p3_writer;
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'test_app') THEN
        REVOKE ALL ON FUNCTION public.mb13_p3_real_legacy_classify() FROM test_app;
    END IF;
END
$$;

-- 7. Run the real-legacy classification. The revision-immutable trigger is
--    disabled briefly so the current-revision quarantine flags can be updated.
ALTER TABLE public.mb13_p3_action_pack_revision DISABLE TRIGGER trg_mb13_p3_revision_immutable;
SELECT public.mb13_p3_real_legacy_classify();
ALTER TABLE public.mb13_p3_action_pack_revision ENABLE TRIGGER trg_mb13_p3_revision_immutable;
