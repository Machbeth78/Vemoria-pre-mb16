-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V58 — ECO User Adaptation Controls + Category Switches

ALTER TABLE eco_user_voice_profiles
    ADD COLUMN IF NOT EXISTS learning_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS phonetic_learning_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS semantic_ref_learning_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS screen_habit_learning_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS correction_learning_enabled BOOLEAN NOT NULL DEFAULT TRUE;

UPDATE eco_user_voice_profiles
SET learning_enabled = COALESCE(learning_enabled, TRUE),
    phonetic_learning_enabled = COALESCE(phonetic_learning_enabled, TRUE),
    semantic_ref_learning_enabled = COALESCE(semantic_ref_learning_enabled, TRUE),
    screen_habit_learning_enabled = COALESCE(screen_habit_learning_enabled, TRUE),
    correction_learning_enabled = COALESCE(correction_learning_enabled, TRUE)
WHERE TRUE;
