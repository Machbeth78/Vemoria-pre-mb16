-- MB13-P3 v224 -- role-based mutation gate, full ACL normalization,
-- exact-scope ownership, structural trigger allowlist, reason-specific recovery.
-- Do not reopen MB13-P1/MB13-P2, do not open R3, do not produce APK/AAB.
BEGIN;

-- ============================================================================
-- 1. Role definitions and inertization of legacy privileged roles
-- ============================================================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p3_pack_data_owner') THEN
        CREATE ROLE mb13_p3_pack_data_owner NOLOGIN NOINHERIT NOBYPASSRLS;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p3_pack_lifecycle_executor') THEN
        CREATE ROLE mb13_p3_pack_lifecycle_executor NOLOGIN NOINHERIT NOBYPASSRLS;
    END IF;
END $$;

ALTER ROLE mb13_p3_pack_data_owner NOLOGIN NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p3_pack_lifecycle_executor NOLOGIN NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p3_pack_mutator NOLOGIN NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p3_pack_lifecycle_owner NOLOGIN NOINHERIT NOBYPASSRLS;

-- ============================================================================
-- 2. Exact canonical object allowlist and structural trigger verification
-- ============================================================================
DO $$
DECLARE
    v_allowed_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    v_allowed_sequences TEXT[] := ARRAY[
        'mb13_p3_recovery_audit_audit_id_seq'
    ];
    v_allowed_functions TEXT[] := ARRAY[
        'mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_authorization_append_only()',
        'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_evidence_immutable()',
        'mb13_p3_action_pack_governed_mutation()',
        'mb13_p3_action_pack_monitor_policy_hash()',
        'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)',
        'mb13_p3_action_pack_result_evidence_guard()',
        'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)',
        'mb13_p3_action_pack_result_immutable()',
        'mb13_p3_action_pack_revision_immutable()',
        'mb13_p3_action_pack_terminal_attempt_sync()',
        'mb13_p3_action_pack_timeline_immutable()',
        'mb13_p3_action_pack_transition_guard()',
        'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'mb13_p3_cancel_action_pack(uuid,uuid)',
        'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)',
        'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_expire_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack_attempts(uuid,uuid)',
        'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)',
        'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)',
        'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)',
        'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)',
        'mb13_p3_list_action_packs(uuid,text,integer,integer)',
        'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'mb13_p3_recovery_audit_immutable()',
        'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'mb13_p3_revoke_action_pack(uuid,uuid)',
        'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)',
        'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)',
        'mb13_p3_validate_result_evidence(jsonb)',
        'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)',
        'mb13_p3_validate_steps(uuid,jsonb)',
        'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'
    ];
    v_allowed_roles TEXT[] := ARRAY[
        'mb13_p3_api',
        'mb13_p3_executor',
        'mb13_p3_pack_data_owner',
        'mb13_p3_pack_lifecycle_executor',
        'mb13_p3_pack_lifecycle_owner',
        'mb13_p3_pack_mutator',
        'mb13_p3_validator',
        'mb13_p3_writer'
    ];
    r RECORD;
    t TEXT;
    s TEXT;
    sig TEXT;
BEGIN
    -- Unexpected / missing tables
    FOR r IN
        SELECT relname FROM pg_class
         WHERE relnamespace = 'public'::regnamespace
           AND relkind = 'r'
           AND relname LIKE 'mb13_p3_%'
           AND NOT (relname = ANY(v_allowed_tables))
    LOOP
        RAISE EXCEPTION 'migration_v224 unexpected table: %', r.relname;
    END LOOP;

    FOREACH t IN ARRAY v_allowed_tables LOOP
        IF to_regclass('public.' || t) IS NULL THEN
            RAISE EXCEPTION 'migration_v224 missing table: %', t;
        END IF;
    END LOOP;

    -- Unexpected / missing sequences
    FOR r IN
        SELECT c.relname FROM pg_class c
          JOIN pg_namespace n ON c.relnamespace = n.oid
         WHERE n.nspname = 'public'
           AND c.relkind = 'S'
           AND c.relname LIKE 'mb13_p3_%'
           AND NOT (c.relname = ANY(v_allowed_sequences))
    LOOP
        RAISE EXCEPTION 'migration_v224 unexpected sequence: %', r.relname;
    END LOOP;

    FOREACH s IN ARRAY v_allowed_sequences LOOP
        IF to_regclass('public.' || s) IS NULL THEN
            RAISE EXCEPTION 'migration_v224 missing sequence: %', s;
        END IF;
    END LOOP;

    -- Unexpected / missing functions (exact regprocedure signatures)
    FOR r IN
        SELECT p.oid::regprocedure::text AS sig
          FROM pg_proc p
          JOIN pg_namespace n ON p.pronamespace = n.oid
         WHERE n.nspname = 'public'
           AND p.proname LIKE 'mb13_p3_%'
           AND NOT (p.oid::regprocedure::text = ANY(v_allowed_functions))
    LOOP
        RAISE EXCEPTION 'migration_v224 unexpected function: %', r.sig;
    END LOOP;

    FOREACH sig IN ARRAY v_allowed_functions LOOP
        IF to_regprocedure(sig) IS NULL THEN
            RAISE EXCEPTION 'migration_v224 missing function: %', sig;
        END IF;
    END LOOP;

    -- Unexpected / missing roles
    FOR r IN
        SELECT rolname FROM pg_roles
         WHERE rolname LIKE 'mb13_p3_%'
           AND NOT (rolname = ANY(v_allowed_roles))
    LOOP
        RAISE EXCEPTION 'migration_v224 unexpected role: %', r.rolname;
    END LOOP;

    FOREACH t IN ARRAY v_allowed_roles LOOP
        IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = t) THEN
            RAISE EXCEPTION 'migration_v224 missing role: %', t;
        END IF;
    END LOOP;

    -- Structural trigger allowlist: exact table + trigger + function + timing + events + enabled state.
    CREATE TEMP TABLE IF NOT EXISTS v224_trigger_allowlist (
        relname text,
        tgname text,
        proname text,
        tgtype smallint,
        enabled text
    ) ON COMMIT DROP;
    TRUNCATE v224_trigger_allowlist;

    INSERT INTO v224_trigger_allowlist (relname, tgname, proname, tgtype, enabled) VALUES
        ('mb13_p3_action_pack', 'trg_mb13_p3_action_pack_governed_mutation', 'mb13_p3_action_pack_governed_mutation', 31::smallint, 'O'),
        ('mb13_p3_action_pack', 'trg_mb13_p3_action_pack_monitor_policy_hash', 'mb13_p3_action_pack_monitor_policy_hash', 23::smallint, 'O'),
        ('mb13_p3_action_pack', 'trg_mb13_p3_action_pack_terminal_attempt_sync', 'mb13_p3_action_pack_terminal_attempt_sync', 17::smallint, 'O'),
        ('mb13_p3_action_pack', 'trg_mb13_p3_action_pack_transition_guard', 'mb13_p3_action_pack_transition_guard', 23::smallint, 'O'),
        ('mb13_p3_action_pack_authorization', 'trg_mb13_p3_authorization_append_only', 'mb13_p3_action_pack_authorization_append_only', 27::smallint, 'O'),
        ('mb13_p3_action_pack_evidence', 'trg_mb13_p3_evidence_immutable', 'mb13_p3_action_pack_evidence_immutable', 27::smallint, 'O'),
        ('mb13_p3_action_pack_result', 'trg_mb13_p3_action_pack_result_evidence_guard', 'mb13_p3_action_pack_result_evidence_guard', 7::smallint, 'O'),
        ('mb13_p3_action_pack_result', 'trg_mb13_p3_result_immutable', 'mb13_p3_action_pack_result_immutable', 27::smallint, 'O'),
        ('mb13_p3_action_pack_revision', 'trg_mb13_p3_revision_immutable', 'mb13_p3_action_pack_revision_immutable', 27::smallint, 'O'),
        ('mb13_p3_action_pack_timeline', 'trg_mb13_p3_timeline_immutable', 'mb13_p3_action_pack_timeline_immutable', 31::smallint, 'O'),
        ('mb13_p3_recovery_audit', 'trg_mb13_p3_recovery_audit_immutable', 'mb13_p3_recovery_audit_immutable', 27::smallint, 'O');

    -- Verify expected triggers exist with exact properties.
    FOR r IN SELECT * FROM v224_trigger_allowlist LOOP
        PERFORM 1
          FROM pg_trigger t
          JOIN pg_class c ON t.tgrelid = c.oid
          JOIN pg_namespace n ON c.relnamespace = n.oid
          JOIN pg_proc p ON t.tgfoid = p.oid
         WHERE n.nspname = 'public'
           AND c.relname = r.relname
           AND t.tgname = r.tgname
           AND p.proname = r.proname
           AND t.tgtype = r.tgtype
           AND t.tgenabled = r.enabled;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'migration_v224 missing or malformed trigger % on % (expected type %, function %, enabled %)', r.tgname, r.relname, r.tgtype, r.proname, r.enabled;
        END IF;
    END LOOP;

    -- Reject any unexpected trigger on the allowlisted tables.
    FOR r IN
        SELECT c.relname AS relname, t.tgname AS tgname
          FROM pg_trigger t
          JOIN pg_class c ON t.tgrelid = c.oid
          JOIN pg_namespace n ON c.relnamespace = n.oid
         WHERE n.nspname = 'public'
           AND c.relname = ANY(v_allowed_tables)
           AND NOT t.tgisinternal
    LOOP
        PERFORM 1 FROM v224_trigger_allowlist a
         WHERE a.relname = r.relname AND a.tgname = r.tgname;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'migration_v224 unexpected trigger % on table %', r.tgname, r.relname;
        END IF;
    END LOOP;
END $$;

-- ============================================================================
-- 3. Exact-scope legacy role cleanup: no global REASSIGN OWNED / DROP OWNED
-- ============================================================================
DO $$
DECLARE
    v_allowed_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    v_allowed_sequences TEXT[] := ARRAY[
        'mb13_p3_recovery_audit_audit_id_seq'
    ];
    v_allowed_functions TEXT[] := ARRAY[
        'mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_authorization_append_only()',
        'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_evidence_immutable()',
        'mb13_p3_action_pack_governed_mutation()',
        'mb13_p3_action_pack_monitor_policy_hash()',
        'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)',
        'mb13_p3_action_pack_result_evidence_guard()',
        'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)',
        'mb13_p3_action_pack_result_immutable()',
        'mb13_p3_action_pack_revision_immutable()',
        'mb13_p3_action_pack_terminal_attempt_sync()',
        'mb13_p3_action_pack_timeline_immutable()',
        'mb13_p3_action_pack_transition_guard()',
        'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'mb13_p3_cancel_action_pack(uuid,uuid)',
        'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)',
        'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_expire_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack_attempts(uuid,uuid)',
        'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)',
        'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)',
        'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)',
        'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)',
        'mb13_p3_list_action_packs(uuid,text,integer,integer)',
        'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'mb13_p3_recovery_audit_immutable()',
        'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'mb13_p3_revoke_action_pack(uuid,uuid)',
        'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)',
        'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)',
        'mb13_p3_validate_result_evidence(jsonb)',
        'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)',
        'mb13_p3_validate_steps(uuid,jsonb)',
        'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'
    ];
    r RECORD;
    v_owner_role TEXT;
    v_new_owner TEXT;
    v_fn_proname TEXT;
BEGIN
    FOREACH v_owner_role IN ARRAY ARRAY['mb13_p3_pack_lifecycle_owner', 'mb13_p3_pack_mutator'] LOOP
        -- Tables / sequences owned by the legacy role: fail if unexpected, else transfer per object.
        FOR r IN
            SELECT c.relkind, c.relname
              FROM pg_class c
              JOIN pg_namespace n ON c.relnamespace = n.oid
              JOIN pg_roles rol ON c.relowner = rol.oid
             WHERE rol.rolname = v_owner_role
               AND n.nspname = 'public'
        LOOP
            IF r.relkind = 'S' THEN
                IF NOT (r.relname = ANY(v_allowed_sequences)) THEN
                    RAISE EXCEPTION 'migration_v224 legacy role % owns unexpected sequence %', v_owner_role, r.relname;
                END IF;
                EXECUTE format('ALTER SEQUENCE public.%I OWNER TO mb13_p3_pack_data_owner', r.relname);
            ELSIF r.relkind = 'r' THEN
                IF NOT (r.relname = ANY(v_allowed_tables)) THEN
                    RAISE EXCEPTION 'migration_v224 legacy role % owns unexpected table %', v_owner_role, r.relname;
                END IF;
                EXECUTE format('ALTER TABLE public.%I OWNER TO mb13_p3_pack_data_owner', r.relname);
            END IF;
        END LOOP;

        -- Functions owned by the legacy role: fail if unexpected, else transfer per object.
        FOR r IN
            SELECT p.oid::regprocedure::text AS sig, p.proname
              FROM pg_proc p
              JOIN pg_namespace n ON p.pronamespace = n.oid
              JOIN pg_roles rol ON p.proowner = rol.oid
             WHERE rol.rolname = v_owner_role
               AND n.nspname = 'public'
        LOOP
            IF NOT (r.sig = ANY(v_allowed_functions)) THEN
                RAISE EXCEPTION 'migration_v224 legacy role % owns unexpected function %', v_owner_role, r.sig;
            END IF;
            v_fn_proname := r.proname;
            IF v_fn_proname = ANY(ARRAY['mb13_p3_action_pack_refs_revoked', 'mb13_p3_validate_source_grant_chain', 'mb13_p3_validate_trigger_diff']) THEN
                v_new_owner := 'mb13_p3_validator';
            ELSE
                v_new_owner := 'mb13_p3_pack_lifecycle_executor';
            END IF;
            EXECUTE format('ALTER FUNCTION %s OWNER TO %I', r.sig, v_new_owner);
        END LOOP;
    END LOOP;
END $$;

-- ============================================================================
-- 4. Transfer all allowlisted tables and sequences to the data owner
-- ============================================================================
DO $$
DECLARE
    v_allowed_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    v_allowed_sequences TEXT[] := ARRAY[
        'mb13_p3_recovery_audit_audit_id_seq'
    ];
    t TEXT;
    s TEXT;
BEGIN
    FOREACH t IN ARRAY v_allowed_tables LOOP
        EXECUTE format('ALTER TABLE public.%I OWNER TO mb13_p3_pack_data_owner', t);
    END LOOP;
    FOREACH s IN ARRAY v_allowed_sequences LOOP
        EXECUTE format('ALTER SEQUENCE public.%I OWNER TO mb13_p3_pack_data_owner', s);
    END LOOP;
END $$;

-- ============================================================================
-- 5. Ensure the data owner holds the full privilege set on its own objects
--      and can satisfy FK FOR KEY SHARE checks on referenced tables.
-- ============================================================================
GRANT ALL PRIVILEGES ON TABLE
    public.mb13_p3_action_pack,
    public.mb13_p3_action_pack_attempt,
    public.mb13_p3_action_pack_authorization,
    public.mb13_p3_action_pack_evidence,
    public.mb13_p3_action_pack_result,
    public.mb13_p3_action_pack_revision,
    public.mb13_p3_action_pack_timeline,
    public.mb13_p3_recovery_audit
    TO mb13_p3_pack_data_owner;

GRANT ALL PRIVILEGES ON SEQUENCE public.mb13_p3_recovery_audit_audit_id_seq
    TO mb13_p3_pack_data_owner;

GRANT SELECT ON TABLE public.mb13_p0_monitor_target TO mb13_p3_pack_data_owner;

-- ============================================================================
-- 6. Recreate the pack mutation gate as a role-based fail-closed check.
--      Only mb13_p3_pack_lifecycle_executor (the function owner) may mutate
--      action_pack directly; no GUC or SET ROLE fallback is authorized.
-- ============================================================================
DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_governed_mutation ON public.mb13_p3_action_pack;
DROP FUNCTION IF EXISTS public.mb13_p3_action_pack_governed_mutation();

CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_governed_mutation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF current_user = 'mb13_p3_pack_lifecycle_executor' THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;
    RAISE EXCEPTION 'mb13_p3_action_pack_direct_mutation_denied'
        USING ERRCODE = '42501';
END;
$$;

ALTER FUNCTION public.mb13_p3_action_pack_governed_mutation() OWNER TO mb13_p3_pack_lifecycle_executor;

CREATE TRIGGER trg_mb13_p3_action_pack_governed_mutation
    BEFORE INSERT OR UPDATE OR DELETE ON public.mb13_p3_action_pack
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p3_action_pack_governed_mutation();

-- Re-create the remaining BEFORE triggers so the role-based gate fires first.
DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_monitor_policy_hash ON public.mb13_p3_action_pack;
CREATE TRIGGER trg_mb13_p3_action_pack_monitor_policy_hash
    BEFORE INSERT OR UPDATE ON public.mb13_p3_action_pack
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p3_action_pack_monitor_policy_hash();

DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_transition_guard ON public.mb13_p3_action_pack;
CREATE TRIGGER trg_mb13_p3_action_pack_transition_guard
    BEFORE INSERT OR UPDATE ON public.mb13_p3_action_pack
    FOR EACH ROW EXECUTE FUNCTION public.mb13_p3_action_pack_transition_guard();

-- ============================================================================
-- 7. Transfer all allowlisted functions to the lifecycle executor or validator
-- ============================================================================
DO $$
DECLARE
    v_lifecycle TEXT[] := ARRAY[
        'mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_authorization_append_only()',
        'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_evidence_immutable()',
        'mb13_p3_action_pack_governed_mutation()',
        'mb13_p3_action_pack_monitor_policy_hash()',
        'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)',
        'mb13_p3_action_pack_result_evidence_guard()',
        'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)',
        'mb13_p3_action_pack_result_immutable()',
        'mb13_p3_action_pack_revision_immutable()',
        'mb13_p3_action_pack_terminal_attempt_sync()',
        'mb13_p3_action_pack_timeline_immutable()',
        'mb13_p3_action_pack_transition_guard()',
        'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'mb13_p3_cancel_action_pack(uuid,uuid)',
        'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)',
        'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_expire_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack_attempts(uuid,uuid)',
        'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)',
        'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)',
        'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)',
        'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)',
        'mb13_p3_list_action_packs(uuid,text,integer,integer)',
        'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'mb13_p3_recovery_audit_immutable()',
        'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'mb13_p3_revoke_action_pack(uuid,uuid)',
        'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)',
        'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)',
        'mb13_p3_validate_result_evidence(jsonb)',
        'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)',
        'mb13_p3_validate_steps(uuid,jsonb)',
        'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'
    ];
    v_validator TEXT[] := ARRAY[
        'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)',
        'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)',
        'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'
    ];
    sig TEXT;
BEGIN
    FOREACH sig IN ARRAY v_lifecycle LOOP
        EXECUTE format('ALTER FUNCTION %s OWNER TO mb13_p3_pack_lifecycle_executor', sig);
    END LOOP;
    FOREACH sig IN ARRAY v_validator LOOP
        EXECUTE format('ALTER FUNCTION %s OWNER TO mb13_p3_validator', sig);
    END LOOP;
END $$;

-- ============================================================================
-- 8. Grant lifecycle executor / validator the minimal table/sequence access
-- ============================================================================
DO $$
DECLARE
    v_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    t TEXT;
BEGIN
    FOREACH t IN ARRAY v_tables LOOP
        EXECUTE format('GRANT SELECT, INSERT, UPDATE ON TABLE public.%I TO mb13_p3_pack_lifecycle_executor', t);
    END LOOP;
END $$;

GRANT SELECT ON TABLE public.mb13_p0_monitor_target TO mb13_p3_pack_lifecycle_executor;
GRANT SELECT, UPDATE ON TABLE public.mb13_p0_monitor_target TO mb13_p3_pack_lifecycle_executor;
GRANT SELECT ON TABLE public.mb13_p0_monitor_target_revision TO mb13_p3_pack_lifecycle_executor;
GRANT SELECT ON TABLE public.mb13_p0_monitor_event_ledger TO mb13_p3_pack_lifecycle_executor;
GRANT SELECT ON TABLE public.authorized_memory_consent_grants TO mb13_p3_pack_lifecycle_executor;
GRANT SELECT ON TABLE public.authorized_memory_sources TO mb13_p3_pack_lifecycle_executor;
GRANT SELECT ON TABLE public.authorized_memory_activity_log TO mb13_p3_pack_lifecycle_executor;

GRANT USAGE, SELECT ON SEQUENCE public.mb13_p3_recovery_audit_audit_id_seq TO mb13_p3_pack_lifecycle_executor;

GRANT SELECT ON TABLE
    public.mb13_p3_action_pack,
    public.mb13_p3_action_pack_attempt,
    public.mb13_p3_action_pack_authorization,
    public.mb13_p3_action_pack_evidence,
    public.mb13_p3_action_pack_result,
    public.mb13_p3_action_pack_revision,
    public.mb13_p3_action_pack_timeline,
    public.mb13_p3_recovery_audit
    TO mb13_p3_validator;

GRANT SELECT ON TABLE public.mb13_p0_monitor_target TO mb13_p3_validator;
GRANT SELECT ON TABLE public.mb13_p0_monitor_target_revision TO mb13_p3_validator;
GRANT SELECT ON TABLE public.mb13_p0_monitor_event_ledger TO mb13_p3_validator;
GRANT SELECT ON TABLE public.authorized_memory_consent_grants TO mb13_p3_validator;
GRANT SELECT ON TABLE public.authorized_memory_sources TO mb13_p3_validator;
GRANT SELECT ON TABLE public.authorized_memory_activity_log TO mb13_p3_validator;

GRANT EXECUTE ON FUNCTION public.mb13_p0_hash_jsonb(JSONB) TO mb13_p3_pack_lifecycle_executor, mb13_p3_validator;

-- ============================================================================
-- 9. Normalize table/sequence ACLs per object: revoke-first, grant-exact
-- ============================================================================
DO $$
DECLARE
    v_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    v_revoke_roles TEXT[] := ARRAY[
        'PUBLIC', 'test_app', 'mb13_p3_api', 'mb13_p3_executor', 'mb13_p3_writer',
        'mb13_p3_validator', 'mb13_p3_pack_mutator', 'mb13_p3_pack_lifecycle_owner',
        'mb13_p3_pack_lifecycle_executor', 'mb13_p3_pack_data_owner'
    ];
    v_app_read_roles TEXT[] := ARRAY['mb13_p3_writer', 'mb13_p3_api', 'mb13_p3_executor', 'mb13_p3_validator'];
    t TEXT;
    r TEXT;
    v_grantees TEXT;
    v_role_sql TEXT;
BEGIN
    FOREACH t IN ARRAY v_tables LOOP
        -- Revoke every privilege from every role that must not hold broad grants.
        FOREACH r IN ARRAY v_revoke_roles LOOP
            v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
            EXECUTE format('REVOKE ALL PRIVILEGES ON TABLE public.%I FROM %s', t, v_role_sql);
        END LOOP;

        -- Grant full control to the data owner.
        EXECUTE format('GRANT ALL PRIVILEGES ON TABLE public.%I TO mb13_p3_pack_data_owner', t);

        -- Grant minimal mutation/lock access to the lifecycle executor.
        EXECUTE format('GRANT SELECT, INSERT, UPDATE ON TABLE public.%I TO mb13_p3_pack_lifecycle_executor', t);

        -- Grant read-only access to the application roles.
        v_grantees := array_to_string(v_app_read_roles, ', ');
        EXECUTE format('GRANT SELECT ON TABLE public.%I TO %s', t, v_grantees);
    END LOOP;
END $$;

DO $$
DECLARE
    v_seq TEXT := 'mb13_p3_recovery_audit_audit_id_seq';
    v_revoke_roles TEXT[] := ARRAY[
        'PUBLIC', 'test_app', 'mb13_p3_api', 'mb13_p3_executor', 'mb13_p3_writer',
        'mb13_p3_validator', 'mb13_p3_pack_mutator', 'mb13_p3_pack_lifecycle_owner'
    ];
    r TEXT;
    v_role_sql TEXT;
BEGIN
    FOREACH r IN ARRAY v_revoke_roles LOOP
        v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
        EXECUTE format('REVOKE ALL PRIVILEGES ON SEQUENCE public.%I FROM %s', v_seq, v_role_sql);
    END LOOP;
    EXECUTE format('GRANT ALL PRIVILEGES ON SEQUENCE public.%I TO mb13_p3_pack_data_owner', v_seq);
    EXECUTE format('GRANT USAGE, SELECT ON SEQUENCE public.%I TO mb13_p3_pack_lifecycle_executor', v_seq);
END $$;

-- ============================================================================
-- 10. Exact privilege matrix for all allowlisted functions (revoke-first)
-- ============================================================================
DO $$
DECLARE
    v_api_sigs TEXT[] := ARRAY[
        'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'mb13_p3_cancel_action_pack(uuid,uuid)',
        'mb13_p3_revoke_action_pack(uuid,uuid)'
    ];
    v_executor_sigs TEXT[] := ARRAY[
        'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'mb13_p3_expire_action_pack(uuid,uuid)'
    ];
    v_reader_sigs TEXT[] := ARRAY[
        'mb13_p3_get_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack_attempts(uuid,uuid)',
        'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)',
        'mb13_p3_list_action_packs(uuid,text,integer,integer)'
    ];
    v_all_entrypoints TEXT[] := v_api_sigs || v_executor_sigs || v_reader_sigs;
    v_internal TEXT[] := ARRAY[
        'mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_authorization_append_only()',
        'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_evidence_immutable()',
        'mb13_p3_action_pack_governed_mutation()',
        'mb13_p3_action_pack_monitor_policy_hash()',
        'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)',
        'mb13_p3_action_pack_result_evidence_guard()',
        'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)',
        'mb13_p3_action_pack_result_immutable()',
        'mb13_p3_action_pack_revision_immutable()',
        'mb13_p3_action_pack_terminal_attempt_sync()',
        'mb13_p3_action_pack_timeline_immutable()',
        'mb13_p3_action_pack_transition_guard()',
        'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)',
        'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)',
        'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)',
        'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)',
        'mb13_p3_recovery_audit_immutable()',
        'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)',
        'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)',
        'mb13_p3_validate_result_evidence(jsonb)',
        'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)',
        'mb13_p3_validate_steps(uuid,jsonb)',
        'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'
    ];
    v_revoke_roles TEXT[] := ARRAY[
        'PUBLIC', 'test_app', 'mb13_p3_api', 'mb13_p3_executor', 'mb13_p3_writer',
        'mb13_p3_validator', 'mb13_p3_pack_mutator', 'mb13_p3_pack_lifecycle_owner',
        'mb13_p3_pack_lifecycle_executor', 'mb13_p3_pack_data_owner'
    ];
    sig TEXT;
    proname TEXT;
    r TEXT;
    v_role_sql TEXT;
BEGIN
    -- Public API / lifecycle entrypoints: revoke from every role, then grant narrowly.
    FOREACH sig IN ARRAY v_all_entrypoints LOOP
        FOREACH r IN ARRAY v_revoke_roles LOOP
            v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
            EXECUTE format('REVOKE ALL ON FUNCTION %s FROM %s', sig, v_role_sql);
        END LOOP;
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_writer', sig);
    END LOOP;
    FOREACH sig IN ARRAY (v_api_sigs || v_reader_sigs) LOOP
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_api', sig);
    END LOOP;
    FOREACH sig IN ARRAY (v_executor_sigs || v_reader_sigs) LOOP
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_executor', sig);
    END LOOP;

    -- Internal helpers/triggers: revoke from every role, grant only to the lifecycle
    -- executor or the validator role where the helper is validator-owned.
    FOREACH sig IN ARRAY v_internal LOOP
        proname := split_part(sig, '(', 1);
        FOREACH r IN ARRAY v_revoke_roles LOOP
            v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
            EXECUTE format('REVOKE ALL ON FUNCTION %s FROM %s', sig, v_role_sql);
        END LOOP;
        IF proname = ANY(ARRAY['mb13_p3_action_pack_refs_revoked',
                              'mb13_p3_validate_source_grant_chain',
                              'mb13_p3_validate_trigger_diff']) THEN
            EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_validator, mb13_p3_pack_lifecycle_executor', sig);
        ELSE
            EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_pack_lifecycle_executor', sig);
        END IF;
    END LOOP;
END $$;

-- The governed-mutation trigger is SECURITY INVOKER: every role that may issue a
-- DML on action_pack needs EXECUTE, but the function itself denies all callers
-- except the lifecycle executor (the function owner during canonical DML).
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_governed_mutation()
    TO mb13_p3_pack_data_owner, mb13_p3_writer, mb13_p3_api, mb13_p3_executor,
       mb13_p3_validator, test_app;

-- ============================================================================
-- 11. Force RLS on every data-owner table; owners must not bypass RLS
-- ============================================================================
DO $$
DECLARE
    v_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    t TEXT;
BEGIN
    FOREACH t IN ARRAY v_tables LOOP
        EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
        EXECUTE format('ALTER TABLE public.%I FORCE ROW LEVEL SECURITY', t);
    END LOOP;
END $$;

-- recovery_audit has no owner_user_id column; allow the lifecycle executor to
-- append audit rows while keeping the table under RLS.
DROP POLICY IF EXISTS mb13_p3_recovery_audit_lifecycle ON public.mb13_p3_recovery_audit;
CREATE POLICY mb13_p3_recovery_audit_lifecycle
    ON public.mb13_p3_recovery_audit
    FOR ALL
    TO mb13_p3_pack_lifecycle_executor
    USING (true)
    WITH CHECK (true);

-- ============================================================================
-- 12. Ensure no application or legacy role can SET ROLE into the separated owners
-- ============================================================================
DO $$
DECLARE
    v_app_roles TEXT[] := ARRAY[
        'mb13_p3_writer','mb13_p3_api','mb13_p3_executor','mb13_p3_validator',
        'mb13_p3_pack_mutator','mb13_p3_pack_lifecycle_owner','test_app'
    ];
    v_owners TEXT[] := ARRAY[
        'mb13_p3_pack_data_owner','mb13_p3_pack_lifecycle_executor','mb13_p3_pack_lifecycle_owner'
    ];
    r TEXT;
    o TEXT;
BEGIN
    FOREACH r IN ARRAY v_app_roles LOOP
        FOREACH o IN ARRAY v_owners LOOP
            EXECUTE format('REVOKE %I FROM %I', o, r);
        END LOOP;
    END LOOP;
END $$;

-- ============================================================================
-- 13. Reason-specific quarantine preservation (generic exception is NOT auto-correctable)
-- ============================================================================
ALTER TABLE public.mb13_p3_recovery_audit
    DROP CONSTRAINT IF EXISTS mb13_p3_recovery_audit_classification_check;
ALTER TABLE public.mb13_p3_recovery_audit
    ADD CONSTRAINT mb13_p3_recovery_audit_classification_check
    CHECK (classification = ANY (ARRAY['candidate','verified','ambiguous','skipped','quarantined','upgraded','quarantine_preserved']));

CREATE OR REPLACE FUNCTION public.migration_v224_reason_specific_recovery()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
    v_run_id UUID := gen_random_uuid();
    v_pack RECORD;
    v_pack_hash TEXT;
BEGIN
    FOR v_pack IN
        SELECT *
          FROM public.mb13_p3_action_pack
         WHERE legacy_idempotency_quarantined = TRUE
           AND legacy_idempotency_quarantine_reason = 'legacy_recovery_exception'
         ORDER BY pack_id
    LOOP
        v_pack_hash := encode(digest(v_pack.pack_id::text, 'sha256'), 'hex');

        -- Preserve the generic-exception quarantine on the pack.
        -- The revision is append-only; its legacy quarantine flags are immutable.
        UPDATE public.mb13_p3_action_pack
           SET legacy_idempotency_quarantined = TRUE,
               legacy_idempotency_quarantine_reason = 'legacy_recovery_exception'
         WHERE pack_id = v_pack.pack_id;

        INSERT INTO public.mb13_p3_recovery_audit (
            migration_name, run_id, pack_id_hash, pack_revision, revision,
            classification, reason_code, before_hash, after_hash
        ) VALUES (
            'migration_v224_mb13_p3_role_gate_acl_normalization_exact_scope_closure.sql',
            v_run_id, v_pack_hash, v_pack.pack_revision, v_pack.pack_revision,
            'quarantine_preserved', 'legacy_recovery_exception_preserved',
            v_pack.payload_hash, v_pack.payload_hash
        );
    END LOOP;
END;
$$;

ALTER FUNCTION public.migration_v224_reason_specific_recovery() OWNER TO mb13_p3_pack_lifecycle_executor;
GRANT EXECUTE ON FUNCTION public.migration_v224_reason_specific_recovery() TO mb13_p3_pack_lifecycle_executor;

SELECT public.migration_v224_reason_specific_recovery();

-- ============================================================================
-- 14. Final inertization of legacy privileged roles: strip any residual per-object grants
-- ============================================================================
DO $$
DECLARE
    v_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    v_sequences TEXT[] := ARRAY[
        'mb13_p3_recovery_audit_audit_id_seq'
    ];
    v_functions TEXT[] := ARRAY[
        'mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_authorization_append_only()',
        'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_evidence_immutable()',
        'mb13_p3_action_pack_governed_mutation()',
        'mb13_p3_action_pack_monitor_policy_hash()',
        'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)',
        'mb13_p3_action_pack_result_evidence_guard()',
        'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)',
        'mb13_p3_action_pack_result_immutable()',
        'mb13_p3_action_pack_revision_immutable()',
        'mb13_p3_action_pack_terminal_attempt_sync()',
        'mb13_p3_action_pack_timeline_immutable()',
        'mb13_p3_action_pack_transition_guard()',
        'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'mb13_p3_cancel_action_pack(uuid,uuid)',
        'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)',
        'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_expire_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack_attempts(uuid,uuid)',
        'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)',
        'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)',
        'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)',
        'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)',
        'mb13_p3_list_action_packs(uuid,text,integer,integer)',
        'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'mb13_p3_recovery_audit_immutable()',
        'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'mb13_p3_revoke_action_pack(uuid,uuid)',
        'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)',
        'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)',
        'mb13_p3_validate_result_evidence(jsonb)',
        'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)',
        'mb13_p3_validate_steps(uuid,jsonb)',
        'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'
    ];
    v_legacy_roles TEXT[] := ARRAY['mb13_p3_pack_mutator', 'mb13_p3_pack_lifecycle_owner'];
    t TEXT;
    s TEXT;
    sig TEXT;
    lr TEXT;
BEGIN
    FOREACH lr IN ARRAY v_legacy_roles LOOP
        FOREACH t IN ARRAY v_tables LOOP
            EXECUTE format('REVOKE ALL PRIVILEGES ON TABLE public.%I FROM %I', t, lr);
        END LOOP;
        FOREACH s IN ARRAY v_sequences LOOP
            EXECUTE format('REVOKE ALL PRIVILEGES ON SEQUENCE public.%I FROM %I', s, lr);
        END LOOP;
        FOREACH sig IN ARRAY v_functions LOOP
            EXECUTE format('REVOKE ALL ON FUNCTION %s FROM %I', sig, lr);
        END LOOP;
    END LOOP;
END $$;

ALTER ROLE mb13_p3_pack_mutator NOLOGIN NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p3_pack_lifecycle_owner NOLOGIN NOINHERIT NOBYPASSRLS;

COMMIT;
