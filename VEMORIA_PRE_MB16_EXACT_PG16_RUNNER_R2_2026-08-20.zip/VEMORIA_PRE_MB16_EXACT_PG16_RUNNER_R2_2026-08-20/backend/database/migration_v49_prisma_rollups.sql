-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V49 — Prisma Daily Rollups
-- Aggregazioni giornaliere separate per Control Room Prisma

CREATE TABLE IF NOT EXISTS prisma_daily_rollups (
    rollup_id                UUID PRIMARY KEY,
    bucket_date              DATE NOT NULL,
    scope                    TEXT NOT NULL,
    key1                     TEXT NOT NULL DEFAULT '',
    key2                     TEXT NOT NULL DEFAULT '',
    event_count              INTEGER NOT NULL DEFAULT 0,
    session_count            INTEGER NOT NULL DEFAULT 0,
    success_count            INTEGER NOT NULL DEFAULT 0,
    abandon_count            INTEGER NOT NULL DEFAULT 0,
    failure_count            INTEGER NOT NULL DEFAULT 0,
    avg_duration_ms          DOUBLE PRECISION NULL,
    payload_json             JSONB NULL,
    created_at               TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at               TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_prisma_daily_rollups_unique
    ON prisma_daily_rollups (bucket_date, scope, key1, key2);

CREATE INDEX IF NOT EXISTS idx_prisma_daily_rollups_scope_date
    ON prisma_daily_rollups (scope, bucket_date DESC);

CREATE INDEX IF NOT EXISTS idx_prisma_daily_rollups_key1_date
    ON prisma_daily_rollups (key1, bucket_date DESC);
