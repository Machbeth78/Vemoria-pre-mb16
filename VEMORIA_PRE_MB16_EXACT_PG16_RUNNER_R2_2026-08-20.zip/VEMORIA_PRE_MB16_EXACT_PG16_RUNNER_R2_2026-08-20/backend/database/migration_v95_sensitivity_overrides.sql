-- VEMORA — Migration V95 (V71 Cervello Unico + Dati Sensibili)
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
--
-- Additiva opzionale. Aggiunge override espliciti di sensibilità
-- al documento. Senza questa migration, services/sensitivity_service.py
-- continua a funzionare (classify_document legge via try/except silenzioso
-- e fallisce graceful se le colonne non esistono).
--
-- APPLICABILE IN QUALSIASI MOMENTO: non è breaking, non blocca deploy.
-- Le colonne sono nullable; il comportamento di default resta basato
-- sul tipi_documento.nome dal catalogo Sapere.
--
-- Semantica dei valori consentiti:
--   sensitivity_level_override ∈ {'standard','delicate','highly_sensitive', NULL}
--   sharing_scope_override     ∈ {'owner_only','workspace','confirmed_trust','wide', NULL}
--
-- I CHECK constraint sono volutamente permissivi (NULL ammesso) così
-- l'UPDATE per toglierli richiede solo un SET NULL.

BEGIN;

ALTER TABLE documenti
    ADD COLUMN IF NOT EXISTS sensitivity_level_override TEXT,
    ADD COLUMN IF NOT EXISTS sharing_scope_override TEXT;

-- Enforcement dei valori ammessi (NULL esclusi — sempre ok)
ALTER TABLE documenti
    DROP CONSTRAINT IF EXISTS chk_documenti_sensitivity_level_override,
    ADD  CONSTRAINT chk_documenti_sensitivity_level_override
         CHECK (sensitivity_level_override IS NULL
                OR sensitivity_level_override IN ('standard','delicate','highly_sensitive'));

ALTER TABLE documenti
    DROP CONSTRAINT IF EXISTS chk_documenti_sharing_scope_override,
    ADD  CONSTRAINT chk_documenti_sharing_scope_override
         CHECK (sharing_scope_override IS NULL
                OR sharing_scope_override IN ('owner_only','workspace','confirmed_trust','wide'));

-- Indice parziale solo dove l'override è valorizzato:
-- velocizza query che cercano documenti marcati esplicitamente sensibili.
CREATE INDEX IF NOT EXISTS idx_documenti_sensitivity_override
    ON documenti(sensitivity_level_override)
    WHERE sensitivity_level_override IS NOT NULL;

COMMIT;
