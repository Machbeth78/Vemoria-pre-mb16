-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- MB13-P0 R1 — Universal Monitoring Ledger and Temporal Target Foundation.
-- No auto-action, no auto-notification, no reminder, no diff engine, no Action Pack.

BEGIN;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p0_app') THEN
        CREATE ROLE mb13_p0_app NOLOGIN;
    END IF;
END
$$;

CREATE TABLE IF NOT EXISTS public.mb13_p0_monitor_target (
    owner_user_id      UUID NOT NULL,
    monitor_id         UUID NOT NULL,
    stable_id          TEXT NOT NULL,
    title              TEXT NOT NULL,
    target_type        TEXT NOT NULL,
    target_ref         JSONB NOT NULL,
    target_revision    INTEGER NOT NULL,
    target_payload_hash TEXT NOT NULL,
    monitor_reason     TEXT NOT NULL,
    monitor_state      TEXT NOT NULL,
    monitor_policy     JSONB NOT NULL,
    consent_refs       JSONB NOT NULL DEFAULT '[]'::jsonb,
    source_refs        JSONB NOT NULL DEFAULT '[]'::jsonb,
    evidence_refs      JSONB NOT NULL DEFAULT '[]'::jsonb,
    baseline_ref       JSONB NOT NULL,
    current_revision   INTEGER NOT NULL DEFAULT 1,
    payload_hash       TEXT NOT NULL,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, monitor_id),
    UNIQUE (owner_user_id, stable_id),
    CONSTRAINT ck_mb13_p0_stable_id_nonempty CHECK (length(trim(stable_id)) > 0),
    CONSTRAINT ck_mb13_p0_title_nonempty CHECK (length(trim(title)) > 0),
    CONSTRAINT ck_mb13_p0_monitor_state CHECK (monitor_state IN ('draft','active','paused','blocked','revoked','completed')),
    CONSTRAINT ck_mb13_p0_target_type CHECK (target_type IN ('document','contract','offer','rule','source','dossier','identity','object','decision','generic_entity')),
    CONSTRAINT ck_mb13_p0_revision_positive CHECK (current_revision >= 1),
    CONSTRAINT ck_mb13_p0_target_ref_object CHECK (jsonb_typeof(target_ref) = 'object'),
    CONSTRAINT ck_mb13_p0_policy_object CHECK (jsonb_typeof(monitor_policy) = 'object'),
    CONSTRAINT ck_mb13_p0_baseline_object CHECK (jsonb_typeof(baseline_ref) = 'object'),
    CONSTRAINT ck_mb13_p0_refs_array CHECK (jsonb_typeof(consent_refs) = 'array' AND jsonb_typeof(source_refs) = 'array' AND jsonb_typeof(evidence_refs) = 'array')
);

CREATE TABLE IF NOT EXISTS public.mb13_p0_monitor_target_revision (
    owner_user_id      UUID NOT NULL,
    monitor_id         UUID NOT NULL,
    revision           INTEGER NOT NULL,
    monitor_state      TEXT NOT NULL,
    payload_hash       TEXT NOT NULL,
    target_ref         JSONB NOT NULL,
    target_revision    INTEGER NOT NULL,
    target_payload_hash TEXT NOT NULL,
    monitor_reason     TEXT NOT NULL,
    monitor_policy     JSONB NOT NULL,
    consent_refs       JSONB NOT NULL DEFAULT '[]'::jsonb,
    source_refs        JSONB NOT NULL DEFAULT '[]'::jsonb,
    evidence_refs      JSONB NOT NULL DEFAULT '[]'::jsonb,
    baseline_ref       JSONB NOT NULL,
    request_payload    JSONB NOT NULL,
    result_payload     JSONB NOT NULL,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, monitor_id, revision),
    CONSTRAINT fk_mb13_p0_revision_target
        FOREIGN KEY (owner_user_id, monitor_id)
        REFERENCES public.mb13_p0_monitor_target(owner_user_id, monitor_id)
        ON DELETE RESTRICT,
    CONSTRAINT ck_mb13_p0_rev_state CHECK (monitor_state IN ('draft','active','paused','blocked','revoked','completed')),
    CONSTRAINT ck_mb13_p0_rev_revision_positive CHECK (revision >= 1)
);

CREATE TABLE IF NOT EXISTS public.mb13_p0_monitor_event_ledger (
    event_id           UUID NOT NULL,
    owner_user_id      UUID NOT NULL,
    monitor_id         UUID NOT NULL,
    monitor_revision   INTEGER NOT NULL,
    event_type         TEXT NOT NULL,
    event_status       TEXT NOT NULL,
    event_time         TIMESTAMPTZ NOT NULL,
    observed_ref       JSONB NOT NULL DEFAULT '{}'::jsonb,
    source_refs        JSONB NOT NULL DEFAULT '[]'::jsonb,
    evidence_refs      JSONB NOT NULL DEFAULT '[]'::jsonb,
    consent_refs       JSONB NOT NULL DEFAULT '[]'::jsonb,
    reason             TEXT,
    result_payload     JSONB NOT NULL DEFAULT '{}'::jsonb,
    payload_hash       TEXT NOT NULL,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, event_id),
    CONSTRAINT ck_mb13_p0_event_type CHECK (event_type IN ('MONITOR_CREATED','MONITOR_ACTIVATED','MONITOR_PAUSED','MONITOR_RESUMED','MONITOR_BLOCKED','MONITOR_REVOKED','CHECK_DUE','CHECK_STARTED','CHECK_COMPLETED','CHECK_FAILED','NO_CHANGE_RECORDED','CHANGE_CANDIDATE_RECORDED')),
    CONSTRAINT ck_mb13_p0_event_status CHECK (event_status IN ('pending','recorded','superseded','failed')),
    CONSTRAINT ck_mb13_p0_event_refs_array CHECK (jsonb_typeof(source_refs) = 'array' AND jsonb_typeof(evidence_refs) = 'array' AND jsonb_typeof(consent_refs) = 'array'),
    CONSTRAINT ck_mb13_p0_event_observed_object CHECK (jsonb_typeof(observed_ref) = 'object'),
    CONSTRAINT ck_mb13_p0_event_result_object CHECK (jsonb_typeof(result_payload) = 'object')
);

CREATE INDEX IF NOT EXISTS ix_mb13_p0_target_owner_state
    ON public.mb13_p0_monitor_target(owner_user_id, monitor_state, updated_at DESC);
CREATE INDEX IF NOT EXISTS ix_mb13_p0_revision_owner_target
    ON public.mb13_p0_monitor_target_revision(owner_user_id, monitor_id, revision DESC);
CREATE INDEX IF NOT EXISTS ix_mb13_p0_event_owner_monitor
    ON public.mb13_p0_monitor_event_ledger(owner_user_id, monitor_id, monitor_revision, created_at DESC);

ALTER TABLE public.mb13_p0_monitor_target ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p0_monitor_target FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p0_monitor_target_revision ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p0_monitor_target_revision FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p0_monitor_event_ledger ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p0_monitor_event_ledger FORCE ROW LEVEL SECURITY;

DO $$
DECLARE
    table_name TEXT;
BEGIN
    FOREACH table_name IN ARRAY ARRAY[
        'mb13_p0_monitor_target',
        'mb13_p0_monitor_target_revision',
        'mb13_p0_monitor_event_ledger'
    ] LOOP
        EXECUTE format('DROP POLICY IF EXISTS mb13_p0_owner_isolation ON public.%I', table_name);
        EXECUTE format(
            'CREATE POLICY mb13_p0_owner_isolation ON public.%I '
            'USING (owner_user_id = NULLIF(current_setting(''app.owner_id'', true), '''')::uuid) '
            'WITH CHECK (owner_user_id = NULLIF(current_setting(''app.owner_id'', true), '''')::uuid)',
            table_name
        );
    END LOOP;
END
$$;

CREATE OR REPLACE FUNCTION public.mb13_p0_history_immutable()
RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb13_p0_history_is_append_only';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_history_immutable() FROM PUBLIC;

DROP TRIGGER IF EXISTS trg_mb13_p0_revision_immutable ON public.mb13_p0_monitor_target_revision;
CREATE TRIGGER trg_mb13_p0_revision_immutable
BEFORE UPDATE OR DELETE ON public.mb13_p0_monitor_target_revision
FOR EACH ROW EXECUTE FUNCTION public.mb13_p0_history_immutable();

DROP TRIGGER IF EXISTS trg_mb13_p0_event_immutable ON public.mb13_p0_monitor_event_ledger;
CREATE TRIGGER trg_mb13_p0_event_immutable
BEFORE UPDATE OR DELETE ON public.mb13_p0_monitor_event_ledger
FOR EACH ROW EXECUTE FUNCTION public.mb13_p0_history_immutable();

CREATE OR REPLACE FUNCTION public.mb13_p0_write_monitor(
    p_monitor_id UUID,
    p_stable_id TEXT,
    p_title TEXT,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_target_revision INTEGER,
    p_target_payload_hash TEXT,
    p_monitor_reason TEXT,
    p_monitor_state TEXT,
    p_monitor_policy JSONB,
    p_consent_refs JSONB,
    p_source_refs JSONB,
    p_evidence_refs JSONB,
    p_baseline_ref JSONB,
    p_request_payload JSONB,
    p_result_payload JSONB
) RETURNS TABLE(monitor_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_revision INTEGER;
    v_payload_hash TEXT;
    v_required_target_keys TEXT[] := ARRAY['id','revision','payload_hash','owner_user_id','state'];
    k TEXT;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_authenticated_owner_missing';
    END IF;
    IF p_monitor_id IS NULL
       OR length(trim(COALESCE(p_stable_id, ''))) = 0 OR length(p_stable_id) > 200
       OR length(trim(COALESCE(p_title, ''))) = 0 OR length(p_title) > 300 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_identity_invalid';
    END IF;
    IF p_target_type NOT IN ('document','contract','offer','rule','source','dossier','identity','object','decision','generic_entity') THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_target_type_invalid';
    END IF;
    IF p_monitor_state NOT IN ('draft','active','paused','blocked','revoked','completed') THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_monitor_state_invalid';
    END IF;
    IF jsonb_typeof(p_target_ref) <> 'object' THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_target_ref_invalid';
    END IF;
    FOREACH k IN ARRAY v_required_target_keys LOOP
        IF p_target_ref->>k IS NULL THEN
            RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_target_ref_missing:' || k;
        END IF;
    END LOOP;
    IF p_target_ref->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb13_p0_target_owner_mismatch';
    END IF;
    IF p_monitor_policy->>'timezone' IS NULL OR length(trim(p_monitor_policy->>'timezone')) = 0 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_policy_timezone_required';
    END IF;
    IF p_monitor_state = 'active' AND (p_monitor_policy->>'valid_from' IS NULL OR p_monitor_policy->>'next_check_at' IS NULL) THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb13_p0_active_requires_temporal_policy';
    END IF;
    IF jsonb_typeof(p_consent_refs) <> 'array' OR jsonb_typeof(p_source_refs) <> 'array' OR jsonb_typeof(p_evidence_refs) <> 'array' THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_refs_must_be_arrays';
    END IF;
    IF jsonb_typeof(p_baseline_ref) <> 'object' OR jsonb_typeof(p_request_payload) <> 'object' OR jsonb_typeof(p_result_payload) <> 'object' THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_payload_shape_invalid';
    END IF;

    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_stable_id, 0));

    v_payload_hash := encode(
        digest(convert_to((p_request_payload || jsonb_build_object('result', p_result_payload))::text, 'UTF8'), 'sha256'),
        'hex'
    );

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = v_owner
       AND t.stable_id = p_stable_id
     FOR UPDATE;

    IF FOUND THEN
        IF v_current.payload_hash = v_payload_hash AND v_current.monitor_state = p_monitor_state THEN
            RETURN QUERY SELECT v_current.monitor_id, v_current.current_revision, v_current.payload_hash;
            RETURN;
        END IF;
        IF v_current.monitor_state = 'revoked' AND p_monitor_state <> 'revoked' THEN
            RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb13_p0_revoked_monitor_cannot_reactivate';
        END IF;
        p_monitor_id := v_current.monitor_id;
        v_revision := v_current.current_revision + 1;
    ELSE
        v_revision := 1;
        INSERT INTO public.mb13_p0_monitor_target (
            owner_user_id, monitor_id, stable_id, title, target_type,
            target_ref, target_revision, target_payload_hash,
            monitor_reason, monitor_state, monitor_policy,
            consent_refs, source_refs, evidence_refs, baseline_ref,
            current_revision, payload_hash
        ) VALUES (
            v_owner, p_monitor_id, p_stable_id, p_title, p_target_type,
            p_target_ref, p_target_revision, p_target_payload_hash,
            p_monitor_reason, p_monitor_state, p_monitor_policy,
            p_consent_refs, p_source_refs, p_evidence_refs, p_baseline_ref,
            v_revision, v_payload_hash
        );
    END IF;

    INSERT INTO public.mb13_p0_monitor_target_revision (
        owner_user_id, monitor_id, revision, monitor_state, payload_hash,
        target_ref, target_revision, target_payload_hash,
        monitor_reason, monitor_policy, consent_refs, source_refs, evidence_refs, baseline_ref,
        request_payload, result_payload
    ) VALUES (
        v_owner, p_monitor_id, v_revision, p_monitor_state, v_payload_hash,
        p_target_ref, p_target_revision, p_target_payload_hash,
        p_monitor_reason, p_monitor_policy, p_consent_refs, p_source_refs, p_evidence_refs, p_baseline_ref,
        p_request_payload, p_result_payload
    );

    UPDATE public.mb13_p0_monitor_target AS t
       SET title = p_title,
           target_ref = p_target_ref,
           target_revision = p_target_revision,
           target_payload_hash = p_target_payload_hash,
           monitor_reason = p_monitor_reason,
           monitor_state = p_monitor_state,
           monitor_policy = p_monitor_policy,
           consent_refs = p_consent_refs,
           source_refs = p_source_refs,
           evidence_refs = p_evidence_refs,
           baseline_ref = p_baseline_ref,
           current_revision = v_revision,
           payload_hash = v_payload_hash,
           updated_at = NOW()
     WHERE t.owner_user_id = v_owner
       AND t.monitor_id = p_monitor_id;

    RETURN QUERY SELECT p_monitor_id, v_revision, v_payload_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION public.mb13_p0_revoke_monitor(
    p_monitor_id UUID,
    p_reason TEXT
) RETURNS TABLE(monitor_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_previous public.mb13_p0_monitor_target_revision%ROWTYPE;
    v_revision INTEGER;
    v_result JSONB;
    v_hash TEXT;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_authenticated_owner_missing';
    END IF;
    IF p_monitor_id IS NULL OR length(trim(COALESCE(p_reason, ''))) = 0 OR length(p_reason) > 500 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_revocation_invalid';
    END IF;

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = v_owner
       AND t.monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = 'P0002', MESSAGE = 'mb13_p0_monitor_not_found';
    END IF;
    IF v_current.monitor_state = 'revoked' THEN
        RETURN QUERY SELECT v_current.monitor_id, v_current.current_revision, v_current.payload_hash;
        RETURN;
    END IF;

    SELECT * INTO v_previous
      FROM public.mb13_p0_monitor_target_revision r
     WHERE r.owner_user_id = v_owner
       AND r.monitor_id = p_monitor_id
       AND r.revision = v_current.current_revision;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb13_p0_current_revision_missing';
    END IF;

    v_revision := v_current.current_revision + 1;
    v_result := v_previous.result_payload || jsonb_build_object(
        'state', 'revoked',
        'revocation_reason', trim(p_reason),
        'revoked_from_revision', v_current.current_revision
    );
    v_hash := encode(
        digest(convert_to((v_previous.request_payload || jsonb_build_object('result', v_result))::text, 'UTF8'), 'sha256'),
        'hex'
    );

    INSERT INTO public.mb13_p0_monitor_target_revision (
        owner_user_id, monitor_id, revision, monitor_state, payload_hash,
        target_ref, target_revision, target_payload_hash,
        monitor_reason, monitor_policy, consent_refs, source_refs, evidence_refs, baseline_ref,
        request_payload, result_payload
    ) VALUES (
        v_owner, p_monitor_id, v_revision, 'revoked', v_hash,
        v_previous.target_ref, v_previous.target_revision, v_previous.target_payload_hash,
        v_previous.monitor_reason, v_previous.monitor_policy,
        v_previous.consent_refs, v_previous.source_refs, v_previous.evidence_refs, v_previous.baseline_ref,
        v_previous.request_payload, v_result
    );

    UPDATE public.mb13_p0_monitor_target AS t
       SET monitor_state = 'revoked',
           current_revision = v_revision,
           payload_hash = v_hash,
           updated_at = NOW()
     WHERE t.owner_user_id = v_owner
       AND t.monitor_id = p_monitor_id;

    RETURN QUERY SELECT p_monitor_id, v_revision, v_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION public.mb13_p0_record_monitor_event(
    p_event_id UUID,
    p_monitor_id UUID,
    p_monitor_revision INTEGER,
    p_event_type TEXT,
    p_event_status TEXT,
    p_event_time TIMESTAMPTZ,
    p_observed_ref JSONB,
    p_source_refs JSONB,
    p_evidence_refs JSONB,
    p_consent_refs JSONB,
    p_reason TEXT,
    p_result_payload JSONB
) RETURNS TABLE(event_id UUID, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_payload_hash TEXT;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_authenticated_owner_missing';
    END IF;
    IF p_event_id IS NULL OR p_monitor_id IS NULL OR p_monitor_revision IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_event_identity_invalid';
    END IF;
    IF p_event_type NOT IN ('MONITOR_CREATED','MONITOR_ACTIVATED','MONITOR_PAUSED','MONITOR_RESUMED','MONITOR_BLOCKED','MONITOR_REVOKED','CHECK_DUE','CHECK_STARTED','CHECK_COMPLETED','CHECK_FAILED','NO_CHANGE_RECORDED','CHANGE_CANDIDATE_RECORDED') THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_event_type_invalid';
    END IF;
    IF p_event_status NOT IN ('pending','recorded','superseded','failed') THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_event_status_invalid';
    END IF;
    IF p_event_time IS NULL THEN
        p_event_time := NOW();
    END IF;
    IF p_reason IS NOT NULL AND length(p_reason) > 500 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb13_p0_event_reason_invalid';
    END IF;

    v_payload_hash := encode(
        digest(convert_to(jsonb_build_object(
            'monitor_id', p_monitor_id,
            'monitor_revision', p_monitor_revision,
            'event_type', p_event_type,
            'event_status', p_event_status,
            'event_time', p_event_time,
            'observed_ref', p_observed_ref,
            'result_payload', p_result_payload
        )::text, 'UTF8'), 'sha256'),
        'hex'
    );

    INSERT INTO public.mb13_p0_monitor_event_ledger (
        event_id, owner_user_id, monitor_id, monitor_revision, event_type, event_status, event_time,
        observed_ref, source_refs, evidence_refs, consent_refs, reason, result_payload, payload_hash
    ) VALUES (
        p_event_id, v_owner, p_monitor_id, p_monitor_revision, p_event_type, p_event_status, p_event_time,
        p_observed_ref, p_source_refs, p_evidence_refs, p_consent_refs, p_reason, p_result_payload, v_payload_hash
    );

    RETURN QUERY SELECT p_event_id, v_payload_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_write_monitor(UUID,TEXT,TEXT,TEXT,JSONB,INTEGER,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p0_revoke_monitor(UUID,TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p0_record_monitor_event(UUID,UUID,INTEGER,TEXT,TEXT,TIMESTAMPTZ,JSONB,JSONB,JSONB,JSONB,TEXT,JSONB) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.mb13_p0_write_monitor(UUID,TEXT,TEXT,TEXT,JSONB,INTEGER,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB,JSONB) TO mb13_p0_app;
GRANT EXECUTE ON FUNCTION public.mb13_p0_revoke_monitor(UUID,TEXT) TO mb13_p0_app;
GRANT EXECUTE ON FUNCTION public.mb13_p0_record_monitor_event(UUID,UUID,INTEGER,TEXT,TEXT,TIMESTAMPTZ,JSONB,JSONB,JSONB,JSONB,TEXT,JSONB) TO mb13_p0_app;

REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER
    ON public.mb13_p0_monitor_target,
       public.mb13_p0_monitor_target_revision,
       public.mb13_p0_monitor_event_ledger
    FROM PUBLIC, mb13_p0_app;
GRANT SELECT
    ON public.mb13_p0_monitor_target,
       public.mb13_p0_monitor_target_revision,
       public.mb13_p0_monitor_event_ledger
    TO mb13_p0_app;

COMMIT;
