-- VEMORIA — MB3→MB4 completion: RLS e granularità sul consenso Internet.
-- Migration incrementale rispetto a v229; non altera in modo distruttivo
-- i dati già presenti.

-- ---------------------------------------------------------------------------
-- 1. Azioni granulari (mantiene la colonna allowed per retrocompatibilità)
-- ---------------------------------------------------------------------------
ALTER TABLE internet_consent
    ADD COLUMN IF NOT EXISTS granted_actions JSONB NOT NULL DEFAULT '{}';

COMMENT ON COLUMN internet_consent.granted_actions IS
    'Mappa azione -> boolean che rappresenta il consenso granulare a Internet (es. internet_search). Se allowed=TRUE e granted_actions è vuoto, tutte le azioni sono consentite per retrocompatibilità.';

-- ---------------------------------------------------------------------------
-- 2. Row Level Security owner-scoped
-- ---------------------------------------------------------------------------
ALTER TABLE internet_consent ENABLE ROW LEVEL SECURITY;
ALTER TABLE internet_consent FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS internet_consent_owner_isolation ON internet_consent;

CREATE POLICY internet_consent_owner_isolation ON internet_consent
    FOR ALL
    USING (owner_user_id::text = current_setting('app.owner_id', true))
    WITH CHECK (owner_user_id::text = current_setting('app.owner_id', true));

COMMENT ON POLICY internet_consent_owner_isolation ON internet_consent IS
    'Isolamento owner: il ruolo applicativo vede e modifica solo il consenso del proprietario attivo nel GUC app.owner_id.';

-- ---------------------------------------------------------------------------
-- 3. Permessi minimi per i ruoli applicativi (solo se esistono)
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'test_app') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON internet_consent TO test_app;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p1_api') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON internet_consent TO mb13_p1_api;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p1_worker') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON internet_consent TO mb13_p1_worker;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'vemora_user') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON internet_consent TO vemora_user;
    END IF;
END $$;

-- ---------------------------------------------------------------------------
-- 4. Indice per lookup owner-scoped
-- ---------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_internet_consent_owner_allowed
    ON internet_consent(owner_user_id, allowed);
