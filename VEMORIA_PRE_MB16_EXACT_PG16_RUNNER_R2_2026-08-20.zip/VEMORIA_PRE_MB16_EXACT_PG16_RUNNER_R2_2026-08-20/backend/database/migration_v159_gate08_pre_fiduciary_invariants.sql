-- Gate08-PRE — Fiduciary invariants / Owner-Agent foundation
-- Static governance only. Does not claim runtime, live web, billing, ranking or Cerebro execution.

CREATE TABLE IF NOT EXISTS fiduciary_invariant_registry (
    invariant_code TEXT PRIMARY KEY,
    severity TEXT NOT NULL CHECK (severity IN ('BLOCKER','HIGH','MEDIUM','LOW')),
    owner_agent_required BOOLEAN NOT NULL DEFAULT TRUE,
    ad_channel_allowed BOOLEAN NOT NULL DEFAULT FALSE,
    paid_ranking_allowed BOOLEAN NOT NULL DEFAULT FALSE,
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE,
    meaning TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (owner_agent_required IS TRUE),
    CHECK (ad_channel_allowed IS FALSE),
    CHECK (paid_ranking_allowed IS FALSE),
    CHECK (runtime_pass_claimed IS FALSE)
);

CREATE TABLE IF NOT EXISTS fiduciary_source_origin_policy (
    origin_code TEXT PRIMARY KEY,
    must_be_declared BOOLEAN NOT NULL DEFAULT TRUE,
    can_support_final_recommendation BOOLEAN NOT NULL DEFAULT FALSE,
    requires_official_verification BOOLEAN NOT NULL DEFAULT FALSE,
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE,
    description TEXT NOT NULL,
    CHECK (must_be_declared IS TRUE),
    CHECK (runtime_pass_claimed IS FALSE)
);

INSERT INTO fiduciary_invariant_registry (invariant_code, severity, meaning) VALUES
('VEMORIA_IS_OWNER_AGENT_NOT_AD_CHANNEL','BLOCKER','Vemoria serve il proprietario e non è canale pubblicitario.'),
('NO_PAID_RANKING_IN_CONSUMER_ADVICE','BLOCKER','Pagamento terzo non può alterare ranking/consiglio consumer.'),
('BUSINESS_CAN_PAY_FOR_OWN_PROFILE_NOT_FOR_RECOMMENDATION_BIAS','BLOCKER','Business può pagare servizi propri, non bias di raccomandazione.'),
('RECOMMENDATIONS_MUST_OPTIMIZE_OWNER_INTEREST','BLOCKER','Raccomandazioni ottimizzano interesse del proprietario.'),
('NO_ANSWER_WHEN_OFFER_COMPARISON_IS_NOT_RELIABLE','BLOCKER','Se confronto non è affidabile, nessun vincitore.'),
('ANSWER_MUST_CARRY_SOURCE_CHAIN','BLOCKER','Ogni risposta operativa porta catena fonte.'),
('SOURCE_PROVENANCE_MUST_BE_EXPLICIT','BLOCKER','La provenienza è obbligatoria.'),
('PUBLIC_SOURCE_MUST_BE_OFFICIAL_OR_QUARANTINED','BLOCKER','Fonte pubblica deve essere ufficiale/qualificata o quarantinata.'),
('NO_RECOMMENDATION_WITHOUT_COMPARABILITY','BLOCKER','Nessun consiglio definitivo senza comparabilità.'),
('CEREBRO_MUST_INHERIT_FIDUCIARY_GUARDS','BLOCKER','Cerebro eredita guardie fiduciarie prima di orchestrare.')
ON CONFLICT (invariant_code) DO UPDATE SET severity=EXCLUDED.severity, meaning=EXCLUDED.meaning;

INSERT INTO fiduciary_source_origin_policy (origin_code, can_support_final_recommendation, requires_official_verification, description) VALUES
('MIA_MEMORIA', TRUE, FALSE, 'Memoria locale/personale owner-scoped.'),
('RELAZIONE_GRUPPO', TRUE, FALSE, 'Relazione o gruppo autorizzato, con confini privacy.'),
('DOCUMENTO_UTENTE', TRUE, FALSE, 'Documento fornito/scansionato dall’utente.'),
('FONTE_PUBBLICA_UFFICIALE', TRUE, TRUE, 'Fonte ufficiale o qualificata verificata.'),
('FONTE_QUARANTENATA', FALSE, TRUE, 'Fonte non verificata o sospetta: non supporta raccomandazione definitiva.')
ON CONFLICT (origin_code) DO UPDATE SET
    can_support_final_recommendation=EXCLUDED.can_support_final_recommendation,
    requires_official_verification=EXCLUDED.requires_official_verification,
    description=EXCLUDED.description;
