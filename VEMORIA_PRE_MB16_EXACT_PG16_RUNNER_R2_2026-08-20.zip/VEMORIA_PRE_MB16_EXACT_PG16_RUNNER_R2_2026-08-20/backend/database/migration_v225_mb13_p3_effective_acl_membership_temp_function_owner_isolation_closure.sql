-- migration_v225_mb13_p3_effective_acl_membership_temp_function_owner_isolation_closure.sql
-- MB13-P3 v225: effective ACL closure, membership graph isolation, temporary function cleanup,
-- full ownership inventory and final-state audit.
-- v224 is rejected; this migration closes the residual gaps.
-- Do not reopen MB13-P1/MB13-P2, do not open R3, do not produce APK/AAB.
BEGIN;

-- ============================================================================
-- 0. Drop any residual temporary migration functions created by rejected v224
-- ============================================================================
DROP FUNCTION IF EXISTS public.migration_v224_reason_specific_recovery();
DO $$
DECLARE r RECORD;
BEGIN
    FOR r IN
        SELECT p.proname
          FROM pg_proc p
          JOIN pg_namespace n ON p.pronamespace = n.oid
         WHERE n.nspname = 'public'
           AND p.proname LIKE 'migration_v22x_%'
    LOOP
        EXECUTE format('DROP FUNCTION IF EXISTS public.%I()', r.proname);
    END LOOP;
END $$;

-- ============================================================================
-- 1. Role definitions and inertization
-- ============================================================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p3_pack_data_owner') THEN
        CREATE ROLE mb13_p3_pack_data_owner NOLOGIN NOINHERIT NOBYPASSRLS;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p3_pack_lifecycle_executor') THEN
        CREATE ROLE mb13_p3_pack_lifecycle_executor NOLOGIN NOINHERIT NOBYPASSRLS;
    END IF;
END $$;

ALTER ROLE mb13_p3_pack_data_owner NOLOGIN NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p3_pack_lifecycle_executor NOLOGIN NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p3_pack_mutator NOLOGIN NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p3_pack_lifecycle_owner NOLOGIN NOINHERIT NOBYPASSRLS;

-- ============================================================================
-- 2. Exact canonical object allowlist and structural trigger verification
-- ============================================================================
DO $$
DECLARE
    v_allowed_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    v_allowed_sequences TEXT[] := ARRAY[
        'mb13_p3_recovery_audit_audit_id_seq'
    ];
    v_allowed_functions TEXT[] := ARRAY[
        'mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_authorization_append_only()',
        'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_evidence_immutable()',
        'mb13_p3_action_pack_governed_mutation()',
        'mb13_p3_action_pack_monitor_policy_hash()',
        'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)',
        'mb13_p3_action_pack_result_evidence_guard()',
        'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)',
        'mb13_p3_action_pack_result_immutable()',
        'mb13_p3_action_pack_revision_immutable()',
        'mb13_p3_action_pack_terminal_attempt_sync()',
        'mb13_p3_action_pack_timeline_immutable()',
        'mb13_p3_action_pack_transition_guard()',
        'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'mb13_p3_cancel_action_pack(uuid,uuid)',
        'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)',
        'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_expire_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack_attempts(uuid,uuid)',
        'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)',
        'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)',
        'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)',
        'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)',
        'mb13_p3_list_action_packs(uuid,text,integer,integer)',
        'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'mb13_p3_recovery_audit_immutable()',
        'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'mb13_p3_revoke_action_pack(uuid,uuid)',
        'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)',
        'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)',
        'mb13_p3_validate_result_evidence(jsonb)',
        'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)',
        'mb13_p3_validate_steps(uuid,jsonb)',
        'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'
    ];
    v_allowed_roles TEXT[] := ARRAY[
        'mb13_p3_api',
        'mb13_p3_executor',
        'mb13_p3_pack_data_owner',
        'mb13_p3_pack_lifecycle_executor',
        'mb13_p3_pack_lifecycle_owner',
        'mb13_p3_pack_mutator',
        'mb13_p3_validator',
        'mb13_p3_writer',
        'test_app'
    ];
    v_allowed_policies TEXT[] := ARRAY[
        'mb13_p3_attempt_owner_isolation',
        'mb13_p3_auth_owner_isolation',
        'mb13_p3_evidence_owner_policy',
        'mb13_p3_pack_owner_isolation',
        'mb13_p3_recovery_audit_lifecycle',
        'mb13_p3_result_owner_isolation',
        'mb13_p3_rev_owner_isolation',
        'mb13_p3_timeline_owner_isolation'
    ];
    r RECORD; t TEXT; sig TEXT;
BEGIN
    -- Tables
    FOR r IN
        SELECT c.relname
          FROM pg_class c
          JOIN pg_namespace n ON c.relnamespace = n.oid
         WHERE n.nspname = 'public'
           AND c.relkind = 'r'
           AND c.relname LIKE 'mb13_p3_%'
           AND NOT (relname = ANY(v_allowed_tables))
    LOOP
        RAISE EXCEPTION 'migration_v225 unexpected table: %', r.relname;
    END LOOP;

    FOREACH t IN ARRAY v_allowed_tables LOOP
        IF to_regclass('public.' || t) IS NULL THEN
            RAISE EXCEPTION 'migration_v225 missing table: %', t;
        END IF;
    END LOOP;

    -- Sequences
    FOR r IN
        SELECT c.relname
          FROM pg_class c
          JOIN pg_namespace n ON c.relnamespace = n.oid
         WHERE n.nspname = 'public'
           AND c.relkind = 'S'
           AND c.relname LIKE 'mb13_p3_%'
           AND NOT (c.relname = ANY(v_allowed_sequences))
    LOOP
        RAISE EXCEPTION 'migration_v225 unexpected sequence: %', r.relname;
    END LOOP;

    FOREACH t IN ARRAY v_allowed_sequences LOOP
        IF to_regclass('public.' || t) IS NULL THEN
            RAISE EXCEPTION 'migration_v225 missing sequence: %', t;
        END IF;
    END LOOP;

    -- Functions
    FOR r IN
        SELECT p.proname || '(' || array_to_string(ARRAY(
                   SELECT format_type(oid, NULL) FROM unnest(p.proargtypes::oid[]) AS t(oid)
               ), ',') || ')' AS sig
          FROM pg_proc p
          JOIN pg_namespace n ON p.pronamespace = n.oid
         WHERE n.nspname = 'public'
           AND p.proname LIKE 'mb13_p3_%'
           AND NOT (p.proname LIKE 'migration_v22x_%')
    LOOP
        IF NOT (r.sig = ANY(v_allowed_functions)) THEN
            RAISE EXCEPTION 'migration_v225 unexpected function: %', r.sig;
        END IF;
    END LOOP;

    FOREACH sig IN ARRAY v_allowed_functions LOOP
        IF to_regprocedure(sig) IS NULL THEN
            RAISE EXCEPTION 'migration_v225 missing function: %', sig;
        END IF;
    END LOOP;

    -- Roles
    FOR r IN
        SELECT rolname FROM pg_roles
         WHERE (rolname LIKE 'mb13_p3_%' OR rolname = 'test_app')
           AND NOT (rolname = ANY(v_allowed_roles))
    LOOP
        RAISE EXCEPTION 'migration_v225 unexpected role: %', r.rolname;
    END LOOP;

    FOREACH t IN ARRAY v_allowed_roles LOOP
        IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = t) THEN
            RAISE EXCEPTION 'migration_v225 missing role: %', t;
        END IF;
    END LOOP;

    -- Policies
    FOR r IN
        SELECT p.polname
          FROM pg_policy p
          JOIN pg_class c ON p.polrelid = c.oid
          JOIN pg_namespace n ON c.relnamespace = n.oid
         WHERE n.nspname = 'public'
           AND c.relname LIKE 'mb13_p3_%'
           AND NOT (p.polname = ANY(v_allowed_policies))
    LOOP
        RAISE EXCEPTION 'migration_v225 unexpected policy: %', r.polname;
    END LOOP;

    -- Trigger structural allowlist
    CREATE TEMP TABLE IF NOT EXISTS v225_trigger_allowlist (
        relname text, tgname text, proname text, tgtype smallint, enabled text
    ) ON COMMIT DROP;
    TRUNCATE v225_trigger_allowlist;

    INSERT INTO v225_trigger_allowlist (relname, tgname, proname, tgtype, enabled) VALUES
        ('mb13_p3_action_pack', 'trg_mb13_p3_action_pack_governed_mutation', 'mb13_p3_action_pack_governed_mutation', 31::smallint, 'O'),
        ('mb13_p3_action_pack', 'trg_mb13_p3_action_pack_monitor_policy_hash', 'mb13_p3_action_pack_monitor_policy_hash', 23::smallint, 'O'),
        ('mb13_p3_action_pack', 'trg_mb13_p3_action_pack_terminal_attempt_sync', 'mb13_p3_action_pack_terminal_attempt_sync', 17::smallint, 'O'),
        ('mb13_p3_action_pack', 'trg_mb13_p3_action_pack_transition_guard', 'mb13_p3_action_pack_transition_guard', 23::smallint, 'O'),
        ('mb13_p3_action_pack_authorization', 'trg_mb13_p3_authorization_append_only', 'mb13_p3_action_pack_authorization_append_only', 27::smallint, 'O'),
        ('mb13_p3_action_pack_evidence', 'trg_mb13_p3_evidence_immutable', 'mb13_p3_action_pack_evidence_immutable', 27::smallint, 'O'),
        ('mb13_p3_action_pack_result', 'trg_mb13_p3_action_pack_result_evidence_guard', 'mb13_p3_action_pack_result_evidence_guard', 7::smallint, 'O'),
        ('mb13_p3_action_pack_result', 'trg_mb13_p3_result_immutable', 'mb13_p3_action_pack_result_immutable', 27::smallint, 'O'),
        ('mb13_p3_action_pack_revision', 'trg_mb13_p3_revision_immutable', 'mb13_p3_action_pack_revision_immutable', 27::smallint, 'O'),
        ('mb13_p3_action_pack_timeline', 'trg_mb13_p3_timeline_immutable', 'mb13_p3_action_pack_timeline_immutable', 31::smallint, 'O'),
        ('mb13_p3_recovery_audit', 'trg_mb13_p3_recovery_audit_immutable', 'mb13_p3_recovery_audit_immutable', 27::smallint, 'O');

    FOR r IN SELECT * FROM v225_trigger_allowlist LOOP
        PERFORM 1
          FROM pg_trigger t
          JOIN pg_class c ON t.tgrelid = c.oid
          JOIN pg_namespace n ON c.relnamespace = n.oid
          JOIN pg_proc p ON t.tgfoid = p.oid
         WHERE n.nspname = 'public'
           AND c.relname = r.relname
           AND t.tgname = r.tgname
           AND p.proname = r.proname
           AND t.tgtype = r.tgtype
           AND t.tgenabled = r.enabled;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'migration_v225 missing or malformed trigger % on %', r.tgname, r.relname;
        END IF;
    END LOOP;

    FOR r IN
        SELECT c.relname, t.tgname
          FROM pg_trigger t
          JOIN pg_class c ON t.tgrelid = c.oid
          JOIN pg_namespace n ON c.relnamespace = n.oid
         WHERE n.nspname = 'public'
           AND c.relname LIKE 'mb13_p3_%'
           AND NOT t.tgisinternal
    LOOP
        PERFORM 1 FROM v225_trigger_allowlist a
         WHERE a.relname = r.relname AND a.tgname = r.tgname;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'migration_v225 unexpected trigger % on table %', r.tgname, r.relname;
        END IF;
    END LOOP;
END $$;

-- ============================================================================
-- 3. Expanded ownership inventory and exact per-object transfer
-- ============================================================================
DO $$
DECLARE
    v_allowed_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    v_allowed_sequences TEXT[] := ARRAY[
        'mb13_p3_recovery_audit_audit_id_seq'
    ];
    v_allowed_functions TEXT[] := ARRAY[
        'mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_authorization_append_only()',
        'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_evidence_immutable()',
        'mb13_p3_action_pack_governed_mutation()',
        'mb13_p3_action_pack_monitor_policy_hash()',
        'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)',
        'mb13_p3_action_pack_result_evidence_guard()',
        'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)',
        'mb13_p3_action_pack_result_immutable()',
        'mb13_p3_action_pack_revision_immutable()',
        'mb13_p3_action_pack_terminal_attempt_sync()',
        'mb13_p3_action_pack_timeline_immutable()',
        'mb13_p3_action_pack_transition_guard()',
        'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'mb13_p3_cancel_action_pack(uuid,uuid)',
        'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)',
        'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_expire_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack_attempts(uuid,uuid)',
        'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)',
        'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)',
        'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)',
        'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)',
        'mb13_p3_list_action_packs(uuid,text,integer,integer)',
        'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'mb13_p3_recovery_audit_immutable()',
        'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'mb13_p3_revoke_action_pack(uuid,uuid)',
        'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)',
        'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)',
        'mb13_p3_validate_result_evidence(jsonb)',
        'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)',
        'mb13_p3_validate_steps(uuid,jsonb)',
        'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'
    ];
    v_legacy_roles TEXT[] := ARRAY['mb13_p3_pack_mutator', 'mb13_p3_pack_lifecycle_owner'];
    v_target_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    v_target_sequences TEXT[] := ARRAY[
        'mb13_p3_recovery_audit_audit_id_seq'
    ];
    v_target_functions TEXT[] := ARRAY[
        'mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_authorization_append_only()',
        'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_evidence_immutable()',
        'mb13_p3_action_pack_governed_mutation()',
        'mb13_p3_action_pack_monitor_policy_hash()',
        'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)',
        'mb13_p3_action_pack_result_evidence_guard()',
        'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)',
        'mb13_p3_action_pack_result_immutable()',
        'mb13_p3_action_pack_revision_immutable()',
        'mb13_p3_action_pack_terminal_attempt_sync()',
        'mb13_p3_action_pack_timeline_immutable()',
        'mb13_p3_action_pack_transition_guard()',
        'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'mb13_p3_cancel_action_pack(uuid,uuid)',
        'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)',
        'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_expire_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack_attempts(uuid,uuid)',
        'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)',
        'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)',
        'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)',
        'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)',
        'mb13_p3_list_action_packs(uuid,text,integer,integer)',
        'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'mb13_p3_recovery_audit_immutable()',
        'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'mb13_p3_revoke_action_pack(uuid,uuid)',
        'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)',
        'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)',
        'mb13_p3_validate_result_evidence(jsonb)',
        'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)',
        'mb13_p3_validate_steps(uuid,jsonb)',
        'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'
    ];
    v_validator_functions TEXT[] := ARRAY[
        'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)',
        'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)',
        'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'
    ];
    r RECORD;
    v_owner_role TEXT;
    v_fn_proname TEXT;
    v_fn_sig TEXT;
BEGIN
    -- Legacy roles: fail if they own any object outside the MB13-P3 allowlist,
    -- transfer exact allowlisted objects to the canonical owner.
    FOREACH v_owner_role IN ARRAY v_legacy_roles LOOP
        -- pg_class (tables, indexes, sequences, views, matviews, foreign tables, partitioned tables)
        FOR r IN
            SELECT c.relname, c.relkind, c.oid
              FROM pg_class c
              JOIN pg_namespace n ON c.relnamespace = n.oid
              JOIN pg_roles rl ON c.relowner = rl.oid
             WHERE rl.rolname = v_owner_role
               AND n.nspname NOT IN ('pg_catalog','pg_toast','information_schema')
        LOOP
            IF r.relkind = 'S' AND r.relname = ANY(v_allowed_sequences) THEN
                EXECUTE format('ALTER SEQUENCE public.%I OWNER TO mb13_p3_pack_data_owner', r.relname);
            ELSIF r.relkind = 'r' AND r.relname = ANY(v_allowed_tables) THEN
                EXECUTE format('ALTER TABLE public.%I OWNER TO mb13_p3_pack_data_owner', r.relname);
            ELSIF r.relkind IN ('i','I') THEN
                -- Index on an allowlisted table is acceptable; transfer with its table.
                IF EXISTS (
                    SELECT 1 FROM pg_index pi
                      JOIN pg_class c2 ON pi.indrelid = c2.oid
                     WHERE pi.indexrelid = r.oid
                       AND c2.relname = ANY(v_allowed_tables)
                ) THEN
                    EXECUTE format('ALTER INDEX public.%I OWNER TO mb13_p3_pack_data_owner', r.relname);
                ELSE
                    RAISE EXCEPTION 'migration_v225 legacy role % owns unexpected index % (kind %)', v_owner_role, r.relname, r.relkind;
                END IF;
            ELSIF r.relkind = 't' THEN
                -- TOAST table for an allowlisted table is acceptable; skip internal object.
                IF NOT EXISTS (
                    SELECT 1 FROM pg_class c2
                     WHERE c2.reltoastrelid = r.oid
                       AND c2.relname = ANY(v_allowed_tables)
                ) THEN
                    RAISE EXCEPTION 'migration_v225 legacy role % owns unexpected TOAST table %', v_owner_role, r.relname;
                END IF;
            ELSE
                RAISE EXCEPTION 'migration_v225 legacy role % owns unexpected object % (kind %)', v_owner_role, r.relname, r.relkind;
            END IF;
        END LOOP;

        -- functions
        FOR r IN
            SELECT p.proname,
                   array_to_string(ARRAY(SELECT format_type(oid, NULL) FROM unnest(p.proargtypes::oid[]) AS t(oid)), ',') AS args,
                   rl.rolname AS owner
              FROM pg_proc p
              JOIN pg_namespace n ON p.pronamespace = n.oid
              JOIN pg_roles rl ON p.proowner = rl.oid
             WHERE n.nspname = 'public'
               AND rl.rolname = v_owner_role
        LOOP
            v_fn_sig := r.proname || '(' || r.args || ')';
            IF v_fn_sig = ANY(v_allowed_functions) THEN
                IF v_fn_sig = ANY(v_validator_functions) THEN
                    EXECUTE format('ALTER FUNCTION %s OWNER TO mb13_p3_validator', v_fn_sig);
                ELSE
                    EXECUTE format('ALTER FUNCTION %s OWNER TO mb13_p3_pack_lifecycle_executor', v_fn_sig);
                END IF;
            ELSE
                RAISE EXCEPTION 'migration_v225 legacy role % owns unexpected function %', v_owner_role, v_fn_sig;
            END IF;
        END LOOP;

        -- types / domains in public
        FOR r IN
            SELECT t.typname
              FROM pg_type t
              JOIN pg_namespace n ON t.typnamespace = n.oid
              JOIN pg_roles rl ON t.typowner = rl.oid
             WHERE n.nspname = 'public'
               AND rl.rolname = v_owner_role
        LOOP
            RAISE EXCEPTION 'migration_v225 legacy role % owns unexpected type/domain %', v_owner_role, r.typname;
        END LOOP;

        -- schemas
        FOR r IN
            SELECT n.nspname
              FROM pg_namespace n
              JOIN pg_roles rl ON n.nspowner = rl.oid
             WHERE rl.rolname = v_owner_role
        LOOP
            RAISE EXCEPTION 'migration_v225 legacy role % owns unexpected schema %', v_owner_role, r.nspname;
        END LOOP;
    END LOOP;

    -- Verify new owners do not own unexpected objects in any non-system schema.
    FOR r IN
        SELECT n.nspname AS schema_name, c.relname AS obj_name, c.relkind, c.oid, rl.rolname AS owner
          FROM pg_class c
          JOIN pg_namespace n ON c.relnamespace = n.oid
          JOIN pg_roles rl ON c.relowner = rl.oid
         WHERE rl.rolname IN ('mb13_p3_pack_data_owner', 'mb13_p3_pack_lifecycle_executor')
           AND n.nspname NOT IN ('pg_catalog','pg_toast','information_schema')
    LOOP
        IF r.owner = 'mb13_p3_pack_data_owner' AND r.relkind = 'r' AND r.obj_name = ANY(v_allowed_tables) THEN CONTINUE; END IF;
        IF r.owner = 'mb13_p3_pack_data_owner' AND r.relkind = 'S' AND r.obj_name = ANY(v_allowed_sequences) THEN CONTINUE; END IF;
        IF r.owner = 'mb13_p3_pack_data_owner' AND r.relkind IN ('i','I') AND EXISTS (
            SELECT 1 FROM pg_index pi JOIN pg_class c2 ON pi.indrelid=c2.oid
             WHERE pi.indexrelid=r.oid AND c2.relname = ANY(v_allowed_tables)
        ) THEN CONTINUE; END IF;
        IF r.owner = 'mb13_p3_pack_data_owner' AND r.relkind = 't' AND EXISTS (
            SELECT 1 FROM pg_class c2 WHERE c2.reltoastrelid=r.oid AND c2.relname = ANY(v_allowed_tables)
        ) THEN CONTINUE; END IF;
        RAISE EXCEPTION 'migration_v225 owner % owns unexpected object %.% (kind %)', r.owner, r.schema_name, r.obj_name, r.relkind;
    END LOOP;

    FOR r IN
        SELECT n.nspname AS schema_name,
               p.proname || '(' || array_to_string(ARRAY(SELECT format_type(oid, NULL) FROM unnest(p.proargtypes::oid[]) AS t(oid)), ',') || ')' AS sig,
               rl.rolname AS owner
          FROM pg_proc p
          JOIN pg_namespace n ON p.pronamespace = n.oid
          JOIN pg_roles rl ON p.proowner = rl.oid
         WHERE rl.rolname IN ('mb13_p3_pack_lifecycle_executor', 'mb13_p3_validator')
    LOOP
        IF r.owner = 'mb13_p3_validator' AND r.sig = ANY(v_validator_functions) THEN CONTINUE; END IF;
        IF r.owner = 'mb13_p3_pack_lifecycle_executor' AND r.sig = ANY(v_allowed_functions) THEN CONTINUE; END IF;
        RAISE EXCEPTION 'migration_v225 owner % owns unexpected function %', r.owner, r.sig;
    END LOOP;
END $$;

-- ============================================================================
-- 4. Normalize table/sequence ACLs: revoke-first, grant-exact
-- ============================================================================
DO $$
DECLARE
    v_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    v_sequences TEXT[] := ARRAY[
        'mb13_p3_recovery_audit_audit_id_seq'
    ];
    v_revoke_roles TEXT[] := ARRAY[
        'PUBLIC', 'test_app', 'mb13_p3_api', 'mb13_p3_executor', 'mb13_p3_writer',
        'mb13_p3_validator', 'mb13_p3_pack_mutator', 'mb13_p3_pack_lifecycle_owner',
        'mb13_p3_pack_lifecycle_executor', 'mb13_p3_pack_data_owner'
    ];
    t TEXT; s TEXT; r TEXT; v_role_sql TEXT;
BEGIN
    FOREACH t IN ARRAY v_tables LOOP
        FOREACH r IN ARRAY v_revoke_roles LOOP
            v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
            EXECUTE format('REVOKE ALL PRIVILEGES ON TABLE public.%I FROM %s', t, v_role_sql);
        END LOOP;
        EXECUTE format('GRANT ALL PRIVILEGES ON TABLE public.%I TO mb13_p3_pack_data_owner', t);
        EXECUTE format('GRANT SELECT, INSERT, UPDATE ON TABLE public.%I TO mb13_p3_pack_lifecycle_executor', t);
    END LOOP;

    FOREACH s IN ARRAY v_sequences LOOP
        FOREACH r IN ARRAY v_revoke_roles LOOP
            v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
            EXECUTE format('REVOKE ALL PRIVILEGES ON SEQUENCE public.%I FROM %s', s, v_role_sql);
        END LOOP;
        EXECUTE format('GRANT ALL PRIVILEGES ON SEQUENCE public.%I TO mb13_p3_pack_data_owner', s);
        EXECUTE format('GRANT USAGE, SELECT ON SEQUENCE public.%I TO mb13_p3_pack_lifecycle_executor', s);
    END LOOP;
END $$;

-- ============================================================================
-- 5. Normalize function ACLs: revoke-first, grant-exact
-- ============================================================================
DO $$
DECLARE
    v_entrypoint_sigs TEXT[] := ARRAY[
        'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'mb13_p3_cancel_action_pack(uuid,uuid)',
        'mb13_p3_revoke_action_pack(uuid,uuid)',
        'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'mb13_p3_expire_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack_attempts(uuid,uuid)',
        'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)',
        'mb13_p3_list_action_packs(uuid,text,integer,integer)'
    ];
    v_api_sigs TEXT[] := ARRAY[
        'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'mb13_p3_cancel_action_pack(uuid,uuid)',
        'mb13_p3_revoke_action_pack(uuid,uuid)'
    ];
    v_executor_sigs TEXT[] := ARRAY[
        'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'mb13_p3_expire_action_pack(uuid,uuid)'
    ];
    v_reader_sigs TEXT[] := ARRAY[
        'mb13_p3_get_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack_attempts(uuid,uuid)',
        'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)',
        'mb13_p3_list_action_packs(uuid,text,integer,integer)'
    ];
    v_all_sigs TEXT[] := ARRAY[
        'mb13_p3_action_pack_auth_hash(uuid,uuid,integer,integer,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_authorization_append_only()',
        'mb13_p3_action_pack_authorization_hash(uuid,uuid,integer,text,integer,text,text,text,text,timestamp with time zone,timestamp with time zone)',
        'mb13_p3_action_pack_evidence_immutable()',
        'mb13_p3_action_pack_governed_mutation()',
        'mb13_p3_action_pack_monitor_policy_hash()',
        'mb13_p3_action_pack_payload_hash(uuid,uuid,integer,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_action_pack_refs_revoked(mb13_p0_monitor_target,jsonb,jsonb)',
        'mb13_p3_action_pack_result_evidence_guard()',
        'mb13_p3_action_pack_result_hash(uuid,uuid,integer,uuid,integer,text,text,jsonb,timestamp with time zone)',
        'mb13_p3_action_pack_result_immutable()',
        'mb13_p3_action_pack_revision_immutable()',
        'mb13_p3_action_pack_terminal_attempt_sync()',
        'mb13_p3_action_pack_timeline_immutable()',
        'mb13_p3_action_pack_transition_guard()',
        'mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'mb13_p3_cancel_action_pack(uuid,uuid)',
        'mb13_p3_canonicalize_evidence_payload(mb13_p3_action_pack,text,jsonb)',
        'mb13_p3_canonicalize_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'mb13_p3_expire_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack(uuid,uuid)',
        'mb13_p3_get_action_pack_attempts(uuid,uuid)',
        'mb13_p3_get_action_pack_timeline(uuid,uuid,integer,integer)',
        'mb13_p3_get_active_authorization(uuid,uuid,text,integer,text,text,text,text,integer)',
        'mb13_p3_get_covered_step_consents(mb13_p3_action_pack,jsonb)',
        'mb13_p3_get_monitor_policy_hash(uuid,uuid,integer)',
        'mb13_p3_list_action_packs(uuid,text,integer,integer)',
        'mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'mb13_p3_recovery_audit_immutable()',
        'mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'mb13_p3_revoke_action_pack(uuid,uuid)',
        'mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'mb13_p3_validate_action_pack_integrity(mb13_p3_action_pack)',
        'mb13_p3_validate_evidence_payload_semantics(mb13_p3_action_pack,text,jsonb,text)',
        'mb13_p3_validate_result_evidence(jsonb)',
        'mb13_p3_validate_result_evidence(uuid,uuid,uuid,jsonb)',
        'mb13_p3_validate_source_grant_chain(uuid,mb13_p0_monitor_target,jsonb,jsonb,jsonb)',
        'mb13_p3_validate_steps(uuid,jsonb)',
        'mb13_p3_validate_trigger_diff(uuid,uuid,integer,uuid,uuid)'
    ];
    v_revoke_roles TEXT[] := ARRAY[
        'PUBLIC', 'test_app', 'mb13_p3_api', 'mb13_p3_executor', 'mb13_p3_writer',
        'mb13_p3_validator', 'mb13_p3_pack_mutator', 'mb13_p3_pack_lifecycle_owner',
        'mb13_p3_pack_lifecycle_executor', 'mb13_p3_pack_data_owner'
    ];
    sig TEXT; r TEXT; v_role_sql TEXT; proname TEXT;
    v_validator_internal TEXT[] := ARRAY[
        'mb13_p3_action_pack_refs_revoked',
        'mb13_p3_validate_source_grant_chain',
        'mb13_p3_validate_trigger_diff'
    ];
BEGIN
    FOREACH sig IN ARRAY v_all_sigs LOOP
        FOREACH r IN ARRAY v_revoke_roles LOOP
            v_role_sql := CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END;
            EXECUTE format('REVOKE ALL ON FUNCTION %s FROM %s', sig, v_role_sql);
        END LOOP;
    END LOOP;

    -- Entrypoints / readers: grant only to API and executor roles.
    FOREACH sig IN ARRAY v_api_sigs LOOP
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_api', sig);
    END LOOP;
    FOREACH sig IN ARRAY v_executor_sigs LOOP
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_executor', sig);
    END LOOP;
    FOREACH sig IN ARRAY v_reader_sigs LOOP
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_api, mb13_p3_executor', sig);
    END LOOP;

    -- Internal helpers: owned by lifecycle executor, except validator-owned helpers.
    FOREACH sig IN ARRAY v_all_sigs LOOP
        proname := split_part(sig, '(', 1);
        IF proname = ANY(v_validator_internal) THEN
            EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_validator, mb13_p3_pack_lifecycle_executor', sig);
        ELSIF NOT (sig = ANY(v_entrypoint_sigs)) THEN
            EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_pack_lifecycle_executor', sig);
        END IF;
    END LOOP;
END $$;

GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_governed_mutation()
    TO mb13_p3_pack_data_owner, mb13_p3_writer, mb13_p3_api, mb13_p3_executor,
       mb13_p3_validator, test_app;

-- ============================================================================
-- 6. Force RLS on MB13-P3 tables
-- ============================================================================
DO $$
DECLARE
    v_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    t TEXT;
BEGIN
    FOREACH t IN ARRAY v_tables LOOP
        EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
        EXECUTE format('ALTER TABLE public.%I FORCE ROW LEVEL SECURITY', t);
    END LOOP;
END $$;

DROP POLICY IF EXISTS mb13_p3_recovery_audit_lifecycle ON public.mb13_p3_recovery_audit;
CREATE POLICY mb13_p3_recovery_audit_lifecycle
    ON public.mb13_p3_recovery_audit
    FOR ALL
    TO mb13_p3_pack_lifecycle_executor
    USING (true)
    WITH CHECK (true);

-- ============================================================================
-- 7. Membership graph cleanup and transitive path check
-- ============================================================================
DO $$
DECLARE
    v_app_roles TEXT[] := ARRAY[
        'mb13_p3_writer','mb13_p3_api','mb13_p3_executor','mb13_p3_validator',
        'mb13_p3_pack_mutator','mb13_p3_pack_lifecycle_owner','test_app'
    ];
    v_owners TEXT[] := ARRAY[
        'mb13_p3_pack_data_owner','mb13_p3_pack_lifecycle_executor','mb13_p3_validator'
    ];
    r TEXT; o TEXT;
BEGIN
    -- Revoke any direct membership between application/legacy roles and owner/validator roles.
    FOREACH r IN ARRAY v_app_roles LOOP
        FOREACH o IN ARRAY v_owners LOOP
            EXECUTE format('REVOKE %I FROM %I', o, r);
        END LOOP;
    END LOOP;
END $$;

DO $$
DECLARE
    v_source_roles TEXT[] := ARRAY[
        'test_app','mb13_p3_api','mb13_p3_executor','mb13_p3_writer',
        'mb13_p3_validator','mb13_p3_pack_mutator','mb13_p3_pack_lifecycle_owner'
    ];
    v_target_roles TEXT[] := ARRAY[
        'mb13_p3_pack_data_owner','mb13_p3_pack_lifecycle_executor','mb13_p3_validator'
    ];
    r RECORD;
BEGIN
    WITH RECURSIVE membership AS (
        SELECT m.member::regrole AS member_role,
               m.roleid::regrole AS granted_role,
               1 AS depth,
               m.admin_option
          FROM pg_auth_members m
         WHERE m.member IN (SELECT oid FROM pg_roles WHERE rolname = ANY(v_source_roles))
        UNION
        SELECT p.member_role,
               m.roleid::regrole,
               p.depth + 1,
               m.admin_option
          FROM membership p
          JOIN pg_auth_members m ON p.granted_role::oid = m.member
         WHERE p.depth < 10
    )
    SELECT member_role::text, granted_role::text, depth, admin_option
      INTO r
      FROM membership
     WHERE granted_role::text = ANY(v_target_roles)
     LIMIT 1;
    IF FOUND THEN
        RAISE EXCEPTION 'migration_v225 membership path from app/legacy role to owner/validator: % -> % (depth %)', r.member_role, r.granted_role, r.depth;
    END IF;
END $$;

-- ============================================================================
-- 8. Effective privilege verification on final state
-- ============================================================================
DO $$
DECLARE
    v_tables TEXT[] := ARRAY[
        'mb13_p3_action_pack',
        'mb13_p3_action_pack_attempt',
        'mb13_p3_action_pack_authorization',
        'mb13_p3_action_pack_evidence',
        'mb13_p3_action_pack_result',
        'mb13_p3_action_pack_revision',
        'mb13_p3_action_pack_timeline',
        'mb13_p3_recovery_audit'
    ];
    v_app_roles TEXT[] := ARRAY[
        'test_app','mb13_p3_api','mb13_p3_executor','mb13_p3_writer',
        'mb13_p3_validator','mb13_p3_pack_mutator','mb13_p3_pack_lifecycle_owner'
    ];
    v_privs TEXT[] := ARRAY['INSERT','UPDATE','DELETE','TRUNCATE','REFERENCES','TRIGGER'];
    r TEXT; t TEXT; p TEXT; ok BOOLEAN;
BEGIN
    FOREACH t IN ARRAY v_tables LOOP
        FOREACH r IN ARRAY v_app_roles LOOP
            FOREACH p IN ARRAY v_privs LOOP
                IF has_table_privilege(r, 'public.' || t, p) THEN
                    RAISE EXCEPTION 'migration_v225 effective privilege violation: role % has % on %', r, p, t;
                END IF;
            END LOOP;
        END LOOP;
    END LOOP;

    -- writer must not have direct SELECT on MB13-P3 tables (it is BYPASSRLS).
    FOREACH t IN ARRAY v_tables LOOP
        IF has_table_privilege('mb13_p3_writer', 'public.' || t, 'SELECT') THEN
            RAISE EXCEPTION 'migration_v225 writer has direct SELECT on %', t;
        END IF;
    END LOOP;

    -- no residual migration_v22x_* function
    FOR r IN SELECT proname FROM pg_proc p JOIN pg_namespace n ON p.pronamespace=n.oid WHERE n.nspname='public' AND p.proname LIKE 'migration_v22x_%' LOOP
        RAISE EXCEPTION 'migration_v225 residual temporary function: %', r.proname;
    END LOOP;
END $$;

-- ============================================================================
-- 9. Final legacy role inertization
-- ============================================================================
ALTER ROLE mb13_p3_pack_mutator NOLOGIN NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p3_pack_lifecycle_owner NOLOGIN NOINHERIT NOBYPASSRLS;

COMMIT;
