-- Vemoria Gate06 R1H P4 Localization static completion
-- Runtime remains NON_ESEGUITO. This migration records metadata only.

CREATE TABLE IF NOT EXISTS gate06_r1h_p4_localization_static_completion (
    id INTEGER PRIMARY KEY,
    gate TEXT NOT NULL,
    version TEXT NOT NULL,
    static_completion_state TEXT NOT NULL,
    runtime_real TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    notes TEXT NOT NULL
);

INSERT INTO gate06_r1h_p4_localization_static_completion (
    id, gate, version, static_completion_state, runtime_real, notes
) VALUES (
    1,
    'GATE06_R1H_P4_LOCALIZATION_STATIC_COMPLETION',
    'GATE06_R1H_P4_LOCALIZATION_STATIC_COMPLETION_V147_2026-06-19',
    'STATIC_COMPLETED_RUNTIME_DEFERRED',
    'NON_ESEGUITO',
    'Static completion for VC-045, VC-049, VC-047, VC-048. Original text remains authoritative; translations are derived. No Flutter/Android localization, machine translation or cross-language search runtime executed.'
) ON CONFLICT(id) DO UPDATE SET
    version=excluded.version,
    static_completion_state=excluded.static_completion_state,
    runtime_real=excluded.runtime_real,
    notes=excluded.notes;
