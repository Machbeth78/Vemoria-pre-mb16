-- VEMORA — Migration V84: Gruppi chat operativi
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
--
-- Gruppi operativi per lavoro/documenti: non social generalisti.
-- Un gruppo è sempre associato a un workspace.

CREATE TABLE IF NOT EXISTS chat_gruppi (
    id                  UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    thread_id           UUID        NOT NULL REFERENCES chat_thread(id) ON DELETE CASCADE,
    workspace_type      TEXT        NOT NULL DEFAULT 'personal',
    workspace_id        TEXT        NOT NULL DEFAULT 'personal',
    nome                TEXT        NOT NULL,
    descrizione         TEXT,
    owner_user_id       UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    stato               TEXT        NOT NULL DEFAULT 'attivo'
                                    CHECK (stato IN ('attivo', 'archiviato', 'chiuso')),
    creato_il           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chat_gruppi_workspace
    ON chat_gruppi(workspace_type, workspace_id);
CREATE INDEX IF NOT EXISTS idx_chat_gruppi_owner
    ON chat_gruppi(owner_user_id);

CREATE TABLE IF NOT EXISTS chat_gruppi_membri (
    id                  UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    gruppo_id           UUID        NOT NULL REFERENCES chat_gruppi(id) ON DELETE CASCADE,
    user_id             UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    role                TEXT        NOT NULL DEFAULT 'member'
                                    CHECK (role IN ('owner', 'admin', 'member')),
    joined_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    left_at             TIMESTAMPTZ,
    UNIQUE (gruppo_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_chat_gruppi_membri_gruppo
    ON chat_gruppi_membri(gruppo_id);
CREATE INDEX IF NOT EXISTS idx_chat_gruppi_membri_user
    ON chat_gruppi_membri(user_id);

-- Registra migrazione
-- Nota: registrazione migration demandata al migration runner/registry service.
-- Se la migration viene applicata manualmente via SQL puro, usare poi adopt-existing o status nel runner.
