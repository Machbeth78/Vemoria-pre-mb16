-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB11-P2 Phase A R1B — Corrective migration for canonical identity projection tables.
-- Additive, idempotent. Applies after migration_v171 where v171 may already be present.

BEGIN;

-- Correct JSON list defaults where the runtime contract expects arrays.
ALTER TABLE canonical_identity_projection
    ALTER COLUMN strong_identifiers SET DEFAULT '[]'::jsonb;

ALTER TABLE canonical_identity_split_log
    ALTER COLUMN split_strong_ids SET DEFAULT '[]'::jsonb;

-- Add missing merge/split snapshot columns for exact reversibility.
ALTER TABLE canonical_identity_merge_log
    ADD COLUMN IF NOT EXISTS prior_target_state JSONB,
    ADD COLUMN IF NOT EXISTS prior_target_links JSONB;

ALTER TABLE canonical_identity_split_log
    ADD COLUMN IF NOT EXISTS prior_source_state JSONB,
    ADD COLUMN IF NOT EXISTS prior_new_state JSONB,
    ADD COLUMN IF NOT EXISTS reversed_at TIMESTAMPTZ;

-- Ensure RLS policies enforce both read and write (WITH CHECK) owner isolation.
DROP POLICY IF EXISTS canonical_identity_projection_owner_policy ON canonical_identity_projection;
CREATE POLICY canonical_identity_projection_owner_policy ON canonical_identity_projection
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

DROP POLICY IF EXISTS canonical_identity_link_projection_owner_policy ON canonical_identity_link_projection;
CREATE POLICY canonical_identity_link_projection_owner_policy ON canonical_identity_link_projection
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

DROP POLICY IF EXISTS canonical_identity_merge_log_owner_policy ON canonical_identity_merge_log;
CREATE POLICY canonical_identity_merge_log_owner_policy ON canonical_identity_merge_log
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

DROP POLICY IF EXISTS canonical_identity_split_log_owner_policy ON canonical_identity_split_log;
CREATE POLICY canonical_identity_split_log_owner_policy ON canonical_identity_split_log
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

DROP POLICY IF EXISTS canonical_identity_proposal_projection_owner_policy ON canonical_identity_proposal_projection;
CREATE POLICY canonical_identity_proposal_projection_owner_policy ON canonical_identity_proposal_projection
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

DROP POLICY IF EXISTS canonical_identity_rejection_log_owner_policy ON canonical_identity_rejection_log;
CREATE POLICY canonical_identity_rejection_log_owner_policy ON canonical_identity_rejection_log
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

COMMIT;
