-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
--
-- MB13-P1 R2 — Authoritative Deterministic Diff Closure.
-- Forward-only, idempotent migration. Hardens MB13-P1 governance:
-- observation consent/provenance, baseline/observation compatibility,
-- historical baseline validity, deterministic content identity, and an
-- executor-owned writer that derives counts, state and summary.

BEGIN;

-- ----------------------------------------------------------------------------
-- Dedicated executor role for the authoritative diff writer.
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p1_executor') THEN
        CREATE ROLE mb13_p1_executor NOLOGIN;
    END IF;
END
$$;

-- ----------------------------------------------------------------------------
-- Document revision support so a document monitor can compare revision N
-- against a later revision N+1 of the same document identity.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.mb13_p1_document_revision (
    owner_user_id       UUID NOT NULL,
    document_id         UUID NOT NULL REFERENCES public.documenti(id) ON DELETE CASCADE,
    revision            INTEGER NOT NULL,
    state               TEXT NOT NULL CHECK (state IN ('memorizzato','revoked')),
    payload_hash        TEXT NOT NULL,
    dati_strutturati    JSONB,
    testo_grezzo        TEXT,
    supersedes_revision INTEGER,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, document_id, revision),
    CONSTRAINT ck_mb13_p1_document_revision_positive CHECK (revision >= 1)
);

CREATE INDEX IF NOT EXISTS ix_mb13_p1_document_revision_owner_document
    ON public.mb13_p1_document_revision(owner_user_id, document_id, revision DESC);

ALTER TABLE public.mb13_p1_document_revision ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p1_document_revision FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb13_p1_document_revision_owner_isolation ON public.mb13_p1_document_revision;
CREATE POLICY mb13_p1_document_revision_owner_isolation ON public.mb13_p1_document_revision
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

-- ----------------------------------------------------------------------------
-- Diff tables: deterministic content identity, separate from record identity.
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p1_universal_diff
    ADD COLUMN IF NOT EXISTS content_hash TEXT;

ALTER TABLE public.mb13_p1_universal_diff_revision
    ADD COLUMN IF NOT EXISTS content_hash TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS ix_mb13_p1_diff_content_hash
    ON public.mb13_p1_universal_diff(owner_user_id, content_hash)
    WHERE content_hash IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS ix_mb13_p1_diff_revision_content_hash
    ON public.mb13_p1_universal_diff_revision(owner_user_id, diff_id, content_hash)
    WHERE content_hash IS NOT NULL;

-- ----------------------------------------------------------------------------
-- Typed canonical JSON value for deterministic hashing.
-- Distinguishes boolean true from string "True", null from absent, etc.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_canonical_jsonb(p_value JSONB)
RETURNS JSONB AS $$
DECLARE
    v_keys TEXT[];
    v_key TEXT;
    v_arr JSONB[] := '{}';
    v_i INTEGER;
    v_len INTEGER;
    v_result JSONB;
BEGIN
    IF p_value IS NULL THEN
        RETURN jsonb_build_object('t', 'absent', 'v', NULL);
    END IF;

    CASE jsonb_typeof(p_value)
        WHEN 'null' THEN
            RETURN jsonb_build_object('t', 'null', 'v', NULL);
        WHEN 'boolean' THEN
            RETURN jsonb_build_object('t', 'boolean', 'v', (p_value #>> '{}')::boolean);
        WHEN 'number' THEN
            RETURN jsonb_build_object('t', 'number', 'v', p_value);
        WHEN 'string' THEN
            RETURN jsonb_build_object('t', 'string', 'v', p_value #>> '{}');
        WHEN 'array' THEN
            v_len := jsonb_array_length(p_value);
            FOR v_i IN 0 .. v_len - 1 LOOP
                v_arr := v_arr || public.mb13_p1_canonical_jsonb(p_value->v_i);
            END LOOP;
            RETURN jsonb_build_object('t', 'array', 'v', to_jsonb(v_arr));
        WHEN 'object' THEN
            SELECT array_agg(k ORDER BY k) INTO v_keys FROM jsonb_object_keys(p_value) k;
            v_result := '{}'::jsonb;
            IF v_keys IS NOT NULL THEN
                FOREACH v_key IN ARRAY v_keys LOOP
                    v_result := v_result || jsonb_build_object(v_key, public.mb13_p1_canonical_jsonb(p_value->v_key));
                END LOOP;
            END IF;
            RETURN jsonb_build_object('t', 'object', 'v', v_result);
        ELSE
            RETURN jsonb_build_object('t', 'unknown', 'v', NULL);
    END CASE;
END;
$$ LANGUAGE plpgsql IMMUTABLE
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p1_canonical_jsonb(JSONB) FROM PUBLIC;

CREATE OR REPLACE FUNCTION public.mb13_p1_typed_hash(p_value JSONB)
RETURNS TEXT AS $$
    SELECT public.mb13_p0_hash_jsonb(public.mb13_p1_canonical_jsonb($1));
$$ LANGUAGE SQL IMMUTABLE
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p1_typed_hash(JSONB) FROM PUBLIC;

-- ----------------------------------------------------------------------------
-- Provenance resolver: use the exact revision requested by the target_ref.
-- For decision targets this switches from current_revision to target_ref revision.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p0_get_target_provenance(
    p_owner UUID,
    p_target_type TEXT,
    p_target_ref JSONB
)
RETURNS TABLE(source_refs JSONB, evidence_refs JSONB) AS $$
DECLARE
    v_id TEXT;
    v_revision INTEGER;
    v_source_refs JSONB;
    v_evidence_refs JSONB;
BEGIN
    IF p_target_ref IS NULL OR jsonb_typeof(p_target_ref) <> 'object' THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    v_id := p_target_ref->>'id';
    IF v_id IS NULL OR length(trim(v_id)) = 0 THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    BEGIN
        v_revision := (p_target_ref->>'revision')::INTEGER;
    EXCEPTION WHEN invalid_text_representation THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END;

    -- Source card target: lock and return the binding row as provenance.
    IF p_target_type = 'source' THEN
        SELECT
            jsonb_build_array(jsonb_build_object(
                'source_card_id', b.source_card_id,
                'source_id', b.source_id::text,
                'source_revision_id', b.source_revision_id::text,
                'evidence_id', b.evidence_id::text,
                'grant_id', b.grant_id::text,
                'content_hash', b.content_hash
            )),
            COALESCE((
                SELECT jsonb_agg(jsonb_build_object(
                    'evidence_id', b2.evidence_id::text,
                    'source_id', b2.source_id::text,
                    'source_card_id', b2.source_card_id
                ) ORDER BY b2.evidence_id::text)
                  FROM public.mb12_p0_source_card_binding b2
                 WHERE b2.owner_user_id = p_owner
                   AND b2.source_card_id = v_id
            ), '[]'::jsonb)
          INTO v_source_refs, v_evidence_refs
          FROM public.mb12_p0_source_card_binding b
         WHERE b.owner_user_id = p_owner
           AND b.source_card_id = v_id
         FOR SHARE;
        RETURN QUERY SELECT COALESCE(v_source_refs, '[]'::jsonb), COALESCE(v_evidence_refs, '[]'::jsonb);
        RETURN;
    END IF;

    -- Dossier / contract / offer target: read the exact revision source_refs.
    IF p_target_type IN ('dossier','contract','offer') THEN
        SELECT r.source_refs
          INTO v_source_refs
          FROM public.mb12_p1_offer_contract_revision r
         WHERE r.owner_user_id = p_owner
           AND r.dossier_id = v_id::UUID
           AND r.revision = v_revision;

        IF v_source_refs IS NOT NULL THEN
            v_evidence_refs := COALESCE((
                SELECT jsonb_agg(jsonb_build_object(
                    'evidence_id', (s->>'evidence_id'),
                    'source_id', (s->>'source_id'),
                    'source_card_id', (s->>'source_card_id')
                ) ORDER BY (s->>'evidence_id'))
                  FROM jsonb_array_elements(v_source_refs) AS s
                 WHERE (s->>'evidence_id') IS NOT NULL
            ), '[]'::jsonb);
            RETURN QUERY SELECT public.mb13_p0_normalize_jsonb_array(v_source_refs), public.mb13_p0_normalize_jsonb_array(v_evidence_refs);
            RETURN;
        END IF;
    END IF;

    -- Decision target: use the exact revision requested by target_ref.
    IF p_target_type = 'decision' THEN
        SELECT rev.result_payload->'source_refs'
          INTO v_source_refs
          FROM public.mb12_p4_governed_explainable_ranking r
          JOIN public.mb12_p4_governed_explainable_ranking_revision rev
            ON rev.owner_user_id = r.owner_user_id
           AND rev.ranking_id = r.ranking_id
           AND rev.revision = v_revision
         WHERE r.owner_user_id = p_owner
           AND r.ranking_id = v_id::UUID
         FOR SHARE OF r, rev;

        IF v_source_refs IS NOT NULL THEN
            v_evidence_refs := COALESCE((
                SELECT jsonb_agg(jsonb_build_object(
                    'evidence_id', (s->>'evidence_id'),
                    'source_id', (s->>'source_id'),
                    'source_card_id', (s->>'source_card_id')
                ) ORDER BY (s->>'evidence_id'))
                  FROM jsonb_array_elements(v_source_refs) AS s
                 WHERE (s->>'evidence_id') IS NOT NULL
            ), '[]'::jsonb);
            RETURN QUERY SELECT public.mb13_p0_normalize_jsonb_array(v_source_refs), public.mb13_p0_normalize_jsonb_array(v_evidence_refs);
            RETURN;
        END IF;
    END IF;

    -- Document and generic targets carry no intrinsic provenance.
    RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB) FROM PUBLIC;

-- ----------------------------------------------------------------------------
-- Consent and provenance validation, hardened for diff operations.
-- p_strict_relation=FALSE allows a consent to cover either the baseline or the
-- observation provenance, so a single monitor consent set can cover both.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN);
CREATE OR REPLACE FUNCTION public.mb13_p0_lock_and_verify_consents(
    p_owner UUID,
    p_consent_refs JSONB,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_required BOOLEAN,
    p_strict_relation BOOLEAN DEFAULT TRUE
)
RETURNS JSONB AS $$
DECLARE
    v_ref JSONB;
    v_source_id TEXT;
    v_grant_id TEXT;
    v_grant RECORD;
    v_normalized JSONB;
    v_count INTEGER := 0;
    v_provenance_source_refs JSONB;
    v_provenance_evidence_refs JSONB;
    v_required_pairs TEXT[];
    v_provided_pairs TEXT[];
    v_ps TEXT;
    v_document_id UUID;
    v_allowed_documents JSONB;
BEGIN
    IF p_consent_refs IS NULL OR jsonb_typeof(p_consent_refs) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p0_consent_refs_invalid';
    END IF;
    IF p_required AND jsonb_array_length(p_consent_refs) = 0 THEN
        RAISE EXCEPTION 'mb13_p0_consent_required';
    END IF;

    v_normalized := public.mb13_p0_normalize_jsonb_array(p_consent_refs);

    SELECT source_refs, evidence_refs INTO v_provenance_source_refs, v_provenance_evidence_refs
      FROM public.mb13_p0_get_target_provenance(p_owner, p_target_type, p_target_ref);

    IF p_target_type IN ('dossier','contract','offer','source','decision') THEN
        SELECT array_agg(DISTINCT (((s->>'source_id') || ':' || COALESCE(s->>'grant_id',''))))
          INTO v_required_pairs
          FROM jsonb_array_elements(v_provenance_source_refs) AS s
         WHERE (s->>'source_id') IS NOT NULL
           AND jsonb_typeof(s) = 'object';
    END IF;

    FOR v_ref IN SELECT value FROM jsonb_array_elements(v_normalized) LOOP
        v_source_id := v_ref->>'source_id';
        v_grant_id := v_ref->>'grant_id';
        IF v_source_id IS NULL OR v_grant_id IS NULL THEN
            RAISE EXCEPTION 'mb13_p0_consent_ref_invalid';
        END IF;

        SELECT *
          INTO v_grant
          FROM public.authorized_memory_consent_grants
         WHERE user_id = p_owner
           AND source_id = v_source_id::UUID
           AND id = v_grant_id::UUID
           AND status = 'active'
           AND revoked_at IS NULL
           AND (expires_at IS NULL OR expires_at > NOW())
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_consent_revoked_or_invalid';
        END IF;

        IF v_grant.action NOT IN ('read_metadata','inventory_existence')
           OR v_grant.plane <> 'EXISTENCE' THEN
            RAISE EXCEPTION 'mb13_p0_consent_action_incompatible';
        END IF;

        IF p_target_type IN ('dossier','contract','offer','decision') AND p_strict_relation THEN
            v_ps := v_source_id || ':' || v_grant_id;
            IF v_required_pairs IS NULL OR NOT (v_ps = ANY(v_required_pairs)) THEN
                RAISE EXCEPTION 'mb13_p0_provenance_not_related_to_target';
            END IF;
        END IF;

        IF p_target_type = 'source' THEN
            IF NOT EXISTS (
                SELECT 1 FROM public.mb12_p0_source_card_binding b
                 WHERE b.owner_user_id = p_owner
                   AND b.source_card_id = (p_target_ref->>'id')
                   AND b.source_id = v_source_id::UUID
                   AND b.grant_id = v_grant_id::UUID
            ) THEN
                RAISE EXCEPTION 'mb13_p0_provenance_not_related_to_target';
            END IF;
        END IF;

        IF p_target_type = 'document' THEN
            v_document_id := (p_target_ref->>'id')::UUID;
            v_allowed_documents := NULLIF(v_grant.constraints->'data_scope'->'allowed_documents', 'null'::jsonb);
            IF v_allowed_documents IS NULL
               OR jsonb_typeof(v_allowed_documents) <> 'array'
               OR NOT EXISTS (
                    SELECT 1 FROM jsonb_array_elements_text(v_allowed_documents) AS ad
                     WHERE ad = v_document_id::text
                  )
            THEN
                RAISE EXCEPTION 'mb13_p0_document_capability_not_bound';
            END IF;
        END IF;

        v_count := v_count + 1;
    END LOOP;

    IF p_required AND p_target_type IN ('dossier','contract','offer','decision') THEN
        SELECT array_agg(DISTINCT (((c->>'source_id') || ':' || COALESCE(c->>'grant_id',''))))
          INTO v_provided_pairs
          FROM jsonb_array_elements(v_normalized) AS c
         WHERE (c->>'source_id') IS NOT NULL AND (c->>'grant_id') IS NOT NULL;

        IF v_required_pairs IS NOT NULL THEN
            FOREACH v_ps IN ARRAY v_required_pairs LOOP
                IF v_provided_pairs IS NULL OR NOT (v_ps = ANY(v_provided_pairs)) THEN
                    RAISE EXCEPTION 'mb13_p0_consent_coverage_incomplete';
                END IF;
            END LOOP;
        END IF;
    END IF;

    IF p_required AND v_count = 0 THEN
        RAISE EXCEPTION 'mb13_p0_consent_required';
    END IF;

    RETURN v_normalized;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID,JSONB,TEXT,JSONB,BOOLEAN,BOOLEAN) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID,JSONB,TEXT,JSONB,BOOLEAN,BOOLEAN) TO mb13_p1_executor;

-- ----------------------------------------------------------------------------
-- Authoritative target resolver for diff operations.
-- Validates exact historical or current revision without requiring it to be
-- the current revision of the target.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_resolve_target(
    p_owner UUID,
    p_target_type TEXT,
    p_target_ref JSONB
)
RETURNS TABLE(state TEXT, payload_hash TEXT, target_revision INTEGER) AS $$
DECLARE
    v_id TEXT;
    v_revision INTEGER;
    v_hash TEXT;
    v_state TEXT;
    v_doc RECORD;
    v_dossier RECORD;
    v_decision RECORD;
    v_rev RECORD;
BEGIN
    IF jsonb_typeof(p_target_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p1_target_ref_invalid';
    END IF;
    IF p_target_ref->>'id' IS NULL OR p_target_ref->>'revision' IS NULL OR p_target_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_target_ref_missing';
    END IF;
    IF p_target_ref->>'owner_user_id' IS DISTINCT FROM p_owner::text THEN
        RAISE EXCEPTION 'mb13_p1_target_owner_mismatch';
    END IF;

    v_id := p_target_ref->>'id';
    BEGIN
        v_revision := (p_target_ref->>'revision')::INTEGER;
    EXCEPTION WHEN invalid_text_representation THEN
        RAISE EXCEPTION 'mb13_p1_target_ref_invalid';
    END;
    v_hash := p_target_ref->>'payload_hash';
    v_state := p_target_ref->>'state';

    IF v_revision < 1 THEN
        RAISE EXCEPTION 'mb13_p1_target_revision_invalid';
    END IF;

    -- Document target.
    IF p_target_type = 'document' THEN
        IF v_revision = 1 THEN
            SELECT d.stato_elaborazione AS state, d.hash_file AS payload_hash, 1 AS revision INTO v_doc
              FROM public.documenti d
             WHERE d.id = v_id::UUID
               AND d.proprietario_id = p_owner
             FOR SHARE;
        ELSE
            SELECT r.state, r.payload_hash, r.revision INTO v_doc
              FROM public.mb13_p1_document_revision r
             WHERE r.document_id = v_id::UUID
               AND r.owner_user_id = p_owner
               AND r.revision = v_revision
             FOR SHARE;
        END IF;

        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p1_target_not_found';
        END IF;

        v_state := v_doc.state;

        IF v_state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p1_target_revoked';
        END IF;
        IF v_state <> 'memorizzato' THEN
            RAISE EXCEPTION 'mb13_p1_target_not_available';
        END IF;
        IF v_doc.payload_hash <> v_hash THEN
            RAISE EXCEPTION 'mb13_p1_target_reference_not_current';
        END IF;

        RETURN QUERY SELECT v_state, v_hash, v_revision;
        RETURN;
    END IF;

    -- Dossier / contract / offer target.
    IF p_target_type IN ('dossier','contract','offer') THEN
        SELECT d.current_revision, d.payload_hash, d.state INTO v_dossier
          FROM public.mb12_p1_offer_contract d
         WHERE d.owner_user_id = p_owner
           AND d.dossier_id = v_id::UUID
         FOR SHARE;

        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p1_target_not_found';
        END IF;

        IF v_dossier.state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p1_target_revoked';
        END IF;

        SELECT r.state, r.payload_hash, r.revision INTO v_rev
          FROM public.mb12_p1_offer_contract_revision r
         WHERE r.owner_user_id = p_owner
           AND r.dossier_id = v_id::UUID
           AND r.revision = v_revision
         FOR SHARE;

        IF NOT FOUND
           OR v_rev.payload_hash <> v_hash
           OR v_rev.state <> 'normalized'
           OR v_state IS DISTINCT FROM 'normalized' THEN
            RAISE EXCEPTION 'mb13_p1_target_reference_not_current';
        END IF;

        RETURN QUERY SELECT v_rev.state, v_hash, v_revision;
        RETURN;
    END IF;

    -- Decision target.
    IF p_target_type = 'decision' THEN
        SELECT d.current_revision, d.payload_hash, d.state INTO v_decision
          FROM public.mb12_p4_governed_explainable_ranking d
         WHERE d.owner_user_id = p_owner
           AND d.ranking_id = v_id::UUID
         FOR SHARE;

        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p1_target_not_found';
        END IF;

        IF v_decision.state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p1_target_revoked';
        END IF;

        SELECT r.state, r.payload_hash, r.revision INTO v_rev
          FROM public.mb12_p4_governed_explainable_ranking_revision r
         WHERE r.owner_user_id = p_owner
           AND r.ranking_id = v_id::UUID
           AND r.revision = v_revision
         FOR SHARE;

        IF NOT FOUND
           OR v_rev.payload_hash <> v_hash
           OR v_rev.state NOT IN ('ready','incomplete','incompatible')
           OR v_state IS DISTINCT FROM v_rev.state THEN
            RAISE EXCEPTION 'mb13_p1_target_reference_not_current';
        END IF;

        RETURN QUERY SELECT v_rev.state, v_hash, v_revision;
        RETURN;
    END IF;

    IF p_target_type = 'source' THEN
        RAISE EXCEPTION 'mb13_p1_source_payload_not_diffable';
    END IF;

    IF p_target_type = 'rule' THEN
        RAISE EXCEPTION 'mb13_p1_target_type_not_supported';
    END IF;

    RAISE EXCEPTION 'mb13_p1_target_type_not_supported';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p1_resolve_target(UUID, TEXT, JSONB) FROM PUBLIC;

-- ----------------------------------------------------------------------------
-- Authoritative deterministic diff writer.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_write_diff(UUID,JSONB,TEXT,JSONB,INTEGER,INTEGER,TEXT,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB,JSONB);
CREATE OR REPLACE FUNCTION public.mb13_p1_write_diff(
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT,
    p_changes JSONB,
    p_change_count INTEGER,
    p_material_change_count INTEGER,
    p_diff_state TEXT,
    p_summary TEXT,
    p_algorithm_version TEXT,
    p_normalization_version TEXT,
    p_request_payload JSONB,
    p_result_payload JSONB
) RETURNS TABLE(diff_id UUID, revision INTEGER, content_hash TEXT, diff_state TEXT, change_count INTEGER, material_change_count INTEGER, summary TEXT, changes JSONB) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_baseline_source_refs JSONB;
    v_baseline_evidence_refs JSONB;
    v_observation_source_refs JSONB;
    v_observation_evidence_refs JSONB;
    v_effective_source_refs JSONB;
    v_effective_evidence_refs JSONB;
    v_canonical_consent_refs JSONB;
    v_canonical_changes JSONB;
    v_change_count INTEGER;
    v_material_change_count INTEGER;
    v_diff_state TEXT;
    v_summary TEXT;
    v_content_hash TEXT;
    v_existing_diff_id UUID;
    v_existing_revision INTEGER;
    v_diff_id UUID;
    v_revision INTEGER := 1;
    v_event_type TEXT;
    v_event_id UUID;
    v_event_time TIMESTAMPTZ := NOW();
    v_event_payload_hash TEXT;
    v_event_result_payload JSONB;
    v_expected_algorithm TEXT;
    v_baseline_rev INTEGER;
    v_observation_rev INTEGER;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'id' IS NULL OR p_observation_ref->>'revision' IS NULL OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;
    IF jsonb_typeof(COALESCE(p_changes, '[]'::jsonb)) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p1_changes_invalid';
    END IF;

    v_expected_algorithm := CASE p_diff_kind
        WHEN 'structured' THEN 'mb13-p1-r2-structured'
        WHEN 'text' THEN 'mb13-p1-r2-text'
    END;

    IF p_algorithm_version IS NULL OR p_algorithm_version <> v_expected_algorithm THEN
        RAISE EXCEPTION 'mb13_p1_algorithm_version_invalid';
    END IF;
    IF p_normalization_version IS NULL OR p_normalization_version <> 'mb13-p1-r2' THEN
        RAISE EXCEPTION 'mb13_p1_normalization_version_invalid';
    END IF;

    -- Serialize on monitor to avoid races between diff computation and revocation.
    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_monitor_id::text, 0));

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = v_owner
       AND t.monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_found';
    END IF;
    IF v_current.monitor_state <> 'active' THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;

    -- Resolve baseline and observation independently.
    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, v_current.target_ref);
    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, p_observation_ref);

    -- Compatibility: same identity and observation not earlier than baseline,
    -- unless observation explicitly declares lineage to the baseline.
    IF (v_current.target_ref->>'id') IS DISTINCT FROM (p_observation_ref->>'id') THEN
        RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
    END IF;

    v_baseline_rev := (v_current.target_ref->>'revision')::INTEGER;
    v_observation_rev := (p_observation_ref->>'revision')::INTEGER;

    IF v_observation_rev < v_baseline_rev THEN
        IF NOT (
            (p_observation_ref->>'supersedes' IS NOT DISTINCT FROM v_current.target_ref->>'id')
            OR (p_observation_ref->>'revision_of' IS NOT DISTINCT FROM v_current.target_ref->>'id')
            OR (p_observation_ref->>'derived_from' IS NOT DISTINCT FROM v_current.target_ref->>'id')
            OR ((p_observation_ref->'supersedes'->>'id') IS NOT DISTINCT FROM v_current.target_ref->>'id')
            OR ((p_observation_ref->'revision_of'->>'id') IS NOT DISTINCT FROM v_current.target_ref->>'id')
            OR ((p_observation_ref->'derived_from'->>'id') IS NOT DISTINCT FROM v_current.target_ref->>'id')
        ) THEN
            RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
        END IF;
    END IF;

    -- Consents must cover both baseline and observation; the same monitor grant
    -- set may cover either side, so strict per-target relation is relaxed here.
    v_canonical_consent_refs := public.mb13_p0_lock_and_verify_consents(
        v_owner, v_current.consent_refs, v_current.target_type, v_current.target_ref,
        p_required => TRUE, p_strict_relation => FALSE
    );
    PERFORM public.mb13_p0_lock_and_verify_consents(
        v_owner, v_current.consent_refs, v_current.target_type, p_observation_ref,
        p_required => TRUE, p_strict_relation => FALSE
    );

    -- Provenance for baseline and observation.
    SELECT source_refs, evidence_refs INTO v_baseline_source_refs, v_baseline_evidence_refs
      FROM public.mb13_p0_get_target_provenance(v_owner, v_current.target_type, v_current.target_ref);
    SELECT source_refs, evidence_refs INTO v_observation_source_refs, v_observation_evidence_refs
      FROM public.mb13_p0_get_target_provenance(v_owner, v_current.target_type, p_observation_ref);

    -- Observation evidence must belong to the owner.
    IF v_current.target_type IN ('dossier','contract','offer','decision') THEN
        IF EXISTS (
            SELECT 1
              FROM jsonb_array_elements(COALESCE(v_observation_source_refs, '[]'::jsonb)) AS s
             WHERE (s.value->>'evidence_id') IS NOT NULL
               AND NOT EXISTS (
                   SELECT 1 FROM public.mb12_p0_trusted_data_value v
                    WHERE v.owner_user_id = v_owner
                      AND v.evidence_id = (s.value->>'evidence_id')::UUID
               )
        ) THEN
            RAISE EXCEPTION 'mb13_p1_observation_evidence_invalid';
        END IF;
    END IF;

    v_effective_source_refs := public.mb13_p0_normalize_jsonb_array(
        COALESCE(v_baseline_source_refs, '[]'::jsonb) || COALESCE(v_observation_source_refs, '[]'::jsonb)
    );
    v_effective_evidence_refs := public.mb13_p0_normalize_jsonb_array(
        COALESCE(v_baseline_evidence_refs, '[]'::jsonb) || COALESCE(v_observation_evidence_refs, '[]'::jsonb)
    );

    -- Derive canonical result from the supplied changes.
    v_canonical_changes := public.mb13_p0_normalize_jsonb_array(p_changes);
    v_change_count := jsonb_array_length(v_canonical_changes);

    SELECT COUNT(*) INTO v_material_change_count
      FROM jsonb_array_elements(v_canonical_changes) AS c
     WHERE (c.value->>'materiality') = 'POTENTIALLY_MATERIAL';

    IF v_change_count = 0 THEN
        v_diff_state := 'no_change';
    ELSE
        SELECT CASE WHEN EXISTS (
            SELECT 1 FROM jsonb_array_elements(v_canonical_changes) c
             WHERE (c.value->>'change_type') = 'AMBIGUOUS'
        ) THEN 'ambiguous' ELSE 'computed' END INTO v_diff_state;
    END IF;

    v_summary := CASE WHEN v_change_count = 0
        THEN 'No changes detected'
        ELSE format('Detected %s change(s), %s material', v_change_count, v_material_change_count)
    END;

    IF p_change_count IS DISTINCT FROM v_change_count THEN
        RAISE EXCEPTION 'mb13_p1_change_count_mismatch';
    END IF;
    IF p_material_change_count IS DISTINCT FROM v_material_change_count THEN
        RAISE EXCEPTION 'mb13_p1_material_change_count_mismatch';
    END IF;
    IF p_diff_state IS DISTINCT FROM v_diff_state THEN
        RAISE EXCEPTION 'mb13_p1_diff_state_mismatch';
    END IF;
    IF p_summary IS DISTINCT FROM v_summary THEN
        RAISE EXCEPTION 'mb13_p1_summary_mismatch';
    END IF;

    -- Deterministic content identity excludes diff_id and timestamps.
    v_content_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'baseline_ref', v_current.target_ref,
        'observation_ref', p_observation_ref,
        'diff_kind', p_diff_kind,
        'changes', v_canonical_changes,
        'algorithm_version', p_algorithm_version,
        'normalization_version', p_normalization_version,
        'source_refs', v_effective_source_refs,
        'evidence_refs', v_effective_evidence_refs,
        'consent_refs', v_canonical_consent_refs
    ));

    -- Idempotency: same canonical inputs yield the same identity.
    SELECT d.diff_id, d.current_revision
      INTO v_existing_diff_id, v_existing_revision
      FROM public.mb13_p1_universal_diff d
     WHERE d.owner_user_id = v_owner
       AND d.content_hash = v_content_hash
     LIMIT 1;

    IF FOUND THEN
        RETURN QUERY SELECT v_existing_diff_id, v_existing_revision, v_content_hash, v_diff_state, v_change_count, v_material_change_count, v_summary, v_canonical_changes;
        RETURN;
    END IF;

    v_diff_id := gen_random_uuid();

    v_event_result_payload := COALESCE(p_result_payload, '{}'::jsonb) || jsonb_build_object(
        'diff_id', v_diff_id,
        'diff_revision', v_revision,
        'diff_content_hash', v_content_hash,
        'diff_kind', p_diff_kind,
        'diff_state', v_diff_state,
        'change_count', v_change_count,
        'material_change_count', v_material_change_count,
        'no_auto_action', true,
        'no_auto_notification', true,
        'baseline_source_refs', v_baseline_source_refs,
        'baseline_evidence_refs', v_baseline_evidence_refs,
        'observation_source_refs', v_observation_source_refs,
        'observation_evidence_refs', v_observation_evidence_refs,
        'effective_consent_refs', v_canonical_consent_refs
    );

    INSERT INTO public.mb13_p1_universal_diff (
        owner_user_id, diff_id, monitor_id, monitor_revision, baseline_ref, observation_ref,
        diff_kind, diff_state, summary, change_count, material_change_count, changes,
        source_refs, evidence_refs, consent_refs, algorithm_version, normalization_version,
        payload_hash, content_hash, current_revision, request_payload, result_payload
    ) VALUES (
        v_owner, v_diff_id, p_monitor_id, v_current.current_revision, v_current.target_ref, p_observation_ref,
        p_diff_kind, v_diff_state, v_summary, v_change_count, v_material_change_count, v_canonical_changes,
        v_effective_source_refs, v_effective_evidence_refs, v_canonical_consent_refs,
        p_algorithm_version, p_normalization_version,
        v_content_hash, v_content_hash, v_revision, COALESCE(p_request_payload, '{}'::jsonb), v_event_result_payload
    );

    INSERT INTO public.mb13_p1_universal_diff_revision (
        owner_user_id, diff_id, revision, monitor_revision, baseline_ref, observation_ref,
        diff_kind, diff_state, summary, change_count, material_change_count, changes,
        source_refs, evidence_refs, consent_refs, algorithm_version, normalization_version,
        payload_hash, content_hash, request_payload, result_payload
    ) VALUES (
        v_owner, v_diff_id, v_revision, v_current.current_revision, v_current.target_ref, p_observation_ref,
        p_diff_kind, v_diff_state, v_summary, v_change_count, v_material_change_count, v_canonical_changes,
        v_effective_source_refs, v_effective_evidence_refs, v_canonical_consent_refs,
        p_algorithm_version, p_normalization_version,
        v_content_hash, v_content_hash, COALESCE(p_request_payload, '{}'::jsonb), v_event_result_payload
    );

    -- Atomic MB13-P0 event ledger append.
    IF v_diff_state = 'no_change' THEN
        v_event_type := 'NO_CHANGE_RECORDED';
    ELSE
        v_event_type := 'CHANGE_CANDIDATE_RECORDED';
    END IF;

    v_event_id := gen_random_uuid();
    v_event_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'event_id', v_event_id,
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'event_type', v_event_type,
        'event_status', 'recorded',
        'event_time', to_jsonb(v_event_time),
        'observed_ref', p_observation_ref,
        'source_refs', v_effective_source_refs,
        'evidence_refs', v_effective_evidence_refs,
        'consent_refs', v_canonical_consent_refs,
        'reason', NULL,
        'result_payload', v_event_result_payload
    ));

    INSERT INTO public.mb13_p0_monitor_event_ledger (
        event_id, owner_user_id, monitor_id, monitor_revision, event_type, event_status, event_time,
        observed_ref, source_refs, evidence_refs, consent_refs, reason, result_payload, payload_hash
    ) VALUES (
        v_event_id, v_owner, p_monitor_id, v_current.current_revision, v_event_type, 'recorded', v_event_time,
        p_observation_ref, v_effective_source_refs, v_effective_evidence_refs, v_canonical_consent_refs, NULL, v_event_result_payload, v_event_payload_hash
    );

    RETURN QUERY SELECT v_diff_id, v_revision, v_content_hash, v_diff_state, v_change_count, v_material_change_count, v_summary, v_canonical_changes;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID,JSONB,TEXT,JSONB,INTEGER,INTEGER,TEXT,TEXT,TEXT,TEXT,JSONB,JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_write_diff(UUID,JSONB,TEXT,JSONB,INTEGER,INTEGER,TEXT,TEXT,TEXT,TEXT,JSONB,JSONB) TO mb13_p1_executor;

-- ----------------------------------------------------------------------------
-- Ownership and grants.
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p1_universal_diff OWNER TO mb13_p1_executor;
ALTER TABLE public.mb13_p1_universal_diff_revision OWNER TO mb13_p1_executor;
ALTER TABLE public.mb13_p1_document_revision OWNER TO mb13_p1_executor;

ALTER FUNCTION public.mb13_p1_write_diff(UUID,JSONB,TEXT,JSONB,INTEGER,INTEGER,TEXT,TEXT,TEXT,TEXT,JSONB,JSONB) OWNER TO mb13_p1_executor;
ALTER FUNCTION public.mb13_p1_resolve_target(UUID, TEXT, JSONB) OWNER TO mb13_p1_executor;
ALTER FUNCTION public.mb13_p1_canonical_jsonb(JSONB) OWNER TO mb13_p1_executor;
ALTER FUNCTION public.mb13_p1_typed_hash(JSONB) OWNER TO mb13_p1_executor;

-- Executor must be able to read/lock the monitor and write the event ledger.
GRANT SELECT, UPDATE ON public.mb13_p0_monitor_target TO mb13_p1_executor;
GRANT INSERT ON public.mb13_p0_monitor_event_ledger TO mb13_p1_executor;
GRANT USAGE ON SEQUENCE public.mb13_p0_event_sequence_seq TO mb13_p1_executor;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p1_universal_diff TO mb13_p1_executor;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p1_universal_diff_revision TO mb13_p1_executor;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mb13_p1_document_revision TO mb13_p1_executor;
GRANT SELECT, UPDATE ON public.documenti TO mb13_p1_executor;
GRANT SELECT, UPDATE ON public.mb12_p1_offer_contract TO mb13_p1_executor;
GRANT SELECT, UPDATE ON public.mb12_p1_offer_contract_revision TO mb13_p1_executor;
GRANT SELECT, UPDATE ON public.mb12_p4_governed_explainable_ranking TO mb13_p1_executor;
GRANT SELECT, UPDATE ON public.mb12_p4_governed_explainable_ranking_revision TO mb13_p1_executor;
GRANT SELECT ON public.mb12_p0_trusted_data_value TO mb13_p1_executor;

-- Executor must call P0 provenance/consent helpers.
GRANT EXECUTE ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID,JSONB,TEXT,JSONB,BOOLEAN,BOOLEAN) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p0_get_target_provenance(UUID,TEXT,JSONB) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p0_hash_jsonb(JSONB) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p0_normalize_jsonb_array(JSONB) TO mb13_p1_executor;

COMMIT;
