# Vemoria
# Copyright © 2026 Devoti Massimo. All rights reserved.
# Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

# v109 — Source Indexer V1.
# Import side-effect: garantisce che le classi SQLAlchemy del Source Indexer
# siano caricate (e quindi registrate sulla Base condivisa) prima che qualsiasi
# query venga eseguita. Non altera l'API pubblica del package database.
try:
    from database import models_source_indexer  # noqa: F401
except Exception:  # difesa: se il modulo non esiste (deploy parziale), continua.
    pass

# v110 — Folder Access V1 (Universal Digital Memory V1.1).
# Stesso pattern difensivo.
try:
    from database import models_folder_access  # noqa: F401
except Exception:
    pass

# v111 — Operational Sends V1.2 (Search Desk).
# Stesso pattern difensivo.
try:
    from database import models_operational_sends  # noqa: F401
except Exception:
    pass
