-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V40 — Radar V1
-- Mappa Errori e Diagnostica Strutturata

CREATE TABLE IF NOT EXISTS trace_sessions (
    trace_id                 UUID PRIMARY KEY,
    transaction_type         TEXT NOT NULL,
    utente_id                UUID NULL,
    documento_id             UUID NULL,
    evento_id                UUID NULL,
    contatto_id              UUID NULL,
    source_module            TEXT NULL,
    source_screen            TEXT NULL,
    final_status             TEXT NOT NULL DEFAULT 'running',
    started_at_utc           TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    started_at_local         TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    finished_at_utc          TIMESTAMP WITH TIME ZONE NULL,
    finished_at_local        TIMESTAMP WITH TIME ZONE NULL,
    device_context_json      JSONB NULL,
    user_context_json        JSONB NULL,
    summary_json             JSONB NULL,
    created_at               TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at               TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_trace_sessions_type_status
    ON trace_sessions (transaction_type, final_status, started_at_utc DESC);

CREATE TABLE IF NOT EXISTS diagnostic_batches (
    batch_id                 UUID PRIMARY KEY,
    event_count              INTEGER NOT NULL DEFAULT 0,
    batch_hash               TEXT NOT NULL,
    upload_attempts          INTEGER NOT NULL DEFAULT 0,
    upload_status            TEXT NOT NULL DEFAULT 'created',
    created_at               TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    last_upload_at           TIMESTAMP WITH TIME ZONE NULL,
    summary_json             JSONB NULL
);

CREATE TABLE IF NOT EXISTS diagnostic_events (
    event_id                     UUID PRIMARY KEY,
    trace_id                     UUID NOT NULL REFERENCES trace_sessions(trace_id) ON DELETE CASCADE,
    parent_event_id              UUID NULL REFERENCES diagnostic_events(event_id) ON DELETE SET NULL,
    batch_id                     UUID NULL REFERENCES diagnostic_batches(batch_id) ON DELETE SET NULL,
    module                       TEXT NOT NULL,
    screen                       TEXT NULL,
    function_name                TEXT NOT NULL,
    step_code                    TEXT NOT NULL,
    transaction_type             TEXT NULL,
    sequence_number              INTEGER NOT NULL,
    status                       TEXT NOT NULL,
    severity                     TEXT NOT NULL,
    error_code                   TEXT NULL,
    error_message                TEXT NULL,
    fingerprint                  TEXT NOT NULL,
    timestamp_utc                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    timestamp_local              TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    timezone_offset              TEXT NULL,
    elapsed_ms_from_trace_start  INTEGER NULL,
    device_model                 TEXT NULL,
    os_version                   TEXT NULL,
    app_version                  TEXT NULL,
    network_state                TEXT NULL,
    file_type                    TEXT NULL,
    file_hash                    TEXT NULL,
    payload_json                 JSONB NULL,
    upload_status                TEXT NOT NULL DEFAULT 'pending',
    created_at                   TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at                   TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_diagnostic_events_trace_seq
    ON diagnostic_events (trace_id, sequence_number, timestamp_utc);

CREATE INDEX IF NOT EXISTS idx_diagnostic_events_fingerprint
    ON diagnostic_events (fingerprint, timestamp_utc DESC);

CREATE INDEX IF NOT EXISTS idx_diagnostic_events_upload_status
    ON diagnostic_events (upload_status, severity, timestamp_utc DESC);

CREATE TABLE IF NOT EXISTS error_groups (
    group_id                  UUID PRIMARY KEY,
    fingerprint               TEXT NOT NULL UNIQUE,
    module                    TEXT NULL,
    screen                    TEXT NULL,
    function_name             TEXT NULL,
    step_code                 TEXT NULL,
    error_code                TEXT NULL,
    highest_severity          TEXT NOT NULL,
    total_occurrences         INTEGER NOT NULL DEFAULT 0,
    first_seen_at             TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    last_seen_at              TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    last_trace_id             UUID NULL,
    affected_versions_json    JSONB NULL,
    affected_devices_json     JSONB NULL,
    last_error_message        TEXT NULL,
    created_at                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_error_groups_last_seen
    ON error_groups (last_seen_at DESC, total_occurrences DESC);
