-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- PRE-MB16 Pass 8AF — global/public threat-intelligence snapshots.
-- IMPORTANT: no owner identifier, phone number, e-mail address, message body or
-- other personal data is allowed in this table.
CREATE TABLE IF NOT EXISTS antifraud_intelligence_snapshots (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    country_code    TEXT NOT NULL,
    language_code   TEXT NOT NULL,
    generated_at    TIMESTAMPTZ NOT NULL,
    expires_at      TIMESTAMPTZ NOT NULL,
    payload_json    JSONB NOT NULL,
    payload_sha256  TEXT NOT NULL,
    source_count    INTEGER NOT NULL DEFAULT 0,
    provider_kind   TEXT NOT NULL,
    refresh_status  TEXT NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (char_length(country_code) = 2),
    CHECK (source_count >= 0)
);

CREATE INDEX IF NOT EXISTS idx_antifraud_intel_country_language_generated
    ON antifraud_intelligence_snapshots(country_code, language_code, generated_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS idx_antifraud_intel_payload_sha256
    ON antifraud_intelligence_snapshots(payload_sha256);
-- Owner-specific opt-in is separate from generic Internet consent. Turning
-- antifraud off must stop automatic monitoring even if other product features
-- still retain Internet authorization.
CREATE TABLE IF NOT EXISTS antifraud_owner_settings (
    owner_id UUID PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    enabled BOOLEAN NOT NULL DEFAULT FALSE,
    monitor_forwarded_email BOOLEAN NOT NULL DEFAULT FALSE,
    external_reputation_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE antifraud_owner_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE antifraud_owner_settings FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS antifraud_owner_settings_owner_policy ON antifraud_owner_settings;
CREATE POLICY antifraud_owner_settings_owner_policy
    ON antifraud_owner_settings
    FOR ALL
    USING (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

COMMENT ON TABLE antifraud_owner_settings IS
    'Owner opt-in for continuous antifraud. Generic Internet consent alone never enables monitoring.';

