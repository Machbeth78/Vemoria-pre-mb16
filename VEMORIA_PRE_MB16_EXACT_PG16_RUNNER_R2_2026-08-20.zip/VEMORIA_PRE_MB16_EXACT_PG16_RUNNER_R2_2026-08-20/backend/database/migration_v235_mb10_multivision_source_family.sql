-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.
--
-- MB10-A — Multi-Vision canonical runtime integration.
-- Additive migration: extend the MB9 source_family allowlist to include
-- "multivision" so backend Multi-Vision runtimes can be wired into canonical
-- source intake.

BEGIN;

ALTER TABLE mb9_personal_source_item
    DROP CONSTRAINT IF EXISTS mb9_personal_source_item_source_family_check;

ALTER TABLE mb9_personal_source_item
    ADD CONSTRAINT mb9_personal_source_item_source_family_check
    CHECK (source_family IN ('storage','contacts','calendar','email','pec','multivision'));

COMMIT;
