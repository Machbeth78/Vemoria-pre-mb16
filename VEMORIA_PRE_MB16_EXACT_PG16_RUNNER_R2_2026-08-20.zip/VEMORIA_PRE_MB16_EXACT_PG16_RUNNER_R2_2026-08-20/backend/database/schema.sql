-- ============================================================
-- VEMORA — Schema PostgreSQL Completo
-- Ideatore: Devoti Massimo
-- Generato da: architettura FROZEN V1
-- ============================================================

-- Estensione UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- TABELLA: utenti
-- ============================================================
CREATE TABLE utenti (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome            TEXT NOT NULL,
    email           TEXT NOT NULL UNIQUE,
    password_hash   TEXT NOT NULL,
    creato_il       TIMESTAMP NOT NULL DEFAULT NOW(),
    aggiornato_il   TIMESTAMP NOT NULL DEFAULT NOW(),
    attivo          BOOLEAN NOT NULL DEFAULT TRUE
);

-- ============================================================
-- TABELLA: tipi_documento
-- Libreria modelli — popolata al bootstrap
-- ============================================================
CREATE TABLE tipi_documento (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    codice      TEXT NOT NULL UNIQUE,   -- es: "fattura", "contratto", "generico"
    etichetta   TEXT NOT NULL,          -- es: "Fattura", "Contratto"
    categoria   TEXT NOT NULL,          -- es: "finanziario", "legale", "sanitario"
    attivo      BOOLEAN NOT NULL DEFAULT TRUE,
    creato_il   TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABELLA: documenti
-- Documento fisico ricevuto dal sistema
-- ============================================================
CREATE TABLE documenti (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    proprietario_id         UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    nome_file_originale     TEXT NOT NULL,
    stato_elaborazione      TEXT NOT NULL DEFAULT 'ricevuto',
                            -- ricevuto | in_acquisizione | in_comprensione
                            -- in_costruzione | in_qualita | memorizzato
                            -- in_errore | in_attesa_utente
    tipo_documento_id       UUID REFERENCES tipi_documento(id),
    percorso_storage        TEXT,           -- path relativo in originali/
    hash_file               TEXT,           -- SHA-256 del file originale
    testo_grezzo            TEXT,           -- testo estratto dall'OCR
    lingua_rilevata         TEXT,           -- codice ISO 639-1 es: "it"
    tentativi_correnti      INTEGER NOT NULL DEFAULT 0,
    dati_strutturati        JSONB,          -- PacchettoDocumento serializzato
    creato_il               TIMESTAMP NOT NULL DEFAULT NOW(),
    aggiornato_il           TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_documenti_proprietario    ON documenti(proprietario_id);
CREATE INDEX idx_documenti_stato           ON documenti(stato_elaborazione);
CREATE INDEX idx_documenti_tipo            ON documenti(tipo_documento_id);
CREATE INDEX idx_documenti_aggiornato      ON documenti(aggiornato_il DESC);

-- ============================================================
-- TABELLA: memorie
-- Memoria strutturata e approvata dalla pipeline
-- ============================================================
CREATE TABLE memorie (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    proprietario_id         UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    documento_sorgente_id   UUID REFERENCES documenti(id) ON DELETE SET NULL,

    -- Contenuto principale
    titolo                  TEXT NOT NULL,
    riassunto               TEXT,
    testo_completo          TEXT,

    -- Classificazione
    tipo_documento          TEXT NOT NULL DEFAULT 'generico',
    categoria_documento     TEXT NOT NULL DEFAULT 'generico',
    sottocategoria          TEXT,
    codice_lingua           TEXT NOT NULL DEFAULT 'it',

    -- Qualità
    score_qualita           REAL NOT NULL DEFAULT 0.0,
    livello_affidabilita    REAL NOT NULL DEFAULT 0.0,
    approvata_con_riserva   BOOLEAN NOT NULL DEFAULT FALSE,

    -- Dati strutturati (entità, metadati, qualità)
    dati_strutturati        JSONB,
    metadati_ricerca        JSONB,

    -- Stato
    stato                   TEXT NOT NULL DEFAULT 'attiva',
                            -- attiva | archiviata | eliminata
    versione                INTEGER NOT NULL DEFAULT 1,

    creata_il               TIMESTAMP NOT NULL DEFAULT NOW(),
    aggiornato_il           TIMESTAMP NOT NULL DEFAULT NOW(),
    confermata_il           TIMESTAMP
);

CREATE INDEX idx_memorie_proprietario      ON memorie(proprietario_id);
CREATE INDEX idx_memorie_tipo              ON memorie(tipo_documento);
CREATE INDEX idx_memorie_categoria         ON memorie(categoria_documento);
CREATE INDEX idx_memorie_stato             ON memorie(stato);
CREATE INDEX idx_memorie_creata            ON memorie(creata_il DESC);
CREATE INDEX idx_memorie_documento_src     ON memorie(documento_sorgente_id);

-- Ricerca full-text sul titolo e riassunto
CREATE INDEX idx_memorie_fts ON memorie
    USING GIN (to_tsvector('italian', coalesce(titolo,'') || ' ' || coalesce(riassunto,'')));

-- ============================================================
-- TABELLA: cronologia_eventi
-- Log immutabile di ogni step della pipeline
-- ============================================================
CREATE TABLE cronologia_eventi (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id        UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    nome_camera         TEXT NOT NULL,
    tipo_evento         TEXT NOT NULL,
    numero_tentativo    INTEGER NOT NULL DEFAULT 1,
    dati_evento         JSONB,
    messaggio_errore    TEXT,
    timestamp           TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_cronologia_documento  ON cronologia_eventi(documento_id);
CREATE INDEX idx_cronologia_timestamp  ON cronologia_eventi(timestamp DESC);
CREATE INDEX idx_cronologia_camera     ON cronologia_eventi(nome_camera);

-- ============================================================
-- TABELLA: problemi
-- Documenti che la pipeline non è riuscita a gestire
-- ============================================================
CREATE TABLE problemi (
    id                          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id                UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    camera_origine              TEXT NOT NULL,
    tipo_problema               TEXT NOT NULL,
    motivazione_principale      TEXT,
    dettaglio_tecnico           TEXT,
    tentativi_effettuati        INTEGER NOT NULL DEFAULT 0,
    richiede_intervento_utente  BOOLEAN NOT NULL DEFAULT FALSE,
    risolto                     BOOLEAN NOT NULL DEFAULT FALSE,
    creato_il                   TIMESTAMP NOT NULL DEFAULT NOW(),
    risolto_il                  TIMESTAMP
);

CREATE INDEX idx_problemi_documento    ON problemi(documento_id);
CREATE INDEX idx_problemi_risolto      ON problemi(risolto);

-- ============================================================
-- TABELLA: identita_digitale
-- Impronta SHA-256 verificabile di ogni documento
-- ============================================================
CREATE TABLE identita_digitale (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id        UUID NOT NULL UNIQUE REFERENCES documenti(id) ON DELETE CASCADE,
    hash_documento      TEXT NOT NULL,
    percorso_file       TEXT NOT NULL,
    stato_identita      TEXT NOT NULL DEFAULT 'attiva',
                        -- attiva | revocata | aggiornata
    versione_identita   TEXT NOT NULL DEFAULT '1.0',
    firma_identita      TEXT,           -- placeholder per V2
    metadati            JSONB,
    creata_il           TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_identita_documento ON identita_digitale(documento_id);
CREATE INDEX idx_identita_stato     ON identita_digitale(stato_identita);

-- ============================================================
-- DATI INIZIALI: tipi_documento (Libreria Modelli)
-- ============================================================
INSERT INTO tipi_documento (codice, etichetta, categoria) VALUES
    ('fattura',         'Fattura',              'finanziario'),
    ('ricevuta',        'Ricevuta',             'finanziario'),
    ('contratto',       'Contratto',            'legale'),
    ('lettera',         'Lettera',              'corrispondenza'),
    ('referto_medico',  'Referto Medico',       'sanitario'),
    ('preventivo',      'Preventivo',           'finanziario'),
    ('verbale',         'Verbale',              'legale'),
    ('certificato',     'Certificato',          'ufficiale'),
    ('generico',        'Documento Generico',   'generico');

-- ============================================================
-- FUNZIONE: aggiorna aggiornato_il automaticamente
-- ============================================================
CREATE OR REPLACE FUNCTION aggiorna_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.aggiornato_il = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_documenti_aggiornato
    BEFORE UPDATE ON documenti
    FOR EACH ROW EXECUTE FUNCTION aggiorna_timestamp();

CREATE TRIGGER trigger_memorie_aggiornato
    BEFORE UPDATE ON memorie
    FOR EACH ROW EXECUTE FUNCTION aggiorna_timestamp();
