-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V53 — ECO Camere Ancora / Tempo Umano / Common Ground

CREATE TABLE IF NOT EXISTS eco_anchor_candidates (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id        UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    anchor_label        TEXT NOT NULL,
    anchor_type         TEXT NOT NULL DEFAULT 'generic',
    anchor_strength     TEXT NOT NULL DEFAULT 'probable',
    anchor_score        REAL NOT NULL DEFAULT 0.0,
    linked_entity_type  TEXT,
    linked_entity_id    UUID,
    source              TEXT NOT NULL DEFAULT 'eco',
    reason_codes        JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at          TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_anchor_utterance ON eco_anchor_candidates(utterance_id);
CREATE INDEX IF NOT EXISTS idx_eco_anchor_label ON eco_anchor_candidates(anchor_label, created_at DESC);

CREATE TABLE IF NOT EXISTS eco_temporal_resolutions (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utterance_id        UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    resolution_mode     TEXT NOT NULL,
    expression          TEXT,
    from_date           DATE,
    to_date             DATE,
    resolution_json     JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_temporal_utterance ON eco_temporal_resolutions(utterance_id);
CREATE INDEX IF NOT EXISTS idx_eco_temporal_mode ON eco_temporal_resolutions(resolution_mode, created_at DESC);

CREATE TABLE IF NOT EXISTS eco_common_ground_states (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id              UUID NOT NULL REFERENCES eco_sessions(id) ON DELETE CASCADE,
    utterance_id            UUID NOT NULL REFERENCES eco_utterances(id) ON DELETE CASCADE,
    active_focus_json       JSONB NOT NULL DEFAULT '[]'::jsonb,
    shared_entities_json    JSONB NOT NULL DEFAULT '[]'::jsonb,
    shared_action           TEXT,
    shared_time_scope_json  JSONB NOT NULL DEFAULT '{}'::jsonb,
    shared_anchor_json      JSONB NOT NULL DEFAULT '{}'::jsonb,
    open_uncertainties_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    ground_strength         REAL NOT NULL DEFAULT 0.0,
    created_at              TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_eco_ground_session ON eco_common_ground_states(session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_eco_ground_utterance ON eco_common_ground_states(utterance_id);
