-- VEMORA
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
-- Tutti i diritti riservati.
--
-- Desktop Companion / Secure Line Remote Relay Hardening V1

ALTER TABLE desktop_secure_line_relay_tickets
    ADD COLUMN IF NOT EXISTS relay_ticket_hash TEXT NULL,
    ADD COLUMN IF NOT EXISTS max_redemptions INTEGER NOT NULL DEFAULT 1,
    ADD COLUMN IF NOT EXISTS redemption_count INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS failed_attempts INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS last_attempt_at TIMESTAMPTZ NULL,
    ADD COLUMN IF NOT EXISTS revoked_at TIMESTAMPTZ NULL,
    ADD COLUMN IF NOT EXISTS security_version TEXT NOT NULL DEFAULT 'v2',
    ADD COLUMN IF NOT EXISTS issuer_session_hint TEXT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_secure_line_relay_ticket_hash
    ON desktop_secure_line_relay_tickets (relay_ticket_hash)
    WHERE relay_ticket_hash IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_secure_line_relay_ticket_request_hardened
    ON desktop_secure_line_relay_tickets (utente_id, request_id, purpose, status, expires_at DESC);

CREATE INDEX IF NOT EXISTS idx_secure_line_relay_ticket_device_hardened
    ON desktop_secure_line_relay_tickets (utente_id, issued_for_channel, issued_for_device_id, created_at DESC);
