-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification,
-- distribution or use is prohibited.
--
-- migration_v112_v_pt_core_01_quick_notes.sql
-- Laboratorio: Vemoria Privacy & Trust — Blocco V-PT-CORE-01
-- Scrivania guidata + Quick Notes + Promemoria in chat/relazione
--
-- Filosofia (V-PT-CORE-01):
-- - Quick Notes sono appunti rapidi del proprietario, distinti dalle Memorie
--   (Memoria ha semantica "estrazione da documento": titolo, riassunto,
--   score qualità, ecc.). Mischiare i due domini introdurrebbe debito.
-- - Linker server-side ma trattato come dato sensibile: nessun log del testo,
--   nessuna telemetria comportamentale. Vincolo Privacy & Trust.
-- - EmergenceTrigger: meccanismo per far riemergere un appunto quando
--   l'utente apre un contesto pertinente (chat, relazione, dossier, tempo).
--
-- Sicurezza:
-- - FK proprietario_id → utenti(id) ON DELETE CASCADE (privacy: i dati
--   dell'utente spariscono con l'utente).
-- - FK linked_* → tabelle target ON DELETE SET NULL (l'appunto sopravvive
--   se il target sparisce, perché contiene il pensiero dell'utente).
-- - Denormalizzazione proprietario_id su appunto_emergence_trigger:
--   evita JOIN sulla query calda "pending per contesto chat aperto".
-- - CHECK constraint stretti su origine, stato, tipo trigger.
--
-- Additiva e idempotente: CREATE TABLE IF NOT EXISTS, CREATE INDEX IF NOT EXISTS.
-- NON modifica memorie, NON modifica chat_thread, NON modifica unified_contracts.
-- Nessun ALTER su tabelle esistenti.

BEGIN;

-- ===========================================================================
-- appunti_rapidi
-- ===========================================================================
-- Quick Note del proprietario: pensiero/promemoria catturato rapidamente
-- (long-press, wake word locale, widget OS, shortcut, headset).
--
-- Il backend NON riceve mai audio: l'eventuale wake word è device-side, la
-- trascrizione (Whisper local o STT nativo) è device-side. Qui arriva solo
-- il testo già trascritto.

CREATE TABLE IF NOT EXISTS appunti_rapidi (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    -- proprietà
    proprietario_id     UUID NOT NULL
                        REFERENCES utenti(id) ON DELETE CASCADE,

    -- contenuto (testo grezzo dal client; mai loggato)
    testo               TEXT NOT NULL,
    -- versione normalizzata per match deterministico del linker
    -- (lowercase, accent-folded, stripped). Calcolata lato service Python,
    -- non da SQL function, per evitare dipendenza da unaccent extension.
    testo_normalizzato  TEXT NULL,

    -- come è stata creata
    origine             TEXT NOT NULL DEFAULT 'manual'
                        CHECK (origine IN (
                            'wake_word',
                            'long_press',
                            'shortcut',
                            'widget',
                            'headset',
                            'manual'
                        )),

    -- link risolti dal linker server-side (best effort, niente LLM)
    linked_contact_id   UUID NULL
                        REFERENCES contatti_rubrica(id) ON DELETE SET NULL,
    linked_dossier_id   UUID NULL
                        REFERENCES dossier(id) ON DELETE SET NULL,
    linked_thread_id    UUID NULL
                        REFERENCES chat_thread(id) ON DELETE SET NULL,

    link_confidence     NUMERIC(4,3) NOT NULL DEFAULT 0.000
                        CHECK (link_confidence >= 0.000 AND link_confidence <= 1.000),
    link_method         TEXT NULL
                        CHECK (link_method IS NULL OR link_method IN (
                            'name_match',
                            'alias',
                            'prefix_match',
                            'manual',
                            'none'
                        )),

    -- stato operativo (ciclo di vita)
    stato               TEXT NOT NULL DEFAULT 'aperto'
                        CHECK (stato IN (
                            'aperto',
                            'rimandato',
                            'fatto',
                            'cancellato'
                        )),

    -- voice metadata (opzionali, solo se origine voce)
    voice_duration_s    INTEGER NULL
                        CHECK (voice_duration_s IS NULL OR voice_duration_s >= 0),
    voice_source        TEXT NULL
                        CHECK (voice_source IS NULL OR voice_source IN (
                            'whisper_local',
                            'native_stt',
                            'fallback'
                        )),

    -- timestamps
    creato_il           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    fatto_il            TIMESTAMPTZ NULL
);

-- Indice principale: lista appunti dell'utente per stato e data
CREATE INDEX IF NOT EXISTS idx_appunti_rapidi_owner_stato
    ON appunti_rapidi(proprietario_id, stato, creato_il DESC);

-- Indice partial: lookup veloce "appunti aperti collegati a contatto X"
-- (query calda usata da pending-for-context con context_type=chat|relation)
CREATE INDEX IF NOT EXISTS idx_appunti_rapidi_open_by_contact
    ON appunti_rapidi(proprietario_id, linked_contact_id)
    WHERE stato = 'aperto' AND linked_contact_id IS NOT NULL;

-- Indice partial: lookup "appunti aperti collegati a thread X"
CREATE INDEX IF NOT EXISTS idx_appunti_rapidi_open_by_thread
    ON appunti_rapidi(proprietario_id, linked_thread_id)
    WHERE stato = 'aperto' AND linked_thread_id IS NOT NULL;

-- Indice partial: lookup "appunti aperti collegati a dossier X"
CREATE INDEX IF NOT EXISTS idx_appunti_rapidi_open_by_dossier
    ON appunti_rapidi(proprietario_id, linked_dossier_id)
    WHERE stato = 'aperto' AND linked_dossier_id IS NOT NULL;


-- ===========================================================================
-- appunto_emergence_trigger
-- ===========================================================================
-- Meccanismo per far riemergere un appunto quando l'utente apre un contesto
-- pertinente. Un appunto può avere più trigger (es. contatto + tempo).
--
-- proprietario_id è denormalizzato (FK separata, non solo via appunto_id):
-- la query calda è "dato il proprietario corrente e un contesto, dimmi i
-- trigger attivi". Evitare il JOIN su appunti_rapidi rende l'index lookup
-- O(log n) su (proprietario_id, attivo, tipo).

CREATE TABLE IF NOT EXISTS appunto_emergence_trigger (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    appunto_id          UUID NOT NULL
                        REFERENCES appunti_rapidi(id) ON DELETE CASCADE,

    -- denormalizzazione necessaria (vedi nota sopra)
    proprietario_id     UUID NOT NULL
                        REFERENCES utenti(id) ON DELETE CASCADE,

    -- tipo di trigger
    tipo                TEXT NOT NULL
                        CHECK (tipo IN (
                            'chat_open',
                            'relation_open',
                            'dossier_open',
                            'time_at'
                        )),

    -- parametri specifici del trigger:
    --   chat_open       → {"thread_id": "..."}  oppure {"contact_id": "..."}
    --   relation_open   → {"contact_id": "..."}
    --   dossier_open    → {"dossier_id": "..."}
    --   time_at         → {"at": "2026-06-01T09:00:00Z"}
    parametri           JSONB NOT NULL DEFAULT '{}'::jsonb,

    -- attivo: false dopo fired/canceled, oppure se utente disattiva il singolo trigger
    attivo              BOOLEAN NOT NULL DEFAULT TRUE,

    -- diagnostica leggera (non telemetria comportamentale: campi visibili
    -- solo all'owner, mai aggregati né esportati)
    ultimo_match        TIMESTAMPTZ NULL,
    emerso_count        INTEGER NOT NULL DEFAULT 0,

    creato_il           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indice principale: lookup trigger attivi per owner+tipo
CREATE INDEX IF NOT EXISTS idx_appunto_emergence_owner_tipo_attivo
    ON appunto_emergence_trigger(proprietario_id, tipo, attivo);

-- Indice di navigazione inversa
CREATE INDEX IF NOT EXISTS idx_appunto_emergence_appunto
    ON appunto_emergence_trigger(appunto_id);

-- NOTA V-PT-CORE-01R: l'indice expression-based su ((parametri->>'at')::timestamptz)
-- è stato RIMOSSO da CORE-01. Motivo: il poller scheduler per trigger time_at
-- è rinviato a V-PT-CORE-02; creare l'indice prima del suo consumer è prematuro
-- e può causare ambiguità di parsing su alcune versioni PostgreSQL.
-- Quando arriverà CORE-02, la migration dedicata aggiungerà l'indice insieme
-- al poller che lo userà davvero.


-- ===========================================================================
-- Commenti documentativi (visibili da \d in psql; utili per audit)
-- ===========================================================================
COMMENT ON TABLE  appunti_rapidi IS
    'V-PT-CORE-01: Quick Notes (appunti rapidi) del proprietario. Distinti dalle Memorie. Linker server-side con telemetria zero.';
COMMENT ON COLUMN appunti_rapidi.origine IS
    'V-PT-CORE-01: come è stata creata la nota. wake_word/long_press/etc. Backend non vede mai audio.';
COMMENT ON COLUMN appunti_rapidi.testo IS
    'V-PT-CORE-01: contenuto raw. MAI loggato, MAI emesso in metriche.';
COMMENT ON COLUMN appunti_rapidi.link_confidence IS
    'V-PT-CORE-01: 0..1, confidenza del linker. 0 = nessun link.';
COMMENT ON TABLE  appunto_emergence_trigger IS
    'V-PT-CORE-01: trigger che fanno riemergere un appunto in un contesto pertinente.';

COMMIT;
