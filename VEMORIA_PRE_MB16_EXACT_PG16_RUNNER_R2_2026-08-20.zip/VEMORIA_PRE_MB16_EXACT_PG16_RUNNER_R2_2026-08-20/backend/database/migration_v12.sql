-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V3.1 — Migration V12 — Document Event Engine
CREATE TABLE IF NOT EXISTS document_event (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tipo_evento  TEXT NOT NULL,
    descrizione  TEXT,
    foto_path    TEXT,
    documento_id UUID REFERENCES documenti(id) ON DELETE SET NULL,
    dossier_id   UUID REFERENCES dossier(id)   ON DELETE SET NULL,
    utente_id    UUID NOT NULL,
    creato_il    TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_doc_event_documento ON document_event(documento_id);
CREATE INDEX IF NOT EXISTS idx_doc_event_dossier   ON document_event(dossier_id);
CREATE INDEX IF NOT EXISTS idx_doc_event_utente    ON document_event(utente_id);
CREATE INDEX IF NOT EXISTS idx_doc_event_creato    ON document_event(creato_il DESC);
