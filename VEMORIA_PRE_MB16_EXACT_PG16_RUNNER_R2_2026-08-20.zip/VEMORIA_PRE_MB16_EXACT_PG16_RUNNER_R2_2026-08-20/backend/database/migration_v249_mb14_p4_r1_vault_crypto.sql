-- ===========================================================================
-- VEMORA V249 — MB14-P4-R1 Vault Security Closure
-- ===========================================================================
-- Scope:
--   1. Add per-owner vault key salt table.
--   2. Add crypto envelope/version columns to vault_item.
--   3. Add PIN rate-limiting columns to vault_pin.
--   4. Provide RLS owner isolation.
--
-- NON modifica MB0→MB14-P4; solo additive.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- 1. Owner-specific key salt (master key lives outside the database).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vault_key (
    owner_user_id       UUID PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    key_salt            TEXT NOT NULL,
    crypto_version      INTEGER NOT NULL DEFAULT 1,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE vault_key ENABLE ROW LEVEL SECURITY;
ALTER TABLE vault_key FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS vault_key_owner_isolation ON vault_key;
CREATE POLICY vault_key_owner_isolation ON vault_key
    FOR ALL
    USING (owner_user_id = _rls_owner_uuid())
    WITH CHECK (owner_user_id = _rls_owner_uuid());

-- ---------------------------------------------------------------------------
-- 2. Crypto envelope columns on vault_item.
-- ---------------------------------------------------------------------------
ALTER TABLE vault_item
    ADD COLUMN IF NOT EXISTS crypto_version INTEGER NOT NULL DEFAULT 0;

ALTER TABLE vault_item
    ADD COLUMN IF NOT EXISTS crypto_envelope JSONB;

-- ---------------------------------------------------------------------------
-- 3. PIN rate-limiting columns on vault_pin.
-- ---------------------------------------------------------------------------
ALTER TABLE vault_pin
    ADD COLUMN IF NOT EXISTS failed_attempts INTEGER NOT NULL DEFAULT 0;

ALTER TABLE vault_pin
    ADD COLUMN IF NOT EXISTS locked_until TIMESTAMPTZ;

-- ---------------------------------------------------------------------------
-- 4. Grants.
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'vemoria_app_user') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON vault_key TO vemoria_app_user;
    END IF;

    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p2_api') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON vault_key TO mb13_p2_api;
    END IF;
END $$;
