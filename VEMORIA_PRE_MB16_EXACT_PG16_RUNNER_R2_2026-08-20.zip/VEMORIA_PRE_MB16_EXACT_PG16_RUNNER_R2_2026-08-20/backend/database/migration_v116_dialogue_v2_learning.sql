-- Vemoria — Dialogo Operativo V2
-- Migration v116: apprendimento personale locale e memoria correzioni.
-- Additiva, non distruttiva.

CREATE TABLE IF NOT EXISTS dialogue_personal_rule (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    utente_id UUID NOT NULL,
    scope TEXT NOT NULL DEFAULT 'global',
    rule_type TEXT NOT NULL DEFAULT 'operational_preference',
    rule_text TEXT NOT NULL,
    confidence NUMERIC(4,3) NOT NULL DEFAULT 0.700,
    source_turn TEXT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_dialogue_personal_rule_user_active
    ON dialogue_personal_rule (utente_id, is_active, updated_at DESC);

CREATE INDEX IF NOT EXISTS idx_dialogue_personal_rule_scope
    ON dialogue_personal_rule (utente_id, scope, is_active);

CREATE TABLE IF NOT EXISTS dialogue_correction_memory (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    utente_id UUID NOT NULL,
    scope TEXT NOT NULL DEFAULT 'global',
    correction_summary TEXT NOT NULL,
    extracted_rule TEXT NOT NULL,
    confidence NUMERIC(4,3) NOT NULL DEFAULT 0.700,
    source_turn TEXT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_dialogue_correction_memory_user_created
    ON dialogue_correction_memory (utente_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_dialogue_correction_memory_scope
    ON dialogue_correction_memory (utente_id, scope, created_at DESC);

-- Aggiorna updated_at sulle regole personali.
CREATE OR REPLACE FUNCTION dialogue_personal_rule_touch_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_dialogue_personal_rule_touch_updated_at ON dialogue_personal_rule;
CREATE TRIGGER trg_dialogue_personal_rule_touch_updated_at
BEFORE UPDATE ON dialogue_personal_rule
FOR EACH ROW EXECUTE FUNCTION dialogue_personal_rule_touch_updated_at();
