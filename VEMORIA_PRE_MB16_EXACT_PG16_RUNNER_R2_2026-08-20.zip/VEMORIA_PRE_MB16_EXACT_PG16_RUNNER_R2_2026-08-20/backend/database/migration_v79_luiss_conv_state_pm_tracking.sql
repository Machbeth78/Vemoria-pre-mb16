-- VEMORA -- Migration V79 -- Conversation State: PM token tracking
-- Data: 2026-04-11
-- Autore: Devoti Massimo
--
-- Obiettivo:
--   Aggiunge due colonne nullable a luiss_conversation_state per tracciare
--   quale token di personal memory e' stato USATO nell'ultimo turno.
--
--   Queste colonne servono al pattern used -> confirmed:
--     - turno N:   resolver usa un token PM -> salva last_pm_token/last_pm_type
--     - turno N+1: se NON e' F4 -> conferma (incrementa confirmed_count)
--                  se F4         -> invalida (decrementa confirmed_count)
--
--   Senza questi campi persistiti, il ramo di invalidazione F4 era codice morto.
--
-- Idempotente: ADD COLUMN IF NOT EXISTS.

ALTER TABLE luiss_conversation_state
    ADD COLUMN IF NOT EXISTS last_pm_token TEXT,
    ADD COLUMN IF NOT EXISTS last_pm_type  TEXT
        CHECK (last_pm_type IN ('role', 'alias'));
