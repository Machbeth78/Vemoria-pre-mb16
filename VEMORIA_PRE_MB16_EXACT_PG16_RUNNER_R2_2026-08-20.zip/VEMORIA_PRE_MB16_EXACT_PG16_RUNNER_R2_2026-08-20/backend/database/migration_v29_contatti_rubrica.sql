-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V4.6 — Migration V29 — contatti_rubrica
CREATE TABLE IF NOT EXISTS contatti_rubrica (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    display_name    TEXT NOT NULL,
    email           TEXT,
    phone           TEXT,
    source          TEXT NOT NULL DEFAULT 'device' CHECK (source IN ('device','manuale')),
    registrato      BOOLEAN,
    registrato_utente_id UUID REFERENCES utenti(id) ON DELETE SET NULL,
    creato_il       TIMESTAMP NOT NULL DEFAULT NOW(),
    aggiornato_il   TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, email, phone)
);
CREATE INDEX IF NOT EXISTS idx_contatti_utente ON contatti_rubrica(utente_id);
CREATE INDEX IF NOT EXISTS idx_contatti_email  ON contatti_rubrica(email);
CREATE INDEX IF NOT EXISTS idx_contatti_phone  ON contatti_rubrica(phone);
CREATE INDEX IF NOT EXISTS idx_contatti_registrato ON contatti_rubrica(registrato);
