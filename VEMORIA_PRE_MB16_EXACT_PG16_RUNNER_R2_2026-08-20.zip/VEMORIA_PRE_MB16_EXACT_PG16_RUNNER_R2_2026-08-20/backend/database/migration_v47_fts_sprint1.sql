-- VEMORA — Migration V47 — FTS Sprint 1
-- Data: 2026-04-11
-- Autore: Devoti Massimo
--
-- Obiettivo: portare la ricerca su memorie da ILIKE a FTS reale.
--
-- Strategia scelta: expression index (no ALTER TABLE, no trigger).
--   - Nessuna modifica alla struttura della tabella memorie.
--   - Reversibile con DROP INDEX.
--   - Compatibile con DB esistenti senza riscrittura della tabella.
--   - PostgreSQL 15 (docker-compose postgres:15).
--
-- Pesi tsvector:
--   A = titolo       (peso massimo)
--   B = riassunto    (peso medio)
--   C = testo_completo (peso basso — testo OCR grezzo, potenzialmente lungo)
--
-- Note:
--   - idx_memorie_fts (V1) copriva solo titolo+riassunto. Non dropparlo
--     in questo sprint: serve come fallback se il planner preferisce quello
--     per query senza testo_completo. Dropparlo nel prossimo sprint dopo EXPLAIN.
--   - idx_memorie_tags_gin è nuovo: permette ricerca tag esatta via @>.
--   - NON si usa CREATE INDEX CONCURRENTLY perché questo file viene eseguito
--     da psql in sessione singola (stesso pattern di tutte le migration del progetto).
--     Se si vuole CONCURRENTLY, eseguire il CREATE INDEX manualmente fuori transazione.

-- ── 1. Expression index FTS con pesi A/B/C su memorie ──────────────────────
CREATE INDEX IF NOT EXISTS idx_memorie_fts_v2 ON memorie
    USING GIN (
        (
            setweight(to_tsvector('italian', coalesce(titolo, '')),          'A') ||
            setweight(to_tsvector('italian', coalesce(riassunto, '')),        'B') ||
            setweight(to_tsvector('italian', coalesce(testo_completo, '')),   'C')
        )
    );

-- ── 2. GIN su tags JSONB per ricerca esatta elemento ───────────────────────
-- Permette: WHERE tags @> '["nomtag"]'::jsonb
-- Non promette indicizzazione per ILIKE su substring dentro tag.
CREATE INDEX IF NOT EXISTS idx_memorie_tags_gin ON memorie USING GIN (tags);

-- ── 3. Indice parziale composito utente+stato per filtro sempre presente ───
-- Tutte le query filtrano proprietario_id + stato = 'attiva'.
-- L'indice parziale elimina il filtro stato dal scan residuo.
CREATE INDEX IF NOT EXISTS idx_memorie_owner_attiva
    ON memorie (proprietario_id, creata_il DESC)
    WHERE stato = 'attiva';
