-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB12-P0 — Rule, Clause, Obligation and Eligibility Foundation.
-- Additive, idempotent migration.

BEGIN;

CREATE TABLE IF NOT EXISTS mb12_p0_rule_projection (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    rule_id TEXT NOT NULL,
    stable_id TEXT NOT NULL,
    revision TEXT NOT NULL DEFAULT '1',
    canonical_name TEXT NOT NULL,
    state TEXT NOT NULL DEFAULT 'draft',
    subjects JSONB NOT NULL DEFAULT '[]',
    territories JSONB NOT NULL DEFAULT '[]',
    periods JSONB NOT NULL DEFAULT '[]',
    requirements JSONB NOT NULL DEFAULT '[]',
    exceptions JSONB NOT NULL DEFAULT '[]',
    consequences JSONB NOT NULL DEFAULT '[]',
    clauses JSONB NOT NULL DEFAULT '[]',
    source_refs JSONB NOT NULL DEFAULT '[]',
    valid_from TIMESTAMPTZ,
    valid_to TIMESTAMPTZ,
    jurisdiction_state TEXT NOT NULL DEFAULT 'unknown',
    territory_state TEXT NOT NULL DEFAULT '',
    confidence REAL NOT NULL DEFAULT 1.0,
    uncertainty JSONB NOT NULL DEFAULT '{}',
    revocation JSONB,
    data JSONB NOT NULL DEFAULT '{}',
    provenance JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, rule_id)
);

CREATE INDEX IF NOT EXISTS idx_mb12_p0_rule_state_owner
    ON mb12_p0_rule_projection(owner_user_id, state);

ALTER TABLE mb12_p0_rule_projection ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb12_p0_rule_projection FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb12_p0_rule_projection_owner_policy ON mb12_p0_rule_projection;
CREATE POLICY mb12_p0_rule_projection_owner_policy ON mb12_p0_rule_projection
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

CREATE TABLE IF NOT EXISTS mb12_p0_clause_projection (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    clause_id TEXT NOT NULL,
    stable_id TEXT NOT NULL,
    revision TEXT NOT NULL DEFAULT '1',
    canonical_name TEXT NOT NULL,
    state TEXT NOT NULL DEFAULT 'draft',
    parent_rule TEXT,
    obligations JSONB NOT NULL DEFAULT '[]',
    costs JSONB NOT NULL DEFAULT '[]',
    penalties JSONB NOT NULL DEFAULT '[]',
    exclusions JSONB NOT NULL DEFAULT '[]',
    renewals JSONB NOT NULL DEFAULT '[]',
    risks JSONB NOT NULL DEFAULT '[]',
    source_refs JSONB NOT NULL DEFAULT '[]',
    valid_from TIMESTAMPTZ,
    valid_to TIMESTAMPTZ,
    jurisdiction_state TEXT NOT NULL DEFAULT 'unknown',
    territory_state TEXT NOT NULL DEFAULT '',
    confidence REAL NOT NULL DEFAULT 1.0,
    uncertainty JSONB NOT NULL DEFAULT '{}',
    revocation JSONB,
    data JSONB NOT NULL DEFAULT '{}',
    provenance JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, clause_id)
);

ALTER TABLE mb12_p0_clause_projection ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb12_p0_clause_projection FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb12_p0_clause_projection_owner_policy ON mb12_p0_clause_projection;
CREATE POLICY mb12_p0_clause_projection_owner_policy ON mb12_p0_clause_projection
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

CREATE TABLE IF NOT EXISTS mb12_p0_subject_role_projection (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    role_id TEXT NOT NULL,
    stable_id TEXT NOT NULL,
    role_name TEXT NOT NULL,
    subject_identifiers JSONB NOT NULL DEFAULT '[]',
    source_refs JSONB NOT NULL DEFAULT '[]',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, role_id)
);

ALTER TABLE mb12_p0_subject_role_projection ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb12_p0_subject_role_projection FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb12_p0_subject_role_projection_owner_policy ON mb12_p0_subject_role_projection;
CREATE POLICY mb12_p0_subject_role_projection_owner_policy ON mb12_p0_subject_role_projection
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

CREATE TABLE IF NOT EXISTS mb12_p0_eligibility_evaluation_log (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    evaluation_id TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    result TEXT NOT NULL,
    criteria JSONB NOT NULL DEFAULT '[]',
    missing JSONB NOT NULL DEFAULT '[]',
    evidence JSONB NOT NULL DEFAULT '[]',
    conflicting_rules JSONB NOT NULL DEFAULT '[]',
    evaluated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    legal_certainty REAL NOT NULL DEFAULT 0.0,
    PRIMARY KEY (owner_user_id, evaluation_id)
);

CREATE INDEX IF NOT EXISTS idx_mb12_p0_eligibility_owner_subject
    ON mb12_p0_eligibility_evaluation_log(owner_user_id, subject_id);

ALTER TABLE mb12_p0_eligibility_evaluation_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb12_p0_eligibility_evaluation_log FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb12_p0_eligibility_evaluation_log_owner_policy ON mb12_p0_eligibility_evaluation_log;
CREATE POLICY mb12_p0_eligibility_evaluation_log_owner_policy ON mb12_p0_eligibility_evaluation_log
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

CREATE TABLE IF NOT EXISTS mb12_p0_revision_history (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    record_id TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    revision TEXT NOT NULL DEFAULT '1',
    operation TEXT NOT NULL,
    payload JSONB NOT NULL,
    source_refs JSONB NOT NULL DEFAULT '[]',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, record_id, revision, operation)
);

-- Additive migration: widen primary key if the table was created with only (owner_user_id, record_id).
DO $$
BEGIN
    ALTER TABLE mb12_p0_revision_history
        DROP CONSTRAINT mb12_p0_revision_history_pkey;
    ALTER TABLE mb12_p0_revision_history
        ADD PRIMARY KEY (owner_user_id, record_id, revision, operation);
EXCEPTION WHEN invalid_table_definition THEN
    NULL;
END $$;

CREATE INDEX IF NOT EXISTS idx_mb12_p0_revision_history_owner
    ON mb12_p0_revision_history(owner_user_id, record_id);

ALTER TABLE mb12_p0_revision_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb12_p0_revision_history FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb12_p0_revision_history_owner_policy ON mb12_p0_revision_history;
CREATE POLICY mb12_p0_revision_history_owner_policy ON mb12_p0_revision_history
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

COMMIT;
