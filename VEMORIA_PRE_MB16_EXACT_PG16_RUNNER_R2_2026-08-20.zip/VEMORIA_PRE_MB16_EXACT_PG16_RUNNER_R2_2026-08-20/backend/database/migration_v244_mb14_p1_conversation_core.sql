-- ===========================================================================
-- VEMORA V244 — MB14-P1 Conversation Core
-- ===========================================================================
-- Scope:
--   1. Owner-scoped conversation, participant, message, draft and delivery tables.
--   2. Conversation as a child of relationship (DIRECT foundation).
--   3. Send authorization states, offline queue, idempotency and delivery truth.
--   4. Row Level Security with FORCE RLS on all conversation tables.
--   5. Indexes for owner-scoped list, search and timeline.
--
-- NON modifica le tabelle frozen MB0→MB13 / MB14-P0; soltanto tabelle additive.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- 1. conversation
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS conversation (
    conversation_id   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id     UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id   UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    conversation_type TEXT NOT NULL
        CHECK (conversation_type IN ('DIRECT','GROUP','INSTITUTIONAL','SYSTEM')),
    title             TEXT,
    status            TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active','archived','blocked','removed')),
    last_activity_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    archived_at       TIMESTAMPTZ,
    removed_at        TIMESTAMPTZ,
    provenance        JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_conversation_owner
    ON conversation(owner_user_id);
CREATE INDEX IF NOT EXISTS idx_conversation_relationship
    ON conversation(owner_user_id, relationship_id);
CREATE INDEX IF NOT EXISTS idx_conversation_last_activity
    ON conversation(owner_user_id, last_activity_at DESC);
CREATE INDEX IF NOT EXISTS idx_conversation_status
    ON conversation(owner_user_id, status);

-- ---------------------------------------------------------------------------
-- 2. conversation_participant (foundation for future GROUP, now 1:N)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS conversation_participant (
    participant_id    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id     UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    conversation_id   UUID NOT NULL REFERENCES conversation(conversation_id) ON DELETE CASCADE,
    relationship_id   UUID REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    participant_role  TEXT NOT NULL DEFAULT 'member',
    joined_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    left_at           TIMESTAMPTZ,
    status            TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active','left','removed','blocked')),
    UNIQUE (owner_user_id, conversation_id, relationship_id)
);

CREATE INDEX IF NOT EXISTS idx_conversation_participant_owner_conv
    ON conversation_participant(owner_user_id, conversation_id);
CREATE INDEX IF NOT EXISTS idx_conversation_participant_rel
    ON conversation_participant(owner_user_id, relationship_id);

-- ---------------------------------------------------------------------------
-- 3. conversation_message
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS conversation_message (
    message_id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    conversation_id     UUID NOT NULL REFERENCES conversation(conversation_id) ON DELETE CASCADE,
    sender_reference    TEXT NOT NULL DEFAULT 'owner',    -- 'owner' | relationship_id | system
    direction           TEXT NOT NULL
        CHECK (direction IN ('INBOUND','OUTBOUND','LOCAL_SYSTEM')),
    message_type        TEXT NOT NULL
        CHECK (message_type IN ('TEXT','ATTACHMENT','CARD','SYSTEM_EVENT')),
    body                TEXT NOT NULL DEFAULT '',
    body_format         TEXT NOT NULL DEFAULT 'plain'
        CHECK (body_format IN ('plain','markdown','structured')),
    delivery_state      TEXT NOT NULL DEFAULT 'DRAFT'
        CHECK (delivery_state IN (
            'DRAFT','QUEUED','SENDING','SENT','DELIVERED','FAILED','RECEIVED','READ'
        )),
    reply_to_message_id UUID REFERENCES conversation_message(message_id) ON DELETE SET NULL,
    correlation_id      TEXT NOT NULL,                      -- idempotency key
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    received_at         TIMESTAMPTZ,
    sent_at             TIMESTAMPTZ,
    provenance          JSONB NOT NULL DEFAULT '{}'::jsonb,
    integrity_hash      TEXT,
    UNIQUE (owner_user_id, correlation_id)
);

CREATE INDEX IF NOT EXISTS idx_conversation_message_owner_conv
    ON conversation_message(owner_user_id, conversation_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_conversation_message_correlation
    ON conversation_message(owner_user_id, correlation_id);
CREATE INDEX IF NOT EXISTS idx_conversation_message_state
    ON conversation_message(owner_user_id, delivery_state);
CREATE INDEX IF NOT EXISTS idx_conversation_message_body_search
    ON conversation_message USING gin(to_tsvector('simple', body));

-- ---------------------------------------------------------------------------
-- 4. conversation_draft (owner-scoped drafts; separate from sent messages)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS conversation_draft (
    draft_id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id     UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    conversation_id   UUID NOT NULL REFERENCES conversation(conversation_id) ON DELETE CASCADE,
    body              TEXT NOT NULL DEFAULT '',
    message_type      TEXT NOT NULL DEFAULT 'TEXT'
        CHECK (message_type IN ('TEXT','ATTACHMENT','CARD','SYSTEM_EVENT')),
    attachment_refs   JSONB NOT NULL DEFAULT '[]'::jsonb,
    correlation_id    TEXT NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (owner_user_id, conversation_id)
);

CREATE INDEX IF NOT EXISTS idx_conversation_draft_owner_conv
    ON conversation_draft(owner_user_id, conversation_id);

-- ---------------------------------------------------------------------------
-- 5. message_attachment_reference (reference, not storage)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS message_attachment_reference (
    reference_id      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id     UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    message_id        UUID REFERENCES conversation_message(message_id) ON DELETE CASCADE,
    draft_id          UUID REFERENCES conversation_draft(draft_id) ON DELETE CASCADE,
    attachment_id     TEXT NOT NULL,    -- external canonical document/file id
    attachment_type   TEXT NOT NULL DEFAULT 'generic'
        CHECK (attachment_type IN ('generic','document','image','audio','card')),
    permission_scope  TEXT NOT NULL DEFAULT 'private',
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (message_id IS NOT NULL OR draft_id IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS idx_message_attachment_owner_msg
    ON message_attachment_reference(owner_user_id, message_id);
CREATE INDEX IF NOT EXISTS idx_message_attachment_owner_draft
    ON message_attachment_reference(owner_user_id, draft_id);

-- ---------------------------------------------------------------------------
-- 6. conversation_message_delivery_state (per-transport delivery truth)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS conversation_message_delivery_state (
    delivery_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id     UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    message_id        UUID NOT NULL REFERENCES conversation_message(message_id) ON DELETE CASCADE,
    transport_type    TEXT NOT NULL
        CHECK (transport_type IN ('VEMORIA_INTERNAL','EMAIL','SMS','OTHER_GOVERNED_TRANSPORT')),
    state             TEXT NOT NULL
        CHECK (state IN ('QUEUED','SENDING','SENT','DELIVERED','FAILED','READ')),
    state_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    evidence          JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_message_delivery_owner_msg
    ON conversation_message_delivery_state(owner_user_id, message_id, state_at DESC);

-- ---------------------------------------------------------------------------
-- 7. conversation_timeline_event (canonical timeline integration)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS conversation_timeline_event (
    event_id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id     UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    conversation_id   UUID NOT NULL REFERENCES conversation(conversation_id) ON DELETE CASCADE,
    message_id        UUID REFERENCES conversation_message(message_id) ON DELETE SET NULL,
    event_type        TEXT NOT NULL
        CHECK (event_type IN (
            'conversation_created','message_drafted','message_authorized','message_queued',
            'message_sent','message_failed','message_received','message_read','conversation_archived'
        )),
    event_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    source            TEXT NOT NULL DEFAULT 'conversation_service',
    evidence          JSONB NOT NULL DEFAULT '{}'::jsonb,
    provenance        JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_conversation_timeline_owner_conv
    ON conversation_timeline_event(owner_user_id, conversation_id, event_at DESC);

-- ---------------------------------------------------------------------------
-- 8. Trigger: update conversation.last_activity_at on message insert
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION conversation_update_last_activity()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE conversation
    SET last_activity_at = NEW.created_at,
        updated_at = NOW()
    WHERE conversation_id = NEW.conversation_id
      AND owner_user_id = NEW.owner_user_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_conversation_message_last_activity ON conversation_message;
CREATE TRIGGER trg_conversation_message_last_activity
    AFTER INSERT ON conversation_message
    FOR EACH ROW
    EXECUTE FUNCTION conversation_update_last_activity();

-- ---------------------------------------------------------------------------
-- 9. RLS owner isolation
--
-- Helper function to read the runtime owner from the app GUC.
-- Policies also enforce parent-table ownership so a row cannot be attached
-- to a conversation/relationship owned by another owner through raw SQL.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION _rls_owner_uuid()
RETURNS UUID AS $$
BEGIN
    RETURN NULLIF(current_setting('app.owner_id', true), '')::uuid;
END;
$$ LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION _rls_owner_uuid() TO PUBLIC;

DO $$
BEGIN
    ALTER TABLE conversation ENABLE ROW LEVEL SECURITY;
    ALTER TABLE conversation FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS conversation_owner_isolation ON conversation;
    CREATE POLICY conversation_owner_isolation ON conversation
        FOR ALL
        USING (owner_user_id = _rls_owner_uuid())
        WITH CHECK (owner_user_id = _rls_owner_uuid());

    ALTER TABLE conversation_participant ENABLE ROW LEVEL SECURITY;
    ALTER TABLE conversation_participant FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS conversation_participant_owner_isolation ON conversation_participant;
    CREATE POLICY conversation_participant_owner_isolation ON conversation_participant
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND conversation_id IN (SELECT conversation_id FROM conversation)
            AND (relationship_id IS NULL OR relationship_id IN (SELECT relationship_id FROM relationship))
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND conversation_id IN (SELECT conversation_id FROM conversation)
            AND (relationship_id IS NULL OR relationship_id IN (SELECT relationship_id FROM relationship))
        );

    ALTER TABLE conversation_message ENABLE ROW LEVEL SECURITY;
    ALTER TABLE conversation_message FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS conversation_message_owner_isolation ON conversation_message;
    CREATE POLICY conversation_message_owner_isolation ON conversation_message
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND conversation_id IN (SELECT conversation_id FROM conversation)
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND conversation_id IN (SELECT conversation_id FROM conversation)
        );

    ALTER TABLE conversation_draft ENABLE ROW LEVEL SECURITY;
    ALTER TABLE conversation_draft FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS conversation_draft_owner_isolation ON conversation_draft;
    CREATE POLICY conversation_draft_owner_isolation ON conversation_draft
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND conversation_id IN (SELECT conversation_id FROM conversation)
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND conversation_id IN (SELECT conversation_id FROM conversation)
        );

    ALTER TABLE message_attachment_reference ENABLE ROW LEVEL SECURITY;
    ALTER TABLE message_attachment_reference FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS message_attachment_reference_owner_isolation ON message_attachment_reference;
    CREATE POLICY message_attachment_reference_owner_isolation ON message_attachment_reference
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND (
                message_id IS NULL
                OR message_id IN (SELECT message_id FROM conversation_message)
            )
            AND (
                draft_id IS NULL
                OR draft_id IN (SELECT draft_id FROM conversation_draft)
            )
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND (
                message_id IS NULL
                OR message_id IN (SELECT message_id FROM conversation_message)
            )
            AND (
                draft_id IS NULL
                OR draft_id IN (SELECT draft_id FROM conversation_draft)
            )
        );

    ALTER TABLE conversation_message_delivery_state ENABLE ROW LEVEL SECURITY;
    ALTER TABLE conversation_message_delivery_state FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS conversation_message_delivery_state_owner_isolation ON conversation_message_delivery_state;
    CREATE POLICY conversation_message_delivery_state_owner_isolation ON conversation_message_delivery_state
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND message_id IN (SELECT message_id FROM conversation_message)
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND message_id IN (SELECT message_id FROM conversation_message)
        );

    ALTER TABLE conversation_timeline_event ENABLE ROW LEVEL SECURITY;
    ALTER TABLE conversation_timeline_event FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS conversation_timeline_event_owner_isolation ON conversation_timeline_event;
    CREATE POLICY conversation_timeline_event_owner_isolation ON conversation_timeline_event
        FOR ALL
        USING (
            owner_user_id = _rls_owner_uuid()
            AND conversation_id IN (SELECT conversation_id FROM conversation)
        )
        WITH CHECK (
            owner_user_id = _rls_owner_uuid()
            AND conversation_id IN (SELECT conversation_id FROM conversation)
        );
END $$;

-- ---------------------------------------------------------------------------
-- 10. Least-privilege grants for dedicated API role if present
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p2_api') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE conversation TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE conversation_participant TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE conversation_message TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE conversation_draft TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE message_attachment_reference TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE conversation_message_delivery_state TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE conversation_timeline_event TO mb13_p2_api;
    END IF;
END $$;
