-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.

-- Vemoria Fabric — route-independent transfer metadata and endpoint proof.
-- PostgreSQL only. No plaintext content, filenames, MIME types or document bodies.
-- Blind relay/deposit byte storage is a separate runtime and is referenced only
-- through opaque locator digests with mandatory expiry.

CREATE TABLE IF NOT EXISTS fabric_transfer_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    transfer_id TEXT NOT NULL,
    envelope_id TEXT,
    sender_device_pseudonym TEXT NOT NULL,
    recipient_device_pseudonym TEXT NOT NULL,
    manifest_digest_sha256 CHAR(64) NOT NULL,
    ciphertext_sha256 CHAR(64) NOT NULL,
    merkle_root_sha256 CHAR(64) NOT NULL,
    total_size_bytes BIGINT NOT NULL CHECK (total_size_bytes >= 0),
    chunk_size_bytes INTEGER NOT NULL CHECK (chunk_size_bytes BETWEEN 16384 AND 4194304),
    chunk_count INTEGER NOT NULL CHECK (chunk_count >= 0),
    service_tier TEXT NOT NULL DEFAULT 'base'
        CHECK (service_tier IN ('base','protected_line','certified')),
    privacy_mode TEXT NOT NULL DEFAULT 'standard'
        CHECK (privacy_mode IN ('standard','protected')),
    proof_required BOOLEAN NOT NULL DEFAULT FALSE,
    assisted_routes_authorized BOOLEAN NOT NULL DEFAULT FALSE,
    state TEXT NOT NULL DEFAULT 'queued'
        CHECK (state IN ('prepared','queued','discovering','connecting','transferring',
                         'paused','deposited','verifying','delivered','failed',
                         'cancelled','expired')),
    active_route TEXT
        CHECK (active_route IS NULL OR active_route IN
               ('direct_lan','owner_node','direct_quic','blind_relay','blind_deposit')),
    last_error_code TEXT,
    expires_at TIMESTAMPTZ,
    delivered_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_user_id, transfer_id)
);
CREATE INDEX IF NOT EXISTS idx_fabric_transfer_owner_state
    ON fabric_transfer_sessions(owner_user_id, state, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_fabric_transfer_expiry
    ON fabric_transfer_sessions(expires_at)
    WHERE state NOT IN ('delivered','failed','cancelled','expired');

CREATE TABLE IF NOT EXISTS fabric_route_attempts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    transfer_session_id UUID NOT NULL REFERENCES fabric_transfer_sessions(id) ON DELETE CASCADE,
    route TEXT NOT NULL
        CHECK (route IN ('direct_lan','owner_node','direct_quic','blind_relay','blind_deposit')),
    result TEXT NOT NULL
        CHECK (result IN ('in_progress','started','connected','connect_failed','paused','integrity_failed','verification_failed','failed','deposited','delivered')),
    acknowledged_chunk_count INTEGER NOT NULL DEFAULT 0 CHECK (acknowledged_chunk_count >= 0),
    error_code TEXT,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    finished_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_fabric_attempt_owner_transfer
    ON fabric_route_attempts(owner_user_id, transfer_session_id, started_at DESC);

CREATE TABLE IF NOT EXISTS fabric_endpoint_receipts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    transfer_session_id UUID NOT NULL REFERENCES fabric_transfer_sessions(id) ON DELETE CASCADE,
    receipt_id TEXT NOT NULL,
    endpoint_device_pseudonym TEXT NOT NULL,
    status TEXT NOT NULL
        CHECK (status IN ('prepared','deposited','retrieved','ciphertext_verified',
                          'opened','accepted','rejected','signed','expired','deleted')),
    receipt_payload JSONB NOT NULL,
    receipt_signature TEXT NOT NULL,
    observed_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_user_id, receipt_id)
);
CREATE INDEX IF NOT EXISTS idx_fabric_receipt_owner_transfer
    ON fabric_endpoint_receipts(owner_user_id, transfer_session_id, observed_at DESC);

CREATE TABLE IF NOT EXISTS fabric_blind_object_leases (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    transfer_session_id UUID NOT NULL REFERENCES fabric_transfer_sessions(id) ON DELETE CASCADE,
    blind_service_role TEXT NOT NULL
        CHECK (blind_service_role IN ('blind_relay','blind_deposit')),
    opaque_locator_digest CHAR(64) NOT NULL,
    ciphertext_size_bytes BIGINT NOT NULL CHECK (ciphertext_size_bytes >= 0),
    accepted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    retrieved_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ,
    CHECK (expires_at > accepted_at),
    UNIQUE(blind_service_role, opaque_locator_digest)
);
CREATE INDEX IF NOT EXISTS idx_fabric_blind_lease_expiry
    ON fabric_blind_object_leases(blind_service_role, expires_at)
    WHERE deleted_at IS NULL;

ALTER TABLE chat_messaggi DROP CONSTRAINT IF EXISTS chat_messaggi_transfer_state_check;
ALTER TABLE chat_messaggi ADD CONSTRAINT chat_messaggi_transfer_state_check CHECK (
    transfer_state IN ('not_required','draft','prepared','queued','discovering','waiting_peer',
                       'connecting','transferring','paused','deposited','verifying',
                       'delivered','read','failed','cancelled','expired')
);

COMMENT ON TABLE fabric_transfer_sessions IS
    'Control/proof metadata only. No plaintext names, MIME types or content bytes.';
COMMENT ON TABLE fabric_blind_object_leases IS
    'Opaque references to expiring ciphertext held by isolated blind runtimes.';
COMMENT ON COLUMN fabric_transfer_sessions.ciphertext_sha256 IS
    'Hash of freshly encrypted per-transfer ciphertext; never the original document hash.';
