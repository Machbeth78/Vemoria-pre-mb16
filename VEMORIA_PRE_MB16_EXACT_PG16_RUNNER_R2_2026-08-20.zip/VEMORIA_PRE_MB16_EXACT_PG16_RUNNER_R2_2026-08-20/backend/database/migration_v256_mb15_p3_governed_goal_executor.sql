-- MB15-P3 — Governed Goal Executor
-- Execution persistence, trace, and audit tables with owner RLS.

BEGIN;

CREATE TABLE IF NOT EXISTS mb15_p3_goal_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    plan_id UUID NOT NULL REFERENCES mb15_p2_goal_execution_plans(id) ON DELETE CASCADE,
    goal_id UUID NOT NULL,
    device_ref_hash TEXT NOT NULL DEFAULT '',
    state TEXT NOT NULL DEFAULT 'CREATED',
    current_step TEXT,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    cancelled_at TIMESTAMPTZ,
    failure_code TEXT,
    step_results JSONB NOT NULL DEFAULT '{}',
    authorization_refs JSONB NOT NULL DEFAULT '{}',
    verification_results JSONB NOT NULL DEFAULT '{}',
    trace_ref UUID,
    provenance JSONB NOT NULL DEFAULT '{}',
    query_count INTEGER NOT NULL DEFAULT 0,
    critical_path_ms JSONB NOT NULL DEFAULT '{}',
    fur_ms DOUBLE PRECISION,
    full_completion_ms DOUBLE PRECISION
);

CREATE INDEX IF NOT EXISTS idx_mb15_p3_goal_executions_owner ON mb15_p3_goal_executions(owner_id);
CREATE INDEX IF NOT EXISTS idx_mb15_p3_goal_executions_plan ON mb15_p3_goal_executions(plan_id);

CREATE TABLE IF NOT EXISTS mb15_p3_execution_steps (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    execution_id UUID NOT NULL REFERENCES mb15_p3_goal_executions(id) ON DELETE CASCADE,
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    step_id TEXT NOT NULL,
    step_type TEXT NOT NULL,
    state TEXT NOT NULL DEFAULT 'PENDING',
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    duration_ms DOUBLE PRECISION,
    result JSONB,
    failure_code TEXT,
    verification JSONB,
    authorization_ref TEXT,
    trace_id UUID,
    query_count INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_mb15_p3_execution_steps_execution ON mb15_p3_execution_steps(execution_id);
CREATE INDEX IF NOT EXISTS idx_mb15_p3_execution_steps_owner ON mb15_p3_execution_steps(owner_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_mb15_p3_execution_steps_unique ON mb15_p3_execution_steps(execution_id, step_id);

CREATE TABLE IF NOT EXISTS mb15_p3_execution_traces (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    execution_id UUID NOT NULL REFERENCES mb15_p3_goal_executions(id) ON DELETE CASCADE,
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    step_id TEXT,
    span_id TEXT NOT NULL,
    parent_span_id TEXT,
    component TEXT NOT NULL,
    start_ms DOUBLE PRECISION NOT NULL,
    end_ms DOUBLE PRECISION NOT NULL,
    duration_ms DOUBLE PRECISION NOT NULL,
    result_class TEXT NOT NULL,
    meta JSONB NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_mb15_p3_execution_traces_execution ON mb15_p3_execution_traces(execution_id);
CREATE INDEX IF NOT EXISTS idx_mb15_p3_execution_traces_owner ON mb15_p3_execution_traces(owner_id);

CREATE TABLE IF NOT EXISTS mb15_p3_cancellations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    execution_id UUID NOT NULL REFERENCES mb15_p3_goal_executions(id) ON DELETE CASCADE,
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    reason TEXT NOT NULL,
    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    state TEXT NOT NULL DEFAULT 'CANCELLATION_PENDING'
);

CREATE INDEX IF NOT EXISTS idx_mb15_p3_cancellations_execution ON mb15_p3_cancellations(execution_id);
CREATE INDEX IF NOT EXISTS idx_mb15_p3_cancellations_owner ON mb15_p3_cancellations(owner_id);

ALTER TABLE mb15_p3_goal_executions ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb15_p3_execution_steps ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb15_p3_execution_traces ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb15_p3_cancellations ENABLE ROW LEVEL SECURITY;

ALTER TABLE mb15_p3_goal_executions FORCE ROW LEVEL SECURITY;
ALTER TABLE mb15_p3_execution_steps FORCE ROW LEVEL SECURITY;
ALTER TABLE mb15_p3_execution_traces FORCE ROW LEVEL SECURITY;
ALTER TABLE mb15_p3_cancellations FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb15_p3_goal_executions_owner_isolation ON mb15_p3_goal_executions;
CREATE POLICY mb15_p3_goal_executions_owner_isolation ON mb15_p3_goal_executions
    USING (owner_id = _rls_owner_uuid())
    WITH CHECK (owner_id = _rls_owner_uuid());

DROP POLICY IF EXISTS mb15_p3_execution_steps_owner_isolation ON mb15_p3_execution_steps;
CREATE POLICY mb15_p3_execution_steps_owner_isolation ON mb15_p3_execution_steps
    USING (owner_id = _rls_owner_uuid())
    WITH CHECK (owner_id = _rls_owner_uuid());

DROP POLICY IF EXISTS mb15_p3_execution_traces_owner_isolation ON mb15_p3_execution_traces;
CREATE POLICY mb15_p3_execution_traces_owner_isolation ON mb15_p3_execution_traces
    USING (owner_id = _rls_owner_uuid())
    WITH CHECK (owner_id = _rls_owner_uuid());

DROP POLICY IF EXISTS mb15_p3_cancellations_owner_isolation ON mb15_p3_cancellations;
CREATE POLICY mb15_p3_cancellations_owner_isolation ON mb15_p3_cancellations
    USING (owner_id = _rls_owner_uuid())
    WITH CHECK (owner_id = _rls_owner_uuid());

COMMIT;
