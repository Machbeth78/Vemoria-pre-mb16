-- ============================================================================
-- VEMORA — Migration v113 — Backend A PLUS / DEVIN READY
-- ============================================================================
-- Data:      2026-05-22
-- Autore:    OPUS Backend A PLUS pack
-- Scopo:     Migliorie sicure additive sopra v112. NESSUNA modifica logica.
--
-- VINCOLI HARD:
-- - Tutto additivo. Nessun ALTER su tabelle preesistenti SALVO ADD COLUMN
--   con default sicuro (idempotent_keys è tabella nuova).
-- - Idempotente: CREATE TABLE IF NOT EXISTS, CREATE INDEX IF NOT EXISTS.
-- - Compatibile con PostgreSQL e con il backend Vemoria esistente.
--
-- COSA AGGIUNGE:
-- 1. M6 — Indice partial su workspace_inbox_items per pending_signal veloce.
-- 2. M3 — Tabella idempotency_keys per dedup di POST mutativi.
-- 3. M12 — Tabella rate_limit_buckets (token-bucket archive_matching).
-- ============================================================================

BEGIN;


-- ============================================================================
-- M6 — Indice partial pending_confirmation non letto (per pending_signal Scrivania)
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_inbox_pending_unread_by_owner
    ON workspace_inbox_items (proprietario_id)
    WHERE state = 'pending_confirmation' AND read_at IS NULL;


-- ============================================================================
-- M3 — Idempotency-Key store per POST mutativi
-- ============================================================================
-- Strategia:
-- - Il client invia header "Idempotency-Key: <uuid-or-random-string>".
-- - Il middleware, se la stessa chiave + path + user esiste già in stato
--   'completed', restituisce la response_body originale (replay).
-- - Se è 'in_flight' (richiesta in corso), risponde 409 Conflict.
-- - Se è 'failed' o non esiste, la richiesta procede normalmente.
-- - TTL applicato dal middleware (default 24h) sulla colonna expires_at.
--
-- INVARIANTE:
-- - id_key è (idempotency_key, proprietario_id, method, path) per evitare
--   collisioni cross-endpoint a parità di key.

CREATE TABLE IF NOT EXISTS idempotency_keys (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    idempotency_key         TEXT NOT NULL,
    proprietario_id         UUID NOT NULL,
    method                  TEXT NOT NULL,
    path                    TEXT NOT NULL,
    request_body_hash       TEXT,
    status                  TEXT NOT NULL DEFAULT 'in_flight',
    response_status_code    INTEGER,
    response_body_json      JSONB,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at            TIMESTAMPTZ,
    expires_at              TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '24 hours'),
    CONSTRAINT chk_idem_status CHECK (
        status IN ('in_flight', 'completed', 'failed')
    ),
    UNIQUE (idempotency_key, proprietario_id, method, path)
);

CREATE INDEX IF NOT EXISTS idx_idem_lookup
    ON idempotency_keys (idempotency_key, proprietario_id);

CREATE INDEX IF NOT EXISTS idx_idem_cleanup_by_expires
    ON idempotency_keys (expires_at)
    WHERE status IN ('completed', 'failed');


-- ============================================================================
-- M12 — Rate limit token-bucket per archive_matching
-- ============================================================================
-- Strategia: token-bucket per (proprietario_id, bucket_key).
-- archive_matching usa bucket_key = 'archive_matching'.
-- - Capacità default: 30 token (richieste/ora).
-- - Refill: 1 token ogni 120 secondi (= 30/ora).
-- - Costo per chiamata: 1 token.
-- - Se tokens <= 0 → 429 Too Many Requests.
--
-- I PARAMETRI CAPACITY/REFILL non sono nel DB ma nel codice middleware,
-- per non bloccare tuning. La tabella tiene solo lo stato corrente.

CREATE TABLE IF NOT EXISTS rate_limit_buckets (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    proprietario_id         UUID NOT NULL,
    bucket_key              TEXT NOT NULL,
    tokens                  REAL NOT NULL DEFAULT 30.0,
    last_refill_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (proprietario_id, bucket_key)
);

CREATE INDEX IF NOT EXISTS idx_rate_limit_lookup
    ON rate_limit_buckets (proprietario_id, bucket_key);


COMMIT;

-- ============================================================================
-- Note operative:
-- - Idempotency keys vanno purgate periodicamente. Suggerito cron job
--   giornaliero che esegue:
--     DELETE FROM idempotency_keys WHERE expires_at < NOW();
-- - Rate limit buckets restano in DB. Pulizia rara (mensile) tramite:
--     DELETE FROM rate_limit_buckets WHERE last_refill_at < NOW() - INTERVAL '30 days';
-- ============================================================================
