-- Vemoria Gate03 — guarded rollback companion for migration v122.
-- NOT part of MANAGED_MIGRATIONS. Execute manually only after backup/export.
-- The guard deliberately refuses a destructive rollback while any trust key
-- remains active or pending, preventing silent loss of owner trust state.

DO $$
BEGIN
    IF to_regclass('public.fabric_receipt_trusted_keys') IS NOT NULL AND EXISTS (
        SELECT 1 FROM fabric_receipt_trusted_keys
        WHERE trust_status IN ('active','pending')
    ) THEN
        RAISE EXCEPTION
            'VEMORIA_ROLLBACK_BLOCKED_ACTIVE_RECEIPT_TRUST: export/restore plan required';
    END IF;
END $$;

DROP INDEX IF EXISTS idx_fabric_trusted_key_owner_status;
DROP TABLE IF EXISTS fabric_receipt_trusted_keys;
DROP INDEX IF EXISTS idx_fabric_receipt_owner_issuer;
ALTER TABLE fabric_endpoint_receipts
    DROP CONSTRAINT IF EXISTS fabric_endpoint_receipts_issuer_role_check;
ALTER TABLE fabric_endpoint_receipts
    DROP COLUMN IF EXISTS issuer_key_fingerprint;
ALTER TABLE fabric_endpoint_receipts
    DROP COLUMN IF EXISTS issuer_role;
