-- VEMORA MB13-P3 v213 — Evidence, receipt and attempt-cancellation closure
-- Non modificare MB13-P1/MB13-P2. Non aprire R3. Non produrre APK/AAB.

BEGIN;

-- ----------------------------------------------------------------------------
-- 1. Evidence row provenance and schema-version columns
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p3_action_pack_evidence
    ADD COLUMN IF NOT EXISTS attempt_number INTEGER,
    ADD COLUMN IF NOT EXISTS pack_revision INTEGER,
    ADD COLUMN IF NOT EXISTS monitor_revision INTEGER,
    ADD COLUMN IF NOT EXISTS executor_identity TEXT,
    ADD COLUMN IF NOT EXISTS evidence_schema_version TEXT;

DROP INDEX IF EXISTS uq_mb13_p3_evidence_receipt_id_not_null;
CREATE UNIQUE INDEX uq_mb13_p3_evidence_receipt_id_not_null
    ON public.mb13_p3_action_pack_evidence (receipt_id)
    WHERE receipt_id IS NOT NULL;

-- Allow attempts to be closed to terminal cancellation/revocation/expiration states.
ALTER TABLE public.mb13_p3_action_pack_attempt
    DROP CONSTRAINT IF EXISTS ck_mb13_p3_attempt_status;
ALTER TABLE public.mb13_p3_action_pack_attempt
    ADD CONSTRAINT ck_mb13_p3_attempt_status
    CHECK (status = ANY (ARRAY['claimed'::text, 'executing'::text, 'completed'::text, 'partial'::text, 'failed'::text, 'cancelled'::text, 'revoked'::text, 'expired'::text]));

-- ----------------------------------------------------------------------------
-- 2. Terminal pack status must close every active attempt atomically
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync()
RETURNS TRIGGER AS $$
DECLARE
    v_now TIMESTAMPTZ := clock_timestamp();
BEGIN
    IF NEW.status IN ('completed','partial','failed','cancelled','revoked','expired')
       AND NEW.status IS DISTINCT FROM OLD.status THEN
        UPDATE public.mb13_p3_action_pack_attempt
           SET status = NEW.status,
               completed_at = COALESCE(completed_at, v_now)
         WHERE pack_id = NEW.pack_id
           AND owner_user_id = NEW.owner_user_id
           AND status IN ('claimed','executing');
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync() OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync() TO mb13_p3_writer;

DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_terminal_attempt_sync ON public.mb13_p3_action_pack;
CREATE TRIGGER trg_mb13_p3_action_pack_terminal_attempt_sync
    AFTER UPDATE ON public.mb13_p3_action_pack
    FOR EACH ROW
    WHEN (NEW.status IN ('completed','partial','failed','cancelled','revoked','expired')
          AND NEW.status IS DISTINCT FROM OLD.status)
    EXECUTE FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync();

-- ----------------------------------------------------------------------------
-- 3. Evidence registration bound to the exact executor, revision and schema
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_record_execution_evidence(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_attempt_number INTEGER,
    p_evidence_type TEXT,
    p_evidence_payload JSONB
) RETURNS TABLE(
    evidence_id UUID,
    receipt_id UUID,
    evidence_hash TEXT
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_executor_identity TEXT := session_user;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_schema_version TEXT;
    v_status TEXT;
    v_details JSONB;
    v_evidence_hash TEXT;
    v_receipt_id UUID;
    v_new_id UUID;
    v_target_ref_hash TEXT;
    v_consent_hash TEXT;
    v_provenance_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    -- Lock pack first, then attempt, then monitor (deterministic order).
    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.attempt_number IS DISTINCT FROM p_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;
    IF v_attempt.executor_identity IS DISTINCT FROM v_executor_identity THEN
        RAISE EXCEPTION 'mb13_p3_executor_identity_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;
    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_target_ref_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb));
    v_consent_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb));
    v_provenance_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb));

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, v_target_ref_hash, v_consent_hash, v_provenance_hash,
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    -- Schema/versioned evidence payload validation.
    IF p_evidence_type IS NULL OR p_evidence_type = '' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_type_required';
    END IF;
    IF p_evidence_type NOT IN ('simulation_receipt','internal_action_receipt','step_result') THEN
        RAISE EXCEPTION 'mb13_p3_evidence_type_not_allowed';
    END IF;
    IF p_evidence_payload IS NULL OR jsonb_typeof(p_evidence_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_payload_invalid';
    END IF;
    IF p_evidence_payload = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_payload_empty';
    END IF;
    v_schema_version := NULLIF(p_evidence_payload->>'schema_version', '');
    IF v_schema_version IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_evidence_schema_version_required';
    END IF;
    IF (p_evidence_payload ? 'step_number') = false AND (p_evidence_payload ? 'action_result') = false THEN
        RAISE EXCEPTION 'mb13_p3_evidence_step_or_action_required';
    END IF;
    v_status := NULLIF(p_evidence_payload->>'status', '');
    IF v_status IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_evidence_status_required';
    END IF;
    v_details := p_evidence_payload->'details';
    IF v_details IS NULL OR jsonb_typeof(v_details) <> 'object' OR v_details = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_details_required';
    END IF;

    v_evidence_hash := public.mb13_p0_hash_jsonb(p_evidence_payload);
    v_receipt_id := gen_random_uuid();

    INSERT INTO public.mb13_p3_action_pack_evidence (
        owner_user_id, pack_id, attempt_id, attempt_number, pack_revision, monitor_revision,
        executor_identity, evidence_type, evidence_hash, receipt_id, evidence_payload,
        evidence_schema_version, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, p_attempt_number, v_pack.pack_revision,
        v_monitor.current_revision, v_executor_identity, p_evidence_type, v_evidence_hash,
        v_receipt_id, p_evidence_payload, v_schema_version, v_now
    ) RETURNING public.mb13_p3_action_pack_evidence.evidence_id INTO v_new_id;

    RETURN QUERY SELECT v_new_id, v_receipt_id, v_evidence_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_record_execution_evidence(UUID, UUID, UUID, INTEGER, TEXT, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_record_execution_evidence(UUID, UUID, UUID, INTEGER, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_record_execution_evidence(UUID, UUID, UUID, INTEGER, TEXT, JSONB) TO mb13_p3_executor, mb13_p3_writer;

-- ----------------------------------------------------------------------------
-- 4. Canonical result evidence: both evidence_id and receipt_id must point to
--    the same row; invented or mismatched receipt_id is rejected.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_canonicalize_result_evidence(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_result_payload JSONB
) RETURNS JSONB AS $$
DECLARE
    v_evidence JSONB;
    v_evidence_type TEXT;
    v_evidence_id UUID;
    v_receipt_id UUID;
    v_row public.mb13_p3_action_pack_evidence%ROWTYPE;
    v_expected_hash TEXT;
    v_canonical JSONB;
BEGIN
    IF p_result_payload IS NULL OR jsonb_typeof(p_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_payload_invalid';
    END IF;

    v_evidence := p_result_payload->'evidence';
    IF v_evidence IS NULL OR jsonb_typeof(v_evidence) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_required';
    END IF;
    IF v_evidence ? 'evidence_hash' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_hash_from_body_forbidden';
    END IF;

    v_evidence_type := NULLIF(v_evidence->>'evidence_type', '');
    v_evidence_id := NULLIF(v_evidence->>'evidence_id', '')::UUID;
    v_receipt_id := NULLIF(v_evidence->>'receipt_id', '')::UUID;

    IF v_evidence_type IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_type_required';
    END IF;
    IF v_evidence_id IS NULL AND v_receipt_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_not_pre_registered';
    END IF;

    IF v_evidence_id IS NOT NULL THEN
        SELECT * INTO v_row
          FROM public.mb13_p3_action_pack_evidence
         WHERE evidence_id = v_evidence_id
           AND owner_user_id = p_owner_user_id
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_found';
        END IF;
        IF v_row.pack_id IS DISTINCT FROM p_pack_id OR v_row.attempt_id IS DISTINCT FROM p_attempt_id THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_bound';
        END IF;
        IF v_row.evidence_type IS DISTINCT FROM v_evidence_type THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_type_mismatch';
        END IF;
        v_expected_hash := public.mb13_p0_hash_jsonb(v_row.evidence_payload);
        IF v_row.evidence_hash IS DISTINCT FROM v_expected_hash THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_integrity_failure';
        END IF;
        IF v_receipt_id IS NOT NULL AND v_row.receipt_id IS DISTINCT FROM v_receipt_id THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_receipt_mismatch';
        END IF;
        v_canonical := jsonb_build_object(
            'evidence', jsonb_build_object(
                'evidence_id', v_row.evidence_id,
                'receipt_id', v_row.receipt_id,
                'evidence_type', v_row.evidence_type
            ),
            'evidence_hash', v_row.evidence_hash
        );
        RETURN v_canonical;
    END IF;

    -- Only receipt_id provided.
    SELECT * INTO v_row
      FROM public.mb13_p3_action_pack_evidence
     WHERE receipt_id = v_receipt_id
       AND owner_user_id = p_owner_user_id
     FOR SHARE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_not_found';
    END IF;
    IF v_row.pack_id IS DISTINCT FROM p_pack_id OR v_row.attempt_id IS DISTINCT FROM p_attempt_id THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_not_bound';
    END IF;
    IF v_row.evidence_type IS DISTINCT FROM v_evidence_type THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_type_mismatch';
    END IF;
    v_expected_hash := public.mb13_p0_hash_jsonb(v_row.evidence_payload);
    IF v_row.evidence_hash IS DISTINCT FROM v_expected_hash THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_integrity_failure';
    END IF;
    v_canonical := jsonb_build_object(
        'evidence', jsonb_build_object(
            'evidence_id', v_row.evidence_id,
            'receipt_id', v_row.receipt_id,
            'evidence_type', v_row.evidence_type
        ),
        'evidence_hash', v_row.evidence_hash
    );
    RETURN v_canonical;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_canonicalize_result_evidence(UUID, UUID, UUID, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_canonicalize_result_evidence(UUID, UUID, UUID, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_canonicalize_result_evidence(UUID, UUID, UUID, JSONB) TO mb13_p3_writer;

-- Backward-compatible validator returning just the evidence UUID.
CREATE OR REPLACE FUNCTION public.mb13_p3_validate_result_evidence(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_result_payload JSONB
) RETURNS UUID AS $$
DECLARE
    v_canonical JSONB;
BEGIN
    v_canonical := public.mb13_p3_canonicalize_result_evidence(p_owner_user_id, p_pack_id, p_attempt_id, p_result_payload);
    RETURN ((v_canonical->'evidence')->>'evidence_id')::UUID;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_validate_result_evidence(UUID, UUID, UUID, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_validate_result_evidence(UUID, UUID, UUID, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_result_evidence(UUID, UUID, UUID, JSONB) TO mb13_p3_writer;

-- Result trigger stays identical semantically but now delegates to the canonical validator.
DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_result_evidence_guard ON public.mb13_p3_action_pack_result;
CREATE TRIGGER trg_mb13_p3_action_pack_result_evidence_guard
    BEFORE INSERT ON public.mb13_p3_action_pack_result
    FOR EACH ROW
    WHEN (NEW.outcome IN ('completed','partial'))
    EXECUTE FUNCTION public.mb13_p3_action_pack_result_evidence_guard();

-- ----------------------------------------------------------------------------
-- 5. Complete stores the canonical evidence reference and re-hashes the exact
--    result payload.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) CASCADE;

CREATE OR REPLACE FUNCTION public.mb13_p3_complete_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_expected_pack_revision INTEGER,
    p_expected_attempt_number INTEGER,
    p_outcome TEXT,
    p_result_payload JSONB
) RETURNS TABLE(
    attempt_id UUID,
    pack_id UUID,
    attempt_number INTEGER,
    status TEXT,
    result_hash TEXT,
    completed_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_existing_result public.mb13_p3_action_pack_result%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
    v_result_hash TEXT;
    v_event_kind TEXT;
    v_old_status TEXT;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_canonical_evidence JSONB;
    v_result_payload JSONB;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_outcome NOT IN ('completed','partial','failed') THEN
        RAISE EXCEPTION 'mb13_p3_invalid_outcome';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;
    IF v_attempt.attempt_number IS DISTINCT FROM p_expected_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    -- Idempotent replay after full validation.
    SELECT * INTO v_existing_result
      FROM public.mb13_p3_action_pack_result
     WHERE attempt_id = p_attempt_id
       AND owner_user_id = p_owner_user_id;
    IF FOUND THEN
        IF p_outcome IN ('completed','partial') THEN
            v_canonical_evidence := public.mb13_p3_canonicalize_result_evidence(p_owner_user_id, p_pack_id, p_attempt_id, p_result_payload);
            v_result_payload := COALESCE(p_result_payload, '{}'::jsonb);
            v_result_payload := v_result_payload - 'evidence_hash';
            v_result_payload := jsonb_set(v_result_payload, '{evidence}', v_canonical_evidence->'evidence');
            v_result_payload := jsonb_set(v_result_payload, '{evidence_hash}', v_canonical_evidence->'evidence_hash');
        ELSE
            v_result_payload := COALESCE(p_result_payload, '{}'::jsonb);
        END IF;
        v_result_hash := public.mb13_p3_action_pack_result_hash(
            p_owner_user_id, p_pack_id, v_pack.pack_revision, p_attempt_id,
            v_attempt.attempt_number, p_outcome, v_attempt.executor_identity,
            v_result_payload, v_existing_result.created_at
        );
        IF v_existing_result.outcome = p_outcome AND v_existing_result.result_hash = v_result_hash THEN
            RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                                p_outcome::TEXT, v_result_hash, v_attempt.completed_at;
            RETURN;
        END IF;
        RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
    END IF;

    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    IF p_outcome IN ('completed','partial') THEN
        v_canonical_evidence := public.mb13_p3_canonicalize_result_evidence(p_owner_user_id, p_pack_id, p_attempt_id, p_result_payload);
        v_result_payload := COALESCE(p_result_payload, '{}'::jsonb);
        v_result_payload := v_result_payload - 'evidence_hash';
        v_result_payload := jsonb_set(v_result_payload, '{evidence}', v_canonical_evidence->'evidence');
        v_result_payload := jsonb_set(v_result_payload, '{evidence_hash}', v_canonical_evidence->'evidence_hash');
    ELSE
        v_result_payload := COALESCE(p_result_payload, '{}'::jsonb);
    END IF;

    v_result_hash := public.mb13_p3_action_pack_result_hash(
        p_owner_user_id, p_pack_id, v_pack.pack_revision, p_attempt_id,
        v_attempt.attempt_number, p_outcome, v_attempt.executor_identity,
        v_result_payload, v_now
    );
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);
    v_event_kind := p_outcome;
    v_old_status := v_pack.status;

    INSERT INTO public.mb13_p3_action_pack_result (
        owner_user_id, pack_id, attempt_id, attempt_number, outcome, executor_identity,
        result_payload, result_hash, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, v_attempt.attempt_number, p_outcome,
        v_attempt.executor_identity, v_result_payload, v_result_hash, v_now
    );

    UPDATE public.mb13_p3_action_pack_attempt
       SET status = p_outcome,
           result_payload = v_result_payload,
           result_hash = v_result_hash,
           completed_at = v_now
     WHERE attempt_id = p_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = p_outcome,
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, v_event_kind, 'executing', p_outcome,
        v_now, jsonb_build_object('attempt_id', p_attempt_id, 'attempt_number', v_attempt.attempt_number, 'result_hash', v_result_hash),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                        p_outcome::TEXT, v_result_hash, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) TO mb13_p3_executor;

-- ----------------------------------------------------------------------------
-- 6. Result evidence guard: reject terminal packs and unregistered evidence.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_result_evidence_guard()
RETURNS TRIGGER AS $$
DECLARE
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
BEGIN
    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = NEW.attempt_id
       AND owner_user_id = NEW.owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.pack_id IS DISTINCT FROM NEW.pack_id OR v_attempt.attempt_number IS DISTINCT FROM NEW.attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_bound';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = NEW.pack_id
       AND owner_user_id = NEW.owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    IF NEW.outcome IN ('completed','partial') THEN
        PERFORM public.mb13_p3_validate_result_evidence(NEW.owner_user_id, NEW.pack_id, NEW.attempt_id, NEW.result_payload);
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_result_evidence_guard() OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_result_evidence_guard() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_result_evidence_guard() TO mb13_p3_writer;

DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_result_evidence_guard ON public.mb13_p3_action_pack_result;
CREATE TRIGGER trg_mb13_p3_action_pack_result_evidence_guard
    BEFORE INSERT ON public.mb13_p3_action_pack_result
    FOR EACH ROW
    EXECUTE FUNCTION public.mb13_p3_action_pack_result_evidence_guard();

COMMIT;
