-- ===========================================================================
-- VEMORIA V283 — ordinary encrypted Vault backup/recovery checkpoint
-- ===========================================================================
-- Additive only.  The Vault ciphertext itself remains governed by the
-- existing MB14-P4-R1 AES-256-GCM boundary; this table stores only monotonic
-- backup/restore generations and package digests for rollback/idempotency.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS vault_backup_checkpoint (
    owner_user_id              UUID PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    last_export_generation     BIGINT NOT NULL DEFAULT 0 CHECK (last_export_generation >= 0),
    last_restore_generation    BIGINT NOT NULL DEFAULT 0 CHECK (last_restore_generation >= 0),
    last_restore_sha256        TEXT,
    last_restore_backup_id     UUID,
    last_exported_at           TIMESTAMPTZ,
    last_restored_at           TIMESTAMPTZ,
    updated_at                 TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT vault_backup_checkpoint_restore_sha256_check
        CHECK (last_restore_sha256 IS NULL OR last_restore_sha256 ~ '^[0-9a-f]{64}$')
);

ALTER TABLE vault_backup_checkpoint ENABLE ROW LEVEL SECURITY;
ALTER TABLE vault_backup_checkpoint FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS vault_backup_checkpoint_owner_isolation ON vault_backup_checkpoint;
CREATE POLICY vault_backup_checkpoint_owner_isolation ON vault_backup_checkpoint
    FOR ALL
    USING (owner_user_id = _rls_owner_uuid())
    WITH CHECK (owner_user_id = _rls_owner_uuid());

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'vemoria_app_user') THEN
        GRANT SELECT, INSERT, UPDATE ON vault_backup_checkpoint TO vemoria_app_user;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p2_api') THEN
        GRANT SELECT, INSERT, UPDATE ON vault_backup_checkpoint TO mb13_p2_api;
    END IF;
END $$;
