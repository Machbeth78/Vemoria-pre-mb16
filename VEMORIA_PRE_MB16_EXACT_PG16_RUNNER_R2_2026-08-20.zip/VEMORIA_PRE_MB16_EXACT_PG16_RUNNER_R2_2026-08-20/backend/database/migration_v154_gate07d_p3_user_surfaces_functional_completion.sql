-- Vemoria Gate07D — P3 User Surfaces Functional Completion
-- Static/code integration bookkeeping only.
-- Does not claim Flutter/Android runtime, chat network runtime, payment provider runtime,
-- entitlement activation runtime, business profile publication runtime or PostgreSQL runtime.

CREATE TABLE IF NOT EXISTS gate07d_p3_user_surfaces_functional_completion (
    id BIGSERIAL PRIMARY KEY,
    vc_id TEXT NOT NULL UNIQUE,
    integration_state TEXT NOT NULL CHECK (integration_state = 'CODICE_INTEGRATO'),
    functional_completion_state TEXT NOT NULL CHECK (functional_completion_state = 'FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED'),
    runtime_real TEXT NOT NULL CHECK (runtime_real NOT IN ('PASS','RUNTIME_PASS','PRODUZIONE_ESEGUITA','SUPERATO_RUNTIME_REALE')),
    can_claim_runtime_pass BOOLEAN NOT NULL DEFAULT FALSE CHECK (can_claim_runtime_pass = FALSE),
    owner_scope_required BOOLEAN NOT NULL DEFAULT TRUE,
    explicit_confirmation_required BOOLEAN NOT NULL DEFAULT TRUE,
    evidence JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO gate07d_p3_user_surfaces_functional_completion
(vc_id, integration_state, functional_completion_state, runtime_real, can_claim_runtime_pass, owner_scope_required, explicit_confirmation_required, evidence)
VALUES
('VC-009','CODICE_INTEGRATO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED','NON_ESEGUITO',FALSE,TRUE,FALSE,'{"function":"document_context_card_view_model","flutter_rendering":"NON_ESEGUITO"}'::jsonb),
('VC-056','CODICE_INTEGRATO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED','FLUTTER_ANDROID_RETE_NON_ESEGUITO',FALSE,TRUE,TRUE,'{"function":"chat_direct_group_surface","network_send":"NON_ESEGUITO"}'::jsonb),
('VC-010','CODICE_INTEGRATO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED','FLUTTER_ANDROID_RETE_NON_ESEGUITO',FALSE,TRUE,FALSE,'{"function":"relation_chat_timeline_slice","summary_is_derived": true}'::jsonb),
('VC-073','CODICE_INTEGRATO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED','NON_ESEGUITO',FALSE,TRUE,TRUE,'{"function":"subscription_quote_preflight","payment_provider":"NON_ESEGUITO"}'::jsonb),
('VC-074','CODICE_INTEGRATO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED','NON_ESEGUITO',FALSE,TRUE,FALSE,'{"function":"owner_scoped_entitlement_decision","package_activation":"NON_ESEGUITO"}'::jsonb),
('VC-012','CODICE_INTEGRATO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED','NON_ESEGUITO',FALSE,TRUE,TRUE,'{"function":"optional_business_profile_draft","publication":"NON_ESEGUITO","marketplace": false}'::jsonb)
ON CONFLICT (vc_id) DO UPDATE SET
    integration_state = EXCLUDED.integration_state,
    functional_completion_state = EXCLUDED.functional_completion_state,
    runtime_real = EXCLUDED.runtime_real,
    can_claim_runtime_pass = FALSE,
    owner_scope_required = EXCLUDED.owner_scope_required,
    explicit_confirmation_required = EXCLUDED.explicit_confirmation_required,
    evidence = EXCLUDED.evidence;
