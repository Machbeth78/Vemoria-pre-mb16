-- VEMORA — Migration V94: Smart composer hints runtime
-- Creatore e proprietario: Devoti Massimo
--
-- Stato "prossima azione suggerita" denormalizzato su thread per rendering veloce.

ALTER TABLE chat_thread
    ADD COLUMN IF NOT EXISTS next_action_kind TEXT;
    -- es: remind_signature | request_acceptance | send_proof | follow_up | nothing

ALTER TABLE chat_thread
    ADD COLUMN IF NOT EXISTS next_action_context JSONB NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE chat_thread
    ADD COLUMN IF NOT EXISTS next_action_recomputed_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_chat_thread_next_action
    ON chat_thread(workspace_type, workspace_id)
    WHERE next_action_kind IS NOT NULL AND archived_at IS NULL;

COMMENT ON COLUMN chat_thread.next_action_kind IS
    'Cache della prossima azione suggerita dal composer intelligente. Ricalcolata a ogni invio/cambio stato azione.';
