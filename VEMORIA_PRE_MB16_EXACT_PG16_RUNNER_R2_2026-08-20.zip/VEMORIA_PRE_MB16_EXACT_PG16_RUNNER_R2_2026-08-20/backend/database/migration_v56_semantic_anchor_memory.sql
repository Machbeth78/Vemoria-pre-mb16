-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V56 — Memoria semantica generale per ancore/periodi usati dal vocale
-- Correzione architetturale: ECO consuma refs vocali, non possiede la memoria primaria della vita.

CREATE TABLE IF NOT EXISTS semantic_anchor_events (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    anchor_identity     TEXT NOT NULL,
    short_label         TEXT NOT NULL,
    anchor_domain       TEXT NOT NULL DEFAULT 'generic',
    anchor_kind         TEXT NOT NULL DEFAULT 'semantic_period',
    event_type          TEXT NOT NULL DEFAULT 'event',
    relationship_scope  TEXT,
    salience_level      TEXT NOT NULL DEFAULT 'media',
    temporal_force      INTEGER NOT NULL DEFAULT 0,
    human_priority      INTEGER NOT NULL DEFAULT 0,
    maturity_level      TEXT NOT NULL DEFAULT 'debole',
    maturity_score      REAL NOT NULL DEFAULT 0.0,
    evidence_count      INTEGER NOT NULL DEFAULT 1,
    recurrence_sessions INTEGER NOT NULL DEFAULT 1,
    last_source_session_id UUID,
    owner_scope         TEXT NOT NULL DEFAULT 'vemora_semantic_memory',
    visibility_scope    TEXT NOT NULL DEFAULT 'voice_reference',
    payload_json        JSONB NOT NULL DEFAULT '{}'::jsonb,
    reason_codes        JSONB NOT NULL DEFAULT '[]'::jsonb,
    first_seen_at       TIMESTAMP NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, anchor_identity)
);

CREATE INDEX IF NOT EXISTS idx_semantic_anchor_events_user_score
    ON semantic_anchor_events(utente_id, maturity_score DESC, human_priority DESC, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_semantic_anchor_events_label
    ON semantic_anchor_events(short_label, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_semantic_anchor_events_visibility
    ON semantic_anchor_events(visibility_scope, anchor_domain, event_type);
