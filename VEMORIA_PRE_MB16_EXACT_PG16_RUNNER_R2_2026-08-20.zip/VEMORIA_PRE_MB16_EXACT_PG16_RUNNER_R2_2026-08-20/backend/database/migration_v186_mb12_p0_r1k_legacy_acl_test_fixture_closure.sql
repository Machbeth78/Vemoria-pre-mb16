-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB12-P0 R1K — remove the obsolete owner-supplied binding entry point.
-- Additive/idempotent. Does not modify migrations v176-v185.

BEGIN;

-- v180 introduced an overload that accepts owner_user_id from the caller.
-- It is obsolete and unsafe for application/public execution because it does
-- not derive the owner from app.owner_id. Keep it only for historical schema
-- compatibility, executable by its database owner alone.
REVOKE ALL ON FUNCTION public.mb12_p0_create_source_card_binding(
    TEXT, UUID, UUID, UUID, UUID, TEXT, TEXT
) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb12_p0_create_source_card_binding(
    TEXT, UUID, UUID, UUID, UUID, TEXT, TEXT
) FROM mb12_p0_app;

COMMIT;
