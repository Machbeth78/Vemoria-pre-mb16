-- VEMORA MB13-P3 v214 — Evidence semantic idempotency and terminal audit closure
-- Non modificare MB13-P1/MB13-P2. Non aprire R3. Non produrre APK/AAB.

BEGIN;

-- ----------------------------------------------------------------------------
-- 1. Evidence table integrity: idempotency, state, and completeness
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p3_action_pack_evidence
    ADD COLUMN IF NOT EXISTS idempotency_key TEXT,
    ADD COLUMN IF NOT EXISTS evidence_request_hash TEXT,
    ADD COLUMN IF NOT EXISTS evidence_state TEXT DEFAULT 'active';

-- Temporarily disable user triggers to allow safe backfill of the append-only evidence table.
ALTER TABLE public.mb13_p3_action_pack_evidence DISABLE TRIGGER USER;

-- Backfill legacy rows from the authoritative attempt and pack state.
UPDATE public.mb13_p3_action_pack_evidence e
SET
    attempt_number = COALESCE(e.attempt_number, a.attempt_number),
    pack_revision = COALESCE(e.pack_revision, p.pack_revision),
    monitor_revision = COALESCE(e.monitor_revision, p.monitor_revision),
    executor_identity = COALESCE(e.executor_identity, a.executor_identity),
    evidence_schema_version = COALESCE(e.evidence_schema_version, e.evidence_payload->>'schema_version', 'legacy'),
    idempotency_key = COALESCE(e.idempotency_key, e.evidence_id::text),
    evidence_request_hash = COALESCE(e.evidence_request_hash, 'legacy')
FROM public.mb13_p3_action_pack_attempt a,
     public.mb13_p3_action_pack p
WHERE e.attempt_id = a.attempt_id
  AND e.pack_id = p.pack_id;

-- Quarantine any row that cannot be safely treated as active v1 evidence.
UPDATE public.mb13_p3_action_pack_evidence
SET evidence_state = 'quarantined'
WHERE evidence_state = 'active'
  AND (
      attempt_number IS NULL
      OR pack_revision IS NULL
      OR monitor_revision IS NULL
      OR executor_identity IS NULL
      OR evidence_schema_version IS NULL
      OR evidence_payload IS NULL
      OR evidence_payload = '{}'::jsonb
      OR evidence_hash IS NULL
      OR receipt_id IS NULL
      OR idempotency_key IS NULL
      OR evidence_request_hash IS NULL
      OR evidence_schema_version NOT IN ('mb13-p3-evidence/v1')
      OR evidence_type NOT IN ('simulation_receipt', 'internal_action_receipt', 'step_result')
  );

ALTER TABLE public.mb13_p3_action_pack_evidence
    DROP CONSTRAINT IF EXISTS ck_mb13_p3_evidence_state;
ALTER TABLE public.mb13_p3_action_pack_evidence
    ADD CONSTRAINT ck_mb13_p3_evidence_state
    CHECK (evidence_state IN ('active', 'quarantined', 'legacy'));

ALTER TABLE public.mb13_p3_action_pack_evidence
    DROP CONSTRAINT IF EXISTS ck_mb13_p3_evidence_type_values;
ALTER TABLE public.mb13_p3_action_pack_evidence
    ADD CONSTRAINT ck_mb13_p3_evidence_type_values
    CHECK (evidence_state <> 'active' OR evidence_type IN ('simulation_receipt', 'internal_action_receipt', 'step_result'));

ALTER TABLE public.mb13_p3_action_pack_evidence
    DROP CONSTRAINT IF EXISTS ck_mb13_p3_evidence_active_complete;
ALTER TABLE public.mb13_p3_action_pack_evidence
    ADD CONSTRAINT ck_mb13_p3_evidence_active_complete
    CHECK (
        evidence_state <> 'active' OR (
            attempt_number IS NOT NULL
            AND pack_revision IS NOT NULL
            AND monitor_revision IS NOT NULL
            AND executor_identity IS NOT NULL
            AND evidence_schema_version IS NOT NULL
            AND evidence_payload IS NOT NULL
            AND evidence_payload <> '{}'::jsonb
            AND evidence_hash IS NOT NULL
            AND receipt_id IS NOT NULL
            AND idempotency_key IS NOT NULL
            AND evidence_request_hash IS NOT NULL
            AND evidence_schema_version = 'mb13-p3-evidence/v1'
            AND attempt_number > 0
            AND pack_revision >= 1
            AND monitor_revision >= 1
        )
    );

ALTER TABLE public.mb13_p3_action_pack_evidence
    DROP CONSTRAINT IF EXISTS uq_mb13_p3_evidence_owner_attempt_idempotency;
ALTER TABLE public.mb13_p3_action_pack_evidence
    ADD CONSTRAINT uq_mb13_p3_evidence_owner_attempt_idempotency
    UNIQUE (owner_user_id, attempt_id, idempotency_key);

-- ----------------------------------------------------------------------------
-- 2. Timeline event kinds for per-attempt terminal audit
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p3_action_pack_timeline
    DROP CONSTRAINT IF EXISTS ck_mb13_p3_timeline_event_kind;
ALTER TABLE public.mb13_p3_action_pack_timeline
    ADD CONSTRAINT ck_mb13_p3_timeline_event_kind
    CHECK (event_kind IN (
        'pack_created','pack_revised','authorized','authorization_revoked','claim_revoked','claimed','started',
        'completed','partial','failed','cancelled','expired','rolled_back',
        'attempt_completed','attempt_partial','attempt_failed','attempt_cancelled','attempt_revoked','attempt_expired'
    ));

-- ----------------------------------------------------------------------------
-- 3. Semantic validation of versioned evidence payload
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_validate_evidence_payload_semantics(
    p_pack public.mb13_p3_action_pack,
    p_evidence_type TEXT,
    p_evidence_payload JSONB,
    p_schema_version TEXT
) RETURNS void AS $$
DECLARE
    v_step JSONB;
    v_step_number INTEGER;
    v_status TEXT;
    v_allowed_statuses TEXT[];
    v_details JSONB;
    v_action_result JSONB;
BEGIN
    IF p_evidence_payload IS NULL OR jsonb_typeof(p_evidence_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_payload_invalid';
    END IF;
    IF p_evidence_payload = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_payload_empty';
    END IF;

    IF p_schema_version IS DISTINCT FROM 'mb13-p3-evidence/v1' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_schema_version_not_allowed';
    END IF;

    v_status := NULLIF(p_evidence_payload->>'status', '');
    IF v_status IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_evidence_status_required';
    END IF;

    v_details := p_evidence_payload->'details';
    IF v_details IS NULL OR jsonb_typeof(v_details) <> 'object' OR v_details = '{}'::jsonb THEN
        RAISE EXCEPTION 'mb13_p3_evidence_details_required';
    END IF;

    IF (p_evidence_payload ? 'step_number') = false AND (p_evidence_payload ? 'action_result') = false THEN
        RAISE EXCEPTION 'mb13_p3_evidence_step_or_action_required';
    END IF;

    IF p_evidence_type = 'step_result' THEN
        IF (p_evidence_payload ? 'step_number') = false THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_required_for_step_result';
        END IF;
        BEGIN
            v_step_number := NULLIF(p_evidence_payload->>'step_number', '')::INTEGER;
        EXCEPTION WHEN others THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_invalid';
        END;
        IF v_step_number IS NULL OR v_step_number <= 0 THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_number_invalid';
        END IF;

        SELECT s INTO v_step
          FROM jsonb_array_elements(p_pack.steps) s
         WHERE (s->>'step_number')::INTEGER = v_step_number
         LIMIT 1;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_not_found';
        END IF;
        IF v_step ? 'action_type' AND v_step->>'action_type' IS DISTINCT FROM p_pack.action_type THEN
            RAISE EXCEPTION 'mb13_p3_evidence_step_action_type_mismatch';
        END IF;
        IF p_evidence_payload ? 'action_type' AND (p_evidence_payload->>'action_type') IS DISTINCT FROM v_step->>'action_type' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_payload_action_type_mismatch';
        END IF;

        v_allowed_statuses := ARRAY['ok','completed','failed','skipped'];
    ELSIF p_evidence_type IN ('simulation_receipt','internal_action_receipt') THEN
        IF (p_evidence_payload ? 'action_result') = false THEN
            RAISE EXCEPTION 'mb13_p3_evidence_action_result_required';
        END IF;
        v_action_result := p_evidence_payload->'action_result';
        IF v_action_result IS NULL OR jsonb_typeof(v_action_result) <> 'object' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_action_result_invalid';
        END IF;
        v_allowed_statuses := ARRAY['ok','completed','partial','failed'];
    ELSE
        RAISE EXCEPTION 'mb13_p3_evidence_type_not_allowed';
    END IF;

    IF NOT (v_status = ANY (v_allowed_statuses)) THEN
        RAISE EXCEPTION 'mb13_p3_evidence_status_not_allowed_for_type';
    END IF;
END;
$$ LANGUAGE plpgsql IMMUTABLE
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_validate_evidence_payload_semantics(public.mb13_p3_action_pack, TEXT, JSONB, TEXT) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_validate_evidence_payload_semantics(public.mb13_p3_action_pack, TEXT, JSONB, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_evidence_payload_semantics(public.mb13_p3_action_pack, TEXT, JSONB, TEXT) TO mb13_p3_writer;

-- ----------------------------------------------------------------------------
-- 4. Evidence registration with idempotency, exact executor/revision binding
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p3_record_execution_evidence(UUID, UUID, UUID, INTEGER, TEXT, JSONB) CASCADE;

CREATE OR REPLACE FUNCTION public.mb13_p3_record_execution_evidence(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_attempt_number INTEGER,
    p_evidence_type TEXT,
    p_evidence_payload JSONB,
    p_idempotency_key TEXT
) RETURNS TABLE(
    evidence_id UUID,
    receipt_id UUID,
    evidence_hash TEXT
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_executor_identity TEXT := session_user;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_schema_version TEXT;
    v_evidence_hash TEXT;
    v_receipt_id UUID;
    v_new_id UUID;
    v_request_hash TEXT;
    v_existing public.mb13_p3_action_pack_evidence%ROWTYPE;
    v_target_ref_hash TEXT;
    v_consent_hash TEXT;
    v_provenance_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    IF p_idempotency_key IS NULL OR p_idempotency_key = '' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_idempotency_key_required';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.attempt_number IS DISTINCT FROM p_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;
    IF v_attempt.executor_identity IS DISTINCT FROM v_executor_identity THEN
        RAISE EXCEPTION 'mb13_p3_executor_identity_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;
    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_target_ref_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb));
    v_consent_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb));
    v_provenance_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb));

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, v_target_ref_hash, v_consent_hash, v_provenance_hash,
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    v_schema_version := NULLIF(p_evidence_payload->>'schema_version', '');
    IF v_schema_version IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_evidence_schema_version_required';
    END IF;

    PERFORM public.mb13_p3_validate_evidence_payload_semantics(
        v_pack, p_evidence_type, p_evidence_payload, v_schema_version
    );

    v_evidence_hash := public.mb13_p0_hash_jsonb(p_evidence_payload);
    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'pack_id', p_pack_id,
        'pack_revision', v_pack.pack_revision,
        'attempt_id', p_attempt_id,
        'attempt_number', p_attempt_number,
        'monitor_revision', v_monitor.current_revision,
        'executor_identity', v_executor_identity,
        'evidence_type', p_evidence_type,
        'schema_version', v_schema_version,
        'evidence_payload', p_evidence_payload
    ));

    -- Idempotent lookup: same key + same hash must return the same evidence.
    SELECT * INTO v_existing
      FROM public.mb13_p3_action_pack_evidence
     WHERE owner_user_id = p_owner_user_id
       AND attempt_id = p_attempt_id
       AND idempotency_key = p_idempotency_key
     FOR UPDATE;
    IF FOUND THEN
        IF v_existing.evidence_request_hash IS DISTINCT FROM v_request_hash
           OR v_existing.evidence_type IS DISTINCT FROM p_evidence_type
           OR v_existing.evidence_payload IS DISTINCT FROM p_evidence_payload
           OR v_existing.evidence_state IS DISTINCT FROM 'active' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_idempotency_conflict';
        END IF;
        RETURN QUERY SELECT v_existing.evidence_id, v_existing.receipt_id, v_existing.evidence_hash;
        RETURN;
    END IF;

    v_receipt_id := gen_random_uuid();

    INSERT INTO public.mb13_p3_action_pack_evidence (
        owner_user_id, pack_id, attempt_id, attempt_number, pack_revision, monitor_revision,
        executor_identity, evidence_type, evidence_hash, receipt_id, evidence_payload,
        evidence_schema_version, idempotency_key, evidence_request_hash, evidence_state, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, p_attempt_number, v_pack.pack_revision,
        v_monitor.current_revision, v_executor_identity, p_evidence_type, v_evidence_hash,
        v_receipt_id, p_evidence_payload, v_schema_version, p_idempotency_key, v_request_hash, 'active', v_now
    )
    ON CONFLICT ON CONSTRAINT uq_mb13_p3_evidence_owner_attempt_idempotency DO NOTHING
    RETURNING public.mb13_p3_action_pack_evidence.evidence_id INTO v_new_id;

    IF v_new_id IS NULL THEN
        SELECT * INTO v_existing
          FROM public.mb13_p3_action_pack_evidence
         WHERE owner_user_id = p_owner_user_id
           AND attempt_id = p_attempt_id
           AND idempotency_key = p_idempotency_key
         FOR UPDATE;
        IF FOUND THEN
            IF v_existing.evidence_request_hash IS DISTINCT FROM v_request_hash
               OR v_existing.evidence_type IS DISTINCT FROM p_evidence_type
               OR v_existing.evidence_payload IS DISTINCT FROM p_evidence_payload
               OR v_existing.evidence_state IS DISTINCT FROM 'active' THEN
                RAISE EXCEPTION 'mb13_p3_evidence_idempotency_conflict';
            END IF;
            RETURN QUERY SELECT v_existing.evidence_id, v_existing.receipt_id, v_existing.evidence_hash;
            RETURN;
        END IF;
        RAISE EXCEPTION 'mb13_p3_evidence_insert_failed';
    END IF;

    RETURN QUERY SELECT v_new_id, v_receipt_id, v_evidence_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_record_execution_evidence(UUID, UUID, UUID, INTEGER, TEXT, JSONB, TEXT) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_record_execution_evidence(UUID, UUID, UUID, INTEGER, TEXT, JSONB, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_record_execution_evidence(UUID, UUID, UUID, INTEGER, TEXT, JSONB, TEXT) TO mb13_p3_executor, mb13_p3_writer;

-- ----------------------------------------------------------------------------
-- 5. Canonical result evidence: every verified field must match.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p3_canonicalize_result_evidence(UUID, UUID, UUID, JSONB) CASCADE;

CREATE OR REPLACE FUNCTION public.mb13_p3_canonicalize_result_evidence(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_result_payload JSONB
) RETURNS JSONB AS $$
DECLARE
    v_evidence JSONB;
    v_evidence_type TEXT;
    v_evidence_id UUID;
    v_receipt_id UUID;
    v_row public.mb13_p3_action_pack_evidence%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_expected_hash TEXT;
    v_canonical JSONB;
BEGIN
    IF p_result_payload IS NULL OR jsonb_typeof(p_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_payload_invalid';
    END IF;

    v_evidence := p_result_payload->'evidence';
    IF v_evidence IS NULL OR jsonb_typeof(v_evidence) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_required';
    END IF;
    IF v_evidence ? 'evidence_hash' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_hash_from_body_forbidden';
    END IF;

    v_evidence_type := NULLIF(v_evidence->>'evidence_type', '');
    v_evidence_id := NULLIF(v_evidence->>'evidence_id', '')::UUID;
    v_receipt_id := NULLIF(v_evidence->>'receipt_id', '')::UUID;

    IF v_evidence_type IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_type_required';
    END IF;
    IF v_evidence_id IS NULL AND v_receipt_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_not_pre_registered';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_evidence_id IS NOT NULL THEN
        SELECT * INTO v_row
          FROM public.mb13_p3_action_pack_evidence
         WHERE evidence_id = v_evidence_id
           AND owner_user_id = p_owner_user_id;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_found';
        END IF;
        IF v_row.pack_id IS DISTINCT FROM p_pack_id OR v_row.attempt_id IS DISTINCT FROM p_attempt_id THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_bound';
        END IF;
        IF v_receipt_id IS NOT NULL AND v_row.receipt_id IS DISTINCT FROM v_receipt_id THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_receipt_mismatch';
        END IF;
    ELSE
        SELECT * INTO v_row
          FROM public.mb13_p3_action_pack_evidence
         WHERE receipt_id = v_receipt_id
           AND owner_user_id = p_owner_user_id;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_found';
        END IF;
        IF v_row.pack_id IS DISTINCT FROM p_pack_id OR v_row.attempt_id IS DISTINCT FROM p_attempt_id THEN
            RAISE EXCEPTION 'mb13_p3_result_evidence_not_bound';
        END IF;
    END IF;

    IF v_row.evidence_state IS DISTINCT FROM 'active' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_quarantined';
    END IF;

    PERFORM public.mb13_p3_validate_evidence_payload_semantics(
        v_pack, v_row.evidence_type, v_row.evidence_payload, v_row.evidence_schema_version
    );

    IF v_row.evidence_type IS DISTINCT FROM v_evidence_type THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_type_mismatch';
    END IF;
    IF v_row.attempt_number IS DISTINCT FROM v_attempt.attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_attempt_number_mismatch';
    END IF;
    IF v_row.pack_revision IS DISTINCT FROM v_pack.pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_pack_revision_mismatch';
    END IF;
    IF v_row.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_monitor_revision_mismatch';
    END IF;
    IF v_row.executor_identity IS DISTINCT FROM v_attempt.executor_identity THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_executor_identity_mismatch';
    END IF;
    IF v_row.evidence_schema_version IS DISTINCT FROM 'mb13-p3-evidence/v1' THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_schema_version_mismatch';
    END IF;

    v_expected_hash := public.mb13_p0_hash_jsonb(v_row.evidence_payload);
    IF v_row.evidence_hash IS DISTINCT FROM v_expected_hash THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_integrity_failure';
    END IF;

    v_canonical := jsonb_build_object(
        'evidence', jsonb_build_object(
            'evidence_id', v_row.evidence_id,
            'receipt_id', v_row.receipt_id,
            'evidence_type', v_row.evidence_type
        ),
        'evidence_hash', v_row.evidence_hash
    );
    RETURN v_canonical;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_canonicalize_result_evidence(UUID, UUID, UUID, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_canonicalize_result_evidence(UUID, UUID, UUID, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_canonicalize_result_evidence(UUID, UUID, UUID, JSONB) TO mb13_p3_writer;

-- Backward-compatible validator returning just the evidence UUID.
DROP FUNCTION IF EXISTS public.mb13_p3_validate_result_evidence(UUID, UUID, UUID, JSONB) CASCADE;

CREATE OR REPLACE FUNCTION public.mb13_p3_validate_result_evidence(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_result_payload JSONB
) RETURNS UUID AS $$
DECLARE
    v_canonical JSONB;
BEGIN
    v_canonical := public.mb13_p3_canonicalize_result_evidence(p_owner_user_id, p_pack_id, p_attempt_id, p_result_payload);
    RETURN ((v_canonical->'evidence')->>'evidence_id')::UUID;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_validate_result_evidence(UUID, UUID, UUID, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_validate_result_evidence(UUID, UUID, UUID, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_result_evidence(UUID, UUID, UUID, JSONB) TO mb13_p3_writer;

-- ----------------------------------------------------------------------------
-- 6. Terminal pack status must close every active attempt atomically
--    and emit a per-attempt audit event.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p3_action_pack_terminal_attempt_sync() CASCADE;

CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync()
RETURNS TRIGGER AS $$
DECLARE
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_event_kind TEXT;
    v_old_status TEXT;
BEGIN
    IF NEW.status IN ('completed','partial','failed','cancelled','revoked','expired')
       AND NEW.status IS DISTINCT FROM OLD.status THEN
        v_policy_hash := public.mb13_p0_hash_jsonb(
            COALESCE((SELECT monitor_policy FROM public.mb13_p0_monitor_target
                       WHERE owner_user_id = NEW.owner_user_id AND monitor_id = NEW.monitor_id), '{}'::jsonb)
        );

        IF NEW.status = 'completed' THEN
            v_event_kind := 'attempt_completed';
        ELSIF NEW.status = 'partial' THEN
            v_event_kind := 'attempt_partial';
        ELSIF NEW.status = 'failed' THEN
            v_event_kind := 'attempt_failed';
        ELSIF NEW.status = 'cancelled' THEN
            v_event_kind := 'attempt_cancelled';
        ELSIF NEW.status = 'revoked' THEN
            v_event_kind := 'attempt_revoked';
        ELSE
            v_event_kind := 'attempt_expired';
        END IF;

        FOR v_attempt IN
            SELECT *
              FROM public.mb13_p3_action_pack_attempt
             WHERE pack_id = NEW.pack_id
               AND owner_user_id = NEW.owner_user_id
               AND status IN ('claimed','executing')
               FOR UPDATE
        LOOP
            v_old_status := v_attempt.status;
            UPDATE public.mb13_p3_action_pack_attempt
               SET status = NEW.status,
                   completed_at = COALESCE(completed_at, v_now)
             WHERE attempt_id = v_attempt.attempt_id
               AND owner_user_id = NEW.owner_user_id;

            INSERT INTO public.mb13_p3_action_pack_timeline (
                owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
                event_time, event_payload, monitor_revision, policy_hash
            ) VALUES (
                NEW.owner_user_id, NEW.pack_id, NEW.monitor_id, v_event_kind, v_old_status, NEW.status,
                v_now, jsonb_build_object(
                    'attempt_id', v_attempt.attempt_id,
                    'attempt_number', v_attempt.attempt_number,
                    'executor_identity', v_attempt.executor_identity,
                    'pack_revision', NEW.pack_revision,
                    'monitor_revision', NEW.monitor_revision
                ),
                NEW.monitor_revision, v_policy_hash
            );
        END LOOP;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync() OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync() TO mb13_p3_writer;

DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_terminal_attempt_sync ON public.mb13_p3_action_pack;
CREATE TRIGGER trg_mb13_p3_action_pack_terminal_attempt_sync
    AFTER UPDATE ON public.mb13_p3_action_pack
    FOR EACH ROW
    WHEN (NEW.status IN ('completed','partial','failed','cancelled','revoked','expired')
          AND NEW.status IS DISTINCT FROM OLD.status)
    EXECUTE FUNCTION public.mb13_p3_action_pack_terminal_attempt_sync();

-- ----------------------------------------------------------------------------
-- 7. Complete: exact evidence, outcome coherence, idempotent replay
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) CASCADE;

CREATE OR REPLACE FUNCTION public.mb13_p3_complete_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID,
    p_attempt_id UUID,
    p_expected_pack_revision INTEGER,
    p_expected_attempt_number INTEGER,
    p_outcome TEXT,
    p_result_payload JSONB
) RETURNS TABLE(
    attempt_id UUID,
    pack_id UUID,
    attempt_number INTEGER,
    status TEXT,
    result_hash TEXT,
    completed_at TIMESTAMPTZ
) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_existing_result public.mb13_p3_action_pack_result%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
    v_result_hash TEXT;
    v_event_kind TEXT;
    v_old_status TEXT;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_canonical_evidence JSONB;
    v_result_payload JSONB;
    v_evidence_status TEXT;
    v_status_allowed BOOLEAN;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_outcome NOT IN ('completed','partial','failed') THEN
        RAISE EXCEPTION 'mb13_p3_invalid_outcome';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;
    IF v_attempt.attempt_number IS DISTINCT FROM p_expected_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    IF p_result_payload IS NULL THEN
        v_result_payload := '{}'::jsonb;
    ELSE
        v_result_payload := p_result_payload;
    END IF;
    IF jsonb_typeof(v_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_payload_invalid';
    END IF;

    IF v_result_payload ? 'outcome' THEN
        IF v_result_payload->>'outcome' IS DISTINCT FROM p_outcome THEN
            RAISE EXCEPTION 'mb13_p3_result_payload_outcome_mismatch';
        END IF;
    END IF;

    IF p_outcome IN ('completed','partial') THEN
        v_canonical_evidence := public.mb13_p3_canonicalize_result_evidence(p_owner_user_id, p_pack_id, p_attempt_id, v_result_payload);
        v_evidence_status := (SELECT evidence_payload->>'status'
                                FROM public.mb13_p3_action_pack_evidence
                               WHERE evidence_id = ((v_canonical_evidence->'evidence')->>'evidence_id')::UUID
                                 AND owner_user_id = p_owner_user_id);
        v_status_allowed := false;
        IF p_outcome = 'completed' AND v_evidence_status IN ('ok','completed') THEN
            v_status_allowed := true;
        END IF;
        IF p_outcome = 'partial' AND v_evidence_status IN ('ok','completed','partial','incomplete') THEN
            v_status_allowed := true;
        END IF;
        IF NOT v_status_allowed THEN
            RAISE EXCEPTION 'mb13_p3_evidence_status_incompatible_with_outcome';
        END IF;

        v_result_payload := v_result_payload - 'evidence_hash' - 'evidence' - 'outcome';
        v_result_payload := v_result_payload || jsonb_build_object(
            'outcome', p_outcome,
            'evidence', v_canonical_evidence->'evidence',
            'evidence_hash', v_canonical_evidence->'evidence_hash'
        );
    ELSE
        v_result_payload := v_result_payload - 'outcome';
        v_result_payload := v_result_payload || jsonb_build_object('outcome', p_outcome);
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    SELECT * INTO v_existing_result
      FROM public.mb13_p3_action_pack_result
     WHERE attempt_id = p_attempt_id
       AND owner_user_id = p_owner_user_id;
    IF FOUND THEN
        -- Recompute the hash using the original stored timestamp so a canonical replay matches.
        IF v_existing_result.outcome IS DISTINCT FROM p_outcome THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
        IF v_existing_result.result_payload IS DISTINCT FROM v_result_payload THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
        RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                            p_outcome::TEXT, v_existing_result.result_hash, v_existing_result.created_at;
        RETURN;
    END IF;

    v_result_hash := public.mb13_p3_action_pack_result_hash(
        p_owner_user_id, p_pack_id, v_pack.pack_revision, p_attempt_id,
        v_attempt.attempt_number, p_outcome, v_attempt.executor_identity,
        v_result_payload, v_now
    );

    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    v_event_kind := p_outcome;
    v_old_status := v_pack.status;

    INSERT INTO public.mb13_p3_action_pack_result (
        owner_user_id, pack_id, attempt_id, attempt_number, outcome, executor_identity,
        result_payload, result_hash, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, v_attempt.attempt_number, p_outcome,
        v_attempt.executor_identity, v_result_payload, v_result_hash, v_now
    );

    UPDATE public.mb13_p3_action_pack_attempt
       SET result_payload = v_result_payload,
           result_hash = v_result_hash,
           completed_at = v_now
     WHERE attempt_id = p_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = p_outcome,
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, v_event_kind, v_old_status, p_outcome,
        v_now, jsonb_build_object('attempt_id', p_attempt_id, 'attempt_number', v_attempt.attempt_number, 'result_hash', v_result_hash),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                        p_outcome::TEXT, v_result_hash, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_complete_action_pack(UUID, UUID, UUID, INTEGER, INTEGER, TEXT, JSONB) TO mb13_p3_executor;

-- Result guard delegates to canonical validator.
DROP FUNCTION IF EXISTS public.mb13_p3_action_pack_result_evidence_guard() CASCADE;

CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_result_evidence_guard()
RETURNS TRIGGER AS $$
DECLARE
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
BEGIN
    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = NEW.attempt_id
       AND owner_user_id = NEW.owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.pack_id IS DISTINCT FROM NEW.pack_id OR v_attempt.attempt_number IS DISTINCT FROM NEW.attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_bound';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = NEW.pack_id
       AND owner_user_id = NEW.owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    IF NEW.outcome IN ('completed','partial') THEN
        PERFORM public.mb13_p3_validate_result_evidence(NEW.owner_user_id, NEW.pack_id, NEW.attempt_id, NEW.result_payload);
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_action_pack_result_evidence_guard() OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_result_evidence_guard() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_result_evidence_guard() TO mb13_p3_writer;

DROP TRIGGER IF EXISTS trg_mb13_p3_action_pack_result_evidence_guard ON public.mb13_p3_action_pack_result;
CREATE TRIGGER trg_mb13_p3_action_pack_result_evidence_guard
    BEFORE INSERT ON public.mb13_p3_action_pack_result
    FOR EACH ROW
    EXECUTE FUNCTION public.mb13_p3_action_pack_result_evidence_guard();

-- ----------------------------------------------------------------------------
-- 8. Revoke and expire action packs (terminal transitions with audit events)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p3_revoke_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID
) RETURNS TABLE(pack_id UUID, status TEXT) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status IN ('completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_already_terminal';
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_pack.status, 'revoked',
            v_now, jsonb_build_object('pack_revision', v_pack.pack_revision, 'reason', 'revoke'),
            v_pack.monitor_revision, v_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    UPDATE public.mb13_p3_action_pack
       SET status = 'revoked',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    RETURN QUERY SELECT ap.pack_id, ap.status FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_revoke_action_pack(UUID, UUID) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_revoke_action_pack(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_revoke_action_pack(UUID, UUID) TO mb13_p3_api;

CREATE OR REPLACE FUNCTION public.mb13_p3_expire_action_pack(
    p_owner_user_id UUID,
    p_pack_id UUID
) RETURNS TABLE(pack_id UUID, status TEXT) AS $$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.status IN ('completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_already_terminal';
    END IF;

    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_pack.status, 'expired',
            v_now, jsonb_build_object('pack_revision', v_pack.pack_revision, 'reason', 'expire'),
            v_pack.monitor_revision, v_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    UPDATE public.mb13_p3_action_pack
       SET status = 'expired',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'expired', v_pack.status, 'expired',
        v_now, '{}'::jsonb, v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.status FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_expire_action_pack(UUID, UUID) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_expire_action_pack(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_expire_action_pack(UUID, UUID) TO mb13_p3_api;

-- Re-enable append-only protection now that the table is consistent.
ALTER TABLE public.mb13_p3_action_pack_evidence ENABLE TRIGGER USER;

COMMIT;
