-- VEMORIA — MB3→MB4: consenso esplicito all'uso di Internet nella Scrivania.
-- Tabella separata, fail-closed (default: non consentito), owner-scoped.

CREATE TABLE IF NOT EXISTS internet_consent (
    owner_user_id    UUID PRIMARY KEY REFERENCES utenti(id) ON DELETE CASCADE,
    allowed          BOOLEAN NOT NULL DEFAULT FALSE,
    consent_version  TEXT NOT NULL DEFAULT 'v1',
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE internet_consent IS
    'Consenso esplicito e revocabile del proprietario all''uso di fonti Internet nelle risposte della Scrivania.';

CREATE INDEX IF NOT EXISTS idx_internet_consent_owner_allowed
    ON internet_consent(owner_user_id, allowed);
