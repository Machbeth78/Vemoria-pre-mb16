-- Vemoria AUDIT 01 — Privacy/GDPR/Tutela
-- Additive migration: registro richieste diritti interessato + audit export privacy.

CREATE TABLE IF NOT EXISTS privacy_rights_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    request_type TEXT NOT NULL CHECK (request_type IN (
        'access', 'portability', 'erasure', 'rectification', 'restriction', 'objection', 'automated_decision_review'
    )),
    status TEXT NOT NULL DEFAULT 'received' CHECK (status IN (
        'received', 'pending_confirmation', 'queued_manual_review', 'completed', 'rejected', 'cancelled'
    )),
    confirmation_hash TEXT NULL,
    request_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    inventory_snapshot JSONB NULL,
    response_payload JSONB NULL,
    evidence_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ NULL
);

CREATE INDEX IF NOT EXISTS idx_privacy_rights_requests_user_created
    ON privacy_rights_requests(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_privacy_rights_requests_status
    ON privacy_rights_requests(status, created_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS ux_privacy_rights_requests_evidence_hash
    ON privacy_rights_requests(evidence_hash);

CREATE TABLE IF NOT EXISTS privacy_export_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    export_type TEXT NOT NULL DEFAULT 'gdpr_zip_json',
    export_sha256 TEXT NOT NULL,
    export_size_bytes BIGINT NOT NULL DEFAULT 0,
    manifest_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    evidence_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_privacy_export_events_user_created
    ON privacy_export_events(user_id, created_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS ux_privacy_export_events_evidence_hash
    ON privacy_export_events(evidence_hash);
