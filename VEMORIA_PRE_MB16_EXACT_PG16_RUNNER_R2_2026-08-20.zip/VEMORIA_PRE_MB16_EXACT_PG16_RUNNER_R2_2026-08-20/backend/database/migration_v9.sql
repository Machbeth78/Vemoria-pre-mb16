-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V2.8 — Migration V9
-- Relazioni doc-to-doc + entità estratte

-- Relazioni documento ↔ documento/evento/dossier/entità
CREATE TABLE IF NOT EXISTS relazioni_documenti (
    relazione_id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_origine   UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    documento_destinazione UUID,          -- NULL se destinazione non è un documento
    tipo_relazione      TEXT NOT NULL,    -- 'documento'|'evento'|'dossier'|'entita'
    etichetta           TEXT,             -- descrizione libera del legame
    data_creazione      TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_reldoc_origine ON relazioni_documenti(documento_origine);
CREATE INDEX IF NOT EXISTS idx_reldoc_dest    ON relazioni_documenti(documento_destinazione);
