-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- ============================================================
-- VEMORA — Migration V4b
-- Aggiunge allegato_hash a timeline_eventi
-- La timeline diventa autosufficiente per il proof bundle.
-- ============================================================
ALTER TABLE timeline_eventi
    ADD COLUMN IF NOT EXISTS allegato_hash TEXT;
