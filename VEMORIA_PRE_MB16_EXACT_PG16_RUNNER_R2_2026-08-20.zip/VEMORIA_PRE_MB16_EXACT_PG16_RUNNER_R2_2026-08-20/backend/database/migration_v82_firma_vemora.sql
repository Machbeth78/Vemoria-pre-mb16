-- VEMORA — Migration V82: Firma Vemora
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
--
-- Firma semplice tracciata con valore di prova/deterrenza.
-- NON è firma elettronica qualificata né firma digitale PKI.
-- Il valore sta nel processo probatorio: hash, timestamp, log eventi.
--
-- Tabelle:
--   firma_profili          — profilo firma per utente/workspace
--   firma_sessioni         — singola sessione di firma su documento
--   firma_eventi_log       — log immutabile degli eventi di ogni sessione

-- ── Workspace types ──────────────────────────────────────────────────────────
-- personal: Vemora personale del proprietario
-- company: Vemora aziendale/studio separato

CREATE TABLE IF NOT EXISTS firma_profili (
    id                  UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    owner_user_id       UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    workspace_type      TEXT        NOT NULL DEFAULT 'personal'
                                    CHECK (workspace_type IN ('personal', 'company')),
    workspace_id        TEXT        NOT NULL DEFAULT 'personal',
    nome_display        TEXT,                          -- nome mostrato nella firma (es. "Mario Rossi")
    titolo              TEXT,                          -- titolo/qualifica opzionale
    signature_asset_path TEXT,                        -- path immagine firma scansionata (nullable)
    stato               TEXT        NOT NULL DEFAULT 'attivo'
                                    CHECK (stato IN ('attivo', 'sospeso', 'revocato')),
    creato_il           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (owner_user_id, workspace_type, workspace_id)
);

CREATE INDEX IF NOT EXISTS idx_firma_profili_owner
    ON firma_profili(owner_user_id);

-- ── Sessioni firma ────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS firma_sessioni (
    id                  UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    owner_user_id       UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    workspace_type      TEXT        NOT NULL DEFAULT 'personal',
    workspace_id        TEXT        NOT NULL DEFAULT 'personal',
    documento_id        UUID        REFERENCES documenti(id) ON DELETE SET NULL,
    evento_invio_id     UUID        REFERENCES eventi_invio(id) ON DELETE SET NULL,
    controparte_id      UUID        REFERENCES contatti_rubrica(id) ON DELETE SET NULL,
    -- Tipo azione richiesta
    action_type         TEXT        NOT NULL DEFAULT 'firma'
                                    CHECK (action_type IN ('firma', 'accetto', 'rifiuto', 'presa_visione')),
    -- Hash e versione del documento al momento della firma
    document_hash       TEXT,
    document_version    TEXT,
    -- Stato del processo
    stato               TEXT        NOT NULL DEFAULT 'draft'
                                    CHECK (stato IN ('draft','requested','completed','rejected','cancelled')),
    -- Classificazione documento per livello di cautela
    warning_level       TEXT        NOT NULL DEFAULT 'ok_firma_vemora'
                                    CHECK (warning_level IN ('ok_firma_vemora','attenzione','serve_firma_qualificata')),
    note_warning        TEXT,
    -- Timestamp
    requested_at        TIMESTAMPTZ,
    completed_at        TIMESTAMPTZ,
    -- Proof bundle
    proof_bundle_json   JSONB,                         -- bundle prova serializzato
    note                TEXT,
    creato_il           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_firma_sessioni_owner
    ON firma_sessioni(owner_user_id, creato_il DESC);
CREATE INDEX IF NOT EXISTS idx_firma_sessioni_documento
    ON firma_sessioni(documento_id) WHERE documento_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_firma_sessioni_stato
    ON firma_sessioni(stato);

COMMENT ON TABLE firma_sessioni IS
    'Sessione di firma Vemora — firma semplice tracciata, NON firma elettronica qualificata.';
COMMENT ON COLUMN firma_sessioni.warning_level IS
    'ok_firma_vemora: sufficiente per uso interno. attenzione: valutare caso. serve_firma_qualificata: usare FEA/PKI.';

-- ── Log eventi firma (immutabile) ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS firma_eventi_log (
    id                  UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    firma_sessione_id   UUID        NOT NULL REFERENCES firma_sessioni(id) ON DELETE CASCADE,
    actor_user_id       UUID        REFERENCES utenti(id) ON DELETE SET NULL,
    actor_role          TEXT        NOT NULL DEFAULT 'owner',  -- owner / controparte / sistema
    event_type          TEXT        NOT NULL,                  -- sessione_creata, firma_apposta, rifiutata, proof_generata, ecc.
    payload_json        JSONB,
    creato_il           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_firma_eventi_sessione
    ON firma_eventi_log(firma_sessione_id, creato_il);

COMMENT ON TABLE firma_eventi_log IS
    'Log immutabile degli eventi di una sessione firma. Contribuisce al bundle prova.';

-- Registra migrazione
-- Nota: registrazione migration demandata al migration runner/registry service.
-- Se la migration viene applicata manualmente via SQL puro, usare poi adopt-existing o status nel runner.
