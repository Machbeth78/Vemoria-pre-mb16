-- VEMORIA MB11-P2 Phase A R1C
-- Extend merge/split snapshots to candidate proposals and rejection records.
-- PostgreSQL 14+

BEGIN;

ALTER TABLE canonical_identity_merge_log
  ADD COLUMN IF NOT EXISTS prior_source_proposals JSONB,
  ADD COLUMN IF NOT EXISTS prior_source_rejected JSONB,
  ADD COLUMN IF NOT EXISTS prior_target_proposals JSONB,
  ADD COLUMN IF NOT EXISTS prior_target_rejected JSONB;

ALTER TABLE canonical_identity_split_log
  ADD COLUMN IF NOT EXISTS prior_source_proposals JSONB,
  ADD COLUMN IF NOT EXISTS prior_source_rejected JSONB;

COMMIT;
