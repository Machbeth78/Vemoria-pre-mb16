-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB12-P0 R1B — Governed foundation entity, eligibility and revision history.
-- Additive, idempotent migration. Renames v175 revision history only once and
-- migrates rows into the new append-only history table.

BEGIN;

DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relname = 'mb12_p0_revision_history' AND c.relkind = 'r'
    ) AND NOT EXISTS (
        SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relname = 'mb12_p0_revision_history_r1_deprecated' AND c.relkind = 'r'
    ) THEN
        ALTER TABLE mb12_p0_revision_history RENAME TO mb12_p0_revision_history_r1_deprecated;
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS mb12_p0_foundation_entity (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    entity_id TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    stable_id TEXT NOT NULL,
    revision INT NOT NULL DEFAULT 1,
    canonical_name TEXT NOT NULL DEFAULT '',
    state TEXT NOT NULL DEFAULT 'draft',
    valid_from TIMESTAMPTZ,
    valid_to TIMESTAMPTZ,
    publication_date TIMESTAMPTZ,
    superseded_by TEXT,
    retroactivity_state TEXT NOT NULL DEFAULT 'none',
    unknown_validity INT NOT NULL DEFAULT 0,
    conflicting_validity INT NOT NULL DEFAULT 0,
    source_authority_state TEXT NOT NULL DEFAULT 'unknown',
    jurisdiction_applicability_state TEXT NOT NULL DEFAULT 'unknown',
    jurisdiction_state TEXT NOT NULL DEFAULT 'unknown',
    territory_state TEXT NOT NULL DEFAULT '',
    confidence REAL NOT NULL DEFAULT 0.0,
    uncertainty JSONB NOT NULL DEFAULT '{}',
    source_refs JSONB NOT NULL DEFAULT '[]',
    provenance JSONB NOT NULL DEFAULT '{}',
    revocation JSONB,
    data JSONB NOT NULL DEFAULT '{}',
    payload_hash TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, entity_id),
    UNIQUE (owner_user_id, stable_id, revision),
    CONSTRAINT chk_mb12_p0_retroactivity_state CHECK (
        retroactivity_state IN ('none', 'proactive', 'retroactive', 'transitional')
    )
);

CREATE INDEX IF NOT EXISTS idx_mb12_entity_owner_type_state
    ON mb12_p0_foundation_entity(owner_user_id, entity_type, state);

ALTER TABLE mb12_p0_foundation_entity ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb12_p0_foundation_entity FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb12_p0_foundation_entity_owner_policy ON mb12_p0_foundation_entity;
CREATE POLICY mb12_p0_foundation_entity_owner_policy ON mb12_p0_foundation_entity
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

CREATE TABLE IF NOT EXISTS mb12_p0_eligibility_evaluation (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    evaluation_id TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    request_id TEXT NOT NULL DEFAULT '',
    dossier_id TEXT NOT NULL DEFAULT '',
    rule_set_id TEXT NOT NULL DEFAULT '',
    result TEXT NOT NULL,
    criteria JSONB NOT NULL DEFAULT '[]',
    missing JSONB NOT NULL DEFAULT '[]',
    evidence JSONB NOT NULL DEFAULT '[]',
    conflicting_rules JSONB NOT NULL DEFAULT '[]',
    consent_reference TEXT NOT NULL DEFAULT '',
    evaluated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    legal_certainty REAL NOT NULL DEFAULT 0.0,
    PRIMARY KEY (owner_user_id, evaluation_id)
);

CREATE INDEX IF NOT EXISTS idx_mb12_eval_owner_subject
    ON mb12_p0_eligibility_evaluation(owner_user_id, subject_id);

ALTER TABLE mb12_p0_eligibility_evaluation ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb12_p0_eligibility_evaluation FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb12_p0_eligibility_evaluation_owner_policy ON mb12_p0_eligibility_evaluation;
CREATE POLICY mb12_p0_eligibility_evaluation_owner_policy ON mb12_p0_eligibility_evaluation
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

CREATE TABLE IF NOT EXISTS mb12_p0_revision_history (
    history_id UUID NOT NULL PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    record_id TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    revision INT NOT NULL DEFAULT 1,
    operation TEXT NOT NULL,
    payload JSONB NOT NULL,
    payload_hash TEXT NOT NULL DEFAULT '',
    previous_revision INT,
    payload_version TEXT NOT NULL DEFAULT 'r1b',
    source_refs JSONB NOT NULL DEFAULT '[]',
    provenance JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mb12_history_owner_record
    ON mb12_p0_revision_history(owner_user_id, record_id);

CREATE INDEX IF NOT EXISTS idx_mb12_history_created
    ON mb12_p0_revision_history(owner_user_id, record_id, created_at);

ALTER TABLE mb12_p0_revision_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb12_p0_revision_history FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb12_p0_revision_history_owner_policy ON mb12_p0_revision_history;
CREATE POLICY mb12_p0_revision_history_owner_policy ON mb12_p0_revision_history
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

-- Migrate v175 revision history rows into the new R1B history table once.
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relname = 'mb12_p0_revision_history_r1_deprecated' AND c.relkind = 'r'
    ) THEN
        INSERT INTO mb12_p0_revision_history (
            owner_user_id, record_id, entity_type, revision, operation,
            payload, payload_hash, previous_revision, payload_version, source_refs, provenance, created_at
        )
        SELECT
            d.owner_user_id,
            d.record_id,
            d.entity_type,
            d.revision::int,
            d.operation,
            jsonb_build_object(
                'entity_id', d.record_id,
                'entity_type', d.entity_type,
                'stable_id', d.record_id,
                'revision', d.revision::int,
                'canonical_name', '',
                'state', 'promoted',
                'status', 'promoted',
                'data', d.payload,
                'source_refs', d.source_refs,
                'owner_id', d.owner_user_id::text,
                'source_authority_state', 'unknown',
                'jurisdiction_applicability_state', 'unknown',
                'jurisdiction_state', 'unknown',
                'territory_state', '',
                'confidence', 0.0,
                'uncertainty', '{}'::jsonb,
                'provenance', '{}'::jsonb,
                'retroactivity_state', 'none',
                'unknown_validity', false,
                'conflicting_validity', false
            ),
            '',
            NULL,
            'v175',
            d.source_refs,
            jsonb_build_object('migrated_from', 'mb12_p0_revision_history_r1_deprecated'),
            d.created_at
        FROM mb12_p0_revision_history_r1_deprecated d
        WHERE NOT EXISTS (
            SELECT 1 FROM mb12_p0_revision_history h
            WHERE h.owner_user_id = d.owner_user_id
              AND h.record_id = d.record_id
              AND h.revision = d.revision::int
              AND h.operation = d.operation
              AND h.payload_version = 'v175'
        );
    END IF;
END $$;

COMMIT;
