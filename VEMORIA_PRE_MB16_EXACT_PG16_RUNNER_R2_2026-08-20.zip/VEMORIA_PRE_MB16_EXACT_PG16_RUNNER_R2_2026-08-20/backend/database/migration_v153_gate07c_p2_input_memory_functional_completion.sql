-- Vemoria Gate07C — P2 Input/Memory functional completion
-- Code integration bookkeeping only. Does not claim Android camera/OCR/filesystem/Vault runtime PASS.

CREATE TABLE IF NOT EXISTS gate07c_p2_input_memory_functional_completion (
    id BIGSERIAL PRIMARY KEY,
    vc_id TEXT NOT NULL UNIQUE,
    integration_state TEXT NOT NULL CHECK (integration_state = 'CODICE_INTEGRATO'),
    runtime_real TEXT NOT NULL CHECK (runtime_real IN ('NON_ESEGUITO','FLUTTER_ANDROID_RETE_NON_ESEGUITO','LAB_SUPERATO_PRODUZIONE_NON_ESEGUITA')),
    completion_state TEXT NOT NULL CHECK (completion_state = 'FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED'),
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE CHECK (runtime_pass_claimed = FALSE),
    evidence JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO gate07c_p2_input_memory_functional_completion (vc_id, integration_state, runtime_real, completion_state, evidence) VALUES
('VC-025','CODICE_INTEGRATO','FLUTTER_ANDROID_RETE_NON_ESEGUITO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED','["backend/services/input_memory_p2_functional_service.py","backend/api/routers/input_memory_p2_functional.py","backend/tests/test_gate07c_p2_input_memory_functional_static.py"]'::jsonb),
('VC-027','CODICE_INTEGRATO','FLUTTER_ANDROID_RETE_NON_ESEGUITO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED','["backend/services/input_memory_p2_functional_service.py","backend/api/routers/input_memory_p2_functional.py","backend/tests/test_gate07c_p2_input_memory_functional_static.py"]'::jsonb),
('VC-035','CODICE_INTEGRATO','LAB_SUPERATO_PRODUZIONE_NON_ESEGUITA','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED','["backend/services/input_memory_p2_functional_service.py","backend/api/routers/input_memory_p2_functional.py","backend/tests/test_gate07c_p2_input_memory_functional_static.py"]'::jsonb),
('VC-037','CODICE_INTEGRATO','NON_ESEGUITO','FUNCTIONAL_CODE_COMPLETED_RUNTIME_DEFERRED','["backend/services/input_memory_p2_functional_service.py","backend/api/routers/input_memory_p2_functional.py","backend/tests/test_gate07c_p2_input_memory_functional_static.py"]'::jsonb)
ON CONFLICT (vc_id) DO UPDATE SET
    integration_state = EXCLUDED.integration_state,
    runtime_real = EXCLUDED.runtime_real,
    completion_state = EXCLUDED.completion_state,
    runtime_pass_claimed = FALSE,
    evidence = EXCLUDED.evidence;
