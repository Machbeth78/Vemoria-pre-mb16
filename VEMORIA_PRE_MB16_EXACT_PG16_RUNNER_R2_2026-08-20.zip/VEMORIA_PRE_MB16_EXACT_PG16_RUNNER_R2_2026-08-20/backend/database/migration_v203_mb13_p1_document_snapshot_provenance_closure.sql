-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB13-P1 R2 V203 — Exact Document Snapshot and Monitor-Bound Provenance Closure.
-- Additive, idempotent migration. Does not modify previous migrations.

BEGIN;

-- ----------------------------------------------------------------------------
-- 1. Worker can no longer read documenti directly.
-- ----------------------------------------------------------------------------
REVOKE SELECT ON public.documenti FROM mb13_p1_worker;

-- ----------------------------------------------------------------------------
-- 2. Owner-scoped, job-bound document payload loader.
--    The worker must never SELECT documenti directly; it calls this function
--    and receives the payload from the append-only revision snapshot.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_get_authorized_document_payload(
    p_job_id UUID,
    p_preflight_id UUID,
    p_claim_nonce TEXT,
    p_document_id UUID,
    p_revision INTEGER
) RETURNS JSONB AS $$
DECLARE
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_job public.mb13_p1_diff_job_queue%ROWTYPE;
    v_preflight public.mb13_p1_preflight_state%ROWTYPE;
    v_target_ref JSONB;
    v_doc public.mb13_p1_document_revision%ROWTYPE;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    IF p_job_id IS NULL OR p_preflight_id IS NULL OR p_claim_nonce IS NULL OR p_document_id IS NULL OR p_revision IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_parameters_required';
    END IF;

    SELECT * INTO v_job
      FROM public.mb13_p1_diff_job_queue
     WHERE job_id = p_job_id;
    IF NOT FOUND OR v_job.status <> 'claimed' OR v_job.claimed_by IS DISTINCT FROM v_session_user
       OR v_job.claim_nonce IS DISTINCT FROM p_claim_nonce OR v_job.envelope_id IS NOT NULL THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_job_invalid';
    END IF;

    SELECT * INTO v_preflight
      FROM public.mb13_p1_preflight_state
     WHERE preflight_id = p_preflight_id;
    IF NOT FOUND OR v_preflight.job_id IS DISTINCT FROM p_job_id OR v_preflight.used THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_preflight_invalid';
    END IF;
    IF v_preflight.expires_at <= NOW() THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_preflight_expired';
    END IF;

    -- The requested revision must be one of the two refs bound to the preflight.
    IF (v_preflight.baseline_ref->>'id')::UUID = p_document_id
       AND (v_preflight.baseline_ref->>'revision')::INTEGER = p_revision THEN
        v_target_ref := v_preflight.baseline_ref;
    ELSIF (v_preflight.observation_ref->>'id')::UUID = p_document_id
          AND (v_preflight.observation_ref->>'revision')::INTEGER = p_revision THEN
        v_target_ref := v_preflight.observation_ref;
    ELSE
        RAISE EXCEPTION 'mb13_p1_authorized_payload_target_not_in_preflight';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = v_preflight.owner_user_id
       AND monitor_id = v_preflight.monitor_id;
    IF NOT FOUND OR v_monitor.monitor_state <> 'active' OR v_monitor.target_type <> 'document'
       OR (v_monitor.target_ref->>'id')::UUID IS DISTINCT FROM p_document_id THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_monitor_mismatch';
    END IF;

    SELECT * INTO v_doc
      FROM public.mb13_p1_document_revision
     WHERE owner_user_id = v_preflight.owner_user_id
       AND document_id = p_document_id
       AND revision = p_revision
       AND state = 'memorizzato';
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_document_revision_not_found';
    END IF;
    IF v_doc.payload_hash IS DISTINCT FROM v_target_ref->>'payload_hash' THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_hash_mismatch';
    END IF;
    IF v_doc.owner_user_id IS DISTINCT FROM v_preflight.owner_user_id THEN
        RAISE EXCEPTION 'mb13_p1_authorized_payload_owner_mismatch';
    END IF;

    RETURN jsonb_build_object(
        'dati_strutturati', COALESCE(v_doc.dati_strutturati, '{}'::jsonb),
        'testo_grezzo', COALESCE(v_doc.testo_grezzo, ''),
        'payload_hash', v_doc.payload_hash,
        'state', v_doc.state
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_get_authorized_document_payload(UUID, UUID, TEXT, UUID, INTEGER) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_get_authorized_document_payload(UUID, UUID, TEXT, UUID, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_get_authorized_document_payload(UUID, UUID, TEXT, UUID, INTEGER) TO mb13_p1_worker;

-- ----------------------------------------------------------------------------
-- 3. Target resolver now uses only mb13_p1_document_revision for document
--    targets.  Revision 1 is a snapshot, not a mutable documenti row.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_resolve_target(
    p_owner UUID,
    p_target_type TEXT,
    p_target_ref JSONB
) RETURNS TABLE(state TEXT, payload_hash TEXT, target_revision INTEGER) AS $$
DECLARE
    v_id TEXT;
    v_revision INTEGER;
    v_hash TEXT;
    v_state TEXT;
    v_doc RECORD;
    v_dossier RECORD;
    v_decision RECORD;
    v_rev RECORD;
BEGIN
    IF jsonb_typeof(p_target_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p1_target_ref_invalid';
    END IF;
    IF p_target_ref->>'id' IS NULL OR p_target_ref->>'revision' IS NULL OR p_target_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_target_ref_missing';
    END IF;
    IF p_target_ref->>'owner_user_id' IS DISTINCT FROM p_owner::text THEN
        RAISE EXCEPTION 'mb13_p1_target_owner_mismatch';
    END IF;

    v_id := p_target_ref->>'id';
    BEGIN
        v_revision := (p_target_ref->>'revision')::INTEGER;
    EXCEPTION WHEN invalid_text_representation THEN
        RAISE EXCEPTION 'mb13_p1_target_ref_invalid';
    END;
    v_hash := p_target_ref->>'payload_hash';
    v_state := p_target_ref->>'state';

    IF v_revision < 1 THEN
        RAISE EXCEPTION 'mb13_p1_target_revision_invalid';
    END IF;

    IF p_target_type = 'document' THEN
        SELECT r.state, r.payload_hash, r.revision INTO v_doc
          FROM public.mb13_p1_document_revision r
         WHERE r.document_id = v_id::UUID
           AND r.owner_user_id = p_owner
           AND r.revision = v_revision
         FOR SHARE;

        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p1_target_not_found';
        END IF;

        v_state := v_doc.state;

        IF v_state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p1_target_revoked';
        END IF;
        IF v_state <> 'memorizzato' THEN
            RAISE EXCEPTION 'mb13_p1_target_not_available';
        END IF;
        IF v_doc.payload_hash <> v_hash THEN
            RAISE EXCEPTION 'mb13_p1_target_reference_not_current';
        END IF;

        RETURN QUERY SELECT v_state, v_hash, v_revision;
        RETURN;
    END IF;

    IF p_target_type IN ('dossier','contract','offer') THEN
        SELECT d.current_revision, d.payload_hash, d.state INTO v_dossier
          FROM public.mb12_p1_offer_contract d
         WHERE d.owner_user_id = p_owner
           AND d.dossier_id = v_id::UUID
         FOR SHARE;

        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p1_target_not_found';
        END IF;

        IF v_dossier.state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p1_target_revoked';
        END IF;

        SELECT r.state, r.payload_hash, r.revision INTO v_rev
          FROM public.mb12_p1_offer_contract_revision r
         WHERE r.owner_user_id = p_owner
           AND r.dossier_id = v_id::UUID
           AND r.revision = v_revision
         FOR SHARE;

        IF NOT FOUND
           OR v_rev.payload_hash <> v_hash
           OR v_rev.state <> 'normalized'
           OR (v_state IS NOT NULL AND v_state IS DISTINCT FROM v_rev.state) THEN
            RAISE EXCEPTION 'mb13_p1_target_reference_not_current';
        END IF;

        RETURN QUERY SELECT v_rev.state, v_hash, v_revision;
        RETURN;
    END IF;

    IF p_target_type = 'decision' THEN
        SELECT d.current_revision, d.payload_hash, d.state INTO v_decision
          FROM public.mb12_p4_governed_explainable_ranking d
         WHERE d.owner_user_id = p_owner
           AND d.ranking_id = v_id::UUID
         FOR SHARE;

        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p1_target_not_found';
        END IF;

        IF v_decision.state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p1_target_revoked';
        END IF;

        SELECT r.state, r.payload_hash, r.revision INTO v_rev
          FROM public.mb12_p4_governed_explainable_ranking_revision r
         WHERE r.owner_user_id = p_owner
           AND r.ranking_id = v_id::UUID
           AND r.revision = v_revision
         FOR SHARE;

        IF NOT FOUND
           OR v_rev.payload_hash <> v_hash
           OR v_rev.state NOT IN ('ready','incomplete','incompatible')
           OR (v_state IS NOT NULL AND v_state IS DISTINCT FROM v_rev.state) THEN
            RAISE EXCEPTION 'mb13_p1_target_reference_not_current';
        END IF;

        RETURN QUERY SELECT v_rev.state, v_hash, v_revision;
        RETURN;
    END IF;

    IF p_target_type = 'source' THEN
        RAISE EXCEPTION 'mb13_p1_source_payload_not_diffable';
    END IF;

    IF p_target_type = 'rule' THEN
        RAISE EXCEPTION 'mb13_p1_target_type_not_supported';
    END IF;

    RAISE EXCEPTION 'mb13_p1_target_type_not_supported';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_resolve_target(UUID, TEXT, JSONB) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_resolve_target(UUID, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_resolve_target(UUID, TEXT, JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_resolve_target(UUID, TEXT, JSONB) TO mb13_p1_executor;

-- ----------------------------------------------------------------------------
-- 4. Document revision append now reads public.documenti only to create the
--    first snapshot atomically.  Existing revisions are validated against the
--    append-only revision table alone.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_append_document_revision(
    p_owner_user_id UUID,
    p_document_id UUID,
    p_revision INTEGER,
    p_state TEXT,
    p_payload_hash TEXT,
    p_dati_strutturati JSONB,
    p_testo_grezzo TEXT,
    p_supersedes_revision INTEGER DEFAULT NULL
) RETURNS UUID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_doc_owner UUID;
    v_last_revision INTEGER := 0;
    v_last_hash TEXT;
    v_revision INTEGER := p_revision;
    v_supersedes INTEGER := p_supersedes_revision;
    v_payload_hash TEXT;
    v_revision_id UUID := gen_random_uuid();
    v_doc_dati JSONB;
    v_doc_testo TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_owner_param_mismatch';
    END IF;
    IF p_state NOT IN ('memorizzato','revoked') THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_state_invalid';
    END IF;

    SELECT revision, payload_hash, owner_user_id
      INTO v_last_revision, v_last_hash, v_doc_owner
      FROM public.mb13_p1_document_revision
     WHERE owner_user_id = p_owner_user_id
       AND document_id = p_document_id
     ORDER BY revision DESC
     LIMIT 1
     FOR UPDATE;

    IF NOT FOUND THEN
        v_last_revision := 0;
    END IF;

    IF v_last_revision = 0 THEN
        -- First revision must be atomically snapshotted from documenti.
        SELECT proprietario_id, dati_strutturati, testo_grezzo
          INTO v_doc_owner, v_doc_dati, v_doc_testo
          FROM public.documenti
         WHERE id = p_document_id
         FOR UPDATE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p1_document_not_found';
        END IF;
        IF v_doc_owner IS DISTINCT FROM p_owner_user_id THEN
            RAISE EXCEPTION 'mb13_p1_document_not_found_or_owner_mismatch';
        END IF;

        IF v_revision IS NOT NULL AND v_revision > 1 THEN
            -- Auto-snapshot revision 1 from the current documenti row.
            v_doc_testo := COALESCE(v_doc_testo, '');
            v_doc_dati := COALESCE(v_doc_dati, '{}'::jsonb);
            v_last_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
                'owner_user_id', v_doc_owner,
                'document_id', p_document_id,
                'revision', 1,
                'state', 'memorizzato',
                'dati_strutturati', v_doc_dati,
                'testo_grezzo', v_doc_testo,
                'supersedes_revision', NULL
            ));
            INSERT INTO public.mb13_p1_document_revision (
                owner_user_id, document_id, revision, state, payload_hash,
                dati_strutturati, testo_grezzo, supersedes_revision, created_at
            ) VALUES (
                v_doc_owner, p_document_id, 1, 'memorizzato', v_last_hash,
                v_doc_dati, v_doc_testo, NULL, NOW()
            );
            v_last_revision := 1;
        END IF;
    ELSE
        IF v_doc_owner IS DISTINCT FROM p_owner_user_id THEN
            RAISE EXCEPTION 'mb13_p1_document_not_found_or_owner_mismatch';
        END IF;
    END IF;

    IF v_revision IS NULL THEN
        v_revision := v_last_revision + 1;
    END IF;
    IF v_revision < 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_invalid';
    END IF;

    IF v_revision <> v_last_revision + 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_skipped';
    END IF;

    IF v_supersedes IS NULL THEN
        v_supersedes := v_last_revision;
    END IF;
    IF v_supersedes IS DISTINCT FROM v_last_revision THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_supersedes_mismatch';
    END IF;
    IF v_last_hash IS NULL AND v_last_revision >= 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_baseline_hash_missing';
    END IF;

    IF EXISTS (
        SELECT 1 FROM public.mb13_p1_document_revision
         WHERE owner_user_id = p_owner_user_id
           AND document_id = p_document_id
           AND revision = v_revision
    ) THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_already_exists';
    END IF;

    v_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_doc_owner,
        'document_id', p_document_id,
        'revision', v_revision,
        'state', p_state,
        'dati_strutturati', COALESCE(p_dati_strutturati, '{}'::jsonb),
        'testo_grezzo', COALESCE(p_testo_grezzo, ''),
        'supersedes_revision', v_supersedes
    ));

    INSERT INTO public.mb13_p1_document_revision (
        owner_user_id, document_id, revision, state, payload_hash,
        dati_strutturati, testo_grezzo, supersedes_revision, created_at
    ) VALUES (
        v_doc_owner, p_document_id, v_revision, p_state, v_payload_hash,
        p_dati_strutturati, p_testo_grezzo, v_supersedes, NOW()
    )
    RETURNING revision_id INTO v_revision_id;

    RETURN v_revision_id;
EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION 'mb13_p1_document_revision_concurrent_insert';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) TO mb13_p1_api;

-- ----------------------------------------------------------------------------
-- 4b. Enrich partial source-card refs to a complete relational chain.  All
--     original fields are preserved; missing required keys are filled from
--     an active binding looked up by source_id and grant_id.  Unresolvable
--     refs raise instead of being silently dropped.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_enrich_source_card_refs(
    p_owner UUID,
    p_refs JSONB
) RETURNS JSONB AS $$
DECLARE
    v_ref JSONB;
    v_enriched JSONB := '[]'::jsonb;
    v_source_id TEXT;
    v_grant_id TEXT;
    v_evidence_id TEXT;
    v_binding RECORD;
    v_full JSONB;
    v_provided_evidence TEXT;
BEGIN
    IF p_refs IS NULL OR jsonb_typeof(p_refs) <> 'array' THEN
        RETURN '[]'::jsonb;
    END IF;

    FOR v_ref IN SELECT value FROM jsonb_array_elements(p_refs) LOOP
        IF jsonb_typeof(v_ref) <> 'object' OR v_ref = '{}'::jsonb THEN
            RAISE EXCEPTION 'mb13_p1_provenance_empty_reference';
        END IF;

        IF (v_ref->>'source_card_id') IS NOT NULL
           AND (v_ref->>'source_id') IS NOT NULL
           AND (v_ref->>'source_revision_id') IS NOT NULL
           AND (v_ref->>'evidence_id') IS NOT NULL
           AND (v_ref->>'grant_id') IS NOT NULL THEN
            v_full := v_ref;
            IF v_full->>'provenance_kind' IS NULL THEN
                v_full := v_full || '{"provenance_kind":"source_card"}'::jsonb;
            END IF;
            v_enriched := v_enriched || jsonb_build_array(v_full);
            CONTINUE;
        END IF;

        v_source_id := v_ref->>'source_id';
        IF v_source_id IS NULL THEN
            RAISE EXCEPTION 'mb13_p1_provenance_source_id_missing';
        END IF;
        v_grant_id := v_ref->>'grant_id';
        v_evidence_id := v_ref->>'evidence_id';

        SELECT b.source_card_id,
               b.source_id::text AS source_id,
               b.source_revision_id::text AS source_revision_id,
               b.evidence_id::text AS evidence_id,
               b.grant_id::text AS grant_id,
               b.content_hash
          INTO v_binding
          FROM public.mb12_p0_source_card_binding b
          JOIN public.authorized_memory_sources s
            ON s.id = b.source_id
           AND s.user_id = b.owner_user_id
          JOIN public.authorized_memory_inventory_items i
            ON i.id = b.source_revision_id
           AND i.user_id = b.owner_user_id
          JOIN public.authorized_memory_activity_log e
            ON e.id = b.evidence_id
           AND e.user_id = b.owner_user_id
         WHERE b.owner_user_id = p_owner
           AND b.source_id = v_source_id::UUID
           AND b.grant_id IS NOT DISTINCT FROM NULLIF(v_grant_id, '')::UUID
           AND b.status = 'active'
           AND b.revoked_at IS NULL
           AND s.status = 'active'
           AND s.revoked_at IS NULL
           AND i.deleted_at IS NULL
           AND i.identity_state <> 'revoked'
           AND i.memory_state <> 'revoked'
         ORDER BY b.source_card_id
         LIMIT 1;

        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p1_provenance_evidence_not_resolved';
        END IF;

        -- If the caller supplied an evidence_id, it must match the resolved
        -- binding; a mismatch indicates a cross-owner or stale evidence id.
        v_provided_evidence := NULLIF(v_evidence_id, '');
        IF v_provided_evidence IS NOT NULL
           AND v_provided_evidence IS DISTINCT FROM v_binding.evidence_id THEN
            RAISE EXCEPTION 'mb13_p1_provenance_evidence_cross_owner';
        END IF;

        -- Preserve the original object and overlay the canonical binding fields.
        v_full := v_ref || jsonb_build_object(
            'provenance_kind', 'source_card',
            'source_card_id', v_binding.source_card_id,
            'source_id', v_binding.source_id,
            'source_revision_id', v_binding.source_revision_id,
            'evidence_id', v_binding.evidence_id,
            'grant_id', v_binding.grant_id,
            'content_hash', v_binding.content_hash
        );
        v_enriched := v_enriched || jsonb_build_array(v_full);
    END LOOP;

    RETURN v_enriched;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_enrich_source_card_refs(UUID, JSONB) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_enrich_source_card_refs(UUID, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_enrich_source_card_refs(UUID, JSONB) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p1_enrich_source_card_refs(UUID, JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_enrich_source_card_refs(UUID, JSONB) TO mb13_p1_api;

-- ----------------------------------------------------------------------------
-- 5. Provenance lookup for source/dossier/decision now tags refs with an
--    explicit provenance_kind.  The 3-arg overload for document is kept for
--    backward compatibility (e.g. monitor creation) but does not perform a
--    monitor-bound lookup.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p0_get_target_provenance(
    p_owner UUID,
    p_target_type TEXT,
    p_target_ref JSONB
)
RETURNS TABLE(source_refs JSONB, evidence_refs JSONB) AS $$
DECLARE
    v_id TEXT;
    v_revision INTEGER;
    v_hash TEXT;
    v_owner_text TEXT;
    v_source_refs JSONB;
    v_evidence_refs JSONB;
BEGIN
    IF p_target_ref IS NULL OR jsonb_typeof(p_target_ref) <> 'object' THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    v_id := p_target_ref->>'id';
    IF v_id IS NULL OR length(trim(v_id)) = 0 THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    BEGIN
        v_revision := (p_target_ref->>'revision')::INTEGER;
    EXCEPTION WHEN invalid_text_representation THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END;

    v_hash := p_target_ref->>'payload_hash';
    v_owner_text := COALESCE(p_target_ref->>'owner_user_id', p_owner::text);

    IF p_target_type = 'source' THEN
        SELECT
            jsonb_build_array(jsonb_build_object(
                'provenance_kind', 'source_card',
                'source_card_id', b.source_card_id,
                'source_id', b.source_id::text,
                'source_revision_id', b.source_revision_id::text,
                'evidence_id', b.evidence_id::text,
                'grant_id', b.grant_id::text,
                'content_hash', b.content_hash
            )),
            COALESCE((
                SELECT jsonb_agg(jsonb_build_object(
                    'provenance_kind', 'source_card',
                    'evidence_id', b2.evidence_id::text,
                    'source_id', b2.source_id::text,
                    'source_card_id', b2.source_card_id,
                    'source_revision_id', b2.source_revision_id::text,
                    'grant_id', b2.grant_id::text,
                    'content_hash', b2.content_hash
                ) ORDER BY b2.evidence_id::text)
                  FROM public.mb12_p0_source_card_binding b2
                 WHERE b2.owner_user_id = p_owner
                   AND b2.source_card_id = v_id
            ), '[]'::jsonb)
          INTO v_source_refs, v_evidence_refs
          FROM public.mb12_p0_source_card_binding b
         WHERE b.owner_user_id = p_owner
           AND b.source_card_id = v_id
         FOR SHARE;
        RETURN QUERY SELECT COALESCE(v_source_refs, '[]'::jsonb), COALESCE(v_evidence_refs, '[]'::jsonb);
        RETURN;
    END IF;

    IF p_target_type IN ('dossier','contract','offer') THEN
        SELECT r.source_refs
          INTO v_source_refs
          FROM public.mb12_p1_offer_contract_revision r
         WHERE r.owner_user_id = p_owner
           AND r.dossier_id = v_id::UUID
           AND r.revision = v_revision;

        IF v_source_refs IS NOT NULL THEN
            v_source_refs := public.mb13_p1_enrich_source_card_refs(p_owner, v_source_refs);
            -- Evidence refs carry the same relational chain but are tagged so
            -- the distinctness check in resolve_exact_provenance does not see
            -- them as duplicates of the source refs.
            v_evidence_refs := COALESCE((
                SELECT jsonb_agg(s.value || jsonb_build_object('provenance_role', 'evidence'))
                  FROM jsonb_array_elements(v_source_refs) WITH ORDINALITY AS s(value, ord)
                 WHERE (s.value->>'evidence_id') IS NOT NULL
            ), '[]'::jsonb);
            RETURN QUERY SELECT COALESCE(v_source_refs, '[]'::jsonb), v_evidence_refs;
            RETURN;
        END IF;
    END IF;

    IF p_target_type = 'decision' THEN
        SELECT rev.result_payload->'source_refs'
          INTO v_source_refs
          FROM public.mb12_p4_governed_explainable_ranking r
          JOIN public.mb12_p4_governed_explainable_ranking_revision rev
            ON rev.owner_user_id = r.owner_user_id
           AND rev.ranking_id = r.ranking_id
           AND rev.revision = v_revision
         WHERE r.owner_user_id = p_owner
           AND r.ranking_id = v_id::UUID
         FOR SHARE OF r, rev;

        IF v_source_refs IS NOT NULL THEN
            v_source_refs := public.mb13_p1_enrich_source_card_refs(p_owner, v_source_refs);
            v_evidence_refs := COALESCE((
                SELECT jsonb_agg(s.value || jsonb_build_object('provenance_role', 'evidence'))
                  FROM jsonb_array_elements(v_source_refs) WITH ORDINALITY AS s(value, ord)
                 WHERE (s.value->>'evidence_id') IS NOT NULL
            ), '[]'::jsonb);
            RETURN QUERY SELECT COALESCE(v_source_refs, '[]'::jsonb), v_evidence_refs;
            RETURN;
        END IF;
    END IF;

    -- 3-arg overload: document targets carry no intrinsic source-card provenance.
    -- The monitor-bound provenance for P1 diffs is computed by the 5-arg overload.
    IF p_target_type = 'document' THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
    RETURN;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 6. Monitor-bound provenance lookup overload.
--    For document targets this binds provenance to the exact monitor running
--    the comparison and to the consents attached to that monitor.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p0_get_target_provenance(
    p_owner UUID,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_monitor_id UUID,
    p_consent_refs JSONB DEFAULT '[]'::jsonb
)
RETURNS TABLE(source_refs JSONB, evidence_refs JSONB) AS $$
DECLARE
    v_id TEXT;
    v_revision INTEGER;
    v_hash TEXT;
    v_owner_text TEXT;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_source_refs JSONB;
BEGIN
    IF p_target_ref IS NULL OR jsonb_typeof(p_target_ref) <> 'object' THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    v_id := p_target_ref->>'id';
    IF v_id IS NULL OR length(trim(v_id)) = 0 THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    BEGIN
        v_revision := (p_target_ref->>'revision')::INTEGER;
    EXCEPTION WHEN invalid_text_representation THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END;

    v_hash := p_target_ref->>'payload_hash';
    v_owner_text := COALESCE(p_target_ref->>'owner_user_id', p_owner::text);

    IF p_target_type <> 'document' THEN
        RETURN QUERY SELECT * FROM public.mb13_p0_get_target_provenance(p_owner, p_target_type, p_target_ref);
        RETURN;
    END IF;

    IF p_monitor_id IS NULL THEN
        v_source_refs := jsonb_build_array(jsonb_build_object(
            'provenance_kind', 'local_document_revision',
            'document_id', v_id,
            'document_revision', v_revision,
            'document_payload_hash', v_hash,
            'owner_user_id', v_owner_text,
            'monitor_id', NULL
        ));
        RETURN QUERY SELECT public.mb13_p0_normalize_jsonb_array(v_source_refs), '[]'::jsonb;
        RETURN;
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner
       AND monitor_id = p_monitor_id
       AND monitor_state = 'active'
       AND target_type = 'document'
       AND target_ref->>'id' = v_id
     FOR SHARE;
    IF NOT FOUND THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    v_source_refs := COALESCE((
        SELECT jsonb_agg(jsonb_build_object(
            'provenance_kind', 'local_document_revision',
            'document_id', v_id,
            'document_revision', v_revision,
            'document_payload_hash', v_hash,
            'owner_user_id', v_owner_text,
            'monitor_id', p_monitor_id,
            'source_id', c->>'source_id',
            'grant_id', c->>'grant_id'
        ) ORDER BY c->>'source_id', c->>'grant_id')
          FROM jsonb_array_elements(COALESCE(p_consent_refs, '[]'::jsonb)) c
         WHERE jsonb_typeof(c) = 'object'
           AND (c->>'source_id' IS NOT NULL OR c->>'grant_id' IS NOT NULL)
    ), '[]'::jsonb);

    IF jsonb_array_length(v_source_refs) = 0 THEN
        v_source_refs := jsonb_build_array(jsonb_build_object(
            'provenance_kind', 'local_document_revision',
            'document_id', v_id,
            'document_revision', v_revision,
            'document_payload_hash', v_hash,
            'owner_user_id', v_owner_text,
            'monitor_id', p_monitor_id
        ));
    END IF;

    RETURN QUERY SELECT public.mb13_p0_normalize_jsonb_array(v_source_refs), '[]'::jsonb;
    RETURN;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- 7. Strict relational provenance resolver: explicit provenance_kind,
--    complete required fields, exact relational chain, no empty/partial refs.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_resolve_exact_provenance(
    p_owner UUID,
    p_source_refs JSONB,
    p_evidence_refs JSONB
) RETURNS TABLE(
    source_id UUID,
    source_card_id TEXT,
    source_revision_id UUID,
    evidence_id UUID,
    grant_id UUID,
    source_status TEXT,
    evidence_status TEXT,
    grant_status TEXT,
    binding_status TEXT,
    inventory_state TEXT,
    content_hash TEXT
) AS $$
DECLARE
    v_input INTEGER;
    v_distinct INTEGER;
    v_ref JSONB;
    v_kind TEXT;
    v_source_card_count INTEGER;
    v_local_count INTEGER;
    v_resolved INTEGER;
BEGIN
    v_input := COALESCE(jsonb_array_length(COALESCE(p_source_refs, '[]'::jsonb)), 0)
             + COALESCE(jsonb_array_length(COALESCE(p_evidence_refs, '[]'::jsonb)), 0);
    IF v_input = 0 THEN
        RETURN;
    END IF;

    FOR v_ref IN
        SELECT value FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb))
        UNION ALL
        SELECT value FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb))
    LOOP
        IF jsonb_typeof(v_ref) <> 'object' OR v_ref = '{}'::jsonb THEN
            RAISE EXCEPTION 'mb13_p1_provenance_ref_empty';
        END IF;
        v_kind := v_ref->>'provenance_kind';
        IF v_kind IS NULL OR length(trim(v_kind)) = 0 THEN
            RAISE EXCEPTION 'mb13_p1_provenance_kind_missing';
        END IF;
        IF v_kind NOT IN ('source_card', 'local_document_revision') THEN
            RAISE EXCEPTION 'mb13_p1_provenance_kind_unsupported:%', v_kind;
        END IF;
        IF v_kind = 'source_card' THEN
            IF NULLIF(v_ref->>'source_id', '') IS NULL
               OR NULLIF(v_ref->>'source_card_id', '') IS NULL
               OR NULLIF(v_ref->>'source_revision_id', '') IS NULL
               OR NULLIF(v_ref->>'evidence_id', '') IS NULL
               OR NULLIF(v_ref->>'grant_id', '') IS NULL THEN
                RAISE EXCEPTION 'mb13_p1_provenance_source_card_incomplete';
            END IF;
        ELSIF v_kind = 'local_document_revision' THEN
            IF NULLIF(v_ref->>'document_id', '') IS NULL
               OR NULLIF(v_ref->>'document_revision', '') IS NULL
               OR NULLIF(v_ref->>'document_payload_hash', '') IS NULL
               OR NULLIF(v_ref->>'owner_user_id', '') IS NULL
               OR NULLIF(v_ref->>'monitor_id', '') IS NULL THEN
                RAISE EXCEPTION 'mb13_p1_provenance_local_document_incomplete';
            END IF;
        END IF;
    END LOOP;

    SELECT
        (SELECT COUNT(DISTINCT value) FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)))
      + (SELECT COUNT(DISTINCT value) FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)))
      INTO v_distinct;
    IF v_distinct <> v_input THEN
        RAISE EXCEPTION 'mb13_p1_provenance_duplicate_refs';
    END IF;

    -- ------------------------------------------------------------------------
    -- source_card provenance
    -- ------------------------------------------------------------------------
    SELECT
        (SELECT COUNT(*) FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) WHERE value->>'provenance_kind' = 'source_card')
      + (SELECT COUNT(*) FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) WHERE value->>'provenance_kind' = 'source_card')
      INTO v_source_card_count;

    IF v_source_card_count > 0 THEN
        PERFORM s.id
          FROM public.authorized_memory_sources s
         WHERE s.user_id = p_owner
           AND s.id IN (
               SELECT NULLIF(el.value->>'source_id', '')::UUID
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'source_card'
           )
         ORDER BY s.id
         FOR UPDATE OF s;

        PERFORM g.id
          FROM public.authorized_memory_consent_grants g
         WHERE g.user_id = p_owner
           AND g.id IN (
               SELECT NULLIF(el.value->>'grant_id', '')::UUID
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'source_card'
           )
         ORDER BY g.id
         FOR UPDATE OF g;

        PERFORM i.id
          FROM public.authorized_memory_inventory_items i
         WHERE i.user_id = p_owner
           AND i.id IN (
               SELECT NULLIF(el.value->>'source_revision_id', '')::UUID
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'source_card'
           )
         ORDER BY i.id
         FOR UPDATE OF i;

        PERFORM e.id
          FROM public.authorized_memory_activity_log e
         WHERE e.user_id = p_owner
           AND e.id IN (
               SELECT NULLIF(el.value->>'evidence_id', '')::UUID
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'source_card'
           )
         ORDER BY e.id
         FOR UPDATE OF e;

        PERFORM b.source_card_id
          FROM public.mb12_p0_source_card_binding b
         WHERE b.owner_user_id = p_owner
           AND b.source_card_id IN (
               SELECT el.value->>'source_card_id'
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'source_card'
           )
         ORDER BY b.source_card_id
         FOR UPDATE OF b;

        SELECT COUNT(*) INTO v_resolved
          FROM (
            SELECT el.value
              FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
             WHERE el.value->>'provenance_kind' = 'source_card'
          ) q
          JOIN public.authorized_memory_sources s
            ON s.id = NULLIF(q.value->>'source_id', '')::UUID
           AND s.user_id = p_owner
          JOIN public.authorized_memory_consent_grants g
            ON g.id = NULLIF(q.value->>'grant_id', '')::UUID
           AND g.user_id = p_owner
          JOIN public.authorized_memory_inventory_items i
            ON i.id = NULLIF(q.value->>'source_revision_id', '')::UUID
           AND i.user_id = p_owner
          JOIN public.authorized_memory_activity_log e
            ON e.id = NULLIF(q.value->>'evidence_id', '')::UUID
           AND e.user_id = p_owner
          JOIN public.mb12_p0_source_card_binding b
            ON b.source_card_id = q.value->>'source_card_id'
           AND b.owner_user_id = p_owner
         WHERE s.status = 'active' AND s.revoked_at IS NULL
           AND g.status = 'active' AND g.revoked_at IS NULL AND (g.expires_at IS NULL OR g.expires_at > NOW())
           AND i.deleted_at IS NULL AND i.identity_state <> 'revoked' AND i.memory_state <> 'revoked'
           AND (g.source_id IS NOT DISTINCT FROM s.id)
           AND (i.source_id = s.id)
           AND (i.grant_id IS NOT DISTINCT FROM g.id)
           AND (e.source_id = s.id)
           AND (e.grant_id IS NOT DISTINCT FROM g.id)
           AND b.status = 'active' AND b.revoked_at IS NULL
           AND (b.source_id = s.id)
           AND (b.source_revision_id = i.id)
           AND (b.evidence_id IS NOT DISTINCT FROM e.id)
           AND (b.grant_id IS NOT DISTINCT FROM g.id);

        IF v_resolved <> v_source_card_count THEN
            RAISE EXCEPTION 'mb13_p1_provenance_source_card_unresolved';
        END IF;
    END IF;

    -- ------------------------------------------------------------------------
    -- local_document_revision provenance
    -- ------------------------------------------------------------------------
    SELECT
        (SELECT COUNT(*) FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) WHERE value->>'provenance_kind' = 'local_document_revision')
      + (SELECT COUNT(*) FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) WHERE value->>'provenance_kind' = 'local_document_revision')
      INTO v_local_count;

    IF v_local_count > 0 THEN
        PERFORM dr.document_id, dr.revision
          FROM public.mb13_p1_document_revision dr
         WHERE dr.owner_user_id = p_owner
           AND (dr.document_id, dr.revision) IN (
               SELECT NULLIF(el.value->>'document_id', '')::UUID, NULLIF(el.value->>'document_revision', '')::INTEGER
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'local_document_revision'
           )
         ORDER BY dr.document_id, dr.revision
         FOR SHARE OF dr;

        PERFORM t.monitor_id
          FROM public.mb13_p0_monitor_target t
         WHERE t.owner_user_id = p_owner
           AND t.monitor_id IN (
               SELECT DISTINCT NULLIF(el.value->>'monitor_id', '')::UUID
                 FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
                WHERE el.value->>'provenance_kind' = 'local_document_revision'
                  AND el.value->>'monitor_id' IS NOT NULL
           )
         ORDER BY t.monitor_id
         FOR SHARE OF t;

        SELECT COUNT(*) INTO v_resolved
          FROM (
            SELECT el.value
              FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb) || COALESCE(p_evidence_refs, '[]'::jsonb)) el
             WHERE el.value->>'provenance_kind' = 'local_document_revision'
          ) q
          JOIN public.mb13_p1_document_revision dr
            ON dr.document_id = NULLIF(q.value->>'document_id', '')::UUID
           AND dr.owner_user_id = p_owner
           AND dr.revision = NULLIF(q.value->>'document_revision', '')::INTEGER
          JOIN public.mb13_p0_monitor_target t
            ON t.monitor_id = NULLIF(q.value->>'monitor_id', '')::UUID
           AND t.owner_user_id = p_owner
           AND t.monitor_state = 'active'
           AND t.target_ref->>'id' = q.value->>'document_id'
         WHERE dr.state = 'memorizzato'
           AND dr.payload_hash = q.value->>'document_payload_hash'
           AND (q.value->>'source_id' IS NULL OR EXISTS (
               SELECT 1 FROM public.authorized_memory_sources s
                WHERE s.id = NULLIF(q.value->>'source_id', '')::UUID
                  AND s.user_id = p_owner
                  AND s.status = 'active'
                  AND s.revoked_at IS NULL
           ))
           AND (q.value->>'grant_id' IS NULL OR EXISTS (
               SELECT 1 FROM public.authorized_memory_consent_grants g
                WHERE g.id = NULLIF(q.value->>'grant_id', '')::UUID
                  AND g.user_id = p_owner
                  AND g.status = 'active'
                  AND g.revoked_at IS NULL
                  AND (g.expires_at IS NULL OR g.expires_at > NOW())
           ));

        IF v_resolved <> v_local_count THEN
            RAISE EXCEPTION 'mb13_p1_provenance_local_document_unresolved';
        END IF;
    END IF;

    RETURN QUERY
    WITH all_refs AS (
        SELECT value FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb))
        UNION ALL
        SELECT value FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb))
    )
    SELECT
        s.id,
        b.source_card_id,
        i.id,
        e.id,
        g.id,
        s.status,
        'active'::text,
        g.status,
        b.status,
        i.identity_state,
        i.content_hash
    FROM all_refs el
    JOIN public.authorized_memory_sources s
      ON s.id = NULLIF(el.value->>'source_id', '')::UUID
     AND s.user_id = p_owner
    JOIN public.authorized_memory_consent_grants g
      ON g.id = NULLIF(el.value->>'grant_id', '')::UUID
     AND g.user_id = p_owner
    JOIN public.authorized_memory_inventory_items i
      ON i.id = NULLIF(el.value->>'source_revision_id', '')::UUID
     AND i.user_id = p_owner
    JOIN public.authorized_memory_activity_log e
      ON e.id = NULLIF(el.value->>'evidence_id', '')::UUID
     AND e.user_id = p_owner
    JOIN public.mb12_p0_source_card_binding b
      ON b.source_card_id = el.value->>'source_card_id'
     AND b.owner_user_id = p_owner
    WHERE el.value->>'provenance_kind' = 'source_card'
      AND s.status = 'active' AND s.revoked_at IS NULL
      AND g.status = 'active' AND g.revoked_at IS NULL AND (g.expires_at IS NULL OR g.expires_at > NOW())
      AND i.deleted_at IS NULL AND i.identity_state <> 'revoked' AND i.memory_state <> 'revoked'
      AND (g.source_id IS NOT DISTINCT FROM s.id)
      AND (i.source_id = s.id)
      AND (i.grant_id IS NOT DISTINCT FROM g.id)
      AND (e.source_id = s.id)
      AND (e.grant_id IS NOT DISTINCT FROM g.id)
      AND b.status = 'active' AND b.revoked_at IS NULL
      AND (b.source_id = s.id)
      AND (b.source_revision_id = i.id)
      AND (b.evidence_id IS NOT DISTINCT FROM e.id)
      AND (b.grant_id IS NOT DISTINCT FROM g.id)
    UNION ALL
    SELECT
        NULL::UUID,
        NULL::TEXT,
        NULL::UUID,
        NULL::UUID,
        NULL::UUID,
        NULL::TEXT,
        NULL::TEXT,
        NULL::TEXT,
        NULL::TEXT,
        dr.state,
        dr.payload_hash
    FROM all_refs el
    JOIN public.mb13_p1_document_revision dr
      ON dr.document_id = NULLIF(el.value->>'document_id', '')::UUID
     AND dr.owner_user_id = p_owner
     AND dr.revision = NULLIF(el.value->>'document_revision', '')::INTEGER
    JOIN public.mb13_p0_monitor_target t
      ON t.monitor_id = NULLIF(el.value->>'monitor_id', '')::UUID
     AND t.owner_user_id = p_owner
     AND t.monitor_state = 'active'
     AND t.target_ref->>'id' = el.value->>'document_id'
    WHERE el.value->>'provenance_kind' = 'local_document_revision'
      AND dr.state = 'memorizzato'
      AND dr.payload_hash = el.value->>'document_payload_hash';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) TO mb13_p1_executor;

-- ----------------------------------------------------------------------------
-- 8. Preflight now uses the monitor-bound provenance lookup.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_preflight(
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT
) RETURNS UUID AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_baseline_source_refs JSONB;
    v_baseline_evidence_refs JSONB;
    v_observation_source_refs JSONB;
    v_observation_evidence_refs JSONB;
    v_baseline_rev INTEGER;
    v_observation_rev INTEGER;
    v_preflight_id UUID := gen_random_uuid();
    v_request_hash TEXT;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object'
       OR p_observation_ref->>'id' IS NULL
       OR p_observation_ref->>'revision' IS NULL
       OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
        RAISE EXCEPTION 'mb13_p1_target_owner_mismatch';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;

    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_monitor_id::text, 0));

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = v_owner
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_found';
    END IF;
    IF v_current.monitor_state <> 'active' THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;

    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, v_current.target_ref);
    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, p_observation_ref);

    IF (v_current.target_ref->>'id') IS DISTINCT FROM (p_observation_ref->>'id') THEN
        RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
    END IF;

    v_baseline_rev := (v_current.target_ref->>'revision')::INTEGER;
    v_observation_rev := (p_observation_ref->>'revision')::INTEGER;

    IF v_observation_rev < v_baseline_rev THEN
        RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
    END IF;

    IF v_observation_rev = v_baseline_rev THEN
        IF (v_current.target_ref->>'payload_hash') IS DISTINCT FROM (p_observation_ref->>'payload_hash')
           OR (v_current.target_ref->>'state') IS DISTINCT FROM (p_observation_ref->>'state') THEN
            RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
        END IF;
    END IF;

    PERFORM public.mb13_p0_lock_and_verify_consents(
        v_owner, v_current.consent_refs, v_current.target_type, v_current.target_ref,
        p_required => TRUE, p_strict_relation => FALSE
    );
    PERFORM public.mb13_p0_lock_and_verify_consents(
        v_owner, v_current.consent_refs, v_current.target_type, p_observation_ref,
        p_required => TRUE, p_strict_relation => FALSE
    );

    SELECT source_refs, evidence_refs INTO v_baseline_source_refs, v_baseline_evidence_refs
      FROM public.mb13_p0_get_target_provenance(v_owner, v_current.target_type, v_current.target_ref, p_monitor_id, v_current.consent_refs);
    SELECT source_refs, evidence_refs INTO v_observation_source_refs, v_observation_evidence_refs
      FROM public.mb13_p0_get_target_provenance(v_owner, v_current.target_type, p_observation_ref, p_monitor_id, v_current.consent_refs);

    PERFORM * FROM public.mb13_p1_resolve_exact_provenance(v_owner, v_baseline_source_refs, v_baseline_evidence_refs);
    PERFORM * FROM public.mb13_p1_resolve_exact_provenance(v_owner, v_observation_source_refs, v_observation_evidence_refs);

    IF jsonb_array_length(COALESCE(v_baseline_source_refs, '[]'::jsonb)) = 0
       AND jsonb_array_length(COALESCE(v_baseline_evidence_refs, '[]'::jsonb)) = 0 THEN
        RAISE EXCEPTION 'mb13_p1_baseline_provenance_empty';
    END IF;
    IF jsonb_array_length(COALESCE(v_observation_source_refs, '[]'::jsonb)) = 0
       AND jsonb_array_length(COALESCE(v_observation_evidence_refs, '[]'::jsonb)) = 0 THEN
        RAISE EXCEPTION 'mb13_p1_observation_provenance_empty';
    END IF;

    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'baseline_ref', v_current.target_ref,
        'observation_ref', p_observation_ref,
        'diff_kind', p_diff_kind,
        'baseline_source_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs), '[]'::jsonb),
        'baseline_evidence_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs), '[]'::jsonb),
        'observation_source_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_source_refs), '[]'::jsonb),
        'observation_evidence_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_evidence_refs), '[]'::jsonb),
        'consent_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_current.consent_refs), '[]'::jsonb)
    ));

    INSERT INTO public.mb13_p1_preflight_state (
        preflight_id, owner_user_id, monitor_id, observation_ref, diff_kind,
        baseline_source_refs, baseline_evidence_refs,
        observation_source_refs, observation_evidence_refs,
        consent_refs, monitor_revision, baseline_ref, request_hash
    ) VALUES (
        v_preflight_id, v_owner, p_monitor_id, p_observation_ref, p_diff_kind,
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_source_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_evidence_refs), '[]'::jsonb),
        public.mb13_p0_normalize_jsonb_array(v_current.consent_refs),
        v_current.current_revision,
        v_current.target_ref,
        v_request_hash
    );

    RETURN v_preflight_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) TO mb13_p1_writer;

-- ----------------------------------------------------------------------------
-- 9. P0 target validation for documents now uses the append-only revision
--     snapshot instead of the mutable documenti row.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p0_validate_target(
    p_owner UUID,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_for_active BOOLEAN
)
RETURNS void AS $$
DECLARE
    v_id TEXT;
    v_revision INTEGER;
    v_hash TEXT;
    v_state TEXT;
    v_doc RECORD;
    v_dossier RECORD;
    v_source RECORD;
    v_decision RECORD;
    v_rev_hash TEXT;
BEGIN
    IF jsonb_typeof(p_target_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p0_target_ref_invalid';
    END IF;
    IF p_target_ref->>'id' IS NULL OR p_target_ref->>'revision' IS NULL OR p_target_ref->>'payload_hash' IS NULL OR p_target_ref->>'owner_user_id' IS NULL OR p_target_ref->>'state' IS NULL THEN
        RAISE EXCEPTION 'mb13_p0_target_ref_missing';
    END IF;
    v_id := p_target_ref->>'id';
    BEGIN
        v_revision := (p_target_ref->>'revision')::INTEGER;
    EXCEPTION WHEN invalid_text_representation THEN
        RAISE EXCEPTION 'mb13_p0_target_ref_invalid';
    END;
    v_hash := p_target_ref->>'payload_hash';
    v_state := p_target_ref->>'state';

    IF p_target_ref->>'owner_user_id' IS DISTINCT FROM p_owner::text THEN
        RAISE EXCEPTION 'mb13_p0_target_owner_mismatch';
    END IF;

    IF p_target_type = 'generic_entity' THEN
        IF p_for_active THEN
            RAISE EXCEPTION 'mb13_p0_target_type_not_activatable';
        END IF;
        RETURN;
    END IF;

    IF p_target_type IN ('rule','identity','object') THEN
        IF p_for_active THEN
            RAISE EXCEPTION 'mb13_p0_target_type_not_activatable';
        END IF;
        RETURN;
    END IF;

    IF p_target_type = 'document' THEN
        -- Prefer the append-only revision snapshot.  If no snapshot exists yet,
        -- fall back to the original documenti row for P0 monitor creation.
        SELECT state, payload_hash INTO v_doc
          FROM public.mb13_p1_document_revision
         WHERE owner_user_id = p_owner
           AND document_id = v_id::UUID
           AND revision = v_revision
         FOR SHARE;
        IF NOT FOUND THEN
            SELECT stato_elaborazione AS state, hash_file AS payload_hash INTO v_doc
              FROM public.documenti
             WHERE id = v_id::UUID
               AND proprietario_id = p_owner
             FOR SHARE;
            IF NOT FOUND THEN
                RAISE EXCEPTION 'mb13_p0_target_not_found';
            END IF;
            -- In legacy mode only revision 1 can be validated from documenti.
            IF v_revision <> 1 THEN
                RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
            END IF;
            IF v_doc.payload_hash IS NULL OR length(trim(v_doc.payload_hash)) = 0 THEN
                RAISE EXCEPTION 'mb13_p0_target_authoritative_hash_missing';
            END IF;
            IF v_doc.payload_hash <> v_hash OR v_doc.state <> v_state THEN
                RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
            END IF;
            RETURN;
        END IF;
        IF v_doc.state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_target_revoked';
        END IF;
        IF v_doc.state <> 'memorizzato' THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_doc.payload_hash IS NULL OR length(trim(v_doc.payload_hash)) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_target_authoritative_hash_missing';
        END IF;
        IF v_doc.payload_hash <> v_hash OR v_state <> 'memorizzato' THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        RETURN;
    END IF;

    IF p_target_type IN ('dossier','contract','offer') THEN
        SELECT current_revision, payload_hash, state INTO v_dossier
          FROM public.mb12_p1_offer_contract
         WHERE owner_user_id = p_owner
           AND dossier_id = v_id::UUID
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_target_not_found';
        END IF;
        IF v_dossier.state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_target_revoked';
        END IF;
        IF v_dossier.state <> 'normalized' THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_dossier.current_revision <> v_revision
           OR v_dossier.payload_hash IS NULL OR length(trim(v_dossier.payload_hash)) = 0
           OR v_dossier.payload_hash <> v_hash
           OR v_state <> 'normalized' THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        SELECT payload_hash INTO v_rev_hash
          FROM public.mb12_p1_offer_contract_revision
         WHERE owner_user_id = p_owner
           AND dossier_id = v_id::UUID
           AND revision = v_revision
         FOR SHARE;
        IF NOT FOUND OR v_rev_hash <> v_hash THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        RETURN;
    END IF;

    IF p_target_type = 'source' THEN
        IF v_revision <> 1 THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        SELECT
            b.content_hash,
            b.status,
            b.revoked_at,
            b.source_id::text AS binding_source_id,
            a.status AS authority_status,
            a.source_state,
            a.revocation_state,
            s.status AS source_status,
            s.revoked_at AS source_revoked,
            i.memory_state,
            i.deleted_at,
            i.content_hash AS item_hash,
            l.id AS evidence_id
          INTO v_source
          FROM public.mb12_p0_source_card_binding b
          JOIN public.canonical_source_card_authority a
            ON a.owner_user_id = b.owner_user_id
           AND a.source_card_id = b.source_card_id
          JOIN public.authorized_memory_sources s
            ON s.id = b.source_id
           AND s.user_id = b.owner_user_id
          JOIN public.authorized_memory_inventory_items i
            ON i.id = b.source_revision_id
           AND i.user_id = b.owner_user_id
           AND i.source_id = b.source_id
          JOIN public.authorized_memory_activity_log l
            ON l.id = b.evidence_id
           AND l.user_id = b.owner_user_id
         WHERE b.owner_user_id = p_owner
           AND b.source_card_id = v_id
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_target_not_found';
        END IF;
        IF v_source.status <> 'active' OR v_source.revoked_at IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p0_target_revoked';
        END IF;
        IF v_source.authority_status <> 'active'
           OR v_source.source_state <> 'active'
           OR v_source.revocation_state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_source.source_status <> 'active' OR v_source.source_revoked IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_source.memory_state = 'revoked' OR v_source.deleted_at IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_source.content_hash IS NULL OR length(trim(v_source.content_hash)) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_target_authoritative_hash_missing';
        END IF;
        IF v_source.content_hash <> v_hash OR v_state <> 'active' THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        RETURN;
    END IF;

    IF p_target_type = 'decision' THEN
        SELECT current_revision, payload_hash, state INTO v_decision
          FROM public.mb12_p4_governed_explainable_ranking
         WHERE owner_user_id = p_owner
           AND ranking_id = v_id::UUID
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_target_not_found';
        END IF;
        IF v_decision.state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_target_revoked';
        END IF;
        IF v_decision.current_revision <> v_revision
           OR v_decision.payload_hash IS NULL OR length(trim(v_decision.payload_hash)) = 0
           OR v_decision.payload_hash <> v_hash
           OR v_state <> v_decision.state THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        RETURN;
    END IF;

    RAISE EXCEPTION 'mb13_p0_target_type_not_supported';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_validate_target(UUID, TEXT, JSONB, BOOLEAN) FROM PUBLIC;

-- ----------------------------------------------------------------------------
-- 9b. Consent verification with full target coverage.  Before resolving
--     provenance, ensure the provided consent list covers every source_id
--     declared by the target revision.  This catches observation refs that
--     introduce sources not authorized by the monitor.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN);
CREATE OR REPLACE FUNCTION public.mb13_p0_lock_and_verify_consents(
    p_owner UUID,
    p_consent_refs JSONB,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_required BOOLEAN,
    p_strict_relation BOOLEAN DEFAULT TRUE
)
RETURNS JSONB AS $$
DECLARE
    v_ref JSONB;
    v_source_id TEXT;
    v_grant_id TEXT;
    v_grant RECORD;
    v_normalized JSONB;
    v_count INTEGER := 0;
    v_provenance_source_refs JSONB;
    v_provenance_evidence_refs JSONB;
    v_required_pairs TEXT[];
    v_provided_pairs TEXT[];
    v_ps TEXT;
    v_document_id UUID;
    v_allowed_documents JSONB;
    v_target_source_id TEXT;
BEGIN
    IF p_consent_refs IS NULL OR jsonb_typeof(p_consent_refs) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p0_consent_refs_invalid';
    END IF;
    IF p_required AND jsonb_array_length(p_consent_refs) = 0 THEN
        RAISE EXCEPTION 'mb13_p0_consent_required';
    END IF;

    v_normalized := public.mb13_p0_normalize_jsonb_array(p_consent_refs);

    -- Gather the source:grant pairs the target revision claims it depends on.
    IF p_target_type IN ('dossier','contract','offer') THEN
        SELECT array_agg(DISTINCT (COALESCE(s->>'source_id','') || ':' || COALESCE(s->>'grant_id','')))
          INTO v_required_pairs
          FROM public.mb12_p1_offer_contract_revision r,
               jsonb_array_elements(r.source_refs) AS s
         WHERE r.owner_user_id = p_owner
           AND r.dossier_id = (p_target_ref->>'id')::UUID
           AND r.revision = (p_target_ref->>'revision')::INTEGER
           AND s->>'source_id' IS NOT NULL;
    ELSIF p_target_type = 'decision' THEN
        SELECT array_agg(DISTINCT (COALESCE(s->>'source_id','') || ':' || COALESCE(s->>'grant_id','')))
          INTO v_required_pairs
          FROM public.mb12_p4_governed_explainable_ranking_revision rev,
               jsonb_array_elements(rev.result_payload->'source_refs') AS s
         WHERE rev.owner_user_id = p_owner
           AND rev.ranking_id = (p_target_ref->>'id')::UUID
           AND rev.revision = (p_target_ref->>'revision')::INTEGER
           AND s->>'source_id' IS NOT NULL;
    ELSIF p_target_type = 'source' THEN
        SELECT source_id::text INTO v_target_source_id
          FROM public.mb12_p0_source_card_binding
         WHERE owner_user_id = p_owner
           AND source_card_id = p_target_ref->>'id';
    END IF;

    SELECT array_agg(DISTINCT (COALESCE(c->>'source_id','') || ':' || COALESCE(c->>'grant_id','')))
      INTO v_provided_pairs
      FROM jsonb_array_elements(v_normalized) AS c
     WHERE c->>'source_id' IS NOT NULL
       AND c->>'grant_id' IS NOT NULL;

    IF p_required AND p_target_type IN ('dossier','contract','offer','decision') THEN
        IF v_required_pairs IS NOT NULL THEN
            FOREACH v_ps IN ARRAY v_required_pairs LOOP
                IF v_provided_pairs IS NULL OR NOT (v_ps = ANY(v_provided_pairs)) THEN
                    RAISE EXCEPTION 'mb13_p0_consent_coverage_incomplete';
                END IF;
            END LOOP;
        END IF;
    END IF;

    IF p_required AND p_target_type = 'source' THEN
        IF v_target_source_id IS NULL THEN
            RAISE EXCEPTION 'mb13_p0_consent_source_not_related_to_target';
        END IF;
        IF NOT EXISTS (
            SELECT 1
              FROM jsonb_array_elements(v_normalized) AS c
             WHERE c->>'source_id' = v_target_source_id
        ) THEN
            RAISE EXCEPTION 'mb13_p0_consent_coverage_incomplete';
        END IF;
    END IF;

    SELECT source_refs, evidence_refs INTO v_provenance_source_refs, v_provenance_evidence_refs
      FROM public.mb13_p0_get_target_provenance(p_owner, p_target_type, p_target_ref);

    IF p_target_type IN ('dossier','contract','offer','source','decision') THEN
        SELECT array_agg(DISTINCT (((s->>'source_id') || ':' || COALESCE(s->>'grant_id',''))))
          INTO v_required_pairs
          FROM jsonb_array_elements(v_provenance_source_refs) AS s
         WHERE (s->>'source_id') IS NOT NULL
           AND jsonb_typeof(s) = 'object';
    END IF;

    FOR v_ref IN SELECT value FROM jsonb_array_elements(v_normalized) LOOP
        v_source_id := v_ref->>'source_id';
        v_grant_id := v_ref->>'grant_id';
        IF v_source_id IS NULL OR v_grant_id IS NULL THEN
            RAISE EXCEPTION 'mb13_p0_consent_ref_invalid';
        END IF;

        SELECT *
          INTO v_grant
          FROM public.authorized_memory_consent_grants
         WHERE user_id = p_owner
           AND source_id = v_source_id::UUID
           AND id = v_grant_id::UUID
           AND status = 'active'
           AND revoked_at IS NULL
           AND (expires_at IS NULL OR expires_at > NOW())
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_consent_revoked_or_invalid';
        END IF;

        IF v_grant.action NOT IN ('read_metadata','inventory_existence')
           OR v_grant.plane <> 'EXISTENCE' THEN
            RAISE EXCEPTION 'mb13_p0_consent_action_incompatible';
        END IF;

        IF p_target_type IN ('dossier','contract','offer','decision') AND p_strict_relation THEN
            v_ps := v_source_id || ':' || v_grant_id;
            IF v_required_pairs IS NULL OR NOT (v_ps = ANY(v_required_pairs)) THEN
                RAISE EXCEPTION 'mb13_p0_provenance_not_related_to_target';
            END IF;
        END IF;

        IF p_target_type = 'source' THEN
            IF NOT EXISTS (
                SELECT 1 FROM public.mb12_p0_source_card_binding b
                 WHERE b.owner_user_id = p_owner
                   AND b.source_card_id = (p_target_ref->>'id')
                   AND b.source_id = v_source_id::UUID
                   AND b.grant_id = v_grant_id::UUID
            ) THEN
                RAISE EXCEPTION 'mb13_p0_provenance_not_related_to_target';
            END IF;
        END IF;

        IF p_target_type = 'document' THEN
            v_document_id := (p_target_ref->>'id')::UUID;
            v_allowed_documents := NULLIF(v_grant.constraints->'data_scope'->'allowed_documents', 'null'::jsonb);
            IF v_allowed_documents IS NULL
               OR jsonb_typeof(v_allowed_documents) <> 'array'
               OR NOT EXISTS (
                    SELECT 1 FROM jsonb_array_elements_text(v_allowed_documents) AS ad
                     WHERE ad = v_document_id::text
                  )
            THEN
                RAISE EXCEPTION 'mb13_p0_document_capability_not_bound';
            END IF;
        END IF;

        v_count := v_count + 1;
    END LOOP;

    IF p_required AND v_count = 0 THEN
        RAISE EXCEPTION 'mb13_p0_consent_required';
    END IF;

    RETURN v_normalized;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN, BOOLEAN) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN, BOOLEAN) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN, BOOLEAN) TO mb13_p1_writer;

-- ----------------------------------------------------------------------------
-- 10. Re-grant provenance lookup so that both the private writer and the
--    executor can continue to invoke it.
-- ----------------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB) TO mb13_p1_executor;

REVOKE ALL ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB, UUID, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB, UUID, JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB, UUID, JSONB) TO mb13_p1_executor;

-- The executor (SECURITY DEFINER owner of mb13_p1_get_authorized_document_payload)
-- needs to read the preflight state and queue rows while resolving a payload.
GRANT SELECT ON public.mb13_p1_preflight_state TO mb13_p1_executor;
GRANT SELECT ON public.mb13_p1_diff_job_queue TO mb13_p1_executor;

COMMIT;
