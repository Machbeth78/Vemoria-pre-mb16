-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V4.5.1 — Migration V25
-- Estende tipi_documento con sottocategoria, parole_chiave, has_scadenza
-- Idempotente

ALTER TABLE tipi_documento
    ADD COLUMN IF NOT EXISTS sottocategoria  TEXT,
    ADD COLUMN IF NOT EXISTS parole_chiave   TEXT[],
    ADD COLUMN IF NOT EXISTS has_scadenza    BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS macro_categoria TEXT;

CREATE INDEX IF NOT EXISTS idx_tipo_doc_macro ON tipi_documento(macro_categoria);
CREATE INDEX IF NOT EXISTS idx_tipo_doc_cat   ON tipi_documento(categoria);

-- ============================================================
-- FALLBACK VIEW: macro_categoria per documenti non riconosciuti
-- Se codice non trovato in tipi_documento, assegna macro dal testo
-- ============================================================
CREATE OR REPLACE VIEW v_fallback_macro AS
SELECT
    codice,
    etichetta,
    macro_categoria,
    sottocategoria,
    parole_chiave,
    has_scadenza
FROM tipi_documento
WHERE attivo = TRUE;

-- Index per ricerca rapida per parole_chiave (GIN su array)
CREATE INDEX IF NOT EXISTS idx_tipo_doc_keywords ON tipi_documento USING gin(parole_chiave);

-- Funzione helper: dato un testo OCR, trova macro_categoria probabile

-- ============================================================
-- FALLBACK: guess_macro_categoria
-- Dato testo OCR, restituisce macro_categoria piu probabile.
-- Fallback finale garantito: 'generico'
-- ============================================================
CREATE OR REPLACE FUNCTION guess_macro_categoria(testo_ocr TEXT)
RETURNS TEXT AS $$
DECLARE
    result      TEXT;
    testo_lower TEXT;
BEGIN
    IF testo_ocr IS NULL OR length(trim(testo_ocr)) < 3 THEN
        RETURN 'generico';
    END IF;

    testo_lower := lower(testo_ocr);

    -- 1. Cerca corrispondenza parole_chiave tramite GIN index
    SELECT macro_categoria INTO result
    FROM tipi_documento
    WHERE attivo = TRUE
      AND parole_chiave IS NOT NULL
      AND parole_chiave && string_to_array(
            regexp_replace(testo_lower, '[^a-z0-9 ]', ' ', 'g'), ' ')
    ORDER BY array_length(
        ARRAY(
            SELECT unnest(parole_chiave)
            INTERSECT
            SELECT unnest(string_to_array(
                regexp_replace(testo_lower, '[^a-z0-9 ]', ' ', 'g'), ' '))
        ), 1
    ) DESC NULLS LAST
    LIMIT 1;

    IF result IS NOT NULL THEN
        RETURN result;
    END IF;

    -- 2. Fallback per pattern comuni italiani nel testo OCR
    -- Ordine: più specifico prima
    RETURN CASE
        WHEN testo_lower ~ '(cantiere|psc |pos |dvr|duvri|rspp|durc|collaudo statico|computo metrico|capitolato|vvf |cpi |superbonus|ecobonus|sismabonus|scia edilizia|cila|permesso di costruire|agibilita)' THEN 'cantiere_edilizia'
        WHEN testo_lower ~ '(universita degli studi|universita di|universita statale|corso di laurea|laurea magistrale|laurea triennale|diploma di laurea|facolta|ateneo|ecdl|icdl|patente europea computer|pagella scolastica|iscrizione scolastica|crediti formativi|attestato di frequenza)' THEN 'scuola'
        WHEN testo_lower ~ '(visura camerale|registro delle imprese|registro imprese|partita iva|s\.r\.l\.|s\.p\.a\.|statuto|rea |attivita commerciale|bilancio|sede legale)' THEN 'impresa'
        WHEN testo_lower ~ '(decreto ingiuntivo|atto notarile|sentenza|tribunale|avvocato|ricorso|diffida|pignoramento|successione|lodo arbitrale|mediazione|citazione)' THEN 'legale'
        WHEN testo_lower ~ '(busta paga|cedolino|contratto di lavoro|ccnl|assunzione|licenziamento|dimissioni|inps|tfr|liquidazione)' THEN 'lavoro'
        WHEN testo_lower ~ '(irpef|f24|dichiarazione dei redditi|agenzia delle entrate|730 |modello unico|imu |tari |cartella esattoriale|avviso di accertamento)' THEN 'fisco'
        WHEN testo_lower ~ '(fattura|bonifico|conto corrente|mutuo|prestito|leasing|estratto conto|tasso|spread bancario|taeg|tan)' THEN 'banca'
        WHEN testo_lower ~ '(carta d identita|passaporto|patente di guida|codice fiscale|tessera sanitaria|stato di famiglia|atto di nascita|matrimonio|residenza)' THEN 'identita'
        WHEN testo_lower ~ '(referto|diagnosi|ricetta medica|ospedale|asl |paziente|terapia|farmac|analisi cliniche|ecografia|risonanza|biopsia)' THEN 'salute'
        WHEN testo_lower ~ '(contratto di affitto|contratto di locazione|rogito|catasto|visura catastale|condominio|agibilita|planimetria)' THEN 'casa'
        WHEN testo_lower ~ '(polizza|sinistro|premio assicurativo|constatazione amichevole|attestato di rischio|bonus malus|denuncia sinistro)' THEN 'assicurazioni'
        WHEN testo_lower ~ '(libretto di circolazione|immatricolazione|revisione auto|bollo auto|moto|veicolo|targa|perizia auto|stima veicolo|collaudo motorizzazione)' THEN 'veicoli'
        WHEN testo_lower ~ '(bolletta|energia elettrica|gas naturale|acqua potabile|fibra ottica|internet|kwh|consumo energetico)' THEN 'utenze'
        ELSE 'generico'
    END;
END;
$$ LANGUAGE plpgsql STABLE;
