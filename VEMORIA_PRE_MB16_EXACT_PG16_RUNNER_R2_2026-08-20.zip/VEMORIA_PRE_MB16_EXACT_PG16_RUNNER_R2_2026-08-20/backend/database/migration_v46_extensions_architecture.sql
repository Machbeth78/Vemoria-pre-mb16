-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V46 — Extensions Architecture V1
-- Registro tecnico dei moduli data-driven caricabili.
-- CORREZIONE 2026-04-03: gen_random_uuid() → uuid_generate_v4() (uniformità uuid-ossp).

CREATE TABLE IF NOT EXISTS extension_modules (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    module_id           TEXT NOT NULL UNIQUE,
    module_type         TEXT NOT NULL,
    name                TEXT NOT NULL,
    version             TEXT NOT NULL,
    status              TEXT NOT NULL,
    locale              TEXT,
    domain              TEXT,
    checksum            TEXT,
    dependencies        JSONB NOT NULL DEFAULT '[]'::jsonb,
    validation_result   JSONB,
    entry_file          TEXT,
    source              TEXT NOT NULL DEFAULT 'filesystem',
    active_from         TIMESTAMP NULL,
    disabled_at         TIMESTAMP NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_extension_modules_type_status
    ON extension_modules (module_type, status);

CREATE INDEX IF NOT EXISTS idx_extension_modules_locale
    ON extension_modules (locale);
