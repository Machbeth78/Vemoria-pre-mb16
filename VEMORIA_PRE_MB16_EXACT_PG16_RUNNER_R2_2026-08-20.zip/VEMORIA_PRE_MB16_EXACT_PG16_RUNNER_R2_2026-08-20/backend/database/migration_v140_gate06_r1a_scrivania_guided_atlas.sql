-- Vemoria Gate06 R1A - Scrivania guided by Self-Knowledge Atlas
-- Static schema contract only. Runtime PostgreSQL execution not performed here.
-- The tables store redacted guide/session metadata only.
-- They must not contain raw user text, document content, secrets, keys, audio, photos or adaptive profile values.

CREATE TABLE IF NOT EXISTS gate06_scrivania_guided_sessions (
    id TEXT PRIMARY KEY,
    owner_id TEXT NOT NULL,
    atlas_version TEXT NOT NULL,
    guide_version TEXT NOT NULL,
    primary_vc_id TEXT NOT NULL,
    candidate_vc_ids_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    satellite_families_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    permissions_to_explain_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    requires_explicit_confirmation BOOLEAN NOT NULL DEFAULT FALSE,
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE CHECK (runtime_pass_claimed = FALSE),
    stores_raw_user_text BOOLEAN NOT NULL DEFAULT FALSE CHECK (stores_raw_user_text = FALSE),
    contains_secret BOOLEAN NOT NULL DEFAULT FALSE CHECK (contains_secret = FALSE),
    status TEXT NOT NULL DEFAULT 'GUIDE_ONLY_NO_EXECUTION',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_gate06_scrivania_guided_owner_created
    ON gate06_scrivania_guided_sessions(owner_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_gate06_scrivania_guided_primary_vc
    ON gate06_scrivania_guided_sessions(primary_vc_id, status);

CREATE TABLE IF NOT EXISTS gate06_scrivania_guided_safety_events (
    id TEXT PRIMARY KEY,
    owner_id TEXT NOT NULL,
    event_kind TEXT NOT NULL,
    vc_id TEXT,
    reason TEXT NOT NULL,
    raw_user_text_stored BOOLEAN NOT NULL DEFAULT FALSE CHECK (raw_user_text_stored = FALSE),
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE CHECK (runtime_pass_claimed = FALSE),
    contains_secret BOOLEAN NOT NULL DEFAULT FALSE CHECK (contains_secret = FALSE),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_gate06_scrivania_guided_safety_owner_created
    ON gate06_scrivania_guided_safety_events(owner_id, created_at DESC);
