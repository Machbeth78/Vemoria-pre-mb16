-- ----------------------------------------------------------------------------
-- Vemoria MB13-P3 v218: legacy idempotency restoration, payload/revision integrity,
-- owner-scoped policy helper closure.
-- ----------------------------------------------------------------------------


-- 1. Add legacy idempotency flag to pack and revision
ALTER TABLE public.mb13_p3_action_pack
    ADD COLUMN IF NOT EXISTS legacy_idempotency_unverified BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE public.mb13_p3_action_pack_revision
    ADD COLUMN IF NOT EXISTS legacy_idempotency_unverified BOOLEAN NOT NULL DEFAULT FALSE;

-- 2. Drop NOT NULL so legacy rows can be restored to the original NULL idempotency_key.
ALTER TABLE public.mb13_p3_action_pack
    ALTER COLUMN idempotency_key DROP NOT NULL;
ALTER TABLE public.mb13_p3_action_pack
    DROP CONSTRAINT IF EXISTS ck_mb13_p3_pack_idempotency_key;

ALTER TABLE public.mb13_p3_action_pack_revision
    ALTER COLUMN idempotency_key DROP NOT NULL;
ALTER TABLE public.mb13_p3_action_pack_revision
    DROP CONSTRAINT IF EXISTS ck_mb13_p3_pack_revision_idempotency_key;

-- 3. Revert v217 synthetic idempotency keys on rows that originally had NULL.
--    This restores the original payload_hash semantics and marks them as legacy.
--    No payload_hash is modified.
UPDATE public.mb13_p3_action_pack
   SET legacy_idempotency_unverified = TRUE,
       idempotency_key = NULL
 WHERE idempotency_key LIKE 'legacy-pack-%';

ALTER TABLE public.mb13_p3_action_pack_revision DISABLE TRIGGER trg_mb13_p3_revision_immutable;
UPDATE public.mb13_p3_action_pack_revision
   SET legacy_idempotency_unverified = TRUE,
       idempotency_key = NULL
 WHERE idempotency_key LIKE 'legacy-rev-%';
ALTER TABLE public.mb13_p3_action_pack_revision ENABLE TRIGGER trg_mb13_p3_revision_immutable;

-- 4. Allow NULL idempotency_key only for legacy rows; non-legacy keys must be non-empty.
ALTER TABLE public.mb13_p3_action_pack
    ADD CONSTRAINT ck_mb13_p3_pack_idempotency_key
        CHECK (legacy_idempotency_unverified = TRUE OR (idempotency_key IS NOT NULL AND length(trim(idempotency_key)) > 0));

ALTER TABLE public.mb13_p3_action_pack_revision
    ADD CONSTRAINT ck_mb13_p3_pack_revision_idempotency_key
        CHECK (legacy_idempotency_unverified = TRUE OR (idempotency_key IS NOT NULL AND length(trim(idempotency_key)) > 0));

-- 5. Integrity validator: legacy denial, payload_hash check, current revision coherence.
CREATE OR REPLACE FUNCTION public.mb13_p3_validate_action_pack_integrity(
    p_pack public.mb13_p3_action_pack
) RETURNS VOID AS $$
DECLARE
    v_computed_hash TEXT;
    v_revision public.mb13_p3_action_pack_revision%ROWTYPE;
BEGIN
    IF p_pack.legacy_idempotency_unverified THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_legacy_unverified';
    END IF;

    SELECT * INTO v_revision
      FROM public.mb13_p3_action_pack_revision
     WHERE pack_id = p_pack.pack_id
       AND revision = p_pack.pack_revision;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_revision_not_found';
    END IF;

    IF v_revision.idempotency_key IS DISTINCT FROM p_pack.idempotency_key
       OR v_revision.legacy_idempotency_unverified IS DISTINCT FROM p_pack.legacy_idempotency_unverified THEN
        RAISE EXCEPTION 'mb13_p3_revision_idempotency_mismatch';
    END IF;

    IF v_revision.payload_hash IS DISTINCT FROM p_pack.payload_hash THEN
        RAISE EXCEPTION 'mb13_p3_pack_revision_payload_hash_mismatch';
    END IF;

    v_computed_hash := public.mb13_p3_action_pack_payload_hash(
        p_pack.owner_user_id, p_pack.monitor_id, v_revision.monitor_revision,
        v_revision.trigger_event_id, v_revision.diff_result_id, v_revision.action_type,
        v_revision.target_ref, v_revision.consent_refs, v_revision.provenance_refs, v_revision.steps,
        v_revision.expires_at, v_revision.idempotency_key, v_revision.status
    );
    IF v_computed_hash IS DISTINCT FROM v_revision.payload_hash THEN
        RAISE EXCEPTION 'mb13_p3_revision_payload_hash_mismatch';
    END IF;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p3_validate_action_pack_integrity(public.mb13_p3_action_pack) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_validate_action_pack_integrity(public.mb13_p3_action_pack) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_action_pack_integrity(public.mb13_p3_action_pack) TO mb13_p3_writer, mb13_p3_validator;


-- 5. Owner-scoped monitor policy hash helper without custom GUC authentication.
CREATE OR REPLACE FUNCTION public.mb13_p3_get_monitor_policy_hash(p_owner_user_id uuid, p_monitor_id uuid, p_monitor_revision integer)
 RETURNS text
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_policy JSONB;
BEGIN
    SELECT monitor_policy INTO v_policy
      FROM public.mb13_p0_monitor_target_revision
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = p_monitor_id
       AND revision = p_monitor_revision;
    IF FOUND THEN
        RETURN public.mb13_p0_hash_jsonb(v_policy);
    END IF;

    SELECT monitor_policy INTO v_policy
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = p_monitor_id
       AND current_revision = p_monitor_revision;
    IF FOUND THEN
        RETURN public.mb13_p0_hash_jsonb(v_policy);
    END IF;

    RETURN NULL;
END;
$function$;
ALTER FUNCTION public.mb13_p3_get_monitor_policy_hash(UUID, UUID, INTEGER) OWNER TO postgres;
REVOKE ALL ON FUNCTION public.mb13_p3_get_monitor_policy_hash(UUID, UUID, INTEGER) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p3_get_monitor_policy_hash(UUID, UUID, INTEGER) FROM mb13_p3_api;
REVOKE ALL ON FUNCTION public.mb13_p3_get_monitor_policy_hash(UUID, UUID, INTEGER) FROM mb13_p3_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_monitor_policy_hash(UUID, UUID, INTEGER) TO mb13_p3_writer, mb13_p3_validator;

-- 6. Policy-hash trigger no longer sets custom GUC before calling helper.
CREATE OR REPLACE FUNCTION public.mb13_p3_action_pack_monitor_policy_hash()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
    v_policy_hash TEXT;
BEGIN
    IF TG_OP = 'INSERT' OR NEW.monitor_revision IS DISTINCT FROM OLD.monitor_revision THEN
        v_policy_hash := public.mb13_p3_get_monitor_policy_hash(NEW.owner_user_id, NEW.monitor_id, NEW.monitor_revision);
        IF v_policy_hash IS NULL THEN
            NEW.monitor_policy_hash := public.mb13_p0_hash_jsonb(jsonb_build_object('provenance_unverified', NEW.monitor_revision));
            NEW.provenance_state := 'unverified';
        ELSE
            NEW.monitor_policy_hash := v_policy_hash;
            NEW.provenance_state := 'verified';
        END IF;
    END IF;
    RETURN NEW;
END;
$function$;

-- 7. Recreate create without custom GUC assumptions (new rows default legacy=false).
DROP FUNCTION IF EXISTS public.mb13_p3_create_action_pack(uuid, uuid, uuid, uuid, text, jsonb, jsonb, jsonb, jsonb, timestamp with time zone, text, text);
CREATE OR REPLACE FUNCTION public.mb13_p3_create_action_pack(p_owner_user_id uuid, p_monitor_id uuid, p_trigger_event_id uuid, p_diff_result_id uuid, p_action_type text, p_target_ref jsonb, p_consent_refs jsonb, p_provenance_refs jsonb, p_steps jsonb, p_expires_at timestamp with time zone, p_idempotency_key text, p_initial_status text DEFAULT 'proposed'::text)
 RETURNS TABLE(pack_id uuid, owner_user_id uuid, monitor_id uuid, monitor_revision integer, trigger_event_id uuid, diff_result_id uuid, pack_revision integer, payload_hash text, action_type text, target_ref jsonb, consent_refs jsonb, provenance_refs jsonb, steps jsonb, expires_at timestamp with time zone, idempotency_key text, status text, claimed_attempt_id uuid, created_at timestamp with time zone, updated_at timestamp with time zone, monitor_policy_hash text, provenance_state text, legacy_idempotency_unverified boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_existing public.mb13_p3_action_pack%ROWTYPE;
    v_pack_id UUID;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
    v_payload_hash TEXT;
    v_status TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_idempotency_key IS NULL OR length(trim(p_idempotency_key)) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_idempotency_key_required';
    END IF;

    -- Serialize concurrent creates with the same owner-scoped idempotency key.
    PERFORM pg_advisory_xact_lock(hashtextextended(p_owner_user_id::text || ':' || p_idempotency_key, 0));

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := COALESCE(public.mb13_p3_get_monitor_policy_hash(p_owner_user_id, p_monitor_id, v_monitor_revision), public.mb13_p0_hash_jsonb(v_monitor.monitor_policy));
    v_status := COALESCE(p_initial_status, 'proposed');

    IF v_status NOT IN ('draft','proposed','awaiting_confirmation') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_invalid_initial_status';
    END IF;

    IF p_action_type NOT IN ('simulate','internal') THEN
        RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
    END IF;

    PERFORM public.mb13_p3_validate_steps(p_owner_user_id, COALESCE(p_steps, '[]'::jsonb));

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, p_monitor_id, v_monitor_revision,
        p_trigger_event_id, p_diff_result_id
    );

    IF p_expires_at IS NOT NULL AND p_expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    SELECT * INTO v_existing
      FROM public.mb13_p3_action_pack
     WHERE owner_user_id = p_owner_user_id
       AND idempotency_key = p_idempotency_key;
    IF FOUND THEN
        v_payload_hash := public.mb13_p3_action_pack_payload_hash(
            p_owner_user_id, p_monitor_id, v_monitor_revision,
            p_trigger_event_id, p_diff_result_id, p_action_type,
            p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
            p_expires_at, p_idempotency_key, v_status
        );
        IF v_existing.payload_hash IS DISTINCT FROM v_payload_hash THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
        RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = v_existing.pack_id AND ap.owner_user_id = p_owner_user_id;
        RETURN;
    END IF;

    v_payload_hash := public.mb13_p3_action_pack_payload_hash(
        p_owner_user_id, p_monitor_id, v_monitor_revision,
        p_trigger_event_id, p_diff_result_id, p_action_type,
        p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
        p_expires_at, p_idempotency_key, v_status
    );

    INSERT INTO public.mb13_p3_action_pack (
        owner_user_id, monitor_id, monitor_revision, trigger_event_id, diff_result_id,
        pack_revision, payload_hash, action_type, target_ref, consent_refs, provenance_refs,
        steps, expires_at, idempotency_key, status, created_at, updated_at
    ) VALUES (
        p_owner_user_id, p_monitor_id, v_monitor_revision, p_trigger_event_id, p_diff_result_id,
        1, v_payload_hash, p_action_type, COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, p_idempotency_key, v_status, v_now, v_now
    ) RETURNING public.mb13_p3_action_pack.pack_id INTO v_pack_id;

    INSERT INTO public.mb13_p3_action_pack_revision (
        owner_user_id, pack_id, revision, monitor_revision, trigger_event_id, diff_result_id,
        payload_hash, action_type, target_ref, consent_refs, provenance_refs, steps,
        expires_at, idempotency_key, status, created_at
    ) VALUES (
        p_owner_user_id, v_pack_id, 1, v_monitor_revision, p_trigger_event_id, p_diff_result_id,
        v_payload_hash, p_action_type, COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, p_idempotency_key, v_status, v_now
    );

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_pack_id, p_monitor_id, 'pack_created', NULL, v_status,
        v_now, jsonb_build_object('pack_revision', 1),
        v_monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = v_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;

ALTER FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_create_action_pack(UUID, UUID, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT, TEXT) TO mb13_p3_api, mb13_p3_writer;

-- 8. Authorize: validate integrity and use owner-scoped policy helper.
CREATE OR REPLACE FUNCTION public.mb13_p3_authorize_action_pack(p_owner_user_id uuid, p_pack_id uuid, p_expires_at timestamp with time zone DEFAULT NULL::timestamp with time zone)
 RETURNS TABLE(pack_id uuid, owner_user_id uuid, status text, pack_revision integer, authorized_at timestamp with time zone, expires_at timestamp with time zone)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_auth_expires TIMESTAMPTZ;
    v_policy_hash TEXT;
    v_auth_hash TEXT;
    v_pack_payload_hash TEXT;
    v_target_ref_hash TEXT;
    v_consent_hash TEXT;
    v_provenance_hash TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.status NOT IN ('draft','proposed','awaiting_confirmation','authorized') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_cannot_authorize';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth_expires := COALESCE(p_expires_at, v_pack.expires_at, v_now + interval '1 hour');
    IF v_auth_expires <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_authorization_expired';
    END IF;

    v_policy_hash := COALESCE(public.mb13_p3_get_monitor_policy_hash(v_pack.owner_user_id, v_pack.monitor_id, v_pack.monitor_revision), public.mb13_p0_hash_jsonb(v_monitor.monitor_policy));
    v_pack_payload_hash := v_pack.payload_hash;
    v_target_ref_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb));
    v_consent_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb));
    v_provenance_hash := public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb));

    v_auth_hash := public.mb13_p3_action_pack_authorization_hash(
        p_pack_id, p_owner_user_id, v_pack.pack_revision, v_pack_payload_hash,
        v_monitor.current_revision, v_pack.action_type, v_target_ref_hash,
        v_consent_hash, v_provenance_hash, v_now, v_auth_expires
    );

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_pack.status, 'authorized',
            v_now, jsonb_build_object('pack_revision', v_pack.pack_revision, 'reason', 'authorize'),
            v_pack.monitor_revision, v_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    INSERT INTO public.mb13_p3_action_pack_authorization (
        owner_user_id, pack_id, pack_revision, authorized_at, expires_at,
        auth_payload_hash, pack_payload_hash, monitor_revision, action_type,
        target_ref_hash, consent_hash, provenance_hash, authorization_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.pack_revision, v_now, v_auth_expires,
        v_auth_hash, v_pack_payload_hash, v_monitor.current_revision, v_pack.action_type,
        v_target_ref_hash, v_consent_hash, v_provenance_hash, v_auth_hash
    );

    UPDATE public.mb13_p3_action_pack
       SET status = 'authorized',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorized', v_pack.status, 'authorized',
        v_now, jsonb_build_object('pack_revision', v_pack.pack_revision, 'expires_at', v_auth_expires),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.owner_user_id, ap.status, ap.pack_revision, v_now, v_auth_expires
                   FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;

-- 9. Claim: validate integrity and use owner-scoped policy helper.
CREATE OR REPLACE FUNCTION public.mb13_p3_claim_action_pack(p_owner_user_id uuid, p_pack_id uuid, p_expected_pack_revision integer, p_claim_nonce text, p_idempotency_key text)
 RETURNS TABLE(attempt_id uuid, pack_id uuid, attempt_number integer, claim_nonce text, status text, created_at timestamp with time zone)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_existing public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
    v_attempt_number INTEGER;
    v_attempt_id UUID;
    v_request_hash TEXT;
    v_executor_identity TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_idempotency_key IS NULL OR length(COALESCE(p_idempotency_key, '')) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_idempotency_key_required';
    END IF;
    IF p_claim_nonce IS NULL OR length(COALESCE(p_claim_nonce, '')) = 0 THEN
        RAISE EXCEPTION 'mb13_p3_claim_nonce_required';
    END IF;

    v_executor_identity := session_user;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_existing
      FROM public.mb13_p3_action_pack_attempt
     WHERE pack_id = p_pack_id
       AND idempotency_key = p_idempotency_key
     FOR UPDATE;
    IF FOUND THEN
        v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'pack_id', p_pack_id,
            'pack_revision', p_expected_pack_revision,
            'claim_nonce', p_claim_nonce,
            'idempotency_key', p_idempotency_key,
            'executor_identity', v_executor_identity
        ));
        IF v_existing.claim_request_hash IS DISTINCT FROM v_request_hash
           OR v_existing.claim_pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;

    IF v_existing.attempt_id IS NULL AND v_pack.status IS DISTINCT FROM 'authorized' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_authorized';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    IF v_existing.attempt_id IS NOT NULL THEN
        RETURN QUERY SELECT v_existing.attempt_id, v_existing.pack_id, v_existing.attempt_number,
                            v_existing.claim_nonce, v_existing.status, v_existing.created_at;
        RETURN;
    END IF;

    v_policy_hash := COALESCE(public.mb13_p3_get_monitor_policy_hash(v_pack.owner_user_id, v_pack.monitor_id, v_pack.monitor_revision), public.mb13_p0_hash_jsonb(v_monitor.monitor_policy));
    v_attempt_number := COALESCE((SELECT MAX(attempt_number) FROM public.mb13_p3_action_pack_attempt WHERE pack_id = p_pack_id), 0) + 1;
    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'pack_id', p_pack_id,
        'pack_revision', p_expected_pack_revision,
        'claim_nonce', p_claim_nonce,
        'idempotency_key', p_idempotency_key,
        'executor_identity', v_executor_identity
    ));

    INSERT INTO public.mb13_p3_action_pack_attempt (
        owner_user_id, pack_id, attempt_number, idempotency_key, claim_nonce,
        executor_identity, status, created_at, claim_request_hash, claim_pack_revision
    ) VALUES (
        p_owner_user_id, p_pack_id, v_attempt_number, p_idempotency_key, p_claim_nonce,
        v_executor_identity, 'claimed', v_now, v_request_hash, p_expected_pack_revision
    ) RETURNING public.mb13_p3_action_pack_attempt.attempt_id INTO v_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = 'claimed',
           claimed_attempt_id = v_attempt_id,
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'claimed', 'authorized', 'claimed',
        v_now, jsonb_build_object('attempt_id', v_attempt_id, 'attempt_number', v_attempt_number, 'claim_nonce', p_claim_nonce, 'executor_identity', v_executor_identity),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt_id, p_pack_id, v_attempt_number, p_claim_nonce, 'claimed'::TEXT, v_now;
END;
$function$;

-- 10. Start: validate integrity and use owner-scoped policy helper.
CREATE OR REPLACE FUNCTION public.mb13_p3_start_action_pack(p_owner_user_id uuid, p_pack_id uuid, p_attempt_id uuid, p_expected_pack_revision integer)
 RETURNS TABLE(attempt_id uuid, pack_id uuid, attempt_number integer, status text, started_at timestamp with time zone)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.executor_identity IS DISTINCT FROM session_user THEN
        RAISE EXCEPTION 'mb13_p3_executor_identity_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;

    IF v_pack.status NOT IN ('claimed','executing') OR v_attempt.status IS DISTINCT FROM 'claimed' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_claimed';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    PERFORM public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    v_policy_hash := COALESCE(public.mb13_p3_get_monitor_policy_hash(v_pack.owner_user_id, v_pack.monitor_id, v_pack.monitor_revision), public.mb13_p0_hash_jsonb(v_monitor.monitor_policy));

    UPDATE public.mb13_p3_action_pack_attempt
       SET status = 'executing',
           started_at = v_now
     WHERE attempt_id = p_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = 'executing',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'started', 'claimed', 'executing',
        v_now, jsonb_build_object('attempt_id', p_attempt_id, 'attempt_number', v_attempt.attempt_number),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number, 'executing'::TEXT, v_now;
END;
$function$;

-- 11. Record evidence: validate integrity before processing.
CREATE OR REPLACE FUNCTION public.mb13_p3_record_execution_evidence(p_owner_user_id uuid, p_pack_id uuid, p_attempt_id uuid, p_attempt_number integer, p_evidence_type text, p_evidence_payload jsonb, p_idempotency_key text)
 RETURNS TABLE(evidence_id uuid, receipt_id uuid, evidence_hash text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_executor_identity TEXT := session_user;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_canonical_payload JSONB;
    v_evidence_hash TEXT;
    v_request_hash TEXT;
    v_receipt_id UUID;
    v_new_id UUID;
    v_existing public.mb13_p3_action_pack_evidence%ROWTYPE;
    v_step_consents JSONB := '[]'::jsonb;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    IF p_idempotency_key IS NULL OR p_idempotency_key = '' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_idempotency_key_required';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.attempt_number IS DISTINCT FROM p_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;
    IF v_attempt.executor_identity IS DISTINCT FROM v_executor_identity THEN
        RAISE EXCEPTION 'mb13_p3_executor_identity_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.provenance_state IS DISTINCT FROM 'verified' THEN
        RAISE EXCEPTION 'mb13_p3_pack_provenance_unverified';
    END IF;

    v_canonical_payload := public.mb13_p3_canonicalize_evidence_payload(v_pack, p_evidence_type, p_evidence_payload);

    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'pack_id', p_pack_id,
        'pack_revision', v_pack.pack_revision,
        'attempt_id', p_attempt_id,
        'attempt_number', p_attempt_number,
        'monitor_revision', v_monitor.current_revision,
        'executor_identity', v_executor_identity,
        'evidence_type', p_evidence_type,
        'schema_version', v_canonical_payload->>'schema_version',
        'evidence_payload', v_canonical_payload
    ));

    SELECT * INTO v_existing
      FROM public.mb13_p3_action_pack_evidence
     WHERE owner_user_id = p_owner_user_id
       AND attempt_id = p_attempt_id
       AND idempotency_key = p_idempotency_key
     FOR UPDATE;
    IF FOUND THEN
        IF v_existing.pack_id IS DISTINCT FROM p_pack_id
           OR v_existing.evidence_type IS DISTINCT FROM p_evidence_type
           OR v_existing.attempt_number IS DISTINCT FROM p_attempt_number
           OR v_existing.executor_identity IS DISTINCT FROM v_executor_identity
           OR v_existing.evidence_payload IS DISTINCT FROM v_canonical_payload
           OR v_existing.evidence_state IS DISTINCT FROM 'active' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_idempotency_conflict';
        END IF;

        IF v_pack.status IS DISTINCT FROM 'executing' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
        END IF;
        IF v_attempt.status IS DISTINCT FROM 'executing' THEN
            RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
        END IF;
        IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
            RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
        END IF;
        IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
            RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
        END IF;

        PERFORM public.mb13_p3_validate_trigger_diff(
            p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
            v_pack.trigger_event_id, v_pack.diff_result_id
        );

        v_auth := public.mb13_p3_get_active_authorization(
            p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
            v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
            public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
            public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
            v_monitor.current_revision
        );

        v_step_consents := public.mb13_p3_get_covered_step_consents(v_pack, v_canonical_payload);

        PERFORM public.mb13_p3_validate_source_grant_chain(
            p_owner_user_id, v_monitor, v_pack.consent_refs, v_pack.provenance_refs, v_step_consents
        );

        RETURN QUERY SELECT v_existing.evidence_id, v_existing.receipt_id, v_existing.evidence_hash;
        RETURN;
    END IF;

    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;
    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;
    IF v_pack.monitor_revision IS DISTINCT FROM v_monitor.current_revision THEN
        RAISE EXCEPTION 'mb13_p3_monitor_revision_stale';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    v_step_consents := public.mb13_p3_get_covered_step_consents(v_pack, v_canonical_payload);

    PERFORM public.mb13_p3_validate_source_grant_chain(
        p_owner_user_id, v_monitor, v_pack.consent_refs, v_pack.provenance_refs, v_step_consents
    );

    v_evidence_hash := public.mb13_p0_hash_jsonb(v_canonical_payload);
    v_receipt_id := gen_random_uuid();

    INSERT INTO public.mb13_p3_action_pack_evidence (
        owner_user_id, pack_id, attempt_id, attempt_number, pack_revision, monitor_revision,
        executor_identity, evidence_type, evidence_hash, receipt_id, evidence_payload,
        evidence_schema_version, idempotency_key, evidence_request_hash, evidence_state, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, p_attempt_number, v_pack.pack_revision,
        v_monitor.current_revision, v_executor_identity, p_evidence_type, v_evidence_hash,
        v_receipt_id, v_canonical_payload, 'mb13-p3-evidence/v1', p_idempotency_key,
        v_request_hash, 'active', v_now
    )
    ON CONFLICT ON CONSTRAINT uq_mb13_p3_evidence_owner_attempt_idempotency DO NOTHING
    RETURNING public.mb13_p3_action_pack_evidence.evidence_id INTO v_new_id;

    IF v_new_id IS NULL THEN
        SELECT * INTO v_existing
          FROM public.mb13_p3_action_pack_evidence
         WHERE owner_user_id = p_owner_user_id
           AND attempt_id = p_attempt_id
           AND idempotency_key = p_idempotency_key
         FOR UPDATE;
        IF FOUND THEN
            IF v_existing.pack_id IS DISTINCT FROM p_pack_id
               OR v_existing.evidence_type IS DISTINCT FROM p_evidence_type
               OR v_existing.attempt_number IS DISTINCT FROM p_attempt_number
               OR v_existing.executor_identity IS DISTINCT FROM v_executor_identity
               OR v_existing.evidence_payload IS DISTINCT FROM v_canonical_payload
               OR v_existing.evidence_state IS DISTINCT FROM 'active' THEN
                RAISE EXCEPTION 'mb13_p3_evidence_idempotency_conflict';
            END IF;
            IF v_pack.status IS DISTINCT FROM 'executing' OR v_attempt.status IS DISTINCT FROM 'executing' THEN
                RAISE EXCEPTION 'mb13_p3_evidence_historical_replay: evidence_id=%, receipt_id=%', v_existing.evidence_id, v_existing.receipt_id;
            END IF;
            RETURN QUERY SELECT v_existing.evidence_id, v_existing.receipt_id, v_existing.evidence_hash;
            RETURN;
        END IF;
        RAISE EXCEPTION 'mb13_p3_evidence_insert_failed';
    END IF;

    RETURN QUERY SELECT v_new_id, v_receipt_id, v_evidence_hash;
END;
$function$;

-- 12. Complete: validate integrity and use pack-bound transition policy helper.
CREATE OR REPLACE FUNCTION public.mb13_p3_complete_action_pack(p_owner_user_id uuid, p_pack_id uuid, p_attempt_id uuid, p_expected_pack_revision integer, p_expected_attempt_number integer, p_outcome text, p_result_payload jsonb)
 RETURNS TABLE(attempt_id uuid, pack_id uuid, attempt_number integer, status text, result_hash text, completed_at timestamp with time zone)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_attempt public.mb13_p3_action_pack_attempt%ROWTYPE;
    v_existing_result public.mb13_p3_action_pack_result%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_transition_monitor_revision INTEGER;
    v_transition_policy_hash TEXT;
    v_pack_policy_hash TEXT;
    v_result_hash TEXT;
    v_event_kind TEXT;
    v_old_status TEXT;
    v_auth public.mb13_p3_action_pack_authorization%ROWTYPE;
    v_canonical_evidence JSONB;
    v_evidence_payload JSONB;
    v_evidence_status TEXT;
    v_covered_steps JSONB;
    v_result_payload JSONB;
    v_status_allowed BOOLEAN;
    v_pack_step_numbers INTEGER[];
    v_covered INTEGER[];
    v_missing INTEGER;
    v_n INTEGER;
    v_element TEXT;
    v_step_consents JSONB := '[]'::jsonb;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    IF p_outcome NOT IN ('completed','partial','failed') THEN
        RAISE EXCEPTION 'mb13_p3_invalid_outcome';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;

    SELECT * INTO v_attempt
      FROM public.mb13_p3_action_pack_attempt
     WHERE attempt_id = p_attempt_id
       AND pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_found';
    END IF;
    IF v_attempt.executor_identity IS DISTINCT FROM session_user THEN
        RAISE EXCEPTION 'mb13_p3_executor_identity_mismatch';
    END IF;

    IF v_pack.pack_revision IS DISTINCT FROM p_expected_pack_revision THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_stale_revision';
    END IF;
    IF v_attempt.attempt_number IS DISTINCT FROM p_expected_attempt_number THEN
        RAISE EXCEPTION 'mb13_p3_attempt_number_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);

    IF v_pack.provenance_state IS DISTINCT FROM 'verified' THEN
        RAISE EXCEPTION 'mb13_p3_pack_provenance_unverified';
    END IF;

    IF v_pack.expires_at IS NOT NULL AND v_pack.expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    PERFORM public.mb13_p3_validate_trigger_diff(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id
    );

    v_auth := public.mb13_p3_get_active_authorization(
        p_owner_user_id, p_pack_id, v_pack.payload_hash, v_pack.pack_revision,
        v_pack.action_type, public.mb13_p0_hash_jsonb(COALESCE(v_pack.target_ref, '{}'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.consent_refs, '[]'::jsonb)),
        public.mb13_p0_hash_jsonb(COALESCE(v_pack.provenance_refs, '[]'::jsonb)),
        v_monitor.current_revision
    );

    IF public.mb13_p3_action_pack_refs_revoked(v_monitor, v_pack.consent_refs, v_pack.provenance_refs) THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_refs_revoked';
    END IF;

    IF p_result_payload IS NULL THEN
        v_result_payload := '{}'::jsonb;
    ELSE
        v_result_payload := p_result_payload;
    END IF;
    IF jsonb_typeof(v_result_payload) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p3_result_payload_invalid';
    END IF;

    IF NOT (v_result_payload ? 'evidence') THEN
        RAISE EXCEPTION 'mb13_p3_result_evidence_required';
    END IF;

    IF v_result_payload ? 'outcome' THEN
        IF v_result_payload->>'outcome' IS DISTINCT FROM p_outcome THEN
            RAISE EXCEPTION 'mb13_p3_result_payload_outcome_mismatch';
        END IF;
    END IF;

    v_canonical_evidence := public.mb13_p3_canonicalize_result_evidence(p_owner_user_id, p_pack_id, p_attempt_id, v_result_payload);
    v_evidence_payload := v_canonical_evidence->'evidence_payload';
    v_evidence_status := v_evidence_payload->>'status';

    IF p_outcome = 'failed' THEN
        IF v_canonical_evidence->'evidence'->>'evidence_type' IS DISTINCT FROM 'failure_receipt' THEN
            RAISE EXCEPTION 'mb13_p3_result_failure_receipt_required';
        END IF;
    ELSE
        IF v_canonical_evidence->'evidence'->>'evidence_type' IS DISTINCT FROM 'failure_receipt' THEN
            v_status_allowed := false;
            IF p_outcome = 'completed' AND v_evidence_status IN ('ok','completed') THEN
                v_status_allowed := true;
            END IF;
            IF p_outcome = 'partial' AND v_evidence_status IN ('ok','completed','partial') THEN
                v_status_allowed := true;
            END IF;
            IF NOT v_status_allowed THEN
                RAISE EXCEPTION 'mb13_p3_evidence_status_incompatible_with_outcome';
            END IF;
        ELSE
            RAISE EXCEPTION 'mb13_p3_evidence_status_incompatible_with_outcome';
        END IF;
    END IF;

    v_covered_steps := v_evidence_payload->'covered_steps';
    IF v_covered_steps IS NULL OR jsonb_typeof(v_covered_steps) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p3_evidence_covered_steps_invalid';
    END IF;

    SELECT COALESCE(array_agg(NULLIF(s->>'step_number', '')::INTEGER ORDER BY NULLIF(s->>'step_number', '')::INTEGER), ARRAY[]::INTEGER[])
      INTO v_pack_step_numbers
      FROM jsonb_array_elements(COALESCE(v_pack.steps, '[]'::jsonb)) s;

    v_covered := ARRAY[]::INTEGER[];
    FOR v_element IN SELECT jsonb_array_elements_text(v_covered_steps) LOOP
        BEGIN
            v_n := NULLIF(v_element, '')::INTEGER;
        EXCEPTION WHEN OTHERS THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
        END;
        IF v_n IS NULL OR v_n <= 0 THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_step_invalid';
        END IF;
        IF v_n = ANY(COALESCE(v_covered, ARRAY[]::INTEGER[])) THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_step_duplicate';
        END IF;
        IF NOT (v_n = ANY(v_pack_step_numbers)) THEN
            RAISE EXCEPTION 'mb13_p3_evidence_covered_step_not_found';
        END IF;
        v_covered := array_append(v_covered, v_n);
    END LOOP;

    IF p_outcome = 'completed' THEN
        IF array_length(v_pack_step_numbers, 1) > 0 THEN
            IF array_length(v_covered, 1) IS NULL OR array_length(v_covered, 1) = 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_step_coverage_incomplete';
            END IF;
            FOREACH v_missing IN ARRAY v_pack_step_numbers LOOP
                IF NOT (v_missing = ANY(v_covered)) THEN
                    RAISE EXCEPTION 'mb13_p3_evidence_step_coverage_incomplete';
                END IF;
            END LOOP;
        ELSE
            IF array_length(v_covered, 1) > 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_step_coverage_incomplete';
            END IF;
        END IF;
    ELSIF p_outcome = 'partial' THEN
        IF array_length(v_pack_step_numbers, 1) > 0 THEN
            IF array_length(v_covered, 1) IS NULL OR array_length(v_covered, 1) = 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_partial_no_step_covered';
            END IF;
        ELSE
            IF array_length(v_covered, 1) > 0 THEN
                RAISE EXCEPTION 'mb13_p3_evidence_partial_no_step_covered';
            END IF;
        END IF;
    END IF;

    v_result_payload := v_result_payload - 'evidence_hash' - 'evidence' - 'outcome' - 'evidence_payload';
    v_result_payload := v_result_payload || jsonb_build_object(
        'outcome', p_outcome,
        'evidence', v_canonical_evidence->'evidence',
        'evidence_hash', v_canonical_evidence->'evidence_hash',
        'evidence_payload', v_canonical_evidence->'evidence_payload'
    );

    SELECT * INTO v_existing_result
      FROM public.mb13_p3_action_pack_result
     WHERE attempt_id = p_attempt_id
       AND owner_user_id = p_owner_user_id;
    IF FOUND THEN
        IF v_existing_result.outcome IS DISTINCT FROM p_outcome THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
        IF v_existing_result.result_payload IS DISTINCT FROM v_result_payload THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
        RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                            p_outcome::TEXT, v_existing_result.result_hash, v_existing_result.created_at;
        RETURN;
    END IF;

    v_step_consents := public.mb13_p3_get_covered_step_consents(v_pack, v_evidence_payload);
    PERFORM public.mb13_p3_validate_source_grant_chain(
        p_owner_user_id, v_monitor, v_pack.consent_refs, v_pack.provenance_refs, v_step_consents
    );

    IF v_pack.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_executing';
    END IF;
    IF v_attempt.status IS DISTINCT FROM 'executing' THEN
        RAISE EXCEPTION 'mb13_p3_attempt_not_executing';
    END IF;

    v_transition_monitor_revision := v_monitor.current_revision;
    v_transition_policy_hash := COALESCE(public.mb13_p3_get_monitor_policy_hash(v_pack.owner_user_id, v_pack.monitor_id, v_monitor.current_revision), public.mb13_p0_hash_jsonb(COALESCE(v_monitor.monitor_policy, '{}'::jsonb)));
    v_pack_policy_hash := v_pack.monitor_policy_hash;

    v_event_kind := p_outcome;
    v_old_status := v_pack.status;

    v_result_hash := public.mb13_p3_action_pack_result_hash(
        p_owner_user_id, p_pack_id, v_pack.pack_revision, p_attempt_id,
        v_attempt.attempt_number, p_outcome, v_attempt.executor_identity,
        v_result_payload, v_now
    );

    INSERT INTO public.mb13_p3_action_pack_result (
        owner_user_id, pack_id, attempt_id, attempt_number, outcome, executor_identity,
        result_payload, result_hash, created_at
    ) VALUES (
        p_owner_user_id, p_pack_id, p_attempt_id, v_attempt.attempt_number, p_outcome,
        v_attempt.executor_identity, v_result_payload, v_result_hash, v_now
    );

    UPDATE public.mb13_p3_action_pack_attempt
       SET result_payload = v_result_payload,
           result_hash = v_result_hash,
           completed_at = v_now
     WHERE attempt_id = p_attempt_id;

    UPDATE public.mb13_p3_action_pack
       SET status = p_outcome,
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, v_event_kind, v_old_status, p_outcome,
        v_now, jsonb_build_object(
            'attempt_id', p_attempt_id,
            'attempt_number', v_attempt.attempt_number,
            'result_hash', v_result_hash,
            'pack_monitor_revision', v_pack.monitor_revision,
            'pack_policy_hash', v_pack_policy_hash,
            'transition_monitor_revision', v_transition_monitor_revision,
            'transition_policy_hash', v_transition_policy_hash
        ),
        v_transition_monitor_revision, v_transition_policy_hash
    );

    RETURN QUERY SELECT v_attempt.attempt_id, p_pack_id, v_attempt.attempt_number,
                        p_outcome::TEXT, v_result_hash, v_now;
END;
$function$;

-- 13. Revise: governed legacy upgrade with explicit idempotency_key.
DROP FUNCTION IF EXISTS public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ);
CREATE OR REPLACE FUNCTION public.mb13_p3_revise_action_pack(p_owner_user_id uuid, p_pack_id uuid, p_action_type text, p_target_ref jsonb, p_consent_refs jsonb, p_provenance_refs jsonb, p_steps jsonb, p_expires_at timestamp with time zone, p_idempotency_key text DEFAULT NULL)
 RETURNS TABLE(pack_id uuid, owner_user_id uuid, monitor_id uuid, monitor_revision integer, monitor_policy_hash text, pack_revision integer, payload_hash text, action_type text, status text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_pack public.mb13_p3_action_pack%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_new_revision INTEGER;
    v_payload_hash TEXT;
    v_policy_hash TEXT;
    v_old_status TEXT;
    v_active_auth_count INTEGER := 0;
    v_revocation_event_id UUID;
    v_new_idempotency_key TEXT;
    v_new_legacy BOOLEAN;
    v_existing_pack public.mb13_p3_action_pack%ROWTYPE;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_pack
      FROM public.mb13_p3_action_pack
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_not_found';
    END IF;
    IF v_pack.owner_user_id IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = p_owner_user_id
       AND monitor_id = v_pack.monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p3_monitor_not_found';
    END IF;

    IF v_pack.legacy_idempotency_unverified THEN
        IF p_idempotency_key IS NULL OR length(trim(p_idempotency_key)) = 0 THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_key_required';
        END IF;
        PERFORM 1 FROM public.mb13_p3_action_pack
                  WHERE owner_user_id = p_owner_user_id
                    AND idempotency_key = p_idempotency_key
                    AND pack_id <> p_pack_id;
        IF FOUND THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_conflict';
        END IF;
        v_new_idempotency_key := p_idempotency_key;
        v_new_legacy := FALSE;
    ELSE
        IF p_idempotency_key IS NOT NULL AND length(trim(p_idempotency_key)) > 0
           AND p_idempotency_key IS DISTINCT FROM v_pack.idempotency_key THEN
            RAISE EXCEPTION 'mb13_p3_idempotency_key_immutable';
        END IF;
        PERFORM public.mb13_p3_validate_action_pack_integrity(v_pack);
        v_new_idempotency_key := v_pack.idempotency_key;
        v_new_legacy := v_pack.legacy_idempotency_unverified;
    END IF;

    IF v_pack.status IN ('claimed','executing','completed','partial','failed','cancelled','revoked','expired') THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_cannot_revise';
    END IF;

    IF p_expires_at IS NOT NULL AND p_expires_at <= v_now THEN
        RAISE EXCEPTION 'mb13_p3_action_pack_expired';
    END IF;

    IF p_action_type NOT IN ('simulate','internal') THEN
        RAISE EXCEPTION 'mb13_p3_action_type_forbidden';
    END IF;

    PERFORM public.mb13_p3_validate_steps(p_owner_user_id, COALESCE(p_steps, '[]'::jsonb));

    v_old_status := v_pack.status;
    v_new_revision := v_pack.pack_revision + 1;
    v_payload_hash := public.mb13_p3_action_pack_payload_hash(
        p_owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id, p_action_type,
        p_target_ref, p_consent_refs, p_provenance_refs, p_steps,
        p_expires_at, v_new_idempotency_key, 'proposed'
    );
    v_policy_hash := COALESCE(public.mb13_p3_get_monitor_policy_hash(v_pack.owner_user_id, v_pack.monitor_id, v_pack.monitor_revision), public.mb13_p0_hash_jsonb(v_monitor.monitor_policy));

    UPDATE public.mb13_p3_action_pack
       SET pack_revision = v_new_revision,
           payload_hash = v_payload_hash,
           action_type = p_action_type,
           target_ref = COALESCE(p_target_ref, '{}'::jsonb),
           consent_refs = COALESCE(p_consent_refs, '[]'::jsonb),
           provenance_refs = COALESCE(p_provenance_refs, '[]'::jsonb),
           steps = COALESCE(p_steps, '[]'::jsonb),
           expires_at = p_expires_at,
           idempotency_key = v_new_idempotency_key,
           legacy_idempotency_unverified = v_new_legacy,
           status = 'proposed',
           updated_at = v_now
     WHERE pack_id = p_pack_id;

    SELECT COUNT(*) INTO v_active_auth_count
      FROM public.mb13_p3_action_pack_authorization
     WHERE pack_id = p_pack_id
       AND owner_user_id = p_owner_user_id
       AND revoked = false;

    IF v_active_auth_count > 0 THEN
        INSERT INTO public.mb13_p3_action_pack_timeline (
            owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_pack_id, v_pack.monitor_id, 'authorization_revoked', v_old_status, 'proposed',
            v_now, jsonb_build_object('pack_revision', v_new_revision, 'reason', 'revise'),
            v_pack.monitor_revision, v_policy_hash
        ) RETURNING timeline_event_id INTO v_revocation_event_id;

        UPDATE public.mb13_p3_action_pack_authorization
           SET revoked = true,
               revoked_at = v_now,
               revocation_event_id = v_revocation_event_id
         WHERE pack_id = p_pack_id
           AND owner_user_id = p_owner_user_id
           AND revoked = false;
    END IF;

    INSERT INTO public.mb13_p3_action_pack_revision (
        owner_user_id, pack_id, revision, monitor_revision, trigger_event_id, diff_result_id,
        payload_hash, action_type, target_ref, consent_refs, provenance_refs, steps,
        expires_at, idempotency_key, status, created_at, legacy_idempotency_unverified
    ) VALUES (
        p_owner_user_id, p_pack_id, v_new_revision, v_pack.monitor_revision,
        v_pack.trigger_event_id, v_pack.diff_result_id, v_payload_hash, p_action_type,
        COALESCE(p_target_ref, '{}'::jsonb), COALESCE(p_consent_refs, '[]'::jsonb),
        COALESCE(p_provenance_refs, '[]'::jsonb), COALESCE(p_steps, '[]'::jsonb),
        p_expires_at, v_new_idempotency_key, 'proposed', v_now, v_new_legacy
    );

    INSERT INTO public.mb13_p3_action_pack_timeline (
        owner_user_id, pack_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_pack_id, v_pack.monitor_id, 'pack_revised', v_old_status, 'proposed',
        v_now, jsonb_build_object('pack_revision', v_new_revision),
        v_pack.monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT ap.pack_id, ap.owner_user_id, ap.monitor_id, ap.monitor_revision, ap.monitor_policy_hash,
                        ap.pack_revision, ap.payload_hash, ap.action_type, ap.status
                   FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;

ALTER FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_revise_action_pack(UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMPTZ, TEXT) TO mb13_p3_api, mb13_p3_writer;

-- 14. Recreate get/list helpers to include the new legacy flag.
DROP FUNCTION IF EXISTS public.mb13_p3_get_action_pack(UUID, UUID);
CREATE OR REPLACE FUNCTION public.mb13_p3_get_action_pack(p_owner_user_id uuid, p_pack_id uuid)
 RETURNS TABLE(pack_id uuid, owner_user_id uuid, monitor_id uuid, monitor_revision integer, trigger_event_id uuid, diff_result_id uuid, pack_revision integer, payload_hash text, action_type text, target_ref jsonb, consent_refs jsonb, provenance_refs jsonb, steps jsonb, expires_at timestamp with time zone, idempotency_key text, status text, claimed_attempt_id uuid, created_at timestamp with time zone, updated_at timestamp with time zone, monitor_policy_hash text, provenance_state text, legacy_idempotency_unverified boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    RETURN QUERY SELECT * FROM public.mb13_p3_action_pack ap WHERE ap.pack_id = p_pack_id AND ap.owner_user_id = p_owner_user_id;
END;
$function$;

ALTER FUNCTION public.mb13_p3_get_action_pack(UUID, UUID) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_get_action_pack(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_action_pack(UUID, UUID) TO mb13_p3_api, mb13_p3_writer;

DROP FUNCTION IF EXISTS public.mb13_p3_list_action_packs(UUID, TEXT, INTEGER, INTEGER);
CREATE OR REPLACE FUNCTION public.mb13_p3_list_action_packs(p_owner_user_id uuid, p_status text DEFAULT NULL::text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0)
 RETURNS TABLE(pack_id uuid, owner_user_id uuid, monitor_id uuid, monitor_revision integer, trigger_event_id uuid, diff_result_id uuid, pack_revision integer, payload_hash text, action_type text, target_ref jsonb, consent_refs jsonb, provenance_refs jsonb, steps jsonb, expires_at timestamp with time zone, idempotency_key text, status text, claimed_attempt_id uuid, created_at timestamp with time zone, updated_at timestamp with time zone, monitor_policy_hash text, provenance_state text, legacy_idempotency_unverified boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
#variable_conflict use_column
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p3_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p3_owner_mismatch';
    END IF;
    RETURN QUERY
        SELECT * FROM public.mb13_p3_action_pack ap
        WHERE ap.owner_user_id = p_owner_user_id
          AND (p_status IS NULL OR ap.status = p_status)
        ORDER BY ap.created_at DESC
        LIMIT p_limit OFFSET p_offset;
END;
$function$;

ALTER FUNCTION public.mb13_p3_list_action_packs(UUID, TEXT, INTEGER, INTEGER) OWNER TO mb13_p3_writer;
REVOKE ALL ON FUNCTION public.mb13_p3_list_action_packs(UUID, TEXT, INTEGER, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p3_list_action_packs(UUID, TEXT, INTEGER, INTEGER) TO mb13_p3_api, mb13_p3_writer;
