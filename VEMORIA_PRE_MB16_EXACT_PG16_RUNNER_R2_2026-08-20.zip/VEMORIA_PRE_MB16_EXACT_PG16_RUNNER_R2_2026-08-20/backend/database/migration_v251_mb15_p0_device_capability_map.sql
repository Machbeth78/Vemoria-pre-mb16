-- MB15-P0 — Device Capability Map snapshot table
-- Author: Devoti Massimo
-- Purpose: persist owner- and device-scoped capability snapshots locally.

CREATE TABLE IF NOT EXISTS mb15_p0_capability_snapshots (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID REFERENCES utenti(id) ON DELETE CASCADE,
    device_ref_hash TEXT NOT NULL DEFAULT '',
    snapshot_version TEXT NOT NULL DEFAULT 'mb15-p0-v1',
    snapshot_data JSONB NOT NULL DEFAULT '{}'::jsonb,
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    stale_after TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mb15_owner ON mb15_p0_capability_snapshots(owner_id);
CREATE INDEX IF NOT EXISTS idx_mb15_device ON mb15_p0_capability_snapshots(owner_id, device_ref_hash);
CREATE INDEX IF NOT EXISTS idx_mb15_generated ON mb15_p0_capability_snapshots(generated_at DESC);
