-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- PRE-MB16 Pass 8AO
-- Generic explicit owner-goal watch adapter. MB13-P0 remains the canonical
-- monitor/event ledger; this table stores only the recurring public-search
-- authorization/checkpoint bound to the exact owner query + criteria.
CREATE TABLE IF NOT EXISTS public.generic_interest_watch_authorizations (
    authorization_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NOT NULL REFERENCES public.utenti(id) ON DELETE CASCADE,
    watch_fingerprint TEXT NOT NULL,
    search_query TEXT NOT NULL,
    criteria_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    language TEXT NOT NULL DEFAULT 'it',
    status TEXT NOT NULL DEFAULT 'active',
    cadence_hours INTEGER NOT NULL DEFAULT 24,
    last_snapshot_hash TEXT NOT NULL DEFAULT '',
    seen_result_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
    last_result_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    last_checked_at TIMESTAMPTZ NULL,
    next_check_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_error TEXT NULL,
    explicit_owner_request BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revoked_at TIMESTAMPTZ NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_id, watch_fingerprint),
    CHECK (length(trim(search_query)) BETWEEN 3 AND 700),
    CHECK (length(watch_fingerprint) = 64),
    CHECK (status IN ('active','revoked')),
    CHECK (cadence_hours BETWEEN 6 AND 168),
    CHECK (jsonb_typeof(criteria_json) = 'object'),
    CHECK (jsonb_typeof(seen_result_ids) = 'array'),
    CHECK (jsonb_typeof(last_result_json) = 'object')
);

CREATE INDEX IF NOT EXISTS idx_generic_interest_watch_due
    ON public.generic_interest_watch_authorizations(status, next_check_at)
    WHERE status = 'active' AND revoked_at IS NULL AND explicit_owner_request = TRUE;

ALTER TABLE public.generic_interest_watch_authorizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.generic_interest_watch_authorizations FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS generic_interest_watch_authorizations_owner_policy
    ON public.generic_interest_watch_authorizations;
CREATE POLICY generic_interest_watch_authorizations_owner_policy
    ON public.generic_interest_watch_authorizations
    FOR ALL
    USING (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

COMMENT ON TABLE public.generic_interest_watch_authorizations IS
    'Explicit owner-scoped authorization/checkpoint for recurring bounded public Internet goal watches. Canonical lifecycle/events remain in MB13-P0.';

-- MB13 originally kept generic_entity draft-only and required authorized-memory
-- consent refs for every operational state. Pass 8AI introduced an explicitly
-- confirmed receipt-public-entity watch, so that original guard also made the
-- product adapter impossible to activate on a real DB. Preserve the old
-- authority for every existing target while adding a very narrow operational
-- exception for owner-scoped generic targets that have their own product
-- authorization rows. An active MB13 row alone grants no network execution;
-- schedulers must still join the owner authorization table.
DO $$
BEGIN
    IF to_regprocedure('public.mb13_p0_validate_target_pre296(uuid,text,jsonb,boolean)') IS NULL THEN
        ALTER FUNCTION public.mb13_p0_validate_target(UUID, TEXT, JSONB, BOOLEAN)
            RENAME TO mb13_p0_validate_target_pre296;
    END IF;
    IF to_regprocedure('public.mb13_p0_lock_and_verify_consents_pre296(uuid,jsonb,text,jsonb,boolean)') IS NULL THEN
        ALTER FUNCTION public.mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN)
            RENAME TO mb13_p0_lock_and_verify_consents_pre296;
    END IF;
END
$$;

CREATE OR REPLACE FUNCTION public.mb13_p0_validate_target(
    p_owner UUID,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_for_active BOOLEAN
)
RETURNS void AS $$
DECLARE
    v_source_type TEXT;
    v_revision INTEGER;
    v_hash TEXT;
BEGIN
    IF p_target_type = 'generic_entity' AND p_for_active THEN
        IF jsonb_typeof(p_target_ref) <> 'object' THEN
            RAISE EXCEPTION 'mb13_p0_target_ref_invalid';
        END IF;
        IF p_target_ref->>'id' IS NULL
           OR p_target_ref->>'revision' IS NULL
           OR p_target_ref->>'payload_hash' IS NULL
           OR p_target_ref->>'owner_user_id' IS NULL
           OR p_target_ref->>'state' IS NULL
           OR p_target_ref->>'source_type' IS NULL THEN
            RAISE EXCEPTION 'mb13_p0_target_ref_missing';
        END IF;
        IF p_target_ref->>'owner_user_id' IS DISTINCT FROM p_owner::text THEN
            RAISE EXCEPTION 'mb13_p0_target_owner_mismatch';
        END IF;
        BEGIN
            v_revision := (p_target_ref->>'revision')::INTEGER;
        EXCEPTION WHEN invalid_text_representation THEN
            RAISE EXCEPTION 'mb13_p0_target_ref_invalid';
        END;
        v_hash := lower(p_target_ref->>'payload_hash');
        v_source_type := p_target_ref->>'source_type';
        IF v_revision <> 1 OR p_target_ref->>'state' <> 'active' THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        IF v_hash !~ '^[0-9a-f]{64}$' THEN
            RAISE EXCEPTION 'mb13_p0_target_authoritative_hash_missing';
        END IF;
        IF v_source_type NOT IN ('receipt_public_entity', 'owner_goal_watch') THEN
            RAISE EXCEPTION 'mb13_p0_target_type_not_activatable';
        END IF;
        RETURN;
    END IF;

    PERFORM public.mb13_p0_validate_target_pre296(
        p_owner, p_target_type, p_target_ref, p_for_active
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_validate_target(UUID, TEXT, JSONB, BOOLEAN) FROM PUBLIC;

CREATE OR REPLACE FUNCTION public.mb13_p0_lock_and_verify_consents(
    p_owner UUID,
    p_consent_refs JSONB,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_required BOOLEAN
)
RETURNS JSONB AS $$
DECLARE
    v_source_type TEXT;
BEGIN
    IF p_target_type = 'generic_entity' THEN
        IF p_consent_refs IS NULL OR jsonb_typeof(p_consent_refs) <> 'array' THEN
            RAISE EXCEPTION 'mb13_p0_consent_refs_invalid';
        END IF;
        v_source_type := p_target_ref->>'source_type';
        IF v_source_type IN ('receipt_public_entity', 'owner_goal_watch') THEN
            -- These targets do not read an authorized-memory source. Their
            -- external execution authority lives in the owner-scoped product
            -- authorization row and is rechecked by the corresponding
            -- scheduler adapter. Smuggled memory-consent refs are rejected.
            IF jsonb_array_length(p_consent_refs) <> 0 THEN
                RAISE EXCEPTION 'mb13_p0_consent_ref_invalid';
            END IF;
            RETURN '[]'::jsonb;
        END IF;
    END IF;

    RETURN public.mb13_p0_lock_and_verify_consents_pre296(
        p_owner, p_consent_refs, p_target_type, p_target_ref, p_required
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN) FROM PUBLIC;
