-- Vemoria V79.2K — Protected beta mode
CREATE TABLE IF NOT EXISTS beta_tester_acceptances (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NULL,
    tester_ref TEXT NULL,
    beta_program_version TEXT NOT NULL DEFAULT 'V79.2K',
    accepted_terms_hash TEXT NOT NULL,
    confidentiality_ack BOOLEAN NOT NULL DEFAULT FALSE,
    no_redistribution_ack BOOLEAN NOT NULL DEFAULT FALSE,
    no_critical_use_ack BOOLEAN NOT NULL DEFAULT FALSE,
    revocation_ack BOOLEAN NOT NULL DEFAULT FALSE,
    evidence_hash TEXT NOT NULL,
    metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    accepted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_beta_tester_acceptances_hash ON beta_tester_acceptances(evidence_hash);
CREATE INDEX IF NOT EXISTS idx_beta_tester_acceptances_user ON beta_tester_acceptances(user_id, accepted_at DESC);
