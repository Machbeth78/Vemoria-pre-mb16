-- Vemoria Gate06 R1J P6 Fabric/Proof static completion
-- Runtime remains NON_ESEGUITO. This migration records metadata only.

CREATE TABLE IF NOT EXISTS gate06_r1j_p6_fabric_proof_static_completion (
    id INTEGER PRIMARY KEY,
    gate TEXT NOT NULL,
    version TEXT NOT NULL,
    static_completion_state TEXT NOT NULL,
    runtime_real TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    notes TEXT NOT NULL
);

INSERT INTO gate06_r1j_p6_fabric_proof_static_completion (
    id, gate, version, static_completion_state, runtime_real, notes
) VALUES (
    1,
    'GATE06_R1J_P6_FABRIC_PROOF_STATIC_COMPLETION',
    'GATE06_R1J_P6_FABRIC_PROOF_STATIC_COMPLETION_V149_2026-06-19',
    'STATIC_COMPLETED_RUNTIME_DEFERRED',
    'NON_ESEGUITO',
    'Static completion for VC-063 and VC-067. Signature/acceptance and protected preview contracts are closed statically; DEPOSITED remains distinct from DELIVERED; receipt fabrication is forbidden. No real Fabric transfer, signature, preview, PostgreSQL or Android/Flutter runtime executed.'
) ON CONFLICT(id) DO UPDATE SET
    version=excluded.version,
    static_completion_state=excluded.static_completion_state,
    runtime_real=excluded.runtime_real,
    notes=excluded.notes;
