-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- database/migration_v38_luiss_behavior.sql

CREATE TABLE IF NOT EXISTS luiss_decision_log (
    id              UUID PRIMARY KEY,
    trigger         TEXT NOT NULL,
    utente_id       UUID NULL,
    documento_id    UUID NULL,
    evento_id       UUID NULL,
    contatto_id     UUID NULL,
    contesto_json   JSONB NULL,
    output_json     JSONB NULL,
    creato_il       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_luiss_decision_trigger
    ON luiss_decision_log(trigger, creato_il DESC);

CREATE INDEX IF NOT EXISTS idx_luiss_decision_documento
    ON luiss_decision_log(documento_id, creato_il DESC);

CREATE INDEX IF NOT EXISTS idx_luiss_decision_evento
    ON luiss_decision_log(evento_id, creato_il DESC);

CREATE TABLE IF NOT EXISTS luiss_feedback_log (
    id                  UUID PRIMARY KEY,
    decision_log_id     UUID NOT NULL REFERENCES luiss_decision_log(id) ON DELETE CASCADE,
    scelta_utente       BOOLEAN NULL,
    correzione_tipo     TEXT NULL,
    correzione_payload  JSONB NULL,
    registrato_il       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_luiss_feedback_decision
    ON luiss_feedback_log(decision_log_id, registrato_il DESC);

CREATE TABLE IF NOT EXISTS luiss_next_step_cache (
    id              UUID PRIMARY KEY,
    target_tipo     TEXT NOT NULL,
    target_id       TEXT NOT NULL,
    next_step_json  JSONB NULL,
    aggiornato_il   TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_luiss_next_step UNIQUE (target_tipo, target_id)
);
