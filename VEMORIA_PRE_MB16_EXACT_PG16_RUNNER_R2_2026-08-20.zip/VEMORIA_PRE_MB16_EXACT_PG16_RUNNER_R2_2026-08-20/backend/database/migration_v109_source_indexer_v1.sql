-- Vemoria — Source Indexer V1 (Product Probe)
-- Migration v109 — additive. Solo CREATE IF NOT EXISTS / ALTER ADD COLUMN IF NOT EXISTS.
--
-- Obiettivo: permettere a Vemoria di ricevere contenuti storici autorizzati
-- (file, immagini, PDF, screenshot, export chat testo, allegati generici,
--  manual import) e trasformarli in memoria operativa collegata a
-- relazione/dossier/timeline/ricerca.
--
-- Filosofia: non sostituisce documenti.py / memorie.py. Vive accanto come
-- "porta dentro memoria esistente". Il vero contenuto, una volta importato,
-- vive nelle tabelle canoniche (documenti, memorie) se l'utente sceglie
-- "salva_in_vemoria" o "vault_copy"; resta solo come puntatore se sceglie
-- "indexed_only" (in tal caso documento/memoria NON vengono creati,
-- ricercabilità solo via source_indexed_items.extracted_text/summary).
--
-- Nessuna UPDATE distruttiva. Nessun DROP. Nessuna FK obbligatoria verso
-- tabelle che non esistono ancora (Gmail v2). Le FK opzionali verso
-- utenti/memorie/dossier/documenti/contatti_utente sono già presenti.

-- ============================================================
-- source_connections
-- Una "fonte" registrata da cui l'utente autorizza Vemoria a
-- importare contenuti (es: device_local, gmail, screenshot_batch,
-- chat_export). Per V1 la maggior parte saranno create al volo
-- durante l'import diretto e marcate status='direct'.
-- ============================================================
CREATE TABLE IF NOT EXISTS source_connections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,

    -- Tipo sorgente. Lista controllata via CHECK:
    --   device_local      = file dal telefono dell'utente (import manuale)
    --   chat_export       = esportazione testuale di chat (WhatsApp/Telegram/Signal export)
    --   screenshot_batch  = lotto di screenshot
    --   email_forwarded   = email inoltrata manualmente (non Gmail OAuth)
    --   attachment_batch  = batch di allegati senza email
    --   manual_import     = catch-all per import manuale
    --   gmail             = SPEC_ONLY in V1 — connector Gmail OAuth, NON implementato qui
    source_type TEXT NOT NULL CHECK (source_type IN (
        'device_local',
        'chat_export',
        'screenshot_batch',
        'email_forwarded',
        'attachment_batch',
        'manual_import',
        'gmail'
    )),

    -- Etichetta human-readable per UI (es. "iPhone di Massimo", "Chat WA Mamma")
    source_label TEXT NULL,

    -- Scope consenso JSON. Esempi:
    --   {"granular": ["images"], "max_size_bytes_per_item": 52428800}
    --   {"granular": ["pdfs","attachments"], "retention_days": 365}
    permission_scope JSONB NOT NULL DEFAULT '{}'::jsonb,

    -- Stato. 'active'=in uso; 'revoked'=utente ha revocato; 'direct'=connection
    -- effimera creata al volo per un singolo import_v1 (no persist long-term).
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','revoked','direct','suspended')),

    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revoked_at      TIMESTAMPTZ NULL,
    last_indexed_at TIMESTAMPTZ NULL
);

CREATE INDEX IF NOT EXISTS idx_source_connections_user_created
    ON source_connections(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_source_connections_user_type_status
    ON source_connections(user_id, source_type, status);


-- ============================================================
-- source_indexed_items
-- Un item indicizzato/importato. Distinzione semantica chiave
-- (NESSUN'AMBIGUITÀ — questa è la filosofia di Vemoria):
--
--   indexed_only=TRUE, saved_in_vemoria=FALSE
--     → solo metadati + extracted_text. Nessun file copiato.
--       Ricercabile in source_indexed_items, NON in memorie.
--
--   indexed_only=FALSE, saved_in_vemoria=TRUE
--     → contenuto promosso a Memoria. linked_memoria_id valorizzato.
--       Ricercabile via FTS su memorie (canonico).
--
--   vault_copy_document_id valorizzato
--     → oltre alla memoria esiste anche una copia file su storage Vemoria
--       (Documento). Per V1 = pari a saved_in_vemoria=TRUE + Documento creato.
--
--   source_reference (path/URI/locator)
--     → puntatore alla fonte originale. Non garantito persistente nel tempo.
-- ============================================================
CREATE TABLE IF NOT EXISTS source_indexed_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,

    -- NULLABLE: import "diretti" senza connection registrata
    source_connection_id UUID NULL REFERENCES source_connections(id) ON DELETE SET NULL,

    source_type TEXT NOT NULL CHECK (source_type IN (
        -- Tipi contenuto (NON tipi connection — granulare)
        'image',
        'pdf',
        'generic_document',
        'generic_file',
        'exported_chat_text',
        'screenshot',
        'email_forwarded',
        'attachment',
        'manual_import'
    )),

    -- Puntatore alla fonte originale (path device, URI, identificatore esterno).
    -- Per V1: stringa libera. Mai usata come autorità.
    source_reference TEXT NULL,

    original_filename TEXT NULL,
    mime_type         TEXT NULL,
    size_bytes        BIGINT NULL,

    -- Hash SHA256 del contenuto, se disponibile.
    -- Permette deduplicazione lato V2.
    content_hash TEXT NULL,

    -- Flag policy contenuto:
    indexed_only      BOOLEAN NOT NULL DEFAULT TRUE,
    saved_in_vemoria  BOOLEAN NOT NULL DEFAULT FALSE,

    -- Promozioni verso tabelle canoniche (FK opzionali):
    linked_memoria_id      UUID NULL REFERENCES memorie(id)   ON DELETE SET NULL,
    vault_copy_document_id UUID NULL REFERENCES documenti(id) ON DELETE SET NULL,

    -- Estrazione/derivati testuali (NON-binari):
    extracted_text   TEXT NULL,
    summary          TEXT NULL,
    detected_people  JSONB NOT NULL DEFAULT '[]'::jsonb,
    detected_dates   JSONB NOT NULL DEFAULT '[]'::jsonb,
    detected_keywords JSONB NOT NULL DEFAULT '[]'::jsonb,

    -- Collegamenti operativi (FK opzionali):
    linked_contact_id  UUID NULL,  -- contatti_utente.id  (FK non hard: contatti vive in altro modulo)
    linked_dossier_id  UUID NULL REFERENCES dossier(id) ON DELETE SET NULL,

    -- Titolo/descrizione human, se l'utente li passa dall'UI
    title        TEXT NULL,
    description  TEXT NULL,

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    -- Soft delete tombstone per richieste di cancellazione indice
    deleted_at TIMESTAMPTZ NULL,

    -- Coerenza interna: se saved_in_vemoria=TRUE deve esistere linked_memoria_id
    CONSTRAINT chk_source_item_promotion CHECK (
        (saved_in_vemoria = FALSE)
        OR (saved_in_vemoria = TRUE AND linked_memoria_id IS NOT NULL)
    )
);

CREATE INDEX IF NOT EXISTS idx_source_items_user_created
    ON source_indexed_items(user_id, created_at DESC)
    WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_source_items_user_type
    ON source_indexed_items(user_id, source_type)
    WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_source_items_connection
    ON source_indexed_items(source_connection_id)
    WHERE source_connection_id IS NOT NULL AND deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_source_items_linked_dossier
    ON source_indexed_items(linked_dossier_id)
    WHERE linked_dossier_id IS NOT NULL AND deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_source_items_linked_contact
    ON source_indexed_items(linked_contact_id)
    WHERE linked_contact_id IS NOT NULL AND deleted_at IS NULL;

-- FTS leggero sul contenuto indicizzato (estratto testo + summary + titolo).
-- Coerente con la convenzione di ricerca.py (italian, peso titolo > sommario > testo).
CREATE INDEX IF NOT EXISTS idx_source_items_fts
    ON source_indexed_items
    USING GIN (
        (
            setweight(to_tsvector('italian', coalesce(title,'')),         'A') ||
            setweight(to_tsvector('italian', coalesce(summary,'')),       'B') ||
            setweight(to_tsvector('italian', coalesce(extracted_text,'')), 'C')
        )
    )
    WHERE deleted_at IS NULL;

-- Dedup hash (advisory, non unique: due utenti diversi possono avere lo stesso file)
CREATE INDEX IF NOT EXISTS idx_source_items_user_hash
    ON source_indexed_items(user_id, content_hash)
    WHERE content_hash IS NOT NULL AND deleted_at IS NULL;


-- ============================================================
-- source_consent_log
-- Audit append-only di tutti gli eventi di consenso/revoca/cancellazione
-- legati a source_connections. Mai UPDATE, mai DELETE.
-- ============================================================
CREATE TABLE IF NOT EXISTS source_consent_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,

    source_type TEXT NOT NULL,                       -- coerente con source_connections.source_type
    source_connection_id UUID NULL,                   -- opzionale: non FK per non bloccare audit su delete

    action TEXT NOT NULL CHECK (action IN (
        'register',
        'import',
        'revoke',
        'delete_index',
        'modify_scope'
    )),

    scope JSONB NOT NULL DEFAULT '{}'::jsonb,
    user_visible_scope_description TEXT NULL,

    revoked          BOOLEAN NOT NULL DEFAULT FALSE,
    deletion_requested BOOLEAN NOT NULL DEFAULT FALSE,

    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_source_consent_log_user_ts
    ON source_consent_log(user_id, timestamp DESC);

CREATE INDEX IF NOT EXISTS idx_source_consent_log_conn
    ON source_consent_log(source_connection_id, timestamp DESC)
    WHERE source_connection_id IS NOT NULL;


-- ============================================================
-- timeline_event — additive: NESSUN ALTER. La policy ORIGINI_VALIDE
-- è applicata lato Python in api/routers/timeline.py.
-- In v109 viene introdotto in modo permanente l'origine 'source' e
-- viene patchato il set Python coerentemente in timeline.py.
-- ============================================================

-- ============================================================
-- Nota di registro:
-- Le tabelle "source_*" sono ADDITIVE. Non toccano:
--   utenti, documenti, memorie, dossier, contatti_utente, timeline_event,
--   eventi_documento, schema_migration_state, privacy_*.
-- Una rollback è ottenibile con un DROP TABLE IF EXISTS in ordine inverso
-- (source_consent_log → source_indexed_items → source_connections);
-- non è fornita migration_runner-side per evitare perdita audit accidentale.
-- ============================================================
