-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB12-P0 R1J — canonical binding-only trusted writer, non-forgeable governed
-- context history, serialized revisions and explicit stale-revision control.
-- Additive/idempotent. Does not modify migrations v176-v184.

BEGIN;

-- ---------------------------------------------------------------------------
-- 1. Persist governance provenance on the canonical source-card binding.
-- ---------------------------------------------------------------------------
ALTER TABLE public.mb12_p0_source_card_binding
    ADD COLUMN IF NOT EXISTS actor_id TEXT NOT NULL DEFAULT '';
ALTER TABLE public.mb12_p0_source_card_binding
    ADD COLUMN IF NOT EXISTS device_id TEXT NOT NULL DEFAULT '';
ALTER TABLE public.mb12_p0_source_card_binding
    ADD COLUMN IF NOT EXISTS audit_id UUID NULL;
ALTER TABLE public.mb12_p0_source_card_binding
    ADD COLUMN IF NOT EXISTS operation TEXT NOT NULL DEFAULT '';

-- ---------------------------------------------------------------------------
-- 2. Governed-context history integrity and privileges.
-- ---------------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_mb12_p0_governed_context_history_immutable
    ON public.mb12_p0_governed_context_history;

-- R1I stored the first link as 0. Normalize it before enforcing the canonical
-- chain invariant (revision 1 has no predecessor).
UPDATE public.mb12_p0_governed_context_history
   SET previous_revision = NULL
 WHERE revision = 1
   AND previous_revision = 0;

CREATE UNIQUE INDEX IF NOT EXISTS uq_mb12_governed_context_history_revision
    ON public.mb12_p0_governed_context_history(owner_user_id, context_id, revision);

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
          FROM pg_constraint
         WHERE conname = 'chk_mb12_governed_context_history_revision_chain'
           AND conrelid = 'public.mb12_p0_governed_context_history'::regclass
    ) THEN
        ALTER TABLE public.mb12_p0_governed_context_history
            ADD CONSTRAINT chk_mb12_governed_context_history_revision_chain CHECK (
                (revision = 1 AND previous_revision IS NULL)
                OR
                (revision > 1 AND previous_revision = revision - 1)
            );
    END IF;
END
$$;

REVOKE INSERT, UPDATE, DELETE ON public.mb12_p0_governed_context_history FROM PUBLIC;
REVOKE INSERT, UPDATE, DELETE ON public.mb12_p0_governed_context_history FROM mb12_p0_app;
GRANT SELECT ON public.mb12_p0_governed_context_history TO mb12_p0_app;

CREATE OR REPLACE FUNCTION public.mb12_p0_governed_context_history_immutable()
RETURNS trigger AS $$
DECLARE
    v_writer_token TEXT := COALESCE(current_setting('mb12.context_history_writer', true), '');
BEGIN
    IF TG_OP = 'INSERT'
       AND v_writer_token <> ''
       AND v_writer_token = COALESCE(NEW.audit_id, '') THEN
        RETURN NEW;
    END IF;
    RAISE EXCEPTION USING
        ERRCODE = '42501',
        MESSAGE = 'mb12_p0_governed_context_history is append-only and writer-governed';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_mb12_p0_governed_context_history_immutable
    ON public.mb12_p0_governed_context_history;
CREATE TRIGGER trg_mb12_p0_governed_context_history_immutable
    BEFORE INSERT OR UPDATE OR DELETE ON public.mb12_p0_governed_context_history
    FOR EACH ROW EXECUTE FUNCTION public.mb12_p0_governed_context_history_immutable();

REVOKE ALL ON FUNCTION public.mb12_p0_governed_context_history_immutable() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb12_p0_governed_context_history_immutable() FROM mb12_p0_app;

-- ---------------------------------------------------------------------------
-- 3. Canonical binding writer with explicit audit provenance.
--    The legacy six-argument writer remains for historical migration replay but
--    is no longer executable by PUBLIC or the application role.
-- ---------------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.mb12_p0_create_source_card_binding(
    TEXT, UUID, UUID, UUID, TEXT, UUID
) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb12_p0_create_source_card_binding(
    TEXT, UUID, UUID, UUID, TEXT, UUID
) FROM mb12_p0_app;

CREATE OR REPLACE FUNCTION public.mb12_p0_create_source_card_binding(
    p_source_card_id TEXT,
    p_source_id UUID,
    p_source_revision_id UUID,
    p_evidence_id UUID,
    p_scope TEXT,
    p_grant_id UUID,
    p_actor_id TEXT,
    p_device_id TEXT,
    p_audit_id UUID,
    p_operation TEXT
) RETURNS VOID AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_hash TEXT;
    v_inventory_grant UUID;
    v_evidence_grant UUID;
    v_audit_payload JSONB;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'authenticated owner missing';
    END IF;
    IF COALESCE(trim(p_source_card_id), '') = ''
       OR COALESCE(trim(p_actor_id), '') = ''
       OR COALESCE(trim(p_device_id), '') = ''
       OR COALESCE(trim(p_operation), '') = ''
       OR p_audit_id IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'binding governance provenance incomplete';
    END IF;

    SELECT l.technical_payload
      INTO v_audit_payload
      FROM public.authorized_memory_activity_log l
     WHERE l.id = p_audit_id
       AND l.user_id = v_owner
       AND l.source_id IS NULL
       AND l.action = p_operation
       AND l.plane = 'MEMORY';
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = '23503', MESSAGE = 'canonical binding audit event not found';
    END IF;
    IF COALESCE(v_audit_payload->>'actor_id', '') <> p_actor_id
       OR COALESCE(v_audit_payload->>'device_id', '') <> p_device_id
       OR COALESCE(v_audit_payload->>'operation', '') <> p_operation
       OR jsonb_typeof(v_audit_payload->'source_cards') <> 'array'
       OR NOT (v_audit_payload->'source_cards' ? p_source_card_id) THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'canonical binding audit payload mismatch';
    END IF;

    SELECT i.content_hash, i.grant_id
      INTO v_hash, v_inventory_grant
      FROM public.authorized_memory_inventory_items i
     WHERE i.id = p_source_revision_id
       AND i.user_id = v_owner
       AND i.source_id = p_source_id
       AND i.deleted_at IS NULL
       AND i.memory_state <> 'revoked';
    IF NOT FOUND OR v_hash IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '23503', MESSAGE = 'source revision not found or not owned';
    END IF;
    IF v_inventory_grant IS NOT NULL AND v_inventory_grant IS DISTINCT FROM p_grant_id THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'binding grant does not match inventory grant';
    END IF;

    SELECT l.grant_id
      INTO v_evidence_grant
      FROM public.authorized_memory_activity_log l
     WHERE l.id = p_evidence_id
       AND l.user_id = v_owner
       AND l.source_id = p_source_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = '23503', MESSAGE = 'binding evidence not found or not owned';
    END IF;
    IF v_evidence_grant IS DISTINCT FROM p_grant_id THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'binding grant does not match evidence grant';
    END IF;

    INSERT INTO public.mb12_p0_source_card_binding (
        source_card_id, owner_user_id, source_id, source_revision_id, evidence_id,
        content_hash, scope, status, grant_id, actor_id, device_id, audit_id, operation
    ) VALUES (
        p_source_card_id, v_owner, p_source_id, p_source_revision_id, p_evidence_id,
        v_hash, COALESCE(NULLIF(p_scope, ''), 'source'), 'active', p_grant_id,
        p_actor_id, p_device_id, p_audit_id, p_operation
    )
    ON CONFLICT (owner_user_id, source_card_id) DO UPDATE SET
        source_id = EXCLUDED.source_id,
        source_revision_id = EXCLUDED.source_revision_id,
        evidence_id = EXCLUDED.evidence_id,
        content_hash = EXCLUDED.content_hash,
        scope = EXCLUDED.scope,
        grant_id = EXCLUDED.grant_id,
        actor_id = EXCLUDED.actor_id,
        device_id = EXCLUDED.device_id,
        audit_id = EXCLUDED.audit_id,
        operation = EXCLUDED.operation,
        status = 'active',
        revoked_at = NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb12_p0_create_source_card_binding(
    TEXT, UUID, UUID, UUID, TEXT, UUID, TEXT, TEXT, UUID, TEXT
) FROM PUBLIC;
REVOKE INSERT, UPDATE, DELETE ON public.mb12_p0_source_card_binding FROM PUBLIC;
REVOKE INSERT, UPDATE, DELETE ON public.mb12_p0_source_card_binding FROM mb12_p0_app;
GRANT SELECT ON public.mb12_p0_source_card_binding TO mb12_p0_app;
GRANT EXECUTE ON FUNCTION public.mb12_p0_create_source_card_binding(
    TEXT, UUID, UUID, UUID, TEXT, UUID, TEXT, TEXT, UUID, TEXT
) TO mb12_p0_app;

-- ---------------------------------------------------------------------------
-- 4. Private trusted-data writer. It cannot be called by PUBLIC or the app role;
--    the canonical binding trigger is its only production entry point.
-- ---------------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.mb12_p0_upsert_trusted_data_value(
    UUID, UUID, UUID, TEXT, TEXT, TEXT, UUID, TEXT
) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb12_p0_upsert_trusted_data_value(
    UUID, UUID, UUID, TEXT, TEXT, TEXT, UUID, TEXT
) FROM mb12_p0_app;

CREATE OR REPLACE FUNCTION public.mb12_p0_upsert_trusted_data_value(
    p_source_card_id TEXT,
    p_source_id UUID,
    p_source_revision_id UUID,
    p_evidence_id UUID,
    p_field_name TEXT,
    p_normalized_value TEXT,
    p_content_hash TEXT,
    p_grant_id UUID,
    p_scope TEXT
) RETURNS VOID AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_binding RECORD;
    v_source RECORD;
    v_item RECORD;
    v_evidence RECORD;
    v_payload JSONB;
    v_fields JSONB;
    v_value TEXT;
    v_derived_scope TEXT;
    v_keys TEXT;
    v_payload_grant TEXT;
    v_expected_action TEXT;
    v_grant RECORD;
    v_constraints JSONB;
    v_data_scope JSONB;
    v_is_public BOOLEAN := FALSE;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'authenticated owner missing';
    END IF;

    SELECT b.*
      INTO v_binding
      FROM public.mb12_p0_source_card_binding b
     WHERE b.owner_user_id = v_owner
       AND b.source_card_id = p_source_card_id
       AND b.status = 'active'
       AND b.revoked_at IS NULL;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = '23503', MESSAGE = 'canonical source-card binding not found';
    END IF;
    IF v_binding.source_id IS DISTINCT FROM p_source_id
       OR v_binding.source_revision_id IS DISTINCT FROM p_source_revision_id
       OR v_binding.evidence_id IS DISTINCT FROM p_evidence_id
       OR v_binding.content_hash IS DISTINCT FROM p_content_hash
       OR v_binding.grant_id IS DISTINCT FROM p_grant_id
       OR v_binding.scope IS DISTINCT FROM p_scope THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'trusted data does not match canonical binding';
    END IF;
    IF COALESCE(v_binding.actor_id, '') = ''
       OR COALESCE(v_binding.device_id, '') = ''
       OR v_binding.audit_id IS NULL
       OR COALESCE(v_binding.operation, '') = '' THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'canonical binding provenance incomplete';
    END IF;

    SELECT s.status, s.revoked_at, s.source_kind
      INTO v_source
      FROM public.authorized_memory_sources s
     WHERE s.id = p_source_id
       AND s.user_id = v_owner;
    IF NOT FOUND OR v_source.status <> 'active' OR v_source.revoked_at IS NOT NULL THEN
        RAISE EXCEPTION USING ERRCODE = '23503', MESSAGE = 'source not found, cross-owner, revoked or inactive';
    END IF;

    SELECT i.content_hash, i.item_type, i.grant_id, i.memory_state, i.deleted_at
      INTO v_item
      FROM public.authorized_memory_inventory_items i
     WHERE i.id = p_source_revision_id
       AND i.user_id = v_owner
       AND i.source_id = p_source_id;
    IF NOT FOUND OR v_item.deleted_at IS NOT NULL OR v_item.memory_state = 'revoked'
       OR v_item.content_hash IS NULL OR v_item.content_hash IS DISTINCT FROM p_content_hash THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'source revision/hash mismatch';
    END IF;
    IF v_item.grant_id IS NOT NULL AND v_item.grant_id IS DISTINCT FROM p_grant_id THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'inventory grant does not match canonical binding';
    END IF;

    SELECT l.action, l.plane, l.technical_payload, l.grant_id
      INTO v_evidence
      FROM public.authorized_memory_activity_log l
     WHERE l.id = p_evidence_id
       AND l.user_id = v_owner
       AND l.source_id = p_source_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = '23503', MESSAGE = 'evidence not found or cross-owner';
    END IF;
    IF v_evidence.action NOT IN ('read_metadata', 'eligibility_read', 'promote_to_canonical') THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'evidence action not allowed';
    END IF;
    IF (v_evidence.action IN ('read_metadata', 'eligibility_read') AND v_evidence.plane <> 'EXISTENCE')
       OR (v_evidence.action = 'promote_to_canonical' AND v_evidence.plane <> 'MEMORY') THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'evidence action/plane mismatch';
    END IF;
    IF v_evidence.grant_id IS DISTINCT FROM p_grant_id THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'evidence grant does not match canonical binding';
    END IF;

    v_payload := COALESCE(v_evidence.technical_payload, '{}'::jsonb);
    IF jsonb_typeof(v_payload) <> 'object'
       OR COALESCE(v_payload->>'source_id', '') <> p_source_id::text
       OR COALESCE(v_payload->>'source_revision_id', '') <> p_source_revision_id::text
       OR COALESCE(v_payload->>'content_hash', '') <> p_content_hash
       OR COALESCE(v_payload->>'action', v_payload->>'operation', '') <> v_evidence.action
       OR COALESCE(v_payload->>'plane', '') <> v_evidence.plane THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'evidence payload lineage mismatch';
    END IF;

    v_payload_grant := NULLIF(v_payload->>'grant_id', '');
    IF p_grant_id IS NOT NULL AND v_payload_grant IS DISTINCT FROM p_grant_id::text THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'evidence payload grant mismatch';
    ELSIF p_grant_id IS NULL AND v_payload_grant IS NOT NULL THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'unexpected evidence payload grant';
    END IF;

    v_fields := v_payload->'fields';
    IF NULLIF(v_payload->>'scope', '') IS NOT NULL THEN
        v_derived_scope := v_payload->>'scope';
    ELSIF jsonb_typeof(v_fields) = 'object' AND v_fields <> '{}'::jsonb THEN
        SELECT string_agg(k, ',' ORDER BY k)
          INTO v_keys
          FROM jsonb_object_keys(v_fields) AS k;
        v_derived_scope := 'data:' || COALESCE(v_keys, 'unknown');
    ELSIF COALESCE(v_item.item_type, '') NOT IN ('', 'source', 'source_revision') THEN
        v_derived_scope := 'document:' || v_item.item_type;
    ELSE
        v_derived_scope := 'source';
    END IF;
    IF v_derived_scope IS DISTINCT FROM p_scope THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'trusted-data scope does not match evidence-derived scope';
    END IF;

    IF jsonb_typeof(v_fields) = 'object' AND v_fields ? p_field_name THEN
        v_value := v_fields->>p_field_name;
    ELSIF p_scope LIKE 'document:%' AND p_field_name = substring(p_scope from 10) THEN
        v_value := p_content_hash;
    ELSE
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'trusted field is not attested by evidence';
    END IF;
    IF p_normalized_value IS DISTINCT FROM v_value THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'trusted normalized value mismatch';
    END IF;

    SELECT COALESCE(a.is_public_evidence, FALSE)
      INTO v_is_public
      FROM public.canonical_source_card_authority a
     WHERE a.owner_user_id = v_owner
       AND a.source_card_id = p_source_card_id
       AND a.status = 'active';
    v_is_public := COALESCE(v_is_public, FALSE);

    IF p_grant_id IS NULL THEN
        IF NOT v_is_public THEN
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'personal source requires a canonical grant';
        END IF;
    ELSE
        SELECT g.action, g.plane, g.status, g.expires_at, g.revoked_at,
               g.explicit_user_ack, g.constraints, g.window_policy
          INTO v_grant
          FROM public.authorized_memory_consent_grants g
         WHERE g.id = p_grant_id
           AND g.user_id = v_owner
           AND g.source_id = p_source_id;
        IF NOT FOUND OR v_grant.status <> 'active' OR v_grant.revoked_at IS NOT NULL
           OR (v_grant.expires_at IS NOT NULL AND v_grant.expires_at <= NOW())
           OR NOT COALESCE(v_grant.explicit_user_ack, FALSE) THEN
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'grant inactive, revoked, expired or not acknowledged';
        END IF;
        v_expected_action := CASE
            WHEN v_evidence.action = 'eligibility_read' THEN 'read_metadata'
            ELSE v_evidence.action
        END;
        IF v_grant.action IS DISTINCT FROM v_expected_action
           OR v_grant.plane IS DISTINCT FROM v_evidence.plane THEN
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'grant action/plane mismatch';
        END IF;

        v_constraints := COALESCE(v_grant.constraints, '{}'::jsonb);
        IF COALESCE(v_constraints->>'owner_confirmation_required', 'false') <> 'true' THEN
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'grant owner confirmation missing';
        END IF;
        IF jsonb_typeof(v_constraints->'covered_source_card_ids') = 'array'
           AND jsonb_array_length(v_constraints->'covered_source_card_ids') > 0
           AND NOT (v_constraints->'covered_source_card_ids' ? p_source_card_id) THEN
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'grant does not cover source card';
        END IF;

        IF v_evidence.action IN ('read_metadata', 'eligibility_read') THEN
            IF COALESCE(v_constraints->>'purpose', '') <> 'eligibility' THEN
                RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'grant purpose mismatch';
            END IF;
            v_data_scope := COALESCE(v_constraints->'data_scope', '{}'::jsonb);
            IF p_scope LIKE 'data:%' THEN
                IF jsonb_typeof(v_data_scope->'allowed_data_keys') <> 'array'
                   OR NOT (v_data_scope->'allowed_data_keys' ? p_field_name) THEN
                    RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'grant data scope does not cover field';
                END IF;
            ELSIF p_scope LIKE 'document:%' THEN
                IF jsonb_typeof(v_data_scope->'allowed_documents') <> 'array'
                   OR NOT (v_data_scope->'allowed_documents' ? p_field_name) THEN
                    RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'grant document scope does not cover document';
                END IF;
            END IF;
        END IF;
    END IF;

    INSERT INTO public.mb12_p0_trusted_data_value (
        owner_user_id, source_id, source_revision_id, evidence_id, field_name,
        normalized_value, content_hash, grant_id, scope, source_card_id,
        actor_id, device_id, audit_id
    ) VALUES (
        v_owner, p_source_id, p_source_revision_id, p_evidence_id, p_field_name,
        p_normalized_value, p_content_hash, p_grant_id, p_scope, p_source_card_id,
        v_binding.actor_id, v_binding.device_id, v_binding.audit_id::text
    )
    ON CONFLICT (owner_user_id, source_id, source_revision_id, field_name) DO UPDATE SET
        evidence_id = EXCLUDED.evidence_id,
        normalized_value = EXCLUDED.normalized_value,
        content_hash = EXCLUDED.content_hash,
        grant_id = EXCLUDED.grant_id,
        scope = EXCLUDED.scope,
        source_card_id = EXCLUDED.source_card_id,
        actor_id = EXCLUDED.actor_id,
        device_id = EXCLUDED.device_id,
        audit_id = EXCLUDED.audit_id,
        created_at = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb12_p0_upsert_trusted_data_value(
    TEXT, UUID, UUID, UUID, TEXT, TEXT, TEXT, UUID, TEXT
) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb12_p0_upsert_trusted_data_value(
    TEXT, UUID, UUID, UUID, TEXT, TEXT, TEXT, UUID, TEXT
) FROM mb12_p0_app;

DROP TRIGGER IF EXISTS trg_mb12_p0_trusted_data_from_binding
    ON public.mb12_p0_source_card_binding;
DROP FUNCTION IF EXISTS public.mb12_p0_trusted_data_from_binding();

CREATE OR REPLACE FUNCTION public.mb12_p0_trusted_data_from_binding()
RETURNS trigger AS $$
DECLARE
    v_payload JSONB;
    v_fields JSONB;
    v_field TEXT;
BEGIN
    SELECT l.technical_payload
      INTO v_payload
      FROM public.authorized_memory_activity_log l
     WHERE l.id = NEW.evidence_id
       AND l.user_id = NEW.owner_user_id
       AND l.source_id = NEW.source_id;
    IF NOT FOUND OR jsonb_typeof(v_payload) <> 'object' THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'canonical binding evidence payload unavailable';
    END IF;

    v_fields := v_payload->'fields';
    IF jsonb_typeof(v_fields) = 'object' THEN
        FOR v_field IN SELECT jsonb_object_keys(v_fields) LOOP
            PERFORM public.mb12_p0_upsert_trusted_data_value(
                NEW.source_card_id,
                NEW.source_id,
                NEW.source_revision_id,
                NEW.evidence_id,
                v_field,
                v_fields->>v_field,
                NEW.content_hash,
                NEW.grant_id,
                NEW.scope
            );
        END LOOP;
    END IF;

    IF NEW.scope LIKE 'document:%' THEN
        v_field := substring(NEW.scope from 10);
        PERFORM public.mb12_p0_upsert_trusted_data_value(
            NEW.source_card_id,
            NEW.source_id,
            NEW.source_revision_id,
            NEW.evidence_id,
            v_field,
            NEW.content_hash,
            NEW.content_hash,
            NEW.grant_id,
            NEW.scope
        );
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

CREATE TRIGGER trg_mb12_p0_trusted_data_from_binding
    AFTER INSERT OR UPDATE ON public.mb12_p0_source_card_binding
    FOR EACH ROW EXECUTE FUNCTION public.mb12_p0_trusted_data_from_binding();

REVOKE ALL ON FUNCTION public.mb12_p0_trusted_data_from_binding() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb12_p0_trusted_data_from_binding() FROM mb12_p0_app;

REVOKE INSERT, UPDATE, DELETE ON public.mb12_p0_trusted_data_value FROM PUBLIC;
REVOKE INSERT, UPDATE, DELETE ON public.mb12_p0_trusted_data_value FROM mb12_p0_app;
GRANT SELECT ON public.mb12_p0_trusted_data_value TO mb12_p0_app;

-- ---------------------------------------------------------------------------
-- 5. Serialized governed-context writer with expected-revision and canonical
--    audit verification. The legacy seven-argument writer is disabled.
-- ---------------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.mb12_p0_upsert_governed_context(
    TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TIMESTAMPTZ
) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb12_p0_upsert_governed_context(
    TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TIMESTAMPTZ
) FROM mb12_p0_app;

CREATE OR REPLACE FUNCTION public.mb12_p0_upsert_governed_context(
    p_context_id TEXT,
    p_dossier_id TEXT,
    p_rule_set_id TEXT,
    p_subject_id TEXT,
    p_territory TEXT,
    p_state TEXT,
    p_revoked_at TIMESTAMPTZ,
    p_expected_revision INTEGER,
    p_actor_id TEXT,
    p_device_id TEXT,
    p_audit_id UUID,
    p_operation TEXT
) RETURNS INTEGER AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_projection public.mb12_p0_governed_context%ROWTYPE;
    v_latest public.mb12_p0_governed_context_history%ROWTYPE;
    v_previous_revision INTEGER := 0;
    v_new_revision INTEGER;
    v_payload JSONB;
    v_payload_hash TEXT;
    v_audit_payload JSONB;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'authenticated owner missing';
    END IF;
    IF COALESCE(trim(p_context_id), '') = ''
       OR COALESCE(trim(p_actor_id), '') = ''
       OR COALESCE(trim(p_device_id), '') = ''
       OR COALESCE(trim(p_operation), '') = ''
       OR p_audit_id IS NULL
       OR p_expected_revision IS NULL
       OR p_expected_revision < 0 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'governed context provenance or expected revision incomplete';
    END IF;
    IF p_state NOT IN ('active', 'revoked', 'superseded') THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'invalid governed context state';
    END IF;
    IF (p_state = 'active' AND p_revoked_at IS NOT NULL)
       OR (p_state = 'revoked' AND p_revoked_at IS NULL) THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'governed context state/revocation mismatch';
    END IF;

    SELECT l.technical_payload
      INTO v_audit_payload
      FROM public.authorized_memory_activity_log l
     WHERE l.id = p_audit_id
       AND l.user_id = v_owner
       AND l.source_id IS NULL
       AND l.action = 'governed_context'
       AND l.plane = 'MEMORY';
    IF NOT FOUND
       OR COALESCE(v_audit_payload->>'context_id', '') <> p_context_id
       OR COALESCE(v_audit_payload->>'actor_id', '') <> p_actor_id
       OR COALESCE(v_audit_payload->>'device_id', '') <> p_device_id
       OR COALESCE(v_audit_payload->>'operation', '') <> p_operation THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'governed context audit mismatch';
    END IF;

    -- Serialize both first creation and updates for this owner/context pair.
    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_context_id, 0));

    SELECT c.*
      INTO v_projection
      FROM public.mb12_p0_governed_context c
     WHERE c.owner_user_id = v_owner
       AND c.context_id = p_context_id
     FOR UPDATE;

    SELECT h.*
      INTO v_latest
      FROM public.mb12_p0_governed_context_history h
     WHERE h.owner_user_id = v_owner
       AND h.context_id = p_context_id
     ORDER BY h.revision DESC
     LIMIT 1;

    IF FOUND THEN
        v_previous_revision := v_latest.revision;
        IF v_projection.context_id IS NULL
           OR v_projection.revision IS DISTINCT FROM v_latest.revision
           OR v_projection.payload_hash IS DISTINCT FROM v_latest.payload_hash
           OR v_projection.state IS DISTINCT FROM v_latest.state THEN
            RAISE EXCEPTION USING ERRCODE = '40001', MESSAGE = 'governed_context_projection_history_mismatch';
        END IF;
        IF v_projection.state IN ('revoked', 'superseded') AND p_state = 'active' THEN
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'governed_context_reactivation_forbidden';
        END IF;
    ELSIF v_projection.context_id IS NOT NULL THEN
        RAISE EXCEPTION USING ERRCODE = '40001', MESSAGE = 'governed_context_history_missing';
    END IF;

    IF p_expected_revision <> v_previous_revision THEN
        RAISE EXCEPTION USING ERRCODE = '40001', MESSAGE = 'governed_context_stale_revision';
    END IF;

    v_new_revision := v_previous_revision + 1;
    v_payload := jsonb_build_object(
        'context_id', p_context_id,
        'dossier_id', p_dossier_id,
        'rule_set_id', p_rule_set_id,
        'subject_id', p_subject_id,
        'territory', p_territory,
        'state', p_state,
        'revoked_at', p_revoked_at,
        'revision', v_new_revision,
        'previous_revision', CASE WHEN v_previous_revision = 0 THEN NULL ELSE v_previous_revision END,
        'actor_id', p_actor_id,
        'device_id', p_device_id,
        'audit_id', p_audit_id::text,
        'operation', p_operation
    );
    v_payload_hash := encode(digest(convert_to(v_payload::text, 'UTF8'), 'sha256'), 'hex');

    PERFORM set_config('mb12.context_history_writer', p_audit_id::text, true);
    INSERT INTO public.mb12_p0_governed_context_history (
        owner_user_id, context_id, dossier_id, rule_set_id, subject_id, territory,
        state, revoked_at, revision, previous_revision, payload_hash,
        actor_id, device_id, audit_id, operation, created_at
    ) VALUES (
        v_owner, p_context_id, p_dossier_id, p_rule_set_id, p_subject_id, p_territory,
        p_state, p_revoked_at, v_new_revision,
        CASE WHEN v_previous_revision = 0 THEN NULL ELSE v_previous_revision END,
        v_payload_hash, p_actor_id, p_device_id, p_audit_id::text, p_operation, NOW()
    );
    PERFORM set_config('mb12.context_history_writer', '', true);

    INSERT INTO public.mb12_p0_governed_context (
        owner_user_id, context_id, dossier_id, rule_set_id, subject_id, territory,
        state, revoked_at, revision, actor_id, device_id, audit_id, operation,
        payload_hash, created_at, updated_at
    ) VALUES (
        v_owner, p_context_id, p_dossier_id, p_rule_set_id, p_subject_id, p_territory,
        p_state, p_revoked_at, v_new_revision, p_actor_id, p_device_id,
        p_audit_id::text, p_operation, v_payload_hash, NOW(), NOW()
    )
    ON CONFLICT (owner_user_id, context_id) DO UPDATE SET
        dossier_id = EXCLUDED.dossier_id,
        rule_set_id = EXCLUDED.rule_set_id,
        subject_id = EXCLUDED.subject_id,
        territory = EXCLUDED.territory,
        state = EXCLUDED.state,
        revoked_at = EXCLUDED.revoked_at,
        revision = EXCLUDED.revision,
        actor_id = EXCLUDED.actor_id,
        device_id = EXCLUDED.device_id,
        audit_id = EXCLUDED.audit_id,
        operation = EXCLUDED.operation,
        payload_hash = EXCLUDED.payload_hash,
        updated_at = NOW();

    RETURN v_new_revision;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb12_p0_upsert_governed_context(
    TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TIMESTAMPTZ, INTEGER, TEXT, TEXT, UUID, TEXT
) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p0_upsert_governed_context(
    TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TIMESTAMPTZ, INTEGER, TEXT, TEXT, UUID, TEXT
) TO mb12_p0_app;

REVOKE INSERT, UPDATE, DELETE ON public.mb12_p0_governed_context FROM PUBLIC;
REVOKE INSERT, UPDATE, DELETE ON public.mb12_p0_governed_context FROM mb12_p0_app;
GRANT SELECT ON public.mb12_p0_governed_context TO mb12_p0_app;

ALTER TABLE public.mb12_p0_source_card_binding FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p0_trusted_data_value FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p0_governed_context FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p0_governed_context_history FORCE ROW LEVEL SECURITY;

COMMIT;
