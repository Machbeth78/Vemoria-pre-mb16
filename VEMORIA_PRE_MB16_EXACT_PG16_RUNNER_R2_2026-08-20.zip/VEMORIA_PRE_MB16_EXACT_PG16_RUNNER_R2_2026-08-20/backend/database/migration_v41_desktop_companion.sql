-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V41 — Desktop Companion / PC Companion
-- Phone-first, desktop-companion

CREATE TABLE IF NOT EXISTS desktop_pairing_requests (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID REFERENCES utenti(id) ON DELETE CASCADE,
    pairing_code        TEXT NOT NULL UNIQUE,
    device_name         TEXT NOT NULL,
    device_type         TEXT NOT NULL DEFAULT 'desktop',
    os_name             TEXT,
    app_version         TEXT,
    public_key          TEXT,
    session_token       TEXT,
    requested_ip        TEXT,
    local_capabilities  JSONB,
    status              TEXT NOT NULL DEFAULT 'pending',
    requested_at        TIMESTAMP NOT NULL DEFAULT NOW(),
    confirmed_at        TIMESTAMP,
    expires_at          TIMESTAMP NOT NULL,
    revoked_at          TIMESTAMP,
    meta                JSONB
);

CREATE INDEX IF NOT EXISTS idx_desktop_pair_req_status    ON desktop_pairing_requests(status);
CREATE INDEX IF NOT EXISTS idx_desktop_pair_req_expires   ON desktop_pairing_requests(expires_at);
CREATE INDEX IF NOT EXISTS idx_desktop_pair_req_user      ON desktop_pairing_requests(utente_id);

CREATE TABLE IF NOT EXISTS desktop_devices (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    pairing_request_id  UUID REFERENCES desktop_pairing_requests(id) ON DELETE SET NULL,
    device_name         TEXT NOT NULL,
    device_type         TEXT NOT NULL DEFAULT 'desktop',
    os_name             TEXT,
    app_version         TEXT,
    public_key          TEXT,
    trust_status        TEXT NOT NULL DEFAULT 'active',
    local_capabilities  JSONB,
    meta                JSONB,
    paired_at           TIMESTAMP NOT NULL DEFAULT NOW(),
    last_seen_at        TIMESTAMP,
    revoked_at          TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_desktop_devices_user       ON desktop_devices(utente_id);
CREATE INDEX IF NOT EXISTS idx_desktop_devices_status     ON desktop_devices(trust_status);
CREATE INDEX IF NOT EXISTS idx_desktop_devices_last_seen  ON desktop_devices(last_seen_at DESC);

CREATE TABLE IF NOT EXISTS desktop_import_queue (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id               UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    source_device_id        UUID REFERENCES desktop_devices(id) ON DELETE SET NULL,
    filename                TEXT NOT NULL,
    mime_type               TEXT,
    size_bytes              BIGINT,
    temp_hash               TEXT,
    state                   TEXT NOT NULL DEFAULT 'pending',
    classification_status   TEXT NOT NULL DEFAULT 'pending',
    assigned_category       TEXT,
    assigned_dossier_id     UUID REFERENCES dossier(id) ON DELETE SET NULL,
    notes                   TEXT,
    payload                 JSONB,
    final_document_id       UUID REFERENCES documenti(id) ON DELETE SET NULL,
    received_at             TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_desktop_import_user        ON desktop_import_queue(utente_id);
CREATE INDEX IF NOT EXISTS idx_desktop_import_state       ON desktop_import_queue(state);
CREATE INDEX IF NOT EXISTS idx_desktop_import_received    ON desktop_import_queue(received_at DESC);

CREATE TABLE IF NOT EXISTS desktop_transfer_log (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    source_device_id    UUID REFERENCES desktop_devices(id) ON DELETE SET NULL,
    target_device_id    UUID REFERENCES desktop_devices(id) ON DELETE SET NULL,
    document_id         UUID REFERENCES documenti(id) ON DELETE SET NULL,
    direction           TEXT NOT NULL,
    method              TEXT NOT NULL DEFAULT 'metadata_only',
    status              TEXT NOT NULL DEFAULT 'queued',
    transfer_hash       TEXT,
    details             JSONB,
    started_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    completed_at        TIMESTAMP,
    expires_at          TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_desktop_transfer_user      ON desktop_transfer_log(utente_id);
CREATE INDEX IF NOT EXISTS idx_desktop_transfer_doc       ON desktop_transfer_log(document_id);
CREATE INDEX IF NOT EXISTS idx_desktop_transfer_status    ON desktop_transfer_log(status);
CREATE INDEX IF NOT EXISTS idx_desktop_transfer_started   ON desktop_transfer_log(started_at DESC);

CREATE TABLE IF NOT EXISTS desktop_document_pins (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id           UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    desktop_device_id   UUID NOT NULL REFERENCES desktop_devices(id) ON DELETE CASCADE,
    document_id         UUID NOT NULL REFERENCES documenti(id) ON DELETE CASCADE,
    local_available     BOOLEAN NOT NULL DEFAULT FALSE,
    offline_pinned      BOOLEAN NOT NULL DEFAULT FALSE,
    requested_at        TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    last_opened_at      TIMESTAMP,
    CONSTRAINT uq_desktop_pin UNIQUE (desktop_device_id, document_id)
);

CREATE INDEX IF NOT EXISTS idx_desktop_pins_user          ON desktop_document_pins(utente_id);
CREATE INDEX IF NOT EXISTS idx_desktop_pins_device        ON desktop_document_pins(desktop_device_id);
CREATE INDEX IF NOT EXISTS idx_desktop_pins_document      ON desktop_document_pins(document_id);
