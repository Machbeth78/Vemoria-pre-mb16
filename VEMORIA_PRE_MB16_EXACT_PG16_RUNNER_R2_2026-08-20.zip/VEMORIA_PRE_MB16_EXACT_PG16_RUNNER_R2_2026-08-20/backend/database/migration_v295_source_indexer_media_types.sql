-- Vemoria PRE-MB16 Pass 8AK
-- Extend the existing Source Indexer source_type truth to first-class local
-- audio/video imports. This does not grant microphone/gallery access; bytes
-- still arrive only through an already authorized/manual source path.

ALTER TABLE source_indexed_items
    DROP CONSTRAINT IF EXISTS source_indexed_items_source_type_check;

ALTER TABLE source_indexed_items
    ADD CONSTRAINT source_indexed_items_source_type_check
    CHECK (source_type IN (
        'image',
        'pdf',
        'audio',
        'video',
        'generic_document',
        'generic_file',
        'exported_chat_text',
        'screenshot',
        'email_forwarded',
        'attachment',
        'manual_import'
    ));
