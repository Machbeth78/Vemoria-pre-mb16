-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- MB12-P3 R1 — explicit owner decision profile and constraint applicability.
-- No hidden inference, scoring, ranking, recommendation, winner or sponsored priority.

BEGIN;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb12_p3_app') THEN
        CREATE ROLE mb12_p3_app NOLOGIN;
    END IF;
END
$$;

CREATE TABLE IF NOT EXISTS public.mb12_p3_owner_decision_profile (
    owner_user_id      UUID NOT NULL,
    profile_id         UUID NOT NULL,
    stable_id          TEXT NOT NULL,
    title              TEXT NOT NULL,
    current_revision   INTEGER NOT NULL DEFAULT 1,
    state              TEXT NOT NULL,
    payload_hash       TEXT NOT NULL,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, profile_id),
    UNIQUE (owner_user_id, stable_id),
    CONSTRAINT ck_mb12_p3_stable_id_nonempty CHECK (length(trim(stable_id)) > 0),
    CONSTRAINT ck_mb12_p3_title_nonempty CHECK (length(trim(title)) > 0),
    CONSTRAINT ck_mb12_p3_state CHECK (state IN ('ready','incomplete','incompatible','revoked')),
    CONSTRAINT ck_mb12_p3_revision_positive CHECK (current_revision >= 1)
);

CREATE TABLE IF NOT EXISTS public.mb12_p3_owner_decision_profile_revision (
    owner_user_id      UUID NOT NULL,
    profile_id         UUID NOT NULL,
    revision           INTEGER NOT NULL,
    state              TEXT NOT NULL,
    payload_hash       TEXT NOT NULL,
    assessment_ref     JSONB NOT NULL,
    request_payload    JSONB NOT NULL,
    result_payload     JSONB NOT NULL,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, profile_id, revision),
    CONSTRAINT fk_mb12_p3_revision_profile
        FOREIGN KEY (owner_user_id, profile_id)
        REFERENCES public.mb12_p3_owner_decision_profile(owner_user_id, profile_id)
        ON DELETE RESTRICT,
    CONSTRAINT ck_mb12_p3_revision_state CHECK (state IN ('ready','incomplete','incompatible','revoked')),
    CONSTRAINT ck_mb12_p3_revision_positive_2 CHECK (revision >= 1),
    CONSTRAINT ck_mb12_p3_assessment_ref_object CHECK (jsonb_typeof(assessment_ref) = 'object'),
    CONSTRAINT ck_mb12_p3_request_object CHECK (jsonb_typeof(request_payload) = 'object'),
    CONSTRAINT ck_mb12_p3_result_object CHECK (jsonb_typeof(result_payload) = 'object')
);

CREATE TABLE IF NOT EXISTS public.mb12_p3_decision_criterion (
    owner_user_id      UUID NOT NULL,
    profile_id         UUID NOT NULL,
    revision           INTEGER NOT NULL,
    criterion_id       TEXT NOT NULL,
    criterion_mode     TEXT NOT NULL,
    dimension          TEXT NOT NULL,
    criterion_payload  JSONB NOT NULL,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, profile_id, revision, criterion_id),
    CONSTRAINT fk_mb12_p3_criterion_revision
        FOREIGN KEY (owner_user_id, profile_id, revision)
        REFERENCES public.mb12_p3_owner_decision_profile_revision(owner_user_id, profile_id, revision)
        ON DELETE RESTRICT,
    CONSTRAINT ck_mb12_p3_criterion_mode CHECK (criterion_mode IN ('hard_constraint','preference')),
    CONSTRAINT ck_mb12_p3_criterion_id_nonempty CHECK (length(trim(criterion_id)) > 0),
    CONSTRAINT ck_mb12_p3_dimension_nonempty CHECK (length(trim(dimension)) > 0),
    CONSTRAINT ck_mb12_p3_criterion_payload_object CHECK (jsonb_typeof(criterion_payload) = 'object')
);

CREATE INDEX IF NOT EXISTS ix_mb12_p3_profile_owner_state
    ON public.mb12_p3_owner_decision_profile(owner_user_id, state, updated_at DESC);
CREATE INDEX IF NOT EXISTS ix_mb12_p3_revision_owner_profile
    ON public.mb12_p3_owner_decision_profile_revision(owner_user_id, profile_id, revision DESC);
CREATE INDEX IF NOT EXISTS ix_mb12_p3_criterion_owner_dimension
    ON public.mb12_p3_decision_criterion(owner_user_id, dimension, criterion_mode);

ALTER TABLE public.mb12_p3_owner_decision_profile ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p3_owner_decision_profile FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p3_owner_decision_profile_revision ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p3_owner_decision_profile_revision FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p3_decision_criterion ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb12_p3_decision_criterion FORCE ROW LEVEL SECURITY;

DO $$
DECLARE
    table_name TEXT;
BEGIN
    FOREACH table_name IN ARRAY ARRAY[
        'mb12_p3_owner_decision_profile',
        'mb12_p3_owner_decision_profile_revision',
        'mb12_p3_decision_criterion'
    ] LOOP
        EXECUTE format('DROP POLICY IF EXISTS mb12_p3_owner_isolation ON public.%I', table_name);
        EXECUTE format(
            'CREATE POLICY mb12_p3_owner_isolation ON public.%I '
            'USING (owner_user_id = NULLIF(current_setting(''app.owner_id'', true), '''')::uuid) '
            'WITH CHECK (owner_user_id = NULLIF(current_setting(''app.owner_id'', true), '''')::uuid)',
            table_name
        );
    END LOOP;
END
$$;

CREATE OR REPLACE FUNCTION public.mb12_p3_history_immutable()
RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb12_p3_history_is_append_only';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb12_p3_history_immutable() FROM PUBLIC;

DROP TRIGGER IF EXISTS trg_mb12_p3_revision_immutable ON public.mb12_p3_owner_decision_profile_revision;
CREATE TRIGGER trg_mb12_p3_revision_immutable
BEFORE UPDATE OR DELETE ON public.mb12_p3_owner_decision_profile_revision
FOR EACH ROW EXECUTE FUNCTION public.mb12_p3_history_immutable();

DROP TRIGGER IF EXISTS trg_mb12_p3_criterion_immutable ON public.mb12_p3_decision_criterion;
CREATE TRIGGER trg_mb12_p3_criterion_immutable
BEFORE UPDATE OR DELETE ON public.mb12_p3_decision_criterion
FOR EACH ROW EXECUTE FUNCTION public.mb12_p3_history_immutable();

CREATE OR REPLACE FUNCTION public.mb12_p3_write_decision_profile(
    p_profile_id UUID,
    p_stable_id TEXT,
    p_title TEXT,
    p_state TEXT,
    p_assessment_ref JSONB,
    p_request_payload JSONB,
    p_result_payload JSONB,
    p_criteria JSONB
) RETURNS TABLE(profile_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb12_p3_owner_decision_profile%ROWTYPE;
    v_assessment_revision public.mb12_p2_comparability_revision%ROWTYPE;
    v_dossier_revision public.mb12_p1_offer_contract_revision%ROWTYPE;
    v_revision INTEGER;
    v_payload_hash TEXT;
    v_criterion JSONB;
    v_ref JSONB;
    v_source_ref JSONB;
    v_criterion_count INTEGER;
    v_distinct_count INTEGER;
    v_preference_count INTEGER := 0;
    v_preference_weight INTEGER := 0;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p3_authenticated_owner_missing';
    END IF;
    IF p_profile_id IS NULL
       OR length(trim(COALESCE(p_stable_id, ''))) = 0 OR length(p_stable_id) > 200
       OR length(trim(COALESCE(p_title, ''))) = 0 OR length(p_title) > 300 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p3_identity_invalid';
    END IF;
    IF p_state NOT IN ('ready','incomplete','incompatible','revoked') THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p3_state_invalid';
    END IF;
    IF jsonb_typeof(p_assessment_ref) <> 'object'
       OR jsonb_typeof(p_request_payload) <> 'object'
       OR jsonb_typeof(p_result_payload) <> 'object'
       OR jsonb_typeof(p_criteria) <> 'array'
       OR jsonb_array_length(p_criteria) < 1
       OR jsonb_array_length(p_criteria) > 50
       OR jsonb_typeof(p_result_payload->'items') <> 'array' THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p3_payload_shape_invalid';
    END IF;

    IF p_result_payload->'score' IS DISTINCT FROM 'null'::jsonb
       OR p_result_payload->'ranking' IS DISTINCT FROM 'null'::jsonb
       OR p_result_payload->'recommendation' IS DISTINCT FROM 'null'::jsonb
       OR p_result_payload->'winner' IS DISTINCT FROM 'null'::jsonb
       OR COALESCE((p_result_payload->>'no_auto_decision')::boolean, FALSE) IS NOT TRUE
       OR COALESCE((p_result_payload->>'sponsored_ranking')::boolean, TRUE) IS NOT FALSE
       OR p_result_payload->>'engine_version' IS DISTINCT FROM 'mb12-p3-r1' THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p3_neutrality_invariant_invalid';
    END IF;
    IF p_request_payload ?| ARRAY[
        'score','ranking','recommendation','winner','sponsor','paid_placement',
        'commercial_priority','inferred_profile','confidence','source_refs'
       ]
       OR p_result_payload ?| ARRAY['utility_score','normalized_score','paid_placement'] THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p3_forbidden_decision_field';
    END IF;
    IF p_result_payload->'assessment_ref' IS DISTINCT FROM p_assessment_ref
       OR p_result_payload->'criteria' IS DISTINCT FROM p_criteria THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p3_result_binding_invalid';
    END IF;

    SELECT count(*), count(DISTINCT value->>'criterion_id')
      INTO v_criterion_count, v_distinct_count
      FROM jsonb_array_elements(p_criteria);
    IF v_criterion_count <> v_distinct_count THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p3_criterion_id_duplicate';
    END IF;

    FOR v_criterion IN SELECT value FROM jsonb_array_elements(p_criteria) LOOP
        IF length(trim(COALESCE(v_criterion->>'criterion_id', ''))) = 0
           OR length(v_criterion->>'criterion_id') > 100
           OR length(trim(COALESCE(v_criterion->>'dimension', ''))) = 0
           OR length(v_criterion->>'dimension') > 100
           OR COALESCE(v_criterion->>'source', '') <> 'explicit_owner'
           OR lower(v_criterion->>'dimension') = ANY(ARRAY[
                'score','ranking','recommendation','winner','sponsor','paid_placement','commercial_priority'
           ]) THEN
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p3_criterion_identity_invalid';
        END IF;
        IF v_criterion->>'mode' = 'hard_constraint' THEN
            IF NOT (v_criterion->>'operator' = ANY(ARRAY['eq','neq','lte','gte','in','not_in','exists']))
               OR COALESCE(v_criterion->>'weight', '') <> '' THEN
                RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p3_hard_constraint_invalid';
            END IF;
        ELSIF v_criterion->>'mode' = 'preference' THEN
            IF NOT (v_criterion->>'operator' = ANY(ARRAY['minimize','maximize','target']))
               OR COALESCE(v_criterion->>'weight', '') = ''
               OR (v_criterion->>'weight')::integer < 1
               OR (v_criterion->>'weight')::integer > 100 THEN
                RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p3_preference_invalid';
            END IF;
            v_preference_count := v_preference_count + 1;
            v_preference_weight := v_preference_weight + (v_criterion->>'weight')::integer;
        ELSE
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p3_criterion_mode_invalid';
        END IF;
    END LOOP;
    IF v_preference_count > 0 AND v_preference_weight <> 100 THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p3_preference_weights_must_total_100';
    END IF;

    SELECT r.* INTO v_assessment_revision
      FROM public.mb12_p2_comparability_assessment a
      JOIN public.mb12_p2_comparability_revision r
        ON r.owner_user_id = a.owner_user_id
       AND r.comparison_id = a.comparison_id
       AND r.revision = a.current_revision
     WHERE a.owner_user_id = v_owner
       AND a.comparison_id = NULLIF(p_assessment_ref->>'assessment_id', '')::uuid
       AND a.current_revision = NULLIF(p_assessment_ref->>'revision', '')::integer
       AND a.payload_hash = p_assessment_ref->>'payload_hash'
       AND a.state = 'comparable'
       AND r.state = 'comparable';
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p3_current_comparable_p2_assessment_required';
    END IF;

    FOR v_ref IN SELECT value FROM jsonb_array_elements(v_assessment_revision.dossier_refs) LOOP
        SELECT r.* INTO v_dossier_revision
          FROM public.mb12_p1_offer_contract d
          JOIN public.mb12_p1_offer_contract_revision r
            ON r.owner_user_id = d.owner_user_id
           AND r.dossier_id = d.dossier_id
           AND r.revision = d.current_revision
         WHERE d.owner_user_id = v_owner
           AND d.dossier_id = NULLIF(v_ref->>'dossier_id', '')::uuid
           AND d.current_revision = NULLIF(v_ref->>'revision', '')::integer
           AND d.payload_hash = v_ref->>'payload_hash'
           AND d.state <> 'revoked';
        IF NOT FOUND THEN
            RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p3_current_p1_revision_required';
        END IF;

        FOR v_source_ref IN SELECT value FROM jsonb_array_elements(v_dossier_revision.source_refs) LOOP
            IF NOT EXISTS (
                SELECT 1
                  FROM public.mb12_p0_source_card_binding b
                  JOIN public.mb12_p0_trusted_data_value t
                    ON t.owner_user_id = b.owner_user_id
                   AND t.source_id = b.source_id
                   AND t.source_revision_id = b.source_revision_id
                   AND t.evidence_id = b.evidence_id
                   AND t.content_hash = b.content_hash
                   AND t.grant_id IS NOT DISTINCT FROM b.grant_id
                  JOIN public.canonical_source_card_authority a
                    ON a.owner_user_id = b.owner_user_id
                   AND a.source_card_id = b.source_card_id
                  JOIN public.authorized_memory_sources s
                    ON s.id = b.source_id AND s.user_id = b.owner_user_id
                  JOIN public.authorized_memory_inventory_items i
                    ON i.id = b.source_revision_id
                   AND i.user_id = b.owner_user_id
                   AND i.source_id = b.source_id
                  JOIN public.authorized_memory_activity_log l
                    ON l.id = b.evidence_id
                   AND l.user_id = b.owner_user_id
                   AND l.source_id = b.source_id
                  LEFT JOIN public.authorized_memory_consent_grants g
                    ON g.id = b.grant_id
                   AND g.user_id = b.owner_user_id
                   AND g.source_id = b.source_id
                 WHERE b.owner_user_id = v_owner
                   AND b.source_card_id = v_source_ref->>'source_card_id'
                   AND b.source_id = NULLIF(v_source_ref->>'source_id', '')::uuid
                   AND b.source_revision_id = NULLIF(v_source_ref->>'source_revision_id', '')::uuid
                   AND b.evidence_id = NULLIF(v_source_ref->>'evidence_id', '')::uuid
                   AND b.content_hash = v_source_ref->>'content_hash'
                   AND b.grant_id IS NOT DISTINCT FROM NULLIF(v_source_ref->>'grant_id', '')::uuid
                   AND b.scope = v_source_ref->>'scope'
                   AND b.status = 'active'
                   AND b.revoked_at IS NULL
                   AND a.status = 'active'
                   AND a.source_state = 'active'
                   AND COALESCE(a.revocation_state, '') <> 'revoked'
                   AND s.status = 'active'
                   AND s.revoked_at IS NULL
                   AND i.deleted_at IS NULL
                   AND i.memory_state <> 'revoked'
                   AND l.id = t.evidence_id
                   AND t.field_name = v_source_ref->>'field_name'
                   AND t.normalized_value = v_source_ref->>'trusted_value'
                   AND (
                        b.grant_id IS NULL
                        OR (
                            g.status = 'active'
                            AND g.revoked_at IS NULL
                            AND (g.expires_at IS NULL OR g.expires_at > NOW())
                        )
                   )
            ) THEN
                RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'mb12_p3_live_p0_provenance_required';
            END IF;
        END LOOP;
    END LOOP;

    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_stable_id, 0));
    v_payload_hash := encode(
        digest(convert_to((p_request_payload || jsonb_build_object('result', p_result_payload))::text, 'UTF8'), 'sha256'),
        'hex'
    );

    SELECT * INTO v_current
      FROM public.mb12_p3_owner_decision_profile p
     WHERE p.owner_user_id = v_owner
       AND p.stable_id = p_stable_id
     FOR UPDATE;

    IF FOUND THEN
        IF v_current.payload_hash = v_payload_hash AND v_current.state = p_state THEN
            RETURN QUERY SELECT v_current.profile_id, v_current.current_revision, v_current.payload_hash;
            RETURN;
        END IF;
        IF v_current.state = 'revoked' AND p_state <> 'revoked' THEN
            RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb12_p3_revoked_profile_cannot_reactivate';
        END IF;
        p_profile_id := v_current.profile_id;
        v_revision := v_current.current_revision + 1;
    ELSE
        v_revision := 1;
        INSERT INTO public.mb12_p3_owner_decision_profile (
            owner_user_id, profile_id, stable_id, title, current_revision, state, payload_hash
        ) VALUES (
            v_owner, p_profile_id, p_stable_id, p_title, v_revision, p_state, v_payload_hash
        );
    END IF;

    INSERT INTO public.mb12_p3_owner_decision_profile_revision (
        owner_user_id, profile_id, revision, state, payload_hash,
        assessment_ref, request_payload, result_payload
    ) VALUES (
        v_owner, p_profile_id, v_revision, p_state, v_payload_hash,
        p_assessment_ref, p_request_payload, p_result_payload
    );

    FOR v_criterion IN SELECT value FROM jsonb_array_elements(p_criteria) LOOP
        INSERT INTO public.mb12_p3_decision_criterion (
            owner_user_id, profile_id, revision, criterion_id,
            criterion_mode, dimension, criterion_payload
        ) VALUES (
            v_owner, p_profile_id, v_revision,
            v_criterion->>'criterion_id', v_criterion->>'mode',
            v_criterion->>'dimension', v_criterion
        );
    END LOOP;

    UPDATE public.mb12_p3_owner_decision_profile AS p
       SET title = p_title,
           current_revision = v_revision,
           state = p_state,
           payload_hash = v_payload_hash,
           updated_at = NOW()
     WHERE p.owner_user_id = v_owner
       AND p.profile_id = p_profile_id;

    RETURN QUERY SELECT p_profile_id, v_revision, v_payload_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

CREATE OR REPLACE FUNCTION public.mb12_p3_revoke_decision_profile(
    p_profile_id UUID,
    p_reason TEXT
) RETURNS TABLE(profile_id UUID, revision INTEGER, payload_hash TEXT) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_current public.mb12_p3_owner_decision_profile%ROWTYPE;
    v_previous public.mb12_p3_owner_decision_profile_revision%ROWTYPE;
    v_revision INTEGER;
    v_result JSONB;
    v_hash TEXT;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p3_authenticated_owner_missing';
    END IF;
    IF p_profile_id IS NULL OR length(trim(COALESCE(p_reason, ''))) = 0 OR length(p_reason) > 500 THEN
        RAISE EXCEPTION USING ERRCODE = '22023', MESSAGE = 'mb12_p3_revocation_invalid';
    END IF;

    SELECT * INTO v_current
      FROM public.mb12_p3_owner_decision_profile p
     WHERE p.owner_user_id = v_owner
       AND p.profile_id = p_profile_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = 'P0002', MESSAGE = 'mb12_p3_profile_not_found';
    END IF;
    IF v_current.state = 'revoked' THEN
        RETURN QUERY SELECT v_current.profile_id, v_current.current_revision, v_current.payload_hash;
        RETURN;
    END IF;

    SELECT * INTO v_previous
      FROM public.mb12_p3_owner_decision_profile_revision r
     WHERE r.owner_user_id = v_owner
       AND r.profile_id = p_profile_id
       AND r.revision = v_current.current_revision;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING ERRCODE = '55000', MESSAGE = 'mb12_p3_current_revision_missing';
    END IF;

    v_revision := v_current.current_revision + 1;
    v_result := v_previous.result_payload || jsonb_build_object(
        'state', 'revoked',
        'revocation_reason', trim(p_reason),
        'revoked_from_revision', v_current.current_revision
    );
    v_hash := encode(
        digest(convert_to((v_previous.request_payload || jsonb_build_object('result', v_result))::text, 'UTF8'), 'sha256'),
        'hex'
    );

    INSERT INTO public.mb12_p3_owner_decision_profile_revision (
        owner_user_id, profile_id, revision, state, payload_hash,
        assessment_ref, request_payload, result_payload
    ) VALUES (
        v_owner, p_profile_id, v_revision, 'revoked', v_hash,
        v_previous.assessment_ref, v_previous.request_payload, v_result
    );

    INSERT INTO public.mb12_p3_decision_criterion (
        owner_user_id, profile_id, revision, criterion_id,
        criterion_mode, dimension, criterion_payload
    )
    SELECT c.owner_user_id, c.profile_id, v_revision, c.criterion_id,
           c.criterion_mode, c.dimension, c.criterion_payload
      FROM public.mb12_p3_decision_criterion c
     WHERE c.owner_user_id = v_owner
       AND c.profile_id = p_profile_id
       AND c.revision = v_current.current_revision;

    UPDATE public.mb12_p3_owner_decision_profile AS p
       SET current_revision = v_revision,
           state = 'revoked',
           payload_hash = v_hash,
           updated_at = NOW()
     WHERE p.owner_user_id = v_owner
       AND p.profile_id = p_profile_id;

    RETURN QUERY SELECT p_profile_id, v_revision, v_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb12_p3_write_decision_profile(UUID,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb12_p3_revoke_decision_profile(UUID,TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p3_write_decision_profile(UUID,TEXT,TEXT,TEXT,JSONB,JSONB,JSONB,JSONB) TO mb12_p3_app;
GRANT EXECUTE ON FUNCTION public.mb12_p3_revoke_decision_profile(UUID,TEXT) TO mb12_p3_app;

REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER
    ON public.mb12_p3_owner_decision_profile,
       public.mb12_p3_owner_decision_profile_revision,
       public.mb12_p3_decision_criterion
    FROM PUBLIC, mb12_p3_app;
GRANT SELECT
    ON public.mb12_p3_owner_decision_profile,
       public.mb12_p3_owner_decision_profile_revision,
       public.mb12_p3_decision_criterion
    TO mb12_p3_app;

COMMIT;
