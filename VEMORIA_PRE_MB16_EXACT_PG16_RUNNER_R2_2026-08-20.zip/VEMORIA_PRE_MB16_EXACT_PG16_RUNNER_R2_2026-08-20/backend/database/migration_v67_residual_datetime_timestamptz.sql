-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V67 — Residual datetime columns alignment to TIMESTAMPTZ
-- Chiude il drift rilevato nell'audit V57 su colonne sopravvissute come TIMESTAMP naive
-- dopo la foundation V52/V66. Sicura su DB già migrati (IF EXISTS + USING).

-- memorie.data_documento — campo opzionale per data del documento (usato da ORM V2)
ALTER TABLE IF EXISTS memorie
    ALTER COLUMN data_documento TYPE TIMESTAMPTZ
    USING (data_documento AT TIME ZONE 'UTC');

-- memorie.confermata_il — timestamp di conferma memoria
ALTER TABLE IF EXISTS memorie
    ALTER COLUMN confermata_il TYPE TIMESTAMPTZ
    USING (confermata_il AT TIME ZONE 'UTC');

-- eventi_invio.data_scadenza — scadenza accesso 72h
ALTER TABLE IF EXISTS eventi_invio
    ALTER COLUMN data_scadenza TYPE TIMESTAMPTZ
    USING (data_scadenza AT TIME ZONE 'UTC');
