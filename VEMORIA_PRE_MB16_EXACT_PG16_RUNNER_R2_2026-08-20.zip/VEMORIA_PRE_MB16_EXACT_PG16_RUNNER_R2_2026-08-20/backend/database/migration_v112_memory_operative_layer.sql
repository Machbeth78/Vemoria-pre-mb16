-- ============================================================================
-- VEMORA — Migration v112 — Memory Operative Layer Backend A
-- ============================================================================
-- Data:      2026-05-22
-- Autore:    OPUS Memory Operative Backend A pack
-- Scopo:     Tabelle additive per Practice Workspace, Manifest, Inbox,
--            Checklist, Match, Client Requests, Precheck, Project↔Stato,
--            Contextual Exceptions, Source Routing, Operative Profile.
--
-- VINCOLI HARD:
-- - Migrazione ADDITIVA. NESSUN ALTER su tabelle preesistenti.
-- - NESSUN DROP. NESSUN UPDATE su invarianti legali append-only
--   (eventi_invio, timeline_eventi, evidence_hash_chain_events) — qui non
--   sono nemmeno toccati.
-- - Idempotente: CREATE TABLE IF NOT EXISTS, CREATE INDEX IF NOT EXISTS.
-- - Compatibile con backend Vemoria esistente (PostgreSQL, gen_random_uuid()).
-- - Tutte le tabelle hanno proprietario_id UUID per ownership enforcement
--   a livello applicativo (FK soft verso utenti, gestita dal codice).
-- ============================================================================

BEGIN;

-- ============================================================================
-- 1. operative_profiles  (spec 03 — Onboarding Profilazione Operativa)
-- ============================================================================
CREATE TABLE IF NOT EXISTS operative_profiles (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    proprietario_id         UUID NOT NULL UNIQUE,
    preferred_language      TEXT NOT NULL DEFAULT 'it',
    country_code            TEXT NOT NULL DEFAULT 'IT',
    user_type               TEXT,
    profession_code         TEXT,
    work_use                TEXT,
    other_languages         JSONB NOT NULL DEFAULT '[]'::JSONB,
    linked_devices          JSONB NOT NULL DEFAULT '[]'::JSONB,
    initial_permissions     JSONB NOT NULL DEFAULT '{}'::JSONB,
    suggested_packages      JSONB NOT NULL DEFAULT '[]'::JSONB,
    setup_completed         BOOLEAN NOT NULL DEFAULT FALSE,
    comune_principale       TEXT,
    practice_types_active   JSONB NOT NULL DEFAULT '[]'::JSONB,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_operative_profiles_owner
    ON operative_profiles (proprietario_id);


-- ============================================================================
-- 2. practice_workspaces  (spec 05 — Fascicolo Vivo)
-- ============================================================================
CREATE TABLE IF NOT EXISTS practice_workspaces (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    proprietario_id         UUID NOT NULL,
    dossier_id              UUID,                       -- opzionale: link dossier esistente
    titolo                  TEXT NOT NULL,
    state                   TEXT NOT NULL DEFAULT 'active',
    practice_kind           TEXT,
    cliente_ref             JSONB NOT NULL DEFAULT '{}'::JSONB,
    country_code            TEXT NOT NULL DEFAULT 'IT',
    region_code             TEXT,
    comune_code             TEXT,
    address                 TEXT,
    object_description      TEXT,
    authority_ref           JSONB NOT NULL DEFAULT '{}'::JSONB,
    exceptions_memory       JSONB NOT NULL DEFAULT '[]'::JSONB,
    summary_cache           JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_activity_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    paused_at               TIMESTAMPTZ,
    reopened_at             TIMESTAMPTZ,
    closed_at               TIMESTAMPTZ,
    archived_at             TIMESTAMPTZ,
    CONSTRAINT chk_workspace_state CHECK (
        state IN ('active','paused','waiting_client','waiting_authority','closed','archived')
    )
);

CREATE INDEX IF NOT EXISTS idx_workspaces_owner_state
    ON practice_workspaces (proprietario_id, state);
CREATE INDEX IF NOT EXISTS idx_workspaces_last_activity
    ON practice_workspaces (proprietario_id, last_activity_at DESC);


-- ============================================================================
-- 3. practice_manifest_items  (spec 06 — Manifest)
-- ============================================================================
CREATE TABLE IF NOT EXISTS practice_manifest_items (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id            UUID NOT NULL REFERENCES practice_workspaces(id) ON DELETE CASCADE,
    proprietario_id         UUID NOT NULL,
    role_code               TEXT NOT NULL,
    role_label              TEXT NOT NULL,
    state                   TEXT NOT NULL DEFAULT 'missing',
    required                BOOLEAN NOT NULL DEFAULT TRUE,
    versioning_chain        UUID NOT NULL DEFAULT gen_random_uuid(),
    version_index           INTEGER NOT NULL DEFAULT 1,
    file_source             TEXT,                       -- 'documento'|'memoria'|'source_indexed_items'
    file_source_id          UUID,
    file_content_hash       TEXT,
    file_filename           TEXT,
    sensitivity_level       TEXT,
    ordine                  INTEGER NOT NULL DEFAULT 0,
    note                    TEXT,
    timeline_event_id       UUID,                       -- soft link
    candidate_count         INTEGER NOT NULL DEFAULT 0,
    last_changed_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_manifest_state CHECK (
        state IN ('present','missing','doubtful','outdated','to_produce','to_confirm','replaced','excluded')
    )
);

CREATE INDEX IF NOT EXISTS idx_manifest_workspace
    ON practice_manifest_items (workspace_id);
CREATE INDEX IF NOT EXISTS idx_manifest_owner
    ON practice_manifest_items (proprietario_id);
CREATE INDEX IF NOT EXISTS idx_manifest_versioning_chain
    ON practice_manifest_items (versioning_chain);
CREATE INDEX IF NOT EXISTS idx_manifest_file_ref
    ON practice_manifest_items (file_source, file_source_id)
    WHERE file_source IS NOT NULL;


-- ============================================================================
-- 4. practice_export_manifests  (spec 07 — Export)
-- ============================================================================
CREATE TABLE IF NOT EXISTS practice_export_manifests (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id            UUID NOT NULL REFERENCES practice_workspaces(id) ON DELETE CASCADE,
    proprietario_id         UUID NOT NULL,
    kind                    TEXT NOT NULL,
    snapshot_hash           TEXT NOT NULL,
    snapshot_json           JSONB NOT NULL,
    version_label           TEXT,
    requires_strong_retention BOOLEAN NOT NULL DEFAULT FALSE,
    is_probatorio           BOOLEAN NOT NULL DEFAULT FALSE,
    recomposable_state      TEXT NOT NULL DEFAULT 'unknown',
    last_recompose_check_at TIMESTAMPTZ,
    note                    TEXT,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_export_kind CHECK (
        kind IN ('pdf_lavoro','json_portable','package_probatorio')
    ),
    CONSTRAINT chk_export_recomposable CHECK (
        recomposable_state IN ('unknown','recomposable','partial','broken')
    )
);

CREATE INDEX IF NOT EXISTS idx_export_workspace
    ON practice_export_manifests (workspace_id);
CREATE INDEX IF NOT EXISTS idx_export_owner
    ON practice_export_manifests (proprietario_id);


-- ============================================================================
-- 5. workspace_inbox_items  (spec 09 — Inbox / Novità)
-- ============================================================================
CREATE TABLE IF NOT EXISTS workspace_inbox_items (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id            UUID REFERENCES practice_workspaces(id) ON DELETE CASCADE,
    proprietario_id         UUID NOT NULL,
    kind                    TEXT NOT NULL,
    state                   TEXT NOT NULL DEFAULT 'pending_confirmation',
    title                   TEXT NOT NULL,
    body_preview            TEXT,
    candidate_source        TEXT,                       -- 'documento'|'memoria'|'email'|'chat'|...
    candidate_source_id     UUID,
    candidate_content_hash  TEXT,
    linked_request_id       UUID,
    linked_manifest_item_id UUID,
    linked_finding_id       UUID,
    suggested_actions       JSONB NOT NULL DEFAULT '[]'::JSONB,
    metadata                JSONB NOT NULL DEFAULT '{}'::JSONB,
    received_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    read_at                 TIMESTAMPTZ,
    acted_upon_at           TIMESTAMPTZ,
    CONSTRAINT chk_inbox_state CHECK (
        state IN ('auto_linked','suggested','pending_confirmation','rejected','unclassified','confirmed')
    )
);

CREATE INDEX IF NOT EXISTS idx_inbox_workspace_unread
    ON workspace_inbox_items (workspace_id) WHERE read_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_inbox_owner
    ON workspace_inbox_items (proprietario_id);
CREATE INDEX IF NOT EXISTS idx_inbox_unclassified
    ON workspace_inbox_items (proprietario_id) WHERE workspace_id IS NULL;


-- ============================================================================
-- 6. workspace_resume_snapshots  (spec 05 §resume)
-- ============================================================================
CREATE TABLE IF NOT EXISTS workspace_resume_snapshots (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id            UUID NOT NULL REFERENCES practice_workspaces(id) ON DELETE CASCADE,
    proprietario_id         UUID NOT NULL,
    snapshot_kind           TEXT NOT NULL,              -- 'pause'|'reopen'|'manual'
    snapshot_json           JSONB NOT NULL,
    note                    TEXT,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_resume_kind CHECK (
        snapshot_kind IN ('pause','reopen','manual','close')
    )
);

CREATE INDEX IF NOT EXISTS idx_resume_workspace
    ON workspace_resume_snapshots (workspace_id, created_at DESC);


-- ============================================================================
-- 7. linked_file_guard_refs  (spec 08)
-- Materializzazione delle dipendenze file → workspace, per check rapidi.
-- Popolata dai trigger applicativi del servizio.
-- ============================================================================
CREATE TABLE IF NOT EXISTS linked_file_guard_refs (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    proprietario_id         UUID NOT NULL,
    file_source             TEXT NOT NULL,
    file_source_id          UUID NOT NULL,
    workspace_id            UUID REFERENCES practice_workspaces(id) ON DELETE CASCADE,
    export_id               UUID REFERENCES practice_export_manifests(id) ON DELETE CASCADE,
    manifest_item_id        UUID REFERENCES practice_manifest_items(id) ON DELETE CASCADE,
    proof_kind              TEXT,                       -- 'manifest_link'|'export_include'|'proof_chain'
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_guard_file
    ON linked_file_guard_refs (file_source, file_source_id);
CREATE INDEX IF NOT EXISTS idx_guard_owner
    ON linked_file_guard_refs (proprietario_id);


-- ============================================================================
-- 8. practice_checklist_items  (spec 13)
-- Una tabella unica: ogni riga è un item di checklist di un workspace.
-- Template non normalizzato in DB in fase A (vivono in JSON in services/).
-- ============================================================================
CREATE TABLE IF NOT EXISTS practice_checklist_items (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id            UUID NOT NULL REFERENCES practice_workspaces(id) ON DELETE CASCADE,
    proprietario_id         UUID NOT NULL,
    template_key            TEXT,
    item_key                TEXT NOT NULL,
    label                   TEXT NOT NULL,
    kind                    TEXT NOT NULL DEFAULT 'verification',
    required                BOOLEAN NOT NULL DEFAULT TRUE,
    state                   TEXT NOT NULL DEFAULT 'pending',
    note                    TEXT,
    linked_role_codes       JSONB NOT NULL DEFAULT '[]'::JSONB,
    linked_manifest_item_id UUID REFERENCES practice_manifest_items(id) ON DELETE SET NULL,
    source_ref              JSONB NOT NULL DEFAULT '{}'::JSONB,
    ordine                  INTEGER NOT NULL DEFAULT 0,
    last_changed_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_checklist_kind CHECK (
        kind IN ('verification','document_required','external_action','signature','payment','notice')
    ),
    CONSTRAINT chk_checklist_state CHECK (
        state IN ('pending','ok','missing','not_applicable','flagged')
    )
);

CREATE INDEX IF NOT EXISTS idx_checklist_workspace
    ON practice_checklist_items (workspace_id);


-- ============================================================================
-- 9. practice_document_matches  (spec 14 — Archive Matching)
-- Risultati materializzati di find_candidates. Cache di candidati per role.
-- ============================================================================
CREATE TABLE IF NOT EXISTS practice_document_matches (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id            UUID NOT NULL REFERENCES practice_workspaces(id) ON DELETE CASCADE,
    proprietario_id         UUID NOT NULL,
    manifest_item_id        UUID REFERENCES practice_manifest_items(id) ON DELETE CASCADE,
    role_code               TEXT NOT NULL,
    candidate_source        TEXT NOT NULL,
    candidate_source_id     UUID NOT NULL,
    candidate_label         TEXT,
    candidate_hash          TEXT,
    score_origin            TEXT NOT NULL,              -- 'find_related'|'fts'|'history'
    score_value             NUMERIC,
    snippet                 TEXT,
    state                   TEXT NOT NULL DEFAULT 'proposed',
    matched_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_match_state CHECK (
        state IN ('proposed','accepted','rejected','superseded')
    )
);

CREATE INDEX IF NOT EXISTS idx_matches_workspace_role
    ON practice_document_matches (workspace_id, role_code);


-- ============================================================================
-- 10. client_document_requests  (spec 15)
-- ============================================================================
CREATE TABLE IF NOT EXISTS client_document_requests (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id            UUID NOT NULL REFERENCES practice_workspaces(id) ON DELETE RESTRICT,
    proprietario_id         UUID NOT NULL,
    manifest_item_id        UUID REFERENCES practice_manifest_items(id) ON DELETE SET NULL,
    cliente_contact         JSONB NOT NULL,
    requested_role_code     TEXT NOT NULL,
    requested_label         TEXT NOT NULL,
    message_to_client       TEXT,
    state                   TEXT NOT NULL DEFAULT 'created',
    invio_event_id          UUID,                       -- soft FK (no cascade, no UPDATE su eventi_invio)
    firma_vemora_token      TEXT,
    received_file_ref       JSONB,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    sent_at                 TIMESTAMPTZ,
    received_at             TIMESTAMPTZ,
    confirmed_at            TIMESTAMPTZ,
    declined_at             TIMESTAMPTZ,
    cancelled_at            TIMESTAMPTZ,
    expires_at              TIMESTAMPTZ,
    CONSTRAINT chk_request_state CHECK (
        state IN ('created','sent','received','confirmed','declined','expired','cancelled')
    )
);

CREATE INDEX IF NOT EXISTS idx_client_req_workspace
    ON client_document_requests (workspace_id);
CREATE INDEX IF NOT EXISTS idx_client_req_owner_state
    ON client_document_requests (proprietario_id, state);


-- ============================================================================
-- 11. source_routing_registry  (spec 11/12)
-- ============================================================================
CREATE TABLE IF NOT EXISTS source_routing_registry (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    route_key               TEXT NOT NULL,
    sector                  TEXT,
    country_code            TEXT NOT NULL DEFAULT 'IT',
    region_code             TEXT,
    comune_code             TEXT,
    profession_code         TEXT,
    practice_kind           TEXT,
    label                   TEXT NOT NULL,
    source_kind             TEXT NOT NULL,              -- 'official_endpoint'|'sapere_module'|'manual_reference'
    url_or_pattern          TEXT,
    capability              TEXT,                       -- 'read_norm_reference'|'read_modulo_template'|...
    priority                INTEGER NOT NULL DEFAULT 100,
    reliability             NUMERIC NOT NULL DEFAULT 0.5,
    active                  BOOLEAN NOT NULL DEFAULT TRUE,
    payload                 JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (route_key, country_code, region_code, comune_code, profession_code, practice_kind)
);

CREATE INDEX IF NOT EXISTS idx_routing_active_lookup
    ON source_routing_registry (practice_kind, comune_code) WHERE active;


-- ============================================================================
-- 12. technical_prechecks  (spec 16)
-- ============================================================================
CREATE TABLE IF NOT EXISTS technical_prechecks (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id            UUID NOT NULL REFERENCES practice_workspaces(id) ON DELETE CASCADE,
    proprietario_id         UUID NOT NULL,
    precheck_key            TEXT NOT NULL,
    severity                TEXT NOT NULL,
    status                  TEXT NOT NULL DEFAULT 'open',
    detail                  JSONB NOT NULL DEFAULT '{}'::JSONB,
    suppressed_by_exception_id UUID,
    detected_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at             TIMESTAMPTZ,
    CONSTRAINT chk_precheck_severity CHECK (
        severity IN ('info','warning','blocker')
    ),
    CONSTRAINT chk_precheck_status CHECK (
        status IN ('open','resolved','suppressed','obsolete')
    )
);

CREATE INDEX IF NOT EXISTS idx_precheck_workspace_open
    ON technical_prechecks (workspace_id) WHERE status = 'open';


-- ============================================================================
-- 13. project_existing_state_comparisons  (spec 17 — Confronto progetto↔stato)
-- Funzione esplicita, non sepolta nel precheck.
-- ============================================================================
CREATE TABLE IF NOT EXISTS project_existing_state_comparisons (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id            UUID NOT NULL REFERENCES practice_workspaces(id) ON DELETE CASCADE,
    proprietario_id         UUID NOT NULL,
    project_refs            JSONB NOT NULL DEFAULT '[]'::JSONB,
    existing_state_refs     JSONB NOT NULL DEFAULT '[]'::JSONB,
    comparison_inputs       JSONB NOT NULL DEFAULT '{}'::JSONB,
    findings                JSONB NOT NULL DEFAULT '[]'::JSONB,
    coherent_elements       JSONB NOT NULL DEFAULT '[]'::JSONB,
    incoherent_elements     JSONB NOT NULL DEFAULT '[]'::JSONB,
    missing_data            JSONB NOT NULL DEFAULT '[]'::JSONB,
    doubtful_points         JSONB NOT NULL DEFAULT '[]'::JSONB,
    norm_refs               JSONB NOT NULL DEFAULT '[]'::JSONB,
    questions_for_authority JSONB NOT NULL DEFAULT '[]'::JSONB,
    confidence_level        TEXT NOT NULL DEFAULT 'low',
    status                  TEXT NOT NULL DEFAULT 'open',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_pec_confidence CHECK (
        confidence_level IN ('low','medium','high')
    ),
    CONSTRAINT chk_pec_status CHECK (
        status IN ('open','reviewed','resolved','obsolete')
    )
);

CREATE INDEX IF NOT EXISTS idx_pec_workspace
    ON project_existing_state_comparisons (workspace_id);


-- ============================================================================
-- 14. contextual_exceptions  (spec 18)
-- Le eccezioni vivono come tabella propria (non solo JSONB del workspace),
-- perché vanno indicizzate per riproposizione/scope.
-- ============================================================================
CREATE TABLE IF NOT EXISTS contextual_exceptions (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id            UUID NOT NULL REFERENCES practice_workspaces(id) ON DELETE CASCADE,
    proprietario_id         UUID NOT NULL,
    issue_key               TEXT NOT NULL,
    scope                   TEXT NOT NULL DEFAULT 'this_practice',
    applies_to              TEXT NOT NULL DEFAULT 'precheck',
    rationale               TEXT,
    source_person_or_entity TEXT,
    evidence_ref            JSONB,
    valid_for_document_id   UUID,
    valid_for_version_index INTEGER,
    revoked_at              TIMESTAMPTZ,
    revoked_reason          TEXT,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_exception_scope CHECK (
        scope IN ('this_practice','this_version','client','comune','global')
    ),
    CONSTRAINT chk_exception_applies_to CHECK (
        applies_to IN ('precheck','project_existing_state','checklist','manifest')
    )
);

CREATE INDEX IF NOT EXISTS idx_exception_workspace
    ON contextual_exceptions (workspace_id);
CREATE INDEX IF NOT EXISTS idx_exception_owner_scope
    ON contextual_exceptions (proprietario_id, scope) WHERE revoked_at IS NULL;


-- ============================================================================
-- 15. workspace_relations  (spec 04 — Chat persistente)
-- Linker leggero tra contatti (entity esistente) e workspace.
-- La chat vera vive in tabelle esistenti (chat_threads/chat_messages).
-- ============================================================================
CREATE TABLE IF NOT EXISTS workspace_relations (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    proprietario_id         UUID NOT NULL,
    workspace_id            UUID REFERENCES practice_workspaces(id) ON DELETE CASCADE,
    relation_kind           TEXT NOT NULL,              -- 'contact'|'authority'|'collaborator'
    relation_ref            JSONB NOT NULL,             -- { entity_id, label, role }
    chat_thread_id          UUID,                       -- soft FK
    last_state              JSONB NOT NULL DEFAULT '{}'::JSONB,
    last_message_at         TIMESTAMPTZ,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_workspace_rel_workspace
    ON workspace_relations (workspace_id);
CREATE INDEX IF NOT EXISTS idx_workspace_rel_owner
    ON workspace_relations (proprietario_id);


COMMIT;

-- ============================================================================
-- Verifica idempotenza:
-- - Eseguire una seconda volta non deve produrre errori, perché tutti i
--   CREATE usano IF NOT EXISTS.
-- - Eseguire su DB esistente non tocca eventi_invio, timeline_eventi,
--   evidence_hash_chain_events.
-- - Nessun ALTER su tabelle preesistenti.
-- ============================================================================
