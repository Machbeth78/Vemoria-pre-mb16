-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB13-P1 R2 V202 — Private writer, privilege boundary and canonical hash closure.
-- Additive, idempotent migration. Does not modify previous migrations.

BEGIN;

-- ----------------------------------------------------------------------------
-- 1. Role hardening: worker and API must not inherit writer/executor privileges.
-- The writer and executor remain NOLOGIN private roles; no login role is a member.
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_auth_members am JOIN pg_roles r ON r.oid = am.roleid JOIN pg_roles m ON m.oid = am.member WHERE r.rolname = 'mb13_p1_writer' AND m.rolname = 'mb13_p1_worker') THEN
        EXECUTE 'REVOKE mb13_p1_writer FROM mb13_p1_worker';
    END IF;
    IF EXISTS (SELECT 1 FROM pg_auth_members am JOIN pg_roles r ON r.oid = am.roleid JOIN pg_roles m ON m.oid = am.member WHERE r.rolname = 'mb13_p1_executor' AND m.rolname = 'mb13_p1_worker') THEN
        EXECUTE 'REVOKE mb13_p1_executor FROM mb13_p1_worker';
    END IF;
    IF EXISTS (SELECT 1 FROM pg_auth_members am JOIN pg_roles r ON r.oid = am.roleid JOIN pg_roles m ON m.oid = am.member WHERE r.rolname = 'mb13_p1_writer' AND m.rolname = 'mb13_p1_api') THEN
        EXECUTE 'REVOKE mb13_p1_writer FROM mb13_p1_api';
    END IF;
    IF EXISTS (SELECT 1 FROM pg_auth_members am JOIN pg_roles r ON r.oid = am.roleid JOIN pg_roles m ON m.oid = am.member WHERE r.rolname = 'mb13_p1_executor' AND m.rolname = 'mb13_p1_api') THEN
        EXECUTE 'REVOKE mb13_p1_executor FROM mb13_p1_api';
    END IF;
    IF EXISTS (SELECT 1 FROM pg_auth_members am JOIN pg_roles r ON r.oid = am.roleid JOIN pg_roles m ON m.oid = am.member WHERE r.rolname = 'mb13_p1_writer' AND m.rolname = 'mb13_p1_app') THEN
        EXECUTE 'REVOKE mb13_p1_writer FROM mb13_p1_app';
    END IF;
    IF EXISTS (SELECT 1 FROM pg_auth_members am JOIN pg_roles r ON r.oid = am.roleid JOIN pg_roles m ON m.oid = am.member WHERE r.rolname = 'mb13_p1_executor' AND m.rolname = 'mb13_p1_app') THEN
        EXECUTE 'REVOKE mb13_p1_executor FROM mb13_p1_app';
    END IF;
END
$$;

ALTER ROLE mb13_p1_worker NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p1_api NOINHERIT NOBYPASSRLS;
ALTER ROLE mb13_p1_app NOLOGIN;
ALTER ROLE mb13_p1_writer NOLOGIN;
ALTER ROLE mb13_p1_executor NOLOGIN;

-- The worker needs read-only access to target and payload tables to compute diffs
-- locally; it still cannot write to them because the writer functions are private.
GRANT SELECT ON public.mb13_p0_monitor_target TO mb13_p1_worker;
GRANT SELECT ON public.mb13_p1_preflight_state TO mb13_p1_worker;
GRANT SELECT ON public.documenti TO mb13_p1_worker;
GRANT SELECT ON public.mb13_p1_document_revision TO mb13_p1_worker;
GRANT SELECT ON public.mb12_p1_offer_contract_revision TO mb13_p1_worker;
GRANT SELECT ON public.mb12_p4_governed_explainable_ranking_revision TO mb13_p1_worker;

-- The API and worker roles must be able to read diff results (API via get_diff,
-- worker to return the diff it just sealed without querying internals).
GRANT SELECT ON public.mb13_p1_universal_diff TO mb13_p1_api, mb13_p1_worker;
GRANT SELECT ON public.mb13_p1_universal_diff_revision TO mb13_p1_api;
GRANT EXECUTE ON FUNCTION public.mb13_p1_request_diff_job(UUID, JSONB, TEXT) TO mb13_p1_api;
GRANT EXECUTE ON FUNCTION public.mb13_p1_get_job_status(UUID) TO mb13_p1_api;

-- The worker and API need to compute canonical hashes locally while building envelopes.
GRANT EXECUTE ON FUNCTION public.mb13_p0_hash_jsonb(JSONB) TO mb13_p1_worker, mb13_p1_api;
GRANT EXECUTE ON FUNCTION public.mb13_p0_normalize_jsonb_array(JSONB) TO mb13_p1_worker, mb13_p1_api;

-- The worker reads its own preflight state row to build the sealed result envelope.
DROP POLICY IF EXISTS preflight_state_worker_select ON public.mb13_p1_preflight_state;
CREATE POLICY preflight_state_worker_select ON public.mb13_p1_preflight_state
    FOR SELECT TO mb13_p1_worker
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

-- ----------------------------------------------------------------------------
-- 2. Internal preflight/writer functions are reachable only by the private writer.
-- The job-bound wrappers remain callable by the worker. The default NULL on the
-- internal writer envelope is removed via a controlled replacement.
-- ----------------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) TO mb13_p1_writer;

REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) TO mb13_p1_writer;

-- Ensure worker cannot call the 3-arg preflight or the 14-arg write_diff directly.
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) FROM mb13_p1_worker;
REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) FROM mb13_p1_worker;

-- ----------------------------------------------------------------------------
-- 3. Canonical content hash: single source of truth for writer and verify.
-- Uses the same JSON contract the writer has used since v201b.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_compute_content_hash(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_monitor_revision INTEGER,
    p_baseline_ref JSONB,
    p_observation_ref JSONB,
    p_diff_kind TEXT,
    p_changes JSONB,
    p_algorithm_version TEXT,
    p_normalization_version TEXT,
    p_source_refs JSONB,
    p_evidence_refs JSONB,
    p_consent_refs JSONB
) RETURNS TEXT AS $$
BEGIN
    RETURN public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', p_owner_user_id,
        'monitor_id', p_monitor_id,
        'monitor_revision', p_monitor_revision,
        'baseline_ref', p_baseline_ref,
        'observation_ref', p_observation_ref,
        'diff_kind', p_diff_kind,
        'changes', p_changes,
        'algorithm_version', p_algorithm_version,
        'normalization_version', p_normalization_version,
        'source_refs', public.mb13_p0_normalize_jsonb_array(COALESCE(p_source_refs, '[]'::jsonb)),
        'evidence_refs', public.mb13_p0_normalize_jsonb_array(COALESCE(p_evidence_refs, '[]'::jsonb)),
        'consent_refs', public.mb13_p0_normalize_jsonb_array(COALESCE(p_consent_refs, '[]'::jsonb))
    ));
END;
$$ LANGUAGE plpgsql IMMUTABLE
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p1_compute_content_hash(UUID, UUID, INTEGER, JSONB, JSONB, TEXT, JSONB, TEXT, TEXT, JSONB, JSONB, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_compute_content_hash(UUID, UUID, INTEGER, JSONB, JSONB, TEXT, JSONB, TEXT, TEXT, JSONB, JSONB, JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_compute_content_hash(UUID, UUID, INTEGER, JSONB, JSONB, TEXT, JSONB, TEXT, TEXT, JSONB, JSONB, JSONB) TO mb13_p1_executor;
ALTER FUNCTION public.mb13_p1_compute_content_hash(UUID, UUID, INTEGER, JSONB, JSONB, TEXT, JSONB, TEXT, TEXT, JSONB, JSONB, JSONB) OWNER TO mb13_p1_writer;

-- ----------------------------------------------------------------------------
-- 4. Verify content hash uses the canonical function and is owner-scoped.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_verify_content_hash(p_diff_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
    v_diff public.mb13_p1_universal_diff%ROWTYPE;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_claimed_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_recomputed TEXT;
BEGIN
    SELECT * INTO v_diff
      FROM public.mb13_p1_universal_diff
     WHERE diff_id = p_diff_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_diff_not_found';
    END IF;

    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT COALESCE(v_is_superuser, FALSE) THEN
        IF v_claimed_owner IS NULL OR v_diff.owner_user_id IS DISTINCT FROM v_claimed_owner THEN
            RAISE EXCEPTION 'mb13_p1_verify_content_hash_owner_scope';
        END IF;
    END IF;

    v_recomputed := public.mb13_p1_compute_content_hash(
        v_diff.owner_user_id,
        v_diff.monitor_id,
        v_diff.monitor_revision,
        v_diff.baseline_ref,
        v_diff.observation_ref,
        v_diff.diff_kind,
        v_diff.changes,
        v_diff.algorithm_version,
        v_diff.normalization_version,
        v_diff.source_refs,
        v_diff.evidence_refs,
        v_diff.consent_refs
    );

    RETURN v_recomputed = v_diff.content_hash;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = pg_catalog, public;
ALTER FUNCTION public.mb13_p1_verify_content_hash(UUID) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_verify_content_hash(UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_verify_content_hash(UUID) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_verify_content_hash(UUID) TO mb13_p1_api;

-- ----------------------------------------------------------------------------
-- 5. Document provenance is derived from the governed monitor baseline.
-- For document targets the authoritative source is the active monitor's consent
-- set (which is itself bound to real sources, grants and evidence).
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p0_get_target_provenance(
    p_owner UUID,
    p_target_type TEXT,
    p_target_ref JSONB
)
RETURNS TABLE(source_refs JSONB, evidence_refs JSONB) AS $$
DECLARE
    v_id TEXT;
    v_revision INTEGER;
    v_source_refs JSONB;
    v_evidence_refs JSONB;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
BEGIN
    IF p_target_ref IS NULL OR jsonb_typeof(p_target_ref) <> 'object' THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    v_id := p_target_ref->>'id';
    IF v_id IS NULL OR length(trim(v_id)) = 0 THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    BEGIN
        v_revision := (p_target_ref->>'revision')::INTEGER;
    EXCEPTION WHEN invalid_text_representation THEN
        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END;

    IF p_target_type = 'source' THEN
        SELECT
            jsonb_build_array(jsonb_build_object(
                'source_card_id', b.source_card_id,
                'source_id', b.source_id::text,
                'source_revision_id', b.source_revision_id::text,
                'evidence_id', b.evidence_id::text,
                'grant_id', b.grant_id::text,
                'content_hash', b.content_hash
            )),
            COALESCE((
                SELECT jsonb_agg(jsonb_build_object(
                    'evidence_id', b2.evidence_id::text,
                    'source_id', b2.source_id::text,
                    'source_card_id', b2.source_card_id
                ) ORDER BY b2.evidence_id::text)
                  FROM public.mb12_p0_source_card_binding b2
                 WHERE b2.owner_user_id = p_owner
                   AND b2.source_card_id = v_id
            ), '[]'::jsonb)
          INTO v_source_refs, v_evidence_refs
          FROM public.mb12_p0_source_card_binding b
         WHERE b.owner_user_id = p_owner
           AND b.source_card_id = v_id
         FOR SHARE;
        RETURN QUERY SELECT COALESCE(v_source_refs, '[]'::jsonb), COALESCE(v_evidence_refs, '[]'::jsonb);
        RETURN;
    END IF;

    IF p_target_type IN ('dossier','contract','offer') THEN
        SELECT r.source_refs
          INTO v_source_refs
          FROM public.mb12_p1_offer_contract_revision r
         WHERE r.owner_user_id = p_owner
           AND r.dossier_id = v_id::UUID
           AND r.revision = v_revision;

        IF v_source_refs IS NOT NULL THEN
            v_evidence_refs := COALESCE((
                SELECT jsonb_agg(jsonb_build_object(
                    'evidence_id', (s->>'evidence_id'),
                    'source_id', (s->>'source_id'),
                    'source_card_id', (s->>'source_card_id')
                ) ORDER BY (s->>'evidence_id'))
                  FROM jsonb_array_elements(v_source_refs) AS s
                 WHERE (s->>'evidence_id') IS NOT NULL
            ), '[]'::jsonb);
            RETURN QUERY SELECT public.mb13_p0_normalize_jsonb_array(v_source_refs), public.mb13_p0_normalize_jsonb_array(v_evidence_refs);
            RETURN;
        END IF;
    END IF;

    IF p_target_type = 'decision' THEN
        SELECT rev.result_payload->'source_refs'
          INTO v_source_refs
          FROM public.mb12_p4_governed_explainable_ranking r
          JOIN public.mb12_p4_governed_explainable_ranking_revision rev
            ON rev.owner_user_id = r.owner_user_id
           AND rev.ranking_id = r.ranking_id
           AND rev.revision = v_revision
         WHERE r.owner_user_id = p_owner
           AND r.ranking_id = v_id::UUID
         FOR SHARE OF r, rev;

        IF v_source_refs IS NOT NULL THEN
            v_evidence_refs := COALESCE((
                SELECT jsonb_agg(jsonb_build_object(
                    'evidence_id', (s->>'evidence_id'),
                    'source_id', (s->>'source_id'),
                    'source_card_id', (s->>'source_card_id')
                ) ORDER BY (s->>'evidence_id'))
                  FROM jsonb_array_elements(v_source_refs) AS s
                 WHERE (s->>'evidence_id') IS NOT NULL
            ), '[]'::jsonb);
            RETURN QUERY SELECT public.mb13_p0_normalize_jsonb_array(v_source_refs), public.mb13_p0_normalize_jsonb_array(v_evidence_refs);
            RETURN;
        END IF;
    END IF;

    -- Document target: provenance comes from the active governed monitor baseline.
    -- If no active monitor exists yet (e.g. monitor creation) the canonical set is
    -- empty; when an active monitor exists, its consent_refs become the source set.
    IF p_target_type = 'document' THEN
        SELECT *
          INTO v_monitor
          FROM public.mb13_p0_monitor_target
         WHERE owner_user_id = p_owner
           AND target_type = 'document'
           AND target_ref->>'id' = v_id
           AND monitor_state = 'active'
         ORDER BY created_at DESC
         LIMIT 1
         FOR SHARE;

        IF FOUND THEN
            RETURN QUERY SELECT
                public.mb13_p0_normalize_jsonb_array(v_monitor.consent_refs),
                public.mb13_p0_normalize_jsonb_array(COALESCE(v_monitor.evidence_refs, '[]'::jsonb));
            RETURN;
        END IF;

        RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
        RETURN;
    END IF;

    -- Generic targets carry no intrinsic provenance.
    RETURN QUERY SELECT '[]'::jsonb, '[]'::jsonb;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p0_get_target_provenance(UUID, TEXT, JSONB) TO mb13_p1_executor;

-- ----------------------------------------------------------------------------
-- 6. Document revision guard: unconditional block of UPDATE/DELETE, INSERT only
-- through the executor-owned function. Strengthened to reject any session that
-- is not the executor role or a superuser.
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_mb13_p1_document_revision_guard ON public.mb13_p1_document_revision;
CREATE OR REPLACE FUNCTION public.mb13_p1_document_revision_guard()
RETURNS trigger AS $$
DECLARE
    v_is_superuser BOOLEAN;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = current_user;
    IF current_user = 'mb13_p1_executor' OR COALESCE(v_is_superuser, FALSE) THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;
    RAISE EXCEPTION 'mb13_p1_document_revision_direct_dml_blocked';
END;
$$ LANGUAGE plpgsql
SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_mb13_p1_document_revision_guard ON public.mb13_p1_document_revision;
CREATE TRIGGER trg_mb13_p1_document_revision_guard
    BEFORE INSERT OR DELETE OR UPDATE ON public.mb13_p1_document_revision
    FOR EACH STATEMENT
    EXECUTE FUNCTION public.mb13_p1_document_revision_guard();

-- ----------------------------------------------------------------------------
-- 7. Document revision append: p_owner_user_id is strictly validated against the
-- session owner and the document owner. Payload hash remains server-derived.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_append_document_revision(
    p_owner_user_id UUID,
    p_document_id UUID,
    p_revision INTEGER,
    p_state TEXT,
    p_payload_hash TEXT,
    p_dati_strutturati JSONB,
    p_testo_grezzo TEXT,
    p_supersedes_revision INTEGER DEFAULT NULL
) RETURNS UUID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_doc_owner UUID;
    v_last_revision INTEGER := 0;
    v_last_hash TEXT;
    v_revision INTEGER := p_revision;
    v_supersedes INTEGER := p_supersedes_revision;
    v_payload_hash TEXT;
    v_revision_id UUID := gen_random_uuid();
    v_doc_dati JSONB;
    v_doc_testo TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_owner_param_mismatch';
    END IF;
    IF p_state NOT IN ('memorizzato','revoked') THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_state_invalid';
    END IF;

    SELECT proprietario_id, dati_strutturati, testo_grezzo
      INTO v_doc_owner, v_doc_dati, v_doc_testo
      FROM public.documenti
     WHERE id = p_document_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_document_not_found';
    END IF;
    IF v_doc_owner IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p1_document_not_found_or_owner_mismatch';
    END IF;

    SELECT revision, payload_hash INTO v_last_revision, v_last_hash
      FROM public.mb13_p1_document_revision
     WHERE owner_user_id = p_owner_user_id
       AND document_id = p_document_id
     ORDER BY revision DESC
     LIMIT 1
     FOR UPDATE;

    IF v_last_revision IS NULL THEN
        v_last_revision := 0;
    END IF;

    IF v_revision IS NULL THEN
        v_revision := v_last_revision + 1;
    END IF;
    IF v_revision < 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_invalid';
    END IF;

    IF v_revision > 1 AND v_last_revision = 0 THEN
        INSERT INTO public.mb13_p1_document_revision (
            owner_user_id, document_id, revision, state, payload_hash,
            dati_strutturati, testo_grezzo, supersedes_revision, created_at
        ) VALUES (
            v_doc_owner, p_document_id, 1, 'memorizzato',
            public.mb13_p0_hash_jsonb(jsonb_build_object(
                'owner_user_id', v_doc_owner,
                'document_id', p_document_id,
                'revision', 1,
                'state', 'memorizzato',
                'dati_strutturati', COALESCE(v_doc_dati, '{}'::jsonb),
                'testo_grezzo', COALESCE(v_doc_testo, ''),
                'supersedes_revision', NULL
            )),
            COALESCE(v_doc_dati, '{}'::jsonb), COALESCE(v_doc_testo, ''), NULL, NOW()
        );
        v_last_revision := 1;
        v_last_hash := (
            SELECT payload_hash FROM public.mb13_p1_document_revision
             WHERE owner_user_id = v_doc_owner AND document_id = p_document_id AND revision = 1
        );
    END IF;

    IF v_revision <> v_last_revision + 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_skipped';
    END IF;

    IF v_supersedes IS NULL THEN
        v_supersedes := v_last_revision;
    END IF;
    IF v_supersedes IS DISTINCT FROM v_last_revision THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_supersedes_mismatch';
    END IF;
    IF v_last_hash IS NULL AND v_last_revision >= 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_baseline_hash_missing';
    END IF;

    IF EXISTS (
        SELECT 1 FROM public.mb13_p1_document_revision
         WHERE owner_user_id = p_owner_user_id
           AND document_id = p_document_id
           AND revision = v_revision
    ) THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_already_exists';
    END IF;

    v_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_doc_owner,
        'document_id', p_document_id,
        'revision', v_revision,
        'state', p_state,
        'dati_strutturati', COALESCE(p_dati_strutturati, '{}'::jsonb),
        'testo_grezzo', COALESCE(p_testo_grezzo, ''),
        'supersedes_revision', v_supersedes
    ));

    INSERT INTO public.mb13_p1_document_revision (
        owner_user_id, document_id, revision, state, payload_hash,
        dati_strutturati, testo_grezzo, supersedes_revision, created_at
    ) VALUES (
        v_doc_owner, p_document_id, v_revision, p_state, v_payload_hash,
        p_dati_strutturati, p_testo_grezzo, v_supersedes, NOW()
    )
    RETURNING revision_id INTO v_revision_id;

    RETURN v_revision_id;
EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION 'mb13_p1_document_revision_concurrent_insert';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;
ALTER FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p1_append_document_revision(UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER) TO mb13_p1_api;

-- ----------------------------------------------------------------------------
-- 8. Internal preflight and writer are further hardened: fail if the worker
-- result envelope or the job id are missing. The internal 3-arg preflight is not
-- reachable by the worker; the 14-arg writer is not reachable by the worker.
-- This controlled replacement removes the DEFAULT NULL on the envelope and adds
-- the explicit missing-envelope check.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_write_diff(
    p_preflight_id UUID,
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT,
    p_changes JSONB,
    p_change_count INTEGER,
    p_material_change_count INTEGER,
    p_diff_state TEXT,
    p_summary TEXT,
    p_algorithm_version TEXT,
    p_normalization_version TEXT,
    p_request_payload JSONB,
    p_result_payload JSONB,
    p_worker_result_envelope JSONB DEFAULT NULL
) RETURNS TABLE(diff_id UUID, revision INTEGER, content_hash TEXT, diff_state TEXT, change_count INTEGER, material_change_count INTEGER, summary TEXT, changes JSONB) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_preflight public.mb13_p1_preflight_state%ROWTYPE;
    v_baseline_source_refs JSONB;
    v_baseline_evidence_refs JSONB;
    v_observation_source_refs JSONB;
    v_observation_evidence_refs JSONB;
    v_canonical_consent_refs JSONB;
    v_canonical_changes JSONB;
    v_change_count INTEGER;
    v_material_change_count INTEGER;
    v_diff_state TEXT;
    v_summary TEXT;
    v_content_hash TEXT;
    v_input_hash TEXT;
    v_output_hash TEXT;
    v_envelope_input_hash TEXT;
    v_envelope_output_hash TEXT;
    v_existing_diff_id UUID;
    v_existing_revision INTEGER;
    v_diff_id UUID;
    v_revision INTEGER := 1;
    v_event_type TEXT;
    v_event_id UUID;
    v_event_time TIMESTAMPTZ := NOW();
    v_event_payload_hash TEXT;
    v_event_result_payload JSONB;
    v_expected_algorithm TEXT;
    v_job_id UUID;
    v_envelope_id UUID;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_preflight_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_preflight_required';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'id' IS NULL OR p_observation_ref->>'revision' IS NULL OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;

    v_expected_algorithm := CASE p_diff_kind
        WHEN 'structured' THEN 'mb13-p1-r2-structured'
        WHEN 'text' THEN 'mb13-p1-r2-text'
    END;

    IF p_algorithm_version IS NULL OR p_algorithm_version <> v_expected_algorithm THEN
        RAISE EXCEPTION 'mb13_p1_algorithm_version_invalid';
    END IF;
    IF p_normalization_version IS NULL OR p_normalization_version <> 'mb13-p1-r2' THEN
        RAISE EXCEPTION 'mb13_p1_normalization_version_invalid';
    END IF;

    PERFORM public.mb13_p1_validate_change_schema(p_changes);

    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_monitor_id::text, 0));

    SELECT * INTO v_preflight
      FROM public.mb13_p1_preflight_state
     WHERE preflight_id = p_preflight_id
       AND owner_user_id = v_owner
       AND monitor_id = p_monitor_id
       AND used = FALSE
       AND expires_at > NOW()
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_preflight_invalid_or_expired';
    END IF;

    IF v_preflight.observation_ref IS DISTINCT FROM p_observation_ref
       OR v_preflight.diff_kind IS DISTINCT FROM p_diff_kind THEN
        RAISE EXCEPTION 'mb13_p1_preflight_mismatch';
    END IF;

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = v_owner
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_found';
    END IF;
    IF v_current.monitor_state <> 'active' THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;
    IF v_preflight.monitor_revision IS DISTINCT FROM v_current.current_revision THEN
        RAISE EXCEPTION 'mb13_p1_monitor_revision_changed_between_preflight_and_write';
    END IF;
    IF v_preflight.baseline_ref IS DISTINCT FROM v_current.target_ref THEN
        RAISE EXCEPTION 'mb13_p1_baseline_changed_between_preflight_and_write';
    END IF;

    UPDATE public.mb13_p1_preflight_state
       SET used = TRUE
     WHERE preflight_id = p_preflight_id;

    v_baseline_source_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.baseline_source_refs);
    v_baseline_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.baseline_evidence_refs);
    v_observation_source_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.observation_source_refs);
    v_observation_evidence_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.observation_evidence_refs);
    v_canonical_consent_refs := public.mb13_p0_normalize_jsonb_array(v_preflight.consent_refs);

    v_canonical_changes := public.mb13_p0_normalize_jsonb_array(p_changes);

    v_canonical_changes := COALESCE((
        SELECT jsonb_agg(
            jsonb_set(
                jsonb_set(c.value, '{source_refs}', COALESCE(v_baseline_source_refs, '[]'::jsonb) || COALESCE(v_observation_source_refs, '[]'::jsonb)),
                '{evidence_refs}', COALESCE(v_baseline_evidence_refs, '[]'::jsonb) || COALESCE(v_observation_evidence_refs, '[]'::jsonb))
        )
        FROM jsonb_array_elements(v_canonical_changes) c
    ), '[]'::jsonb);

    v_change_count := jsonb_array_length(v_canonical_changes);

    SELECT COUNT(*) INTO v_material_change_count
      FROM jsonb_array_elements(v_canonical_changes) AS c
     WHERE (c.value->>'materiality') = 'POTENTIALLY_MATERIAL';

    IF v_change_count = 0 THEN
        v_diff_state := 'no_change';
    ELSE
        SELECT CASE WHEN EXISTS (
            SELECT 1 FROM jsonb_array_elements(v_canonical_changes) c
             WHERE (c.value->>'change_type') = 'AMBIGUOUS'
        ) THEN 'ambiguous' ELSE 'computed' END INTO v_diff_state;
    END IF;

    v_summary := CASE WHEN v_change_count = 0
        THEN 'No changes detected'
        ELSE format('Detected %s change(s), %s material', v_change_count, v_material_change_count)
    END;

    IF p_change_count IS DISTINCT FROM v_change_count THEN
        RAISE EXCEPTION 'mb13_p1_change_count_mismatch';
    END IF;
    IF p_material_change_count IS DISTINCT FROM v_material_change_count THEN
        RAISE EXCEPTION 'mb13_p1_material_change_count_mismatch';
    END IF;
    IF p_diff_state IS DISTINCT FROM v_diff_state THEN
        RAISE EXCEPTION 'mb13_p1_diff_state_mismatch';
    END IF;
    IF p_summary IS DISTINCT FROM v_summary THEN
        RAISE EXCEPTION 'mb13_p1_summary_mismatch';
    END IF;

    v_content_hash := public.mb13_p1_compute_content_hash(
        v_owner,
        p_monitor_id,
        v_current.current_revision,
        v_current.target_ref,
        p_observation_ref,
        p_diff_kind,
        v_canonical_changes,
        p_algorithm_version,
        p_normalization_version,
        v_baseline_source_refs || v_observation_source_refs,
        v_baseline_evidence_refs || v_observation_evidence_refs,
        v_canonical_consent_refs
    );

    IF p_worker_result_envelope IS NOT NULL THEN
        v_envelope_input_hash := p_worker_result_envelope->>'input_hash';
        v_envelope_output_hash := p_worker_result_envelope->>'output_hash';
        v_job_id := NULLIF(p_worker_result_envelope->>'job_id', '')::UUID;
        v_envelope_id := NULLIF(p_worker_result_envelope->>'envelope_id', '')::UUID;

        IF v_envelope_input_hash IS NULL OR v_envelope_output_hash IS NULL THEN
            RAISE EXCEPTION 'mb13_p1_worker_result_envelope_required';
        END IF;

        v_input_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'monitor_revision', v_current.current_revision,
            'baseline_ref', v_current.target_ref,
            'observation_ref', p_observation_ref,
            'baseline_source_refs', v_baseline_source_refs,
            'baseline_evidence_refs', v_baseline_evidence_refs,
            'observation_source_refs', v_observation_source_refs,
            'observation_evidence_refs', v_observation_evidence_refs,
            'consent_refs', v_canonical_consent_refs,
            'request_hash', v_preflight.request_hash,
            'algorithm_version', p_algorithm_version,
            'normalization_version', p_normalization_version
        ));

        v_output_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'changes', v_canonical_changes,
            'change_count', v_change_count,
            'material_change_count', v_material_change_count,
            'diff_state', v_diff_state,
            'summary', v_summary
        ));

        IF v_input_hash IS DISTINCT FROM v_envelope_input_hash THEN
            RAISE EXCEPTION 'mb13_p1_worker_envelope_input_hash_mismatch';
        END IF;
        IF v_output_hash IS DISTINCT FROM v_envelope_output_hash THEN
            RAISE EXCEPTION 'mb13_p1_worker_envelope_output_hash_mismatch';
        END IF;

        IF v_job_id IS NOT NULL THEN
            SELECT d.diff_id, d.current_revision
              INTO v_existing_diff_id, v_existing_revision
              FROM public.mb13_p1_universal_diff d
             WHERE d.owner_user_id = v_owner
               AND d.job_id = v_job_id
               AND d.content_hash = v_content_hash;
            IF FOUND THEN
                RETURN QUERY SELECT v_existing_diff_id, v_existing_revision, v_content_hash, v_diff_state, v_change_count, v_material_change_count, v_summary, v_canonical_changes;
                RETURN;
            END IF;
        END IF;
    ELSE
        IF NOT COALESCE(v_is_superuser, FALSE) THEN
            RAISE EXCEPTION 'mb13_p1_worker_result_envelope_required';
        END IF;
    END IF;

    SELECT d.diff_id, d.current_revision
      INTO v_existing_diff_id, v_existing_revision
      FROM public.mb13_p1_universal_diff d
     WHERE d.owner_user_id = v_owner
       AND d.content_hash = v_content_hash
     LIMIT 1;
    IF FOUND THEN
        RETURN QUERY SELECT v_existing_diff_id, v_existing_revision, v_content_hash, v_diff_state, v_change_count, v_material_change_count, v_summary, v_canonical_changes;
        RETURN;
    END IF;

    v_diff_id := gen_random_uuid();

    v_event_result_payload := COALESCE(p_result_payload, '{}'::jsonb) || jsonb_build_object(
        'diff_id', v_diff_id,
        'diff_revision', v_revision,
        'diff_content_hash', v_content_hash,
        'diff_kind', p_diff_kind,
        'diff_state', v_diff_state,
        'change_count', v_change_count,
        'material_change_count', v_material_change_count,
        'no_auto_action', true,
        'no_auto_notification', true,
        'baseline_source_refs', v_baseline_source_refs,
        'baseline_evidence_refs', v_baseline_evidence_refs,
        'observation_source_refs', v_observation_source_refs,
        'observation_evidence_refs', v_observation_evidence_refs,
        'effective_consent_refs', v_canonical_consent_refs
    );

    INSERT INTO public.mb13_p1_universal_diff (
        owner_user_id, diff_id, monitor_id, monitor_revision, baseline_ref, observation_ref,
        diff_kind, diff_state, summary, change_count, material_change_count, changes,
        source_refs, evidence_refs, consent_refs, algorithm_version, normalization_version,
        payload_hash, content_hash, current_revision, request_payload, result_payload,
        envelope_id, job_id
    ) VALUES (
        v_owner, v_diff_id, p_monitor_id, v_current.current_revision, v_current.target_ref, p_observation_ref,
        p_diff_kind, v_diff_state, v_summary, v_change_count, v_material_change_count, v_canonical_changes,
        public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs),
        public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs),
        v_canonical_consent_refs,
        p_algorithm_version, p_normalization_version,
        v_content_hash, v_content_hash, v_revision, COALESCE(p_request_payload, '{}'::jsonb), v_event_result_payload,
        v_envelope_id, v_job_id
    );

    INSERT INTO public.mb13_p1_universal_diff_revision (
        owner_user_id, diff_id, revision, monitor_revision, baseline_ref, observation_ref,
        diff_kind, diff_state, summary, change_count, material_change_count, changes,
        source_refs, evidence_refs, consent_refs, algorithm_version, normalization_version,
        payload_hash, content_hash, request_payload, result_payload,
        envelope_id, job_id
    ) VALUES (
        v_owner, v_diff_id, v_revision, v_current.current_revision, v_current.target_ref, p_observation_ref,
        p_diff_kind, v_diff_state, v_summary, v_change_count, v_material_change_count, v_canonical_changes,
        public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs),
        public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs),
        v_canonical_consent_refs,
        p_algorithm_version, p_normalization_version,
        v_content_hash, v_content_hash, COALESCE(p_request_payload, '{}'::jsonb), v_event_result_payload,
        v_envelope_id, v_job_id
    );

    IF v_diff_state = 'no_change' THEN
        v_event_type := 'NO_CHANGE_RECORDED';
    ELSE
        v_event_type := 'CHANGE_CANDIDATE_RECORDED';
    END IF;

    v_event_id := gen_random_uuid();
    v_event_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'event_id', v_event_id,
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'event_type', v_event_type,
        'event_status', 'recorded',
        'event_time', to_jsonb(v_event_time),
        'observed_ref', p_observation_ref,
        'source_refs', public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs),
        'evidence_refs', public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs),
        'consent_refs', v_canonical_consent_refs,
        'reason', NULL,
        'result_payload', v_event_result_payload
    ));

    INSERT INTO public.mb13_p0_monitor_event_ledger (
        event_id, owner_user_id, monitor_id, monitor_revision, event_type, event_status, event_time,
        observed_ref, source_refs, evidence_refs, consent_refs, reason, result_payload, payload_hash
    ) VALUES (
        v_event_id, v_owner, p_monitor_id, v_current.current_revision, v_event_type, 'recorded', v_event_time,
        p_observation_ref,
        public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs || v_observation_source_refs),
        public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs || v_observation_evidence_refs),
        v_canonical_consent_refs, NULL, v_event_result_payload, v_event_payload_hash
    );

    RETURN QUERY SELECT v_diff_id, v_revision, v_content_hash, v_diff_state, v_change_count, v_material_change_count, v_summary, v_canonical_changes;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) TO mb13_p1_writer;

-- ----------------------------------------------------------------------------
-- 9. Internal preflight: fail if the worker envelope/job is missing. This is the
-- 3-arg internal form; the job-bound 5-arg wrapper remains the worker entry point.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_preflight(
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT
) RETURNS UUID AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_current public.mb13_p0_monitor_target%ROWTYPE;
    v_baseline_source_refs JSONB;
    v_baseline_evidence_refs JSONB;
    v_observation_source_refs JSONB;
    v_observation_evidence_refs JSONB;
    v_baseline_rev INTEGER;
    v_observation_rev INTEGER;
    v_preflight_id UUID := gen_random_uuid();
    v_request_hash TEXT;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object'
       OR p_observation_ref->>'id' IS NULL
       OR p_observation_ref->>'revision' IS NULL
       OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
        RAISE EXCEPTION 'mb13_p1_target_owner_mismatch';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;

    PERFORM pg_advisory_xact_lock(hashtextextended(v_owner::text || ':' || p_monitor_id::text, 0));

    SELECT * INTO v_current
      FROM public.mb13_p0_monitor_target
     WHERE owner_user_id = v_owner
       AND monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_found';
    END IF;
    IF v_current.monitor_state <> 'active' THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;

    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, v_current.target_ref);
    PERFORM public.mb13_p1_resolve_target(v_owner, v_current.target_type, p_observation_ref);

    IF (v_current.target_ref->>'id') IS DISTINCT FROM (p_observation_ref->>'id') THEN
        RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
    END IF;

    v_baseline_rev := (v_current.target_ref->>'revision')::INTEGER;
    v_observation_rev := (p_observation_ref->>'revision')::INTEGER;

    IF v_observation_rev < v_baseline_rev THEN
        RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
    END IF;

    IF v_observation_rev = v_baseline_rev THEN
        IF (v_current.target_ref->>'payload_hash') IS DISTINCT FROM (p_observation_ref->>'payload_hash')
           OR (v_current.target_ref->>'state') IS DISTINCT FROM (p_observation_ref->>'state') THEN
            RAISE EXCEPTION 'mb13_p1_observation_not_compatible';
        END IF;
    END IF;

    PERFORM public.mb13_p0_lock_and_verify_consents(
        v_owner, v_current.consent_refs, v_current.target_type, v_current.target_ref,
        p_required => TRUE, p_strict_relation => FALSE
    );
    PERFORM public.mb13_p0_lock_and_verify_consents(
        v_owner, v_current.consent_refs, v_current.target_type, p_observation_ref,
        p_required => TRUE, p_strict_relation => FALSE
    );

    SELECT source_refs, evidence_refs INTO v_baseline_source_refs, v_baseline_evidence_refs
      FROM public.mb13_p0_get_target_provenance(v_owner, v_current.target_type, v_current.target_ref);
    SELECT source_refs, evidence_refs INTO v_observation_source_refs, v_observation_evidence_refs
      FROM public.mb13_p0_get_target_provenance(v_owner, v_current.target_type, p_observation_ref);

    PERFORM * FROM public.mb13_p1_resolve_exact_provenance(v_owner, v_baseline_source_refs, v_baseline_evidence_refs);
    PERFORM * FROM public.mb13_p1_resolve_exact_provenance(v_owner, v_observation_source_refs, v_observation_evidence_refs);

    IF jsonb_array_length(COALESCE(v_baseline_source_refs, '[]'::jsonb)) = 0
       AND jsonb_array_length(COALESCE(v_baseline_evidence_refs, '[]'::jsonb)) = 0 THEN
        RAISE EXCEPTION 'mb13_p1_baseline_provenance_empty';
    END IF;
    IF jsonb_array_length(COALESCE(v_observation_source_refs, '[]'::jsonb)) = 0
       AND jsonb_array_length(COALESCE(v_observation_evidence_refs, '[]'::jsonb)) = 0 THEN
        RAISE EXCEPTION 'mb13_p1_observation_provenance_empty';
    END IF;

    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'monitor_revision', v_current.current_revision,
        'baseline_ref', v_current.target_ref,
        'observation_ref', p_observation_ref,
        'diff_kind', p_diff_kind,
        'baseline_source_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs), '[]'::jsonb),
        'baseline_evidence_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs), '[]'::jsonb),
        'observation_source_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_source_refs), '[]'::jsonb),
        'observation_evidence_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_evidence_refs), '[]'::jsonb),
        'consent_refs', COALESCE(public.mb13_p0_normalize_jsonb_array(v_current.consent_refs), '[]'::jsonb)
    ));

    INSERT INTO public.mb13_p1_preflight_state (
        preflight_id, owner_user_id, monitor_id, observation_ref, diff_kind,
        baseline_source_refs, baseline_evidence_refs,
        observation_source_refs, observation_evidence_refs,
        consent_refs, monitor_revision, baseline_ref, request_hash
    ) VALUES (
        v_preflight_id, v_owner, p_monitor_id, p_observation_ref, p_diff_kind,
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_source_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_baseline_evidence_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_source_refs), '[]'::jsonb),
        COALESCE(public.mb13_p0_normalize_jsonb_array(v_observation_evidence_refs), '[]'::jsonb),
        public.mb13_p0_normalize_jsonb_array(v_current.consent_refs),
        v_current.current_revision,
        v_current.target_ref,
        v_request_hash
    );

    RETURN v_preflight_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;
ALTER FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) TO mb13_p1_writer;

COMMIT;
