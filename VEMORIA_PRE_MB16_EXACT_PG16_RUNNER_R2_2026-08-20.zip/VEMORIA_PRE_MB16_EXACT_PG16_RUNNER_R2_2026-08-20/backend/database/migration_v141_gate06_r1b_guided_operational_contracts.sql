-- Vemoria Gate06 R1B - Scrivania guided partial-state and operational handoff contracts
-- Static schema contract only. Runtime PostgreSQL execution not performed here.
-- These tables store only redacted metadata; they must never contain raw user text,
-- document content, secrets, keys, audio/photo data or adaptive profile values.

CREATE TABLE IF NOT EXISTS gate06_guided_operational_handoff_contracts (
    id TEXT PRIMARY KEY,
    owner_id TEXT NOT NULL,
    atlas_version TEXT NOT NULL,
    guided_version TEXT NOT NULL,
    selected_vc_id TEXT NOT NULL,
    selected_is_partial BOOLEAN NOT NULL DEFAULT FALSE,
    target_pipeline TEXT NOT NULL DEFAULT 'scrivania_conv_7_stage',
    target_endpoint TEXT NOT NULL DEFAULT '/api/v1/scrivania-conv/dialogue',
    candidate_is_not_execution BOOLEAN NOT NULL DEFAULT TRUE CHECK (candidate_is_not_execution = TRUE),
    requires_explicit_confirmation BOOLEAN NOT NULL DEFAULT TRUE CHECK (requires_explicit_confirmation = TRUE),
    must_pass_risk_assessor BOOLEAN NOT NULL DEFAULT TRUE CHECK (must_pass_risk_assessor = TRUE),
    raw_user_text_stored BOOLEAN NOT NULL DEFAULT FALSE CHECK (raw_user_text_stored = FALSE),
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE CHECK (runtime_pass_claimed = FALSE),
    contains_secret BOOLEAN NOT NULL DEFAULT FALSE CHECK (contains_secret = FALSE),
    status TEXT NOT NULL DEFAULT 'PREPARED_NOT_EXECUTED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_gate06_handoff_owner_created
    ON gate06_guided_operational_handoff_contracts(owner_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_gate06_handoff_vc_status
    ON gate06_guided_operational_handoff_contracts(selected_vc_id, status);

CREATE TABLE IF NOT EXISTS gate06_cerebro_orchestration_map_contracts (
    id TEXT PRIMARY KEY,
    atlas_version TEXT NOT NULL,
    source_of_truth TEXT NOT NULL DEFAULT 'backend/registry/self_knowledge_atlas.json',
    future_consumer TEXT NOT NULL DEFAULT 'CEREBRO_ORCHESTRATOR_DEFERRED',
    second_map_allowed BOOLEAN NOT NULL DEFAULT FALSE CHECK (second_map_allowed = FALSE),
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE CHECK (runtime_pass_claimed = FALSE),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
