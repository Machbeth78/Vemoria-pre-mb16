-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA P0/P1 Adversarial Closure — v240
-- Resolve UNKNOWN_BLOCKER tables and add deterministic owner/RLS.

DO $$
DECLARE
    v_role name;
    v_tbl regclass;
BEGIN
    -- Unknown blockers with documento_id owner path
    ALTER TABLE document_insight ADD COLUMN IF NOT EXISTS owner_user_id UUID;
    UPDATE document_insight di
    SET owner_user_id = d.proprietario_id
    FROM documenti d
    WHERE d.id = di.documento_id
      AND di.owner_user_id IS NULL;
    UPDATE document_insight SET owner_user_id = '00000000-0000-0000-0000-000000000000'::uuid WHERE owner_user_id IS NULL;
    ALTER TABLE document_insight ALTER COLUMN owner_user_id SET NOT NULL;
    ALTER TABLE document_insight ENABLE ROW LEVEL SECURITY;
    ALTER TABLE document_insight FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS document_insight_owner_policy ON document_insight;
    CREATE POLICY document_insight_owner_policy ON document_insight
        FOR ALL TO PUBLIC
        USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
        WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

    ALTER TABLE document_metadata ADD COLUMN IF NOT EXISTS owner_user_id UUID;
    UPDATE document_metadata dm
    SET owner_user_id = d.proprietario_id
    FROM documenti d
    WHERE d.id = dm.documento_id
      AND dm.owner_user_id IS NULL;
    UPDATE document_metadata SET owner_user_id = '00000000-0000-0000-0000-000000000000'::uuid WHERE owner_user_id IS NULL;
    ALTER TABLE document_metadata ALTER COLUMN owner_user_id SET NOT NULL;
    ALTER TABLE document_metadata ENABLE ROW LEVEL SECURITY;
    ALTER TABLE document_metadata FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS document_metadata_owner_policy ON document_metadata;
    CREATE POLICY document_metadata_owner_policy ON document_metadata
        FOR ALL TO PUBLIC
        USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
        WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

    -- libreria_documenti: reference catalog (global public). No RLS; ensure row owner is not required.
    -- Reclassified as GLOBAL_PUBLIC per schema investigation.

    -- Sapere tables with documento_id TEXT (UUID-as-text) as owner path
    FOR v_tbl IN SELECT unnest(ARRAY[
        'sapere_contenuti',
        'sapere_documenti',
        'sapere_relazioni',
        'sapere_tassonomie',
        'sapere_template_items',
        'sapere_workflow_profili',
        'sapere_workflow_stage_items'
    ]::name[])
    LOOP
        EXECUTE format('ALTER TABLE %I ADD COLUMN IF NOT EXISTS owner_user_id UUID', v_tbl);
        EXECUTE format($f$
            UPDATE %I t
            SET owner_user_id = d.proprietario_id
            FROM documenti d
            WHERE t.documento_id ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
              AND d.id = t.documento_id::uuid
              AND t.owner_user_id IS NULL
        $f$, v_tbl);
        EXECUTE format('UPDATE %I SET owner_user_id = ''00000000-0000-0000-0000-000000000000''::uuid WHERE owner_user_id IS NULL', v_tbl);
        EXECUTE format('ALTER TABLE %I ALTER COLUMN owner_user_id SET NOT NULL', v_tbl);
        EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', v_tbl);
        EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', v_tbl);
        EXECUTE format('DROP POLICY IF EXISTS %I ON %I', v_tbl || '_owner_policy', v_tbl);
        EXECUTE format($f$
            CREATE POLICY %I ON %I
                FOR ALL TO PUBLIC
                USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
                WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
        $f$, v_tbl || '_owner_policy', v_tbl);
    END LOOP;

    -- Minimal grants
    FOR v_role IN SELECT unnest(ARRAY['test_app', 'vemora_user', 'app']::name[])
    LOOP
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = v_role) THEN
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE document_insight TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE document_metadata TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE sapere_contenuti TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE sapere_documenti TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE sapere_relazioni TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE sapere_tassonomie TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE sapere_template_items TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE sapere_workflow_profili TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE sapere_workflow_stage_items TO %I', v_role);
        END IF;
    END LOOP;
END $$;
