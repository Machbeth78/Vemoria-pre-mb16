-- ===========================================================================
-- VEMORA V250 — MB14-P5 Conversation Expressivity
-- ===========================================================================
-- Scope:
--   1. Message reactions (owner-scoped, one active reaction per reactor/message).
--   2. Status reactions (owner-scoped, one active reaction per reactor/status).
--   3. Emoji recents and favorites, owner-local and relationship-aware.
--   4. Source Card verification state foundation (already in v247) is extended
--      for user-facing re-verification entry point.
--
-- NON modifica MB0→MB14-P4-R1; solo additive.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- 1. Message reactions
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS conversation_reaction (
    reaction_id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id     UUID REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    conversation_id     UUID NOT NULL REFERENCES conversation(conversation_id) ON DELETE CASCADE,
    message_id          UUID NOT NULL REFERENCES conversation_message(message_id) ON DELETE CASCADE,
    reactor_reference   TEXT NOT NULL DEFAULT 'owner',
    emoji               TEXT NOT NULL,
    state               TEXT NOT NULL DEFAULT 'active' CHECK (state IN ('active','removed')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (owner_user_id, message_id, reactor_reference)
);

CREATE INDEX IF NOT EXISTS idx_conversation_reaction_message
    ON conversation_reaction(owner_user_id, message_id, state);
CREATE INDEX IF NOT EXISTS idx_conversation_reaction_conversation
    ON conversation_reaction(owner_user_id, conversation_id, created_at DESC);

ALTER TABLE conversation_reaction ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversation_reaction FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS conversation_reaction_owner_isolation ON conversation_reaction;
CREATE POLICY conversation_reaction_owner_isolation ON conversation_reaction
    FOR ALL
    USING (owner_user_id = _rls_owner_uuid())
    WITH CHECK (owner_user_id = _rls_owner_uuid());

-- ---------------------------------------------------------------------------
-- 2. Status reactions
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS status_reaction (
    reaction_id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id     UUID REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    status_id           UUID NOT NULL REFERENCES relationship_status(status_id) ON DELETE CASCADE,
    reactor_reference   TEXT NOT NULL DEFAULT 'owner',
    emoji               TEXT NOT NULL,
    state               TEXT NOT NULL DEFAULT 'active' CHECK (state IN ('active','removed')),
    provenance          JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (owner_user_id, status_id, reactor_reference)
);

CREATE INDEX IF NOT EXISTS idx_status_reaction_status
    ON status_reaction(owner_user_id, status_id, state);
CREATE INDEX IF NOT EXISTS idx_status_reaction_relationship
    ON status_reaction(owner_user_id, relationship_id, created_at DESC);

ALTER TABLE status_reaction ENABLE ROW LEVEL SECURITY;
ALTER TABLE status_reaction FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS status_reaction_owner_isolation ON status_reaction;
CREATE POLICY status_reaction_owner_isolation ON status_reaction
    FOR ALL
    USING (owner_user_id = _rls_owner_uuid())
    WITH CHECK (owner_user_id = _rls_owner_uuid());

-- ---------------------------------------------------------------------------
-- 3. Emoji recents and favorites
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS owner_emoji_recents (
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    emoji               TEXT NOT NULL,
    category            TEXT,
    use_count           INTEGER NOT NULL DEFAULT 1,
    last_used_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, emoji)
);

CREATE INDEX IF NOT EXISTS idx_owner_emoji_recents_last_used
    ON owner_emoji_recents(owner_user_id, last_used_at DESC);

ALTER TABLE owner_emoji_recents ENABLE ROW LEVEL SECURITY;
ALTER TABLE owner_emoji_recents FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS owner_emoji_recents_owner_isolation ON owner_emoji_recents;
CREATE POLICY owner_emoji_recents_owner_isolation ON owner_emoji_recents
    FOR ALL
    USING (owner_user_id = _rls_owner_uuid())
    WITH CHECK (owner_user_id = _rls_owner_uuid());

CREATE TABLE IF NOT EXISTS owner_emoji_favorites (
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    emoji               TEXT NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, emoji)
);

ALTER TABLE owner_emoji_favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE owner_emoji_favorites FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS owner_emoji_favorites_owner_isolation ON owner_emoji_favorites;
CREATE POLICY owner_emoji_favorites_owner_isolation ON owner_emoji_favorites
    FOR ALL
    USING (owner_user_id = _rls_owner_uuid())
    WITH CHECK (owner_user_id = _rls_owner_uuid());

-- Relationship-aware emoji recency: convenience signal, no profiling/analytics.
CREATE TABLE IF NOT EXISTS relationship_emoji_recents (
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    relationship_id     UUID NOT NULL REFERENCES relationship(relationship_id) ON DELETE CASCADE,
    emoji               TEXT NOT NULL,
    use_count           INTEGER NOT NULL DEFAULT 1,
    last_used_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, relationship_id, emoji)
);

CREATE INDEX IF NOT EXISTS idx_relationship_emoji_recents_last_used
    ON relationship_emoji_recents(owner_user_id, relationship_id, last_used_at DESC);

ALTER TABLE relationship_emoji_recents ENABLE ROW LEVEL SECURITY;
ALTER TABLE relationship_emoji_recents FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS relationship_emoji_recents_owner_isolation ON relationship_emoji_recents;
CREATE POLICY relationship_emoji_recents_owner_isolation ON relationship_emoji_recents
    FOR ALL
    USING (owner_user_id = _rls_owner_uuid())
    WITH CHECK (owner_user_id = _rls_owner_uuid());

-- ---------------------------------------------------------------------------
-- 4. Extend vault_item item_type for protected reaction bundles
-- ---------------------------------------------------------------------------
ALTER TABLE vault_item
    DROP CONSTRAINT IF EXISTS vault_item_item_type_check;
ALTER TABLE vault_item
    ADD CONSTRAINT vault_item_item_type_check
    CHECK (item_type IN ('message','card','attachment','message_reactions','status_reactions'));

-- ---------------------------------------------------------------------------
-- 5. Source Card re-verification intent table (foundation, no Internet fetch yet)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS source_card_reverify_intent (
    intent_id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_user_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    card_id             UUID NOT NULL REFERENCES conversation_card(card_id) ON DELETE CASCADE,
    requested_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    state               TEXT NOT NULL DEFAULT 'pending'
        CHECK (state IN ('pending','completed','failed','disabled')),
    reason              TEXT,
    provenance          JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_source_card_reverify_intent_owner
    ON source_card_reverify_intent(owner_user_id, card_id, requested_at DESC);

ALTER TABLE source_card_reverify_intent ENABLE ROW LEVEL SECURITY;
ALTER TABLE source_card_reverify_intent FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS source_card_reverify_intent_owner_isolation ON source_card_reverify_intent;
CREATE POLICY source_card_reverify_intent_owner_isolation ON source_card_reverify_intent
    FOR ALL
    USING (owner_user_id = _rls_owner_uuid())
    WITH CHECK (owner_user_id = _rls_owner_uuid());

-- ---------------------------------------------------------------------------
-- 5. Grants
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'vemoria_app_user') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON conversation_reaction TO vemoria_app_user;
        GRANT SELECT, INSERT, UPDATE, DELETE ON status_reaction TO vemoria_app_user;
        GRANT SELECT, INSERT, UPDATE, DELETE ON owner_emoji_recents TO vemoria_app_user;
        GRANT SELECT, INSERT, UPDATE, DELETE ON owner_emoji_favorites TO vemoria_app_user;
        GRANT SELECT, INSERT, UPDATE, DELETE ON relationship_emoji_recents TO vemoria_app_user;
        GRANT SELECT, INSERT, UPDATE, DELETE ON source_card_reverify_intent TO vemoria_app_user;
    END IF;

    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p2_api') THEN
        GRANT SELECT, INSERT, UPDATE, DELETE ON conversation_reaction TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON status_reaction TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON owner_emoji_recents TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON owner_emoji_favorites TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON relationship_emoji_recents TO mb13_p2_api;
        GRANT SELECT, INSERT, UPDATE, DELETE ON source_card_reverify_intent TO mb13_p2_api;
    END IF;
END $$;
