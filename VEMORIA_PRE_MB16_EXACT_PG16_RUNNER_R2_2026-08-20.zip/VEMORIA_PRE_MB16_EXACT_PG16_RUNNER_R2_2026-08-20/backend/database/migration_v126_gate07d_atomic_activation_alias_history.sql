-- Vemoria Gate07D — attivazione atomica acquisizione, alias nel log e consumer watermark.
-- Additiva. Non migra timeline, ricerca, Evidence Graph o Cerebro.
BEGIN;

INSERT INTO canonical_event_payload_registry(payload_type, schema_version, description)
VALUES ('content_alias.v1', 1, 'Binding storico tra source_content_id e identità canonica cnt_<sha256>')
ON CONFLICT (payload_type, schema_version) DO NOTHING;

ALTER TABLE canonical_content_alias_projection
    ADD COLUMN IF NOT EXISTS last_lamport_clock BIGINT NOT NULL DEFAULT 1
    CHECK (last_lamport_clock >= 1);

CREATE INDEX IF NOT EXISTS idx_canonical_event_operation
    ON canonical_event_log(owner_user_id, operation_id, lamport_clock)
    WHERE operation_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_canonical_acquisition_operation_role
    ON canonical_event_log(owner_user_id, operation_id, event_type)
    WHERE operation_id IS NOT NULL
      AND event_type IN ('CONTENT_IDENTITY_OBSERVED','CONTENT_ALIAS_BOUND','CONTENT_OCCURRENCE_OBSERVED');

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname='canonical_acquisition_operation_required'
    ) THEN
        ALTER TABLE canonical_event_log ADD CONSTRAINT canonical_acquisition_operation_required CHECK (
            event_type NOT IN ('CONTENT_IDENTITY_OBSERVED','CONTENT_ALIAS_BOUND','CONTENT_OCCURRENCE_OBSERVED')
            OR operation_id IS NOT NULL
        );
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname='canonical_content_alias_event_contract'
    ) THEN
        ALTER TABLE canonical_event_log ADD CONSTRAINT canonical_content_alias_event_contract CHECK (
            event_type <> 'CONTENT_ALIAS_BOUND'
            OR (
                payload_type='content_alias.v1'
                AND subject_type='COLLEGAMENTO'
                AND payload ?& ARRAY['source_content_id','canonical_content_id','sha256','source_system']
                AND related_refs @? '$[*] ? (@.relation == "alias_of")'
            )
        );
    END IF;
END $$;

COMMENT ON COLUMN canonical_content_alias_projection.last_lamport_clock IS
    'Ultimo evento alias applicato; la storia completa resta nel canonical_event_log.';
COMMENT ON INDEX uq_canonical_acquisition_operation_role IS
    'Una sola identità, un alias e una occorrenza per ruolo nella stessa operation_id di acquisizione.';

COMMIT;
