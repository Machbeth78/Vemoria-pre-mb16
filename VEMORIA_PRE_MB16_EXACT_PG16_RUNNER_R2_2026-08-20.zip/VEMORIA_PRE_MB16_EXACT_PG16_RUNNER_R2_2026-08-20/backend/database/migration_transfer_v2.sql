-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V4.6 — Transfer Unification Migration
-- Aggiunge colonne per hash server-side e collegamento a eventi_invio
-- Eseguire su DB esistenti che hanno già la tabella transfer

DO $$
BEGIN
    -- Aggiunge file_hash se non esiste
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name='transfer' AND column_name='file_hash'
    ) THEN
        ALTER TABLE transfer ADD COLUMN file_hash TEXT;
    END IF;

    -- Aggiunge evento_invio_id FK se non esiste
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name='transfer' AND column_name='evento_invio_id'
    ) THEN
        ALTER TABLE transfer ADD COLUMN evento_invio_id UUID REFERENCES eventi_invio(id) ON DELETE SET NULL;
    END IF;

    -- Aggiunge oggetto se non esiste
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name='transfer' AND column_name='oggetto'
    ) THEN
        ALTER TABLE transfer ADD COLUMN oggetto TEXT;
    END IF;

    -- Aggiunge corpo se non esiste
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name='transfer' AND column_name='corpo'
    ) THEN
        ALTER TABLE transfer ADD COLUMN corpo TEXT;
    END IF;

    -- Aggiorna constraint status per includere 'downloaded' (se non già presente)
    ALTER TABLE transfer DROP CONSTRAINT IF EXISTS transfer_status_check;
    ALTER TABLE transfer DROP CONSTRAINT IF EXISTS transfer_status_chk;
    ALTER TABLE transfer ADD CONSTRAINT transfer_status_check
        CHECK (status IN ('pending', 'downloaded', 'received', 'expired'));

    RAISE NOTICE 'Migration transfer_v2 completata.';
END $$;
