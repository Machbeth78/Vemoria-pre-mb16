-- VEMORA — Migration V74: Hardening blocco invio / protezione / accettazione snapshot
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo — Tutti i diritti riservati.
--
-- Aggiunge a eventi_invio:
--   view_only          — solo visualizzazione inline, blocca download lato backend
--   download_blocked   — log + rifiuto esplicito richieste download
--   max_views          — numero massimo visualizzazioni consentite (NULL = illimitato)
--   views_count        — contatore aperture reali (incrementato a ogni stream)
--   notice_autore      — testo notice autore/titolarità associato all'invio
--   licenza_testo      — testo licenza/restrizione associato all'invio
--   accettazione_testo_snapshot — snapshot esatto del testo mostrato/accettato al destinatario
--   clausola_ip_snapshot        — snapshot della clausola IP mostrata all'apertura viewer

ALTER TABLE eventi_invio
    ADD COLUMN IF NOT EXISTS view_only                   BOOLEAN  NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS download_blocked            BOOLEAN  NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS max_views                   INTEGER  DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS views_count                 INTEGER  NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS notice_autore               TEXT     DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS licenza_testo               TEXT     DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS accettazione_testo_snapshot TEXT     DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS clausola_ip_snapshot        TEXT     DEFAULT NULL;

COMMENT ON COLUMN eventi_invio.view_only IS
    'Se TRUE il backend serve il file con header inline + no download. Il destinatario può leggere ma non scaricare facilmente.';
COMMENT ON COLUMN eventi_invio.download_blocked IS
    'Se TRUE ogni richiesta con Content-Disposition: attachment viene negata e loggata in timeline.';
COMMENT ON COLUMN eventi_invio.max_views IS
    'Numero massimo di stream del file consentiti. NULL = illimitato. Confrontato con views_count.';
COMMENT ON COLUMN eventi_invio.views_count IS
    'Contatore incrementale delle aperture reali del file via signed-url/stream.';
COMMENT ON COLUMN eventi_invio.notice_autore IS
    'Testo notice autore/titolarità incluso nel proof bundle e mostrato al destinatario.';
COMMENT ON COLUMN eventi_invio.licenza_testo IS
    'Testo licenza o restrizioni d''uso associato a questo specifico invio.';
COMMENT ON COLUMN eventi_invio.accettazione_testo_snapshot IS
    'Snapshot immutabile del testo di accettazione mostrato al destinatario al momento della risposta.';
COMMENT ON COLUMN eventi_invio.clausola_ip_snapshot IS
    'Snapshot della clausola IP mostrata al destinatario all''apertura del viewer.';

-- Indici utili per osservabilità
CREATE INDEX IF NOT EXISTS idx_eventi_view_only        ON eventi_invio(view_only) WHERE view_only = TRUE;
CREATE INDEX IF NOT EXISTS idx_eventi_download_blocked ON eventi_invio(download_blocked) WHERE download_blocked = TRUE;
CREATE INDEX IF NOT EXISTS idx_eventi_max_views        ON eventi_invio(max_views) WHERE max_views IS NOT NULL;

-- Registra migrazione
-- Nota: registrazione migration demandata al migration runner/registry service.
-- Se la migration viene applicata manualmente via SQL puro, usare poi adopt-existing o status nel runner.
