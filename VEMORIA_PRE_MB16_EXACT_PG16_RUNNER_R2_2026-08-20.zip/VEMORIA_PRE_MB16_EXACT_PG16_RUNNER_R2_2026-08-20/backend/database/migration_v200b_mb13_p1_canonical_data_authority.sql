-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
--
-- MB13-P1 R2 — v200b Canonical data authority.
-- Forward-only, idempotent. Does not modify v196, v197, v198a, v198b, v199a or v199b.

BEGIN;

-- ----------------------------------------------------------------------------
-- Envelope table for single-use worker envelopes.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.mb13_p1_worker_envelope (
    envelope_id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    job_id            UUID NOT NULL,
    claim_nonce_hash  TEXT NOT NULL,
    worker_identity   TEXT NOT NULL,
    preflight_id      UUID,
    input_hash        TEXT NOT NULL,
    output_hash       TEXT NOT NULL,
    algorithm_version TEXT NOT NULL,
    normalization_version TEXT NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at        TIMESTAMPTZ NOT NULL,
    consumed_at       TIMESTAMPTZ,
    diff_id           UUID,
    UNIQUE (job_id, envelope_id)
);

ALTER TABLE public.mb13_p1_worker_envelope OWNER TO mb13_p1_writer;
GRANT SELECT, INSERT, UPDATE ON public.mb13_p1_worker_envelope TO mb13_p1_writer;
REVOKE ALL ON public.mb13_p1_worker_envelope FROM PUBLIC;

ALTER TABLE public.mb13_p1_diff_job_queue
    ADD COLUMN IF NOT EXISTS claim_nonce TEXT,
    ADD COLUMN IF NOT EXISTS claimed_by TEXT,
    ADD COLUMN IF NOT EXISTS envelope_id UUID;

ALTER TABLE public.mb13_p1_preflight_state
    ADD COLUMN IF NOT EXISTS job_id UUID,
    ADD COLUMN IF NOT EXISTS claim_nonce_hash TEXT,
    ADD COLUMN IF NOT EXISTS worker_identity TEXT;

ALTER TABLE public.mb13_p1_universal_diff
    ADD COLUMN IF NOT EXISTS envelope_id UUID,
    ADD COLUMN IF NOT EXISTS job_id UUID;

ALTER TABLE public.mb13_p1_universal_diff_revision
    ADD COLUMN IF NOT EXISTS envelope_id UUID,
    ADD COLUMN IF NOT EXISTS job_id UUID;

-- The document-revision append function expects a generated row UUID.
ALTER TABLE public.mb13_p1_document_revision
    ADD COLUMN IF NOT EXISTS revision_id UUID DEFAULT gen_random_uuid();

-- Re-create the document-revision guard as SECURITY INVOKER so that a
-- SECURITY DEFINER append function (owner mb13_p1_executor) is allowed to
-- insert while direct DML from other roles is still rejected.
CREATE OR REPLACE FUNCTION public.mb13_p1_document_revision_guard()
RETURNS trigger AS $$
BEGIN
    IF pg_has_role(current_user, 'mb13_p1_executor', 'MEMBER') THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;
    RAISE EXCEPTION 'mb13_p1_document_revision_direct_dml_blocked';
END;
$$ LANGUAGE plpgsql
SET search_path = pg_catalog, public;

-- The v198a executor-owned overload needs to insert revisions itself.
GRANT INSERT ON public.mb13_p1_document_revision TO mb13_p1_executor;

-- The v199b 9-argument writer-owned overload cannot take row locks on documenti
-- because the writer role lacks UPDATE on that table. Drop it so the 8-argument
-- executor-owned overload is used unambiguously by callers.
DROP FUNCTION IF EXISTS public.mb13_p1_append_document_revision(
    UUID, UUID, INTEGER, TEXT, TEXT, JSONB, TEXT, INTEGER, TEXT
);

-- Enforce monotonic revision sequence in the executor-owned overload.
CREATE OR REPLACE FUNCTION public.mb13_p1_append_document_revision(
    p_owner_user_id UUID,
    p_document_id UUID,
    p_revision INTEGER,
    p_state TEXT,
    p_payload_hash TEXT,
    p_dati_strutturati JSONB,
    p_testo_grezzo TEXT,
    p_supersedes_revision INTEGER DEFAULT NULL
) RETURNS UUID AS $$
DECLARE
    v_last_revision INTEGER;
    v_last_hash TEXT;
    v_doc_owner UUID;
    v_revision_id UUID := gen_random_uuid();
BEGIN
    IF p_state NOT IN ('memorizzato','revoked','superseded') THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_state_invalid';
    END IF;

    SELECT proprietario_id INTO v_doc_owner
      FROM public.documenti
     WHERE id = p_document_id
       AND proprietario_id = p_owner_user_id
     FOR SHARE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_document_not_found_or_owner_mismatch';
    END IF;

    IF p_revision < 1 THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_invalid';
    END IF;

    IF p_revision > 1 THEN
        SELECT revision, payload_hash INTO v_last_revision, v_last_hash
          FROM public.mb13_p1_document_revision
         WHERE owner_user_id = p_owner_user_id
           AND document_id = p_document_id
           AND revision < p_revision
         ORDER BY revision DESC
         LIMIT 1;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p1_document_revision_skipped';
        END IF;
        IF p_supersedes_revision IS DISTINCT FROM v_last_revision THEN
            RAISE EXCEPTION 'mb13_p1_document_revision_supersedes_mismatch';
        END IF;
        IF p_revision <> v_last_revision + 1 THEN
            RAISE EXCEPTION 'mb13_p1_document_revision_skipped';
        END IF;
        IF p_state = 'memorizzato' AND v_last_hash IS NULL THEN
            RAISE EXCEPTION 'mb13_p1_document_revision_baseline_hash_missing';
        END IF;
    END IF;

    IF EXISTS (
        SELECT 1 FROM public.mb13_p1_document_revision
         WHERE owner_user_id = p_owner_user_id
           AND document_id = p_document_id
           AND revision = p_revision
    ) THEN
        RAISE EXCEPTION 'mb13_p1_document_revision_already_exists';
    END IF;

    INSERT INTO public.mb13_p1_document_revision (
        owner_user_id, document_id, revision, state, payload_hash,
        dati_strutturati, testo_grezzo, supersedes_revision, created_at
    ) VALUES (
        p_owner_user_id, p_document_id, p_revision, p_state, p_payload_hash,
        p_dati_strutturati, p_testo_grezzo, p_supersedes_revision, NOW()
    )
    RETURNING revision_id INTO v_revision_id;

    RETURN v_revision_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

-- ----------------------------------------------------------------------------
-- Request diff job: stable request hash, no NOW().
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_request_diff_job(UUID, JSONB, TEXT);
CREATE OR REPLACE FUNCTION public.mb13_p1_request_diff_job(
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT
) RETURNS UUID AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_job_id UUID := gen_random_uuid();
    v_request_hash TEXT;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_api', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_api_role_required';
    END IF;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object'
       OR p_observation_ref->>'id' IS NULL
       OR p_observation_ref->>'revision' IS NULL
       OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
        RAISE EXCEPTION 'mb13_p1_target_owner_mismatch';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM public.mb13_p0_monitor_target
         WHERE owner_user_id = v_owner
           AND monitor_id = p_monitor_id
           AND monitor_state = 'active'
    ) THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;

    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'observation_ref', p_observation_ref,
        'diff_kind', p_diff_kind
    ));

    INSERT INTO public.mb13_p1_diff_job_queue (
        job_id, owner_user_id, monitor_id, observation_ref, diff_kind, status,
        request_hash, created_at, updated_at
    ) VALUES (
        v_job_id, v_owner, p_monitor_id, p_observation_ref, p_diff_kind, 'pending',
        v_request_hash, NOW(), NOW()
    );

    RETURN v_job_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_request_diff_job(UUID, JSONB, TEXT) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_request_diff_job(UUID, JSONB, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_request_diff_job(UUID, JSONB, TEXT) TO mb13_p1_api;

-- ----------------------------------------------------------------------------
-- Claim job for worker: produce a single-use claim nonce.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_claim_job_for_worker();
CREATE OR REPLACE FUNCTION public.mb13_p1_claim_job_for_worker()
RETURNS TABLE(
    job_id UUID,
    owner_user_id UUID,
    monitor_id UUID,
    observation_ref JSONB,
    diff_kind TEXT,
    request_hash TEXT,
    claim_nonce TEXT,
    claimed_by TEXT
) AS $$
DECLARE
    v_job public.mb13_p1_diff_job_queue%ROWTYPE;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_nonce TEXT;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    SELECT * INTO v_job
      FROM public.mb13_p1_diff_job_queue
     WHERE status = 'pending'
     ORDER BY created_at ASC
     FOR UPDATE SKIP LOCKED
     LIMIT 1;

    IF NOT FOUND THEN
        RETURN;
    END IF;

    v_nonce := encode(gen_random_bytes(24), 'base64');

    UPDATE public.mb13_p1_diff_job_queue
       SET status = 'claimed',
           worker_name = v_session_user,
           claimed_by = v_session_user,
           claim_nonce = v_nonce,
           claimed_at = NOW(),
           updated_at = NOW()
     WHERE public.mb13_p1_diff_job_queue.job_id = v_job.job_id;

    RETURN QUERY SELECT v_job.job_id, v_job.owner_user_id, v_job.monitor_id, v_job.observation_ref, v_job.diff_kind, v_job.request_hash, v_nonce, v_session_user;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_claim_job_for_worker() OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_claim_job_for_worker() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_claim_job_for_worker() TO mb13_p1_worker;

-- ----------------------------------------------------------------------------
-- Complete job: verify claim nonce and worker identity.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_complete_job(UUID, TEXT, JSONB, TEXT, UUID);
CREATE OR REPLACE FUNCTION public.mb13_p1_complete_job(
    p_job_id UUID,
    p_status TEXT,
    p_result_payload JSONB,
    p_error_message TEXT,
    p_diff_id UUID,
    p_claim_nonce TEXT DEFAULT NULL,
    p_worker_identity TEXT DEFAULT NULL
) RETURNS VOID AS $$
DECLARE
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_job public.mb13_p1_diff_job_queue%ROWTYPE;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    SELECT * INTO v_job
      FROM public.mb13_p1_diff_job_queue
     WHERE job_id = p_job_id
     FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_job_not_found';
    END IF;

    IF v_job.status <> 'claimed' THEN
        RAISE EXCEPTION 'mb13_p1_job_not_claimed';
    END IF;

    IF v_job.claimed_by IS DISTINCT FROM COALESCE(p_worker_identity, v_session_user) THEN
        RAISE EXCEPTION 'mb13_p1_complete_job_worker_mismatch';
    END IF;

    IF v_job.claim_nonce IS DISTINCT FROM p_claim_nonce THEN
        RAISE EXCEPTION 'mb13_p1_complete_job_nonce_mismatch';
    END IF;

    UPDATE public.mb13_p1_diff_job_queue
       SET status = p_status,
           result_payload = p_result_payload,
           error_message = p_error_message,
           diff_id = p_diff_id,
           completed_at = NOW(),
           updated_at = NOW()
     WHERE job_id = p_job_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_complete_job(UUID, TEXT, JSONB, TEXT, UUID, TEXT, TEXT) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_complete_job(UUID, TEXT, JSONB, TEXT, UUID, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_complete_job(UUID, TEXT, JSONB, TEXT, UUID, TEXT, TEXT) TO mb13_p1_worker;

-- ----------------------------------------------------------------------------
-- Relational provenance resolver: real joins, ordered advisory locks, count checks.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB);
CREATE OR REPLACE FUNCTION public.mb13_p1_resolve_exact_provenance(
    p_owner UUID,
    p_source_refs JSONB,
    p_evidence_refs JSONB
) RETURNS TABLE(
    source_id UUID,
    source_card_id TEXT,
    source_revision_id UUID,
    evidence_id UUID,
    grant_id UUID,
    source_status TEXT,
    evidence_status TEXT,
    grant_status TEXT,
    binding_status TEXT,
    inventory_state TEXT,
    content_hash TEXT
) AS $$
DECLARE
    v_input_count INTEGER;
    v_resolved_count INTEGER;
    v_source_ids UUID[];
    v_grant_ids UUID[];
    v_inventory_ids UUID[];
    v_evidence_ids UUID[];
    v_binding_ids TEXT[];
    v_id UUID;
    v_bid TEXT;
BEGIN
    -- Pass 1: collect referenced IDs in deterministic order.
    SELECT array_agg(DISTINCT s_id ORDER BY s_id)
      INTO v_source_ids
      FROM (
          SELECT DISTINCT NULLIF((sr->>'source_id')::text, '')::UUID AS s_id
            FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) sr
           WHERE sr->>'source_id' IS NOT NULL
          UNION
          SELECT DISTINCT NULLIF((er->>'source_id')::text, '')::UUID AS s_id
            FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) er
           WHERE er->>'source_id' IS NOT NULL
      ) s;

    SELECT array_agg(DISTINCT g_id ORDER BY g_id)
      INTO v_grant_ids
      FROM (
          SELECT DISTINCT NULLIF((sr->>'grant_id')::text, '')::UUID AS g_id
            FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) sr
           WHERE sr->>'grant_id' IS NOT NULL
          UNION
          SELECT DISTINCT NULLIF((er->>'grant_id')::text, '')::UUID AS g_id
            FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) er
           WHERE er->>'grant_id' IS NOT NULL
      ) g;

    SELECT array_agg(DISTINCT i_id ORDER BY i_id)
      INTO v_inventory_ids
      FROM (
          SELECT DISTINCT NULLIF((sr->>'source_revision_id')::text, '')::UUID AS i_id
            FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) sr
           WHERE sr->>'source_revision_id' IS NOT NULL
          UNION
          SELECT DISTINCT NULLIF((er->>'source_revision_id')::text, '')::UUID AS i_id
            FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) er
           WHERE er->>'source_revision_id' IS NOT NULL
      ) i;

    SELECT array_agg(DISTINCT e_id ORDER BY e_id)
      INTO v_evidence_ids
      FROM (
          SELECT DISTINCT NULLIF((sr->>'evidence_id')::text, '')::UUID AS e_id
            FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) sr
           WHERE sr->>'evidence_id' IS NOT NULL
          UNION
          SELECT DISTINCT NULLIF((er->>'evidence_id')::text, '')::UUID AS e_id
            FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) er
           WHERE er->>'evidence_id' IS NOT NULL
      ) e;

    SELECT array_agg(DISTINCT b_id ORDER BY b_id)
      INTO v_binding_ids
      FROM (
          SELECT DISTINCT NULLIF(sr->>'source_card_id', '') AS b_id
            FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) sr
           WHERE sr->>'source_card_id' IS NOT NULL
      ) b;

    -- Pass 2: acquire ordered advisory xact locks (class, id hash) to avoid table UPDATE privilege.
    IF v_source_ids IS NOT NULL AND array_length(v_source_ids, 1) > 0 THEN
        FOREACH v_id IN ARRAY v_source_ids
        LOOP
            PERFORM pg_advisory_xact_lock(hashtextextended(v_id::text, 13101));
        END LOOP;
    END IF;

    IF v_grant_ids IS NOT NULL AND array_length(v_grant_ids, 1) > 0 THEN
        FOREACH v_id IN ARRAY v_grant_ids
        LOOP
            PERFORM pg_advisory_xact_lock(hashtextextended(v_id::text, 13102));
        END LOOP;
    END IF;

    IF v_inventory_ids IS NOT NULL AND array_length(v_inventory_ids, 1) > 0 THEN
        FOREACH v_id IN ARRAY v_inventory_ids
        LOOP
            PERFORM pg_advisory_xact_lock(hashtextextended(v_id::text, 13103));
        END LOOP;
    END IF;

    IF v_evidence_ids IS NOT NULL AND array_length(v_evidence_ids, 1) > 0 THEN
        FOREACH v_id IN ARRAY v_evidence_ids
        LOOP
            PERFORM pg_advisory_xact_lock(hashtextextended(v_id::text, 13104));
        END LOOP;
    END IF;

    IF v_binding_ids IS NOT NULL AND array_length(v_binding_ids, 1) > 0 THEN
        FOREACH v_bid IN ARRAY v_binding_ids
        LOOP
            PERFORM pg_advisory_xact_lock(hashtextextended(v_bid, 13105));
        END LOOP;
    END IF;

    v_input_count := COALESCE(jsonb_array_length(COALESCE(p_source_refs, '[]'::jsonb)), 0)
                   + COALESCE(jsonb_array_length(COALESCE(p_evidence_refs, '[]'::jsonb)), 0);

    -- Pass 3: resolve with real relational joins using NULL-aware equality.
    RETURN QUERY
    WITH refs AS (
        SELECT
            NULLIF((sr->>'source_id')::text, '')::UUID AS r_source_id,
            NULLIF(sr->>'source_card_id', '') AS r_source_card_id,
            NULLIF((sr->>'source_revision_id')::text, '')::UUID AS r_source_revision_id,
            NULLIF((sr->>'evidence_id')::text, '')::UUID AS r_evidence_id,
            NULLIF((sr->>'grant_id')::text, '')::UUID AS r_grant_id
          FROM jsonb_array_elements(COALESCE(p_source_refs, '[]'::jsonb)) sr
        UNION ALL
        SELECT
            NULLIF((er->>'source_id')::text, '')::UUID AS r_source_id,
            NULLIF(er->>'source_card_id', '') AS r_source_card_id,
            NULLIF((er->>'source_revision_id')::text, '')::UUID AS r_source_revision_id,
            NULLIF((er->>'evidence_id')::text, '')::UUID AS r_evidence_id,
            NULLIF((er->>'grant_id')::text, '')::UUID AS r_grant_id
          FROM jsonb_array_elements(COALESCE(p_evidence_refs, '[]'::jsonb)) er
    )
    SELECT
        s.id,
        b.source_card_id,
        i.id,
        e.id,
        g.id,
        s.status,
        'active'::text,
        g.status,
        b.status,
        i.identity_state,
        i.content_hash
    FROM refs r
    LEFT JOIN public.authorized_memory_sources s
           ON s.id IS NOT DISTINCT FROM r.r_source_id
          AND s.user_id = p_owner
    LEFT JOIN public.authorized_memory_consent_grants g
           ON g.id IS NOT DISTINCT FROM r.r_grant_id
          AND g.user_id = p_owner
          AND g.source_id IS NOT DISTINCT FROM s.id
    LEFT JOIN public.authorized_memory_inventory_items i
           ON i.id IS NOT DISTINCT FROM r.r_source_revision_id
          AND i.user_id = p_owner
          AND i.source_id IS NOT DISTINCT FROM s.id
          AND i.grant_id IS NOT DISTINCT FROM g.id
    LEFT JOIN public.authorized_memory_activity_log e
           ON e.id IS NOT DISTINCT FROM r.r_evidence_id
          AND e.user_id = p_owner
          AND e.source_id IS NOT DISTINCT FROM s.id
          AND e.grant_id IS NOT DISTINCT FROM g.id
    LEFT JOIN public.mb12_p0_source_card_binding b
           ON b.source_id IS NOT DISTINCT FROM s.id
          AND b.source_revision_id IS NOT DISTINCT FROM i.id
          AND b.evidence_id IS NOT DISTINCT FROM e.id
          AND b.grant_id IS NOT DISTINCT FROM g.id
          AND b.owner_user_id = p_owner
          AND b.source_card_id IS NOT DISTINCT FROM r.r_source_card_id;

    GET DIAGNOSTICS v_resolved_count = ROW_COUNT;

    IF v_resolved_count <> v_input_count THEN
        RAISE EXCEPTION 'mb13_p1_provenance_count_mismatch';
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_resolve_exact_provenance(UUID, JSONB, JSONB) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION pg_catalog.hashtextextended(TEXT, BIGINT) TO mb13_p1_writer;
GRANT EXECUTE ON FUNCTION pg_catalog.pg_advisory_xact_lock(BIGINT) TO mb13_p1_writer;

-- ----------------------------------------------------------------------------
-- Job-bound preflight overload.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_preflight(
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT,
    p_job_id UUID,
    p_claim_nonce TEXT
) RETURNS UUID AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_job public.mb13_p1_diff_job_queue%ROWTYPE;
    v_preflight_id UUID;
    v_nonce_hash TEXT;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_job_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_job_id_required';
    END IF;
    IF p_claim_nonce IS NULL OR p_claim_nonce = '' THEN
        RAISE EXCEPTION 'mb13_p1_claim_nonce_required';
    END IF;

    SELECT * INTO v_job
      FROM public.mb13_p1_diff_job_queue
     WHERE job_id = p_job_id
       AND owner_user_id = v_owner
     FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_job_not_found';
    END IF;
    IF v_job.status IS DISTINCT FROM 'claimed' THEN
        RAISE EXCEPTION 'mb13_p1_job_not_claimed';
    END IF;
    IF v_job.claimed_by IS DISTINCT FROM v_session_user THEN
        RAISE EXCEPTION 'mb13_p1_worker_not_claimant';
    END IF;
    IF v_job.claim_nonce IS DISTINCT FROM p_claim_nonce THEN
        RAISE EXCEPTION 'mb13_p1_claim_nonce_mismatch';
    END IF;
    IF v_job.envelope_id IS NOT NULL THEN
        RAISE EXCEPTION 'mb13_p1_job_already_completed';
    END IF;

    -- Delegate validation and provenance to the existing 3-arg preflight.
    v_preflight_id := public.mb13_p1_preflight(p_monitor_id, p_observation_ref, p_diff_kind);

    v_nonce_hash := public.mb13_p0_hash_jsonb(to_jsonb(p_claim_nonce));

    UPDATE public.mb13_p1_preflight_state
       SET job_id = p_job_id,
           claim_nonce_hash = v_nonce_hash,
           worker_identity = v_session_user
     WHERE preflight_id = v_preflight_id
       AND owner_user_id = v_owner;

    RETURN v_preflight_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT, UUID, TEXT) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT, UUID, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT, UUID, TEXT) TO mb13_p1_worker;

-- ----------------------------------------------------------------------------
-- Job-bound canonical write_diff overload.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p1_write_diff(
    p_preflight_id UUID,
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT,
    p_changes JSONB,
    p_change_count INTEGER,
    p_material_change_count INTEGER,
    p_diff_state TEXT,
    p_summary TEXT,
    p_algorithm_version TEXT,
    p_normalization_version TEXT,
    p_request_payload JSONB,
    p_result_payload JSONB,
    p_worker_result_envelope JSONB,
    p_job_id UUID,
    p_claim_nonce TEXT
) RETURNS TABLE(diff_id UUID, revision INTEGER, content_hash TEXT, diff_state TEXT, change_count INTEGER, material_change_count INTEGER, summary TEXT, changes JSONB) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_preflight public.mb13_p1_preflight_state%ROWTYPE;
    v_job public.mb13_p1_diff_job_queue%ROWTYPE;
    v_envelope_id UUID;
    v_nonce_hash TEXT;
    v_result RECORD;
    v_diff_id UUID;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_worker_result_envelope IS NULL OR jsonb_typeof(p_worker_result_envelope) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_required';
    END IF;
    IF p_job_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_job_id_required';
    END IF;
    IF p_claim_nonce IS NULL OR p_claim_nonce = '' THEN
        RAISE EXCEPTION 'mb13_p1_claim_nonce_required';
    END IF;

    -- Validate envelope shape.
    IF p_worker_result_envelope->>'envelope_id' IS NULL
       OR p_worker_result_envelope->>'job_id' IS NULL
       OR p_worker_result_envelope->>'preflight_id' IS NULL
       OR p_worker_result_envelope->>'claim_nonce_hash' IS NULL
       OR p_worker_result_envelope->>'worker_identity' IS NULL
       OR p_worker_result_envelope->>'input_hash' IS NULL
       OR p_worker_result_envelope->>'output_hash' IS NULL
       OR p_worker_result_envelope->>'created_at' IS NULL
       OR p_worker_result_envelope->>'expires_at' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_incomplete';
    END IF;

    v_envelope_id := (p_worker_result_envelope->>'envelope_id')::UUID;
    IF EXISTS (SELECT 1 FROM public.mb13_p1_worker_envelope WHERE envelope_id = v_envelope_id) THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_replay_detected';
    END IF;

    SELECT * INTO v_preflight
      FROM public.mb13_p1_preflight_state
     WHERE preflight_id = p_preflight_id
       AND owner_user_id = v_owner
       AND used = FALSE
       AND expires_at > NOW()
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_preflight_invalid_or_expired';
    END IF;

    SELECT * INTO v_job
      FROM public.mb13_p1_diff_job_queue
     WHERE job_id = p_job_id
       AND owner_user_id = v_owner
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_job_not_found';
    END IF;

    IF v_preflight.job_id IS DISTINCT FROM p_job_id THEN
        RAISE EXCEPTION 'mb13_p1_preflight_job_mismatch';
    END IF;
    IF v_job.monitor_id IS DISTINCT FROM p_monitor_id THEN
        RAISE EXCEPTION 'mb13_p1_job_monitor_mismatch';
    END IF;
    IF v_preflight.observation_ref IS DISTINCT FROM p_observation_ref THEN
        RAISE EXCEPTION 'mb13_p1_preflight_observation_mismatch';
    END IF;
    IF v_preflight.diff_kind IS DISTINCT FROM p_diff_kind THEN
        RAISE EXCEPTION 'mb13_p1_preflight_diff_kind_mismatch';
    END IF;
    IF v_job.claimed_by IS DISTINCT FROM v_session_user THEN
        RAISE EXCEPTION 'mb13_p1_complete_job_worker_mismatch';
    END IF;
    IF v_job.claim_nonce IS DISTINCT FROM p_claim_nonce THEN
        RAISE EXCEPTION 'mb13_p1_claim_nonce_mismatch';
    END IF;

    v_nonce_hash := public.mb13_p0_hash_jsonb(to_jsonb(p_claim_nonce));
    IF v_preflight.claim_nonce_hash IS DISTINCT FROM v_nonce_hash THEN
        RAISE EXCEPTION 'mb13_p1_preflight_nonce_hash_mismatch';
    END IF;
    IF v_preflight.claim_nonce_hash IS DISTINCT FROM (p_worker_result_envelope->>'claim_nonce_hash') THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_nonce_hash_mismatch';
    END IF;
    IF v_preflight.preflight_id::text IS DISTINCT FROM p_worker_result_envelope->>'preflight_id' THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_preflight_mismatch';
    END IF;
    IF p_job_id::text IS DISTINCT FROM p_worker_result_envelope->>'job_id' THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_job_mismatch';
    END IF;
    IF v_session_user IS DISTINCT FROM p_worker_result_envelope->>'worker_identity' THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_identity_mismatch';
    END IF;

    IF (p_worker_result_envelope->>'expires_at')::timestamptz <= NOW() THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_expired';
    END IF;

    -- Record envelope as consumed.
    INSERT INTO public.mb13_p1_worker_envelope (
        envelope_id, job_id, claim_nonce_hash, worker_identity, preflight_id,
        input_hash, output_hash, algorithm_version, normalization_version,
        created_at, expires_at, consumed_at
    ) VALUES (
        v_envelope_id, p_job_id, v_preflight.claim_nonce_hash, v_session_user, p_preflight_id,
        p_worker_result_envelope->>'input_hash', p_worker_result_envelope->>'output_hash',
        p_worker_result_envelope->>'algorithm_version', p_worker_result_envelope->>'normalization_version',
        (p_worker_result_envelope->>'created_at')::timestamptz,
        (p_worker_result_envelope->>'expires_at')::timestamptz,
        NOW()
    );

    -- Delegate canonical diff write to the existing 14-arg write_diff.
    SELECT * INTO v_result FROM public.mb13_p1_write_diff(
        p_preflight_id, p_monitor_id, p_observation_ref, p_diff_kind,
        p_changes, p_change_count, p_material_change_count, p_diff_state, p_summary,
        p_algorithm_version, p_normalization_version, p_request_payload, p_result_payload,
        p_worker_result_envelope
    );
    IF v_result IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_write_diff_no_result';
    END IF;

    v_diff_id := v_result.diff_id;

    UPDATE public.mb13_p1_universal_diff
       SET envelope_id = v_envelope_id,
           job_id = p_job_id
     WHERE public.mb13_p1_universal_diff.diff_id = v_diff_id
       AND public.mb13_p1_universal_diff.owner_user_id = v_owner;

    RETURN QUERY SELECT v_result.diff_id, v_result.revision, v_result.content_hash, v_result.diff_state,
                        v_result.change_count, v_result.material_change_count, v_result.summary, v_result.changes;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB, UUID, TEXT) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB, UUID, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB, UUID, TEXT) TO mb13_p1_worker;

-- The canonical job-bound functions need to read and finalize jobs.
GRANT SELECT, UPDATE ON public.mb13_p1_diff_job_queue TO mb13_p1_writer;

-- The legacy 3-arg preflight and 14-arg write_diff must not be reachable from the worker role.
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT) FROM mb13_p1_worker;
REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB) FROM mb13_p1_worker;

COMMIT;
