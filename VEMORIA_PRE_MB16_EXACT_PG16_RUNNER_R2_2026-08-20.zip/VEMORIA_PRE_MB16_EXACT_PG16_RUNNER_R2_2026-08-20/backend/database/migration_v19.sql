-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V3.8 — Migration V19 — Performance Layer
-- Indici composti e ottimizzazioni query

-- document_metadata: chiave+valore per lookup rapido
CREATE INDEX IF NOT EXISTS idx_metadata_chiave_valore
    ON document_metadata(chiave, valore);

-- search_index: ricerca testuale già coperta da GIN V17
-- Aggiunta indice su creato_il per ordinamento
CREATE INDEX IF NOT EXISTS idx_search_creato
    ON search_index(creato_il DESC);

-- document_insight: tipo+confidenza per filtri per qualità
CREATE INDEX IF NOT EXISTS idx_insight_tipo_conf
    ON document_insight(tipo_insight, confidenza DESC);

-- timeline_event: indice composto per query principale
CREATE INDEX IF NOT EXISTS idx_timeline_compound
    ON timeline_event(target_tipo, target_id, creato_il DESC);

-- document_lifecycle: indice su documento+creato per timeline sintetica
CREATE INDEX IF NOT EXISTS idx_lifecycle_doc_data
    ON document_lifecycle(documento_id, creato_il DESC);
