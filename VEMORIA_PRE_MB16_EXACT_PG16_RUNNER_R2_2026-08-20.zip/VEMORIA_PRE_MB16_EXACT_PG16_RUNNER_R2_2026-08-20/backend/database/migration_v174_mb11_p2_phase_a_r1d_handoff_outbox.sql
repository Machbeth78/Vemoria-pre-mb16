-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB11-P2 Phase A R1D — Idempotent production handoff outbox to MB9/Gemello.
-- Additive, idempotent. Preserves MB10 results and enables retry without duplicate
-- source or canonical identity registration.

BEGIN;

CREATE TABLE IF NOT EXISTS canonical_identity_handoff_outbox (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    outbox_id TEXT NOT NULL,
    mb10_result_id TEXT NOT NULL,
    source_card_id TEXT,
    canonical_id TEXT NOT NULL,
    source_id TEXT NOT NULL,
    source_revision_id TEXT NOT NULL,
    content_sha256 TEXT NOT NULL,
    media_kind TEXT NOT NULL,
    consent_id TEXT NOT NULL,
    consent_revision INT NOT NULL DEFAULT 0,
    status TEXT NOT NULL CHECK (status IN ('pending','completed','failed')),
    attempts INT NOT NULL DEFAULT 0,
    mb9_source_version_id TEXT,
    last_error TEXT,
    source_locator TEXT,
    original_filename TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, outbox_id),
    UNIQUE (owner_user_id, mb10_result_id)
);

-- Ensure the column exists when the migration is re-applied to a pre-R1D database.
ALTER TABLE canonical_identity_handoff_outbox
    ADD COLUMN IF NOT EXISTS mb9_source_version_id TEXT;

CREATE INDEX IF NOT EXISTS idx_canonical_identity_handoff_outbox_owner_status
    ON canonical_identity_handoff_outbox(owner_user_id, status);

ALTER TABLE canonical_identity_handoff_outbox ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_identity_handoff_outbox FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS canonical_identity_handoff_outbox_owner_policy ON canonical_identity_handoff_outbox;
CREATE POLICY canonical_identity_handoff_outbox_owner_policy ON canonical_identity_handoff_outbox
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID)
    WITH CHECK (owner_user_id = current_setting('app.owner_id', true)::UUID);

COMMIT;
