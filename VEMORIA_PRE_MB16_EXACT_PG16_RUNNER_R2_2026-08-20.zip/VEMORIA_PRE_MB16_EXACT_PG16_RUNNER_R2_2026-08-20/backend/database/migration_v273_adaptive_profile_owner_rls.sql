-- Vemoria MB0→MB15 audit convergence — adaptive profile owner RLS.
-- v96 declares both tables private to the owner; v273 makes that invariant a
-- database policy rather than only an application-layer convention.
BEGIN;

ALTER TABLE user_operational_profile ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_operational_profile FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS user_operational_profile_owner_isolation ON user_operational_profile;
CREATE POLICY user_operational_profile_owner_isolation ON user_operational_profile
    USING (utente_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (utente_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

ALTER TABLE user_corrections ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_corrections FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS user_corrections_owner_isolation ON user_corrections;
CREATE POLICY user_corrections_owner_isolation ON user_corrections
    USING (utente_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (utente_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

COMMIT;
