-- Gate08B — Active Workfile / Fascicolo di Lavoro Attivo
-- Static schema contract. Runtime PostgreSQL probe NON ESEGUITO.

CREATE TABLE IF NOT EXISTS active_workfile_manifest_gate08b (
    id BIGSERIAL PRIMARY KEY,
    owner_id UUID NOT NULL,
    workfile_id TEXT NOT NULL,
    title TEXT NOT NULL,
    scope_type TEXT NOT NULL,
    state TEXT NOT NULL,
    encrypted_payload BYTEA,
    payload_sha256 TEXT NOT NULL,
    source_chain_sha256 TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revoked_at TIMESTAMPTZ,
    CHECK (state IN ('DRAFT','ACTIVE','PAUSED','WAITING_FOR_USER','COMPLETED','REVOKED')),
    CHECK (scope_type IN ('FREE_DESK','RELATION','PRACTICE','DOCUMENT','CONSUMER_TASK','VERTICAL_TASK')),
    UNIQUE(owner_id, workfile_id)
);

CREATE TABLE IF NOT EXISTS active_workfile_checkpoint_gate08b (
    id BIGSERIAL PRIMARY KEY,
    owner_id UUID NOT NULL,
    workfile_id TEXT NOT NULL,
    checkpoint_hash TEXT NOT NULL,
    previous_checkpoint_hash TEXT NOT NULL,
    encrypted_delta BYTEA,
    delta_sha256 TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_id, workfile_id, checkpoint_hash)
);

CREATE TABLE IF NOT EXISTS active_workfile_revocation_gate08b (
    id BIGSERIAL PRIMARY KEY,
    owner_id UUID NOT NULL,
    workfile_id TEXT NOT NULL,
    revocation_scope TEXT NOT NULL,
    tombstone_hash TEXT NOT NULL,
    revoked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (revocation_scope IN ('WORKFILE_ONLY','WORKFILE_AND_CHECKPOINTS','WORKFILE_DRAFTS_ONLY')),
    UNIQUE(owner_id, workfile_id)
);

COMMENT ON TABLE active_workfile_manifest_gate08b IS 'Gate08B static contract: Fascicolo di Lavoro Attivo owner-scoped, encrypted-at-rest required in runtime. Runtime DB probe non eseguito.';
COMMENT ON TABLE active_workfile_checkpoint_gate08b IS 'Gate08B static contract: append-only checkpoint hash chain. Runtime DB probe non eseguito.';
COMMENT ON TABLE active_workfile_revocation_gate08b IS 'Gate08B static contract: granular revocation tombstone. Runtime DB probe non eseguito.';
