-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA P0/P1 Adversarial Closure — v237
-- Owner isolation for automation_rule and automation_event.

DO $$
DECLARE
    v_role name;
BEGIN
    -- Add owner column to automation tables
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'automation_rule' AND column_name = 'owner_user_id'
    ) THEN
        ALTER TABLE automation_rule ADD COLUMN owner_user_id UUID;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'automation_event' AND column_name = 'owner_user_id'
    ) THEN
        ALTER TABLE automation_event ADD COLUMN owner_user_id UUID;
    END IF;

    -- Deterministic backfill:
    -- 1. Try to backfill automation_event from the target document/dossier/event owner.
    UPDATE automation_event ae
    SET owner_user_id = COALESCE(
        (SELECT d.proprietario_id FROM documenti d WHERE d.id = ae.target_id::uuid LIMIT 1),
        (SELECT dos.proprietario_id FROM dossier dos WHERE dos.id = ae.target_id::uuid LIMIT 1),
        (SELECT ei.mittente_id FROM eventi_invio ei WHERE ei.id = ae.target_id::uuid LIMIT 1)
    )
    WHERE ae.owner_user_id IS NULL;

    -- 2. Propagate owner from events to their rule.
    UPDATE automation_rule ar
    SET owner_user_id = sub.owner
    FROM (
        SELECT rule_id, MAX(owner_user_id::text)::uuid AS owner
        FROM automation_event
        WHERE owner_user_id IS NOT NULL
        GROUP BY rule_id
    ) sub
    WHERE ar.id = sub.rule_id AND ar.owner_user_id IS NULL;

    -- 3. Any rule that still has no owner is assigned the system sentinel.
    --    This makes legacy/global rules visible only when app.owner_id is the sentinel,
    --    which normal user sessions never set. This is fail-closed.
    UPDATE automation_rule SET owner_user_id = '00000000-0000-0000-0000-000000000000'::uuid
    WHERE owner_user_id IS NULL;

    -- 4. Events whose rule got the sentinel inherit it as well.
    UPDATE automation_event ae
    SET owner_user_id = ar.owner_user_id
    FROM automation_rule ar
    WHERE ae.rule_id = ar.id AND ae.owner_user_id IS NULL;

    UPDATE automation_event SET owner_user_id = '00000000-0000-0000-0000-000000000000'::uuid
    WHERE owner_user_id IS NULL;

    -- Make columns NOT NULL now that they are populated
    ALTER TABLE automation_rule ALTER COLUMN owner_user_id SET NOT NULL;
    ALTER TABLE automation_event ALTER COLUMN owner_user_id SET NOT NULL;

    -- RLS owner policy using the canonical app.owner_id GUC.
    -- NULLIF(... , '') handles the case where app.owner_id is not set.
    ALTER TABLE automation_rule ENABLE ROW LEVEL SECURITY;
    ALTER TABLE automation_rule FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS automation_rule_owner_policy ON automation_rule;
    CREATE POLICY automation_rule_owner_policy ON automation_rule
        FOR ALL TO PUBLIC
        USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
        WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

    ALTER TABLE automation_event ENABLE ROW LEVEL SECURITY;
    ALTER TABLE automation_event FORCE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS automation_event_owner_policy ON automation_event;
    CREATE POLICY automation_event_owner_policy ON automation_event
        FOR ALL TO PUBLIC
        USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
        WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

    -- Minimal per-role grants (conditional on role existence).
    FOR v_role IN SELECT unnest(ARRAY['test_app', 'vemora_user', 'app']::name[])
    LOOP
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = v_role) THEN
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE automation_rule TO %I', v_role);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE automation_event TO %I', v_role);
        END IF;
    END LOOP;
END $$;
