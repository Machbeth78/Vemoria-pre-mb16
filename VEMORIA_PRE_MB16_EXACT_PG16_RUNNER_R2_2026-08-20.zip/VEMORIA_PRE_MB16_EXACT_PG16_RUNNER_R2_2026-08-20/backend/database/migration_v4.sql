-- ============================================================
-- VEMORA — Migration V4 — Modulo Invio (engine interno)
-- Ideatore: Devoti Massimo
-- Regola: tutte le tabelle sono append-only — nessun UPDATE.
-- ============================================================

-- ── Tabella eventi invio ────────────────────────────────────
CREATE TABLE IF NOT EXISTS eventi_invio (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    mittente_id     UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    documento_id    UUID REFERENCES documenti(id) ON DELETE SET NULL,
    destinatario    TEXT NOT NULL,
    oggetto         TEXT,
    corpo           TEXT,
    allegato_nome   TEXT,
    allegato_hash   TEXT,
    stato           TEXT NOT NULL DEFAULT 'creato',
    token_invio     TEXT UNIQUE,
    creato_il       TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_eventi_mittente ON eventi_invio(mittente_id);
CREATE INDEX IF NOT EXISTS idx_eventi_stato    ON eventi_invio(stato);
CREATE INDEX IF NOT EXISTS idx_eventi_token    ON eventi_invio(token_invio);
CREATE INDEX IF NOT EXISTS idx_eventi_creato   ON eventi_invio(creato_il DESC);

-- ── Tabella timeline — separata, immutabile, append-only ────
-- Ogni cambio di stato è una nuova riga. Nessun UPDATE.
CREATE TABLE IF NOT EXISTS timeline_eventi (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    evento_id       UUID NOT NULL REFERENCES eventi_invio(id) ON DELETE CASCADE,
    stato           TEXT NOT NULL,
                    -- creato | inviato | consegnato | aperto | scaduto | errore
    dettaglio       TEXT,
    registrato_il   TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_timeline_evento    ON timeline_eventi(evento_id);
CREATE INDEX IF NOT EXISTS idx_timeline_registrato ON timeline_eventi(registrato_il);
