-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
--
-- MB13-P1 R2 — v201a Hard runtime and job boundary.
-- Forward-only, idempotent. Does not modify v196-v200b.

BEGIN;

-- ----------------------------------------------------------------------------
-- Enforce one preflight, one envelope and one diff per job.
-- ----------------------------------------------------------------------------
CREATE UNIQUE INDEX IF NOT EXISTS ix_mb13_p1_preflight_state_one_per_job
    ON public.mb13_p1_preflight_state(job_id)
    WHERE job_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS ix_mb13_p1_worker_envelope_one_per_job
    ON public.mb13_p1_worker_envelope(job_id);

CREATE UNIQUE INDEX IF NOT EXISTS ix_mb13_p1_universal_diff_one_per_job
    ON public.mb13_p1_universal_diff(job_id)
    WHERE job_id IS NOT NULL;

-- ----------------------------------------------------------------------------
-- Job-bound preflight: exact binding before delegating to provenance preflight.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_preflight(UUID, JSONB, TEXT, UUID, TEXT);
CREATE OR REPLACE FUNCTION public.mb13_p1_preflight(
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT,
    p_job_id UUID,
    p_claim_nonce TEXT
) RETURNS UUID AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_job public.mb13_p1_diff_job_queue%ROWTYPE;
    v_preflight_id UUID;
    v_nonce_hash TEXT;
    v_expected_request_hash TEXT;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_job_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_job_id_required';
    END IF;
    IF p_claim_nonce IS NULL OR p_claim_nonce = '' THEN
        RAISE EXCEPTION 'mb13_p1_claim_nonce_required';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object'
       OR p_observation_ref->>'id' IS NULL
       OR p_observation_ref->>'revision' IS NULL
       OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
        RAISE EXCEPTION 'mb13_p1_target_owner_mismatch';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;

    SELECT * INTO v_job
      FROM public.mb13_p1_diff_job_queue
     WHERE job_id = p_job_id
       AND owner_user_id = v_owner
     FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_job_not_found';
    END IF;
    IF v_job.status IS DISTINCT FROM 'claimed' THEN
        RAISE EXCEPTION 'mb13_p1_job_not_claimed';
    END IF;
    IF v_job.claimed_by IS DISTINCT FROM v_session_user THEN
        RAISE EXCEPTION 'mb13_p1_worker_not_claimant';
    END IF;
    IF v_job.claim_nonce IS DISTINCT FROM p_claim_nonce THEN
        RAISE EXCEPTION 'mb13_p1_claim_nonce_mismatch';
    END IF;
    IF v_job.envelope_id IS NOT NULL THEN
        RAISE EXCEPTION 'mb13_p1_job_already_completed';
    END IF;
    IF v_job.monitor_id IS DISTINCT FROM p_monitor_id THEN
        RAISE EXCEPTION 'mb13_p1_job_monitor_mismatch';
    END IF;
    IF v_job.observation_ref IS DISTINCT FROM p_observation_ref THEN
        RAISE EXCEPTION 'mb13_p1_job_observation_mismatch';
    END IF;
    IF v_job.diff_kind IS DISTINCT FROM p_diff_kind THEN
        RAISE EXCEPTION 'mb13_p1_job_diff_kind_mismatch';
    END IF;

    v_expected_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'observation_ref', p_observation_ref,
        'diff_kind', p_diff_kind
    ));
    IF v_job.request_hash IS DISTINCT FROM v_expected_request_hash THEN
        RAISE EXCEPTION 'mb13_p1_job_request_hash_mismatch';
    END IF;

    -- One preflight per job.
    IF EXISTS (
        SELECT 1 FROM public.mb13_p1_preflight_state
         WHERE job_id = p_job_id
    ) THEN
        RAISE EXCEPTION 'mb13_p1_preflight_already_exists_for_job';
    END IF;

    -- Delegate provenance validation and preflight creation to the 3-arg function.
    v_preflight_id := public.mb13_p1_preflight(p_monitor_id, p_observation_ref, p_diff_kind);

    v_nonce_hash := public.mb13_p0_hash_jsonb(to_jsonb(p_claim_nonce));

    UPDATE public.mb13_p1_preflight_state
       SET job_id = p_job_id,
           claim_nonce_hash = v_nonce_hash,
           worker_identity = v_session_user,
           request_hash = v_job.request_hash
     WHERE preflight_id = v_preflight_id
       AND owner_user_id = v_owner;

    RETURN v_preflight_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT, UUID, TEXT) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT, UUID, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_preflight(UUID, JSONB, TEXT, UUID, TEXT) TO mb13_p1_worker;

-- ----------------------------------------------------------------------------
-- Job-bound write_diff: one envelope per job and exact binding.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB, UUID, TEXT);
CREATE OR REPLACE FUNCTION public.mb13_p1_write_diff(
    p_preflight_id UUID,
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT,
    p_changes JSONB,
    p_change_count INTEGER,
    p_material_change_count INTEGER,
    p_diff_state TEXT,
    p_summary TEXT,
    p_algorithm_version TEXT,
    p_normalization_version TEXT,
    p_request_payload JSONB,
    p_result_payload JSONB,
    p_worker_result_envelope JSONB,
    p_job_id UUID,
    p_claim_nonce TEXT
) RETURNS TABLE(diff_id UUID, revision INTEGER, content_hash TEXT, diff_state TEXT, change_count INTEGER, material_change_count INTEGER, summary TEXT, changes JSONB) AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
    v_preflight public.mb13_p1_preflight_state%ROWTYPE;
    v_job public.mb13_p1_diff_job_queue%ROWTYPE;
    v_envelope_id UUID;
    v_nonce_hash TEXT;
    v_result RECORD;
    v_diff_id UUID;
    v_existing_job_id UUID;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_worker', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_worker_role_required';
    END IF;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_worker_result_envelope IS NULL OR jsonb_typeof(p_worker_result_envelope) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_required';
    END IF;
    IF p_job_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_job_id_required';
    END IF;
    IF p_claim_nonce IS NULL OR p_claim_nonce = '' THEN
        RAISE EXCEPTION 'mb13_p1_claim_nonce_required';
    END IF;

    -- Validate envelope shape.
    IF p_worker_result_envelope->>'envelope_id' IS NULL
       OR p_worker_result_envelope->>'job_id' IS NULL
       OR p_worker_result_envelope->>'preflight_id' IS NULL
       OR p_worker_result_envelope->>'claim_nonce_hash' IS NULL
       OR p_worker_result_envelope->>'worker_identity' IS NULL
       OR p_worker_result_envelope->>'input_hash' IS NULL
       OR p_worker_result_envelope->>'output_hash' IS NULL
       OR p_worker_result_envelope->>'created_at' IS NULL
       OR p_worker_result_envelope->>'expires_at' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_incomplete';
    END IF;

    v_envelope_id := (p_worker_result_envelope->>'envelope_id')::UUID;
    IF EXISTS (SELECT 1 FROM public.mb13_p1_worker_envelope WHERE envelope_id = v_envelope_id) THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_replay_detected';
    END IF;
    IF EXISTS (SELECT 1 FROM public.mb13_p1_worker_envelope WHERE job_id = p_job_id) THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_already_exists_for_job';
    END IF;

    SELECT * INTO v_preflight
      FROM public.mb13_p1_preflight_state
     WHERE preflight_id = p_preflight_id
       AND owner_user_id = v_owner
       AND used = FALSE
       AND expires_at > NOW()
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_preflight_invalid_or_expired';
    END IF;

    SELECT * INTO v_job
      FROM public.mb13_p1_diff_job_queue
     WHERE job_id = p_job_id
       AND owner_user_id = v_owner
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_job_not_found';
    END IF;

    IF v_preflight.job_id IS DISTINCT FROM p_job_id THEN
        RAISE EXCEPTION 'mb13_p1_preflight_job_mismatch';
    END IF;
    IF v_job.monitor_id IS DISTINCT FROM p_monitor_id THEN
        RAISE EXCEPTION 'mb13_p1_job_monitor_mismatch';
    END IF;
    IF v_preflight.observation_ref IS DISTINCT FROM p_observation_ref THEN
        RAISE EXCEPTION 'mb13_p1_preflight_observation_mismatch';
    END IF;
    IF v_preflight.diff_kind IS DISTINCT FROM p_diff_kind THEN
        RAISE EXCEPTION 'mb13_p1_preflight_diff_kind_mismatch';
    END IF;
    IF v_job.observation_ref IS DISTINCT FROM p_observation_ref THEN
        RAISE EXCEPTION 'mb13_p1_job_observation_mismatch';
    END IF;
    IF v_job.diff_kind IS DISTINCT FROM p_diff_kind THEN
        RAISE EXCEPTION 'mb13_p1_job_diff_kind_mismatch';
    END IF;
    IF v_job.claimed_by IS DISTINCT FROM v_session_user THEN
        RAISE EXCEPTION 'mb13_p1_complete_job_worker_mismatch';
    END IF;
    IF v_job.claim_nonce IS DISTINCT FROM p_claim_nonce THEN
        RAISE EXCEPTION 'mb13_p1_claim_nonce_mismatch';
    END IF;
    IF v_preflight.request_hash IS DISTINCT FROM v_job.request_hash THEN
        RAISE EXCEPTION 'mb13_p1_preflight_request_hash_mismatch';
    END IF;

    v_nonce_hash := public.mb13_p0_hash_jsonb(to_jsonb(p_claim_nonce));
    IF v_preflight.claim_nonce_hash IS DISTINCT FROM v_nonce_hash THEN
        RAISE EXCEPTION 'mb13_p1_preflight_nonce_hash_mismatch';
    END IF;
    IF v_preflight.claim_nonce_hash IS DISTINCT FROM (p_worker_result_envelope->>'claim_nonce_hash') THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_nonce_hash_mismatch';
    END IF;
    IF v_preflight.preflight_id::text IS DISTINCT FROM p_worker_result_envelope->>'preflight_id' THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_preflight_mismatch';
    END IF;
    IF p_job_id::text IS DISTINCT FROM p_worker_result_envelope->>'job_id' THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_job_mismatch';
    END IF;
    IF v_session_user IS DISTINCT FROM p_worker_result_envelope->>'worker_identity' THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_identity_mismatch';
    END IF;

    IF (p_worker_result_envelope->>'expires_at')::timestamptz <= NOW() THEN
        RAISE EXCEPTION 'mb13_p1_worker_envelope_expired';
    END IF;

    IF v_job.envelope_id IS NOT NULL OR v_job.diff_id IS NOT NULL THEN
        RAISE EXCEPTION 'mb13_p1_job_already_completed';
    END IF;

    -- Record the single-use envelope as consumed.
    INSERT INTO public.mb13_p1_worker_envelope (
        envelope_id, job_id, claim_nonce_hash, worker_identity, preflight_id,
        input_hash, output_hash, algorithm_version, normalization_version,
        created_at, expires_at, consumed_at
    ) VALUES (
        v_envelope_id, p_job_id, v_preflight.claim_nonce_hash, v_session_user, p_preflight_id,
        p_worker_result_envelope->>'input_hash', p_worker_result_envelope->>'output_hash',
        p_worker_result_envelope->>'algorithm_version', p_worker_result_envelope->>'normalization_version',
        (p_worker_result_envelope->>'created_at')::timestamptz,
        (p_worker_result_envelope->>'expires_at')::timestamptz,
        NOW()
    );

    -- Delegate canonical diff creation to the provenance-aware writer.
    SELECT * INTO v_result FROM public.mb13_p1_write_diff(
        p_preflight_id, p_monitor_id, p_observation_ref, p_diff_kind,
        p_changes, p_change_count, p_material_change_count, p_diff_state, p_summary,
        p_algorithm_version, p_normalization_version, p_request_payload, p_result_payload,
        p_worker_result_envelope
    );
    IF v_result IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_write_diff_no_result';
    END IF;

    v_diff_id := v_result.diff_id;

    -- Bind the canonical diff to this job only if it is not already bound to another job.
    SELECT d.job_id INTO v_existing_job_id
      FROM public.mb13_p1_universal_diff d
     WHERE d.diff_id = v_diff_id
       AND d.owner_user_id = v_owner;

    IF v_existing_job_id IS NOT NULL AND v_existing_job_id IS DISTINCT FROM p_job_id THEN
        RAISE EXCEPTION 'mb13_p1_diff_already_bound_to_another_job';
    END IF;

    UPDATE public.mb13_p1_universal_diff
       SET envelope_id = v_envelope_id,
           job_id = p_job_id
     WHERE public.mb13_p1_universal_diff.diff_id = v_diff_id
       AND public.mb13_p1_universal_diff.owner_user_id = v_owner
       AND (public.mb13_p1_universal_diff.job_id IS NULL OR public.mb13_p1_universal_diff.job_id = p_job_id);

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p1_universal_diff_bind_failed';
    END IF;

    -- Complete the job atomically in the same transaction as the diff and event.
    UPDATE public.mb13_p1_diff_job_queue
       SET envelope_id = v_envelope_id,
           diff_id = v_diff_id,
           status = 'completed',
           result_payload = jsonb_build_object('diff_id', v_diff_id),
           completed_at = NOW(),
           updated_at = NOW()
     WHERE job_id = p_job_id
       AND owner_user_id = v_owner;

    RETURN QUERY SELECT v_result.diff_id, v_result.revision, v_result.content_hash, v_result.diff_state,
                        v_result.change_count, v_result.material_change_count, v_result.summary, v_result.changes;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB, UUID, TEXT) OWNER TO mb13_p1_writer;
REVOKE ALL ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB, UUID, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_write_diff(UUID, UUID, JSONB, TEXT, JSONB, INTEGER, INTEGER, TEXT, TEXT, TEXT, TEXT, JSONB, JSONB, JSONB, UUID, TEXT) TO mb13_p1_worker;

-- ----------------------------------------------------------------------------
-- Idempotent job request: a completed identical request returns the same job.
-- This preserves content-hash idempotency while still enforcing one diff per job.
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p1_request_diff_job(UUID, JSONB, TEXT);
CREATE OR REPLACE FUNCTION public.mb13_p1_request_diff_job(
    p_monitor_id UUID,
    p_observation_ref JSONB,
    p_diff_kind TEXT
) RETURNS UUID AS $$
DECLARE
    v_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_job_id UUID;
    v_request_hash TEXT;
    v_session_user TEXT := session_user;
    v_is_superuser BOOLEAN;
BEGIN
    SELECT rolsuper INTO v_is_superuser FROM pg_catalog.pg_roles WHERE rolname = v_session_user;
    IF NOT (pg_catalog.pg_has_role(v_session_user, 'mb13_p1_api', 'MEMBER') OR COALESCE(v_is_superuser, FALSE)) THEN
        RAISE EXCEPTION 'mb13_p1_api_role_required';
    END IF;

    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_owner_missing';
    END IF;
    IF p_monitor_id IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_monitor_identity_invalid';
    END IF;
    IF jsonb_typeof(p_observation_ref) <> 'object'
       OR p_observation_ref->>'id' IS NULL
       OR p_observation_ref->>'revision' IS NULL
       OR p_observation_ref->>'payload_hash' IS NULL THEN
        RAISE EXCEPTION 'mb13_p1_observation_ref_invalid';
    END IF;
    IF p_observation_ref->>'owner_user_id' IS DISTINCT FROM v_owner::text THEN
        RAISE EXCEPTION 'mb13_p1_target_owner_mismatch';
    END IF;
    IF p_diff_kind NOT IN ('structured','text') THEN
        RAISE EXCEPTION 'mb13_p1_diff_kind_invalid';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM public.mb13_p0_monitor_target
         WHERE owner_user_id = v_owner
           AND monitor_id = p_monitor_id
           AND monitor_state = 'active'
    ) THEN
        RAISE EXCEPTION 'mb13_p1_monitor_not_active';
    END IF;

    v_request_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
        'owner_user_id', v_owner,
        'monitor_id', p_monitor_id,
        'observation_ref', p_observation_ref,
        'diff_kind', p_diff_kind
    ));

    -- Idempotency: an already-completed identical request returns the same job.
    SELECT job_id INTO v_job_id
      FROM public.mb13_p1_diff_job_queue
     WHERE owner_user_id = v_owner
       AND monitor_id = p_monitor_id
       AND request_hash = v_request_hash
       AND status = 'completed'
       AND diff_id IS NOT NULL
     ORDER BY completed_at DESC
     LIMIT 1;

    IF FOUND THEN
        RETURN v_job_id;
    END IF;

    v_job_id := gen_random_uuid();

    INSERT INTO public.mb13_p1_diff_job_queue (
        job_id, owner_user_id, monitor_id, observation_ref, diff_kind, status,
        request_hash, created_at, updated_at
    ) VALUES (
        v_job_id, v_owner, p_monitor_id, p_observation_ref, p_diff_kind, 'pending',
        v_request_hash, NOW(), NOW()
    );

    RETURN v_job_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p1_request_diff_job(UUID, JSONB, TEXT) OWNER TO mb13_p1_executor;
REVOKE ALL ON FUNCTION public.mb13_p1_request_diff_job(UUID, JSONB, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p1_request_diff_job(UUID, JSONB, TEXT) TO mb13_p1_api;

COMMIT;
