-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA — Migration V89: contesto operativo gruppi chat
-- Estende i gruppi per supportare mini gruppi evento/pratica e contesto esplicito.

ALTER TABLE chat_gruppi
    ADD COLUMN IF NOT EXISTS gruppo_tipo TEXT NOT NULL DEFAULT 'work';

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'chk_chat_gruppi_tipo'
    ) THEN
        ALTER TABLE chat_gruppi
            ADD CONSTRAINT chk_chat_gruppi_tipo
            CHECK (gruppo_tipo IN ('work', 'event', 'practice', 'family', 'project'));
    END IF;
END $$;

ALTER TABLE chat_gruppi
    ADD COLUMN IF NOT EXISTS linked_target_type TEXT;

ALTER TABLE chat_gruppi
    ADD COLUMN IF NOT EXISTS linked_target_id TEXT;

ALTER TABLE chat_gruppi
    ADD COLUMN IF NOT EXISTS linked_target_label TEXT;

CREATE INDEX IF NOT EXISTS idx_chat_gruppi_tipo ON chat_gruppi(gruppo_tipo);
CREATE INDEX IF NOT EXISTS idx_chat_gruppi_linked_target ON chat_gruppi(linked_target_type, linked_target_id);

-- Nota: registrazione migration demandata al migration runner/registry service.
-- Se la migration viene applicata manualmente via SQL puro, usare poi adopt-existing o status nel runner.
