-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- PRE-MB16 Pass 8U — authoritative Fabric peer device identity/key delivery.
--
-- Public transport keys are bound to the already-authenticated owner/device
-- authority. They are not a global Vemoria membership directory: cross-owner
-- SELECT is allowed only across an active direct chat thread with exactly two
-- participants. Writes remain strictly owner-scoped.

CREATE TABLE IF NOT EXISTS fabric_peer_device_keys (
    id                         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_user_id              UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    auth_device_id             UUID        NOT NULL REFERENCES owner_device_registration(id) ON DELETE CASCADE,
    fabric_device_id           TEXT        NOT NULL,
    device_name                TEXT        NOT NULL DEFAULT 'Dispositivo Vemoria',
    ed25519_public_key_b64     TEXT        NOT NULL,
    x25519_public_key_b64      TEXT        NOT NULL,
    ed25519_fingerprint        TEXT        NOT NULL,
    x25519_fingerprint         TEXT        NOT NULL,
    registration_protocol      TEXT        NOT NULL DEFAULT 'VEMORIA_FABRIC_DEVICE_KEY_V1',
    proof_verified_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    registered_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    status                     TEXT        NOT NULL DEFAULT 'active'
                                           CHECK (status IN ('active', 'revoked', 'rotated')),
    revoked_at                 TIMESTAMPTZ NULL,
    revoke_reason              TEXT        NULL,
    CHECK (char_length(fabric_device_id) BETWEEN 8 AND 96),
    CHECK (fabric_device_id ~ '^[A-Za-z0-9._:-]+$'),
    CHECK (char_length(ed25519_public_key_b64) BETWEEN 43 AND 44),
    CHECK (char_length(x25519_public_key_b64) BETWEEN 43 AND 44),
    CHECK (ed25519_fingerprint ~ '^sha256:[0-9a-f]{64}$'),
    CHECK (x25519_fingerprint ~ '^sha256:[0-9a-f]{64}$'),
    UNIQUE (owner_user_id, auth_device_id),
    UNIQUE (owner_user_id, fabric_device_id)
);

CREATE INDEX IF NOT EXISTS idx_fabric_peer_device_keys_owner_active
    ON fabric_peer_device_keys(owner_user_id, last_seen_at DESC)
    WHERE status = 'active';

CREATE INDEX IF NOT EXISTS idx_fabric_peer_device_keys_auth_device
    ON fabric_peer_device_keys(auth_device_id);

ALTER TABLE fabric_peer_device_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE fabric_peer_device_keys FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS fabric_peer_device_keys_select_scope ON fabric_peer_device_keys;
CREATE POLICY fabric_peer_device_keys_select_scope
ON fabric_peer_device_keys
FOR SELECT
USING (
    owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
    OR EXISTS (
        SELECT 1
        FROM chat_thread ct
        JOIN chat_partecipanti cp_me
          ON cp_me.thread_id = ct.id
         AND cp_me.user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
         AND cp_me.left_at IS NULL
        JOIN chat_partecipanti cp_peer
          ON cp_peer.thread_id = ct.id
         AND cp_peer.user_id = fabric_peer_device_keys.owner_user_id
         AND cp_peer.left_at IS NULL
        WHERE ct.thread_type = 'direct'
          AND ct.archived_at IS NULL
          AND (
              SELECT COUNT(*)
              FROM chat_partecipanti cp_count
              WHERE cp_count.thread_id = ct.id
                AND cp_count.left_at IS NULL
          ) = 2
    )
);

DROP POLICY IF EXISTS fabric_peer_device_keys_insert_owner ON fabric_peer_device_keys;
CREATE POLICY fabric_peer_device_keys_insert_owner
ON fabric_peer_device_keys
FOR INSERT
WITH CHECK (
    owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
);

DROP POLICY IF EXISTS fabric_peer_device_keys_update_owner ON fabric_peer_device_keys;
CREATE POLICY fabric_peer_device_keys_update_owner
ON fabric_peer_device_keys
FOR UPDATE
USING (
    owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
)
WITH CHECK (
    owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
);

DROP POLICY IF EXISTS fabric_peer_device_keys_delete_owner ON fabric_peer_device_keys;
CREATE POLICY fabric_peer_device_keys_delete_owner
ON fabric_peer_device_keys
FOR DELETE
USING (
    owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
);

COMMENT ON TABLE fabric_peer_device_keys IS
'PRE-MB16 Pass 8U: public E2E transport keys bound to authenticated owner_device_registration; cross-owner visibility only for an active exact 1:1 chat peer.';
