-- VEMORA — Migration V85: Workspace governance reale
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
--
-- Introduce governance reale dei workspace aziendali.
-- Nota: il workspace personale legacy resta supportato come scope speciale
-- (`workspace_type=personal`, `workspace_id=personal`) per retrocompatibilità.

CREATE TABLE IF NOT EXISTS workspaces (
    id                  TEXT        PRIMARY KEY,
    workspace_type      TEXT        NOT NULL DEFAULT 'company'
                                    CHECK (workspace_type IN ('personal', 'company')),
    owner_user_id       UUID        REFERENCES utenti(id) ON DELETE SET NULL,
    nome                TEXT        NOT NULL,
    slug                TEXT,
    stato               TEXT        NOT NULL DEFAULT 'attivo'
                                    CHECK (stato IN ('attivo', 'sospeso', 'archiviato')),
    metadata_json       JSONB,
    creato_il           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_workspaces_owner
    ON workspaces(owner_user_id, creato_il DESC);
CREATE INDEX IF NOT EXISTS idx_workspaces_type_state
    ON workspaces(workspace_type, stato, aggiornato_il DESC);

CREATE TABLE IF NOT EXISTS workspace_members (
    id                  UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    workspace_id        TEXT        NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    user_id             UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    role                TEXT        NOT NULL DEFAULT 'member'
                                    CHECK (role IN ('owner', 'admin', 'member', 'guest')),
    stato               TEXT        NOT NULL DEFAULT 'attivo'
                                    CHECK (stato IN ('attivo', 'sospeso', 'revocato')),
    joined_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    left_at             TIMESTAMPTZ,
    metadata_json       JSONB,
    UNIQUE (workspace_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_workspace_members_user
    ON workspace_members(user_id, workspace_id);
CREATE INDEX IF NOT EXISTS idx_workspace_members_workspace
    ON workspace_members(workspace_id, role)
    WHERE left_at IS NULL AND stato = 'attivo';

COMMENT ON TABLE workspaces IS
    'Workspace governati reali. I workspace company devono vivere qui. Il workspace personale legacy resta supportato come scope speciale.';
COMMENT ON TABLE workspace_members IS
    'Membri workspace con ruoli minimi owner/admin/member/guest.';

-- Backfill best-effort dei workspace company già presenti in V56.
INSERT INTO workspaces (id, workspace_type, owner_user_id, nome, slug, metadata_json)
SELECT DISTINCT src.workspace_id, 'company', src.owner_user_id,
       COALESCE(src.nome, 'Workspace aziendale'),
       regexp_replace(lower(COALESCE(src.nome, src.workspace_id)), '[^a-z0-9]+', '-', 'g'),
       jsonb_build_object('backfilled', true, 'source', src.source)
FROM (
    SELECT DISTINCT fs.workspace_id, fs.owner_user_id, NULL::text AS nome, 'firma_sessioni' AS source
    FROM firma_sessioni fs
    WHERE fs.workspace_type = 'company' AND COALESCE(fs.workspace_id, '') <> ''
    UNION ALL
    SELECT DISTINCT ct.workspace_id, ct.created_by AS owner_user_id, ct.titolo AS nome, 'chat_thread' AS source
    FROM chat_thread ct
    WHERE ct.workspace_type = 'company' AND COALESCE(ct.workspace_id, '') <> ''
    UNION ALL
    SELECT DISTINCT cg.workspace_id, cg.owner_user_id, cg.nome, 'chat_gruppi' AS source
    FROM chat_gruppi cg
    WHERE cg.workspace_type = 'company' AND COALESCE(cg.workspace_id, '') <> ''
) src
ON CONFLICT (id) DO NOTHING;

INSERT INTO workspace_members (workspace_id, user_id, role, metadata_json)
SELECT DISTINCT w.id, w.owner_user_id,
       CASE WHEN w.workspace_type = 'company' THEN 'owner' ELSE 'member' END,
       jsonb_build_object('backfilled', true)
FROM workspaces w
WHERE w.owner_user_id IS NOT NULL
ON CONFLICT (workspace_id, user_id) DO NOTHING;

-- Nota: registrazione migration demandata al migration runner/registry service.
-- Se la migration viene applicata manualmente via SQL puro, usare poi adopt-existing o status nel runner.
