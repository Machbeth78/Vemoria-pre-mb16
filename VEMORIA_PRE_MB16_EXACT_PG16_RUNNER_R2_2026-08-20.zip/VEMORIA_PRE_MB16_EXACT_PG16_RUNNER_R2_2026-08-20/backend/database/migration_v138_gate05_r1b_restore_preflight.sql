-- Vemoria Gate05 R1B - Restore preflight, recovery UX state and audit events
-- Static schema contract only. Runtime PostgreSQL execution not performed here.

CREATE TABLE IF NOT EXISTS gate05_restore_preflight_sessions (
    id TEXT PRIMARY KEY,
    owner_id TEXT NOT NULL,
    scenario TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('draft', 'fail_closed', 'allow_attempt', 'completed', 'aborted')),
    adaptive_profile_requested BOOLEAN NOT NULL DEFAULT FALSE,
    adaptive_profile_allowed BOOLEAN NOT NULL DEFAULT FALSE,
    root_verified BOOLEAN NOT NULL DEFAULT FALSE,
    fail_closed_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_gate05_restore_preflight_owner_status
    ON gate05_restore_preflight_sessions(owner_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS gate05_restore_material_checks (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL REFERENCES gate05_restore_preflight_sessions(id) ON DELETE CASCADE,
    owner_id TEXT NOT NULL,
    material TEXT NOT NULL,
    present BOOLEAN NOT NULL DEFAULT FALSE,
    verified BOOLEAN NOT NULL DEFAULT FALSE,
    source TEXT NOT NULL,
    secret_value_stored BOOLEAN NOT NULL DEFAULT FALSE CHECK (secret_value_stored = FALSE),
    checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(session_id, material)
);

CREATE INDEX IF NOT EXISTS idx_gate05_restore_material_checks_owner_session
    ON gate05_restore_material_checks(owner_id, session_id, material);

CREATE TABLE IF NOT EXISTS gate05_restore_safety_events (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL REFERENCES gate05_restore_preflight_sessions(id) ON DELETE CASCADE,
    owner_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    event_payload_json TEXT NOT NULL DEFAULT '{}',
    contains_secret BOOLEAN NOT NULL DEFAULT FALSE CHECK (contains_secret = FALSE),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_gate05_restore_safety_events_owner_created
    ON gate05_restore_safety_events(owner_id, created_at DESC);
