-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
--
-- MB13-P1 R2 — v200a Production execution boundary.
-- Forward-only, idempotent. Ensures dedicated API/worker roles can connect
-- via separate DSNs (VEMORA_MB13_P1_API_DATABASE_URL and
-- VEMORA_MB13_P1_WORKER_DATABASE_URL). Does not modify v196-v199b.

BEGIN;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p1_api') THEN
        CREATE ROLE mb13_p1_api LOGIN;
    ELSE
        ALTER ROLE mb13_p1_api LOGIN;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb13_p1_worker') THEN
        CREATE ROLE mb13_p1_worker LOGIN;
    ELSE
        ALTER ROLE mb13_p1_worker LOGIN;
    END IF;

    EXECUTE format('GRANT CONNECT ON DATABASE %I TO mb13_p1_api, mb13_p1_worker', current_database());
    EXECUTE format('GRANT TEMP ON DATABASE %I TO mb13_p1_api, mb13_p1_worker', current_database());
END
$$;

GRANT USAGE ON SCHEMA public TO mb13_p1_api, mb13_p1_worker;

COMMIT;
