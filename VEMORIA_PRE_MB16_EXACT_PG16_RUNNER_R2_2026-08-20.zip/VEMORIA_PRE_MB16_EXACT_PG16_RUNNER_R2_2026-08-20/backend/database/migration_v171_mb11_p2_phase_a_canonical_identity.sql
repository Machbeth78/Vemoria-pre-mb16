-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB11-P2 Phase A — Canonical identity ledger projection tables.
-- Additive, owner-scoped, append-only projection. The canonical_event_log
-- remains the source of truth; these tables are rebuildable views.

BEGIN;

-- Payload registry entries for identity domain events.
INSERT INTO canonical_event_payload_registry(payload_type, schema_version, description)
VALUES
    ('canonical_identity.v1', 1, 'Canonical identity create/augment/conflict/recalc/revoke'),
    ('canonical_identity_link.v1', 1, 'Canonical identity link propose/confirm/reject'),
    ('canonical_identity_merge.v1', 1, 'Canonical identity merge propose/apply/reverse'),
    ('canonical_identity_split.v1', 1, 'Canonical identity split propose/apply'),
    ('canonical_identity_proposal.v1', 1, 'Canonical identity weak-evidence candidate proposal')
ON CONFLICT (payload_type, schema_version) DO NOTHING;

-- Owner-scoped canonical identity projection.
CREATE TABLE IF NOT EXISTS canonical_identity_projection (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    canonical_id TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_subtype TEXT,
    canonical_name TEXT NOT NULL,
    aliases JSONB NOT NULL DEFAULT '[]'::jsonb,
    strong_identifiers JSONB NOT NULL DEFAULT '{}'::jsonb,
    evidence_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
    acquisition_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
    state TEXT NOT NULL,
    confidence DOUBLE PRECISION NOT NULL DEFAULT 0,
    reason_code TEXT,
    user_decision TEXT,
    merged_into TEXT,
    split_from TEXT,
    operation_history JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (owner_user_id, canonical_id)
);

CREATE INDEX IF NOT EXISTS idx_canonical_identity_projection_owner_state
    ON canonical_identity_projection(owner_user_id, state);
CREATE INDEX IF NOT EXISTS idx_canonical_identity_projection_owner_type
    ON canonical_identity_projection(owner_user_id, entity_type);

-- Identity links projection.
CREATE TABLE IF NOT EXISTS canonical_identity_link_projection (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    link_id TEXT NOT NULL,
    source_id TEXT NOT NULL,
    target_id TEXT NOT NULL,
    link_type TEXT NOT NULL,
    state TEXT NOT NULL,
    evidence JSONB NOT NULL DEFAULT '[]'::jsonb,
    confidence DOUBLE PRECISION NOT NULL DEFAULT 0,
    reason_code TEXT,
    created_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (owner_user_id, link_id)
);

CREATE INDEX IF NOT EXISTS idx_canonical_identity_link_projection_owner_source
    ON canonical_identity_link_projection(owner_user_id, source_id);
CREATE INDEX IF NOT EXISTS idx_canonical_identity_link_projection_owner_target
    ON canonical_identity_link_projection(owner_user_id, target_id);

-- Merge operation log projection.
CREATE TABLE IF NOT EXISTS canonical_identity_merge_log (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    operation_id TEXT NOT NULL,
    source_id TEXT NOT NULL,
    target_id TEXT NOT NULL,
    state TEXT NOT NULL,
    prior_source_state JSONB,
    prior_source_links JSONB,
    created_at TIMESTAMPTZ NOT NULL,
    applied_at TIMESTAMPTZ,
    reversed_at TIMESTAMPTZ,
    PRIMARY KEY (owner_user_id, operation_id)
);

-- Split operation log projection.
CREATE TABLE IF NOT EXISTS canonical_identity_split_log (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    operation_id TEXT NOT NULL,
    source_id TEXT NOT NULL,
    new_id TEXT NOT NULL,
    state TEXT NOT NULL,
    split_strong_ids JSONB NOT NULL DEFAULT '{}'::jsonb,
    split_aliases JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL,
    applied_at TIMESTAMPTZ,
    PRIMARY KEY (owner_user_id, operation_id)
);

-- Weak-evidence candidate proposals projection.
CREATE TABLE IF NOT EXISTS canonical_identity_proposal_projection (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    proposal_id TEXT NOT NULL,
    source_id TEXT NOT NULL,
    candidate_id TEXT NOT NULL,
    proposal_type TEXT NOT NULL,
    state TEXT NOT NULL,
    scores JSONB NOT NULL DEFAULT '{}'::jsonb,
    model_info JSONB NOT NULL DEFAULT '{}'::jsonb,
    evidence JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (owner_user_id, proposal_id)
);

CREATE INDEX IF NOT EXISTS idx_canonical_identity_proposal_owner_source
    ON canonical_identity_proposal_projection(owner_user_id, source_id);
CREATE INDEX IF NOT EXISTS idx_canonical_identity_proposal_owner_candidate
    ON canonical_identity_proposal_projection(owner_user_id, candidate_id);

-- Rejection history for deduplication (preserves user "never link" decisions).
CREATE TABLE IF NOT EXISTS canonical_identity_rejection_log (
    owner_user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    source_id TEXT NOT NULL,
    rejected_id TEXT NOT NULL,
    reason TEXT,
    rejected_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_user_id, source_id, rejected_id)
);

ALTER TABLE canonical_identity_projection ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_identity_link_projection ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_identity_merge_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_identity_split_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_identity_proposal_projection ENABLE ROW LEVEL SECURITY;
ALTER TABLE canonical_identity_rejection_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS canonical_identity_projection_owner_policy ON canonical_identity_projection;
CREATE POLICY canonical_identity_projection_owner_policy ON canonical_identity_projection
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID);

DROP POLICY IF EXISTS canonical_identity_link_projection_owner_policy ON canonical_identity_link_projection;
CREATE POLICY canonical_identity_link_projection_owner_policy ON canonical_identity_link_projection
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID);

DROP POLICY IF EXISTS canonical_identity_merge_log_owner_policy ON canonical_identity_merge_log;
CREATE POLICY canonical_identity_merge_log_owner_policy ON canonical_identity_merge_log
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID);

DROP POLICY IF EXISTS canonical_identity_split_log_owner_policy ON canonical_identity_split_log;
CREATE POLICY canonical_identity_split_log_owner_policy ON canonical_identity_split_log
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID);

DROP POLICY IF EXISTS canonical_identity_proposal_projection_owner_policy ON canonical_identity_proposal_projection;
CREATE POLICY canonical_identity_proposal_projection_owner_policy ON canonical_identity_proposal_projection
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID);

DROP POLICY IF EXISTS canonical_identity_rejection_log_owner_policy ON canonical_identity_rejection_log;
CREATE POLICY canonical_identity_rejection_log_owner_policy ON canonical_identity_rejection_log
    USING (owner_user_id = current_setting('app.owner_id', true)::UUID);

COMMIT;
