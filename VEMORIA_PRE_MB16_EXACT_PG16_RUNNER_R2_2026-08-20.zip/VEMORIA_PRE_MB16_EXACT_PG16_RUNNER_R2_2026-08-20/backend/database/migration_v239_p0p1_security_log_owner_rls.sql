-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA P0/P1 Adversarial Closure — v239
-- Owner isolation for security_log with admin-bypass capability.

DO $$
DECLARE
    v_role name;
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'security_log' AND column_name = 'owner_user_id'
    ) THEN
        ALTER TABLE security_log ADD COLUMN owner_user_id UUID;
    END IF;

    UPDATE security_log
    SET owner_user_id = '00000000-0000-0000-0000-000000000000'::uuid
    WHERE owner_user_id IS NULL;

    ALTER TABLE security_log ALTER COLUMN owner_user_id SET NOT NULL;

    ALTER TABLE security_log ENABLE ROW LEVEL SECURITY;
    ALTER TABLE security_log FORCE ROW LEVEL SECURITY;

    DROP POLICY IF EXISTS security_log_owner_policy ON security_log;
    CREATE POLICY security_log_owner_policy ON security_log
        FOR ALL TO PUBLIC
        USING (
            owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
            OR NULLIF(current_setting('app.is_admin', true), '') = 'true'
        )
        WITH CHECK (
            owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid
            OR NULLIF(current_setting('app.is_admin', true), '') = 'true'
        );

    FOR v_role IN SELECT unnest(ARRAY['test_app', 'vemora_user', 'app']::name[])
    LOOP
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = v_role) THEN
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE security_log TO %I', v_role);
        END IF;
    END LOOP;
END $$;
