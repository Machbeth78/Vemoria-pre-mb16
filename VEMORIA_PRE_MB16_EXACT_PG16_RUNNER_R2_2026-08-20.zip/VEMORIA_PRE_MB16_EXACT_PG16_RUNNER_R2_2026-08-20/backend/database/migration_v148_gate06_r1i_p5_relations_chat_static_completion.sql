-- Vemoria Gate06 R1I P5 Relations/Chat static completion
-- Runtime remains NON_ESEGUITO. This migration records metadata only.

CREATE TABLE IF NOT EXISTS gate06_r1i_p5_relations_chat_static_completion (
    id INTEGER PRIMARY KEY,
    gate TEXT NOT NULL,
    version TEXT NOT NULL,
    static_completion_state TEXT NOT NULL,
    runtime_real TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    notes TEXT NOT NULL
);

INSERT INTO gate06_r1i_p5_relations_chat_static_completion (
    id, gate, version, static_completion_state, runtime_real, notes
) VALUES (
    1,
    'GATE06_R1I_P5_RELATIONS_CHAT_STATIC_COMPLETION',
    'GATE06_R1I_P5_RELATIONS_CHAT_STATIC_COMPLETION_V148_2026-06-19',
    'STATIC_COMPLETED_RUNTIME_DEFERRED',
    'NON_ESEGUITO',
    'Static completion for VC-058 and VC-057. Email/chat access remains owner-scoped and source-authorized; summaries are derived and preserve source event references. No real email account, chat index, summary runtime, PostgreSQL or Android/Flutter runtime executed.'
) ON CONFLICT(id) DO UPDATE SET
    version=excluded.version,
    static_completion_state=excluded.static_completion_state,
    runtime_real=excluded.runtime_real,
    notes=excluded.notes;
