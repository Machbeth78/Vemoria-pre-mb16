-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB12-P0 R1F — Canonical consent, owner-safe binding and governed eligibility closure.
-- Additive, idempotent migration. Does not modify v176/v177/v178/v179/v180.

BEGIN;

-- Binding must optionally record the promotion consent grant used to authorize it.
ALTER TABLE mb12_p0_source_card_binding
    ADD COLUMN IF NOT EXISTS grant_id UUID NULL;

-- ---------------------------------------------------------------------------
-- Validation trigger: source/evidence/revision/hash integrity, fail-closed.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION mb12_p0_validate_source_card_binding()
RETURNS trigger AS $$
DECLARE
    v_session_owner UUID := current_setting('app.owner_id', true)::UUID;
    v_inventory_hash TEXT;
    v_evidence RECORD;
    v_payload JSONB;
BEGIN
    -- Owner must be set and must equal the session owner.
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'binding owner missing from session';
    END IF;
    IF NEW.owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'binding owner does not match authenticated owner';
    END IF;

    -- Source ownership and state.
    IF NOT EXISTS (
        SELECT 1 FROM public.authorized_memory_sources s
         WHERE s.id = NEW.source_id
           AND s.user_id = NEW.owner_user_id
           AND s.status = 'active'
           AND s.revoked_at IS NULL
    ) THEN
        RAISE EXCEPTION 'binding source not found, cross-owner, revoked or inactive';
    END IF;

    -- Inventory item ownership, source link and state.
    SELECT i.content_hash INTO v_inventory_hash
      FROM public.authorized_memory_inventory_items i
     WHERE i.id = NEW.source_revision_id
       AND i.user_id = NEW.owner_user_id
       AND i.source_id = NEW.source_id
       AND i.deleted_at IS NULL
       AND i.memory_state <> 'revoked';
    IF NOT FOUND THEN
        RAISE EXCEPTION 'binding revision not found, cross-owner, wrong source or revoked';
    END IF;

    -- Content-hash must always be derived from inventory; caller hash ignored.
    NEW.content_hash := COALESCE(v_inventory_hash, '');

    -- Evidence must exist, belong to same owner and source, and explicitly
    -- reference the exact source revision and action.
    SELECT l.action, l.plane, l.technical_payload, l.grant_id
      INTO v_evidence
      FROM public.authorized_memory_activity_log l
     WHERE l.id = NEW.evidence_id
       AND l.user_id = NEW.owner_user_id
       AND l.source_id = NEW.source_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'binding evidence not found, cross-owner or wrong source';
    END IF;

    IF v_evidence.action NOT IN ('promote_to_canonical','read_metadata','eligibility_read') THEN
        RAISE EXCEPTION 'binding evidence action not allowed:%', v_evidence.action;
    END IF;

    IF v_evidence.action = 'promote_to_canonical' AND v_evidence.plane <> 'MEMORY' THEN
        RAISE EXCEPTION 'promotion evidence must be on MEMORY plane';
    END IF;

    IF v_evidence.action IN ('read_metadata','eligibility_read') AND v_evidence.plane <> 'EXISTENCE' THEN
        RAISE EXCEPTION 'read evidence must be on EXISTENCE plane';
    END IF;

    -- Technical payload, when present, must reference the exact source revision.
    BEGIN
        v_payload := COALESCE(v_evidence.technical_payload, '{}'::jsonb);
    EXCEPTION WHEN OTHERS THEN
        v_payload := '{}'::jsonb;
    END;
    IF (v_payload ->> 'source_revision_id') IS NOT NULL
       AND (v_payload ->> 'source_revision_id')::text <> NEW.source_revision_id::text THEN
        RAISE EXCEPTION 'evidence payload references a different source revision';
    END IF;

    -- If a grant is recorded, it must exist, be active and cover promotion when
    -- the binding is for a promotion operation.
    IF NEW.grant_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.authorized_memory_consent_grants g
             WHERE g.id = NEW.grant_id
               AND g.user_id = NEW.owner_user_id
               AND g.source_id = NEW.source_id
               AND g.status = 'active'
               AND g.revoked_at IS NULL
               AND (g.expires_at IS NULL OR g.expires_at > NOW())
        ) THEN
            RAISE EXCEPTION 'binding grant not found, cross-owner, revoked or expired';
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

DROP TRIGGER IF EXISTS trg_mb12_p0_validate_source_card_binding ON public.mb12_p0_source_card_binding;
CREATE TRIGGER trg_mb12_p0_validate_source_card_binding
    BEFORE INSERT OR UPDATE ON public.mb12_p0_source_card_binding
    FOR EACH ROW EXECUTE FUNCTION public.mb12_p0_validate_source_card_binding();

-- ---------------------------------------------------------------------------
-- Governed writer: owner and hash are derived; caller cannot impersonate.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb12_p0_create_source_card_binding(
    p_source_card_id TEXT,
    p_source_id UUID,
    p_source_revision_id UUID,
    p_evidence_id UUID,
    p_scope TEXT DEFAULT 'source',
    p_grant_id UUID DEFAULT NULL
) RETURNS VOID AS $$
DECLARE
    v_owner UUID := current_setting('app.owner_id', true)::UUID;
    v_hash TEXT;
BEGIN
    IF v_owner IS NULL THEN
        RAISE EXCEPTION 'authenticated owner missing';
    END IF;

    SELECT i.content_hash INTO v_hash
      FROM public.authorized_memory_inventory_items i
     WHERE i.id = p_source_revision_id
       AND i.user_id = v_owner
       AND i.source_id = p_source_id
       AND i.deleted_at IS NULL
       AND i.memory_state <> 'revoked';
    IF NOT FOUND THEN
        RAISE EXCEPTION 'source revision not found or not owned';
    END IF;

    INSERT INTO public.mb12_p0_source_card_binding (
        source_card_id, owner_user_id, source_id, source_revision_id, evidence_id,
        content_hash, scope, status, grant_id
    ) VALUES (
        p_source_card_id, v_owner, p_source_id, p_source_revision_id, p_evidence_id,
        COALESCE(v_hash, ''), p_scope, 'active', p_grant_id
    )
    ON CONFLICT (owner_user_id, source_card_id) DO UPDATE SET
        source_id = EXCLUDED.source_id,
        source_revision_id = EXCLUDED.source_revision_id,
        evidence_id = EXCLUDED.evidence_id,
        content_hash = EXCLUDED.content_hash,
        scope = EXCLUDED.scope,
        grant_id = EXCLUDED.grant_id,
        status = 'active',
        revoked_at = NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

-- ---------------------------------------------------------------------------
-- Permissions: direct INSERT on binding remains revoked; only the writer is
-- executable by the application role.
-- ---------------------------------------------------------------------------
REVOKE INSERT ON public.mb12_p0_source_card_binding FROM mb12_p0_app;
REVOKE ALL ON FUNCTION public.mb12_p0_create_source_card_binding(TEXT, UUID, UUID, UUID, TEXT, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb12_p0_create_source_card_binding(TEXT, UUID, UUID, UUID, TEXT, UUID) TO mb12_p0_app;

COMMIT;
