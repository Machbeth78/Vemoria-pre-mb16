-- Vemoria Gate06 R1C - Satellite completion contracts for 34 partial functions
-- Static schema contract only. Runtime PostgreSQL execution not performed here.
-- This schema stores redacted contract metadata, not user content, secrets,
-- documents, chat text, files, keys, audio, photos or adaptive profile values.

CREATE TABLE IF NOT EXISTS gate06_satellite_completion_contracts (
    vc_id TEXT PRIMARY KEY,
    atlas_version TEXT NOT NULL,
    contract_version TEXT NOT NULL,
    satellite_family TEXT NOT NULL,
    completion_phase TEXT NOT NULL,
    dependency_order INTEGER NOT NULL CHECK (dependency_order >= 1 AND dependency_order <= 34),
    priority_rank INTEGER NOT NULL,
    depends_on_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    missing_completion_work_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    required_tests_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    runtime_probe_required_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    risk_level TEXT NOT NULL CHECK (risk_level IN ('BASSO','MEDIO','ALTO')),
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE CHECK (runtime_pass_claimed = FALSE),
    stores_raw_user_text BOOLEAN NOT NULL DEFAULT FALSE CHECK (stores_raw_user_text = FALSE),
    contains_secret BOOLEAN NOT NULL DEFAULT FALSE CHECK (contains_secret = FALSE),
    second_satellite_map_allowed BOOLEAN NOT NULL DEFAULT FALSE CHECK (second_satellite_map_allowed = FALSE),
    status TEXT NOT NULL DEFAULT 'PARTIAL_COMPLETION_CONTRACT_ONLY',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_gate06_satellite_contract_dependency_order
    ON gate06_satellite_completion_contracts(dependency_order);

CREATE INDEX IF NOT EXISTS idx_gate06_satellite_contract_family_phase
    ON gate06_satellite_completion_contracts(satellite_family, completion_phase, dependency_order);

CREATE INDEX IF NOT EXISTS idx_gate06_satellite_contract_risk
    ON gate06_satellite_completion_contracts(risk_level, dependency_order);

CREATE TABLE IF NOT EXISTS gate06_satellite_completion_phase_contracts (
    phase TEXT PRIMARY KEY,
    first_dependency_order INTEGER NOT NULL,
    contract_count INTEGER NOT NULL CHECK (contract_count >= 1),
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE CHECK (runtime_pass_claimed = FALSE),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
