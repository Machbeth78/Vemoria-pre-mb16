-- Gate07F — P5 Relations/Chat functional completion
-- Code integration marker only. Does not claim real email account, chat index,
-- PostgreSQL, Android or runtime summary execution. Runtime pass remains false.

CREATE TABLE IF NOT EXISTS gate07f_p5_relations_chat_functional_completion (
    id INTEGER PRIMARY KEY,
    gate TEXT NOT NULL DEFAULT 'GATE07F_P5_RELATIONS_CHAT_FUNCTIONAL_COMPLETION',
    version TEXT NOT NULL DEFAULT 'GATE07F_P5_RELATIONS_CHAT_FUNCTIONAL_COMPLETION_V156_2026-06-20',
    p5_vc_ids TEXT NOT NULL DEFAULT 'VC-058,VC-057',
    integration_state TEXT NOT NULL DEFAULT 'CODICE_INTEGRATO',
    runtime_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    runtime_pass_claimed BOOLEAN NOT NULL DEFAULT FALSE,
    email_account_runtime_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    chat_index_runtime_real TEXT NOT NULL DEFAULT 'NON_ESEGUITO',
    summaries_are_derived BOOLEAN NOT NULL DEFAULT TRUE,
    source_event_refs_preserved BOOLEAN NOT NULL DEFAULT TRUE,
    owner_scope_required BOOLEAN NOT NULL DEFAULT TRUE,
    CHECK (runtime_pass_claimed = FALSE),
    CHECK (runtime_real <> 'PASS')
);

INSERT INTO gate07f_p5_relations_chat_functional_completion(id) VALUES (1) ON CONFLICT DO NOTHING;
