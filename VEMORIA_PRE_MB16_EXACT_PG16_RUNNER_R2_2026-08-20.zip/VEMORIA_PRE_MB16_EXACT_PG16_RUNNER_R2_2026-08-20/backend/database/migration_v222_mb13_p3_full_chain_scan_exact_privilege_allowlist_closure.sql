-- MB13-P3 v222 — full chain scan, exact privileges and allowlist closure
-- Corrections from v221:
--   * Classification scans every pack and every historical revision, not only flagged rows.
--   * No quarantine based solely on idempotency-key prefixes.
--   * pack_id_hash is computed before the revision loop; zero-revision packs do not abort.
--   * Lifecycle role receives only explicit, minimal privileges.
--   * Writer/API/Executor/Test_app/PUBLIC are denied direct DML on all Action Pack tables.
--   * Lifecycle functions are allow-listed by exact regprocedure signature.
--   * RLS and FORCE RLS are enabled on every lifecycle-owned table.

BEGIN;

-- ============================================================================
-- 1. Lifecycle role attributes
-- ============================================================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p3_pack_lifecycle_owner') THEN
        CREATE ROLE mb13_p3_pack_lifecycle_owner NOLOGIN NOINHERIT NOBYPASSRLS;
    END IF;
END $$;

ALTER ROLE mb13_p3_pack_lifecycle_owner NOLOGIN NOINHERIT NOBYPASSRLS;
GRANT USAGE ON SCHEMA public TO mb13_p3_pack_lifecycle_owner;

-- ============================================================================
-- 2. Remove broad schema-level grants given in v221
-- ============================================================================
REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM mb13_p3_pack_lifecycle_owner;
REVOKE ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public FROM mb13_p3_pack_lifecycle_owner;
REVOKE ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public FROM mb13_p3_pack_lifecycle_owner;

-- ============================================================================
-- 3. Transfer all Action Pack tables (and the audit table) to the lifecycle role
-- ============================================================================
DO $$
DECLARE
    r RECORD;
BEGIN
    FOR r IN
        SELECT relname
          FROM pg_class
         WHERE relnamespace = 'public'::regnamespace
           AND relkind = 'r'
           AND (relname LIKE 'mb13_p3_action_pack%'
                OR relname = 'mb13_p3_recovery_audit')
         ORDER BY relname
    LOOP
        EXECUTE format('ALTER TABLE public.%I OWNER TO mb13_p3_pack_lifecycle_owner', r.relname);
    END LOOP;
END $$;

-- The lifecycle role owns the Action Pack tables but the previous broad revoke
-- removed even the implicit owner privileges; grant only the DML it actually needs.
DO $$
DECLARE
    r RECORD;
BEGIN
    FOR r IN
        SELECT relname
          FROM pg_class
         WHERE relnamespace = 'public'::regnamespace
           AND relkind = 'r'
           AND (relname LIKE 'mb13_p3_action_pack%'
                OR relname = 'mb13_p3_recovery_audit')
         ORDER BY relname
    LOOP
        EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.%I TO mb13_p3_pack_lifecycle_owner', r.relname);
    END LOOP;
END $$;

-- ============================================================================
-- 4. Transfer Action Pack trigger/helper functions to the lifecycle role
--    so SECURITY DEFINER triggers can maintain tables owned by lifecycle.
--    The validator helper mb13_p3_action_pack_refs_revoked must remain
--    owned by mb13_p3_validator (tested explicitly by v212).
-- ============================================================================
DO $$
DECLARE
    r RECORD;
BEGIN
    FOR r IN
        SELECT proname, pg_get_function_identity_arguments(oid) AS args
          FROM pg_proc
         WHERE pronamespace = 'public'::regnamespace
           AND proname LIKE 'mb13_p3_action_pack%'
           AND proname <> 'mb13_p3_action_pack_refs_revoked'
         ORDER BY proname
    LOOP
        BEGIN
            EXECUTE format('ALTER FUNCTION public.%I(%s) OWNER TO mb13_p3_pack_lifecycle_owner', r.proname, r.args);
        EXCEPTION WHEN undefined_function THEN
            NULL;
        END;
    END LOOP;
END $$;

-- Restore the validator helper to the validator role; v221 may have moved it.
ALTER FUNCTION public.mb13_p3_action_pack_refs_revoked(public.mb13_p0_monitor_target, JSONB, JSONB) OWNER TO mb13_p3_validator;
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_refs_revoked(public.mb13_p0_monitor_target, JSONB, JSONB) FROM PUBLIC, mb13_p3_api, mb13_p3_executor, test_app;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_refs_revoked(public.mb13_p0_monitor_target, JSONB, JSONB) TO mb13_p3_writer, mb13_p3_pack_lifecycle_owner;

-- ============================================================================
-- 5. Grant lifecycle role exact, minimal privileges
-- ============================================================================
-- Helper functions used by lifecycle functions (allow-listed by exact signature).
-- The previous broad REVOKE removed every explicit grant; re-grant only what the
-- lifecycle functions actually call.
GRANT EXECUTE ON FUNCTION public.mb13_p0_hash_jsonb(JSONB) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_monitor_policy_hash(UUID, UUID, INTEGER) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_trigger_diff(UUID, UUID, INTEGER, UUID, UUID) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_refs_revoked(public.mb13_p0_monitor_target, JSONB, JSONB) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_source_grant_chain(UUID, public.mb13_p0_monitor_target, JSONB, JSONB, JSONB) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_steps(UUID, JSONB) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_action_pack_integrity(public.mb13_p3_action_pack) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_evidence_payload_semantics(public.mb13_p3_action_pack, TEXT, JSONB, TEXT) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_result_evidence(JSONB) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_validate_result_evidence(UUID, UUID, UUID, JSONB) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_active_authorization(UUID, UUID, TEXT, INTEGER, TEXT, TEXT, TEXT, TEXT, INTEGER) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_covered_step_consents(public.mb13_p3_action_pack, JSONB) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_canonicalize_evidence_payload(public.mb13_p3_action_pack, TEXT, JSONB) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_canonicalize_result_evidence(UUID, UUID, UUID, JSONB) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_action_pack_attempts(UUID, UUID) TO mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_get_action_pack_timeline(UUID, UUID, INTEGER, INTEGER) TO mb13_p3_pack_lifecycle_owner;

-- Hash helpers are SECURITY INVOKER and are called by writer/validator-owned
-- validation functions as well as by lifecycle functions; preserve the narrow
-- execute grants they had before the ownership transfer.
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_payload_hash(UUID, UUID, INTEGER, UUID, UUID, TEXT, JSONB, JSONB, JSONB, JSONB, TIMESTAMP WITH TIME ZONE, TEXT, TEXT) TO mb13_p3_pack_lifecycle_owner, mb13_p3_writer, mb13_p3_pack_mutator, mb13_p3_validator;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_authorization_hash(UUID, UUID, INTEGER, TEXT, INTEGER, TEXT, TEXT, TEXT, TEXT, TIMESTAMP WITH TIME ZONE, TIMESTAMP WITH TIME ZONE) TO mb13_p3_pack_lifecycle_owner, mb13_p3_writer, mb13_p3_validator;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_result_hash(UUID, UUID, INTEGER, UUID, INTEGER, TEXT, TEXT, JSONB, TIMESTAMP WITH TIME ZONE) TO mb13_p3_pack_lifecycle_owner, mb13_p3_writer, mb13_p3_validator;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_auth_hash(UUID, UUID, INTEGER, INTEGER, TIMESTAMP WITH TIME ZONE, TIMESTAMP WITH TIME ZONE) TO mb13_p3_pack_lifecycle_owner, mb13_p3_writer, mb13_p3_validator;

-- Read access to referenced monitor/consent/diff/event tables.
-- FOR UPDATE on monitor_target requires UPDATE privilege.
GRANT SELECT, UPDATE ON TABLE public.mb13_p0_monitor_target TO mb13_p3_pack_lifecycle_owner;
GRANT SELECT ON TABLE public.mb13_p0_monitor_target_revision TO mb13_p3_pack_lifecycle_owner;
GRANT SELECT ON TABLE public.mb13_p0_monitor_event_ledger TO mb13_p3_pack_lifecycle_owner;
GRANT SELECT ON TABLE public.authorized_memory_consent_grants TO mb13_p3_pack_lifecycle_owner;
GRANT SELECT ON TABLE public.authorized_memory_sources TO mb13_p3_pack_lifecycle_owner;
GRANT SELECT ON TABLE public.authorized_memory_activity_log TO mb13_p3_pack_lifecycle_owner;

-- Sequences owned by lifecycle tables are already usable by the owner; grant
-- sequence usage explicitly in case future helper code needs it.
DO $$
DECLARE
    r RECORD;
BEGIN
    FOR r IN
        SELECT c.relname
          FROM pg_class c
          JOIN pg_namespace n ON n.oid = c.relnamespace
         WHERE n.nspname = 'public'
           AND c.relkind = 'S'
           AND c.relname LIKE 'mb13_p3_action_pack%'
    LOOP
        EXECUTE format('GRANT USAGE, SELECT ON SEQUENCE public.%I TO mb13_p3_pack_lifecycle_owner', r.relname);
    END LOOP;
END $$;

-- ============================================================================
-- 6. Deny direct DML on all Action Pack tables and the audit table to shared roles
-- ============================================================================
DO $$
DECLARE
    r RECORD;
BEGIN
    FOR r IN
        SELECT relname
          FROM pg_class
         WHERE relnamespace = 'public'::regnamespace
           AND relkind = 'r'
           AND (relname LIKE 'mb13_p3_action_pack%'
                OR relname = 'mb13_p3_recovery_audit')
         ORDER BY relname
    LOOP
        EXECUTE format('REVOKE ALL ON TABLE public.%I FROM PUBLIC, mb13_p3_writer, mb13_p3_api, mb13_p3_executor, test_app', r.relname);
        EXECUTE format('GRANT SELECT ON TABLE public.%I TO mb13_p3_validator, mb13_p3_writer, mb13_p3_api, mb13_p3_executor', r.relname);
    END LOOP;
END $$;

-- The recovery audit table is append-only; only the migration/lifecycle can insert.
-- Readers may SELECT; no external role may INSERT/UPDATE/DELETE.
REVOKE INSERT, UPDATE, DELETE ON TABLE public.mb13_p3_recovery_audit FROM PUBLIC, mb13_p3_writer, mb13_p3_api, mb13_p3_executor, test_app, mb13_p3_pack_lifecycle_owner;

-- ============================================================================
-- 7. Exact allowlist by regprocedure signature
-- ============================================================================
DO $$
DECLARE
    v_api_sigs TEXT[] := ARRAY[
        'public.mb13_p3_create_action_pack(uuid,uuid,uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text,text)',
        'public.mb13_p3_revise_action_pack(uuid,uuid,text,jsonb,jsonb,jsonb,jsonb,timestamp with time zone,text)',
        'public.mb13_p3_authorize_action_pack(uuid,uuid,timestamp with time zone)',
        'public.mb13_p3_cancel_action_pack(uuid,uuid)',
        'public.mb13_p3_revoke_action_pack(uuid,uuid)'
    ];
    v_executor_sigs TEXT[] := ARRAY[
        'public.mb13_p3_claim_action_pack(uuid,uuid,integer,text,text)',
        'public.mb13_p3_start_action_pack(uuid,uuid,uuid,integer)',
        'public.mb13_p3_record_execution_evidence(uuid,uuid,uuid,integer,text,jsonb,text)',
        'public.mb13_p3_complete_action_pack(uuid,uuid,uuid,integer,integer,text,jsonb)',
        'public.mb13_p3_expire_action_pack(uuid,uuid)'
    ];
    v_all_lifecycle_sigs TEXT[] := v_api_sigs || v_executor_sigs;
    v_lifecycle_names TEXT[] := ARRAY[
        'mb13_p3_create_action_pack','mb13_p3_revise_action_pack','mb13_p3_authorize_action_pack',
        'mb13_p3_claim_action_pack','mb13_p3_start_action_pack','mb13_p3_record_execution_evidence',
        'mb13_p3_complete_action_pack','mb13_p3_cancel_action_pack','mb13_p3_revoke_action_pack',
        'mb13_p3_expire_action_pack'
    ];
    v_sig TEXT;
    v_proc regprocedure;
    v_allowed_oids oid[] := ARRAY[]::oid[];
    r RECORD;
BEGIN
    -- Resolve the exact allow-listed signatures and take ownership / set grants.
    FOREACH v_sig IN ARRAY v_all_lifecycle_sigs LOOP
        v_proc := to_regprocedure(v_sig);
        IF v_proc IS NULL THEN
            RAISE EXCEPTION 'migration_v222 required lifecycle signature missing: %', v_sig;
        END IF;
        v_allowed_oids := array_append(v_allowed_oids, v_proc::oid);
        EXECUTE format('ALTER FUNCTION %s OWNER TO mb13_p3_pack_lifecycle_owner', v_proc);
        EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC, mb13_p3_writer, mb13_p3_api, mb13_p3_executor, test_app', v_proc);
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_writer', v_proc);
    END LOOP;

    FOREACH v_sig IN ARRAY v_api_sigs LOOP
        v_proc := to_regprocedure(v_sig);
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_api', v_proc);
    END LOOP;

    FOREACH v_sig IN ARRAY v_executor_sigs LOOP
        v_proc := to_regprocedure(v_sig);
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_executor', v_proc);
    END LOOP;

    -- Any overload of a lifecycle name that is NOT in the allowlist must not be
    -- owned by the lifecycle role and must not be executable by API/executor/writer/test_app.
    FOR r IN
        SELECT p.oid::regprocedure AS sig
          FROM pg_proc p
         WHERE p.proname = ANY(v_lifecycle_names)
           AND p.pronamespace = 'public'::regnamespace
           AND NOT (p.oid = ANY(v_allowed_oids))
    LOOP
        EXECUTE format('ALTER FUNCTION %s OWNER TO postgres', r.sig);
        EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC, mb13_p3_writer, mb13_p3_api, mb13_p3_executor, test_app', r.sig);
    END LOOP;
END $$;

-- ============================================================================
-- 8. Enable RLS and FORCE RLS on every lifecycle-owned table
-- ============================================================================
DO $$
DECLARE
    r RECORD;
BEGIN
    FOR r IN
        SELECT relname
          FROM pg_class
         WHERE relnamespace = 'public'::regnamespace
           AND relkind = 'r'
           AND relowner = (SELECT oid FROM pg_roles WHERE rolname = 'mb13_p3_pack_lifecycle_owner')
    LOOP
        EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', r.relname);
        EXECUTE format('ALTER TABLE public.%I FORCE ROW LEVEL SECURITY', r.relname);
    END LOOP;
END $$;

-- ============================================================================
-- 9. Full chain re-classification: every pack, every revision, no prefix logic
-- ============================================================================
DO $$
DECLARE
    v_run_id UUID := gen_random_uuid();
    v_pack RECORD;
    v_rev RECORD;
    v_current_rev public.mb13_p3_action_pack_revision%ROWTYPE;
    v_pack_hash TEXT;
    v_expected TEXT;
    v_pack_expected TEXT;
    v_pack_quarantine BOOLEAN;
    v_pack_reason TEXT;
    v_is_candidate BOOLEAN;
    v_rev_count INTEGER;
    v_expected_rev INTEGER;
    v_chain_gap BOOLEAN;
    v_revision_ambiguous BOOLEAN;
BEGIN
    ALTER TABLE public.mb13_p3_action_pack DISABLE TRIGGER USER;
    ALTER TABLE public.mb13_p3_action_pack_revision DISABLE TRIGGER USER;

    FOR v_pack IN
        SELECT * FROM public.mb13_p3_action_pack
         ORDER BY pack_id
    LOOP
        BEGIN
            v_pack_hash := encode(digest(v_pack.pack_id::text, 'sha256'), 'hex');
            v_pack_quarantine := FALSE;
            v_pack_reason := NULL;
            v_is_candidate := FALSE;

            -- Any legacy flag on the pack itself makes it a candidate.
            IF v_pack.legacy_idempotency_unverified IS TRUE
               OR v_pack.legacy_idempotency_quarantined IS TRUE
               OR v_pack.idempotency_key IS NULL THEN
                v_is_candidate := TRUE;
            END IF;

            -- Locate the current revision (must equal pack_revision).
            SELECT * INTO v_current_rev
              FROM public.mb13_p3_action_pack_revision r
             WHERE r.pack_id = v_pack.pack_id
               AND r.revision = v_pack.pack_revision;

            IF NOT FOUND THEN
                v_pack_quarantine := TRUE;
                v_pack_reason := 'legacy_recovery_current_revision_missing';
            ELSE
                -- Canonical projection: pack and current revision must agree on
                -- every field except idempotency/ payload/ quarantine flags.
                IF v_pack.owner_user_id IS DISTINCT FROM v_current_rev.owner_user_id
                   OR v_pack.pack_id IS DISTINCT FROM v_current_rev.pack_id
                   OR v_pack.pack_revision IS DISTINCT FROM v_current_rev.revision
                   OR v_pack.monitor_revision IS DISTINCT FROM v_current_rev.monitor_revision
                   OR v_pack.trigger_event_id IS DISTINCT FROM v_current_rev.trigger_event_id
                   OR v_pack.diff_result_id IS DISTINCT FROM v_current_rev.diff_result_id
                   OR v_pack.action_type IS DISTINCT FROM v_current_rev.action_type
                   OR v_pack.target_ref IS DISTINCT FROM v_current_rev.target_ref
                   OR v_pack.consent_refs IS DISTINCT FROM v_current_rev.consent_refs
                   OR v_pack.provenance_refs IS DISTINCT FROM v_current_rev.provenance_refs
                   OR v_pack.steps IS DISTINCT FROM v_current_rev.steps
                   OR v_pack.expires_at IS DISTINCT FROM v_current_rev.expires_at
                THEN
                    v_pack_quarantine := TRUE;
                    v_pack_reason := 'legacy_recovery_current_revision_canonical_mismatch';
                END IF;

                -- Pack payload hash: use the stored idempotency key and the current revision status.
                IF NOT v_pack_quarantine THEN
                    BEGIN
                        v_pack_expected := public.mb13_p3_action_pack_payload_hash(
                            v_pack.owner_user_id, v_pack.monitor_id, v_pack.monitor_revision,
                            v_pack.trigger_event_id, v_pack.diff_result_id, v_pack.action_type,
                            v_pack.target_ref, v_pack.consent_refs, v_pack.provenance_refs, v_pack.steps,
                            v_pack.expires_at, v_pack.idempotency_key, v_current_rev.status
                        );
                    EXCEPTION WHEN OTHERS THEN
                        v_pack_expected := NULL;
                    END;

                    IF v_pack_expected IS DISTINCT FROM v_pack.payload_hash THEN
                        v_pack_quarantine := TRUE;
                        v_pack_reason := 'legacy_recovery_pack_hash_mismatch';
                    END IF;
                END IF;
            END IF;

            -- Verify every historical revision: continuity, hash coherence, legacy flags.
            v_rev_count := 0;
            v_revision_ambiguous := FALSE;

            FOR v_rev IN
                SELECT * FROM public.mb13_p3_action_pack_revision
                 WHERE pack_id = v_pack.pack_id
                 ORDER BY revision
            LOOP
                v_rev_count := v_rev_count + 1;

                -- Continuous sequence: revision numbers must be 1..N with no gaps.
                IF v_rev.revision IS DISTINCT FROM v_rev_count THEN
                    v_chain_gap := TRUE;
                    v_pack_quarantine := TRUE;
                    IF v_pack_reason IS NULL THEN
                        v_pack_reason := 'legacy_recovery_chain_gap';
                    END IF;
                END IF;

                -- Any legacy/null marker on any revision broadens the candidate set.
                IF v_rev.legacy_idempotency_unverified IS TRUE
                   OR v_rev.legacy_idempotency_quarantined IS TRUE
                   OR v_rev.idempotency_key IS NULL THEN
                    v_is_candidate := TRUE;
                END IF;

                -- Verify the revision payload hash using its own stored key.
                BEGIN
                    v_expected := public.mb13_p3_action_pack_payload_hash(
                        v_rev.owner_user_id, v_pack.monitor_id, v_rev.monitor_revision,
                        v_rev.trigger_event_id, v_rev.diff_result_id, v_rev.action_type,
                        v_rev.target_ref, v_rev.consent_refs, v_rev.provenance_refs, v_rev.steps,
                        v_rev.expires_at, v_rev.idempotency_key, v_rev.status
                    );
                EXCEPTION WHEN OTHERS THEN
                    v_expected := NULL;
                END;

                IF v_expected IS DISTINCT FROM v_rev.payload_hash THEN
                    v_revision_ambiguous := TRUE;
                    v_pack_quarantine := TRUE;
                    IF v_pack_reason IS NULL THEN
                        v_pack_reason := 'legacy_recovery_revision_hash_mismatch';
                    END IF;

                    UPDATE public.mb13_p3_action_pack_revision
                       SET legacy_idempotency_quarantined = TRUE,
                           legacy_idempotency_quarantine_reason = 'legacy_recovery_revision_hash_mismatch'
                     WHERE pack_id = v_rev.pack_id
                       AND revision = v_rev.revision;

                    INSERT INTO public.mb13_p3_recovery_audit (
                        migration_name, run_id, pack_id_hash, pack_revision, revision,
                        classification, reason_code, before_hash, after_hash
                    ) VALUES (
                        'migration_v222_mb13_p3_full_chain_scan_exact_privilege_allowlist_closure.sql',
                        v_run_id, v_pack_hash, v_pack.pack_revision, v_rev.revision,
                        'ambiguous', 'legacy_recovery_revision_hash_mismatch', v_rev.payload_hash, v_expected
                    );
                ELSE
                    UPDATE public.mb13_p3_action_pack_revision
                       SET legacy_idempotency_quarantined = FALSE,
                           legacy_idempotency_quarantine_reason = NULL
                     WHERE pack_id = v_rev.pack_id
                       AND revision = v_rev.revision;

                    INSERT INTO public.mb13_p3_recovery_audit (
                        migration_name, run_id, pack_id_hash, pack_revision, revision,
                        classification, reason_code, before_hash, after_hash
                    ) VALUES (
                        'migration_v222_mb13_p3_full_chain_scan_exact_privilege_allowlist_closure.sql',
                        v_run_id, v_pack_hash, v_pack.pack_revision, v_rev.revision,
                        'verified', 'legacy_recovery_revision_hash_verified', v_rev.payload_hash, v_expected
                    );
                END IF;
            END LOOP;

            -- A pack with no revisions is unprovable.
            IF v_rev_count = 0 AND NOT v_pack_quarantine THEN
                v_pack_quarantine := TRUE;
                v_pack_reason := 'legacy_recovery_no_revisions';
            END IF;

            -- Pack-level outcome.
            IF v_pack_quarantine THEN
                UPDATE public.mb13_p3_action_pack
                   SET legacy_idempotency_quarantined = TRUE,
                       legacy_idempotency_quarantine_reason = v_pack_reason
                 WHERE pack_id = v_pack.pack_id;

                INSERT INTO public.mb13_p3_recovery_audit (
                    migration_name, run_id, pack_id_hash, pack_revision, revision,
                    classification, reason_code, before_hash, after_hash
                ) VALUES (
                    'migration_v222_mb13_p3_full_chain_scan_exact_privilege_allowlist_closure.sql',
                    v_run_id, v_pack_hash, v_pack.pack_revision, NULL,
                    'quarantined', v_pack_reason, v_pack.payload_hash, NULL
                );
            ELSIF v_is_candidate THEN
                UPDATE public.mb13_p3_action_pack
                   SET legacy_idempotency_quarantined = FALSE,
                       legacy_idempotency_quarantine_reason = NULL
                 WHERE pack_id = v_pack.pack_id;

                INSERT INTO public.mb13_p3_recovery_audit (
                    migration_name, run_id, pack_id_hash, pack_revision, revision,
                    classification, reason_code, before_hash, after_hash
                ) VALUES (
                    'migration_v222_mb13_p3_full_chain_scan_exact_privilege_allowlist_closure.sql',
                    v_run_id, v_pack_hash, v_pack.pack_revision, NULL,
                    'candidate', 'legacy_recovery_chain_verified', v_pack.payload_hash, NULL
                );
            ELSE
                INSERT INTO public.mb13_p3_recovery_audit (
                    migration_name, run_id, pack_id_hash, pack_revision, revision,
                    classification, reason_code, before_hash, after_hash
                ) VALUES (
                    'migration_v222_mb13_p3_full_chain_scan_exact_privilege_allowlist_closure.sql',
                    v_run_id, v_pack_hash, v_pack.pack_revision, NULL,
                    'skipped', 'legacy_recovery_skipped', v_pack.payload_hash, NULL
                );
            END IF;

        EXCEPTION WHEN OTHERS THEN
            -- A single corrupted pack must not abort the whole recovery.
            INSERT INTO public.mb13_p3_recovery_audit (
                migration_name, run_id, pack_id_hash, pack_revision, revision,
                classification, reason_code, before_hash, after_hash
            ) VALUES (
                'migration_v222_mb13_p3_full_chain_scan_exact_privilege_allowlist_closure.sql',
                v_run_id, v_pack_hash, v_pack.pack_revision, NULL,
                'quarantined', 'legacy_recovery_exception', v_pack.payload_hash, NULL
            );
        END;
    END LOOP;

    ALTER TABLE public.mb13_p3_action_pack ENABLE TRIGGER USER;
    ALTER TABLE public.mb13_p3_action_pack_revision ENABLE TRIGGER USER;
END $$;

-- ============================================================================
-- 10. Ensure the recovery audit trigger is owned by postgres and append-only
-- ============================================================================
ALTER FUNCTION public.mb13_p3_recovery_audit_immutable() OWNER TO postgres;

COMMIT;
