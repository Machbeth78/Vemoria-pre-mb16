-- Vemoria — Memoria Esistente Autorizzata Multi-Dispositivo
-- Migration v124 — Macro A: inventario reale + ConsentGrant
--
-- Additive only. Non sostituisce Source Indexer v109, Fabric v121-v123,
-- Secure Line v42-v45 o device_set_v1. Li cabla e li rende espliciti per
-- sorgenti multi-dispositivo e consenso granulare.
--
-- Invarianti:
--   ESISTENZA != IDENTITA != TRASPORTO != MEMORIA
--   ConsentGrant = sorgente × azione × finestra
--   Indicizzato non implica copiato, analizzato o canonico.
--   Revoca non spegne solo il futuro: deve propagare ai derivati.

CREATE TABLE IF NOT EXISTS authorized_memory_sources (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,

    -- device_set_v1 device_id, non FK DB perché il device-set è documento firmato.
    device_id TEXT NOT NULL,
    source_kind TEXT NOT NULL CHECK (source_kind IN (
        'phone_media','phone_downloads','phone_documents','tablet_media',
        'pc_folder','workstation_folder','vault_space','nas_share',
        'external_drive','usb_stick','local_server','shared_folder','future_node'
    )),
    source_label TEXT NULL,

    -- Ref opaco: sourceref:/devref:/vaultref:/localref:. Mai path reale.
    opaque_source_ref TEXT NOT NULL CHECK (
        opaque_source_ref LIKE 'sourceref:%'
        OR opaque_source_ref LIKE 'devref:%'
        OR opaque_source_ref LIKE 'vaultref:%'
        OR opaque_source_ref LIKE 'localref:%'
    ),

    capability_profile JSONB NOT NULL DEFAULT '{}'::jsonb,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','revoked','suspended','offline')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revoked_at TIMESTAMPTZ NULL
);

CREATE INDEX IF NOT EXISTS idx_authorized_sources_user_device
    ON authorized_memory_sources(user_id, device_id, status);

CREATE INDEX IF NOT EXISTS idx_authorized_sources_user_kind
    ON authorized_memory_sources(user_id, source_kind, status);


CREATE TABLE IF NOT EXISTS authorized_memory_consent_grants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    source_id UUID NOT NULL REFERENCES authorized_memory_sources(id) ON DELETE CASCADE,
    issued_by_device_id TEXT NOT NULL,

    action TEXT NOT NULL CHECK (action IN (
        'inventory_existence','read_metadata','compute_identity','light_extraction',
        'heavy_analysis','sync_index_only','transfer_derivative','transfer_content',
        'copy_to_vault','backup_encrypted','promote_to_canonical',
        'delete_index_results','revoke_grant'
    )),

    plane TEXT NOT NULL CHECK (plane IN ('EXISTENCE','IDENTITY','TRANSPORT','MEMORY')),
    window_policy JSONB NOT NULL DEFAULT '{}'::jsonb,
    constraints JSONB NOT NULL DEFAULT '{}'::jsonb,
    owner_visible_description TEXT NOT NULL,
    explicit_user_ack BOOLEAN NOT NULL DEFAULT FALSE,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','revoked','expired','suspended')),
    grant_version INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NULL,
    revoked_at TIMESTAMPTZ NULL,

    CONSTRAINT chk_grant_version_v1 CHECK (grant_version = 1),
    CONSTRAINT chk_content_touching_requires_ack CHECK (
        action NOT IN ('light_extraction','heavy_analysis','transfer_derivative','transfer_content','copy_to_vault','backup_encrypted','promote_to_canonical')
        OR explicit_user_ack = TRUE
    ),
    CONSTRAINT chk_promotion_requires_owner_confirmation CHECK (
        action <> 'promote_to_canonical'
        OR (constraints ->> 'owner_confirmation_required') = 'true'
    ),
    CONSTRAINT chk_transfer_content_requires_secure_line CHECK (
        action <> 'transfer_content'
        OR (constraints ->> 'secure_line_required') = 'true'
    )
);

CREATE INDEX IF NOT EXISTS idx_authorized_grants_user_source
    ON authorized_memory_consent_grants(user_id, source_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_authorized_grants_user_action
    ON authorized_memory_consent_grants(user_id, action, status);


CREATE TABLE IF NOT EXISTS authorized_memory_inventory_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    source_id UUID NOT NULL REFERENCES authorized_memory_sources(id) ON DELETE CASCADE,
    grant_id UUID NULL REFERENCES authorized_memory_consent_grants(id) ON DELETE SET NULL,

    -- item_ref opaco, mai path reale.
    opaque_item_ref TEXT NOT NULL CHECK (
        opaque_item_ref LIKE 'sourceref:%'
        OR opaque_item_ref LIKE 'devref:%'
        OR opaque_item_ref LIKE 'vaultref:%'
        OR opaque_item_ref LIKE 'localref:%'
    ),
    item_type TEXT NOT NULL,
    observed_name_redacted TEXT NULL,
    size_bytes BIGINT NULL,
    observed_at TIMESTAMPTZ NULL,
    content_hash TEXT NULL,

    existence_state TEXT NOT NULL DEFAULT 'indexed' CHECK (existence_state IN ('indexed','excluded','revoked','deleted')),
    identity_state TEXT NOT NULL DEFAULT 'not_computed' CHECK (identity_state IN ('not_computed','candidate','verified','revoked')),
    transport_state TEXT NOT NULL DEFAULT 'none' CHECK (transport_state IN ('none','index_synced','derivative_synced','content_transferred','revoked')),
    memory_state TEXT NOT NULL DEFAULT 'not_canonical' CHECK (memory_state IN ('not_canonical','candidate','canonical','revoked')),

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ NULL,

    CONSTRAINT chk_inventory_not_silent_canonical CHECK (
        memory_state <> 'canonical' OR grant_id IS NOT NULL
    )
);

CREATE INDEX IF NOT EXISTS idx_authorized_inventory_user_source
    ON authorized_memory_inventory_items(user_id, source_id, created_at DESC)
    WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_authorized_inventory_user_hash
    ON authorized_memory_inventory_items(user_id, content_hash)
    WHERE content_hash IS NOT NULL AND deleted_at IS NULL;


CREATE TABLE IF NOT EXISTS authorized_memory_activity_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    source_id UUID NULL REFERENCES authorized_memory_sources(id) ON DELETE SET NULL,
    grant_id UUID NULL REFERENCES authorized_memory_consent_grants(id) ON DELETE SET NULL,
    action TEXT NOT NULL,
    plane TEXT NULL CHECK (plane IS NULL OR plane IN ('EXISTENCE','IDENTITY','TRANSPORT','MEMORY')),
    user_visible_summary TEXT NOT NULL,
    technical_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    -- Log append-only: la policy è applicativa; questa tabella non prevede UPDATE/DELETE distruttivi.
    CONSTRAINT chk_activity_summary_present CHECK (length(user_visible_summary) >= 12)
);

CREATE INDEX IF NOT EXISTS idx_authorized_activity_user_ts
    ON authorized_memory_activity_log(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_authorized_activity_source_ts
    ON authorized_memory_activity_log(source_id, created_at DESC)
    WHERE source_id IS NOT NULL;
