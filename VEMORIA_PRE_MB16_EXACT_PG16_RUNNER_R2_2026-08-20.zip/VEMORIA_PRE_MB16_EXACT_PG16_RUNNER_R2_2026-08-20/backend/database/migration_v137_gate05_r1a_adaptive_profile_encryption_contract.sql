-- Vemoria Gate05 R1A — Adaptive Profile Encryption Contract
-- Additiva sopra v136. Congela che il profilo adattivo deve dichiarare
-- cifratura forte almeno quanto la radice: AEAD, AES-256-GCM, Argon2id,
-- key separation dedicata per categoria, nonce e salt espliciti.
-- Runtime PostgreSQL reale: NON ESEGUITO in questo pacchetto statico.

BEGIN;

ALTER TABLE owner_adaptive_profile_bundle_registry
    ADD COLUMN IF NOT EXISTS cipher_contract_version TEXT NOT NULL
        DEFAULT 'vemoria.adaptive_profile_encryption_contract.v1'
        CHECK (cipher_contract_version IN ('vemoria.adaptive_profile_encryption_contract.v1')),
    ADD COLUMN IF NOT EXISTS cipher_algorithm TEXT NOT NULL
        DEFAULT 'AES-256-GCM'
        CHECK (cipher_algorithm IN ('AES-256-GCM')),
    ADD COLUMN IF NOT EXISTS cipher_key_length_bits INTEGER NOT NULL
        DEFAULT 256 CHECK (cipher_key_length_bits >= 256),
    ADD COLUMN IF NOT EXISTS aead_required BOOLEAN NOT NULL
        DEFAULT TRUE CHECK (aead_required = TRUE),
    ADD COLUMN IF NOT EXISTS kdf_algorithm TEXT NOT NULL
        DEFAULT 'argon2id' CHECK (kdf_algorithm IN ('argon2id')),
    ADD COLUMN IF NOT EXISTS kdf_params_json JSONB NOT NULL
        DEFAULT '{}'::jsonb,
    ADD COLUMN IF NOT EXISTS nonce_b64 TEXT NULL,
    ADD COLUMN IF NOT EXISTS key_separation_context TEXT NULL;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'owner_adaptive_profile_key_context_not_root'
    ) THEN
        ALTER TABLE owner_adaptive_profile_bundle_registry
            ADD CONSTRAINT owner_adaptive_profile_key_context_not_root
            CHECK (
                key_separation_context IS NULL OR (
                    key_separation_context LIKE 'vemoria.gate05.adaptive_profile.%'
                    AND key_separation_context NOT IN (
                        'root',
                        'root_identity',
                        'vemoria.root_export.v1',
                        'vemoria.gate05.root_identity'
                    )
                )
            );
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS owner_adaptive_profile_encryption_contract_audit (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    bundle_id TEXT NOT NULL,
    category TEXT NOT NULL,
    cipher_contract_version TEXT NOT NULL
        CHECK (cipher_contract_version IN ('vemoria.adaptive_profile_encryption_contract.v1')),
    cipher_algorithm TEXT NOT NULL CHECK (cipher_algorithm IN ('AES-256-GCM')),
    cipher_key_length_bits INTEGER NOT NULL CHECK (cipher_key_length_bits >= 256),
    aead_required BOOLEAN NOT NULL CHECK (aead_required = TRUE),
    kdf_algorithm TEXT NOT NULL CHECK (kdf_algorithm IN ('argon2id')),
    kdf_params_json JSONB NOT NULL,
    nonce_b64 TEXT NOT NULL,
    key_separation_context TEXT NOT NULL,
    ciphertext_sha256 TEXT NOT NULL,
    contract_sha256 TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'superseded', 'revoked', 'deleted')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (utente_id, bundle_id, category, contract_sha256)
);

CREATE INDEX IF NOT EXISTS idx_owner_adaptive_profile_contract_owner_category
    ON owner_adaptive_profile_encryption_contract_audit(utente_id, bundle_id, category, status);

INSERT INTO owner_recovery_event_log (
    utente_id,
    event_kind,
    event_authority,
    related_digest,
    metadata_json
)
SELECT
    utente_id,
    'adaptive_profile_category_revoked',
    'system_technical',
    ciphertext_sha256,
    jsonb_build_object(
        'gate', 'GATE05_R1A_ADAPTIVE_PROFILE_ENCRYPTION_CONTRACT',
        'policy', 'encryption_contract_required_for_future_profile_manifests',
        'runtime', 'NON_ESEGUITO_STATIC_MIGRATION_DECLARATION'
    )
FROM owner_adaptive_profile_bundle_registry
WHERE FALSE;

COMMIT;
