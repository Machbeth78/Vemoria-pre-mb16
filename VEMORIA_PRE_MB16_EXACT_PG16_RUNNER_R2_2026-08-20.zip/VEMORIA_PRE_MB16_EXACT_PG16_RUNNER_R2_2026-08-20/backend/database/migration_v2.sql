-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- ============================================================
-- VEMORA V2 — Migration Additiva
-- IMPORTANTE: NON modifica le tabelle core esistenti
-- Aggiunge solo nuove tabelle e colonne opzionali
-- ============================================================

-- ============================================================
-- Aggiunte alle tabelle esistenti (opzionali, nullable)
-- ============================================================

-- Aggiungi categoria_colore a memorie (derivata dalla pipeline)
ALTER TABLE memorie
    ADD COLUMN IF NOT EXISTS categoria_colore TEXT DEFAULT 'white',
    ADD COLUMN IF NOT EXISTS tags             JSONB DEFAULT '[]',
    ADD COLUMN IF NOT EXISTS dossier_id_principale UUID,
    ADD COLUMN IF NOT EXISTS data_documento   TIMESTAMP;

-- Aggiungi tipo_contenuto a documenti (distingue documento vs foto evento)
ALTER TABLE documenti
    ADD COLUMN IF NOT EXISTS tipo_contenuto  TEXT DEFAULT 'documento',
                                             -- documento | foto_evento
    ADD COLUMN IF NOT EXISTS gps_lat         REAL,
    ADD COLUMN IF NOT EXISTS gps_lon         REAL,
    ADD COLUMN IF NOT EXISTS descrizione     TEXT;

-- ============================================================
-- TABELLA: dossier
-- Raccoglitori logici di documenti correlati
-- ============================================================
CREATE TABLE IF NOT EXISTS dossier (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    proprietario_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    titolo          TEXT NOT NULL,
    descrizione     TEXT,
    colore          TEXT NOT NULL DEFAULT 'blue',
    icona           TEXT NOT NULL DEFAULT 'folder',
    keywords        JSONB DEFAULT '[]',     -- parole chiave per auto-assegnazione
    stato           TEXT NOT NULL DEFAULT 'attivo',
    creato_il       TIMESTAMP NOT NULL DEFAULT NOW(),
    aggiornato_il   TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_dossier_proprietario ON dossier(proprietario_id);
CREATE INDEX IF NOT EXISTS idx_dossier_stato        ON dossier(stato);

-- ============================================================
-- TABELLA: documento_dossier
-- Relazione N:N tra memorie e dossier
-- ============================================================
CREATE TABLE IF NOT EXISTS documento_dossier (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    memoria_id  UUID NOT NULL REFERENCES memorie(id) ON DELETE CASCADE,
    dossier_id  UUID NOT NULL REFERENCES dossier(id) ON DELETE CASCADE,
    principale  BOOLEAN NOT NULL DEFAULT FALSE,
    aggiunto_il TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE(memoria_id, dossier_id)
);

CREATE INDEX IF NOT EXISTS idx_doc_dossier_memoria  ON documento_dossier(memoria_id);
CREATE INDEX IF NOT EXISTS idx_doc_dossier_dossier  ON documento_dossier(dossier_id);

-- ============================================================
-- FUNZIONE aggiornamento timestamp per dossier
-- ============================================================
CREATE OR REPLACE FUNCTION aggiorna_timestamp_dossier()
RETURNS TRIGGER AS $$
BEGIN
    NEW.aggiornato_il = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_dossier_aggiornato ON dossier;
CREATE TRIGGER trigger_dossier_aggiornato
    BEFORE UPDATE ON dossier
    FOR EACH ROW EXECUTE FUNCTION aggiorna_timestamp_dossier();

-- ============================================================
-- V2.1 ESTENSIONE ADDITIVE — Note Vocali
-- Aggiunge campi opzionali per la nota vocale alla tabella memorie
-- NON modifica struttura esistente
-- ============================================================

ALTER TABLE memorie
    ADD COLUMN IF NOT EXISTS audio_nota_path            TEXT,      -- path relativo nel filesystem storage
    ADD COLUMN IF NOT EXISTS audio_nota_testo           TEXT,      -- testo trascritto (se disponibile)
    ADD COLUMN IF NOT EXISTS audio_nota_durata_secondi  INTEGER;   -- durata in secondi

-- Indice per ricerca sul testo trascritto
CREATE INDEX IF NOT EXISTS idx_memorie_audio_nota_testo
    ON memorie(audio_nota_path)
    WHERE audio_nota_path IS NOT NULL;
