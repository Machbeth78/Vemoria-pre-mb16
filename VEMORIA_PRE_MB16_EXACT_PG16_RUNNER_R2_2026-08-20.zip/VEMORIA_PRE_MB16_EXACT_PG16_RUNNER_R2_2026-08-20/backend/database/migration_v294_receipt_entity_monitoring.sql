-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- PRE-MB16 Pass 8AI — explicit receipt-derived real-world entity monitoring.
-- This is adapter authorization/checkpoint state; MB13-P0 remains the canonical
-- monitoring/event ledger.  Receipt capture alone never inserts here.
CREATE TABLE IF NOT EXISTS receipt_entity_monitor_authorizations (
    authorization_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    entity_fingerprint TEXT NOT NULL,
    merchant_name TEXT NOT NULL,
    address_hint TEXT NOT NULL DEFAULT '',
    vat_value TEXT NOT NULL DEFAULT '',
    interest_kinds JSONB NOT NULL DEFAULT '[]'::jsonb,
    discovery_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    status TEXT NOT NULL DEFAULT 'active',
    cadence_hours INTEGER NOT NULL DEFAULT 24,
    last_snapshot_hash TEXT NOT NULL DEFAULT '',
    last_checked_at TIMESTAMPTZ NULL,
    next_check_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_error TEXT NULL,
    confirmed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revoked_at TIMESTAMPTZ NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_id, entity_fingerprint),
    CHECK (status IN ('active','revoked')),
    CHECK (cadence_hours BETWEEN 6 AND 168)
);

CREATE INDEX IF NOT EXISTS idx_receipt_entity_monitor_due
    ON receipt_entity_monitor_authorizations(status, next_check_at)
    WHERE status = 'active' AND revoked_at IS NULL;

ALTER TABLE receipt_entity_monitor_authorizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE receipt_entity_monitor_authorizations FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS receipt_entity_monitor_authorizations_owner_policy
    ON receipt_entity_monitor_authorizations;
CREATE POLICY receipt_entity_monitor_authorizations_owner_policy
    ON receipt_entity_monitor_authorizations
    FOR ALL
    USING (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

COMMENT ON TABLE receipt_entity_monitor_authorizations IS
    'Explicit owner authorization and refresh checkpoint for receipt-derived public entity watches. Canonical lifecycle/events remain in MB13-P0.';
