-- VEMORIA Chat Macro F - final UX/security static policy
-- Runtime not executed.

CREATE TABLE IF NOT EXISTS chat_ultra_protected_policies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL,
    thread_id UUID,
    privacy_mode TEXT NOT NULL DEFAULT 'ULTRA_PROTECTED' CHECK (privacy_mode IN ('NORMAL','PROTECTED','ULTRA_PROTECTED')),
    external_backup_disabled_by_default BOOLEAN NOT NULL DEFAULT TRUE,
    gallery_export_disabled_by_default BOOLEAN NOT NULL DEFAULT TRUE,
    screenshot_control_is_best_effort_not_guarantee BOOLEAN NOT NULL DEFAULT TRUE,
    forwarding_requires_confirmation BOOLEAN NOT NULL DEFAULT TRUE,
    server_content_visibility BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (NOT (privacy_mode = 'ULTRA_PROTECTED' AND server_content_visibility = TRUE))
);
