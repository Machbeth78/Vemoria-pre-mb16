-- VEMORIA Chat Macro D - GROUP_COORDINATO visibility states
-- Runtime not executed. Static schema seed for center-rays visibility policy.

CREATE TABLE IF NOT EXISTS chat_group_coordinato_participant_visibility (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL,
    thread_id UUID NOT NULL,
    participant_ref TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('CENTER','RAY','OBSERVER','AUDITOR')),
    state TEXT NOT NULL CHECK (state IN ('ACTIVE','PAUSED_CONNECTED','OUT')),
    historical_access_preserved BOOLEAN NOT NULL DEFAULT TRUE,
    current_visibility_scope TEXT NOT NULL CHECK (current_visibility_scope IN ('CURRENT_RELEVANT','HISTORICAL_ALLOWED','NONE')),
    can_see_other_rays BOOLEAN NOT NULL DEFAULT FALSE,
    can_be_reactivated BOOLEAN NOT NULL DEFAULT TRUE,
    belongs_to_group BOOLEAN NOT NULL DEFAULT TRUE,
    revoked BOOLEAN NOT NULL DEFAULT FALSE,
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (NOT (role = 'RAY' AND can_see_other_rays = TRUE)),
    CHECK (NOT (state = 'PAUSED_CONNECTED' AND (revoked = TRUE OR deleted = TRUE OR belongs_to_group = FALSE))),
    CHECK (NOT (state = 'OUT' AND current_visibility_scope <> 'NONE'))
);

CREATE INDEX IF NOT EXISTS idx_chat_coord_visibility_thread ON chat_group_coordinato_participant_visibility(thread_id);
CREATE INDEX IF NOT EXISTS idx_chat_coord_visibility_owner_thread ON chat_group_coordinato_participant_visibility(owner_id, thread_id);
