-- Vemoria canonical assembly — migration_v115_acquisition_real_r10r2.sql
-- Integra PATCH-05R2 nel registro sequenziale del backend GitHub.
-- PostgreSQL only. Applicare dopo migration_v114_v_pt_core_03_dialogue_pending_plan.sql.
BEGIN;

-- ==== 001_acquisition_sessions.sql ====
-- PATCH-05R1 / M1 — Sessioni acquisizione + identità contenuto, owner-scoped.
-- R1: UNIQUE (owner_id, content_id) per consentire FK composite owner-scoped dai figli.
BEGIN;
CREATE TABLE IF NOT EXISTS acquisition_session (
  session_id    text PRIMARY KEY,
  owner_id      uuid NOT NULL,
  input_kind    text NOT NULL,
  state         text NOT NULL DEFAULT 'DRAFT',
  is_private    boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ck_acq_state CHECK (state IN ('DRAFT','WAITING_DESCRIPTION','PROCESSING','WAITING_LINK_CONFIRMATION','READY','QUARANTINED','FAILED'))
);
CREATE INDEX IF NOT EXISTS ix_acq_session_owner ON acquisition_session(owner_id);

CREATE TABLE IF NOT EXISTS content_identity (
  content_id        text NOT NULL,
  owner_id          uuid NOT NULL,
  original_sha256   text NOT NULL,
  origin            text NOT NULL,
  description       text,
  state             text NOT NULL DEFAULT 'DRAFT',
  version           int NOT NULL DEFAULT 1,
  acquired_at       timestamptz NOT NULL DEFAULT now(),
  path_fingerprint  text,           -- opaco, mai il percorso completo
  PRIMARY KEY (content_id),
  -- R1: chiave univoca composita per FK owner-scoped dai figli
  CONSTRAINT uq_content_owner UNIQUE (owner_id, content_id)
);
CREATE INDEX IF NOT EXISTS ix_content_owner ON content_identity(owner_id);

-- ==== 002_derivatives_ocr.sql ====
-- PATCH-05R1 / M2 — Derivati + OCR, FK COMPOSITE owner-scoped (no cross-owner).
BEGIN;
CREATE TABLE IF NOT EXISTS content_derivative (
  derivative_id text PRIMARY KEY,
  owner_id      uuid NOT NULL,
  content_id    text NOT NULL,
  kind          text NOT NULL,
  sha256        text NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  -- R1: FK su (owner_id, content_id): impossibile riferire contenuto di altro owner
  CONSTRAINT fk_derivative_content FOREIGN KEY (owner_id, content_id)
      REFERENCES content_identity(owner_id, content_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_derivative_owner_content ON content_derivative(owner_id, content_id);

CREATE TABLE IF NOT EXISTS ocr_metadata (
  content_id    text NOT NULL,
  owner_id      uuid NOT NULL,
  ocr_level     text NOT NULL,
  ocr_lang      text NOT NULL,
  confidence    double precision,
  conflict      boolean NOT NULL DEFAULT false,
  needs_confirmation boolean NOT NULL DEFAULT false,
  PRIMARY KEY (owner_id, content_id),
  CONSTRAINT fk_ocr_content FOREIGN KEY (owner_id, content_id)
      REFERENCES content_identity(owner_id, content_id) ON DELETE CASCADE
);

-- ==== 003_link_suggestions_codes.sql ====
-- PATCH-05R1 / M3 — Suggerimenti + codici, FK COMPOSITE owner-scoped.
BEGIN;
CREATE TABLE IF NOT EXISTS link_suggestion (
  suggestion_id text PRIMARY KEY,
  owner_id      uuid NOT NULL,
  content_id    text NOT NULL,
  target_type   text NOT NULL,
  target_id     text NOT NULL,
  reason_key    text NOT NULL,
  confidence    double precision NOT NULL,
  sensitive     boolean NOT NULL DEFAULT false,
  state         text NOT NULL DEFAULT 'SUGGESTED',
  CONSTRAINT ck_link_state CHECK (state IN ('SUGGESTED','CONFIRMED','CORRECTED','IGNORED')),
  CONSTRAINT fk_link_content FOREIGN KEY (owner_id, content_id)
      REFERENCES content_identity(owner_id, content_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_link_owner_content ON link_suggestion(owner_id, content_id);

CREATE TABLE IF NOT EXISTS code_reading (
  reading_id    text PRIMARY KEY,
  owner_id      uuid NOT NULL,
  content_id    text NOT NULL,
  code_type     text NOT NULL,
  value_redacted text,
  risk          text NOT NULL DEFAULT 'LOW',
  read_at       timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT fk_code_content FOREIGN KEY (owner_id, content_id)
      REFERENCES content_identity(owner_id, content_id) ON DELETE CASCADE
);

-- ==== 004_owner_scope_composite_fk.sql ====
-- PATCH-05R1 / M4 — Isolamento owner a livello relazionale. Applicare prima di RLS.
BEGIN;
DO $$ BEGIN
 IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='uq_content_owner') THEN
   ALTER TABLE content_identity ADD CONSTRAINT uq_content_owner UNIQUE (owner_id, content_id);
 END IF;
END $$;
ALTER TABLE content_derivative ADD COLUMN IF NOT EXISTS owner_id uuid;
UPDATE content_derivative d SET owner_id=c.owner_id FROM content_identity c
 WHERE d.content_id=c.content_id AND d.owner_id IS NULL;
ALTER TABLE content_derivative ALTER COLUMN owner_id SET NOT NULL;
ALTER TABLE ocr_metadata ADD COLUMN IF NOT EXISTS owner_id uuid;
UPDATE ocr_metadata o SET owner_id=c.owner_id FROM content_identity c
 WHERE o.content_id=c.content_id AND o.owner_id IS NULL;
ALTER TABLE ocr_metadata ALTER COLUMN owner_id SET NOT NULL;
ALTER TABLE content_derivative DROP CONSTRAINT IF EXISTS fk_derivative_content;
ALTER TABLE content_derivative ADD CONSTRAINT fk_derivative_content_owner
 FOREIGN KEY(owner_id,content_id) REFERENCES content_identity(owner_id,content_id) ON DELETE CASCADE;
ALTER TABLE ocr_metadata DROP CONSTRAINT IF EXISTS fk_ocr_content;
ALTER TABLE ocr_metadata ADD CONSTRAINT fk_ocr_content_owner
 FOREIGN KEY(owner_id,content_id) REFERENCES content_identity(owner_id,content_id) ON DELETE CASCADE;
ALTER TABLE link_suggestion DROP CONSTRAINT IF EXISTS fk_link_content;
ALTER TABLE link_suggestion ADD CONSTRAINT fk_link_content_owner
 FOREIGN KEY(owner_id,content_id) REFERENCES content_identity(owner_id,content_id) ON DELETE CASCADE;
ALTER TABLE code_reading DROP CONSTRAINT IF EXISTS fk_code_content;
ALTER TABLE code_reading ADD CONSTRAINT fk_code_content_owner
 FOREIGN KEY(owner_id,content_id) REFERENCES content_identity(owner_id,content_id) ON DELETE CASCADE;
CREATE INDEX IF NOT EXISTS ix_derivative_owner_content ON content_derivative(owner_id,content_id);
CREATE INDEX IF NOT EXISTS ix_ocr_owner_content ON ocr_metadata(owner_id,content_id);
CREATE INDEX IF NOT EXISTS ix_code_owner_content ON code_reading(owner_id,content_id);

-- ==== 005_runtime_fields_and_outbox.sql ====
-- PATCH-05R1 / M5 — Descrizione obbligatoria prima di READY, refs opachi, Cassaforte e outbox locale.
BEGIN;
ALTER TABLE content_identity ADD COLUMN IF NOT EXISTS opaque_local_ref text;
ALTER TABLE content_identity ADD COLUMN IF NOT EXISTS classification_json jsonb;
ALTER TABLE content_identity ADD COLUMN IF NOT EXISTS description_source text;
ALTER TABLE content_identity ADD COLUMN IF NOT EXISTS description_confirmed_at timestamptz;
ALTER TABLE content_identity ADD COLUMN IF NOT EXISTS vault_state text;
ALTER TABLE content_identity ADD COLUMN IF NOT EXISTS vault_receipt_id text;
DO $$ BEGIN
 IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='ck_description_before_ready') THEN
  ALTER TABLE content_identity ADD CONSTRAINT ck_description_before_ready CHECK (
   state IN ('DRAFT','WAITING_DESCRIPTION','QUARANTINED','FAILED')
   OR (description IS NOT NULL AND length(btrim(description)) >= 3 AND description_confirmed_at IS NOT NULL)
  ) NOT VALID;
 END IF;
END $$;
CREATE TABLE IF NOT EXISTS acquisition_outbox(
 event_id uuid PRIMARY KEY, owner_id uuid NOT NULL, content_id text NOT NULL,
 event_type text NOT NULL, payload jsonb NOT NULL DEFAULT '{}'::jsonb,
 created_at timestamptz NOT NULL DEFAULT now(), processed_at timestamptz,
 attempts integer NOT NULL DEFAULT 0,
 CONSTRAINT fk_outbox_content_owner FOREIGN KEY(owner_id,content_id)
   REFERENCES content_identity(owner_id,content_id) ON DELETE CASCADE,
 CONSTRAINT ck_outbox_type CHECK(event_type IN ('TIMELINE_ACQUISITION_READY','SEARCH_INDEX_CONTENT'))
);
CREATE INDEX IF NOT EXISTS ix_outbox_pending_owner ON acquisition_outbox(owner_id,processed_at,created_at);
ALTER TABLE code_reading ADD COLUMN IF NOT EXISTS normalized_host text;
ALTER TABLE code_reading ADD COLUMN IF NOT EXISTS url_sha256 text;
ALTER TABLE code_reading ADD COLUMN IF NOT EXISTS validation_state text NOT NULL DEFAULT 'NOT_VALIDATED';

-- ==== 006_owner_rls_enable_after_repository.sql ====
-- PATCH-05R1 / M6 — RLS. APPLICARE SOLO DOPO il repository set_config('app.owner_id',...).
BEGIN;
CREATE OR REPLACE FUNCTION vemoria_current_owner_id() RETURNS uuid
LANGUAGE sql STABLE AS $$ SELECT NULLIF(current_setting('app.owner_id',true),'')::uuid $$;
ALTER TABLE acquisition_session ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_identity ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_derivative ENABLE ROW LEVEL SECURITY;
ALTER TABLE ocr_metadata ENABLE ROW LEVEL SECURITY;
ALTER TABLE link_suggestion ENABLE ROW LEVEL SECURITY;
ALTER TABLE code_reading ENABLE ROW LEVEL SECURITY;
ALTER TABLE acquisition_outbox ENABLE ROW LEVEL SECURITY;
DO $$ DECLARE t text; BEGIN
 FOR t IN SELECT unnest(ARRAY['acquisition_session','content_identity','content_derivative','ocr_metadata','link_suggestion','code_reading','acquisition_outbox']) LOOP
   EXECUTE format('DROP POLICY IF EXISTS owner_isolation ON %I',t);
   EXECUTE format('CREATE POLICY owner_isolation ON %I USING (owner_id=vemoria_current_owner_id()) WITH CHECK (owner_id=vemoria_current_owner_id())',t);
 END LOOP;
END $$;

-- ==== 007_outbox_idempotency.sql ====
-- PATCH-05R2 FINAL / M7 — Idempotenza outbox (A6).
-- deduplication_key canonica 'acq:<owner_id>:<content_id>:<version>:<channel>',
-- UNIQUE owner-scoped, inserimento idempotente (ON CONFLICT DO NOTHING), retry state.
BEGIN;
ALTER TABLE acquisition_outbox ADD COLUMN IF NOT EXISTS deduplication_key text;
ALTER TABLE acquisition_outbox ADD COLUMN IF NOT EXISTS retry_count integer NOT NULL DEFAULT 0;
ALTER TABLE acquisition_outbox ADD COLUMN IF NOT EXISTS last_error text;
ALTER TABLE acquisition_outbox ADD COLUMN IF NOT EXISTS last_attempt_at timestamptz;
ALTER TABLE acquisition_outbox ADD COLUMN IF NOT EXISTS delivery_confirmed boolean NOT NULL DEFAULT false;

-- UNIQUE owner-scoped sulla dedup key: un retry non crea un secondo evento.
-- (event_id resta PK distinto dalla chiave di deduplicazione.)
DO $$ BEGIN
 IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='uq_outbox_dedup_owner') THEN
  ALTER TABLE acquisition_outbox ADD CONSTRAINT uq_outbox_dedup_owner UNIQUE (owner_id, deduplication_key);
 END IF;
END $$;

-- Estendo i tipi ammessi con gli eventi provvisori (A5).
DO $$ BEGIN
 IF EXISTS (SELECT 1 FROM pg_constraint WHERE conname='ck_outbox_type') THEN
  ALTER TABLE acquisition_outbox DROP CONSTRAINT ck_outbox_type;
 END IF;
 ALTER TABLE acquisition_outbox ADD CONSTRAINT ck_outbox_type CHECK(
   event_type IN ('TIMELINE_ACQUISITION_READY','SEARCH_INDEX_CONTENT',
                  'ACQUISITION_NEEDS_CONFIRMATION','ACQUISITION_DRAFT_UPDATED'));
END $$;

-- Inserimento idempotente di riferimento (documentazione del pattern usato dal repository):
--   INSERT INTO acquisition_outbox(event_id, owner_id, content_id, deduplication_key, event_type, payload)
--   VALUES (...) ON CONFLICT (owner_id, deduplication_key) DO NOTHING;

-- ==== 008_outbox_delivery_state.sql ====
-- PATCH-05R2 FINAL CORRETTO / M8 (R10_R2) — Allineamento outbox al repository.
-- Aggiunge i campi di stato consegna usati dal repository produttivo:
-- next_attempt_at, delivery_state, delivered_at. (retry_count/last_error/last_attempt_at
-- e deduplication_key/UNIQUE sono già in 007.)
BEGIN;
ALTER TABLE acquisition_outbox ADD COLUMN IF NOT EXISTS next_attempt_at timestamptz;
ALTER TABLE acquisition_outbox ADD COLUMN IF NOT EXISTS delivery_state text NOT NULL DEFAULT 'PENDING';
ALTER TABLE acquisition_outbox ADD COLUMN IF NOT EXISTS delivered_at timestamptz;
DO $$ BEGIN
 IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='ck_outbox_delivery_state') THEN
  ALTER TABLE acquisition_outbox ADD CONSTRAINT ck_outbox_delivery_state
    CHECK (delivery_state IN ('PENDING','DELIVERED','FAILED'));
 END IF;
END $$;
-- content_identity: campi per pending confirmation (BLOCKER 2) e versione/privato.
ALTER TABLE content_identity ADD COLUMN IF NOT EXISTS version integer NOT NULL DEFAULT 1;
ALTER TABLE content_identity ADD COLUMN IF NOT EXISTS is_private boolean NOT NULL DEFAULT false;
ALTER TABLE content_identity ADD COLUMN IF NOT EXISTS pending_reason text;
ALTER TABLE content_identity ADD COLUMN IF NOT EXISTS provisional_confidence double precision;

COMMIT;
