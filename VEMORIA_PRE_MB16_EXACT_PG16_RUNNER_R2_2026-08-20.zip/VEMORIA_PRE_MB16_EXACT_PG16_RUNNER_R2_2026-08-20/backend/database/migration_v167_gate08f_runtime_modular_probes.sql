-- Gate08F — Runtime modular probes / no Cerebro end-to-end
-- Static schema contract only; no runtime PASS is implied.
CREATE TABLE IF NOT EXISTS gate08f_runtime_probe_contracts (
    id BIGSERIAL PRIMARY KEY,
    owner_id TEXT NOT NULL,
    probe_id TEXT NOT NULL,
    probe_family TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'PLANNED',
    evidence_hash TEXT NULL,
    environment_scope TEXT NULL,
    redaction_status TEXT NOT NULL DEFAULT 'NOT_EXECUTED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_id, probe_id)
);
CREATE INDEX IF NOT EXISTS idx_gate08f_runtime_probe_contracts_owner_family
    ON gate08f_runtime_probe_contracts(owner_id, probe_family);
