-- Vemoria MB0→MB15 convergence hardening.
-- Memory-scan metadata is strictly owner-scoped. Raw device bytes never live here.
-- v261-v268 are intentionally reserved for the historical MB15 R5 reconstruction.

BEGIN;

ALTER TABLE memory_scan_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE memory_scan_sessions FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS memory_scan_sessions_owner_isolation ON memory_scan_sessions;
CREATE POLICY memory_scan_sessions_owner_isolation ON memory_scan_sessions
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

ALTER TABLE memory_scan_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE memory_scan_items FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS memory_scan_items_owner_isolation ON memory_scan_items;
CREATE POLICY memory_scan_items_owner_isolation ON memory_scan_items
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

ALTER TABLE memory_scan_audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE memory_scan_audit_log FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS memory_scan_audit_log_owner_isolation ON memory_scan_audit_log;
CREATE POLICY memory_scan_audit_log_owner_isolation ON memory_scan_audit_log
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid)
    WITH CHECK (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::uuid);

COMMIT;
