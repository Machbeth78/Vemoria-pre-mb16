-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V3.6 — Migration V17 — Search & Knowledge Engine
CREATE TABLE IF NOT EXISTS search_index (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    target_tipo TEXT NOT NULL,
    target_id   UUID NOT NULL,
    contenuto   TEXT NOT NULL,
    creato_il   TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (target_tipo, target_id)
);
CREATE INDEX IF NOT EXISTS idx_search_tipo     ON search_index(target_tipo);
CREATE INDEX IF NOT EXISTS idx_search_contenuto ON search_index USING gin(to_tsvector('italian', contenuto));
