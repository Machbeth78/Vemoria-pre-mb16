-- VEMORA — Migration V83: Chat relazionale operativa
-- Creatore e proprietario: Devoti Massimo
-- Copyright (c) 2026 Devoti Massimo
--
-- Chat relazionale-operativa Vemora: non clone WhatsApp, strumento operativo.
-- Ogni thread vive dentro un workspace (personal/company).
-- Messaggi possono portare documenti, richieste firma, prove.

-- ── Thread ────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS chat_thread (
    id                  UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    workspace_type      TEXT        NOT NULL DEFAULT 'personal'
                                    CHECK (workspace_type IN ('personal', 'company')),
    workspace_id        TEXT        NOT NULL DEFAULT 'personal',
    thread_type         TEXT        NOT NULL DEFAULT 'direct'
                                    CHECK (thread_type IN ('direct', 'group', 'system')),
    created_by          UUID        REFERENCES utenti(id) ON DELETE SET NULL,
    titolo              TEXT,                          -- usato per gruppi; per direct, derivato dai partecipanti
    creato_il           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    aggiornato_il       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    archived_at         TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_chat_thread_workspace
    ON chat_thread(workspace_type, workspace_id, aggiornato_il DESC);
CREATE INDEX IF NOT EXISTS idx_chat_thread_created_by
    ON chat_thread(created_by);

-- ── Partecipanti ──────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS chat_partecipanti (
    id                  UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    thread_id           UUID        NOT NULL REFERENCES chat_thread(id) ON DELETE CASCADE,
    user_id             UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    role                TEXT        NOT NULL DEFAULT 'member'
                                    CHECK (role IN ('owner', 'admin', 'member')),
    joined_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    left_at             TIMESTAMPTZ,
    UNIQUE (thread_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_chat_partecipanti_user
    ON chat_partecipanti(user_id, thread_id);
CREATE INDEX IF NOT EXISTS idx_chat_partecipanti_thread
    ON chat_partecipanti(thread_id);

-- ── Messaggi ──────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS chat_messaggi (
    id                  UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    thread_id           UUID        NOT NULL REFERENCES chat_thread(id) ON DELETE CASCADE,
    sender_user_id      UUID        REFERENCES utenti(id) ON DELETE SET NULL,
    sender_role         TEXT        NOT NULL DEFAULT 'member',
    -- Tipo messaggio
    tipo                TEXT        NOT NULL DEFAULT 'text'
                                    CHECK (tipo IN ('text','document','signature_request',
                                                    'acceptance_request','proof','system')),
    testo               TEXT,
    -- Collegamento a oggetti Vemora
    documento_id        UUID        REFERENCES documenti(id) ON DELETE SET NULL,
    evento_invio_id     UUID        REFERENCES eventi_invio(id) ON DELETE SET NULL,
    firma_sessione_id   UUID        REFERENCES firma_sessioni(id) ON DELETE SET NULL,
    related_memory_event_id TEXT,                      -- riferimento evento memoria (stringa UUID)
    -- Metadati
    payload_json        JSONB,                         -- dati aggiuntivi per tipo messaggio
    creato_il           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    edited_at           TIMESTAMPTZ,
    deleted_at          TIMESTAMPTZ                    -- soft delete
);

CREATE INDEX IF NOT EXISTS idx_chat_messaggi_thread
    ON chat_messaggi(thread_id, creato_il);
CREATE INDEX IF NOT EXISTS idx_chat_messaggi_sender
    ON chat_messaggi(sender_user_id);
CREATE INDEX IF NOT EXISTS idx_chat_messaggi_documento
    ON chat_messaggi(documento_id) WHERE documento_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_chat_messaggi_firma
    ON chat_messaggi(firma_sessione_id) WHERE firma_sessione_id IS NOT NULL;

-- ── Read state ────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS chat_read_state (
    id                  UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    thread_id           UUID        NOT NULL REFERENCES chat_thread(id) ON DELETE CASCADE,
    user_id             UUID        NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    last_read_message_id UUID       REFERENCES chat_messaggi(id) ON DELETE SET NULL,
    last_read_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (thread_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_chat_read_state_user
    ON chat_read_state(user_id, thread_id);

-- Registra migrazione
-- Nota: registrazione migration demandata al migration runner/registry service.
-- Se la migration viene applicata manualmente via SQL puro, usare poi adopt-existing o status nel runner.
