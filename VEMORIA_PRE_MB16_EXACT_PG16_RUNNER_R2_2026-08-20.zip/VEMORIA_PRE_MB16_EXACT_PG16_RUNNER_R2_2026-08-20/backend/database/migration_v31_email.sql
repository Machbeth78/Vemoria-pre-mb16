-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- VEMORA V4.6 — Migration V31 — Email → Memoria
-- Tabelle per email ricevute via inoltro.
-- token_ricezione su utenti permette di identificare l'utente
-- dall'indirizzo destinatario: m-{token}@mail.vemora.app

ALTER TABLE utenti
    ADD COLUMN IF NOT EXISTS email_token      TEXT UNIQUE,  -- token inoltro (null = non attivato)
    ADD COLUMN IF NOT EXISTS email_attivo     BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS email_memora (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utente_id       UUID NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    message_id      TEXT UNIQUE,          -- Message-ID header: deduplicazione
    mittente        TEXT NOT NULL,
    mittente_nome   TEXT,
    destinatario    TEXT NOT NULL,
    oggetto         TEXT,
    corpo_testo     TEXT,                 -- plain text estratto, max 50k char
    data_email      TIMESTAMP,
    creato_il       TIMESTAMP NOT NULL DEFAULT NOW(),
    memoria_id      UUID REFERENCES memorie(id) ON DELETE SET NULL,
    contatto_id     UUID REFERENCES contatti_rubrica(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS email_allegati (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email_id     UUID NOT NULL REFERENCES email_memora(id) ON DELETE CASCADE,
    nome_file    TEXT NOT NULL,
    mime_type    TEXT,
    dimensione   INT,
    percorso     TEXT,              -- percorso su /data/vemora/email/
    documento_id UUID REFERENCES documenti(id) ON DELETE SET NULL,
    creato_il    TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_email_utente   ON email_memora(utente_id);
CREATE INDEX IF NOT EXISTS idx_email_mittente ON email_memora(mittente);
CREATE INDEX IF NOT EXISTS idx_email_data     ON email_memora(data_email DESC);
CREATE INDEX IF NOT EXISTS idx_allegati_email ON email_allegati(email_id);

COMMENT ON COLUMN utenti.email_token IS
    'Token inoltro email. Indirizzo: m-{email_token}@mail.vemora.app';
