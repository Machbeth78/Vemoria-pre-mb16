-- Vemoria
-- Copyright 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized use is prohibited.
--
-- MB12-P0 R1C — Integrity closure for revision history.
-- Additive, idempotent migration: makes mb12_p0_revision_history append-only,
-- deduplicates any pre-existing rows and restricts the application role.

BEGIN;

-- Ensure the application role exists. Use a dedicated role name for MB12-P0.
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mb12_p0_app') THEN
        CREATE ROLE mb12_p0_app NOLOGIN;
    END IF;
END $$;

-- Deduplicate revision history deterministically before adding a unique
-- constraint. Keep the row with the smallest (oldest) history_id.
DROP TABLE IF EXISTS mb12_p0_r1c_integrity_report;
CREATE TABLE mb12_p0_r1c_integrity_report (
    report_id SERIAL PRIMARY KEY,
    deduplicated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    duplicate_count INT NOT NULL,
    surviving_history_id UUID,
    removed_history_ids UUID[]
);

DO $$
DECLARE
    all_ids UUID[];
    keeper UUID;
    removed UUID[];
    dup_count INT;
    total_dupes INT := 0;
BEGIN
    FOR all_ids IN
        SELECT array_agg(history_id ORDER BY history_id::text)
          FROM mb12_p0_revision_history
         GROUP BY owner_user_id, record_id, revision
        HAVING COUNT(*) > 1
    LOOP
        keeper := all_ids[1];
        dup_count := array_length(all_ids, 1) - 1;
        total_dupes := total_dupes + dup_count;
        removed := all_ids[2:array_length(all_ids, 1)];
        DELETE FROM mb12_p0_revision_history
         WHERE history_id = ANY(removed);
        INSERT INTO mb12_p0_r1c_integrity_report(
            duplicate_count, surviving_history_id, removed_history_ids
        ) VALUES (
            dup_count, keeper, removed
        );
    END LOOP;
    RAISE NOTICE 'mb12_p0_r1c_integrity_closure: removed % duplicate history rows', total_dupes;
END $$;

-- Unique constraint ensuring one revision per owner + record.
ALTER TABLE mb12_p0_revision_history
    DROP CONSTRAINT IF EXISTS uq_mb12_history_owner_record_revision;
ALTER TABLE mb12_p0_revision_history
    ADD CONSTRAINT uq_mb12_history_owner_record_revision
    UNIQUE (owner_user_id, record_id, revision);

-- Append-only trigger: reject any UPDATE or DELETE on history.
CREATE OR REPLACE FUNCTION mb12_p0_history_immutable()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'UPDATE' THEN
        RAISE EXCEPTION 'mb12_p0_revision_history is append-only: UPDATE is not allowed';
    ELSIF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'mb12_p0_revision_history is append-only: DELETE is not allowed';
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_mb12_p0_history_immutable ON mb12_p0_revision_history;
CREATE TRIGGER trg_mb12_p0_history_immutable
    BEFORE UPDATE OR DELETE ON mb12_p0_revision_history
    FOR EACH ROW EXECUTE FUNCTION mb12_p0_history_immutable();

-- Row-level security must remain active.
ALTER TABLE mb12_p0_revision_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE mb12_p0_revision_history FORCE ROW LEVEL SECURITY;

-- Restrict the application role to append-only access.
GRANT USAGE ON SCHEMA public TO mb12_p0_app;
REVOKE ALL PRIVILEGES ON TABLE mb12_p0_revision_history FROM mb12_p0_app;
GRANT SELECT, INSERT ON TABLE mb12_p0_revision_history TO mb12_p0_app;

REVOKE ALL PRIVILEGES ON TABLE mb12_p0_r1c_integrity_report FROM PUBLIC;
GRANT SELECT ON TABLE mb12_p0_r1c_integrity_report TO mb12_p0_app;

COMMIT;
