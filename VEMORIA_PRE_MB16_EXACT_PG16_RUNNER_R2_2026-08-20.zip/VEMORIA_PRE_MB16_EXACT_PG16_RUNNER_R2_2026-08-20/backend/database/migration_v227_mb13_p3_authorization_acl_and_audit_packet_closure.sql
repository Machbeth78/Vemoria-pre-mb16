-- migration_v227_mb13_p3_authorization_acl_and_audit_packet_closure.sql
-- MB13-P3 v227 (final corrective): narrow authorization table ACL to column-level
-- revocation-only UPDATE, remove EXECUTE on internal trigger helper from app/legacy
-- roles, and verify the corrected state. No new business logic is introduced.
BEGIN;

-- ============================================================================
-- 1. Authorization table: column-level UPDATE only on revocation columns
-- ============================================================================
DO $$
DECLARE
    v_app_roles TEXT[] := ARRAY['PUBLIC','test_app','mb13_p3_api','mb13_p3_executor','mb13_p3_writer','mb13_p3_validator','mb13_p3_pack_mutator','mb13_p3_pack_lifecycle_owner'];
    r TEXT;
BEGIN
    -- Ensure no broad table-level UPDATE remains for any app/legacy role.
    FOREACH r IN ARRAY v_app_roles LOOP
        EXECUTE format('REVOKE ALL PRIVILEGES ON TABLE public.mb13_p3_action_pack_authorization FROM %s',
            CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END);
    END LOOP;

    -- Reset lifecycle executor to the minimal set: SELECT + INSERT table-level,
    -- plus column-level UPDATE only on the three revocation fields.
    EXECUTE 'REVOKE ALL PRIVILEGES ON TABLE public.mb13_p3_action_pack_authorization FROM mb13_p3_pack_lifecycle_executor';
    EXECUTE 'GRANT SELECT, INSERT ON TABLE public.mb13_p3_action_pack_authorization TO mb13_p3_pack_lifecycle_executor';
    EXECUTE 'GRANT UPDATE (revoked, revoked_at, revocation_event_id) ON TABLE public.mb13_p3_action_pack_authorization TO mb13_p3_pack_lifecycle_executor';

    -- Data owner retains ALL.
    EXECUTE 'GRANT ALL PRIVILEGES ON TABLE public.mb13_p3_action_pack_authorization TO mb13_p3_pack_data_owner';
END $$;

-- ============================================================================
-- 2. Internal trigger/helper functions must not be executable by app/legacy roles
-- ============================================================================
DO $$
DECLARE
    v_app_roles TEXT[] := ARRAY['PUBLIC','test_app','mb13_p3_api','mb13_p3_executor','mb13_p3_writer','mb13_p3_validator','mb13_p3_pack_mutator','mb13_p3_pack_lifecycle_owner'];
    v_trigger_helpers TEXT[] := ARRAY[
        'public.mb13_p3_action_pack_authorization_append_only()',
        'public.mb13_p3_action_pack_evidence_immutable()',
        'public.mb13_p3_action_pack_result_immutable()',
        'public.mb13_p3_action_pack_revision_immutable()',
        'public.mb13_p3_action_pack_timeline_immutable()',
        'public.mb13_p3_action_pack_terminal_attempt_sync()',
        'public.mb13_p3_action_pack_monitor_policy_hash()',
        'public.mb13_p3_action_pack_transition_guard()',
        'public.mb13_p3_action_pack_result_evidence_guard()',
        'public.mb13_p3_recovery_audit_immutable()'
    ];
    r TEXT; fn TEXT;
BEGIN
    FOREACH fn IN ARRAY v_trigger_helpers LOOP
        FOREACH r IN ARRAY v_app_roles LOOP
            BEGIN
                EXECUTE format('REVOKE ALL ON FUNCTION %s FROM %s', fn,
                    CASE WHEN r = 'PUBLIC' THEN 'PUBLIC' ELSE quote_ident(r) END);
            EXCEPTION WHEN OTHERS THEN
                NULL;
            END;
        END LOOP;
        -- Lifecycle executor owns the helper functions and must retain EXECUTE.
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO mb13_p3_pack_lifecycle_executor', fn);
    END LOOP;
END $$;

-- The governed mutation gate is a SECURITY INVOKER trigger on the data-owner
-- table; it must not be an application entrypoint.  Revoke from all app and
-- legacy roles, then grant only to the lifecycle executor and data owner.
REVOKE ALL ON FUNCTION public.mb13_p3_action_pack_governed_mutation() FROM PUBLIC, test_app, mb13_p3_api, mb13_p3_executor, mb13_p3_writer, mb13_p3_validator, mb13_p3_pack_mutator, mb13_p3_pack_lifecycle_owner;
GRANT EXECUTE ON FUNCTION public.mb13_p3_action_pack_governed_mutation() TO mb13_p3_pack_lifecycle_executor, mb13_p3_pack_data_owner;

-- ============================================================================
-- 3. Grant lifecycle executor EXECUTE on the canonical revocation entrypoint
-- ============================================================================
GRANT EXECUTE ON FUNCTION public.mb13_p3_revoke_action_pack(uuid, uuid) TO mb13_p3_pack_lifecycle_executor;

-- ============================================================================
-- 4. Verify the corrected ACLs and helper-function EXECUTE isolation
-- ============================================================================
DO $$
DECLARE
    v_app_roles TEXT[] := ARRAY['test_app','mb13_p3_api','mb13_p3_executor','mb13_p3_writer','mb13_p3_validator','mb13_p3_pack_mutator','mb13_p3_pack_lifecycle_owner'];
    r TEXT;
BEGIN
    IF has_table_privilege('mb13_p3_pack_lifecycle_executor', 'public.mb13_p3_action_pack_authorization', 'UPDATE') THEN
        RAISE EXCEPTION 'migration_v227 lifecycle executor still has broad UPDATE on mb13_p3_action_pack_authorization';
    END IF;

    IF NOT has_column_privilege('mb13_p3_pack_lifecycle_executor', 'public.mb13_p3_action_pack_authorization', 'revoked', 'UPDATE') THEN
        RAISE EXCEPTION 'migration_v227 lifecycle executor missing UPDATE on mb13_p3_action_pack_authorization.revoked';
    END IF;
    IF NOT has_column_privilege('mb13_p3_pack_lifecycle_executor', 'public.mb13_p3_action_pack_authorization', 'revoked_at', 'UPDATE') THEN
        RAISE EXCEPTION 'migration_v227 lifecycle executor missing UPDATE on mb13_p3_action_pack_authorization.revoked_at';
    END IF;
    IF NOT has_column_privilege('mb13_p3_pack_lifecycle_executor', 'public.mb13_p3_action_pack_authorization', 'revocation_event_id', 'UPDATE') THEN
        RAISE EXCEPTION 'migration_v227 lifecycle executor missing UPDATE on mb13_p3_action_pack_authorization.revocation_event_id';
    END IF;

    FOREACH r IN ARRAY v_app_roles LOOP
        IF has_table_privilege(r, 'public.mb13_p3_action_pack_authorization', 'UPDATE') THEN
            RAISE EXCEPTION 'migration_v227 app role % has UPDATE on mb13_p3_action_pack_authorization', r;
        END IF;
        IF has_function_privilege(r, 'public.mb13_p3_action_pack_governed_mutation()', 'EXECUTE') THEN
            RAISE EXCEPTION 'migration_v227 app role % can EXECUTE internal trigger helper mb13_p3_action_pack_governed_mutation', r;
        END IF;
    END LOOP;
END $$;

COMMIT;
