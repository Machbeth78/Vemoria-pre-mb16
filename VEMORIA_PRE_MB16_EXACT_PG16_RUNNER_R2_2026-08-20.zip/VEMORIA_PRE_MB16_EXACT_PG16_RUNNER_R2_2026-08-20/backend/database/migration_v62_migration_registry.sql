-- Vemoria
-- Copyright © 2026 Devoti Massimo. All rights reserved.
-- Proprietary and confidential software. Unauthorized copying, modification, distribution or use is prohibited.

-- database/migration_v62_migration_registry.sql
-- Registro applicazioni migration additive post-init_full.

CREATE TABLE IF NOT EXISTS schema_migration_state (
    migration_name       TEXT PRIMARY KEY,
    migration_sha256     TEXT NOT NULL,
    source_path          TEXT NOT NULL,
    applied_by           TEXT NULL,
    applied_notes        TEXT NULL,
    applied_il           TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_schema_migration_state_applied_il
    ON schema_migration_state(applied_il DESC);
