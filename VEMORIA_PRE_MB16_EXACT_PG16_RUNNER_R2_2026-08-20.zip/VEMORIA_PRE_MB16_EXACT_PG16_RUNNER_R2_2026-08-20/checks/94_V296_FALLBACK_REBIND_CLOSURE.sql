-- Vemoria PRE-MB16 runtime closure.
-- Repairs v296 wrappers after intentional cleanup of *_pre296 transport helpers.
-- Semantics are the v203 canonical bodies plus the narrow v296 generic_entity exception.
-- No canonical migration source is modified.

CREATE OR REPLACE FUNCTION public.mb13_p0_validate_target(
    p_owner UUID,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_for_active BOOLEAN
)
RETURNS void AS $$
DECLARE
    v_id TEXT;
    v_revision INTEGER;
    v_hash TEXT;
    v_state TEXT;
    v_source_type TEXT;
    v_doc RECORD;
    v_dossier RECORD;
    v_source RECORD;
    v_decision RECORD;
    v_rev_hash TEXT;
BEGIN
    IF jsonb_typeof(p_target_ref) <> 'object' THEN
        RAISE EXCEPTION 'mb13_p0_target_ref_invalid';
    END IF;
    IF p_target_ref->>'id' IS NULL OR p_target_ref->>'revision' IS NULL OR p_target_ref->>'payload_hash' IS NULL OR p_target_ref->>'owner_user_id' IS NULL OR p_target_ref->>'state' IS NULL THEN
        RAISE EXCEPTION 'mb13_p0_target_ref_missing';
    END IF;
    v_id := p_target_ref->>'id';
    BEGIN
        v_revision := (p_target_ref->>'revision')::INTEGER;
    EXCEPTION WHEN invalid_text_representation THEN
        RAISE EXCEPTION 'mb13_p0_target_ref_invalid';
    END;
    v_hash := p_target_ref->>'payload_hash';
    v_state := p_target_ref->>'state';

    IF p_target_ref->>'owner_user_id' IS DISTINCT FROM p_owner::text THEN
        RAISE EXCEPTION 'mb13_p0_target_owner_mismatch';
    END IF;

    IF p_target_type = 'generic_entity' THEN
        IF p_for_active THEN
            IF p_target_ref->>'source_type' IS NULL THEN
                RAISE EXCEPTION 'mb13_p0_target_ref_missing';
            END IF;
            v_source_type := p_target_ref->>'source_type';
            IF v_revision <> 1 OR v_state <> 'active' THEN
                RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
            END IF;
            IF lower(v_hash) !~ '^[0-9a-f]{64}$' THEN
                RAISE EXCEPTION 'mb13_p0_target_authoritative_hash_missing';
            END IF;
            IF v_source_type NOT IN ('receipt_public_entity', 'owner_goal_watch') THEN
                RAISE EXCEPTION 'mb13_p0_target_type_not_activatable';
            END IF;
        END IF;
        RETURN;
    END IF;

    IF p_target_type IN ('rule','identity','object') THEN
        IF p_for_active THEN
            RAISE EXCEPTION 'mb13_p0_target_type_not_activatable';
        END IF;
        RETURN;
    END IF;

    IF p_target_type = 'document' THEN
        -- Prefer the append-only revision snapshot.  If no snapshot exists yet,
        -- fall back to the original documenti row for P0 monitor creation.
        SELECT state, payload_hash INTO v_doc
          FROM public.mb13_p1_document_revision
         WHERE owner_user_id = p_owner
           AND document_id = v_id::UUID
           AND revision = v_revision
         FOR SHARE;
        IF NOT FOUND THEN
            SELECT stato_elaborazione AS state, hash_file AS payload_hash INTO v_doc
              FROM public.documenti
             WHERE id = v_id::UUID
               AND proprietario_id = p_owner
             FOR SHARE;
            IF NOT FOUND THEN
                RAISE EXCEPTION 'mb13_p0_target_not_found';
            END IF;
            -- In legacy mode only revision 1 can be validated from documenti.
            IF v_revision <> 1 THEN
                RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
            END IF;
            IF v_doc.payload_hash IS NULL OR length(trim(v_doc.payload_hash)) = 0 THEN
                RAISE EXCEPTION 'mb13_p0_target_authoritative_hash_missing';
            END IF;
            IF v_doc.payload_hash <> v_hash OR v_doc.state <> v_state THEN
                RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
            END IF;
            RETURN;
        END IF;
        IF v_doc.state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_target_revoked';
        END IF;
        IF v_doc.state <> 'memorizzato' THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_doc.payload_hash IS NULL OR length(trim(v_doc.payload_hash)) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_target_authoritative_hash_missing';
        END IF;
        IF v_doc.payload_hash <> v_hash OR v_state <> 'memorizzato' THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        RETURN;
    END IF;

    IF p_target_type IN ('dossier','contract','offer') THEN
        SELECT current_revision, payload_hash, state INTO v_dossier
          FROM public.mb12_p1_offer_contract
         WHERE owner_user_id = p_owner
           AND dossier_id = v_id::UUID
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_target_not_found';
        END IF;
        IF v_dossier.state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_target_revoked';
        END IF;
        IF v_dossier.state <> 'normalized' THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_dossier.current_revision <> v_revision
           OR v_dossier.payload_hash IS NULL OR length(trim(v_dossier.payload_hash)) = 0
           OR v_dossier.payload_hash <> v_hash
           OR v_state <> 'normalized' THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        SELECT payload_hash INTO v_rev_hash
          FROM public.mb12_p1_offer_contract_revision
         WHERE owner_user_id = p_owner
           AND dossier_id = v_id::UUID
           AND revision = v_revision
         FOR SHARE;
        IF NOT FOUND OR v_rev_hash <> v_hash THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        RETURN;
    END IF;

    IF p_target_type = 'source' THEN
        IF v_revision <> 1 THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        SELECT
            b.content_hash,
            b.status,
            b.revoked_at,
            b.source_id::text AS binding_source_id,
            a.status AS authority_status,
            a.source_state,
            a.revocation_state,
            s.status AS source_status,
            s.revoked_at AS source_revoked,
            i.memory_state,
            i.deleted_at,
            i.content_hash AS item_hash,
            l.id AS evidence_id
          INTO v_source
          FROM public.mb12_p0_source_card_binding b
          JOIN public.canonical_source_card_authority a
            ON a.owner_user_id = b.owner_user_id
           AND a.source_card_id = b.source_card_id
          JOIN public.authorized_memory_sources s
            ON s.id = b.source_id
           AND s.user_id = b.owner_user_id
          JOIN public.authorized_memory_inventory_items i
            ON i.id = b.source_revision_id
           AND i.user_id = b.owner_user_id
           AND i.source_id = b.source_id
          JOIN public.authorized_memory_activity_log l
            ON l.id = b.evidence_id
           AND l.user_id = b.owner_user_id
         WHERE b.owner_user_id = p_owner
           AND b.source_card_id = v_id
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_target_not_found';
        END IF;
        IF v_source.status <> 'active' OR v_source.revoked_at IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p0_target_revoked';
        END IF;
        IF v_source.authority_status <> 'active'
           OR v_source.source_state <> 'active'
           OR v_source.revocation_state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_source.source_status <> 'active' OR v_source.source_revoked IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_source.memory_state = 'revoked' OR v_source.deleted_at IS NOT NULL THEN
            RAISE EXCEPTION 'mb13_p0_target_not_available';
        END IF;
        IF v_source.content_hash IS NULL OR length(trim(v_source.content_hash)) = 0 THEN
            RAISE EXCEPTION 'mb13_p0_target_authoritative_hash_missing';
        END IF;
        IF v_source.content_hash <> v_hash OR v_state <> 'active' THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        RETURN;
    END IF;

    IF p_target_type = 'decision' THEN
        SELECT current_revision, payload_hash, state INTO v_decision
          FROM public.mb12_p4_governed_explainable_ranking
         WHERE owner_user_id = p_owner
           AND ranking_id = v_id::UUID
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_target_not_found';
        END IF;
        IF v_decision.state = 'revoked' THEN
            RAISE EXCEPTION 'mb13_p0_target_revoked';
        END IF;
        IF v_decision.current_revision <> v_revision
           OR v_decision.payload_hash IS NULL OR length(trim(v_decision.payload_hash)) = 0
           OR v_decision.payload_hash <> v_hash
           OR v_state <> v_decision.state THEN
            RAISE EXCEPTION 'mb13_p0_target_reference_not_current';
        END IF;
        RETURN;
    END IF;

    RAISE EXCEPTION 'mb13_p0_target_type_not_supported';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_validate_target(UUID, TEXT, JSONB, BOOLEAN) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p0_validate_target(UUID, TEXT, JSONB, BOOLEAN) FROM anon, authenticated, service_role;


CREATE OR REPLACE FUNCTION public.mb13_p0_lock_and_verify_consents(
    p_owner UUID,
    p_consent_refs JSONB,
    p_target_type TEXT,
    p_target_ref JSONB,
    p_required BOOLEAN,
    p_strict_relation BOOLEAN DEFAULT TRUE
)
RETURNS JSONB AS $$
DECLARE
    v_ref JSONB;
    v_source_id TEXT;
    v_grant_id TEXT;
    v_grant RECORD;
    v_normalized JSONB;
    v_count INTEGER := 0;
    v_provenance_source_refs JSONB;
    v_provenance_evidence_refs JSONB;
    v_required_pairs TEXT[];
    v_provided_pairs TEXT[];
    v_ps TEXT;
    v_document_id UUID;
    v_allowed_documents JSONB;
    v_target_source_id TEXT;
    v_source_type TEXT;
BEGIN
    IF p_target_type = 'generic_entity' THEN
        IF p_consent_refs IS NULL OR jsonb_typeof(p_consent_refs) <> 'array' THEN
            RAISE EXCEPTION 'mb13_p0_consent_refs_invalid';
        END IF;
        v_source_type := p_target_ref->>'source_type';
        IF v_source_type IN ('receipt_public_entity', 'owner_goal_watch') THEN
            IF jsonb_array_length(p_consent_refs) <> 0 THEN
                RAISE EXCEPTION 'mb13_p0_consent_ref_invalid';
            END IF;
            RETURN '[]'::jsonb;
        END IF;
    END IF;

    IF p_consent_refs IS NULL OR jsonb_typeof(p_consent_refs) <> 'array' THEN
        RAISE EXCEPTION 'mb13_p0_consent_refs_invalid';
    END IF;
    IF p_required AND jsonb_array_length(p_consent_refs) = 0 THEN
        RAISE EXCEPTION 'mb13_p0_consent_required';
    END IF;

    v_normalized := public.mb13_p0_normalize_jsonb_array(p_consent_refs);

    -- Gather the source:grant pairs the target revision claims it depends on.
    IF p_target_type IN ('dossier','contract','offer') THEN
        SELECT array_agg(DISTINCT (COALESCE(s->>'source_id','') || ':' || COALESCE(s->>'grant_id','')))
          INTO v_required_pairs
          FROM public.mb12_p1_offer_contract_revision r,
               jsonb_array_elements(r.source_refs) AS s
         WHERE r.owner_user_id = p_owner
           AND r.dossier_id = (p_target_ref->>'id')::UUID
           AND r.revision = (p_target_ref->>'revision')::INTEGER
           AND s->>'source_id' IS NOT NULL;
    ELSIF p_target_type = 'decision' THEN
        SELECT array_agg(DISTINCT (COALESCE(s->>'source_id','') || ':' || COALESCE(s->>'grant_id','')))
          INTO v_required_pairs
          FROM public.mb12_p4_governed_explainable_ranking_revision rev,
               jsonb_array_elements(rev.result_payload->'source_refs') AS s
         WHERE rev.owner_user_id = p_owner
           AND rev.ranking_id = (p_target_ref->>'id')::UUID
           AND rev.revision = (p_target_ref->>'revision')::INTEGER
           AND s->>'source_id' IS NOT NULL;
    ELSIF p_target_type = 'source' THEN
        SELECT source_id::text INTO v_target_source_id
          FROM public.mb12_p0_source_card_binding
         WHERE owner_user_id = p_owner
           AND source_card_id = p_target_ref->>'id';
    END IF;

    SELECT array_agg(DISTINCT (COALESCE(c->>'source_id','') || ':' || COALESCE(c->>'grant_id','')))
      INTO v_provided_pairs
      FROM jsonb_array_elements(v_normalized) AS c
     WHERE c->>'source_id' IS NOT NULL
       AND c->>'grant_id' IS NOT NULL;

    IF p_required AND p_target_type IN ('dossier','contract','offer','decision') THEN
        IF v_required_pairs IS NOT NULL THEN
            FOREACH v_ps IN ARRAY v_required_pairs LOOP
                IF v_provided_pairs IS NULL OR NOT (v_ps = ANY(v_provided_pairs)) THEN
                    RAISE EXCEPTION 'mb13_p0_consent_coverage_incomplete';
                END IF;
            END LOOP;
        END IF;
    END IF;

    IF p_required AND p_target_type = 'source' THEN
        IF v_target_source_id IS NULL THEN
            RAISE EXCEPTION 'mb13_p0_consent_source_not_related_to_target';
        END IF;
        IF NOT EXISTS (
            SELECT 1
              FROM jsonb_array_elements(v_normalized) AS c
             WHERE c->>'source_id' = v_target_source_id
        ) THEN
            RAISE EXCEPTION 'mb13_p0_consent_coverage_incomplete';
        END IF;
    END IF;

    SELECT source_refs, evidence_refs INTO v_provenance_source_refs, v_provenance_evidence_refs
      FROM public.mb13_p0_get_target_provenance(p_owner, p_target_type, p_target_ref);

    IF p_target_type IN ('dossier','contract','offer','source','decision') THEN
        SELECT array_agg(DISTINCT (((s->>'source_id') || ':' || COALESCE(s->>'grant_id',''))))
          INTO v_required_pairs
          FROM jsonb_array_elements(v_provenance_source_refs) AS s
         WHERE (s->>'source_id') IS NOT NULL
           AND jsonb_typeof(s) = 'object';
    END IF;

    FOR v_ref IN SELECT value FROM jsonb_array_elements(v_normalized) LOOP
        v_source_id := v_ref->>'source_id';
        v_grant_id := v_ref->>'grant_id';
        IF v_source_id IS NULL OR v_grant_id IS NULL THEN
            RAISE EXCEPTION 'mb13_p0_consent_ref_invalid';
        END IF;

        SELECT *
          INTO v_grant
          FROM public.authorized_memory_consent_grants
         WHERE user_id = p_owner
           AND source_id = v_source_id::UUID
           AND id = v_grant_id::UUID
           AND status = 'active'
           AND revoked_at IS NULL
           AND (expires_at IS NULL OR expires_at > NOW())
         FOR SHARE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p0_consent_revoked_or_invalid';
        END IF;

        IF v_grant.action NOT IN ('read_metadata','inventory_existence')
           OR v_grant.plane <> 'EXISTENCE' THEN
            RAISE EXCEPTION 'mb13_p0_consent_action_incompatible';
        END IF;

        IF p_target_type IN ('dossier','contract','offer','decision') AND p_strict_relation THEN
            v_ps := v_source_id || ':' || v_grant_id;
            IF v_required_pairs IS NULL OR NOT (v_ps = ANY(v_required_pairs)) THEN
                RAISE EXCEPTION 'mb13_p0_provenance_not_related_to_target';
            END IF;
        END IF;

        IF p_target_type = 'source' THEN
            IF NOT EXISTS (
                SELECT 1 FROM public.mb12_p0_source_card_binding b
                 WHERE b.owner_user_id = p_owner
                   AND b.source_card_id = (p_target_ref->>'id')
                   AND b.source_id = v_source_id::UUID
                   AND b.grant_id = v_grant_id::UUID
            ) THEN
                RAISE EXCEPTION 'mb13_p0_provenance_not_related_to_target';
            END IF;
        END IF;

        IF p_target_type = 'document' THEN
            v_document_id := (p_target_ref->>'id')::UUID;
            v_allowed_documents := NULLIF(v_grant.constraints->'data_scope'->'allowed_documents', 'null'::jsonb);
            IF v_allowed_documents IS NULL
               OR jsonb_typeof(v_allowed_documents) <> 'array'
               OR NOT EXISTS (
                    SELECT 1 FROM jsonb_array_elements_text(v_allowed_documents) AS ad
                     WHERE ad = v_document_id::text
                  )
            THEN
                RAISE EXCEPTION 'mb13_p0_document_capability_not_bound';
            END IF;
        END IF;

        v_count := v_count + 1;
    END LOOP;

    IF p_required AND v_count = 0 THEN
        RAISE EXCEPTION 'mb13_p0_consent_required';
    END IF;

    RETURN v_normalized;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN, BOOLEAN) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN, BOOLEAN) FROM anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN, BOOLEAN) TO mb13_p1_executor;
GRANT EXECUTE ON FUNCTION public.mb13_p0_lock_and_verify_consents(UUID, JSONB, TEXT, JSONB, BOOLEAN, BOOLEAN) TO mb13_p1_writer;

