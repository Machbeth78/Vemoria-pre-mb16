-- Run BEFORE applying Vemoria migrations. Read-only.
SELECT version() AS postgres_version;
SHOW server_version_num;
SELECT current_user AS current_role, r.rolsuper, r.rolbypassrls
FROM pg_roles r WHERE r.rolname = current_user;
SELECT name, default_version, installed_version
FROM pg_available_extensions
WHERE name IN ('uuid-ossp','pgcrypto','pg_trgm')
ORDER BY name;
