\set ON_ERROR_STOP on

-- Exact version gate.
DO $$
DECLARE v text := current_setting('server_version_num');
BEGIN
  IF v !~ '^16[0-9]{4}$' THEN
    RAISE EXCEPTION 'PRE_MB16_PG16_VERSION_FAIL server_version_num=%', v;
  END IF;
END $$;

-- Registry must terminate at v296 and contain exactly one v296 row.
DO $$
DECLARE n integer;
BEGIN
  SELECT count(*) INTO n
  FROM public.schema_migration_state
  WHERE migration_name='migration_v296_generic_interest_watch.sql';
  IF n <> 1 THEN
    RAISE EXCEPTION 'PRE_MB16_V296_REGISTRY_FAIL count=%', n;
  END IF;
END $$;

-- v296 owner table must be FORCE-RLS and have an owner policy.
DO $$
DECLARE rls boolean; frls boolean; pcount integer;
BEGIN
  SELECT c.relrowsecurity, c.relforcerowsecurity
    INTO rls, frls
  FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
  WHERE n.nspname='public' AND c.relname='generic_interest_watch_authorizations' AND c.relkind='r';
  IF COALESCE(rls,false) IS NOT TRUE OR COALESCE(frls,false) IS NOT TRUE THEN
    RAISE EXCEPTION 'PRE_MB16_V296_RLS_FAIL rls=% force=%', rls, frls;
  END IF;
  SELECT count(*) INTO pcount FROM pg_policies
   WHERE schemaname='public' AND tablename='generic_interest_watch_authorizations';
  IF pcount < 1 THEN
    RAISE EXCEPTION 'PRE_MB16_V296_POLICY_FAIL count=%', pcount;
  END IF;
END $$;

-- No application SECURITY DEFINER function in public may be executable by PUBLIC.
-- Extension-owned functions are excluded (e.g. pg_trgm).
DO $$
DECLARE n integer;
BEGIN
  SELECT count(*) INTO n
  FROM pg_proc p
  JOIN pg_namespace ns ON ns.oid=p.pronamespace
  WHERE ns.nspname='public'
    AND p.prosecdef
    AND has_function_privilege('public', p.oid, 'EXECUTE')
    AND NOT EXISTS (
      SELECT 1 FROM pg_depend d
      WHERE d.classid='pg_proc'::regclass AND d.objid=p.oid AND d.deptype='e'
    );
  IF n <> 0 THEN
    RAISE EXCEPTION 'PRE_MB16_PUBLIC_SD_EXECUTE_FAIL count=%', n;
  END IF;
END $$;

-- Application functions must have a fixed search_path. Extension-owned routines are excluded.
DO $$
DECLARE n integer;
BEGIN
  SELECT count(*) INTO n
  FROM pg_proc p
  JOIN pg_namespace ns ON ns.oid=p.pronamespace
  WHERE ns.nspname='public'
    AND NOT EXISTS (
      SELECT 1 FROM pg_depend d
      WHERE d.classid='pg_proc'::regclass AND d.objid=p.oid AND d.deptype='e'
    )
    AND NOT EXISTS (
      SELECT 1 FROM unnest(COALESCE(p.proconfig, ARRAY[]::text[])) cfg
      WHERE cfg LIKE 'search_path=%'
    );
  IF n <> 0 THEN
    RAISE EXCEPTION 'PRE_MB16_MUTABLE_APP_SEARCH_PATH_FAIL count=%', n;
  END IF;
END $$;

-- If Supabase Data API roles exist in a runner, they must have no direct public table/view/sequence privileges.
DO $$
DECLARE n integer;
BEGIN
  SELECT count(*) INTO n
  FROM information_schema.role_table_grants g
  WHERE g.table_schema='public'
    AND g.grantee IN ('anon','authenticated','service_role');
  IF n <> 0 THEN
    RAISE EXCEPTION 'PRE_MB16_EXTERNAL_TABLE_VIEW_ACL_FAIL count=%', n;
  END IF;

  SELECT count(*) INTO n
  FROM information_schema.role_usage_grants g
  WHERE g.object_schema='public'
    AND g.object_type='SEQUENCE'
    AND g.grantee IN ('anon','authenticated','service_role');
  IF n <> 0 THEN
    RAISE EXCEPTION 'PRE_MB16_EXTERNAL_SEQUENCE_ACL_FAIL count=%', n;
  END IF;
END $$;

-- No external execution on SECURITY DEFINER functions if those roles exist.
DO $$
DECLARE n integer;
BEGIN
  SELECT count(*) INTO n
  FROM pg_proc p
  JOIN pg_namespace ns ON ns.oid=p.pronamespace
  JOIN pg_roles r ON r.rolname IN ('anon','authenticated','service_role')
  WHERE ns.nspname='public' AND p.prosecdef
    AND has_function_privilege(r.oid, p.oid, 'EXECUTE')
    AND NOT EXISTS (
      SELECT 1 FROM pg_depend d
      WHERE d.classid='pg_proc'::regclass AND d.objid=p.oid AND d.deptype='e'
    );
  IF n <> 0 THEN
    RAISE EXCEPTION 'PRE_MB16_EXTERNAL_SD_EXECUTE_FAIL count=%', n;
  END IF;
END $$;

SELECT 'PRE_MB16_EXACT_PG16_SECURITY_RUNTIME_AUDIT_PASS' AS result;
