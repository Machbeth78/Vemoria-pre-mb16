-- DESTRUCTIVE ONLY INSIDE THIS TRANSACTION; ends with ROLLBACK.
-- Requires admin ability to CREATE/SET ROLE. If Supabase blocks role creation,
-- classify this specific owner-isolation smoke as NOT PROVEN in Supabase, not FAIL.
BEGIN;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='vemoria_supabase_rls_smoke') THEN
    CREATE ROLE vemoria_supabase_rls_smoke NOLOGIN NOSUPERUSER NOBYPASSRLS;
  END IF;
END $$;
GRANT USAGE ON SCHEMA public TO vemoria_supabase_rls_smoke;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.generic_interest_watch_authorizations TO vemoria_supabase_rls_smoke;

INSERT INTO public.utenti(id,nome,email,password_hash)
VALUES
('11111111-1111-4111-8111-111111111111','RLS Owner A','rls-a-pre-mb16@test.invalid','x'),
('22222222-2222-4222-8222-222222222222','RLS Owner B','rls-b-pre-mb16@test.invalid','x')
ON CONFLICT (id) DO NOTHING;

SET ROLE vemoria_supabase_rls_smoke;
SELECT set_config('app.owner_id','11111111-1111-4111-8111-111111111111',true);
INSERT INTO public.generic_interest_watch_authorizations(
 owner_id,watch_fingerprint,search_query,criteria_json,explicit_owner_request
) VALUES (
 '11111111-1111-4111-8111-111111111111',repeat('a',64),'pre mb16 rls smoke','{}'::jsonb,true
);

DO $$
DECLARE n integer;
BEGIN
  SELECT count(*) INTO n FROM public.generic_interest_watch_authorizations
   WHERE watch_fingerprint=repeat('a',64);
  IF n <> 1 THEN RAISE EXCEPTION 'RLS_OWNER_A_CANNOT_READ_OWN_ROW count=%', n; END IF;
END $$;

SELECT set_config('app.owner_id','22222222-2222-4222-8222-222222222222',true);
DO $$
DECLARE n integer;
BEGIN
  SELECT count(*) INTO n FROM public.generic_interest_watch_authorizations
   WHERE watch_fingerprint=repeat('a',64);
  IF n <> 0 THEN RAISE EXCEPTION 'RLS_CROSS_OWNER_READ_LEAK count=%', n; END IF;
END $$;

DO $$
BEGIN
  BEGIN
    INSERT INTO public.generic_interest_watch_authorizations(
      owner_id,watch_fingerprint,search_query,criteria_json,explicit_owner_request
    ) VALUES (
      '11111111-1111-4111-8111-111111111111',repeat('b',64),'cross owner injection','{}'::jsonb,true
    );
    RAISE EXCEPTION 'RLS_CROSS_OWNER_INSERT_NOT_BLOCKED';
  EXCEPTION
    WHEN insufficient_privilege OR check_violation THEN NULL;
  END;
END $$;

RESET ROLE;
ROLLBACK;
