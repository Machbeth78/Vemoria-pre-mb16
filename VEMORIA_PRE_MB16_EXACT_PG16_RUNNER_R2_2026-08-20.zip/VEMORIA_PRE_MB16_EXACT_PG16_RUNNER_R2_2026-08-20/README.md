# VEMORIA PRE-MB16 — Exact PostgreSQL 16 Runner

## Stato
Questo pacchetto **NON dichiara il gate PASS da solo**. È il runner riproducibile preparato dal checkpoint `POST-SUPABASE-v296-BACKAUDIT-CLEAN` per ottenere la prova residua richiesta: un vero server PostgreSQL major 16 con `server_version_num = 16xxxx`.

## Cosa contiene
- sorgenti SQL canoniche del FULL, `init_full.sql` + migration registry fino a v296, copiate senza modifica;
- runner canonico `migration_runner.py` e servizi minimi necessari;
- check originali `00_PRECHECK.sql` e `90_POST_MIGRATION_AUDIT.sql`;
- audit aggiuntivo read-only `95_PRE_MB16_SECURITY_RUNTIME_AUDIT.sql` coerente con il final security sweep;
- `scripts/run_exact_pg16_gate.sh` fail-closed;
- workflow GitHub Actions con servizio Docker `postgres:16`;
- cartella `evidence/` dove vengono prodotti log, JSON prova e SHA256.

## Regola fondamentale
Il runner usa solo `127.0.0.1:5432/vemoria_test_db`. **Non puntarlo al Supabase live** `rcbwuaetcjuulurwybxq`.

## Esecuzione locale
Prerequisiti: un vero PostgreSQL 16 raggiungibile su `127.0.0.1:5432`, `psql`, Python 3 e le dipendenze di `requirements-gate.txt`.

```bash
pip install -r requirements-gate.txt
bash scripts/run_exact_pg16_gate.sh
```

Il runner rifiuta automaticamente PostgreSQL 17 o versioni diverse da 16.

## Esecuzione GitHub Actions
Il workflow `.github/workflows/vemoria-exact-pg16-gate.yml` usa esplicitamente `postgres:16`. Un PASS produce l'artifact `vemoria-pre-mb16-exact-pg16-proof`.

## Criterio di chiusura
Solo se il log termina con:

`PRE_MB16_EXACT_PG16_GATE=PASS`

ed esiste `evidence/PRE_MB16_EXACT_PG16_PROOF.json` con `server_version_num=16xxxx`, il checkpoint può avanzare a `PRE-MB16-FINAL-CLEAN`.

MB16 resta bloccato fino a quel momento.

## R2 runtime closure (2026-08-20)
R2 preserves every canonical SQL source file unchanged and applies the already-required v296 five→six argument adaptation only in memory after source hashing. It also closes the discovered dangling `_pre296` runtime dependency, deletes those temporary helpers after rebind, and reproduces the POST-v296 security closure on the isolated PostgreSQL 16 runner.
