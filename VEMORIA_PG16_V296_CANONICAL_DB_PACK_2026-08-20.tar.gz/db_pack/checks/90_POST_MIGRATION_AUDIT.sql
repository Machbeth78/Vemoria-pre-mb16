-- Run AFTER all migrations. Read-only audit.
SELECT version() AS postgres_version;
SHOW server_version_num;

SELECT extname, extversion
FROM pg_extension
WHERE extname IN ('uuid-ossp','pgcrypto','pg_trgm')
ORDER BY extname;

SELECT
  COUNT(*) AS registry_rows,
  COUNT(*) FILTER (WHERE migration_name = 'migration_v296_generic_interest_watch.sql') AS v296_registry_rows
FROM public.schema_migration_state;

SELECT to_regclass('public.generic_interest_watch_authorizations') AS v296_table;
SELECT to_regprocedure('public.mb13_p0_validate_target(uuid,text,jsonb,boolean)') AS validate_target_fn;
SELECT to_regprocedure('public.mb13_p0_lock_and_verify_consents(uuid,jsonb,text,jsonb,boolean)') AS verify_consents_fn;

SELECT c.relname AS table_name, c.relrowsecurity AS rls_enabled, c.relforcerowsecurity AS rls_forced
FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
WHERE n.nspname='public' AND c.relkind='r'
  AND c.relname='generic_interest_watch_authorizations';

SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
FROM pg_policies
WHERE schemaname='public' AND tablename='generic_interest_watch_authorizations';

-- Broad owner-scoped RLS inventory. This is an audit inventory, not by itself proof of correct policy semantics.
WITH owner_tables AS (
  SELECT DISTINCT c.table_name
  FROM information_schema.columns c
  WHERE c.table_schema='public'
    AND c.column_name IN ('owner_id','owner_user_id','utente_id','proprietario_id')
)
SELECT o.table_name,
       pc.relrowsecurity AS rls_enabled,
       pc.relforcerowsecurity AS rls_forced,
       COUNT(pp.policyname) AS policy_count
FROM owner_tables o
JOIN pg_class pc ON pc.relname=o.table_name
JOIN pg_namespace pn ON pn.oid=pc.relnamespace AND pn.nspname='public'
LEFT JOIN pg_policies pp ON pp.schemaname='public' AND pp.tablename=o.table_name
GROUP BY o.table_name, pc.relrowsecurity, pc.relforcerowsecurity
ORDER BY o.table_name;
