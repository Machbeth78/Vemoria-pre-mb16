-- VEMORA — Migration v207
-- MB13-P2 — Server-side authoritative time, executor HTTP/role boundary,
-- test-credential removal, monotonic revision-bound due-state,
-- exact original-event binding and idempotent retry advancement.
-- forward-only, idempotent
BEGIN;

-- ----------------------------------------------------------------------------
-- Roles (ensure, no test credentials in productive migration)
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p2_writer') THEN
        CREATE ROLE mb13_p2_writer NOLOGIN BYPASSRLS;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p2_executor') THEN
        CREATE ROLE mb13_p2_executor NOLOGIN;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p2_api') THEN
        CREATE ROLE mb13_p2_api NOLOGIN;
    END IF;
END $$;

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'test_app') THEN
        EXECUTE 'DROP OWNED BY test_app';
        BEGIN
            EXECUTE 'DROP ROLE test_app';
        EXCEPTION WHEN OTHERS THEN
            RAISE NOTICE 'could not drop test_app in this database context: %', SQLERRM;
        END;
    END IF;
END $$;

GRANT USAGE ON SCHEMA public TO mb13_p2_writer, mb13_p2_executor, mb13_p2_api;
GRANT mb13_p2_writer TO CURRENT_USER WITH SET TRUE, INHERIT TRUE;
GRANT CREATE ON SCHEMA public TO mb13_p2_writer;

-- Writer needs to lock the canonical monitor target while evaluating state.
GRANT SELECT, UPDATE ON TABLE public.mb13_p0_monitor_target TO mb13_p2_writer;

-- ----------------------------------------------------------------------------
-- Schema/constraint hardening
-- ----------------------------------------------------------------------------
-- Ensure provenance columns exist (idempotent if v206 already applied).
ALTER TABLE public.mb13_p2_monitor_state
    ADD COLUMN IF NOT EXISTS monitor_revision INTEGER,
    ADD COLUMN IF NOT EXISTS policy_hash TEXT;

ALTER TABLE public.mb13_p2_monitor_timeline
    ADD COLUMN IF NOT EXISTS monitor_revision INTEGER,
    ADD COLUMN IF NOT EXISTS policy_hash TEXT;

ALTER TABLE public.mb13_p2_reminder_schedule
    ADD COLUMN IF NOT EXISTS dispatched_at TIMESTAMPTZ;

ALTER TABLE public.mb13_p2_retry_schedule
    ADD COLUMN IF NOT EXISTS last_fired_at TIMESTAMPTZ;

-- Require at least one retry attempt.
ALTER TABLE public.mb13_p2_retry_schedule
    DROP CONSTRAINT IF EXISTS ck_mb13_p2_retry_max_retries;
ALTER TABLE public.mb13_p2_retry_schedule
    ADD CONSTRAINT ck_mb13_p2_retry_max_retries
        CHECK (max_retries >= 1 AND max_retries <= 20);

-- Migrate legacy event names and widen the allowed kind list.
UPDATE public.mb13_p2_monitor_timeline
   SET event_kind = 'reminder_dispatched'
 WHERE event_kind = 'reminder_fired';

ALTER TABLE public.mb13_p2_monitor_timeline
    DROP CONSTRAINT IF EXISTS ck_mb13_p2_timeline_event_kind;
ALTER TABLE public.mb13_p2_monitor_timeline
    ADD CONSTRAINT ck_mb13_p2_timeline_event_kind
        CHECK (event_kind IN (
            'state_change','due_entered','grace_entered','expired','completed',
            'state_revalidated','policy_revision_observed',
            'reminder_scheduled','reminder_dispatched','reminder_cancelled','reminder_failed',
            'retry_scheduled','retry_fired','retry_completed','retry_expired','retry_cancelled'
        ));

-- One pending retry per original event per owner (idempotency guard).
CREATE UNIQUE INDEX IF NOT EXISTS ix_mb13_p2_retry_one_pending_per_original
    ON public.mb13_p2_retry_schedule(owner_user_id, original_event_id)
    WHERE status = 'pending' AND original_event_id IS NOT NULL;

-- ----------------------------------------------------------------------------
-- Row-level security and append-only timeline
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p2_monitor_state ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p2_monitor_state FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p2_monitor_timeline ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p2_monitor_timeline FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p2_reminder_schedule ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p2_reminder_schedule FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p2_retry_schedule ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p2_retry_schedule FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS mb13_p2_api_owner_select ON public.mb13_p2_monitor_state;
DROP POLICY IF EXISTS mb13_p2_executor_owner_select ON public.mb13_p2_monitor_state;
DROP POLICY IF EXISTS mb13_p2_api_owner_select ON public.mb13_p2_monitor_timeline;
DROP POLICY IF EXISTS mb13_p2_executor_owner_select ON public.mb13_p2_monitor_timeline;
DROP POLICY IF EXISTS mb13_p2_api_owner_select ON public.mb13_p2_reminder_schedule;
DROP POLICY IF EXISTS mb13_p2_executor_owner_select ON public.mb13_p2_reminder_schedule;
DROP POLICY IF EXISTS mb13_p2_api_owner_select ON public.mb13_p2_retry_schedule;
DROP POLICY IF EXISTS mb13_p2_executor_owner_select ON public.mb13_p2_retry_schedule;

CREATE POLICY mb13_p2_api_owner_select ON public.mb13_p2_monitor_state
    FOR SELECT TO mb13_p2_api
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

CREATE POLICY mb13_p2_executor_owner_select ON public.mb13_p2_monitor_state
    FOR SELECT TO mb13_p2_executor
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

CREATE POLICY mb13_p2_api_owner_select ON public.mb13_p2_monitor_timeline
    FOR SELECT TO mb13_p2_api
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

CREATE POLICY mb13_p2_executor_owner_select ON public.mb13_p2_monitor_timeline
    FOR SELECT TO mb13_p2_executor
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

CREATE POLICY mb13_p2_api_owner_select ON public.mb13_p2_reminder_schedule
    FOR SELECT TO mb13_p2_api
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

CREATE POLICY mb13_p2_executor_owner_select ON public.mb13_p2_reminder_schedule
    FOR SELECT TO mb13_p2_executor
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

CREATE POLICY mb13_p2_api_owner_select ON public.mb13_p2_retry_schedule
    FOR SELECT TO mb13_p2_api
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

CREATE POLICY mb13_p2_executor_owner_select ON public.mb13_p2_retry_schedule
    FOR SELECT TO mb13_p2_executor
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

-- ----------------------------------------------------------------------------
-- Privilege hardening
-- ----------------------------------------------------------------------------
-- Writer retains all privileges on state/reminder/retry, but timeline is append-only.
REVOKE ALL ON public.mb13_p2_monitor_timeline FROM mb13_p2_writer;
GRANT SELECT, INSERT, UPDATE ON public.mb13_p2_monitor_timeline TO mb13_p2_writer;
GRANT ALL ON public.mb13_p2_monitor_state TO mb13_p2_writer;
GRANT ALL ON public.mb13_p2_reminder_schedule TO mb13_p2_writer;
GRANT ALL ON public.mb13_p2_retry_schedule TO mb13_p2_writer;

-- API and executor get no direct DML; only SELECT under RLS.
REVOKE ALL ON public.mb13_p2_monitor_state FROM mb13_p2_api, mb13_p2_executor;
REVOKE ALL ON public.mb13_p2_monitor_timeline FROM mb13_p2_api, mb13_p2_executor;
REVOKE ALL ON public.mb13_p2_reminder_schedule FROM mb13_p2_api, mb13_p2_executor;
REVOKE ALL ON public.mb13_p2_retry_schedule FROM mb13_p2_api, mb13_p2_executor;

GRANT SELECT ON public.mb13_p2_monitor_state TO mb13_p2_api, mb13_p2_executor;
GRANT SELECT ON public.mb13_p2_monitor_timeline TO mb13_p2_api, mb13_p2_executor;
GRANT SELECT ON public.mb13_p2_reminder_schedule TO mb13_p2_api, mb13_p2_executor;
GRANT SELECT ON public.mb13_p2_retry_schedule TO mb13_p2_api, mb13_p2_executor;

-- Shared hash utility used by P2 functions.
GRANT EXECUTE ON FUNCTION public.mb13_p0_hash_jsonb(JSONB) TO mb13_p2_writer;

-- ----------------------------------------------------------------------------
-- Drop old overloads that exposed caller-controlled timestamps
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p2_evaluate_due_state(UUID, UUID, TIMESTAMPTZ);
DROP FUNCTION IF EXISTS public.mb13_p2_fire_reminder(UUID, UUID, TIMESTAMPTZ);
DROP FUNCTION IF EXISTS public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN, TIMESTAMPTZ);
DROP FUNCTION IF EXISTS public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN);

-- ----------------------------------------------------------------------------
-- Helper: due-state computation (unchanged contract)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_compute_due_state(
    p_due_at TIMESTAMPTZ,
    p_grace_until TIMESTAMPTZ,
    p_now TIMESTAMPTZ
) RETURNS TEXT AS $$
BEGIN
    IF p_due_at IS NULL THEN
        RETURN 'not_due';
    END IF;
    IF p_now < p_due_at THEN
        RETURN 'not_due';
    END IF;
    IF p_grace_until IS NULL THEN
        RETURN 'due';
    END IF;
    IF p_now < p_grace_until THEN
        RETURN 'grace';
    END IF;
    RETURN 'expired';
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- ----------------------------------------------------------------------------
-- Monotonic, revision-bound and owner-isolated due-state evaluation
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_evaluate_due_state(
    p_owner_user_id UUID,
    p_monitor_id UUID
) RETURNS TABLE(
    monitor_id UUID,
    due_state TEXT,
    previous_state TEXT,
    changed BOOLEAN,
    evaluated_at TIMESTAMPTZ,
    monitor_revision INTEGER,
    policy_hash TEXT
) AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_target public.mb13_p0_monitor_target%ROWTYPE;
    v_current public.mb13_p2_monitor_state%ROWTYPE;
    v_evaluated_at TIMESTAMPTZ := clock_timestamp();
    v_due_at TIMESTAMPTZ;
    v_grace_until TIMESTAMPTZ;
    v_next_check_at TIMESTAMPTZ;
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
    v_new_state TEXT;
    v_previous_state TEXT;
    v_changed BOOLEAN := FALSE;
    v_revision_changed BOOLEAN := FALSE;
    v_should_update BOOLEAN := FALSE;
    v_event_payload JSONB;
    v_event_hash TEXT;
    v_event_kind TEXT;
    v_payload_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    -- Deterministic lock order: canonical monitor target first, then state.
    SELECT * INTO v_target
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = p_owner_user_id
       AND t.monitor_id = p_monitor_id
     FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_monitor_not_found';
    END IF;

    v_monitor_revision := v_target.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_target.monitor_policy);
    v_due_at := (v_target.monitor_policy->>'due_at')::TIMESTAMPTZ;
    v_grace_until := (v_target.monitor_policy->>'grace_until')::TIMESTAMPTZ;
    v_next_check_at := (v_target.monitor_policy->>'next_check_at')::TIMESTAMPTZ;

    IF v_target.monitor_state = 'completed' THEN
        v_new_state := 'completed';
    ELSE
        v_new_state := public.mb13_p2_compute_due_state(v_due_at, v_grace_until, v_evaluated_at);
    END IF;

    SELECT * INTO v_current
      FROM public.mb13_p2_monitor_state s
     WHERE s.owner_user_id = p_owner_user_id
       AND s.monitor_id = p_monitor_id
     FOR UPDATE;

    IF v_current.due_state IS NULL THEN
        v_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', p_monitor_id,
            'due_state', v_new_state,
            'due_at', v_due_at,
            'grace_until', v_grace_until,
            'next_check_at', v_next_check_at,
            'evaluated_at', v_evaluated_at,
            'monitor_revision', v_monitor_revision,
            'policy_hash', v_policy_hash
        ));

        INSERT INTO public.mb13_p2_monitor_state (
            owner_user_id, monitor_id, due_state, due_at, grace_until, next_check_at,
            evaluated_at, payload_hash, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_monitor_id, v_new_state, v_due_at, v_grace_until, v_next_check_at,
            v_evaluated_at, v_payload_hash, v_monitor_revision, v_policy_hash
        )
        ON CONFLICT ON CONSTRAINT mb13_p2_monitor_state_pkey DO NOTHING
        RETURNING * INTO v_current;

        IF FOUND THEN
            v_previous_state := NULL;
            v_changed := TRUE;
            v_revision_changed := FALSE;
        ELSE
            -- Concurrent insert; reselect the canonical row.
            SELECT * INTO v_current
              FROM public.mb13_p2_monitor_state s
             WHERE s.owner_user_id = p_owner_user_id
               AND s.monitor_id = p_monitor_id
             FOR UPDATE;
        END IF;
    END IF;

    IF NOT v_changed THEN
        -- Guard against stale timestamp and regressed revision.
        IF v_current.evaluated_at IS NOT NULL AND v_evaluated_at < v_current.evaluated_at THEN
            RETURN QUERY SELECT p_monitor_id, v_current.due_state, v_current.due_state, FALSE::BOOLEAN,
                                v_current.evaluated_at, v_current.monitor_revision, v_current.policy_hash;
            RETURN;
        END IF;
        IF v_current.monitor_revision IS NOT NULL AND v_monitor_revision < v_current.monitor_revision THEN
            RETURN QUERY SELECT p_monitor_id, v_current.due_state, v_current.due_state, FALSE::BOOLEAN,
                                v_current.evaluated_at, v_current.monitor_revision, v_current.policy_hash;
            RETURN;
        END IF;

        v_previous_state := v_current.due_state;
        v_changed := (v_current.due_state IS DISTINCT FROM v_new_state);
        v_revision_changed := (v_current.monitor_revision IS DISTINCT FROM v_monitor_revision)
                          OR (v_current.policy_hash IS DISTINCT FROM v_policy_hash);
        v_should_update := v_changed OR v_revision_changed OR (v_evaluated_at > v_current.evaluated_at);

        IF v_should_update THEN
            v_payload_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
                'owner_user_id', p_owner_user_id,
                'monitor_id', p_monitor_id,
                'due_state', v_new_state,
                'due_at', v_due_at,
                'grace_until', v_grace_until,
                'next_check_at', v_next_check_at,
                'evaluated_at', v_evaluated_at,
                'monitor_revision', v_monitor_revision,
                'policy_hash', v_policy_hash
            ));

            UPDATE public.mb13_p2_monitor_state s
               SET due_state = v_new_state,
                   due_at = v_due_at,
                   grace_until = v_grace_until,
                   next_check_at = v_next_check_at,
                   evaluated_at = v_evaluated_at,
                   payload_hash = v_payload_hash,
                   monitor_revision = v_monitor_revision,
                   policy_hash = v_policy_hash
             WHERE s.owner_user_id = p_owner_user_id
               AND s.monitor_id = p_monitor_id;
        END IF;
    END IF;

    IF v_changed OR v_revision_changed THEN
        v_event_payload := jsonb_build_object(
            'evaluated_at', v_evaluated_at,
            'due_at', v_due_at,
            'grace_until', v_grace_until,
            'next_check_at', v_next_check_at,
            'monitor_revision', v_monitor_revision,
            'policy_hash', v_policy_hash
        );
        v_event_kind := CASE
            WHEN v_changed THEN
                CASE v_new_state
                    WHEN 'due' THEN 'due_entered'
                    WHEN 'grace' THEN 'grace_entered'
                    WHEN 'expired' THEN 'expired'
                    WHEN 'completed' THEN 'completed'
                    ELSE 'state_change'
                END
            ELSE 'policy_revision_observed'
        END;
        v_event_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', p_monitor_id,
            'event_kind', v_event_kind,
            'from_state', v_previous_state,
            'to_state', v_new_state,
            'event_time', v_evaluated_at,
            'event_payload', v_event_payload
        ));

        INSERT INTO public.mb13_p2_monitor_timeline (
            owner_user_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, payload_hash, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_monitor_id, v_event_kind, v_previous_state, v_new_state,
            v_evaluated_at, v_event_payload, v_event_hash, v_monitor_revision, v_policy_hash
        );
    END IF;

    RETURN QUERY SELECT p_monitor_id, v_new_state, v_previous_state,
                        (v_changed OR v_revision_changed), v_evaluated_at,
                        v_monitor_revision, v_policy_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_evaluate_due_state(UUID, UUID) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_evaluate_due_state(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_evaluate_due_state(UUID, UUID) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_evaluate_due_state(UUID, UUID) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Read timeline (revision/provenance aware)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_get_timeline(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_limit INTEGER DEFAULT 100,
    p_offset INTEGER DEFAULT 0
) RETURNS TABLE(
    timeline_event_id UUID,
    event_kind TEXT,
    from_state TEXT,
    to_state TEXT,
    event_time TIMESTAMPTZ,
    event_payload JSONB,
    payload_hash TEXT,
    monitor_revision INTEGER,
    policy_hash TEXT
) AS $$
BEGIN
    IF NULLIF(current_setting('app.owner_id', true), '')::UUID IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    RETURN QUERY
    SELECT t.timeline_event_id, t.event_kind, t.from_state, t.to_state,
           t.event_time, t.event_payload, t.payload_hash,
           t.monitor_revision, t.policy_hash
      FROM public.mb13_p2_monitor_timeline t
     WHERE t.owner_user_id = p_owner_user_id
       AND t.monitor_id = p_monitor_id
     ORDER BY t.event_time DESC, t.timeline_event_id DESC
     LIMIT p_limit OFFSET p_offset;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_get_timeline(UUID, UUID, INTEGER, INTEGER) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_get_timeline(UUID, UUID, INTEGER, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_get_timeline(UUID, UUID, INTEGER, INTEGER) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_get_timeline(UUID, UUID, INTEGER, INTEGER) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Schedule reminder (server-side time, provenance-bound)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_schedule_reminder(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_remind_at TIMESTAMPTZ,
    p_reminder_kind TEXT,
    p_channel TEXT DEFAULT 'in_app',
    p_payload JSONB DEFAULT '{}'::jsonb,
    p_immediate BOOLEAN DEFAULT FALSE
) RETURNS UUID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_reminder_id UUID := gen_random_uuid();
    v_now TIMESTAMPTZ := clock_timestamp();
    v_effective_remind_at TIMESTAMPTZ;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;
    IF p_remind_at IS NULL AND NOT p_immediate THEN
        RAISE EXCEPTION 'mb13_p2_reminder_time_invalid';
    END IF;
    IF p_immediate THEN
        v_effective_remind_at := v_now;
    ELSE
        IF p_remind_at < v_now THEN
            RAISE EXCEPTION 'mb13_p2_reminder_time_obsolete';
        END IF;
        v_effective_remind_at := p_remind_at;
    END IF;
    IF p_reminder_kind NOT IN ('pre_due','due','grace','expired','custom') THEN
        RAISE EXCEPTION 'mb13_p2_reminder_kind_invalid';
    END IF;
    IF p_channel NOT IN ('in_app','email','push','sms') THEN
        RAISE EXCEPTION 'mb13_p2_reminder_channel_invalid';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = p_owner_user_id
       AND t.monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_monitor_not_found';
    END IF;

    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    INSERT INTO public.mb13_p2_reminder_schedule (
        reminder_id, owner_user_id, monitor_id, remind_at, reminder_kind,
        channel, status, payload
    ) VALUES (
        v_reminder_id, p_owner_user_id, p_monitor_id, v_effective_remind_at,
        p_reminder_kind, p_channel, 'pending', COALESCE(p_payload, '{}'::jsonb)
    );

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_monitor_id, 'reminder_scheduled', NULL, NULL,
        v_now,
        jsonb_build_object('reminder_id', v_reminder_id, 'reminder_kind', p_reminder_kind, 'channel', p_channel, 'remind_at', v_effective_remind_at),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', p_monitor_id,
            'event_kind', 'reminder_scheduled',
            'from_state', NULL,
            'to_state', NULL,
            'event_time', v_now,
            'event_payload', jsonb_build_object('reminder_id', v_reminder_id, 'reminder_kind', p_reminder_kind, 'channel', p_channel, 'remind_at', v_effective_remind_at)
        )),
        v_monitor_revision, v_policy_hash
    );

    RETURN v_reminder_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_schedule_reminder(UUID, UUID, TIMESTAMPTZ, TEXT, TEXT, JSONB, BOOLEAN) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_schedule_reminder(UUID, UUID, TIMESTAMPTZ, TEXT, TEXT, JSONB, BOOLEAN) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_schedule_reminder(UUID, UUID, TIMESTAMPTZ, TEXT, TEXT, JSONB, BOOLEAN) TO mb13_p2_api;

-- ----------------------------------------------------------------------------
-- Fire reminder (executor-only, server-side clock_timestamp, success-aware)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_fire_reminder(
    p_owner_user_id UUID,
    p_reminder_id UUID,
    p_success BOOLEAN DEFAULT TRUE
) RETURNS TABLE(
    reminder_id UUID,
    monitor_id UUID,
    status TEXT,
    dispatched_at TIMESTAMPTZ
) AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_reminder public.mb13_p2_reminder_schedule%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
    v_new_status TEXT;
    v_event_kind TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    SELECT * INTO v_reminder
      FROM public.mb13_p2_reminder_schedule r
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_reminder_not_found';
    END IF;
    IF v_reminder.status <> 'pending' THEN
        RAISE EXCEPTION 'mb13_p2_reminder_already_handled';
    END IF;
    IF v_reminder.remind_at > v_now THEN
        RAISE EXCEPTION 'mb13_p2_reminder_too_early';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = p_owner_user_id
       AND t.monitor_id = v_reminder.monitor_id
     FOR UPDATE;
    -- The monitor must exist because of the FK on reminder_schedule.
    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    IF p_success THEN
        v_new_status := 'dispatched';
        v_event_kind := 'reminder_dispatched';
    ELSE
        v_new_status := 'failed';
        v_event_kind := 'reminder_failed';
    END IF;

    UPDATE public.mb13_p2_reminder_schedule r
       SET status = v_new_status,
           dispatched_at = v_now
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id;

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_reminder.monitor_id, v_event_kind, 'pending', v_new_status,
        v_now,
        jsonb_build_object('reminder_id', p_reminder_id, 'reminder_kind', v_reminder.reminder_kind, 'channel', v_reminder.channel, 'success', p_success),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', v_reminder.monitor_id,
            'event_kind', v_event_kind,
            'from_state', 'pending',
            'to_state', v_new_status,
            'event_time', v_now,
            'event_payload', jsonb_build_object('reminder_id', p_reminder_id, 'reminder_kind', v_reminder.reminder_kind, 'channel', v_reminder.channel, 'success', p_success)
        )),
        v_monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT p_reminder_id, v_reminder.monitor_id, v_new_status, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_fire_reminder(UUID, UUID, BOOLEAN) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_fire_reminder(UUID, UUID, BOOLEAN) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_fire_reminder(UUID, UUID, BOOLEAN) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Cancel reminder
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_cancel_reminder(
    p_owner_user_id UUID,
    p_reminder_id UUID
) RETURNS VOID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_reminder public.mb13_p2_reminder_schedule%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    SELECT * INTO v_reminder
      FROM public.mb13_p2_reminder_schedule r
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_reminder_not_found';
    END IF;
    IF v_reminder.status NOT IN ('pending','dispatched') THEN
        RAISE EXCEPTION 'mb13_p2_reminder_cannot_cancel';
    END IF;

    SELECT t.current_revision, public.mb13_p0_hash_jsonb(t.monitor_policy)
      INTO v_monitor_revision, v_policy_hash
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = p_owner_user_id
       AND t.monitor_id = v_reminder.monitor_id;

    UPDATE public.mb13_p2_reminder_schedule r
       SET status = 'cancelled'
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id;

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_reminder.monitor_id, 'reminder_cancelled', v_reminder.status, 'cancelled',
        v_now, jsonb_build_object('reminder_id', p_reminder_id),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', v_reminder.monitor_id,
            'event_kind', 'reminder_cancelled',
            'from_state', v_reminder.status,
            'to_state', 'cancelled',
            'event_time', v_now,
            'event_payload', jsonb_build_object('reminder_id', p_reminder_id)
        )),
        v_monitor_revision, v_policy_hash
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Schedule retry (original-event whitelist + live entity state)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_schedule_retry(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_original_event_id UUID,
    p_next_retry_at TIMESTAMPTZ,
    p_max_retries INTEGER DEFAULT 3,
    p_backoff_kind TEXT DEFAULT 'exponential',
    p_last_error_payload JSONB DEFAULT '{}'::jsonb,
    p_immediate BOOLEAN DEFAULT FALSE
) RETURNS UUID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_retry_id UUID := gen_random_uuid();
    v_now TIMESTAMPTZ := clock_timestamp();
    v_effective_next_at TIMESTAMPTZ;
    v_original public.mb13_p2_monitor_timeline%ROWTYPE;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
    v_entity_kind TEXT;
    v_reminder_id UUID;
    v_retry_ref_id UUID;
    v_reminder_status TEXT;
    v_retry_status TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;
    IF p_next_retry_at IS NULL AND NOT p_immediate THEN
        RAISE EXCEPTION 'mb13_p2_retry_time_invalid';
    END IF;
    IF p_immediate THEN
        v_effective_next_at := v_now;
    ELSE
        IF p_next_retry_at < v_now THEN
            RAISE EXCEPTION 'mb13_p2_retry_time_obsolete';
        END IF;
        v_effective_next_at := p_next_retry_at;
    END IF;
    IF p_max_retries < 1 OR p_max_retries > 20 THEN
        RAISE EXCEPTION 'mb13_p2_retry_max_invalid';
    END IF;
    IF p_backoff_kind NOT IN ('fixed','exponential','linear','none') THEN
        RAISE EXCEPTION 'mb13_p2_retry_backoff_invalid';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = p_owner_user_id
       AND t.monitor_id = p_monitor_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_monitor_not_found';
    END IF;

    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    IF p_original_event_id IS NOT NULL THEN
        SELECT * INTO v_original
          FROM public.mb13_p2_monitor_timeline t
         WHERE t.timeline_event_id = p_original_event_id
           AND t.owner_user_id = p_owner_user_id
           AND t.monitor_id = p_monitor_id
         FOR UPDATE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p2_original_event_not_found';
        END IF;

        v_entity_kind := v_original.event_kind;
        IF v_entity_kind IN ('completed','expired','retry_completed','retry_expired','retry_cancelled','reminder_cancelled') THEN
            RAISE EXCEPTION 'mb13_p2_original_event_not_retryable';
        END IF;

        IF v_entity_kind LIKE 'reminder_%' THEN
            v_reminder_id := (v_original.event_payload->>'reminder_id')::UUID;
            SELECT status INTO v_reminder_status
              FROM public.mb13_p2_reminder_schedule r
             WHERE r.reminder_id = v_reminder_id
               AND r.owner_user_id = p_owner_user_id
               AND r.monitor_id = p_monitor_id
             FOR UPDATE;
            IF NOT FOUND OR v_reminder_status IN ('cancelled','dispatched') THEN
                RAISE EXCEPTION 'mb13_p2_original_event_not_retryable';
            END IF;
        ELSIF v_entity_kind LIKE 'retry_%' THEN
            v_retry_ref_id := (v_original.event_payload->>'retry_id')::UUID;
            SELECT status INTO v_retry_status
              FROM public.mb13_p2_retry_schedule rz
             WHERE rz.retry_id = v_retry_ref_id
               AND rz.owner_user_id = p_owner_user_id
               AND rz.monitor_id = p_monitor_id
             FOR UPDATE;
            IF NOT FOUND OR v_retry_status IN ('cancelled','completed','expired') THEN
                RAISE EXCEPTION 'mb13_p2_original_event_not_retryable';
            END IF;
        END IF;
    END IF;

    INSERT INTO public.mb13_p2_retry_schedule (
        retry_id, owner_user_id, monitor_id, original_event_id, retry_count,
        max_retries, next_retry_at, backoff_kind, status, last_error_payload
    ) VALUES (
        v_retry_id, p_owner_user_id, p_monitor_id, p_original_event_id, 0,
        p_max_retries, v_effective_next_at, p_backoff_kind, 'pending', COALESCE(p_last_error_payload, '{}'::jsonb)
    );

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_monitor_id, 'retry_scheduled', NULL, NULL,
        v_now, jsonb_build_object('retry_id', v_retry_id, 'max_retries', p_max_retries, 'backoff_kind', p_backoff_kind, 'original_event_id', p_original_event_id, 'next_retry_at', v_effective_next_at, 'immediate', p_immediate),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', p_monitor_id,
            'event_kind', 'retry_scheduled',
            'from_state', NULL,
            'to_state', NULL,
            'event_time', v_now,
            'event_payload', jsonb_build_object('retry_id', v_retry_id, 'max_retries', p_max_retries, 'backoff_kind', p_backoff_kind, 'original_event_id', p_original_event_id, 'next_retry_at', v_effective_next_at, 'immediate', p_immediate)
        )),
        v_monitor_revision, v_policy_hash
    );

    RETURN v_retry_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB, BOOLEAN) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB, BOOLEAN) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB, BOOLEAN) TO mb13_p2_api;

-- ----------------------------------------------------------------------------
-- Advance retry (executor-only, idempotent via expected_retry_count)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_advance_retry(
    p_owner_user_id UUID,
    p_retry_id UUID,
    p_success BOOLEAN DEFAULT FALSE,
    p_expected_retry_count INTEGER DEFAULT NULL
) RETURNS TABLE(
    retry_id UUID,
    monitor_id UUID,
    status TEXT,
    retry_count INTEGER,
    next_retry_at TIMESTAMPTZ,
    executed_at TIMESTAMPTZ
) AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_retry public.mb13_p2_retry_schedule%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_next_at TIMESTAMPTZ;
    v_new_count INTEGER;
    v_interval INTERVAL;
    v_event_kind TEXT;
    v_to_state TEXT;
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    SELECT * INTO v_retry
      FROM public.mb13_p2_retry_schedule rz
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_retry_not_found';
    END IF;
    IF v_retry.status <> 'pending' THEN
        RAISE EXCEPTION 'mb13_p2_retry_not_pending';
    END IF;
    IF v_retry.next_retry_at > v_now THEN
        RAISE EXCEPTION 'mb13_p2_retry_too_early';
    END IF;
    IF p_expected_retry_count IS NOT NULL AND v_retry.retry_count IS DISTINCT FROM p_expected_retry_count THEN
        RAISE EXCEPTION 'mb13_p2_retry_concurrent_or_stale';
    END IF;

    SELECT * INTO v_monitor
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = p_owner_user_id
       AND t.monitor_id = v_retry.monitor_id
     FOR UPDATE;
    v_monitor_revision := v_monitor.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_monitor.monitor_policy);

    IF p_success THEN
        UPDATE public.mb13_p2_retry_schedule rz
           SET status = 'completed',
               last_fired_at = v_now
         WHERE rz.owner_user_id = p_owner_user_id
           AND rz.retry_id = p_retry_id;

        INSERT INTO public.mb13_p2_monitor_timeline (
            owner_user_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, payload_hash, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, v_retry.monitor_id, 'retry_completed', 'pending', 'completed',
            v_now, jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_retry.retry_count, 'success', true),
            public.mb13_p0_hash_jsonb(jsonb_build_object(
                'owner_user_id', p_owner_user_id,
                'monitor_id', v_retry.monitor_id,
                'event_kind', 'retry_completed',
                'from_state', 'pending',
                'to_state', 'completed',
                'event_time', v_now,
                'event_payload', jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_retry.retry_count, 'success', true)
            )),
            v_monitor_revision, v_policy_hash
        );

        RETURN QUERY SELECT p_retry_id, v_retry.monitor_id, 'completed'::TEXT, v_retry.retry_count, v_retry.next_retry_at, v_now;
        RETURN;
    END IF;

    v_new_count := v_retry.retry_count + 1;
    IF v_new_count >= v_retry.max_retries THEN
        UPDATE public.mb13_p2_retry_schedule rz
           SET status = 'expired',
               retry_count = v_new_count,
               last_fired_at = v_now
         WHERE rz.owner_user_id = p_owner_user_id
           AND rz.retry_id = p_retry_id;

        INSERT INTO public.mb13_p2_monitor_timeline (
            owner_user_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, payload_hash, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, v_retry.monitor_id, 'retry_expired', 'pending', 'expired',
            v_now, jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_new_count, 'success', false),
            public.mb13_p0_hash_jsonb(jsonb_build_object(
                'owner_user_id', p_owner_user_id,
                'monitor_id', v_retry.monitor_id,
                'event_kind', 'retry_expired',
                'from_state', 'pending',
                'to_state', 'expired',
                'event_time', v_now,
                'event_payload', jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_new_count, 'success', false)
            )),
            v_monitor_revision, v_policy_hash
        );

        RETURN QUERY SELECT p_retry_id, v_retry.monitor_id, 'expired'::TEXT, v_new_count, v_retry.next_retry_at, v_now;
        RETURN;
    END IF;

    IF v_retry.backoff_kind = 'fixed' THEN
        v_interval := '1 minute'::INTERVAL;
    ELSIF v_retry.backoff_kind = 'linear' THEN
        v_interval := (v_new_count * '1 minute'::INTERVAL);
    ELSIF v_retry.backoff_kind = 'exponential' THEN
        v_interval := (POWER(2, v_new_count)::INTEGER * '1 minute'::INTERVAL);
    ELSE
        v_interval := '0 minutes'::INTERVAL;
    END IF;

    v_next_at := v_now + v_interval;

    UPDATE public.mb13_p2_retry_schedule rz
       SET retry_count = v_new_count,
           next_retry_at = v_next_at,
           last_fired_at = v_now
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id;

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_retry.monitor_id, 'retry_fired', 'pending', 'pending',
        v_now, jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_new_count, 'success', false, 'next_retry_at', v_next_at),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', v_retry.monitor_id,
            'event_kind', 'retry_fired',
            'from_state', 'pending',
            'to_state', 'pending',
            'event_time', v_now,
            'event_payload', jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_new_count, 'success', false, 'next_retry_at', v_next_at)
        )),
        v_monitor_revision, v_policy_hash
    );

    RETURN QUERY SELECT p_retry_id, v_retry.monitor_id, 'pending'::TEXT, v_new_count, v_next_at, v_now;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN, INTEGER) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN, INTEGER) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Cancel retry
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_cancel_retry(
    p_owner_user_id UUID,
    p_retry_id UUID
) RETURNS VOID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_retry public.mb13_p2_retry_schedule%ROWTYPE;
    v_now TIMESTAMPTZ := clock_timestamp();
    v_monitor public.mb13_p0_monitor_target%ROWTYPE;
    v_monitor_revision INTEGER;
    v_policy_hash TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    SELECT * INTO v_retry
      FROM public.mb13_p2_retry_schedule rz
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id
     FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_retry_not_found';
    END IF;
    IF v_retry.status NOT IN ('pending') THEN
        RAISE EXCEPTION 'mb13_p2_retry_cannot_cancel';
    END IF;

    SELECT t.current_revision, public.mb13_p0_hash_jsonb(t.monitor_policy)
      INTO v_monitor_revision, v_policy_hash
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = p_owner_user_id
       AND t.monitor_id = v_retry.monitor_id;

    UPDATE public.mb13_p2_retry_schedule rz
       SET status = 'cancelled'
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id;

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_retry.monitor_id, 'retry_cancelled', 'pending', 'cancelled',
        v_now, jsonb_build_object('retry_id', p_retry_id),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', v_retry.monitor_id,
            'event_kind', 'retry_cancelled',
            'from_state', 'pending',
            'to_state', 'cancelled',
            'event_time', v_now,
            'event_payload', jsonb_build_object('retry_id', p_retry_id)
        )),
        v_monitor_revision, v_policy_hash
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

ALTER FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) OWNER TO mb13_p2_writer;
REVOKE ALL ON FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) TO mb13_p2_executor;

REVOKE CREATE ON SCHEMA public FROM mb13_p2_writer;
REVOKE SET OPTION FOR mb13_p2_writer FROM CURRENT_USER;
REVOKE INHERIT OPTION FOR mb13_p2_writer FROM CURRENT_USER;

COMMIT;
