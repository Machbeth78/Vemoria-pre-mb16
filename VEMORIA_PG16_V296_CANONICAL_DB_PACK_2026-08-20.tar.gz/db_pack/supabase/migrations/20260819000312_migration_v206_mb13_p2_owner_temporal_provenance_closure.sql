-- VEMORA — Migration v206
-- MB13-P2 — Owner-scoped RLS, append-only timeline, temporal eligibility,
-- original-event binding, monotonic revision-bound due-state and lifecycle events.
-- forward-only, idempotent
BEGIN;

-- ----------------------------------------------------------------------------
-- Roles (ensure)
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p2_writer') THEN
        CREATE ROLE mb13_p2_writer NOLOGIN BYPASSRLS;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p2_executor') THEN
        CREATE ROLE mb13_p2_executor NOLOGIN;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'mb13_p2_api') THEN
        CREATE ROLE mb13_p2_api NOLOGIN;
    END IF;
END $$;

GRANT USAGE ON SCHEMA public TO mb13_p2_writer, mb13_p2_executor, mb13_p2_api;

-- PostgreSQL 17/Supabase ownership handoff portability. Temporary deploy-only window.
GRANT mb13_p2_writer TO CURRENT_USER WITH SET TRUE, INHERIT TRUE;
GRANT CREATE ON SCHEMA public TO mb13_p2_writer;

-- test_app is a test-harness fixture, never a production prerequisite.
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'test_app') THEN
        GRANT mb13_p2_api TO test_app;
        GRANT mb13_p2_executor TO test_app;
    END IF;
END $$;

-- ----------------------------------------------------------------------------
-- Schema extensions for provenance and monotonicity
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p2_monitor_state
    ADD COLUMN IF NOT EXISTS monitor_revision INTEGER,
    ADD COLUMN IF NOT EXISTS policy_hash TEXT;

ALTER TABLE public.mb13_p2_monitor_timeline
    ADD COLUMN IF NOT EXISTS monitor_revision INTEGER,
    ADD COLUMN IF NOT EXISTS policy_hash TEXT;

ALTER TABLE public.mb13_p2_reminder_schedule
    ADD COLUMN IF NOT EXISTS dispatched_at TIMESTAMPTZ;

ALTER TABLE public.mb13_p2_retry_schedule
    ADD COLUMN IF NOT EXISTS last_fired_at TIMESTAMPTZ;

-- ----------------------------------------------------------------------------
-- Constraint updates (drop old first to allow data migration)
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p2_reminder_schedule
    DROP CONSTRAINT IF EXISTS ck_mb13_p2_reminder_status;
ALTER TABLE public.mb13_p2_monitor_timeline
    DROP CONSTRAINT IF EXISTS ck_mb13_p2_timeline_event_kind;

-- Migrate existing v205 data.
UPDATE public.mb13_p2_reminder_schedule SET status = 'dispatched' WHERE status = 'sent';
UPDATE public.mb13_p2_monitor_timeline SET event_kind = 'reminder_fired' WHERE event_kind = 'reminder';

ALTER TABLE public.mb13_p2_reminder_schedule
    ADD CONSTRAINT ck_mb13_p2_reminder_status
        CHECK (status IN ('pending','dispatched','cancelled','failed'));

ALTER TABLE public.mb13_p2_monitor_timeline
    ADD CONSTRAINT ck_mb13_p2_timeline_event_kind
        CHECK (event_kind IN (
            'state_change','due_entered','grace_entered','expired','completed',
            'reminder_scheduled','reminder_fired','reminder_dispatched','reminder_cancelled','reminder_failed',
            'retry_scheduled','retry_fired','retry_completed','retry_expired','retry_cancelled'
        ));

-- One pending retry per original event per owner.
CREATE UNIQUE INDEX IF NOT EXISTS ix_mb13_p2_retry_one_pending_per_original
    ON public.mb13_p2_retry_schedule(owner_user_id, original_event_id)
    WHERE status = 'pending' AND original_event_id IS NOT NULL;

-- ----------------------------------------------------------------------------
-- Row-level security (owner-scoped) and append-only timeline
-- ----------------------------------------------------------------------------
ALTER TABLE public.mb13_p2_monitor_state ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p2_monitor_state FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p2_monitor_timeline ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p2_monitor_timeline FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p2_reminder_schedule ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p2_reminder_schedule FORCE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p2_retry_schedule ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mb13_p2_retry_schedule FORCE ROW LEVEL SECURITY;

-- Drop existing policies to allow re-run.
DROP POLICY IF EXISTS mb13_p2_api_owner_select ON public.mb13_p2_monitor_state;
DROP POLICY IF EXISTS mb13_p2_executor_owner_select ON public.mb13_p2_monitor_state;
DROP POLICY IF EXISTS mb13_p2_api_owner_select ON public.mb13_p2_monitor_timeline;
DROP POLICY IF EXISTS mb13_p2_executor_owner_select ON public.mb13_p2_monitor_timeline;
DROP POLICY IF EXISTS mb13_p2_api_owner_select ON public.mb13_p2_reminder_schedule;
DROP POLICY IF EXISTS mb13_p2_executor_owner_select ON public.mb13_p2_reminder_schedule;
DROP POLICY IF EXISTS mb13_p2_api_owner_select ON public.mb13_p2_retry_schedule;
DROP POLICY IF EXISTS mb13_p2_executor_owner_select ON public.mb13_p2_retry_schedule;

CREATE POLICY mb13_p2_api_owner_select ON public.mb13_p2_monitor_state
    FOR SELECT TO mb13_p2_api
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

CREATE POLICY mb13_p2_executor_owner_select ON public.mb13_p2_monitor_state
    FOR SELECT TO mb13_p2_executor
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

CREATE POLICY mb13_p2_api_owner_select ON public.mb13_p2_monitor_timeline
    FOR SELECT TO mb13_p2_api
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

CREATE POLICY mb13_p2_executor_owner_select ON public.mb13_p2_monitor_timeline
    FOR SELECT TO mb13_p2_executor
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

CREATE POLICY mb13_p2_api_owner_select ON public.mb13_p2_reminder_schedule
    FOR SELECT TO mb13_p2_api
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

CREATE POLICY mb13_p2_executor_owner_select ON public.mb13_p2_reminder_schedule
    FOR SELECT TO mb13_p2_executor
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

CREATE POLICY mb13_p2_api_owner_select ON public.mb13_p2_retry_schedule
    FOR SELECT TO mb13_p2_api
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

CREATE POLICY mb13_p2_executor_owner_select ON public.mb13_p2_retry_schedule
    FOR SELECT TO mb13_p2_executor
    USING (owner_user_id = NULLIF(current_setting('app.owner_id', true), '')::UUID);

-- ----------------------------------------------------------------------------
-- Privilege hardening
-- ----------------------------------------------------------------------------
-- Writer retains all privileges on state/reminder/retry, but timeline is append-only.
REVOKE ALL ON public.mb13_p2_monitor_timeline FROM mb13_p2_writer;
GRANT SELECT, INSERT ON public.mb13_p2_monitor_timeline TO mb13_p2_writer;

-- API and executor get no direct DML; only SELECT under RLS.
REVOKE ALL ON public.mb13_p2_monitor_state FROM mb13_p2_api, mb13_p2_executor;
REVOKE ALL ON public.mb13_p2_monitor_timeline FROM mb13_p2_api, mb13_p2_executor;
REVOKE ALL ON public.mb13_p2_reminder_schedule FROM mb13_p2_api, mb13_p2_executor;
REVOKE ALL ON public.mb13_p2_retry_schedule FROM mb13_p2_api, mb13_p2_executor;

GRANT SELECT ON public.mb13_p2_monitor_state TO mb13_p2_api, mb13_p2_executor;
GRANT SELECT ON public.mb13_p2_monitor_timeline TO mb13_p2_api, mb13_p2_executor;
GRANT SELECT ON public.mb13_p2_reminder_schedule TO mb13_p2_api, mb13_p2_executor;
GRANT SELECT ON public.mb13_p2_retry_schedule TO mb13_p2_api, mb13_p2_executor;

-- Function execute privileges (role separation).
DO $$
DECLARE
    v_function regprocedure;
BEGIN
    FOR v_function IN
        SELECT p.oid::regprocedure
          FROM pg_catalog.pg_proc p
          JOIN pg_catalog.pg_namespace n ON n.oid = p.pronamespace
         WHERE n.nspname = 'public'
           AND p.proname LIKE 'mb13\_p2\_%' ESCAPE '\'
    LOOP
        EXECUTE format(
            'REVOKE ALL ON FUNCTION %s FROM mb13_p2_api, mb13_p2_executor',
            v_function
        );
    END LOOP;
END $$;

-- Shared hash utility used by P2 functions.
GRANT EXECUTE ON FUNCTION public.mb13_p0_hash_jsonb(JSONB) TO mb13_p2_writer;

-- ----------------------------------------------------------------------------
-- Drop old function overloads whose return type changed
-- ----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.mb13_p2_evaluate_due_state(UUID, UUID, TIMESTAMPTZ);
DROP FUNCTION IF EXISTS public.mb13_p2_get_timeline(UUID, UUID, INTEGER, INTEGER);
DROP FUNCTION IF EXISTS public.mb13_p2_fire_reminder(UUID, UUID);
DROP FUNCTION IF EXISTS public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN);
DROP FUNCTION IF EXISTS public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB);
DROP FUNCTION IF EXISTS public.mb13_p2_schedule_reminder(UUID, UUID, TIMESTAMPTZ, TEXT, TEXT, JSONB);

-- ----------------------------------------------------------------------------
-- Helper: due-state computation (unchanged contract)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_compute_due_state(
    p_due_at TIMESTAMPTZ,
    p_grace_until TIMESTAMPTZ,
    p_now TIMESTAMPTZ
) RETURNS TEXT AS $$
BEGIN
    IF p_due_at IS NULL THEN
        RETURN 'not_due';
    END IF;
    IF p_now < p_due_at THEN
        RETURN 'not_due';
    END IF;
    IF p_grace_until IS NULL THEN
        RETURN 'due';
    END IF;
    IF p_now < p_grace_until THEN
        RETURN 'grace';
    END IF;
    RETURN 'expired';
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- ----------------------------------------------------------------------------
-- Monotonic, revision-bound and owner-isolated due-state evaluation
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_evaluate_due_state(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_evaluated_at TIMESTAMPTZ DEFAULT NOW()
) RETURNS TABLE(
    monitor_id UUID,
    due_state TEXT,
    previous_state TEXT,
    changed BOOLEAN,
    evaluated_at TIMESTAMPTZ,
    monitor_revision INTEGER,
    policy_hash TEXT
) AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_target public.mb13_p0_monitor_target%ROWTYPE;
    v_current public.mb13_p2_monitor_state%ROWTYPE;
    v_previous_state TEXT;
    v_new_state TEXT;
    v_policy_hash TEXT;
    v_monitor_revision INTEGER;
    v_due_at TIMESTAMPTZ;
    v_grace_until TIMESTAMPTZ;
    v_changed BOOLEAN;
    v_event_payload JSONB;
    v_event_hash TEXT;
    v_event_kind TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    -- Deterministic lock order: monitor first, then state.
    SELECT * INTO v_target
      FROM public.mb13_p0_monitor_target t
     WHERE t.owner_user_id = p_owner_user_id
       AND t.monitor_id = p_monitor_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_monitor_not_found';
    END IF;

    SELECT * INTO v_current
      FROM public.mb13_p2_monitor_state s
     WHERE s.owner_user_id = p_owner_user_id
       AND s.monitor_id = p_monitor_id
     FOR UPDATE;

    v_previous_state := v_current.due_state;
    v_monitor_revision := v_target.current_revision;
    v_policy_hash := public.mb13_p0_hash_jsonb(v_target.monitor_policy);
    v_due_at := (v_target.monitor_policy->>'due_at')::TIMESTAMPTZ;
    v_grace_until := (v_target.monitor_policy->>'grace_until')::TIMESTAMPTZ;

    IF v_target.monitor_state = 'completed' THEN
        v_new_state := 'completed';
    ELSE
        v_new_state := public.mb13_p2_compute_due_state(v_due_at, v_grace_until, p_evaluated_at);
    END IF;

    -- Reject older evaluations: they cannot overwrite a newer canonical state.
    IF v_current.evaluated_at IS NOT NULL AND p_evaluated_at < v_current.evaluated_at THEN
        RETURN QUERY SELECT p_monitor_id, v_current.due_state, v_current.due_state,
                            FALSE::BOOLEAN, v_current.evaluated_at,
                            v_current.monitor_revision, v_current.policy_hash;
        RETURN;
    END IF;

    v_changed := (v_previous_state IS DISTINCT FROM v_new_state);

    IF v_changed THEN
        IF v_current.due_state IS NULL THEN
            INSERT INTO public.mb13_p2_monitor_state (
                owner_user_id, monitor_id, due_state, due_at, grace_until,
                next_check_at, evaluated_at, payload_hash, monitor_revision, policy_hash
            ) VALUES (
                p_owner_user_id, p_monitor_id, v_new_state, v_due_at, v_grace_until,
                (v_target.monitor_policy->>'next_check_at')::TIMESTAMPTZ,
                p_evaluated_at,
                public.mb13_p0_hash_jsonb(jsonb_build_object(
                    'owner_user_id', p_owner_user_id,
                    'monitor_id', p_monitor_id,
                    'due_state', v_new_state,
                    'due_at', v_due_at,
                    'grace_until', v_grace_until,
                    'next_check_at', (v_target.monitor_policy->>'next_check_at')::TIMESTAMPTZ,
                    'evaluated_at', p_evaluated_at,
                    'monitor_revision', v_monitor_revision,
                    'policy_hash', v_policy_hash
                )),
                v_monitor_revision, v_policy_hash
            )
            ON CONFLICT ON CONSTRAINT mb13_p2_monitor_state_pkey DO NOTHING
            RETURNING * INTO v_current;

            IF NOT FOUND THEN
                -- Another transaction inserted the row concurrently.
                SELECT * INTO v_current
                  FROM public.mb13_p2_monitor_state s
                 WHERE s.owner_user_id = p_owner_user_id
                   AND s.monitor_id = p_monitor_id
                 FOR UPDATE;
                v_previous_state := v_current.due_state;
                -- Reconcile: only overwrite if the new evaluation is still newer/different.
                IF p_evaluated_at < v_current.evaluated_at THEN
                    RETURN QUERY SELECT p_monitor_id, v_current.due_state, v_current.due_state,
                                        FALSE::BOOLEAN, v_current.evaluated_at,
                                        v_current.monitor_revision, v_current.policy_hash;
                    RETURN;
                END IF;
                v_changed := (v_previous_state IS DISTINCT FROM v_new_state);
                IF NOT v_changed THEN
                    RETURN QUERY SELECT p_monitor_id, v_new_state, v_previous_state,
                                        FALSE::BOOLEAN, p_evaluated_at,
                                        v_current.monitor_revision, v_current.policy_hash;
                    RETURN;
                END IF;
            END IF;
        ELSE
            EXECUTE '
                UPDATE public.mb13_p2_monitor_state
                   SET due_state = $1,
                       due_at = $2,
                       grace_until = $3,
                       next_check_at = $4,
                       evaluated_at = $5,
                       payload_hash = $6,
                       monitor_revision = $7,
                       policy_hash = $8
                 WHERE owner_user_id = $9
                   AND monitor_id = $10
            '
            USING v_new_state, v_due_at, v_grace_until,
                  (v_target.monitor_policy->>'next_check_at')::TIMESTAMPTZ,
                  p_evaluated_at,
                  public.mb13_p0_hash_jsonb(jsonb_build_object(
                      'owner_user_id', p_owner_user_id,
                      'monitor_id', p_monitor_id,
                      'due_state', v_new_state,
                      'due_at', v_due_at,
                      'grace_until', v_grace_until,
                      'next_check_at', (v_target.monitor_policy->>'next_check_at')::TIMESTAMPTZ,
                      'evaluated_at', p_evaluated_at,
                      'monitor_revision', v_monitor_revision,
                      'policy_hash', v_policy_hash
                  )),
                  v_monitor_revision, v_policy_hash,
                  p_owner_user_id, p_monitor_id;
        END IF;
    END IF;

    IF v_changed THEN
        v_event_payload := jsonb_build_object(
            'evaluated_at', p_evaluated_at,
            'due_at', v_due_at,
            'grace_until', v_grace_until,
            'monitor_revision', v_monitor_revision,
            'policy_hash', v_policy_hash
        );

        v_event_kind := 'state_change';
        IF v_new_state = 'due' THEN
            v_event_kind := 'due_entered';
        ELSIF v_new_state = 'grace' THEN
            v_event_kind := 'grace_entered';
        ELSIF v_new_state = 'expired' THEN
            v_event_kind := 'expired';
        ELSIF v_new_state = 'completed' THEN
            v_event_kind := 'completed';
        END IF;

        v_event_hash := public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', p_monitor_id,
            'event_kind', v_event_kind,
            'from_state', v_previous_state,
            'to_state', v_new_state,
            'event_time', p_evaluated_at,
            'event_payload', v_event_payload
        ));

        INSERT INTO public.mb13_p2_monitor_timeline (
            owner_user_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, payload_hash, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, p_monitor_id, v_event_kind, v_previous_state, v_new_state,
            p_evaluated_at, v_event_payload, v_event_hash, v_monitor_revision, v_policy_hash
        );
    END IF;

    RETURN QUERY SELECT p_monitor_id, v_new_state, v_previous_state, v_changed,
                        p_evaluated_at, v_monitor_revision, v_policy_hash;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p2_evaluate_due_state(UUID, UUID, TIMESTAMPTZ) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p2_evaluate_due_state(UUID, UUID, TIMESTAMPTZ) FROM anon, authenticated, service_role;
ALTER FUNCTION public.mb13_p2_evaluate_due_state(UUID, UUID, TIMESTAMPTZ) OWNER TO mb13_p2_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p2_evaluate_due_state(UUID, UUID, TIMESTAMPTZ) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_evaluate_due_state(UUID, UUID, TIMESTAMPTZ) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Read timeline (revision/provenance aware)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_get_timeline(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_limit INTEGER DEFAULT 100,
    p_offset INTEGER DEFAULT 0
) RETURNS TABLE(
    timeline_event_id UUID,
    event_kind TEXT,
    from_state TEXT,
    to_state TEXT,
    event_time TIMESTAMPTZ,
    event_payload JSONB,
    payload_hash TEXT,
    monitor_revision INTEGER,
    policy_hash TEXT
) AS $$
BEGIN
    IF NULLIF(current_setting('app.owner_id', true), '')::UUID IS DISTINCT FROM p_owner_user_id THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    RETURN QUERY
    SELECT t.timeline_event_id, t.event_kind, t.from_state, t.to_state,
           t.event_time, t.event_payload, t.payload_hash,
           t.monitor_revision, t.policy_hash
      FROM public.mb13_p2_monitor_timeline t
     WHERE t.owner_user_id = p_owner_user_id
       AND t.monitor_id = p_monitor_id
     ORDER BY t.event_time DESC, t.timeline_event_id DESC
     LIMIT p_limit OFFSET p_offset;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p2_get_timeline(UUID, UUID, INTEGER, INTEGER) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p2_get_timeline(UUID, UUID, INTEGER, INTEGER) FROM anon, authenticated, service_role;
ALTER FUNCTION public.mb13_p2_get_timeline(UUID, UUID, INTEGER, INTEGER) OWNER TO mb13_p2_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p2_get_timeline(UUID, UUID, INTEGER, INTEGER) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_get_timeline(UUID, UUID, INTEGER, INTEGER) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Schedule reminder (future time, atomic)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_schedule_reminder(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_remind_at TIMESTAMPTZ,
    p_reminder_kind TEXT,
    p_channel TEXT DEFAULT 'in_app',
    p_payload JSONB DEFAULT '{}'::jsonb,
    p_immediate BOOLEAN DEFAULT FALSE
) RETURNS UUID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_reminder_id UUID := gen_random_uuid();
    v_now TIMESTAMPTZ := NOW();
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;
    IF p_remind_at IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_reminder_time_invalid';
    END IF;
    IF p_remind_at <= v_now AND NOT p_immediate THEN
        RAISE EXCEPTION 'mb13_p2_reminder_time_obsolete';
    END IF;
    IF p_reminder_kind NOT IN ('pre_due','due','grace','expired','custom') THEN
        RAISE EXCEPTION 'mb13_p2_reminder_kind_invalid';
    END IF;
    IF p_channel NOT IN ('in_app','email','push','sms') THEN
        RAISE EXCEPTION 'mb13_p2_reminder_channel_invalid';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.mb13_p0_monitor_target t
                    WHERE t.owner_user_id = p_owner_user_id
                      AND t.monitor_id = p_monitor_id) THEN
        RAISE EXCEPTION 'mb13_p2_monitor_not_found';
    END IF;

    INSERT INTO public.mb13_p2_reminder_schedule (
        reminder_id, owner_user_id, monitor_id, remind_at, reminder_kind,
        channel, status, payload
    ) VALUES (
        v_reminder_id, p_owner_user_id, p_monitor_id, p_remind_at,
        p_reminder_kind, p_channel, 'pending', COALESCE(p_payload, '{}'::jsonb)
    );

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_monitor_id, 'reminder_scheduled', NULL, NULL,
        v_now, jsonb_build_object('reminder_id', v_reminder_id, 'reminder_kind', p_reminder_kind, 'channel', p_channel, 'remind_at', p_remind_at),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', p_monitor_id,
            'event_kind', 'reminder_scheduled',
            'from_state', NULL,
            'to_state', NULL,
            'event_time', v_now,
            'event_payload', jsonb_build_object('reminder_id', v_reminder_id, 'reminder_kind', p_reminder_kind, 'channel', p_channel, 'remind_at', p_remind_at)
        )),
        NULL, NULL
    );

    RETURN v_reminder_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p2_schedule_reminder(UUID, UUID, TIMESTAMPTZ, TEXT, TEXT, JSONB, BOOLEAN) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p2_schedule_reminder(UUID, UUID, TIMESTAMPTZ, TEXT, TEXT, JSONB, BOOLEAN) FROM anon, authenticated, service_role;
ALTER FUNCTION public.mb13_p2_schedule_reminder(UUID, UUID, TIMESTAMPTZ, TEXT, TEXT, JSONB, BOOLEAN) OWNER TO mb13_p2_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p2_schedule_reminder(UUID, UUID, TIMESTAMPTZ, TEXT, TEXT, JSONB, BOOLEAN) TO mb13_p2_api;

-- ----------------------------------------------------------------------------
-- Fire reminder (executor-only, atomic temporal eligibility)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_fire_reminder(
    p_owner_user_id UUID,
    p_reminder_id UUID,
    p_execution_time TIMESTAMPTZ DEFAULT NOW()
) RETURNS TABLE(
    reminder_id UUID,
    monitor_id UUID,
    status TEXT,
    dispatched_at TIMESTAMPTZ
) AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_reminder public.mb13_p2_reminder_schedule%ROWTYPE;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    SELECT * INTO v_reminder
      FROM public.mb13_p2_reminder_schedule r
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id
     FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_reminder_not_found';
    END IF;
    IF v_reminder.status <> 'pending' THEN
        RAISE EXCEPTION 'mb13_p2_reminder_already_handled';
    END IF;
    IF v_reminder.remind_at > p_execution_time THEN
        RAISE EXCEPTION 'mb13_p2_reminder_too_early';
    END IF;

    UPDATE public.mb13_p2_reminder_schedule r
       SET status = 'dispatched',
           dispatched_at = p_execution_time
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id;

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_reminder.monitor_id, 'reminder_fired', 'pending', 'dispatched',
        p_execution_time, jsonb_build_object('reminder_id', p_reminder_id, 'reminder_kind', v_reminder.reminder_kind, 'channel', v_reminder.channel),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', v_reminder.monitor_id,
            'event_kind', 'reminder_fired',
            'from_state', 'pending',
            'to_state', 'dispatched',
            'event_time', p_execution_time,
            'event_payload', jsonb_build_object('reminder_id', p_reminder_id, 'reminder_kind', v_reminder.reminder_kind, 'channel', v_reminder.channel)
        )),
        NULL, NULL
    );

    RETURN QUERY SELECT v_reminder.reminder_id, v_reminder.monitor_id, 'dispatched'::TEXT, p_execution_time;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p2_fire_reminder(UUID, UUID, TIMESTAMPTZ) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p2_fire_reminder(UUID, UUID, TIMESTAMPTZ) FROM anon, authenticated, service_role;
ALTER FUNCTION public.mb13_p2_fire_reminder(UUID, UUID, TIMESTAMPTZ) OWNER TO mb13_p2_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p2_fire_reminder(UUID, UUID, TIMESTAMPTZ) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Cancel reminder (API/executor allowed)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_cancel_reminder(
    p_owner_user_id UUID,
    p_reminder_id UUID
) RETURNS VOID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_reminder public.mb13_p2_reminder_schedule%ROWTYPE;
    v_now TIMESTAMPTZ := NOW();
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    SELECT * INTO v_reminder
      FROM public.mb13_p2_reminder_schedule r
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id
     FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_reminder_not_found';
    END IF;
    IF v_reminder.status NOT IN ('pending','dispatched') THEN
        RAISE EXCEPTION 'mb13_p2_reminder_cannot_cancel';
    END IF;

    UPDATE public.mb13_p2_reminder_schedule r
       SET status = 'cancelled'
     WHERE r.owner_user_id = p_owner_user_id
       AND r.reminder_id = p_reminder_id;

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_reminder.monitor_id, 'reminder_cancelled', v_reminder.status, 'cancelled',
        v_now, jsonb_build_object('reminder_id', p_reminder_id),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', v_reminder.monitor_id,
            'event_kind', 'reminder_cancelled',
            'from_state', v_reminder.status,
            'to_state', 'cancelled',
            'event_time', v_now,
            'event_payload', jsonb_build_object('reminder_id', p_reminder_id)
        )),
        NULL, NULL
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) FROM anon, authenticated, service_role;
ALTER FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) OWNER TO mb13_p2_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_reminder(UUID, UUID) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Schedule retry (future time, original-event binding, idempotence)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_schedule_retry(
    p_owner_user_id UUID,
    p_monitor_id UUID,
    p_original_event_id UUID,
    p_next_retry_at TIMESTAMPTZ,
    p_max_retries INTEGER DEFAULT 3,
    p_backoff_kind TEXT DEFAULT 'exponential',
    p_last_error_payload JSONB DEFAULT '{}'::jsonb,
    p_immediate BOOLEAN DEFAULT FALSE
) RETURNS UUID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_retry_id UUID := gen_random_uuid();
    v_now TIMESTAMPTZ := NOW();
    v_original public.mb13_p2_monitor_timeline%ROWTYPE;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;
    IF p_next_retry_at IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_retry_time_invalid';
    END IF;
    IF p_next_retry_at <= v_now AND NOT p_immediate THEN
        RAISE EXCEPTION 'mb13_p2_retry_time_obsolete';
    END IF;
    IF p_max_retries < 0 OR p_max_retries > 20 THEN
        RAISE EXCEPTION 'mb13_p2_retry_max_invalid';
    END IF;
    IF p_backoff_kind NOT IN ('fixed','exponential','linear','none') THEN
        RAISE EXCEPTION 'mb13_p2_retry_backoff_invalid';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.mb13_p0_monitor_target t
                    WHERE t.owner_user_id = p_owner_user_id
                      AND t.monitor_id = p_monitor_id) THEN
        RAISE EXCEPTION 'mb13_p2_monitor_not_found';
    END IF;

    IF p_original_event_id IS NOT NULL THEN
        SELECT * INTO v_original
          FROM public.mb13_p2_monitor_timeline
         WHERE timeline_event_id = p_original_event_id
           AND owner_user_id = p_owner_user_id
           AND monitor_id = p_monitor_id;

        IF NOT FOUND THEN
            RAISE EXCEPTION 'mb13_p2_original_event_not_found';
        END IF;
        IF v_original.event_kind IN ('reminder_cancelled','retry_cancelled','retry_expired','expired') THEN
            RAISE EXCEPTION 'mb13_p2_original_event_cancelled_or_final';
        END IF;
    END IF;

    INSERT INTO public.mb13_p2_retry_schedule (
        retry_id, owner_user_id, monitor_id, original_event_id, retry_count,
        max_retries, next_retry_at, backoff_kind, status, last_error_payload
    ) VALUES (
        v_retry_id, p_owner_user_id, p_monitor_id, p_original_event_id, 0,
        p_max_retries, p_next_retry_at, p_backoff_kind, 'pending', COALESCE(p_last_error_payload, '{}'::jsonb)
    );

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, p_monitor_id, 'retry_scheduled', NULL, NULL,
        v_now, jsonb_build_object('retry_id', v_retry_id, 'max_retries', p_max_retries, 'backoff_kind', p_backoff_kind, 'original_event_id', p_original_event_id, 'next_retry_at', p_next_retry_at, 'immediate', p_immediate),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', p_monitor_id,
            'event_kind', 'retry_scheduled',
            'from_state', NULL,
            'to_state', NULL,
            'event_time', v_now,
            'event_payload', jsonb_build_object('retry_id', v_retry_id, 'max_retries', p_max_retries, 'backoff_kind', p_backoff_kind, 'original_event_id', p_original_event_id, 'next_retry_at', p_next_retry_at, 'immediate', p_immediate)
        )),
        NULL, NULL
    );

    RETURN v_retry_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB, BOOLEAN) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB, BOOLEAN) FROM anon, authenticated, service_role;
ALTER FUNCTION public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB, BOOLEAN) OWNER TO mb13_p2_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p2_schedule_retry(UUID, UUID, UUID, TIMESTAMPTZ, INTEGER, TEXT, JSONB, BOOLEAN) TO mb13_p2_api;

-- ----------------------------------------------------------------------------
-- Advance retry (executor-only, atomic temporal eligibility)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_advance_retry(
    p_owner_user_id UUID,
    p_retry_id UUID,
    p_success BOOLEAN DEFAULT FALSE,
    p_execution_time TIMESTAMPTZ DEFAULT NOW()
) RETURNS TABLE(
    retry_id UUID,
    monitor_id UUID,
    status TEXT,
    retry_count INTEGER,
    next_retry_at TIMESTAMPTZ,
    executed_at TIMESTAMPTZ
) AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_retry public.mb13_p2_retry_schedule%ROWTYPE;
    v_next_at TIMESTAMPTZ;
    v_new_count INTEGER;
    v_interval INTERVAL;
    v_event_kind TEXT;
    v_to_state TEXT;
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    SELECT * INTO v_retry
      FROM public.mb13_p2_retry_schedule rz
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id
     FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_retry_not_found';
    END IF;
    IF v_retry.status <> 'pending' THEN
        RAISE EXCEPTION 'mb13_p2_retry_not_pending';
    END IF;
    IF v_retry.next_retry_at > p_execution_time THEN
        RAISE EXCEPTION 'mb13_p2_retry_too_early';
    END IF;

    IF p_success THEN
        UPDATE public.mb13_p2_retry_schedule rz
           SET status = 'completed',
               last_fired_at = p_execution_time
         WHERE rz.owner_user_id = p_owner_user_id
           AND rz.retry_id = p_retry_id;

        INSERT INTO public.mb13_p2_monitor_timeline (
            owner_user_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, payload_hash, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, v_retry.monitor_id, 'retry_completed', 'pending', 'completed',
            p_execution_time, jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_retry.retry_count, 'success', true),
            public.mb13_p0_hash_jsonb(jsonb_build_object(
                'owner_user_id', p_owner_user_id,
                'monitor_id', v_retry.monitor_id,
                'event_kind', 'retry_completed',
                'from_state', 'pending',
                'to_state', 'completed',
                'event_time', p_execution_time,
                'event_payload', jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_retry.retry_count, 'success', true)
            )),
            NULL, NULL
        );

        RETURN QUERY SELECT p_retry_id, v_retry.monitor_id, 'completed'::TEXT, v_retry.retry_count, v_retry.next_retry_at, p_execution_time;
        RETURN;
    END IF;

    v_new_count := v_retry.retry_count + 1;
    IF v_new_count >= v_retry.max_retries THEN
        UPDATE public.mb13_p2_retry_schedule rz
           SET status = 'expired',
               retry_count = v_new_count,
               last_fired_at = p_execution_time
         WHERE rz.owner_user_id = p_owner_user_id
           AND rz.retry_id = p_retry_id;

        INSERT INTO public.mb13_p2_monitor_timeline (
            owner_user_id, monitor_id, event_kind, from_state, to_state,
            event_time, event_payload, payload_hash, monitor_revision, policy_hash
        ) VALUES (
            p_owner_user_id, v_retry.monitor_id, 'retry_expired', 'pending', 'expired',
            p_execution_time, jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_new_count, 'success', false),
            public.mb13_p0_hash_jsonb(jsonb_build_object(
                'owner_user_id', p_owner_user_id,
                'monitor_id', v_retry.monitor_id,
                'event_kind', 'retry_expired',
                'from_state', 'pending',
                'to_state', 'expired',
                'event_time', p_execution_time,
                'event_payload', jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_new_count, 'success', false)
            )),
            NULL, NULL
        );

        RETURN QUERY SELECT p_retry_id, v_retry.monitor_id, 'expired'::TEXT, v_new_count, v_retry.next_retry_at, p_execution_time;
        RETURN;
    END IF;

    IF v_retry.backoff_kind = 'fixed' THEN
        v_interval := '1 minute'::INTERVAL;
    ELSIF v_retry.backoff_kind = 'linear' THEN
        v_interval := (v_new_count * '1 minute'::INTERVAL);
    ELSIF v_retry.backoff_kind = 'exponential' THEN
        v_interval := (POWER(2, v_new_count)::INTEGER * '1 minute'::INTERVAL);
    ELSE
        v_interval := '0 minutes'::INTERVAL;
    END IF;

    v_next_at := p_execution_time + v_interval;

    UPDATE public.mb13_p2_retry_schedule rz
       SET retry_count = v_new_count,
           next_retry_at = v_next_at,
           last_fired_at = p_execution_time
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id;

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_retry.monitor_id, 'retry_fired', 'pending', 'pending',
        p_execution_time, jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_new_count, 'success', false, 'next_retry_at', v_next_at),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', v_retry.monitor_id,
            'event_kind', 'retry_fired',
            'from_state', 'pending',
            'to_state', 'pending',
            'event_time', p_execution_time,
            'event_payload', jsonb_build_object('retry_id', p_retry_id, 'retry_count', v_new_count, 'success', false, 'next_retry_at', v_next_at)
        )),
        NULL, NULL
    );

    RETURN QUERY SELECT p_retry_id, v_retry.monitor_id, 'pending'::TEXT, v_new_count, v_next_at, p_execution_time;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN, TIMESTAMPTZ) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN, TIMESTAMPTZ) FROM anon, authenticated, service_role;
ALTER FUNCTION public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN, TIMESTAMPTZ) OWNER TO mb13_p2_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p2_advance_retry(UUID, UUID, BOOLEAN, TIMESTAMPTZ) TO mb13_p2_executor;

-- ----------------------------------------------------------------------------
-- Cancel retry
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mb13_p2_cancel_retry(
    p_owner_user_id UUID,
    p_retry_id UUID
) RETURNS VOID AS $$
DECLARE
    v_session_owner UUID := NULLIF(current_setting('app.owner_id', true), '')::UUID;
    v_retry public.mb13_p2_retry_schedule%ROWTYPE;
    v_now TIMESTAMPTZ := NOW();
BEGIN
    IF v_session_owner IS NULL THEN
        RAISE EXCEPTION 'mb13_p2_owner_missing';
    END IF;
    IF p_owner_user_id IS DISTINCT FROM v_session_owner THEN
        RAISE EXCEPTION 'mb13_p2_owner_mismatch';
    END IF;

    SELECT * INTO v_retry
      FROM public.mb13_p2_retry_schedule rz
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id
     FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'mb13_p2_retry_not_found';
    END IF;
    IF v_retry.status NOT IN ('pending') THEN
        RAISE EXCEPTION 'mb13_p2_retry_cannot_cancel';
    END IF;

    UPDATE public.mb13_p2_retry_schedule rz
       SET status = 'cancelled'
     WHERE rz.owner_user_id = p_owner_user_id
       AND rz.retry_id = p_retry_id;

    INSERT INTO public.mb13_p2_monitor_timeline (
        owner_user_id, monitor_id, event_kind, from_state, to_state,
        event_time, event_payload, payload_hash, monitor_revision, policy_hash
    ) VALUES (
        p_owner_user_id, v_retry.monitor_id, 'retry_cancelled', 'pending', 'cancelled',
        v_now, jsonb_build_object('retry_id', p_retry_id),
        public.mb13_p0_hash_jsonb(jsonb_build_object(
            'owner_user_id', p_owner_user_id,
            'monitor_id', v_retry.monitor_id,
            'event_kind', 'retry_cancelled',
            'from_state', 'pending',
            'to_state', 'cancelled',
            'event_time', v_now,
            'event_payload', jsonb_build_object('retry_id', p_retry_id)
        )),
        NULL, NULL
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public;

REVOKE ALL ON FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) FROM anon, authenticated, service_role;
ALTER FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) OWNER TO mb13_p2_writer;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) TO mb13_p2_api;
GRANT EXECUTE ON FUNCTION public.mb13_p2_cancel_retry(UUID, UUID) TO mb13_p2_executor;


-- Close the temporary ownership-handoff privileges.
REVOKE CREATE ON SCHEMA public FROM mb13_p2_writer;
REVOKE SET OPTION FOR mb13_p2_writer FROM CURRENT_USER;
REVOKE INHERIT OPTION FOR mb13_p2_writer FROM CURRENT_USER;

COMMIT;
