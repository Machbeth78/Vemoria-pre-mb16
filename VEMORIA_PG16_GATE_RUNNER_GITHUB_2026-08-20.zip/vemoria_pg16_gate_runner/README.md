# Vemoria PRE-MB16 PostgreSQL 16 Gate Runner

Repository dedicato esclusivamente al gate runtime PostgreSQL 16 prima di MB16.

Stato attuale: il workflow prova un server PostgreSQL 16 reale (`postgres:16`), verifica `server_version_num=16xxxx`, installa `uuid-ossp`, `pgcrypto`, `pg_trgm` ed esegue `checks/00_PRECHECK.sql`.

**Non dichiara PRE-MB16-FINAL-CLEAN da solo.** Per la chiusura finale deve essere aggiunta ed eseguita la catena di migration verificata v0→v296 dal FULL canonico, seguita da `checks/90_POST_MIGRATION_AUDIT.sql` e `checks/91_V296_RLS_OWNER_ISOLATION_SMOKE.sql`.

MB16 resta bloccato fino a quel PASS completo.
